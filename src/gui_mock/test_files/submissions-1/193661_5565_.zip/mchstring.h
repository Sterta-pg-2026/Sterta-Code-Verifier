#pragma once
#include <string.h>
#include <iostream>

class MchString
{
public:
	MchString();
	MchString(const char* str);
	~MchString();

	void AddChar(char c);
	int GetLength();
	bool IsDigit();
	int ToInt();
	bool Compare(const MchString* str);
	void Trim();

	bool operator==(const char* str) const;

	bool operator==(const MchString* str) const;

	friend std::ostream& operator<<(std::ostream& stream, MchString& str);
	friend std::ostream& operator<<(std::ostream& stream, MchString* str);

private:
	char* string;
	int length;
	int allocatedSize;

	void AllocateMore();
	void DeleteString();
};

inline MchString::MchString()
{
	length = 0;
	allocatedSize = 1;
	string = new char[allocatedSize];
	string[length] = 0;
}

inline MchString::MchString(const char* str)
{
	length = strlen(str);
	allocatedSize = 1;
	
	for (; length >= allocatedSize; allocatedSize *= 2);

	string = new char[allocatedSize];
	strcpy_s(string, allocatedSize, str);
}

inline MchString::~MchString()
{
	DeleteString();
}

inline void MchString::AddChar(char c)
{
	if (length >= allocatedSize - 1) 
	{
		AllocateMore();
	}

	string[length++] = c;
	string[length] = 0;
}

inline int MchString::GetLength()
{
	return length;
}

inline bool MchString::IsDigit()
{
	for (int i = 0; i < length; i++)
	{
		if (string[i] < 48 || string[i] > 57)
		{
			return false;
		}
	}

	return true;
}

inline int MchString::ToInt()
{
	return atoi(string);
}

inline bool MchString::Compare(const MchString* str)
{
	if (string == nullptr || str->string == nullptr)
	{
		return false;
	}

	return strcmp(string, str->string) == 0;
}

inline void MchString::Trim()
{
	for (int i = length - 1; i >= 0; i--)
	{
		if (string[i] != ' ' && string[i] != '\n')
		{
			return;
		}

		string[i] = '\0';
		length--;
	}
}

inline bool MchString::operator==(const char* str) const
{
	if (string == nullptr || str == nullptr)
	{
		return false;
	}

	return strcmp(string, str) == 0;
}

inline bool MchString::operator==(const MchString* str) const
{
	if (string == nullptr || str->string == nullptr)
	{
		return false;
	}

	return strcmp(string, str->string) == 0;
}

std::ostream& operator<<(std::ostream& stream, MchString& str)
{
	return stream << str.string;
}

std::ostream& operator<<(std::ostream& stream, MchString* str)
{
	return stream << str->string;
}

inline void MchString::AllocateMore()
{
	allocatedSize *= 2;
	char* newString = new char[allocatedSize];
	strcpy_s(newString, allocatedSize, string);
	DeleteString();
	string = newString;
}

inline void MchString::DeleteString()
{
	if (string != nullptr)
	{
		delete[] string;
		string = nullptr;
	}
}
