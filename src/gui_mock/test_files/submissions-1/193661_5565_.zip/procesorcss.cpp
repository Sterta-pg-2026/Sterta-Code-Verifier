#include "parser.h"
#include <iostream>

int main()
{
    Parser parser;
    char c;

    while (std::cin >> std::noskipws >> c)
    {
        parser.Procese(c);
    }
    parser.Procese('\n');

    return 0;
}