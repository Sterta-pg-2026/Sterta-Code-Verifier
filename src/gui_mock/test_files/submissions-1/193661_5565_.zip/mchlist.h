#pragma once
#include <stdexcept>
#define BLOCK_SIZE 29

template <typename T>
class MchList
{
	struct Node
	{
		T data[BLOCK_SIZE];
		bool used[BLOCK_SIZE]{};
		int usedCount = 0;
		int freeIndex = 0;
		Node* previous = nullptr;
		Node* next = nullptr;
	};

	Node* head = nullptr;
	Node* tail = nullptr;
	int nodeCount = 0;
	int size = 0;

	void removeNode(Node* node)
	{
		if (node == tail)
		{
			tail = node->previous;
		}

		if (node == head)
		{
			head = node->next;
		}

		if (node->previous != nullptr)
		{
			node->previous->next = node->next;
		}

		if (node->next != nullptr)
		{
			node->next->previous = node->previous;
		}

		size--;
		delete node;
	}

	void addNewNodeToTail()
	{
		Node* node = new Node();
		node->previous = tail;

		if (tail != nullptr)
		{
			tail->next = node;
		}
		tail = node;

		if (head == nullptr)
		{
			head = node;
		}

		nodeCount++;
	}

public:

	int Add(const T element)
	{
		if (tail == nullptr || tail->freeIndex >= BLOCK_SIZE)
		{
			addNewNodeToTail();
		}
				
		tail->data[tail->freeIndex] = element;
		tail->used[tail->freeIndex] = 1;
		tail->freeIndex++;
		tail->usedCount++;

		return size++;
	}

	T& Last()
	{
		if (size < 1)
		{
			throw std::length_error("List is empty");
		}

		return tail->data[tail->freeIndex - 1];
	}

	T& Get(int index)
	{
		int sum = 0;
		Node* node = head;
		for (int i = 0; i < nodeCount; i++)
		{
			if (sum + node->usedCount > index)
			{
				sum--;
				for (int j = 0; j < node->freeIndex; j++)
				{
					sum += node->used[j];

					if (sum == index)
					{
						return node->data[j];
					}
				}
			}

			sum += node->usedCount;
			node = node->next;
		}

		throw std::length_error("Out of the range in Get method");
	}

	bool Remove(int index)
	{
		int sum = 0;
		Node* node = head;
		for (int i = 0; i < nodeCount; i++)
		{
			if (sum + node->usedCount > index)
			{
				sum--;
				for (int j = 0; j < node->freeIndex; j++)
				{
					sum += node->used[j];

					if (sum == index)
					{
						node->data[j] = T();
						node->used[j] = false;
						node->usedCount--;
						size--;
						return true;
					}
				}
			}

			sum += node->usedCount;
			node = node->next;
		}

		return false;
		throw std::length_error("Out of the range");
	}

	int GetSize()
	{
		return size;
	}

	~MchList()
	{
	}

	class Iterator
	{
	public:
		Iterator(Node* node, int index, int& size) : current(node), index(index), listSize(size) {}

		void operator++()
		{
			index++;

			if (index >= BLOCK_SIZE)
			{
				index = 0;
				current = current->next;

				if (current == nullptr)
				{
					return;
				}
			}

			while (!current->used[index])
			{
				index++;

				if (index >= BLOCK_SIZE)
				{
					index = 0;
					current = current->next;

					if (current == nullptr)
					{
						return;
					}
				}
			}
		}

		void operator=(const T& value) 
		{ 
			current->data[index] = value;
		};

		bool operator!=(const Iterator& other) const
		{
			return current != other.current || index != other.index;
		}

		T& operator*()
		{
			return current->data[index];
		}

		bool Remove()
		{
			if (current == nullptr)
			{
				return false;
			}

			current->data[index] = T();
			current->used[index] = false;
			current->usedCount--;
			listSize--;

			return true;
		}

	private:
		Node* current;
		int index;
		int& listSize;
	};

	Iterator Begin()
	{
		Node* node = head;
		while (node != nullptr)
		{
			if (node->usedCount)
			{
				for (int i = 0; i < BLOCK_SIZE; i++)
				{
					if (node->used[i])
					{
						return Iterator(node, i, size);
					}
				}
			}

			node = node->next;
		}

		return End();
	}

	Iterator End()
	{
		return Iterator(nullptr, 0, size);
	}

};