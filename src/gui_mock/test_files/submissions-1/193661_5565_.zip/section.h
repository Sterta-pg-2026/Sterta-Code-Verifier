#pragma once
#include "mchstring.h"

class Section
{
public:
	struct Attribute
	{
		MchString* Key = new MchString();
		MchString* Value = new MchString();
	};

	MchList<MchString*> Selectors;
	MchList<Attribute> Attributes;

	bool DeleteAttribute(const MchString* name);
	bool IsEmpty();
	int GetSelectorCount();
	int GetAttributeCount();
	MchString* GetSelector(int index);
	MchString* GetAttributeValue(const MchString* name);
	bool FindSelector(const MchString* name);
	bool FindAttribute(const MchString* name);
	void DeleteDuplicate();
	void TrimLastSelector();
};

inline bool Section::DeleteAttribute(const MchString* name)
{
	for (auto it = Attributes.Begin(); it != Attributes.End(); ++it)
	{
		if ((*it).Key->Compare(name))
		{
			it.Remove();
			return true;
		}
	}

	return false;
}

inline bool Section::IsEmpty()
{
	return !Attributes.GetSize();
}

inline int Section::GetSelectorCount()
{
	return Selectors.GetSize();
}

inline int Section::GetAttributeCount()
{
	return Attributes.GetSize();
}

inline MchString* Section::GetSelector(int index)
{
	try
	{
		return Selectors.Get(index);
	}
	catch (const std::exception&)
	{
		return nullptr;
	}
}

inline MchString* Section::GetAttributeValue(const MchString* name)
{
	for (auto it = Attributes.Begin(); it != Attributes.End(); ++it)
	{
		if ((*it).Key->Compare(name))
		{
			return (*it).Value;
		}
	}

	return nullptr;
}

inline bool Section::FindSelector(const MchString* name)
{
	for (auto it = Selectors.Begin(); it != Selectors.End(); ++it)
	{
		if ((*it)->Compare(name))
		{
			return true;
		}
	}

	return false;
}

inline bool Section::FindAttribute(const MchString* name)
{
	for (auto it = Attributes.Begin(); it != Attributes.End(); ++it)
	{
		if ((*it).Key->Compare(name))
		{
			return true;
		}
	}

	return false;
}

inline void Section::DeleteDuplicate()
{
	auto it = Attributes.Begin();
	for (int i = 0; i < Attributes.GetSize() - 1; i++)
	{
		if ((*it).Key->Compare(Attributes.Last().Key))
		{
			it.Remove();
			return;
		}

		++it;
	}
}

inline void Section::TrimLastSelector()
{
	if (Selectors.GetSize())
	{
		Selectors.Last()->Trim();
	}
}
