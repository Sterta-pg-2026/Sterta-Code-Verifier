#pragma once
#define COMMAND_ARGUMENTS 4

#include "mchlist.h"
#include "section.h"

#include <iostream>

class Parser
{
public:
    enum OperationType
    {
        NEW_SECTION,
        NEW_SELECTOR,
        ADD_TO_SELECTOR,
        NEW_ATTRIBUTE,
        ATTRIBUTE_NAME,
        ATTRIBUTE_VALUE,
        COMMAND
    };

    Parser();
    void Procese(char c);

private:
    OperationType operation;
    MchList<Section> sections;

    MchString* arguments = nullptr;
    int currentArgument = 0;

    void onCommand(char c);
    void checkAvailableCommands();
    void resetArguments();
    bool removeSection(int index);
    int countSelectors(const MchString* selector);
    int countAttributes(const MchString* attribute);
    MchString* getAttributeValueForSelector(const MchString* selector, const MchString* attribute);
    void print3Arguments();
};

inline Parser::Parser()
{
    operation = NEW_SELECTOR;
    sections.Add(Section());
    resetArguments();
}

inline void Parser::Procese(char c)
{
    if (c == '?')
    {
        operation = COMMAND;
    }

    if (operation == COMMAND)
    {
        onCommand(c);
    }

    if (c == '\n' || (c == ' ' && operation != ATTRIBUTE_VALUE && operation != ADD_TO_SELECTOR))
    {
        return;
    }

    if (operation == ADD_TO_SELECTOR && c == ',')
    {
        operation = NEW_SELECTOR;
        return;
    }

    if (operation == NEW_SECTION && c == '{')
    {
        sections.Add(Section());
        operation = NEW_ATTRIBUTE;
        return;
    }

    if (((operation == ADD_TO_SELECTOR || operation == NEW_SELECTOR) && c == '{') || (operation == ATTRIBUTE_VALUE && c == ';'))
    {
        sections.Last().TrimLastSelector();
        sections.Last().DeleteDuplicate();
        operation = NEW_ATTRIBUTE;
        return;
    }

    if (operation == ATTRIBUTE_NAME && c == ':')
    {
        operation = ATTRIBUTE_VALUE;
        return;
    }

    if ((operation == NEW_ATTRIBUTE || operation == ATTRIBUTE_VALUE) && c == '}')
    {
        operation = NEW_SECTION;
        return;
    }

    if (operation == NEW_SECTION && ((c > 64 && c < 123) || c == '.' || c == '#'))
    {
        sections.Add(Section());
        operation = NEW_SELECTOR;
    }

    if (operation == NEW_SELECTOR && ((c > 64 && c < 123) || c == '.' || c == '#'))
    {
        sections.Last().TrimLastSelector();
        sections.Last().Selectors.Add(new MchString());
        operation = ADD_TO_SELECTOR;
    }

    if (operation == NEW_ATTRIBUTE && (c > 64 && c < 123 || c == '-'))
    {
        sections.Last().Attributes.Add(Section::Attribute());
        operation = ATTRIBUTE_NAME;
    }

    if (operation == ADD_TO_SELECTOR)
    {
        sections.Last().Selectors.Last()->AddChar(c);
    }
    else if (operation == ATTRIBUTE_NAME)
    {
        sections.Last().Attributes.Last().Key->AddChar(c);
    }
    else if (operation == ATTRIBUTE_VALUE && (c != ' ' || sections.Last().Attributes.Last().Value->GetLength() > 0))
    {
        sections.Last().Attributes.Last().Value->AddChar(c);
    }
}

inline void Parser::onCommand(char c)
{
    if (c == ',')
    {
        currentArgument++;
        return;
    }

    if (!((c == ' ' && !arguments[currentArgument].GetLength()) || c == '\n'))
    {
        arguments[currentArgument].AddChar(c);
        return;
    }

    if (currentArgument == 0 && arguments[0].GetLength())
    {
        if (arguments[0] == "????")
        {
            operation = COMMAND;
        }

        if (arguments[0] == "?")
        {
            std::cout << "? == " << sections.GetSize() << "\n";
        }

        if (arguments[0] == "****")
        {
            operation = NEW_SECTION;
        }

        resetArguments();
        return;
    }

    if (currentArgument == 2 && arguments[2].GetLength())
    {
        checkAvailableCommands();
        resetArguments();
    }

    if (currentArgument > 2)
    {
        resetArguments();
    }
}

inline void Parser::checkAvailableCommands()
{
    if (arguments[0].IsDigit())
    {
        try
        {
            int sectionIndex = arguments[0].ToInt() - 1;

            if (arguments[1] == "D")
            {
                if (arguments[2] == "*" && removeSection(sectionIndex))
                {
                    print3Arguments();
                    std::cout << " == deleted\n";
                    return;
                }

                if (sections.Get(sectionIndex).DeleteAttribute(&arguments[2]))
                {
                    print3Arguments();
                    std::cout << " == deleted\n";

                    if (sections.Get(sectionIndex).IsEmpty())
                    {
                        removeSection(sectionIndex);
                    }

                    return;
                }
            }

            Section& section = sections.Get(sectionIndex);

            if (arguments[2] == "?" && arguments[1] == "A")
            {
                print3Arguments();
                std::cout << " == " << section.GetAttributeCount() << "\n";
                return;
            }

            if (arguments[2] == "?" && arguments[1] == "S")
            {
                print3Arguments();
                std::cout << " == " << section.GetSelectorCount() << "\n";
                return;
            }

            if (arguments[1] == "S" && arguments[2].IsDigit())
            {
                MchString* name = section.GetSelector(arguments[2].ToInt() - 1);

                if (name != nullptr)
                {
                    print3Arguments();
                    std::cout << " == " << name << "\n";
                }

                return;
            }

            if (arguments[1] == "A")
            {
                MchString* value = section.GetAttributeValue(&arguments[2]);

                if (value != nullptr)
                {
                    print3Arguments();
                    std::cout << " == " << value << "\n";
                }

                return;
            }
        }
        catch (const std::exception&)
        {
            return;
        }
    }

    if (arguments[1] == "S")
    {
        print3Arguments();
        std::cout << " == " << countSelectors(&arguments[0]) << "\n";
        return;
    }

    if (arguments[1] == "A")
    {
        print3Arguments();
        std::cout << " == " << countAttributes(&arguments[0]) << "\n";
        return;
    }

    if (arguments[1] == "E")
    {
        MchString* value = getAttributeValueForSelector(&arguments[0], &arguments[2]);

        if (value != nullptr)
        {
            print3Arguments();
            std::cout << " == " << value << "\n";
        }

        return;
    }
}

inline void Parser::resetArguments()
{
    if (arguments != nullptr)
    {
        delete[] arguments;
    }

    arguments = new MchString[COMMAND_ARGUMENTS];
    currentArgument = 0;
}

inline bool Parser::removeSection(int index)
{
    return sections.Remove(index);
}

inline int Parser::countSelectors(const MchString* selector)
{
    int count = 0;
    for (auto it = sections.Begin(); it != sections.End(); ++it)
    {
        count += (*it).FindSelector(selector);
    }

    return count;
}

inline int Parser::countAttributes(const MchString* attribute)
{
    int count = 0;
    for (auto it = sections.Begin(); it != sections.End(); ++it)
    {
        count += (*it).FindAttribute(attribute);
    }

    return count;
}

inline MchString* Parser::getAttributeValueForSelector(const MchString* selector, const MchString* attribute)
{
    MchString* result = nullptr;
    for (auto it = sections.Begin(); it != sections.End(); ++it)
    {
        //Section& section = sections.Get(i);

        if (!(*it).FindSelector(selector))
        {
            continue;
        }

        MchString* temp = (*it).GetAttributeValue(attribute);

        if (temp != nullptr)
        {
            result = temp;
        }
    }

    return result;
}

inline void Parser::print3Arguments()
{
    std::cout << arguments[0] << ',' << arguments[1] << ',' << arguments[2];
}
