﻿#include"css.h"
//#include"list.h"

int main()
{
	css main;
	main.Input();
}
