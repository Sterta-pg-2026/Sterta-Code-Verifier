// CSSParser.cpp : This file contains the 'main' function. Program execution begins and ends there.
//



#include <string.h>
#include <iostream>

const size_t MAX_TOKEN_SIZE = 128;


struct CssAttribute
{
	char name[MAX_TOKEN_SIZE] = "";
	char value[MAX_TOKEN_SIZE] = "";
};

struct CssSelector
{
	char name[MAX_TOKEN_SIZE] = "";
};


const size_t MAX_SIZE = 24;
const size_t T = 8;
char currentCommand[MAX_TOKEN_SIZE];

struct CssSection
{
	CssSelector selectors[MAX_SIZE];
	CssAttribute attributes[MAX_SIZE];
	//counter for attributes
	size_t attrCounter = 0;
	size_t selectorCounter = 0;
};

//structure to define a node of the doubly linked list
struct ListNode {
	CssSection data[T];
	struct ListNode* prev = NULL;
	struct ListNode* next = NULL;
	size_t counter = 0;
};

//root node
struct ListNode* rootNode = NULL;
struct ListNode* lastNode = NULL;

//method to remove node from the doubly linked list
void RemoveNode(struct ListNode* node) {
	if (lastNode == rootNode) {
		delete rootNode;
		rootNode = NULL;
		lastNode = NULL;
		return;
	}
	if (node->prev == NULL) {
		rootNode = node->next;
		if (rootNode != NULL) {
			rootNode->prev = NULL;
		}
		return;
	}
	if (node->next == NULL) {
		node->prev->next = NULL;
		return;
	}
	node->prev->next = node->next;
	node->next->prev = node->prev;
	delete node;
}

//method to add next node to the doubly linked list
struct ListNode* AddNext(struct ListNode* newNode) {
	if (rootNode == NULL) {
		rootNode = newNode;
		rootNode->prev = NULL;
		rootNode->next = NULL;
		lastNode = rootNode;
		return rootNode;
	}

	newNode->prev = lastNode;
	newNode->next = NULL;
	lastNode->next = newNode;
	lastNode = newNode;
	return rootNode;
}

//method to find a node where counter < T
struct ListNode* FindFreeNode() {
	struct ListNode* temp = rootNode;
	if ((lastNode != NULL) && (lastNode->counter < T)) {
			return lastNode;
	}
	temp = new ListNode();
	rootNode = AddNext(temp);
	return temp;


	//while (temp != NULL) {
	//	if (temp->counter < T) {
	//		return temp;
	//	}
	//	temp = temp->next;
	//}
	//temp = new ListNode();
	//rootNode = AddNext(temp);
	//return temp;
}

char* trimwhitespace(char* str)
{
	char* end;

	// Trim leading space
	while (isspace((unsigned char)*str)) str++;

	if (*str == 0)  // All spaces?
		return str;

	// Trim trailing space
	end = str + strlen(str) - 1;
	while (end > str && isspace((unsigned char)*end)) end--;

	// Write new null terminator character
	end[1] = '\0';

	return str;
}

//print the number of CSS sections
void PrintCount() {
	struct ListNode* temp = rootNode;
	size_t count = 0;
	while (temp != NULL) {
		count = count + (temp->counter);
		temp = temp->next;
	}
	std::cout << currentCommand;
	std::cout << " == " << count;
	std::cout << std::endl;
}

//print the number of selectors for section number i (section and attribute numbers start from 1), if there is no such block, skip;
void PrintSelectorCount(size_t i) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			std::cout << currentCommand;
			std::cout << " == " << temp->data[i].selectorCounter;
			std::cout << std::endl;
			return;
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}

//print the number of attributes for section number i, if there is no such block or section, skip;
void PrintAttributeCount(size_t i) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			std::cout << currentCommand;
			std::cout << " == " << temp->data[i].attrCounter;
			std::cout << std::endl;
			return;
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}

//print the total(for all blocks) number of occurrences of attribute named n(duplicates should be removed when reading).It can be 0;
void PrintAttributeCount(char* n) {
	struct ListNode* temp = rootNode;
	int count = 0;
	while (temp != NULL) {
		for (size_t i = 0; i < temp->counter; i++) {
			for (size_t j = 0; j < temp->data[i].attrCounter; j++) {
				if (strcmp(temp->data[i].attributes[j].name, n) == 0) {
					count++;
					break;
				}
			}
		}
		temp = temp->next;
	}
	std::cout << currentCommand;
	std::cout << " == " << count;
	std::cout << std::endl;
}

//print the total (for all blocks) number of occurrences of selector z. It can be 0;
void PrintSelectorCount(char* z) {
	struct ListNode* temp = rootNode;
	size_t count = 0;
	while (temp != NULL) {
		for (size_t i = 0; i < temp->counter; i++) {
			//find selector by name	
			for (size_t j = 0; j < temp->data[i].selectorCounter; j++) {
				if (strcmp(temp->data[i].selectors[j].name, z) == 0) {
					count++;
				}
			}
		}
		temp = temp->next;
	}
	std::cout << currentCommand;
	std::cout << " == " << count;
	std::cout << std::endl;
}

//print the value of the attribute with the name n for the i - th section, if there is no such attribute, skip;
void PrintAttribute(size_t i, char* n) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			for (size_t j = 0; j < temp->data[i].attrCounter; j++) {
				if (strcmp(temp->data[i].attributes[j].name, n) == 0) {
					std::cout << currentCommand;
					std::cout << " == " << temp->data[i].attributes[j].value;
					std::cout << std::endl;
					return;
				}
			}
			return;
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}


//print the j - th selector for the i - th block(section and attribute numbers start from 1), if there is no section or selector, skip;
void PrintSelector(size_t i, size_t j) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			j = j - 1;
			if ((j < temp->data[i].selectorCounter) && (strlen(temp->data[i].selectors[j].name) > 0)) {
				std::cout << currentCommand;
				std::cout << " == " << temp->data[i].selectors[j].name;
				std::cout << std::endl;
				return;
			}
			else {
				return;
			}
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}

//z, E, n - print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one.If there is no such attribute, skip;
void PrintAttribute(char* z, char* n) {
	struct ListNode* temp = rootNode;
	char* value = NULL;
	while (temp != NULL) {
		for (size_t i = 0; i < temp->counter; i++) {
			//find selector by name	
			for (size_t j = 0; j < temp->data[i].selectorCounter; j++) {
				if (strcmp(temp->data[i].selectors[j].name, z) == 0) {
					for (size_t k = 0; k < temp->data[i].attrCounter; k++) {
						if (strcmp(temp->data[i].attributes[k].name, n) == 0) {
							value = temp->data[i].attributes[k].value;
						}
					}
				}
			}
		}
		temp = temp->next;
	}
	if (value != NULL && strlen(value) > 0) {
		std::cout << currentCommand;
		std::cout << " == " << value;
		std::cout << std::endl;
	}
}


//i, D, n - remove the attribute named n from the i - th section, if the section becomes empty as a result of the operation, it should also be removed(along with any selectors), after successful execution, print "deleted".
void DeleteAttribute(size_t i, char* n) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			for (size_t j = 0; j < temp->data[i].attrCounter; j++) {
				if (strcmp(temp->data[i].attributes[j].name, n) == 0) {
					//move items up
					for (size_t k = j; k < temp->data[i].attrCounter; k++) {
						if (k < MAX_SIZE - 1) //not last element
						{
							temp->data[i].attributes[k] = temp->data[i].attributes[k + 1];
						}
					}
					temp->data[i].attrCounter--;
					std::cout << currentCommand;
					std::cout << " == " << "deleted";
					std::cout << std::endl;
					//check if section is empty then delete it
					if (temp->data[i].attrCounter == 0) {
						for (size_t k = i; k < temp->counter; k++) {
							if (k < T - 1) //not last element
							{
								temp->data[k] = temp->data[k + 1];
							}
							else {
								temp->data[T - 1].attrCounter = 0;
								temp->data[T - 1].selectorCounter = 0;
							}
						}
						temp->counter--;
						if (temp->counter == 0)
						{
							RemoveNode(temp);
						}
					}
					return;
				}
			}
			return;
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}



//i, D, * -remove the entire section number i(i.e., separators + attributes), after successful execution, print "deleted";
void DeleteSection(size_t i) {
	struct ListNode* temp = rootNode;
	while (temp != NULL) {
		if (i <= temp->counter) {
			i = i - 1;
			//move items up
			for (size_t j = i; j < temp->counter; j++) {
				if (j < T - 1) //not last element
				{
					temp->data[j] = temp->data[j + 1];
				}
				else {
					temp->data[T - 1].attrCounter = 0;
					temp->data[T - 1].selectorCounter = 0;
				}
			}
			temp->counter--;
			std::cout << currentCommand;
			std::cout << " == " << "deleted";
			std::cout << std::endl;

			if (temp->counter == 0)
			{
				RemoveNode(temp);
			}

			return;
		}
		else {
			i = i - temp->counter;
			temp = temp->next;
		}
	}
}

void ParseCommand(char* command) {
	if (strlen(trimwhitespace(command)) == 0) { return; }

	strcpy_s(currentCommand, command);

	if (command[0] == '?') {
		PrintCount();
	}
	else {

		//split command
		char* token;
		char* next_token = NULL;
		token = strtok_s(command, ",", &next_token);
		char* p1 = token;
		token = strtok_s(NULL, ",", &next_token);
		char* p2 = token;
		token = strtok_s(NULL, ",", &next_token);
		char* p3 = token;

		if (p2[0] == 'S') {
			if (p3[0] == '?') {
				//i,S,? - print the number of selectors for section number i (section and attribute numbers start from 1), if there is no such block, skip;
				size_t i = atoi(p1);
				if (i == 0) {
					//z, S, ? -print the total(for all blocks) number of occurrences of selector z.It can be 0;
					PrintSelectorCount(p1);
				}
				else {
					PrintSelectorCount(i);
				}

			}
			else {
				size_t i = atoi(p1);
				size_t j = atoi(p3);
				//i, S, j - print the j - th selector for the i - th block(section and attribute numbers start from 1), if there is no section or selector, skip;
				PrintSelector(i, j);
			}
		}
		else if (p2[0] == 'A') {
			if (p3[0] == '?') {
				size_t i = atoi(p1);
				if (i == 0) {
					//n, A, ? -print the total(for all blocks) number of occurrences of attribute named n(duplicates should be removed when reading).It can be 0;
					PrintAttributeCount(p1);
				}
				else {
					//i,A,? - print the number of attributes for section number i, if there is no such block or section, skip;
					PrintAttributeCount(i);
				}
			}
			else {
				//i, A, n - print the value of the attribute with the name n for the i - th section, if there is no such attribute, skip;
				size_t i = atoi(p1);
				PrintAttribute(i, p3);
			}
		}
		else if (p2[0] == 'E') {
			//z, E, n - print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one.If there is no such attribute, skip;
			PrintAttribute(p1, p3);
		}
		else if (p2[0] == 'D') {
			size_t i = atoi(p1);
			if (i > 0) {
				if (p3[0] == '*') {
					//i,D,* - remove the entire section number i (i.e., separators+attributes), after successful execution, print "deleted";
					DeleteSection(i);
				}
				else {
					//i, D, n - remove the attribute named n from the i - th section, if the section becomes empty as a result of the operation, it should also be removed(along with any selectors), after successful execution, print "deleted".
					DeleteAttribute(i, p3);
				}

			}
		}
	}
}
//find attribute by name
CssAttribute* FindFreeAttribute(char* name, CssSection* section, bool &duplicate) {
	for (size_t j = 0; j < section->attrCounter; j++) {
		if (strcmp(section->attributes[j].name, name) == 0) {
			duplicate = true;
			return &(section->attributes[j]);
		}
	}
	duplicate = false;
	return &(section->attributes[section->attrCounter]);
}

void ReadCss(char* text)
{
	//ClearList();

	char selector[1024] = "";
	char attributeName[256] = "";
	char value[256] = "";

	CssSection* section = NULL;
	CssAttribute* attribute = NULL;
	struct ListNode* nodeWithFreeCapacity = NULL;

	bool selectorFlag = true;
	bool propertyFlag = false;
	bool valueFlag = false;
	bool duplicate = false;

	size_t len = strlen(text);
	for (size_t i = 0; i < len; i++) {
		if (text[i] == '{') {
			nodeWithFreeCapacity = FindFreeNode();
			selectorFlag = false;
			propertyFlag = true;
			valueFlag = false;
			section = &(nodeWithFreeCapacity->data[nodeWithFreeCapacity->counter]);
			//split selectors to array
			char* token;
			char* next_token = NULL;
			token = strtok_s(selector, ",", &next_token);
			while (token != NULL)
			{
				token = trimwhitespace(token);
				bool isNew = true;
				//check if such selector is already added
				for (size_t k = 0; k < MAX_SIZE; k++)
				{
					if (strcmp(section->selectors[k].name, token) == 0) {
						isNew = false;
						break;
					}
				}
				if (isNew) {
					strcpy_s(section->selectors[section->selectorCounter].name, token);
					section->selectorCounter++;
				}
				token = strtok_s(NULL, ",", &next_token);
			}
			continue;
		}
		else if (text[i] == '}') {
			selectorFlag = true;
			propertyFlag = false;
			valueFlag = false;
			selector[0] = '\0';
			attributeName[0] = '\0';
			value[0] = '\0';

			if (nodeWithFreeCapacity != NULL) {
				nodeWithFreeCapacity->counter++;
			}
			continue;
		}
		else if (text[i] == ';') {
			propertyFlag = true;
			valueFlag = false;

			if ((section != NULL) && (attribute != NULL)) {
				strcpy_s(attribute->value, trimwhitespace(value));
				if (!duplicate) {
					section->attrCounter++;
				}
			}

			value[0] = '\0';
			continue;
		}
		else if ((text[i] == ':') && (section != NULL)) {
			propertyFlag = false;
			valueFlag = true;

			strcpy_s(attributeName, trimwhitespace(attributeName));

			attribute = FindFreeAttribute(attributeName, section, duplicate);
			strcpy_s(attribute->name, attributeName);

			attributeName[0] = '\0';
			continue;
		}
		else if (text[i] == '\t') { continue; } //skip tabs

		if (selectorFlag) {
			strncat_s(selector, &(text[i]), 1);
		}
		else
			if (propertyFlag) {
				strncat_s(attributeName, &(text[i]), 1);
			}
			else
				if (valueFlag) {
					strncat_s(value, &(text[i]), 1);
				}
	}
}

const size_t MAX_CSS_BATCH_SIZE = 2048;
char cssInput[MAX_CSS_BATCH_SIZE];

int main()
{
	bool isCssReadingMode = true;

	cssInput[0] = '\0';

	const size_t MAX_LINE_SIZE = 256;
	char line[MAX_LINE_SIZE];
	size_t linelen = 0;

	while (std::cin.getline(line, MAX_LINE_SIZE, '\n')) {
		if (strcmp(line, "????") == 0)
		{
			isCssReadingMode = false;
			ReadCss(cssInput);
			cssInput[0] = '\0';
		}
		else if (strcmp(line, "****") == 0) {
			isCssReadingMode = true;
		}
		else if (isCssReadingMode) {
			linelen = strlen(line);
			if (linelen > 0) {
				strcat_s(cssInput, line);
				if (line[strlen(line) - 1] == '}')
				{
					ReadCss(cssInput);
					cssInput[0] = '\0';
				}
			}
		}
		else {
			ParseCommand(line);
		}
	};

	return 0;
}