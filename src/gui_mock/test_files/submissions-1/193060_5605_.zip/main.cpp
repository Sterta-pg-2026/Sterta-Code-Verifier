#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "projekt.h"

int main() {
    SelList selectorsList;
    AtrList atributesList;
    BlocksList blockList;

    String buffer;
    String buffer2;
    String buffer3;
    String findS;
    String findV;
    String findVS;
    short commaCounter = 0;
    int countS = 0;
    int countA = 0;
    bool delS;
    bool delA;

    blockList.addBlock();

    bool readSelector = true; //if false we are reading arguments
    bool readCss = true; //if false we are reading commands
    bool readName = true; //if false we are reading values


    char c = getchar();

    while (c != EOF) {
        if (readCss) {
            //reading css
            if (readSelector) {
                //read selectors
                if (c != '{' && c != ',' && c != '\n' && !(c < ' ')) {
                    buffer.addChar(c);
                }
                else if (c == '{') {
                    blockList.addSelector(buffer);
                    readSelector = false;
                    buffer = "";
                }
                else if (c == ',') {
                    blockList.addSelector(buffer);
                    buffer = "";
                }
                if (buffer == "????") {
                    readCss = false;
                    buffer = "";
                }
            }
            else {
                //read arguments
                if (readName) {
                    //read atribute names
                    if (c != '\n' && c != ':' && !(c < ' ') && c != '}') {
                        buffer.addChar(c);
                    }
                    else if (c == ':') {
                        readName = false;
                    }
                    else if (c == '}') {
                        blockList.tail->counter += 1;
                        readSelector = true;
                    }
                }
                else {
                    //read atributes value
                    if (c != ';' && c != '\n') {
                        buffer2.addChar(c);
                    }
                    else if (c == ';' || c == '\n') {
                        blockList.addAttribute(buffer, buffer2);
                        buffer = "";
                        buffer2 = "";
                        readName = true;
                    }
                }
            }
        }
        else {
            //reading commands
            if (commaCounter == 0) {
                if (c != '\n' && !(c < ' ') && c != ',') {
                    buffer.addChar(c);
                }
                else if (c == '\n') {
                    if (buffer == "?") {
                        cout << "? == " << blockList.countSections() << endl;
                        buffer = "";
                        commaCounter = 0;
                    }
                    else if (buffer == "****") {
                        readCss = true;
                        buffer = "";
                        commaCounter = 0;
                    }
                }
            }
            else if (commaCounter == 1) {
                if (c != '\n' && !(c < ' ') && c != ',') {
                    buffer2.addChar(c);
                }
                if (c == '\n') {
                    buffer = "";
                    buffer2 = "";
                    buffer3 = "";
                }
            }
            else if (commaCounter == 2) {
                if (c != '\n' && !(c < ' ') && c != ',') {
                    buffer3.addChar(c);
                }
                else if (c == '\n') {
                    if (buffer2 == "s") {
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "S" && buffer3 == "?") {
                        countS = blockList.countSelectors(intChange(buffer));
                        if (countS >= 0)
                            cout << buffer.getString() << ",S,? == " << countS << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "A" && buffer3 == "?") {
                        countA = blockList.countAttributes(intChange(buffer));
                        if(countA >= 0)
                            cout << buffer.getString() << ",A,? == " << countA << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "S" && buffer3.isNumber()) {
                        findS = blockList.findSelector(intChange(buffer3), intChange(buffer));
                        if (!(findS == ""))
                            cout << buffer.getString() << ",S," << buffer3.getString() << " == " << findS.getString() << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "A") {
                        findV = blockList.findValue(intChange(buffer), buffer3);
                        if (!(findV == ""))
                            cout << buffer.getString() << ",A," << buffer3.getString() << " == " << findV.getString() << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer2 == "A" && buffer3 == "?") {
                        cout << buffer.getString() << ",A,? == " << blockList.countAttribute(buffer) << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer2 == "S" && buffer3 == "?") {
                        cout << buffer.getString() << ",S,? == " << blockList.countSelector(buffer) << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer2 == "E") {
                        findVS = blockList.findValueForSel(buffer, buffer3);
                        if (!(findVS == ""))
                            cout << buffer.getString() << ",E," << buffer3.getString() << " == " << findVS.getString() << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "D" && (buffer3 == "*")) {
                        delS = blockList.deleteSection(intChange(buffer));
                        if(delS)
                            cout << buffer.getString() << ",D,* == deleted" << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                    else if (buffer.isNumber() && buffer2 == "D") {
                        delA = blockList.deleteAttribute(intChange(buffer), buffer3);
                        if(delA)
                            cout << buffer.getString() << ",D," << buffer3.getString() << " == deleted" << endl;
                        buffer = "";
                        buffer2 = "";
                        buffer3 = "";
                        commaCounter = 0;
                    }
                }
            }
            else {
                //zla komenda
                buffer = "";
                buffer2 = "";
                buffer3 = "";
                commaCounter = 0;
            }

            if (c == ',') {
                commaCounter++;
            }
        }
        c = getchar();
    }
    if (buffer == "?") {
        cout << "? == " << blockList.countSections() << endl;
        buffer = "";
        commaCounter = 0;
    }
    return 0;

}
