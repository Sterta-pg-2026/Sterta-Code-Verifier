#include "projekt.h"


//Lista atrybutów
AtrNode::AtrNode() {
    name = nullptr;
    value = nullptr;
    next = nullptr;
}

AtrNode::AtrNode(String name, String value) {
    this->name = name;
    this->value = value;
    this->next = nullptr;
}

AtrList::AtrList() {
    this->head = nullptr;
}

void AtrList::addNode(String name, String value) {
    name = removeWhitespace(name);
    value = removeWhitespace(value);
    AtrNode* newNode = new AtrNode(name, value);
    if (head == nullptr) {
        head = newNode;
    }
    else {
        AtrNode* temp = head;
        while (temp->next != nullptr) {
            if (temp->name == name) {
                temp->value = value;
                return;
            }
            temp = temp->next;
        }
        if (temp->name == name) {
            temp->value = value;
            return;
        }
        temp->next = newNode;
    }
}

void AtrList::printList() const {
    AtrNode* temp = head;
    while (temp != nullptr) {
        cout << "[" << temp->name.getString() << ", " << temp->value.getString() << "] ";
        temp = temp->next;
    }
}


bool AtrList::deleteAttribute(String attribute) {
    AtrNode* temp = head;
    while (temp != nullptr) {
        if (temp->name == attribute) {
            this->deleteNode(attribute);
            return 1;
        }
        temp = temp->next;
    }
    return 0;
}

void AtrList::deleteNode(String nodeName) {
    AtrNode* temp = head;
    AtrNode* prev = nullptr;

    if (temp != nullptr && temp->name == nodeName) {
        head = temp->next;
        delete temp;
        return;
    }

    while (temp != nullptr && !(temp->name == nodeName)) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == nullptr) return;

    prev->next = temp->next;

    delete temp;
}

int AtrList::countAttributes() const {
    int counter = 0;
    AtrNode* temp = head;
    while (temp != nullptr) {
        counter++;
        temp = temp->next;
    }
    return counter;
}

int AtrList::countAttribute(String attribute) const {
    int counter = 0;
    AtrNode* temp = head;
    while (temp != nullptr) {
        if(temp->name == attribute)
            counter++;
        temp = temp->next;
    }
    return counter;
}

String AtrList::findAttribute(String attribute) const{
    AtrNode* temp = head;
    while (temp != nullptr && !(temp->name == attribute)) {
        temp = temp->next;
    }
    if (temp == nullptr) {
        return "";
    }
    return (temp->value);
}

AtrList::~AtrList() {
    AtrNode* current = head;
    while (current != nullptr) {
        AtrNode* temp = current;
        current = current->next;
        delete temp;
    }
}


//Lista selektorów
SelNode::SelNode() {
    name = "";
    next = nullptr;
}

SelNode::SelNode(String name) {
    this->name = name;
    this->next = nullptr;
}

SelList::SelList() {
    this->head = nullptr;
}

void SelList::addNode(String name) {
   SelNode* newNode = new SelNode(name);
    if (head == nullptr) {
        head = newNode;
    }
    else {
        SelNode* temp = head;
        while (temp->next != nullptr) {
            if (temp->name == name) {
                return;
            }
            temp = temp->next;
        }
        if (temp->name == name) {
            return;
        }
        temp->next = newNode;
    }
}

void SelList::printList() const {
    SelNode* temp = head;
    while (temp != nullptr) {
        cout << temp->name.getString() << " ";
        temp = temp->next;
    }
}

int SelList::countSelectors() const {
    int counter = 0;
    SelNode* temp = head;
    while (temp != nullptr) {
        if (!(temp->name == ""))
            counter++;
        temp = temp->next;
    }
    return counter;
}

int SelList::countSelector(String selector) const{
    int counter = 0;
    SelNode* temp = head;
    while (temp != nullptr) {
        if (temp->name == selector)
            counter++;
        temp = temp->next;
    }
    return counter;
}

bool SelList::checkForSelector(String selector) const {
    SelNode* temp = head;
    while (temp != nullptr) {
        if (temp->name == selector)
            return 1;
        temp = temp->next;
    }
    return 0; //0 means that selector was not found
}

String SelList::getSelector(int selNr) {
    int counter = 0;
    SelNode* temp = head;
    while (temp != nullptr && counter < (selNr - 1)) {
        counter++;
        temp = temp->next;
    }
    if (temp == nullptr) {
        return "";
    }
    else {
        return (temp->name);
    }
    
}

SelList::~SelList() {
    SelNode* current = head;
    while (current != nullptr) {
        SelNode* temp = current;
        current = current->next;
        delete temp;
    }
}


//Sekcje
Section::Section() {
    deleted = false;
}

Section::Section(SelList selectorsList, AtrList atributesList) {
    this->selectorsList = selectorsList;
    this->attributesList = atributesList;
    this->deleted = 0;
}

Section::~Section() {
    if (selectorsList.head != nullptr) {
        delete selectorsList.head;
        selectorsList.head = nullptr;
    }

    if (attributesList.head != nullptr) {
        delete attributesList.head;
        attributesList.head = nullptr;
    }
}


//Bloki
BlockNode::BlockNode() {
    sectionsArray = new Section[BLOCK_SIZE];
    counter = 0;
    this->next = nullptr;
    this->prev = nullptr;
}

BlocksList::BlocksList() {
    head = nullptr;
    tail = nullptr;
}

void BlocksList::addBlock() {
    BlockNode* newNode = new BlockNode();

    if (tail == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

void BlocksList::addSelector(String selector) {
    selector = removeWhitespace(selector);
    if (tail->counter < BLOCK_SIZE) {
        tail->sectionsArray[tail->counter].selectorsList.addNode(selector);
    }
    else {
        this->addBlock();
        tail->sectionsArray[0].selectorsList.addNode(selector);
        tail->counter = 0;
    }
}

void BlocksList::addAttribute(String name, String value) {
    if (tail->counter < BLOCK_SIZE) {
        tail->sectionsArray[tail->counter].attributesList.addNode(name, value);
    }
    else {
        this->addBlock();
        tail->sectionsArray[0].attributesList.addNode(name, value);
        tail->counter = 0;
    }
}

void BlocksList::printList() const {
    BlockNode* temp = head;
    while (temp != nullptr) {
        Section* sections = temp->sectionsArray;
        for (int i = 0; i < temp->counter; ++i) {
            cout << "{ ";
            sections[i].selectorsList.printList();
            cout << ": ";
            sections[i].attributesList.printList();
            cout << "} ";
            cout << endl;
        }
        temp = temp->next;
    }
}

bool BlocksList::deleteAttribute(int secNr, String attribute) {
    if (this->countSections() < secNr) {
        return 0;
    }
    BlockNode* current = head;
    int counter = 1;
    int attrCounter = 0;
    bool del;
    while (current != nullptr) {
        for (int i = 0; i < current->counter; i++) {
            if (!(current->sectionsArray[i].deleted)) {
                if (counter == secNr) {
                    del = current->sectionsArray[i].attributesList.deleteAttribute(attribute);
                    if (del) {
                        attrCounter = current->sectionsArray[i].attributesList.countAttributes();
                        if (attrCounter == 0) {
                            current->sectionsArray[i].deleted = true;
                        }
                        return 1;
                    } 
                    return 0;
                }
                counter++;
            }
        }
        current = current->next;
    }
    return 0;
}

bool BlocksList::deleteSection(int secNr) {
    if (countSections() < secNr)
        return 0;
    int counter = 1;
    BlockNode* current = head;
    while (current != nullptr) {
        for (int i = 0; i < current->counter; i++) {
            if (current->sectionsArray[i].selectorsList.head != nullptr && !(current->sectionsArray[i].deleted)) {
                if (counter == secNr) {
                    current->sectionsArray[i].deleted = true;
                    return 1;
                }
                counter++;
            }
        }
        current = current->next;
    }
    if (current == nullptr) {
        return 0;
    }
    return 0;
}

int BlocksList::countSections() {
    int counter = 0;
    BlockNode* temp = head;
    while (temp != nullptr) {
        Section* sections = temp->sectionsArray;
        for (int i = 0; i < temp->counter; ++i) {
            if (sections[i].selectorsList.head != nullptr && !(sections[i].deleted)) {
                counter++;
            }
        }
        temp = temp->next;
    }
    return counter;
}

int BlocksList::countSelectors(int i) {
    if (this->countSections() < i) {
        return -1; 
    }
    int counter = 1;
    int selCounter = 0;
    BlockNode* current = head;
    while (current != nullptr) {
        for (int j = 0; j < current->counter; j++) {
            if (!(current->sectionsArray[j].deleted)) {
                if (counter == i) {
                    selCounter += current->sectionsArray[j].selectorsList.countSelectors();
                    return selCounter;
                }
                counter++;
            }
        }
        current = current->next;
    }
    return -1;
}

int BlocksList::countSelector(String selector) const {
    BlockNode* current = head;
    int selCounter = 0;
    while (current != nullptr) {
        for (int i = 0; i < current->counter; i++) {
            if (!(current->sectionsArray[i].deleted))
                selCounter += current->sectionsArray[i].selectorsList.countSelector(selector);
        }
        current = current->next;
    }
    return selCounter;
}

int BlocksList::countAttributes(int i) {
    if (this->countSections() < i) {
        return -1;
    }
    int counter = 1;
    int atrCounter = 0;
    BlockNode* current = head;
    while (current != nullptr) {
        for (int j = 0; j < current->counter; j++) {
            if (!(current->sectionsArray[j].deleted)) {
                if (counter == i) {
                    atrCounter += current->sectionsArray[j].attributesList.countAttributes();
                    return atrCounter;
                }
                counter++;
            }
        }
        current = current->next;
    }
    return -1;
}

int BlocksList::countAttribute(String attribute) const{
    BlockNode* current = head;
    int attrCounter = 0;
    while (current != nullptr) {
        for (int i = 0; i < current->counter; i++) {
            if(!(current->sectionsArray[i].deleted))
                attrCounter += current->sectionsArray[i].attributesList.countAttribute(attribute);
        }
        current = current->next;
    }
    return attrCounter;
}

String BlocksList::findSelector(int selNr, int secNr) {
    if (this->countSections() < secNr) {
        return "";
    }
    int counter = 1;
    BlockNode* current = head;
    String result = "";

    while (current != nullptr) {
        for (int j = 0; j < current->counter; j++) {
            if (!(current->sectionsArray[j].deleted)) {
                if (counter == secNr) {
                    result = current->sectionsArray[j].selectorsList.getSelector(selNr);
                    return result;
                }
                counter++;
            }
        }
        current = current->next;
    }

    return result;
}

String BlocksList::findValue(int secNr, String attribute) const {
    int counter = 1;
    BlockNode* current = head;
    String result = "";

    while (current != nullptr) {
        for (int j = 0; j < current->counter; j++) {
            if (!(current->sectionsArray[j].deleted)) {
                //current->sectionsArray[j].attributesList.printList();
                if (counter == secNr) {
                    result = current->sectionsArray[j].attributesList.findAttribute(attribute);
                    return result;
                }
                counter++;
            }
        }
        current = current->next;
    }

    if (current == nullptr) {
        return result;
    }
    return result;
}

String BlocksList::findValueForSel(String selector, String attribute) const {
    BlockNode* current = tail;
    bool isSelector = 0;
    while (current != nullptr) {
        for (int i = (current->counter - 1); i >= 0; i--) {
            if(!(current->sectionsArray[i].deleted))
                isSelector = current->sectionsArray[i].selectorsList.checkForSelector(selector);
            if (isSelector) {
                return current->sectionsArray[i].attributesList.findAttribute(attribute);
            }
        }
        current = current->prev;
    }
    return "";
}

BlocksList::~BlocksList() {
    BlockNode* current = head;

    while (current != nullptr) {
        BlockNode* temp = current;
        current = current->next;
        delete temp;
    }
}

//String
String::String() {
    strData = new char[1];
    strData[0] = '\0';
    strLength = 0;
}

String::String(const char* string) {
    if (string != NULL) {
        strLength = strlen(string);
        strData = new char[strLength + 1];
        strcpy(strData, string);
    }
}

String::String(const String& other) {
    try {
        strLength = other.strLength;
        strData = new char[strLength + 1];
        strcpy(strData, other.strData);
    }
    catch (...) {
        delete[] strData;
        strData = nullptr;
        strLength = 0;
        throw;
    };
    if (strData == nullptr) {
        strLength = 0;
    }
}

String::String(String&& other) noexcept {
    strLength = other.strLength;
    strData = other.strData;
    other.strData = nullptr;
    other.strLength = 0;
}

bool String::isNumber() {
    if (strLength == 0) {
        return false;
    }
    int i = 0;

    while (i < strLength) {
        if (isdigit(strData[i])) {
            i++;
        }
        else {
            return false;
        }
    }
    return true;
}

void String::addChar(char c) {
    char* newData = new char[strLength + 2];
    if (strData != NULL)
        strcpy(newData, strData);
    newData[strLength] = c;
    newData[strLength + 1] = '\0';
    delete[] strData;
    strData = newData;
    strLength++;
}

String::~String() {
    delete[] strData;
}

//Pozostałe funkcje
int intChange(String string) {
    int number;
    number = atoi(string.strData);
    return number;
}

String removeWhitespace(String string) {
    int i = 0;
    int j = string.strLength - 1;

    while (i <= j && isspace(string[i])) {
        i++;
    }

    while (j >= i && isspace(string[j])) {
        j--;
    }

    String trimmed = "";
    for (int k = i; k <= j; k++) {
        trimmed.addChar(string[k]);
    }

    return trimmed;
}
