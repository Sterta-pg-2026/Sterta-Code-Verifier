#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>


#define BLOCK_SIZE 29

using namespace std;

//String
class String {
    
public:
    size_t strLength;
    char* strData;
    String();
    String(const char* string);
    String(const String& other);
    String(String&& other) noexcept;
    void addChar(char c);
    bool isNumber();
    ~String();
    String& operator=(const String& other) {
        if (this != &other) {
            delete[] strData;
            strLength = other.strLength;
            strData = new char[strLength + 1];
            strcpy(strData, other.strData);
        }
        return *this;
    }
    String& operator=(String&& other) noexcept {
        if (this != &other) {
            delete[] strData;
            strLength = other.strLength;
            strData = other.strData;
            other.strData = nullptr;
            other.strLength = 0;
        }
        return *this;
    }
    String& operator+=(const String& other) {
        int newLength = strLength + other.strLength;
        char* tmp = new char[strLength + other.strLength + 1];
        strcpy_s(tmp, strLength + 1, strData);
        strcat_s(tmp, newLength + 1, other.strData);
        delete[] strData;
        strData = tmp;
        strLength += other.strLength;
        return *this;
    }
    friend String operator+(String left, const String& right) {
        left += right;
        return left;
    }
    const char& operator[](size_t idx) const {
        return strData[idx];
    }
    char& operator[](size_t idx) {
        return strData[idx];
    }
    bool operator==(const String& other) const {
        if (strLength != other.strLength) {
            return false;
        }
        return strcmp(strData, other.strData) == 0;
    }
    size_t length() const {
        return strLength;
    }
    const char* getString() const {
        if (strLength > 0) {
            return strData;
        }
        return "";
    }
};

//Lista atrybutow
class AtrNode {
public:
    String name;
    String value;
    AtrNode* next;

    AtrNode();
    AtrNode(String name, String value);
};

class AtrList {
public:
    AtrNode* head;

    AtrList();
    void addNode(String name, String value);
    void printList() const;
    bool deleteAttribute(String attribute);
    void deleteNode(String nodeName);
    int countAttributes() const;
    int countAttribute(String attribute) const;
    String findAttribute(String attribute) const;
    ~AtrList();
};


//Lista selektorow
class SelNode {
public:
    String name;
    SelNode* next;

    SelNode();
    SelNode(String name);
};

class SelList {
public:
    SelNode* head;

    SelList();
    void addNode(String name);
    void printList() const;
    int countSelectors() const;
    int countSelector(String selector) const;
    bool checkForSelector(String selector) const;
    String getSelector(int selNr);
    ~SelList();
};


//Sekcje
class Section {
public:
    SelList selectorsList;
    AtrList attributesList;
    bool deleted;
    Section();
    Section(SelList selectorsList, AtrList atributesList);
    ~Section();
};


//Bloki
class BlockNode {
public:
    Section* sectionsArray;
    short int counter;
    BlockNode* next;
    BlockNode* prev;

    BlockNode();
};

class BlocksList {
public:
    BlockNode* head;
    BlockNode* tail;
    BlocksList();
    void addBlock();
    void addSelector(String selector);
    void addAttribute(String name, String value);
    void printList() const;
    bool deleteAttribute(int secNr, String attribute);
    bool deleteSection(int secNr);
    String findSelector(int selNr, int secNr);
    String findValue(int secNr, String attribute) const;
    String findValueForSel(String selector, String attribute) const;
    int countSections();
    int countSelectors(int i);
    int countSelector(String selector) const;
    int countAttributes(int i);
    int countAttribute(String attribute) const;
    ~BlocksList();
};

int intChange(String string);

String removeWhitespace(String string);

