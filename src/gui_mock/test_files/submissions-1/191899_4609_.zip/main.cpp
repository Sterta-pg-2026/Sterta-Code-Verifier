#include <iostream>
#include <cstring>
using namespace std;

#define _CRT_SECURE_NO_WARNINGS




class Mystring {
    char* str;
public:
    Mystring();
    Mystring(const char* val);
    Mystring(const Mystring& source);
    Mystring(Mystring&& source);
    Mystring& operator=(const Mystring& rhs);
    Mystring& operator=(Mystring&& rhs);
    ~Mystring() { delete[] str; }
    friend ostream& operator<<(ostream& os, const Mystring& obj);
    friend istream& operator>>(istream& is, Mystring& obj);
    friend bool operator==(const Mystring& lhs, const char* rhs);
    friend bool operator==(const Mystring& lhs, const Mystring& rhs);
};

Mystring::Mystring()
{
    str = new char[1];
    *str = '\0';
}

Mystring::Mystring(const char* val)
{
    if (val == nullptr) {
        str = new char[1];
        *str = '\0';
    }
    else {
        str = new char[strlen(val) + 1];
        strcpy_s(str, strlen(val) + 1, val);
    }
}

Mystring::Mystring(const Mystring& source)
{
    str = new char[strlen(source.str) + 1];
    strcpy_s(str, strlen(source.str) + 1, source.str);
}

Mystring::Mystring(Mystring&& source)
{
    str = source.str;
    source.str = nullptr;
}

Mystring& Mystring::operator=(const Mystring& rhs)
{
    if (this == &rhs) {
        return *this;
    }
    delete[] str;
    str = new char[strlen(rhs.str) + 1];
    strcpy_s(str, strlen(rhs.str) + 1, rhs.str);
    return *this;
}

Mystring& Mystring::operator=(Mystring&& rhs)
{
    if (this == &rhs) {
        return *this;
    }
    delete[] str;
    str = rhs.str;
    rhs.str = nullptr;
    return *this;
}

ostream& operator<<(ostream& os, const Mystring& obj)
{
    os << obj.str;
    return os;
}

istream& operator>>(istream& is, Mystring& obj)
{
    char buffer[100];
    is >> buffer;
    obj = Mystring(buffer);
    return is;
}

bool operator==(const Mystring& lhs, const char* rhs) {
    return (strcmp(lhs.str, rhs) == 0);
}

bool operator==(const Mystring& lhs, const Mystring& rhs) {
    return (strcmp(lhs.str, rhs.str) == 0);
}

const int MAX_BLOCK_SIZE = 8;

struct Attribute {
    char name[32];
    char value[32];
};

struct Selector {
    char name[32];
    Attribute attributes[MAX_BLOCK_SIZE];
    int numAttributes;
    Selector* prev;
    Selector* next;
};

struct Section {
    Selector selectors[MAX_BLOCK_SIZE];
    int numSelectors;
    Section* prev;
    Section* next;
};

class CSS {
private:
    Section* headSection;
    Section* tailSection;
    int numSections;
public:
    CSS() {
        headSection = nullptr;
        tailSection = nullptr;
        numSections = 0;
    }
    
    void addSection() {
        Section* newSection = new Section();
        newSection->numSelectors = 0;
        newSection->prev = tailSection;
        newSection->next = nullptr;
        if (tailSection != nullptr) {
            tailSection->next = newSection;
        }
        tailSection = newSection;
        if (headSection == nullptr) {
            headSection = tailSection;
        }
        numSections++;
    }
    
    void addSelector(const char* name) {
        if (numSections == 0) {
            return;
        }
        Selector* newSelector = new Selector();
        //strncpy(newSelector->name, name, sizeof(newSelector->name) - 1);
        strncpy_s(newSelector->name, sizeof(newSelector->name), name, _TRUNCATE);

        newSelector->numAttributes = 0;
        newSelector->prev = nullptr;
        newSelector->next = nullptr;
        if (tailSection->numSelectors == MAX_BLOCK_SIZE) {
            addSection();
        }
        Selector* tailSelector = &(tailSection->selectors[tailSection->numSelectors]);
        *tailSelector = *newSelector;
        tailSection->numSelectors++;
        delete newSelector;
    }
    
    void addAttribute(const char* name, const char* value) {
        if (numSections == 0 || tailSection->numSelectors == 0) {
            return;
        }
        Selector* tailSelector = &(tailSection->selectors[tailSection->numSelectors - 1]);
        if (tailSelector->numAttributes == MAX_BLOCK_SIZE) {
            addSelector(tailSelector->name);
            tailSelector = &(tailSection->selectors[tailSection->numSelectors - 1]);
        }
        Attribute* tailAttribute = &(tailSelector->attributes[tailSelector->numAttributes]);
        //strncpy(tailAttribute->name, name, sizeof(tailAttribute->name) - 1);
        //strncpy(tailAttribute->value, value, sizeof(tailAttribute->value) - 1);
        strncpy_s(tailAttribute->name, sizeof(tailAttribute->name), name, _TRUNCATE);
        strncpy_s(tailAttribute->value, sizeof(tailAttribute->value), value, _TRUNCATE);

        tailSelector->numAttributes++;
    }
    
    void printNumSections() {
        std::cout << numSections << std::endl;
    }
    
    void printNumSelectors(int idx) {
        if (idx <= 0 || idx > numSections) {
            return;
        }
        Section* section = headSection;
        for (int i = 1; i < idx; i++) {
            section = section->next;
        }
        std::cout << section->numSelectors << std::endl;
    }
    
    void printAttribute(int secIdx, const char* name) {
        if (secIdx <= 0 || secIdx > numSections) {
            return;
        }
        Section* section = headSection;
        while (section != nullptr) {
            for (int i = 0; i < section->numSelectors; i++) {
                Selector* selector = &(section->selectors[i]);
                for (int j = 0; j < selector->numAttributes; j++) {
                    Attribute* attribute = &(selector->attributes[j]);
                    if (strcmp(attribute->name, name) == 0) {
                        std::cout << selector->name << ": " << attribute->value << std::endl;
                    }
                }
            }
            section = section->next;
        }
    }
    
    void printTotalOccurrences(const char* name) {
        int count = 0;
        Section* section = headSection;
        while (section != nullptr) {
            for (int i = 0; i < section->numSelectors; i++) {
                Selector* selector = &(section->selectors[i]);
                for (int j = 0; j < selector->numAttributes; j++) {
                    Attribute* attribute = &(selector->attributes[j]);
                    if (strcmp(attribute->name, name) == 0) {
                        count++;
                    }
                }
            }
            section = section->next;
        }
        std::cout << count << std::endl;
    }
    
    void printTotalSelectorOccurrences(const char* name) {
        int count = 0;
        Section* section = headSection;
        while (section != nullptr) {
            for (int i = 0; i < section->numSelectors; i++) {
                Selector* selector = &(section->selectors[i]);
                if (strcmp(selector->name, name) == 0) {
                    count++;
                }
            }
            section = section->next;
        }
        std::cout << count << std::endl;
    }
    
    void printSelectorAttribute(const char* name, const char* attrName) {
        Section* section = headSection;
        while (section != nullptr) {
            for (int i = 0; i < section->numSelectors; i++) {
                Selector* selector = &(section->selectors[i]);
                if (strcmp(selector->name, name) == 0) {
                    for (int j = 0; j < selector->numAttributes; j++) {
                        Attribute* attribute = &(selector->attributes[j]);
                        if (strcmp(attribute->name, attrName) == 0) {
                            std::cout << attribute->value << std::endl;
                        }
                    }
                }
            }
            section = section->next;
        }
    }
    
    void removeSection(int idx) {
        if (idx <= 0 || idx > numSections) {
            return;
        }
        Section* section = headSection;
        for (int i = 1; i < idx; i++) {
            section = section->next;
        }
        if (section->prev != nullptr) {
            section->prev->next = section->next;
        }
        else {
            headSection = section->next;
        }
        if (section->next != nullptr) {
            section->next->prev = section->prev;
        }
        else {
            tailSection = section->prev;
        }
        delete section;
        numSections--;
    }
    
    void printNumAttributes(int idx) {
        if (idx <= 0 || idx > numSections) {
            return;
        }
        Section* section = headSection;
        for (int i = 1; i < idx; i++) {
            section = section->next;
        }
        for (int i = 0; i < section->numSelectors; i++) {
            std::cout << section->selectors[i].numAttributes << " ";
        }
        std::cout << std::endl;
    }

    void printSelector(int secIdx, int selIdx) {
        if (secIdx <= 0 || secIdx > numSections) {
            return;
        }
        Section* section = headSection;
        for (int i = 1; i < secIdx; i++) {
            section = section->next;
        }
        if (selIdx <= 0 || selIdx > section->numSelectors) {
            return;
        }
        Selector* selector = &(section->selectors[selIdx - 1]);
        std::cout << selector->name << " {";
        for (int i = 0; i < selector->numAttributes; i++) {
            std::cout << " " << selector->attributes[i].name << ": " << selector->attributes[i].value << ";";
        }
        std::cout << " }" << std::endl;
    }

    void removeAttribute(int secIdx, const char* name) {
        if (secIdx <= 0 || secIdx > numSections) {
            return;
        }
        Section* section = headSection;
        for (int i = 1; i < secIdx; i++) {
            section = section->next;
        }

        for (int i = 0; i < section->numSelectors; i++) {
            Selector* selector = &(section->selectors[i]);
            for (int j = 0; j < selector->numAttributes; j++) {
                Attribute* attribute = &(selector->attributes[j]);
                if (strcmp(attribute->name, name) == 0) {
                    // shift remaining attributes one position to the left
                    for (int k = j + 1; k < selector->numAttributes; k++) {
                        Attribute* nextAttr = &(selector->attributes[k]);
                        Attribute* prevAttr = &(selector->attributes[k - 1]);
                        //strncpy(prevAttr->name, nextAttr->name, sizeof(prevAttr->name) - 1);
                        //strncpy(prevAttr->value, nextAttr->value, sizeof(prevAttr->value) - 1);
                        strncpy_s(prevAttr->name, sizeof(prevAttr->name), nextAttr->name, _TRUNCATE);
                        strncpy_s(prevAttr->value, sizeof(prevAttr->value), nextAttr->value, _TRUNCATE);
                    }
                    selector->numAttributes--;
                    j--;
                }
            }
        }
    }

    
    
};


int main()
{
    Mystring start;
    Mystring option;
	CSS mycss;
    mycss.addSection();
	mycss.addSelector("body");
	mycss.addAttribute("background-color", "red");
	mycss.addAttribute("color", "white");
    
    cin >> start;

    if (start == "????") {
        
        //???? - start of command section.       
        cin >> option;
        
        if (option == "****") {
            // resume reading CSS.
                   
        }
        else if (option == "?") {
		    // print the number of sections in the CSS.
			mycss.printNumSections();      
        }
        else if ("i,S,?") {
            // print the number of selectors for block number i (block and attribute numbers start from 1), if there is no such block, skip.
            

        }
        else if ("i,A,?") {
		    // print the number of attributes for selector number i in block number j, if there is no such block or selector, skip.
			mycss.printNumAttributes(1);
        }
        else if ("i,S,j") {
		    // print the j-th selector for block number i, if there is no such block or selector, skip.
			mycss.printSelector(1, 1);
        }
        else if ("i,A,n") {
			// - print the value of the attribute with the name n for the i-th block, if there is no such attribute or block, skip.
			mycss.printAttribute(1, "background-color");
        }
        else if ("n,A,?") {
			// print the j-th selector for the i-th block (block and attribute numbers start from 1), if there is no block or selector, skip.
			mycss.printSelector(1, 1);

        }
        else if ("z,S,?") {
            //print the total (for all blocks) number of occurrences of attribute named n (duplicates should be removed when reading).It can be 0.         

        }
        else if ("z,E,n") {
            // print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one.If there is no such attribute, skip.
            

        }
        else if ("i,D,*") {
            // remove the entire block number i (i.e., separators+attributes), after successful execution, print "deleted".
			mycss.removeSection(1);

        }
        else if ("i,D,n") {
            // - remove the attribute named n from the i-th block, if the block becomes empty as a result of the operation, it should also be removed(along with any selectors), after successful execution, print "deleted".
			mycss.removeAttribute(1, "background-color");
        }
        else {
            cout << "error : invalid entry";
        }
        
    }
    else {
        cout << "error : invalid entry";
    }

    return 0;
}
