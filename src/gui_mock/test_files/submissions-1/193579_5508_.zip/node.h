#pragma once

template<typename T> 
struct Node {

	T data;
	Node<T>* next;
	Node<T>* prev;

	Node();

	Node(T data);

};

template<typename T> Node<T>::Node() : data(), next(nullptr), prev(nullptr) {}

template<typename T> Node<T>::Node(T Tdata) : data(Tdata), next(nullptr), prev(nullptr) {}