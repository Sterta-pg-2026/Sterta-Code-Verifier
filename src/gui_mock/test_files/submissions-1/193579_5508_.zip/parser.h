#include "string.h"
#include "cssblock.h"
#include "blocklist.h"

enum ParseModes { Att, Select };

class Parser {

    String in;
    CssBlock* block;
    Atts newAtt;

    int parseMode;
    bool parsed;

    static const String parseStop;
    static const String parseStart;

    void parseAttributes();

    void parseSelectors();

    public:

    Parser();

    ~Parser();

    void parseBlock(DoublyLinkedList<BlockList>& list);

    bool validateBlock();

    void pushBlock(DoublyLinkedList<BlockList>& list);

    void removeBlock();

    bool isInputObsolete();

    String& getInput();

    bool changeParserState();

    int getParseMode() const;

    bool getParserState() const;

    bool isBlockParsed() const;

    void setParsed(bool p);

    bool isParsing;

};


