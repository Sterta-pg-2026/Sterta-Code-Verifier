#pragma once
#include "string.h"
#include "doublylinkedlist.h"
#include "atts.h"

struct CssBlock {

    DoublyLinkedList<Atts> atts;
    DoublyLinkedList<String> selects;

};


