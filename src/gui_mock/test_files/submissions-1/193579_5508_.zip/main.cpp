#include <iostream>
#include "parser.h"
#include "string.h"
#include "commandprocessor.h"
#include "doublylinkedlist.h"

int main() {

    DoublyLinkedList<BlockList> list;
    CommandProcessor processor;
    Parser parser;

    while ((parser.getInput() = std::cin.peek()) && std::cin.peek() != -1) {


        if(list.length() == 0) { list.addFirst(); }

        if (parser.getParserState()) {
            parser.parseBlock(list);
            if(!parser.getParserState()) { processor.changeProcessorState(); }
        }
        else {
            if(processor.extractCommand() && processor.executeCommand(list)) {

                std::cout << processor.buildResponse(list) << std::endl;

            }
            if(!processor.getProcessorState()) { parser.isParsing = !parser.isParsing; }
        }

    }

    //list.clear();
    //parser.removeBlock();

    return 0;
}
