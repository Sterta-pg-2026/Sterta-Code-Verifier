#include "parser.h"
#include "string.h"

const String Parser::parseStart = "****";
const String Parser::parseStop = "????";

enum SeparatorFlags { Newline, Space, Coma, Colon, Selectors, Attributes, Commands};

Parser::Parser() : parseMode(Select), parsed(false), isParsing(true), block(new CssBlock()) {}

Parser::~Parser() { removeBlock(); }

void Parser::removeBlock() { delete block; block = nullptr; }

int Parser::getParseMode() const { return parseMode; }

bool Parser::getParserState() const { return isParsing; }

String& Parser::getInput() { return in; }

bool Parser::isBlockParsed() const { return parsed; }

bool Parser::isInputObsolete() { return in.length() == 0 || in == Parser::parseStop || in == Parser::parseStart; }

bool Parser::changeParserState() {

    if(in == parseStart) { return (isParsing = true); }
    if(in == parseStop) { isParsing = (isParsing = false);  }

    return false;

}

void Parser::parseSelectors() {

    getFromStream(std::cin, in, Selectors);
    trimStr(in);

    changeParserState();

    if(!isInputObsolete() && getParserState() && getParseMode() == Select) { block->selects.pushBack(String(getInput())); }

    if(std::cin.get() == '{') { parseMode = Att; }
}

void Parser::parseAttributes() {

    getFromStream(std::cin, in, Attributes);
    trimStr(in);

    int next = std::cin.peek();
    if( next == ':' || next == ';' || next == '\n') std::cin.get();
    if (next == '}') { std::cin.get(); parseMode = Select; parsed = true; }

    if(newAtt.att.length() == 0) { newAtt.att = in;}
    else { newAtt.val = in; }

    if(newAtt.att.length() != 0 && newAtt.val.length() != 0) {

        Node<Atts>* iterAtt = block->atts.getHead();
        while(iterAtt) {

            if(iterAtt->data.att == newAtt.att) { iterAtt->data.val = newAtt.val; newAtt.att = ""; break; }

            if(iterAtt->next) { iterAtt = iterAtt->next;}
            else { break; }

        }

        if(newAtt.att != "") { block->atts.pushBack(newAtt); }

        newAtt.val.clear();
        newAtt.att.clear();

    }

}

void Parser::parseBlock(DoublyLinkedList<BlockList>& list) {

    changeParserState();

    if (getParseMode() == Select) { parseSelectors(); }
    if (getParseMode() == Att) { parseAttributes(); }

    if (isBlockParsed() && validateBlock()) {

        pushBlock(list);

    }

}

bool Parser::validateBlock() {

    return block->atts.getHead();

}

void Parser::pushBlock(DoublyLinkedList<BlockList>& list) {

    setParsed(false);

    if (list.getLast().isSpace()) {
        list.getLast().pushBlock(block);
    } else {
        list.pushBack();
        list.getLast().pushBlock(block);
    }

    block = nullptr;
    if(isParsing) { block = new CssBlock; }

}

void Parser::setParsed(bool p) {

    parsed = p;

}







