#include "atts.h"


Atts::Atts() : val(), att() {}

Atts::Atts(String v,  String  a) : val(std::move(v)), att(std::move(a)) {}

std::ostream& operator<<(std::ostream& out, const Atts& a) {

    out<< a.att << " " << a.val << std::endl;
    return out;

}