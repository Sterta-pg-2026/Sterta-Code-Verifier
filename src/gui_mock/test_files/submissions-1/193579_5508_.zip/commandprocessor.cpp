#include "commandprocessor.h"

enum SeparatorFlags { Newline, Space, Coma, Colon, Selectors, Attributes, Commands};

CommandProcessor::CommandProcessor() : isProcessing(false) {}

bool CommandProcessor::getProcessorState() const { return isProcessing;}

void CommandProcessor::changeProcessorState() { isProcessing = !isProcessing; }

String CommandProcessor::buildResponse(DoublyLinkedList<BlockList>& list) {

    String resp = comOpFirst;
    if(resp == "?") { resp += " == "; resp += response; return resp;}

    resp += ","; resp += comOpMid;
    resp += ",";
    resp += comOpLast;
    resp += " == ";
    resp += response;

    return resp;

}

void CommandProcessor::countSections(DoublyLinkedList<BlockList> &list) {

    Node<BlockList>* iter = list.getHead();
    int count = 0;

    if(list.length() == 0 || list.getHead()->data.lastIndex == 0) { intToString(count, response); return; }

    for(; iter; iter= iter->next) { count += iter->data.lastIndex - iter->data.deletedCount; }

    intToString(count, response);

}

void CommandProcessor::countSelectsForSection(DoublyLinkedList<BlockList> &list) {

    size_t index = stringToInt(comOpFirst);
    Node<BlockList>* iter = getSectionNumber(list, index);

    if(index > iter->data.lastIndex - 1) { return; }

    intToString( iter->data.blocks[index]->selects.length(), response);

}

void CommandProcessor::countAttsForSection(DoublyLinkedList<BlockList> &list) {

    size_t index = stringToInt(comOpFirst);

    Node<BlockList>* iter = getSectionNumber(list, index);

    if(index > iter->data.lastIndex - 1) { return; }

    intToString( iter->data.blocks[index]->atts.length(), response);

}

void CommandProcessor::getIselectorJblock(DoublyLinkedList<BlockList> &list) {

    size_t indexBlock = stringToInt(comOpFirst);
    int indexSelect = stringToInt(comOpLast) - 1;
    Node<BlockList>* iter = getSectionNumber(list, indexBlock);

    if(indexBlock > iter->data.lastIndex - 1) { return; }

    Node<String>* iterAtts = iter->data.blocks[indexBlock]->selects.getHead();

    if(!iterAtts || indexSelect > iter->data.blocks[indexBlock]->selects.length() - 1) { return; }

    for(int i = 0; iterAtts && i < indexSelect; iterAtts = iterAtts->next, i++) {}

    response = iterAtts->data;

}

void CommandProcessor::getAttributeValueForSection(DoublyLinkedList<BlockList> &list) {

    size_t indexBlock = stringToInt(comOpFirst);
    Node<BlockList>* iter = getSectionNumber(list, indexBlock);

    Node<Atts>* iterAtts = iter->data.blocks[indexBlock]->atts.getHead();

    for(;iterAtts; iterAtts = iterAtts->next) {
        if(iterAtts->data.att == comOpLast) {
            response = iterAtts->data.val;
            return;
        }
    }
}

void CommandProcessor::countSelect(DoublyLinkedList<BlockList> &list) {

    Node<BlockList>* iter = list.getHead();
    Node<String>* iterSelect;
    int count = 0;

    for(; iter; iter = iter->next) {
        for(int i = 0; i < iter->data.lastIndex; i++) {
            if(!iter->data.blocks[i]) { continue;}
            for(iterSelect = iter->data.blocks[i]->selects.getHead(); iterSelect; iterSelect = iterSelect->next) {
                if(iterSelect->data == comOpFirst) { count++; break;}
            }
        }
    }

    intToString(count, response);

}

void CommandProcessor::countAttribute(DoublyLinkedList<BlockList> &list) {

    Node<BlockList>* iter = list.getHead();
    Node<Atts>* iterSelect;
    int count = 0;

    for(; iter; iter = iter->next) {
        for(int i = 0; i < iter->data.lastIndex; i++) {
            if(!iter->data.blocks[i]) { continue;}
            for(iterSelect = iter->data.blocks[i]->atts.getHead(); iterSelect; iterSelect = iterSelect->next) {

                if(iterSelect->data.att == comOpFirst) { count++; break;}

            }
        }
    }
    intToString(count, response);
}

void CommandProcessor::deleteSection(DoublyLinkedList<BlockList> &list) {

    size_t sectionNumber = stringToInt(comOpFirst);
    Node<BlockList> *iter = getSectionNumber(list, sectionNumber);

    if(sectionNumber > iter->data.lastIndex - 1) { return; }

    if(iter->data.blocks[sectionNumber]) {

        delete iter->data.blocks[sectionNumber];
        iter->data.blocks[sectionNumber] = nullptr;
        iter->data.deletedCount++;
        response = "deleted";

    }

    iter = list.getHead();
    for(size_t i = 0; iter; i++) {

        if(iter->data.lastIndex == iter->data.deletedCount) {
            iter = iter->next;
            list.removeElement(i);
            continue;

        }

        iter = iter->next;

    }

}

void CommandProcessor::deleteAttribute(DoublyLinkedList<BlockList> &list) {

    size_t sectionNumber = stringToInt(comOpFirst);
    String attName = comOpLast;

    Node<BlockList>* block = getSectionNumber(list, sectionNumber);

    if(sectionNumber > block->data.lastIndex - 1 ) { return; }

    Node<Atts>* iterAtt = block->data.blocks[sectionNumber]->atts.getHead();

    size_t i = 0;
    for(; iterAtt->data.att != attName; i++) {
        if(iterAtt->next) { iterAtt = iterAtt->next;}
        else { break; }
    }

    if(iterAtt->data.att == attName) {

        block->data.blocks[sectionNumber]->atts.removeElement(i);

        if(block->data.blocks[sectionNumber]->atts.length() == 0) {
            delete block->data.blocks[sectionNumber];
            block->data.blocks[sectionNumber] = nullptr;
            block->data.deletedCount++;
        }
        response = "deleted";
    }

    block = list.getHead();
    for(size_t i = 0; block; i++) {

        if(block->data.lastIndex == block->data.deletedCount) {
            block = block->next;
            list.removeElement(i);
            continue;

        }

        block = block->next;

    }
}

void CommandProcessor::getAttributeForSelector(DoublyLinkedList<BlockList> &list) {

    String attName = comOpLast;
    String selectName = comOpFirst;
    bool isSelectPresent = false;
    bool isAttPresent = false;

    Node<BlockList>* iter = list.getTail();
    Node<String>* iterSelect;

    while(iter && !isAttPresent) {

        for(int i = iter->data.lastIndex - 1; i > 0 && !isAttPresent; i--) {

            if(!iter->data.blocks[i]) { continue;}

            for(iterSelect = iter->data.blocks[i]->selects.getHead(); iterSelect && !isSelectPresent; ) {

                if (iterSelect->data == selectName) { isSelectPresent = true; }
                if(!isSelectPresent) { iterSelect = iterSelect->next; continue; }
            }
            if(!isSelectPresent) { continue; }

            for(Node<Atts>* iterAtt = iter->data.blocks[i]->atts.getHead(); iterAtt;) {

                if(iterAtt->data.att == comOpLast) {response = iterAtt->data.val; isAttPresent = true; break;}
                iterAtt = iterAtt->next;
            }
        }
        iter = iter->prev;
    }
}



bool CommandProcessor::executeCommand(DoublyLinkedList<BlockList>& list) {

    response = "";

    //count command
    if(comOpFirst == "?") {
        countSections(list);
    }
        //count selectors
    else if(isNumber(comOpFirst) && comOpMid == "S" && comOpLast == "?") {
        countSelectsForSection(list);
    }
        //count attributes
    else if(isNumber(comOpFirst) && comOpMid == "A" && comOpLast == "?") {
        countAttsForSection(list);
    }
        //get i-th selector in j-th block
    else if(isNumber(comOpFirst) && comOpMid == "S" && isNumber(comOpLast)) {
        getIselectorJblock(list);
    }
        //attribute value for i-th section
    else if (isNumber(comOpFirst) && comOpMid == "A" && !isNumber(comOpLast) && comOpLast != "?") {
        getAttributeValueForSection(list);
    }
        //count selector with given name
    else if(comOpMid == "S" && comOpLast == "?") {
        countSelect(list);
    }
        //count attribute with given name
    else if(!isNumber(comOpFirst) && comOpMid == "A" && comOpLast == "?") {
        countAttribute(list);
    }
        //delete section
    else if(isNumber(comOpFirst) && comOpMid == "D" && comOpLast == "*") {
        deleteSection(list);
    }
        //delete attribute if section is empty delete section
    else if(isNumber(comOpFirst) && comOpMid == "D" && comOpLast != "*") {
        deleteAttribute(list);
    }
        //attribute value for last occurence of a selector
    else if(comOpMid == "E") {
        getAttributeForSelector(list);
    }


    if(response.length()) return true;

    return false;

}

Node<BlockList>* CommandProcessor::getSectionNumber(DoublyLinkedList<BlockList>& list, size_t& sectionNumber) {

    Node<BlockList>* iter = list.getHead();
    sectionNumber--;

    size_t i = 0;
    for (; (i <= sectionNumber) && iter; i++) {

        if (i + iter->data.lastIndex - iter->data.deletedCount <= sectionNumber) { i += iter->data.lastIndex - 1 - iter->data.deletedCount; }
        else {
            sectionNumber -= i;
            break;
        }

        if(iter->next) { iter = iter->next; }
        else { break; }
    }

    size_t emptySpaces = 0;

    for(i = 0; i-emptySpaces < sectionNumber+1; i++) {

        if(!iter->data.blocks[i]) { emptySpaces++; }

    }

    sectionNumber+=emptySpaces;

    return iter;

}




bool CommandProcessor::extractCommand() {

    comOpFirst.clear();
    comOpMid.clear();
    comOpLast.clear();

    String garbage;

    if(std::cin.peek() == ',') { getFromStream(std::cin, garbage, Newline); }

    getFromStream(std::cin, comOpFirst, Commands);
    trimStr(comOpFirst);

    if(comOpFirst == "****") { return (isProcessing = false); }
    if(comOpFirst == "?") { return true; } //only command which consists only of one statement

    std::cin.get();
    getFromStream(std::cin, comOpMid, Commands);
    std::cin.get();
    getFromStream(std::cin, comOpLast, Commands);

    trimStr(comOpMid);
    trimStr(comOpLast);

    return true;

}