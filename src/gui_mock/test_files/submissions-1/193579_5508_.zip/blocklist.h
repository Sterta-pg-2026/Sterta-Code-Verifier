#pragma once
#include "cssblock.h"

struct BlockList {

    static const int blockCount = 17;

    CssBlock* blocks[blockCount];
    size_t lastIndex;
    size_t deletedCount;

    BlockList();

    ~BlockList();

    bool isSpace() const;

    void pushBlock(CssBlock* block);

    friend std::ostream& operator<<(std::ostream& out, const BlockList& bl);

};