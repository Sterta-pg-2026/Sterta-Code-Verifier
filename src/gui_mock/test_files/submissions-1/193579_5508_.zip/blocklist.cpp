#include "blocklist.h"

BlockList::BlockList() : lastIndex(0), deletedCount(0), blocks() {}

BlockList::~BlockList() {

    for(int i = 0; i < lastIndex; i++) {

        if (blocks[i]) { delete blocks[i]; }

    }
}

bool BlockList::isSpace() const { return lastIndex < blockCount; }

void BlockList::pushBlock(CssBlock* block) { blocks[lastIndex++] = block; }

std::ostream& operator<<(std::ostream& out, const BlockList& bl) {

    for(size_t i = 0; i < bl.lastIndex; i++ ) { out << bl.blocks[i]; }

    return out;

}


