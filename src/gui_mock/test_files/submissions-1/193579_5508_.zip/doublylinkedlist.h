#pragma once
#include <iostream>
#include "node.h"

template<typename T>
class DoublyLinkedList {

    Node<T>* head;
    Node<T>* tail;
    size_t size;

public:

    DoublyLinkedList();

    DoublyLinkedList(size_t size);

    DoublyLinkedList(const DoublyLinkedList<T>& other);

    ~DoublyLinkedList();

    DoublyLinkedList<T>& operator=(const DoublyLinkedList<T>& other);

    void pushBack(T data);

    void addFirst(T data);

    void addFirst();

    void pushBack();

    T& getLast();

    T& getFirst();

    Node<T>* getHead();

    Node<T>* getTail();

    Node<T>* getNext(Node<T>* node);

    void clear();

    //both methods return a base value (T()) if the list is empty
    T removeLast();

    T removeFirst();

    T removeElement(size_t index);

    bool isEmpty();

    size_t length();

    template<typename U> friend std::ostream& operator<<(std::ostream& out, const DoublyLinkedList<U>& list);

};

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList() :
        size(), head(), tail() {}

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList(size_t Tsize) :
        size(Tsize), head(), tail() {

    head = new Node<T>;

    Node<T>* nodePtr = head;

    for(size_t i = 0; i < Tsize - 1; i++) {

        nodePtr->next = new Node<T>;
        nodePtr->next->prev = nodePtr;
        nodePtr = nodePtr->next;

    }

}

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList(const DoublyLinkedList& other) : size(other.size) {

    head = new Node<T>(other.head->data);

    //iterators over both lists
    Node<T>* nodePtr = head;
    const Node<T>* nodePtrOther = other.head->next;

    while(nodePtrOther) {

        nodePtr->next = new Node<T>;
        nodePtr->next->data = nodePtrOther->data;
        nodePtr->next->prev = nodePtr;

        nodePtr = nodePtr->next;
        nodePtrOther = nodePtrOther->next;

    }

    tail = nodePtr;

}

template<typename T>
Node<T> *DoublyLinkedList<T>::getHead() { return head; }

template<typename T>
Node<T> *DoublyLinkedList<T>::getTail() { return tail; }

template<typename T>
Node<T> *DoublyLinkedList<T>::getNext(Node<T>* node) { return node->next; }

template<typename T>
DoublyLinkedList<T>::~DoublyLinkedList() {

    Node<T>* node;

    if(size == 0) return;
    if(!head) return;

    while (head) {

        node = head;
        head = head->next;
        delete node;

    }

    size = 0;

}

template<typename T>
void DoublyLinkedList<T>::addFirst(T data) {

    Node<T>* newNode = new Node<T>(data);
    size++;

    if (!head) { head = tail = newNode; return; }

    head->prev = newNode;
    newNode->next = head;

    head = newNode;

}

template<typename T>
void DoublyLinkedList<T>::addFirst() {

    Node<T>* newNode = new Node<T>;
    size++;

    if (size == 1) { head = tail = newNode; return; }

    head->prev = newNode;
    newNode->next = head;

    head = newNode;

}

template<typename T>
void DoublyLinkedList<T>::pushBack(T data) {

    Node<T>* newNode = new Node<T>(data);
    size++;

    if (!tail) { head = tail = newNode; return; }

    tail->next = newNode;
    newNode->prev = tail;

    tail = newNode;

}

template<typename T>
void DoublyLinkedList<T>::pushBack() {

    Node<T>* newNode = new Node<T>;
    size++;

    if (!tail) { head = tail = newNode; return; }

    tail->next = newNode;
    newNode->prev = tail;

    tail = newNode;

}

template<typename T>
T& DoublyLinkedList<T>::getLast() { return tail->data; }

template<typename T>
T& DoublyLinkedList<T>::getFirst() { return head->data; }

//what if value returned by the default constructor is a valid value???
template<typename T>
T DoublyLinkedList<T>::removeLast() {

    if (!tail) { return T(); }

    Node<T>* nodeToDelete = tail;
    T returnData = nodeToDelete->data;
    tail = tail->prev;

    if(nodeToDelete->prev) { nodeToDelete->prev->next = nullptr; }

    delete nodeToDelete;

    size--;

    return returnData;

}

template<typename T>
T DoublyLinkedList<T>::removeFirst() {

    if (!head) { return T(); }

    Node<T>* nodeToDelete = head;
    T returnData = head->data;
    head = head->next;

    if(tail != head) { head->prev = nullptr; }
    if(nodeToDelete->next) { nodeToDelete->next->prev = nullptr; }

    nodeToDelete->next = nullptr;
    delete nodeToDelete;

    size--;

    return returnData;
}

template<typename T>
T DoublyLinkedList<T>::removeElement(size_t index) {

    if(index > size) { return T(); }

    Node<T>* nodeTodelete = head;
    for(size_t i = 0; i < index; i++, nodeTodelete = nodeTodelete->next ) {}

    if(!nodeTodelete->next) { return removeLast(); }
    if(!nodeTodelete->prev) { return  removeFirst(); }

    T returnData = nodeTodelete->data;

    Node<T>* temp = nodeTodelete->prev;
    nodeTodelete->next->prev = temp;
    nodeTodelete->prev->next = nodeTodelete->next;

    delete nodeTodelete;

    size--;

    return returnData;

}

template<typename T>
void DoublyLinkedList<T>::clear() {

    Node<T>* node;

    if(size == 0) { return; }
    
    while(head) {

        node = head;
        head = head->next;
        delete node;

    }
    
    head = nullptr;
    tail = nullptr;
    size = 0;

}


template<typename T>
size_t DoublyLinkedList<T>::length() {

    return size;

}

template<typename T>
bool DoublyLinkedList<T>::isEmpty() {

    return size == 0;

}

template<typename T>
DoublyLinkedList<T>& DoublyLinkedList<T>::operator=(const DoublyLinkedList<T>& other) {

    DoublyLinkedList tmp(other);

    clear();

    std::swap(this->head, tmp.head);
    std::swap(this->tail, tmp.tail);
    std::swap(this->size, tmp.size);

    return *this;

}

template<typename T>
std::ostream& operator<<(std::ostream& out, const DoublyLinkedList<T>& list) {

    if(list.head == nullptr) { return out; }

    const Node<T>* iterNode = list.head;

    while (iterNode) {

        out << iterNode->data << " ";
        iterNode = iterNode->next;

    }

    return out;

}



