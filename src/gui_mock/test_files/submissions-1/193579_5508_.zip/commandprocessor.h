#include "doublylinkedlist.h"
#include "blocklist.h"
#include "string.h"

class CommandProcessor {

    String comOpFirst;
    String comOpMid;
    String comOpLast;
    String response;

    bool isProcessing;

    private:

    void countAttribute(DoublyLinkedList<BlockList>& list);

    void countAttsForSection(DoublyLinkedList<BlockList>& list);

    void countSelect(DoublyLinkedList<BlockList>& list);

    void countSelectsForSection(DoublyLinkedList<BlockList>& list);

    void countSections(DoublyLinkedList<BlockList>& list);

    void getIselectorJblock(DoublyLinkedList<BlockList>& list);

    void getAttributeValueForSection(DoublyLinkedList<BlockList>& list);

    void deleteSection(DoublyLinkedList<BlockList>& list);

    void deleteAttribute(DoublyLinkedList<BlockList>& list);

    void getAttributeForSelector(DoublyLinkedList<BlockList>& list);

    public:

    CommandProcessor();

    void changeProcessorState();

    bool getProcessorState() const;

    String buildResponse(DoublyLinkedList<BlockList>& list);

    bool executeCommand(DoublyLinkedList<BlockList>& list); //returns true if command executed properly

    bool extractCommand();

    Node<BlockList>* getSectionNumber(DoublyLinkedList<BlockList>& list, size_t& sectionNumber);
};


