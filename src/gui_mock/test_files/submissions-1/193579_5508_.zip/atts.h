#pragma once
#include "string.h"

struct Atts {

    String val;
    String att;

    Atts();

    Atts(String v,  String  a);

    friend std::ostream& operator<<(std::ostream& out, const Atts& a);

};
