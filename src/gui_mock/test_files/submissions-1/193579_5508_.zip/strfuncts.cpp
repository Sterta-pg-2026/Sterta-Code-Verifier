#include "string.h"
#include "string.h"
#include <algorithm>
#include <cctype>

enum SeparatorFlags { Newline, Space, Coma, Colon, Selectors, Attributes, Commands};

void trimStr(String& str) {

    const char* iterBeg = str.buffer;
    const char* iterEnd = str.buffer + str.size;

    if(iterBeg == iterEnd) { return; }

    while (std::isspace(*(iterEnd -1)) && iterEnd > iterBeg) { iterEnd--; }

    while (iterBeg && std::isspace(*iterBeg) && iterBeg < iterEnd) { iterBeg++; }

    size_t newSize = (iterEnd - iterBeg);

    char* newBuff = new char[newSize + 1];

    for(size_t i = 0; i < newSize; i++) { newBuff[i] = iterBeg[i]; }

    newBuff[newSize] = '\0';

    str.clear();

    str.buffer = newBuff;
    str.size = newSize;

}

bool isNumber(const String& str) {

    char* iter = str.buffer;

    if(!iter) { return false; }

    while(*iter != '\0') {
        if(*iter > '9' || *iter < '0'){ return false; }
        iter++;
    }

    return true;

}

void intToString(int val, String& str) {

    int bufferSize = snprintf(NULL, 0,"%d", val);

    str.clear();
    str.buffer = new char[bufferSize + 1];
    str.size = bufferSize;

    sprintf(str.buffer, "%d", val);
}



int stringToInt(const String& str) {

    return atoi(str.buffer);

}

std::istream& getFromStream(std::istream& in, String& out, int separatorFlags) {

    out.clear();

    std::istream::sentry sentry(in);

    unsigned int size = String::BaseBufferSize;
    unsigned int tail = 0;
    char* temp = new char[size + 1];
    int next;

    while ((next = in.peek()) && next != - 1 && std::cin.peek() != '=') {

        if (separatorFlags == Newline && next == '\n') break;
        if (separatorFlags == Space && std::isspace(next)) break;
        if (separatorFlags == Coma && next == ',') break;
        if (separatorFlags == Colon && next == ':') break;
        if (separatorFlags == Selectors && (next == ',' || next == '{' || next == '\n')) break;
        if (separatorFlags == Attributes && next == ':' || next == ';' || next == '\n' || next == '}') break;
        if (separatorFlags == Commands && (next == ',') ) break;

        if (tail >= size) {

            unsigned int newsize = std::max(2*size, 16u);
            char* newtemp = new char[newsize+1];
            for(int i = 0; temp[i]; i++) { newtemp[i] = temp[i]; }
            newtemp[newsize] = '\0';
            delete [] temp;
            temp = newtemp;
            size = newsize;
        }

        temp[tail++] = in.get();

    }

    temp[tail] = '\0';
    out = temp;
    delete[] temp;

    return in;
}
