#include <iostream>
#include <sstream>

using namespace std;
const long long int size_of_css = 100;

class Node;
class List;
class String;
typedef struct Array_List
{
    List* selector_struct;
    List* attribute_property_struct;
    List* attribute_value_struct;
};

class String {
private:
    char* data = nullptr;
    size_t length = 0;
    int capacity = 1;

    void resize(int new_capacity) {
        char* new_data = new char[new_capacity];
        if (data != nullptr)
        {
            std::memcpy(new_data, data, length + 1);
            delete[] data;
        }
        data = new_data;
        capacity = new_capacity;
        memset(data + length, 0, new_capacity - length);
    }

public:
    // Konstruktor domyślny
    String() : data(nullptr), length(0) {}

    // Konstruktor, który tworzy obiekt String z podanego ciągu znaków
    String(const char* str) {

        length = strlen(str);
        data = new char[length + 1];
        strcpy_s(data, length + 1, str);

    }

    // Konstruktor kopiujący
    String(const String& other) {
        length = other.length;
        if (other.data != nullptr) {
            data = new char[length + 1];
            strcpy_s(data, length + 1, other.data);
        }
        else
            data = nullptr;
    }

    // Destruktor
    ~String() {
        delete[] data;
    }

    // Zwraca długość ciągu znaków
    int size() const {
        return length;
    }

    // Zwraca wskaźnik do ciągu znaków (const)
    const char* c_str() const {
        return data;
    }

    // Czyści zawartość obiektu String
    void clear() {
        delete[] data;
        length = 0;
        capacity = 1;
        data = new char[capacity];
        data[0] = '\0';
    }


    // Operator przypisania, który przypisuje ciąg znaków do obiektu String
    String& operator=(const char* str) {
        clear();
        length = strlen(str);
        data = new char[length + 1];
        strcpy_s(data, capacity - length - 1, str);
        return *this;
    }

    // Operator przypisania kopiujący, który przypisuje zawartość innego obiektu String do tego obiektu
    String& operator=(const String& other) {
        if (this == &other)
        {
            return *this;
        }
        clear();
        if (other.length > 0 && other.data != nullptr) {
            length = other.length;
            data = new char[length + 1];
            strcpy_s(data, length + 1, other.data);
        }
        return *this;
    }

    // Operator indeksowania, który zwraca znak o podanym indeksie
    char& operator[](int index) {
        return data[index];
    }

    // Operator indeksowania (const), który zwraca znak o podanym indeksie (tylko do odczytu)
    const char& operator[](int index) const {
        return data[index];
    }

    // Operator dodawania, który zwraca nowy obiekt String, będący połączeniem tego obiektu i podanego ciągu znaków
    String operator+(const char* str) const {
        String result(*this);
        result += str;
        return result;
    }

    // Operator dodawania, który zwraca nowy obiekt String, będący połączeniem dwóch obiektów String
    String operator+(const String& other) const {
        String result(*this);
        result += other;
        return result;
    }

    // Operator dodawania i przypisania, który dodaje podany ciąg znaków do tego obiektu i zwraca referencję do niego
    String& operator+=(const char* str) {
        int new_length = length + static_cast<int>(std::strlen(str));
        if (new_length >= capacity) {
            int new_capacity = capacity * 2;
            while (new_capacity <= new_length) {
                new_capacity *= 2;
            }
            resize(new_capacity);
            data[length] = '\0';
        }
        strcat_s(data, new_length + 1, str);
        length = new_length;
        return *this;
    }

    String& operator+=(const String& other) {
        return (*this += other.data);
    }
    String& operator+=(char c) {
        char temp[2] = { c, '\0' };
        return (*this += temp);
    }

    friend ostream& operator<<(ostream& os, const String& str) {
        os << str.data;
        return os;
    }

    friend istream& operator>>(std::istream& is, String& str) {
        char buffer[4096];
        is >> buffer;
        str = buffer;
        return is;
    }
    bool operator==(const char* str) const {
        return strcmp(data, str) == 0;
    }
    bool operator==(const String& other) const {
        return strcmp(data, other.data) == 0;
    }

    bool operator!=(const char* str) const {
        return strcmp(data, str) != 0;
    }

    bool operator!=(const String& other) const {
        return strcmp(data, other.data) != 0;
    }
    bool is_empty() const {
        return (data == nullptr || *data == '\0');
    }
    void my_strcat_s(char* dest, const char* src, size_t dest_size)
    {
        size_t i = 0;
        while (dest[i] != '\n') {
            ++i;
        }
        while (*src != '\n' && i < dest_size - 1) {
            dest[i++] = *src++;
        }
        dest[i] = '\n';
    }
    bool isWhitespace(const char* str) {
        while (*str) {
            if (*str != ' ' && *str != '\n' && *str != '\r' && *str != '\t') {
                return false;
            }
            str++;
        }
        return true;
    }
    String selector_read_until()
    {
        String input;
        char c;
        while ((c = getchar()))
        {
            if (c == ',' || c == '\n'||c==' ')
            {
                if (input.is_empty() || input == "," || input == "\n" || input == "{") 
                {
                    input.clear();
                    continue;
                }
                else
                {
                    String result = input;
                    input.clear();
                    return result;
                }
            }
            else if (c == '{')
            {
                if (input.is_empty() || input == "," || input == "\n" || input == "{")
                {
                    input.clear();
                    continue;
                }
                else 
                {
                    String result = input;
                    input.clear();
                    return result;
                }
            }
            else
            {
                input += c;
            }
        }
    }
    String attribute_property_read_until() {
        String input;
        char c;
        while ((c = getchar())) {
            if (c == ':' || c == '\n'||c==' ') {
                if (input.is_empty() || input == ":" || input == "\n") {
                    input.clear();
                    continue;
                }
                else {
                    String result = input;
                    input.clear();
                    return result;
                    break;
                }
            }
            
            else {
                input += c;
            }
        }
    }
    String attribute_value_read_until() {
        String input;
        char c;
        while ((c = getchar())) {
            if (c == ';' || c == '\n' || c == '}'||c==' ') {
                if (input.is_empty() || input == ";" || input == "\n" || input == "}") {
                    input.clear();
                    continue;
                }
                else {
                    String result = input;
                    input.clear();
                    return result;
                }
            }
            else {
                input += c;
            }
        }
    }
    bool is_digit() const {
        for (int i = 0; i < length; i++) {
            if (!(data[i] >= '0' && data[i] <= '9')) {
                return false;
            }
        }
        return true;
    }
    int to_int() const {
        int value = 0;
        bool negative = false;
        for (int i = 0; i < size(); i++) {
            if (i == 0 && data[i] == '-') { // sprawdź, czy liczba jest ujemna
                negative = true;
                continue;
            }
            if (!(data[i] >= '0' && data[i] <= '9')) { // jeśli napotkano znak innego typu, zwróć zero
                return 0;
            }
            value = value * 10 + (data[i] - '0'); // wylicz wartość liczbową
        }
        return negative ? -value : value;
    }


};



class Node {
private:

public:
    String value; // wartość, którą przechowuje węzeł
    Array_List* data;
    String wart;
    Node* next; // wskaźnik na kolejny węzeł w liście
    Node* prev;
    Node* sublist1_head;
    Node* sublist2_head;
    Node(String val) {
        value = val;
        next = nullptr;
        sublist1_head = nullptr;
        sublist2_head = nullptr;
    }



    Node() {
        data; // lub jakąkolwiek inną wartość domyślną dla typu danych w strukturze
        next = nullptr;
        prev = nullptr;
    }

    ~Node() {
        delete next;
        delete sublist1_head;
        delete sublist2_head;
    }

};


class List {
private:
    Node* head; // wskaźnik na pierwszy węzeł w liście
    Node* tail;
    int size; // rozmiar listy

public:


    void add_value_at_the_end_of_the_list(String val) { // dodanie nowego węzła z daną wartością na koniec listy
        Node* newNode = new Node(val); // tworzenie nowego węzła z daną wartością
        if (head == nullptr) { // jeśli lista jest pusta, ustawiamy wskaźnik na pierwszy węzeł na nowy węzeł
            head = newNode;
        }
        else { // w przeciwnym razie, idziemy na koniec listy i ustawiamy wskaźnik na kolejny węzeł na nowy węzeł
            Node* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
        size++; // zwiększamy rozmiar listy
    }

    void add_value_at_index(String val, int index) { // dodanie nowego węzła z daną wartością na wybraną pozycję w liście
        if (index < 0 || index > size) { // jeśli podany indeks jest niepoprawny, zwracamy pustą wartość
            return;
        }
        Node* newNode = new Node(val); // tworzenie nowego węzła z daną wartością
        if (index == 0) { // jeśli chcemy dodać węzeł na początku listy, ustawiamy wskaźnik na kolejny węzeł nowego węzła na obecny pierwszy węzeł i ustawiamy wskaźnik na pierwszy węzeł na nowy węzeł
            newNode->next = head;
            head = newNode;
        }
        else { // w przeciwnym razie, idziemy do węzła o poprzednim indeksie i ustawiamy wskaźniki nowego węzła i poprzedniego węzła na odpowiednie węzły
            Node* current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
        size++; // zwiększamy rozmiar listy
    }
    String getValueAtIndex(int index) {
        Node* node = getNode(index);
        if (node == nullptr) {
            return "";
        }
        return node->value;
    }
    // zwraca węzeł o danym indeksie
    Node* getNode(int index) {
        if (index < 0) return nullptr;
        Node* current = head;
        int i = 0;
        while (current != nullptr && i < index) {
            current = current->next;
            i++;
        }
        return current;
    }

    // zwraca ostatni węzeł w liście
    Node* getLastNode() {
        Node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        return current;
    }
    Node* find_node(String value) {
        Node* current = head;
        while (current != nullptr) {
            if (current->wart == value) {
                return current;
            }
            current = current->next;
        }
        return nullptr;
    }
    int find_index(String value) const {
        int index = 0;
        Node* current = head;

        while (current != nullptr) {
            if (current->wart == value) {
                return index;
            }
            current = current->next;
            index++;
        }

        return -1;
    }
    int count_occurrences(const String& value) const {
        int count = 0;
        Node* current = head;

        while (current != nullptr) {
            if (current->wart == value) {
                count++;
            }
            current = current->next;
        }
        return count;
    }
    bool contains_value(String value) {
        Node* current = head;
        while (current != nullptr) {
            if (current->wart == value) {
                return true;
            }
            current = current->next;
        }
        return false;
    }
    void clear_list(List* &head) {
        Node* current = head->head;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
        head->head = nullptr;
        head->tail = nullptr;
        head->size = 0;
    }
    void clear_section(Array_List* section, int index) {
        // usuwanie listy z atrybutami
        Node* current_attr = section[index].attribute_value_struct->head;
        while (current_attr != nullptr) {
            Node* temp = current_attr;
            current_attr = current_attr->next;
            delete temp;
        }
        section[index].attribute_value_struct->head = nullptr;

        // usuwanie listy z właściwościami atrybutów
        Node* current_prop = section[index].attribute_property_struct->head;
        while (current_prop != nullptr) {
            Node* temp = current_prop;
            current_prop = current_prop->next;
            delete temp;
        }
        section[index].attribute_property_struct->head = nullptr;

        // usuwanie listy z selektorami
        Node* current_sel = section[index].selector_struct->head;
        while (current_sel != nullptr) {
            Node* temp = current_sel;
            current_sel = current_sel->next;
            delete temp;
        }
        section[index].selector_struct->head = nullptr;
    }

    // dodawanie podlisty na wskazanym indeksie
    void add_sublist_at_index(List sublist, int index) {
        Node* current = getNode(index);
        Node* nextNode = current->next;

        // ustawienie ostatniego węzła podlisty na następny węzeł po aktualnym
        Node* lastNode = sublist.getLastNode();
        lastNode->next = nextNode;

        // ustawienie węzła następnego po aktualnym na pierwszy węzeł podlisty
        current->next = sublist.head;
    }
    void add_sublists_at_index(List sublist1, List sublist2, int index) {
        Node* current = getNode(index);
        Node* nextNode = current->next;

        // ustawienie ostatniego węzła podlisty 1 na początek podlisty 2
        Node* lastNode1 = sublist1.getLastNode();
        lastNode1->next = sublist2.head;

        // ustawienie węzła następnego po aktualnym na początek podlisty 1
        current->next = sublist1.head;

        // ustawienie wskaźnika na początek podlisty 1 i 2 w węźle aktualnym
        current->sublist1_head = sublist1.head;
        current->sublist2_head = sublist2.head;
    }

    void addArrayListAtIndex(Array_List arr[], int index) {
        if (index < 0 || index > size) {
            cout << "Invalid index" << endl;
            return;
        }

        Node* newNode = new Node();
        newNode->data = new Array_List[8];

        for (int i = 0; i < 8; i++) {
            newNode->data[i] = arr[i];
        }

        if (size == 0) {
            head = newNode;
            tail = newNode;
        }
        else if (index == 0) {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        else if (index == size) {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        else {
            Node* current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next->prev = newNode;
            current->next = newNode;
            newNode->prev = current;
        }
        size++;
    }



    void remove(int index) { // usunięcie węzła o podanym indeksie z listy
        if (index < 0 || index >= size) { // jeśli podany indeks jest niepoprawny, zwracamy pustą wartość
            return;
        }
        if (index == 0) { // jeśli chcemy usunąć pierwszy węzeł, ustawiamy wskaźnik na pierwszy węzeł na kolejny węzeł i usuwamy poprzedni pierwszy węzeł
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        else { // w przeciwnym razie, idziemy do węzła o poprzednim indeksie i ustawiamy jego wskaźnik na kolejny węzeł na kolejny węzeł po usuwanym węźle, a następnie usuwamy węzeł
            Node* current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current->next;
            }
            Node* temp = current->next;
            current->next = temp->next;
            delete temp;
        }
        size--; // zmniejszamy rozmiar listy
    }
/*void clear_section(int index, Array_List* sections) {
        Node* current = this->data[index].attribute_value_struct;
        while (current != NULL) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
        sections[index].attribute_value_struct = NULL;
        sections[index].attribute_property_struct = NULL;
        sections[index].attribute_property_count = 0;
    }*/

    void display() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->value << " ";
            current = current->next;
        }
        cout << endl;
    }

    int getSize() {
        return size;
    }
};


//WPIERDOLIC FUNKCJEN WPISUJACA SELEKTORY DO MAINA JUTRO !!!!

int main()
{

    const int num_of_blocks = 8;
    List css_sections;
    Array_List Section[num_of_blocks];
    String Input;
    String command[10];
    String input_block = "after selectors :)";
    char c='w';
    int num_of_section = 0;
    int command_num_of_section = 0;
    int turn = 0;
    int attribute_turn = 0;
    int i, j; //do loopa
    int index_selector = 0;
    int index_section = 0;
    int index_attribute = 0;
    int array_index = 0;
    int block_number = 0;
    int selector_number=0;
    int attribute_number = 0;

    do
    {
        css:
        if (turn == 0)
        {
          
            for (i = 0; i < num_of_blocks; i++)
            {
                List selector;
                List attribute;

            
                for (j = 0; j < size_of_css; j++)
                {

                    if (c != '{')
                    {
                        String result;
                        while ((c = getchar())&&turn==0)
                        {
                            
                            if (c == ',' || c == '\n')
                            {
                                if (Input.is_empty() || Input == ","  || Input == " " )
                                {
                                    Input.clear();
                                    continue;
                                }
                                else if (Input == "{")
                                {
                                    Section[array_index].selector_struct = &selector;
                                    Input.clear();
                                    break;
                                }
                                else
                                {
                                    if (Input != "????")
                                    {
                                        result = Input;
                                        Input.clear();
                                        selector.add_value_at_index(result, index_selector);
                                        result.clear();
                                        index_selector++;
                                    }
                                    else
                                    {
                                        turn = 1;
                                        goto command;
                                    }
                                  
                                }
                              
                            }
                            
                            else if (c == '{')
                            {
                                if (Input.is_empty() || Input == "," || Input == "\n" ||Input==" ")
                                {
                                    Input.clear();
                                    continue;
                                }
                                else
                                {
                                    Section[array_index].selector_struct = &selector;
                                    Input.clear();
                                    break;
                                }
                            }
                            else
                            {
                                Input += c;
                            }
                                                 
                        }
                        
                    }
                    if (c== '{')
                    {//ATRYBUTY
                      
                        char c;
                        while ((c = getchar())&&turn==0)
                        {
                         
                            if (attribute_turn == 0) //Attribute property
                            {
                              
                                if (c == ':' || c == '\n')
                                {
                                    if (Input.is_empty() || Input == ":" || Input == "\n")
                                    {
                                        Input.clear();
                                        continue;
                                    }
                                    else
                                    {
                                        String result = Input;
                                        attribute.add_value_at_index(result, index_attribute);
                                        Section[array_index].attribute_property_struct = &attribute;
                                        Input.clear();
                                        attribute_turn = 1;
                                    }
                                }

                                else {
                                    Input += c;
                                }
                            }
                            else if (attribute_turn == 1) //Attribute value
                            {
                              
                                if (c == ';'  || c == ' ')
                                {
                                    if (Input.is_empty() || Input == ";" || Input == "\n" || Input == "}")
                                    {
                                        Input.clear();
                                        continue;
                                    }
                                    else
                                    {
                                        String result = Input;
                                        attribute.add_value_at_index(result, index_attribute);
                                        index_attribute++;
                                        Section[array_index].attribute_value_struct = &attribute;
                                        Input.clear();

                                    }
                                }
                                else if (c == '\n')
                                {
                                    if (Input.is_empty() || Input == ";" || Input == "\n" || Input == "}")
                                    {
                                        Input.clear();
                                        continue;
                                    }
                                    else
                                    {
                                        attribute_turn = 0;
                                        Input.clear();

                                    }

                                }
                                else if ( c == '}')
                                {
                                    
                                    array_index++;
                                    num_of_section++;
                                    break;
                                }
                                else {
                                    Input += c;
                                }
                            }
                        }
                        break;
                    }    
                }
            }
            css_sections.addArrayListAtIndex(Section, index_section);
            index_section++;
            break;
        
        }
    command:
        if (turn == 1)
        {
         
            
            
                String input;
                String result_array[10]; // tablica na 10 ciągów znaków
                int index = 0;
                char c;
                while ((c = getchar())) {
                    if (c == ','&&!EOF)
                    {
                        if (input.is_empty() || input == "," )
                        {
                            input.clear();
                            continue;
                        }
                       
                        else
                        {
                            result_array[index] = input; // dodaj ciąg do tablicy
                            input.clear();
                            index++; // zwiększ indeks
                        }
                    }
                    else if (c == '\n')
                    {
                        result_array[index] = input;
                        if (result_array[0] == "****" ) //?
                        {
                            turn = 0;
                            input.clear();
                            memset(command, 0, sizeof(command));
                            goto css;

                        }
                        else if (result_array[0] == "?")
                        {
                            cout << "? == " << num_of_section << endl;
                            memset(command, 0, sizeof(command));
                        }
                        else if (result_array[0].is_digit() && result_array[1] == "S" && result_array[2]=="?")//i,S,?
                        {
                            block_number = result_array[0].to_int();
                            int index_section1 = (block_number / 8) + 1;
                            int array_index1 = block_number % 8;
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) {
                                Array_List* Section = node->data;
                                List* list = node->data[array_index1].selector_struct;
                                int list_size = list->getSize();
                                cout << block_number << ",S,? == " << list_size << endl;
                            }
                            memset(command, 0, sizeof(command));

                        }
                        else if (result_array[0].is_digit() && result_array[1] == "A" && result_array[2] == "?")//i,A,?
                        {
                            block_number = result_array[0].to_int();
                            int index_section1 = (block_number / 8) + 1;
                            int array_index1 = block_number % 8;
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) {
                                Array_List* Section = node->data;
                                List* list = node->data[array_index1].attribute_property_struct;
                                int list_size = list->getSize();
                                cout << block_number << ",A,? == " << list_size << endl;
                            }
                            memset(command, 0, sizeof(command));


                        }
                        else if (result_array[0].is_digit() && result_array[1] == "A" && result_array[2].is_digit())//i,S,j
                        {
                            selector_number = result_array[2].to_int();
                            block_number = result_array[0].to_int();
                            int index_section1 = (block_number / 8) + 1;
                            int array_index1 = block_number % 8;
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) {
                                Array_List* Section = node->data;
                                List* list = node->data[array_index1].selector_struct;
                                String value = list->getValueAtIndex(selector_number);
                                cout << block_number << ",S," << selector_number << " == " << value << endl;
                            }
                            memset(command, 0, sizeof(command));

                        }
                        else if (result_array[0].is_digit() && result_array[1] == "A" && !result_array[2].is_digit())//i,A,n
                        {
                            String atr = result_array[2];
                            block_number = result_array[0].to_int();
                            int index_section1 = (block_number / 8) + 1; //wezel w liscie section
                            int array_index1 = block_number % 8;//komorka tablicy
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) {
                                Array_List* Section = node->data;
                                List* list_property = node->data[array_index1].attribute_property_struct;
                                int searching_index = list_property->find_index(atr);
                                List* list_value = node->data[array_index1].attribute_value_struct;
                                String value = list_value->getValueAtIndex(searching_index);
                                cout << block_number << ",S," << atr << " == " << value << endl;
                            }
                            memset(command, 0, sizeof(command));

                        }
                        else if (!result_array[0].is_digit() && result_array[1] == "A" && result_array[2]=="?")//n,A,?
                        {
                            String atr = result_array[0];
                            int quantity=0;
                            for (int k = 0; k < index_section; k++)
                            {
                                for (int p = 0; p < array_index; p++)
                                {
                                    Node* node = css_sections.getNode(k);
                                    if (node != nullptr)
                                    {
                                        Array_List* Section = node->data;
                                        List* list_property = node->data[p].attribute_property_struct;
                                        quantity+= list_property->count_occurrences(atr);
                                    }
                                }
                            }
                             cout << atr << ",A,? == " << quantity << endl;
                            
                            memset(command, 0, sizeof(command));

                        }
                        else if (!result_array[0].is_digit() && result_array[1] == "S" && result_array[2] == "?")//n,S,?
                        {
                            String slk = result_array[0];
                            int quantity = 0;
                            for (int k = 0; k < index_section; k++)
                            {
                                for (int p = 0; p < array_index; p++)
                                {
                                    Node* node = css_sections.getNode(k);
                                    if (node != nullptr)
                                    {
                                        Array_List* Section = node->data;
                                        List* list_property = node->data[p].selector_struct;
                                        quantity += list_property->count_occurrences(slk);
                                    }
                                }
                            }
                            cout << slk << ",S,? == " << quantity << endl;

                            memset(command, 0, sizeof(command));

                        }
                        else if (!result_array[0].is_digit() && result_array[1] == "E" && !result_array[0].is_digit())//z,E,n
                        {
                            String slk = result_array[0];
                            String atr = result_array[2];
                            bool contains_selec;
                            bool contains_atr;
                            for (int k = 0; k < index_section; k++)
                            {
                                for (int p = 0; p < array_index; p++)
                                {
                                    Node* node = css_sections.getNode(k);
                                    if (node != nullptr)
                                    {
                                        Array_List* Section = node->data;
                                        List* list_selec = node->data[p].selector_struct;
                                        contains_selec = list_selec->contains_value(slk);
                                        List* list_atr = node->data[p].attribute_property_struct;
                                        contains_atr = list_atr->contains_value(atr);
                                        if (contains_selec == true && contains_atr == true)
                                        {
                                            List* list_atr_prop = node->data[p].attribute_property_struct;
                                            int index_prop = list_atr->find_index(atr);
                                            List* list_atr_val = node->data[p].attribute_value_struct;
                                            String value_selec_atr = list_atr_val->getValueAtIndex(index_prop);
                                            cout << slk << ",E," << atr << " == " << value_selec_atr;
                                            break;
                                        }
                                        else
                                            continue;
                                    }

                                }
                                break;
                            }
                        }
                        else if (result_array[0].is_digit() && result_array[1] == "D" && result_array[2] == "*")//i,D,*
                        {
                            block_number = result_array[0].to_int();
                            int index_section1 = (block_number / 8) + 1;
                            int array_index1 = block_number % 8;
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) {
                                Array_List* Section = node->data;
                                css_sections.clear_section(Section, array_index1);
                                
                            }
                            memset(command, 0, sizeof(command));
                        }
                        else if (result_array[0].is_digit() && result_array[1] == "D" && !result_array[2].is_digit())//i,D,n
                        {
                            block_number = result_array[0].to_int();
                            String atr = result_array[2];
                            int index_section1 = (block_number / 8) + 1;
                            int array_index1 = block_number % 8;
                            Node* node = css_sections.getNode(index_section1);
                            if (node != nullptr) 
                            {
                                Array_List* Section = node->data;
                                List* list_property = node->data[array_index1].attribute_property_struct;
                                int index_atr = list_property->find_index(atr);
                                list_property->remove(index_atr);
                                List* list_value = node->data[array_index1].attribute_value_struct;
                                list_value->remove(index_atr);

                                cout << block_number << ",D," << atr << " == deleted" << endl;
                            }
                        }

                        memset(result_array, 0, sizeof(command));
                        index = 0;
                    }
                    else 
                    {
                        input += c;
                    }
                   
                }
                 // zwróć tablicę w przypadku braku kolejnych ciągów
        }
    } while (!EOF);
  
    return 0;
}