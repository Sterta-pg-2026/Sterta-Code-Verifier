#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
const int T = 43;
const int MAX = 128;

struct Selektor {
	char* sel;
	Selektor* next;

	Selektor() {
		sel = new char[MAX];
		next = NULL;
	}
	~Selektor() {
		delete[] sel;
	}
};
struct Atrybut {
	char* name;
	char* value;
	Atrybut* next;
	Atrybut* prev;

	Atrybut() {
		name = new char[MAX];
		value = new char[MAX];
		next = NULL;
		prev = NULL;
	}
	~Atrybut() {
		delete[] name;
		delete[] value;
	}
};
class Sekcja {
public:
	bool deleted;
	Selektor* selHead;
	Selektor* selTail;
	Atrybut* attHead;
	Atrybut* attTail;

	Sekcja() {
		deleted = false;
		selHead = NULL;
		selTail = NULL;
		attHead = NULL;
		attTail = NULL;
	}
	~Sekcja() {
		Sekcja* current = this;
		if (selHead != NULL) {
			Selektor* currentSel = selHead;
			while (currentSel != NULL) {
				Selektor* help = currentSel;
				currentSel = currentSel->next;
				delete help;
			}
			currentSel = NULL;
		}
		Atrybut* currentAtt = attHead;
		while (currentAtt != NULL) {
			Atrybut* help = currentAtt;
			currentAtt = currentAtt->next;
			delete help;
		}
		currentAtt = NULL;
		deleted = true;
		current = nullptr;
	}
	void add_sel(char* tab)
	{
		Selektor* nowy = new Selektor;
		strncpy(nowy->sel, tab, MAX);
		if (selHead == NULL)
		{
			this->selHead = nowy;
			this->selTail = nowy;
			nowy->next = NULL;
		}
		else
		{
			this->selTail->next = nowy;
			this->selTail = nowy;
			nowy->next = NULL;
		}
	}
	void add_att(char* nam, char* val)
	{
		Atrybut* nowy = new Atrybut;
		strncpy(nowy->name, nam, MAX);
		strncpy(nowy->value, val, MAX);
		nowy->value[MAX - 1] = '\0';
		if (attHead == NULL)
		{
			this->attHead = nowy;
			this->attTail = nowy;
			nowy->next = NULL;
			nowy->prev = NULL;
		}
		else
		{
			nowy->prev = attTail;
			nowy->next = NULL;
			attTail->next = nowy;
			attTail = nowy;
		}
	}
	void read(char first)
	{
		bool attbool = first == '{' ? false : true;
		bool koniec = true;
		if (attbool) {

			while (koniec)
			{
				char* tab = new char[MAX];
				strncpy(tab, "", MAX);
				int i = 0;
				if (selHead == NULL && first > ' ') {
					tab[i] = first;
					i++;
				}
				while (char c = (char)getchar())
				{
					if (i == 0 && c <= ' ')
						continue;
					else if (c == '{' || c == ',')
					{
						koniec = c == '{' ? false : true;
						while (tab[i] <= ' ') {
							tab[i] = '\0';
							i--;
						}
						break;
					}
					else {
						tab[i] = c;
						i++;
					}
				}
				Selektor* help = selHead;
				bool nie_istnieje = true;
				while (help != NULL) {
					if (!strncmp(help->sel, tab, MAX)) {
						nie_istnieje = false;
						break;
					}
					help = help->next;
				}
				if (nie_istnieje)
					add_sel(tab);
				delete[] tab;
			}
		}
		koniec = true;
		while (koniec) {
			char* nam = new char[MAX];
			char* val = new char[MAX];
			strncpy(nam, "", MAX);
			strncpy(val, "", MAX);
			bool nam_val = true;
			int i = 0;
			while (char c = (char)getchar())
			{
				if (i == 0 && (c <= ' ' || c == '\n'))
					continue;
				else if (c == '}' || c == ';')
				{
					koniec = c == '}' ? false : true;
					while (val[i] <= ' ' && i >= 0) {
						val[i] = '\0';
						i--;
					}
					break;
				}
				else
				{
					if (c == ':')
					{
						nam_val = false;
						i = 0;
					}
					else
					{
						if (nam_val)
						{
							nam[i] = c;
							i++;
						}
						else
						{
							val[i] = c;
							i++;
						}
					}
				}

			}
			bool brak_powtorki = true;
			Atrybut* help = attHead;
			while (help != NULL) {
				if (!strncmp(help->name, nam, MAX)) {
					brak_powtorki = false;
					break;
				}
				help = help->next;
			}
			if (nam[0] != '\0' && brak_powtorki) {
				this->add_att(nam, val);
			}
			else if (nam[0] != '\0' && !brak_powtorki) {
				strncpy(help->value, val, MAX);
			}
			delete[] nam;
			delete[] val;
		}
	}
};
class SekcjaNode {
public:
	SekcjaNode* prev;
	SekcjaNode* next;
	int SekCount;
	int DeletedCount;
	Sekcja** arr;

	SekcjaNode() {
		next = NULL;
		prev = NULL;
		arr = new Sekcja*[T];
		SekCount = 0;
		DeletedCount = 0;
	}
	~SekcjaNode() {
		delete[] arr;
	}
	void add_sek(char a) {
		Sekcja* nowa = new Sekcja;
		nowa->read(a);
		arr[SekCount] = nowa;
		SekCount++;
		if (SekCount == T)
			return;
	}
};

class css {
public:
	SekcjaNode* sekHead;
	SekcjaNode* sekTail;

	css() {
		sekHead = NULL;
		sekTail = NULL;
	}
	~css() {
		SekcjaNode* currentNode = sekHead;
		while (currentNode != NULL) {
			SekcjaNode* help = currentNode;
			currentNode = currentNode->next;
			delete help;
		}
		currentNode = NULL;
	}
	static void wypisz(char* text) {
		int i = 0;
		while (text[i] != '\0') {
			cout << text[i];
			i++;
		}
	}
	Sekcja* znajdz_sekcje(char* num)
	{
		SekcjaNode* help = sekHead;
		int liczba = atoi(num);
		int iterator = 0;
		while ((iterator + help->SekCount - help->DeletedCount) < liczba) {
			if (help->next == NULL)
				return NULL;
			iterator += help->SekCount;
			iterator -= help->DeletedCount;
			help = help->next;
		}
		int i = -1;
		while (iterator != liczba)
		{
			++i;
			if (i == help->SekCount)
				break;
			if (!help->arr[i]->deleted)
				iterator++;
		}
		if (i == -1)
			i++;
		return help->arr[i];
	}
	void add_tab() {
		if (sekHead == NULL) {
			SekcjaNode* nowa = new SekcjaNode;
			sekHead = nowa;
			sekTail = nowa;
			nowa->next = NULL;
			nowa->prev = NULL;
		}
		else if (sekTail->SekCount == T) {
			SekcjaNode* nowa = new SekcjaNode;
			sekTail->next = nowa;
			nowa->prev = sekTail;
			sekTail = nowa;
			nowa->next = NULL;
		}
	}
	void add_sek(char a) {
		add_tab();
		sekTail->add_sek(a);
	}
	void liczba_sekcji() {
		SekcjaNode* help;
		int suma = 0;
		help = sekHead;
		if (sekHead == nullptr)
			suma = 0;
		else {
			while (help != NULL)
			{
				suma += help->SekCount;
				suma -= help->DeletedCount;
				help = help->next;
			}
		}
		cout << "? == " << suma << endl;
	}
	void liczba_sel_sekcji(char* num) {
		Sekcja* help = znajdz_sekcje(num);
		if (help != NULL) {
			int wynik = 0;
			Selektor* helpSel = help->selHead;
			while (helpSel != NULL) {
				wynik++;
				helpSel = helpSel->next;
			}
			wypisz(num);
			cout << ",S,? == " << wynik << endl;
		}
	}
	void liczba_att_sekcji(char* num) {
		Sekcja* help = znajdz_sekcje(num);
		if (help != NULL) {
			int wynik = 0;
			Atrybut* helpAtt = help->attHead;
			while (helpAtt != NULL) {
				wynik++;
				helpAtt = helpAtt->next;
			}
			wypisz(num);
			cout << ",A,? == " << wynik << endl;
		}
	}
	void selektor_dla_sekcji(char* numSek, char* numSel) {
		int liczbaSel = atoi(numSel);
		Sekcja* help = znajdz_sekcje(numSek);
		if (help != NULL) {
			int iterator = 1;
			Selektor* helpSel = help->selHead;
			while (iterator != liczbaSel) {
				helpSel = helpSel->next;
				iterator++;
			}
			if (helpSel != NULL) {
				wypisz(numSek);
				cout << ",S," << liczbaSel << " == ";
				wypisz(helpSel->sel);
				cout << '\n';
			}
		}
	}
	void wart_atryb_dla_sekcji(char* numSek, char* nameAtryb) {
		Sekcja* help = znajdz_sekcje(numSek);
		if (help != NULL) {
			char* AttNam = new char[MAX];
			strncpy(AttNam, nameAtryb, MAX);
			Atrybut* helpAtt = help->attHead;
			while (helpAtt != nullptr) {
				if (!strncmp(helpAtt->name, AttNam, MAX)) {
					break;
				}
				helpAtt = helpAtt->next;
			}
			if (helpAtt != NULL) {
				wypisz(numSek);
				cout << ",A,";
				wypisz(nameAtryb);
				cout << " == ";
				wypisz(helpAtt->value);
				cout << endl;
			}
			delete[] AttNam;
		}
	}
	void wystapienia_selektora(char* selek) {
		SekcjaNode* help = sekHead;
		char* SelNam = new char[MAX];
		strncpy(SelNam, selek, MAX);
		int wynik = 0;
		while (help != NULL) {
			for (int i = 0; i < help->SekCount; i++) {
				if (help->arr[i]->deleted)
					continue;
				else {
					Selektor* helpSel = help->arr[i]->selHead;
					while (helpSel != NULL) {
						if (!strncmp(helpSel->sel, SelNam, MAX))
							wynik++;
						helpSel = helpSel->next;
					}
				}
			}
			help = help->next;
		}
		wypisz(SelNam);
		cout << ",S,? == " << wynik << '\n';
		delete[] SelNam;
	}
	void wystapienia_atrybutu(char* atryb) {
		SekcjaNode* help = sekHead;
		char* AttNam = new char[MAX];
		strncpy(AttNam, atryb, MAX);
		int wynik = 0;
		while (help != NULL) {
			for (int i = 0; i < help->SekCount; i++) {
				if (help->arr[i]->deleted)
					continue;
				else {
					Atrybut* helpAtt = help->arr[i]->attHead;
					while (helpAtt != NULL) {
						if (!strncmp(helpAtt->name, AttNam, MAX))
							wynik++;
						helpAtt = helpAtt->next;
					}
				}
			}
			help = help->next;
		}
		wypisz(AttNam);
		cout << ",A,? == " << wynik << '\n';
		delete[] AttNam;
	}
	void atrybut_dla_sel(char* selek, char* atryb) {
		SekcjaNode* help = sekTail;
		Sekcja* szukana = NULL;
		char* AttNam = new char[MAX];
		char* SelekNam = new char[MAX];
		strncpy(AttNam, atryb, MAX);
		strncpy(SelekNam, selek, MAX);
		bool escape = true;
		while (help != NULL && escape) {
			for (int i = help->SekCount - 1; i >= 0; i--) {
				if (!escape)
					break;
				else if (help->arr[i]->deleted)
					continue;
				else {
					Selektor* SelHelp = help->arr[i]->selHead;
					while (SelHelp != NULL) {
						if (!strncmp(SelHelp->sel, SelekNam, MAX)) {
							szukana = help->arr[i];
							escape = false;
							break;
						}
						SelHelp = SelHelp->next;
					}
				}
			}
			help = help->prev;
		}
		if (escape) {
			delete[] AttNam;
			delete[] SelekNam;
			return;
		}
		else {
			Atrybut* attHelp = szukana->attHead;
			while (attHelp != NULL) {
				if (!strncmp(attHelp->name, AttNam, MAX))
					break;
				attHelp = attHelp->next;
			}
			if (attHelp != NULL) {
				wypisz(SelekNam);
				cout << ",E,";
				wypisz(AttNam);
				cout << " == ";
				wypisz(attHelp->value);
				cout << endl;
			}
		}
	}
	void usun_sekcje(char* numSek) {
		SekcjaNode* help = sekHead;
		int liczba = atoi(numSek);
		int iterator = 0;
		while ((iterator + help->SekCount - help->DeletedCount) < liczba) {
			if (help->next == NULL)
				return;
			iterator += help->SekCount;
			iterator -= help->DeletedCount;
			help = help->next;
		}
		int i = -1;
		while (iterator != liczba)
		{
			i++;
			if (i == help->SekCount)
				break;
			if (!help->arr[i]->deleted)
				iterator++;
		}
		help->arr[i]->~Sekcja();
		help->DeletedCount++;
		if (help->DeletedCount == T)
		{
			if (help == sekHead && help == sekTail) {

				delete help;
				sekHead = nullptr;
				sekTail = nullptr;
			}
			else if (help == sekHead) {
				sekHead = help->next;
				help->next->prev = nullptr;
				delete help;
			}
			else if (help == sekTail) {
				sekTail = help->prev;
				help->prev->next = nullptr;
				delete help;
			}
			else {
				help->prev->next = help->next;
				help->next->prev = help->prev;
				delete help;
			}
		}
		wypisz(numSek);
		cout << ",D,* == deleted" << '\n';
	}
	void usun_atrybut(char* numSek, char* nameAtryb) {
		SekcjaNode* help = sekHead;
		int liczba = atoi(numSek);
		char* attNam = new char[MAX];
		strncpy(attNam, nameAtryb, MAX);
		int iterator = 0;
		while ((iterator + help->SekCount - help->DeletedCount) < liczba) {
			if (help->next == NULL) {
				delete[] attNam;
				return;
			}
			iterator += help->SekCount;
			iterator -= help->DeletedCount;
			help = help->next;
		}
		int i = -1;
		while (iterator != liczba)
		{
			i++;
			if (!help->arr[i]->deleted)
				iterator++;
		}
		Atrybut* helpAtt = help->arr[i]->attHead;
		while (helpAtt != NULL) {
			if (!strncmp(helpAtt->name, attNam, MAX)) {
				break;
			}
			helpAtt = helpAtt->next;
		}
		if (helpAtt == NULL) {
			delete[] attNam;
			return;
		}
		if (helpAtt == help->arr[i]->attHead && helpAtt == help->arr[i]->attTail) {
			help->arr[i]->~Sekcja();
			help->DeletedCount++;
			help->arr[i]->deleted = true;
			if (help->DeletedCount == T)
			{
				if (help == sekHead && help == sekTail) {
					sekHead = nullptr;
					sekTail = nullptr;
					delete help;
				}
				else if (help == sekHead) {
					sekHead = help->next;
					help->next->prev = nullptr;
					delete help;
				}
				else if (help == sekTail) {
					sekTail = help->prev;
					help->prev->next = nullptr;
					delete help;
				}
				else {
					help->prev->next = help->next;
					help->next->prev = help->prev;
					delete help;
				}
			}
		}
		else if (helpAtt == help->arr[i]->attHead) {
			helpAtt->next->prev = NULL;
			help->arr[i]->attHead = helpAtt->next;
			helpAtt->~Atrybut();
		}
		else if (helpAtt == help->arr[i]->attTail) {
			helpAtt->prev->next = NULL;
			help->arr[i]->attTail = helpAtt->prev;
			helpAtt->~Atrybut();
		}
		else {
			helpAtt->prev->next = helpAtt->next;
			helpAtt->next->prev = helpAtt->prev;
			helpAtt->~Atrybut();
		}
		wypisz(numSek);
		cout << ",D,";
		wypisz(nameAtryb);
		cout << " == deleted" << '\n';
		delete[] attNam;
	}
	void trybkomend() {
		char c;
		for (int i = 0; i < 3; i++)
			c = (char)getchar();
		while (c = (char)getchar()) {
			if (c == '\n')
				continue;
			else if (c == '?')
				liczba_sekcji();
			else if (c == '*') {
				for (int i = 0; i < 3; i++)
					c = (char)getchar();
				readd();
			}
			else if (c == EOF)
				exit(0);
			else {
				char* kom1 = new char[MAX];
				char kom2;
				char* kom3 = new char[MAX];
				int i = 1;
				strncpy(kom1, "", MAX);
				strncpy(kom3, "", MAX);
				kom1[0] = c;
				while (c = (char)getchar()) {
					if (c != ',' && c >= ' ') {
						kom1[i] = c;
						i++;
					}
					else
					{
						i = 0;
						break;
					}
				}
				kom2 = c = (char)getchar();
				c = (char)getchar();
				while (c = (char)getchar()) {
					if (c != '\n' && c != EOF) {
						kom3[i] = c;
						i++;
					}
					else if (c == ',')
						trybkomend();
					else {
						i = 0;
						break;
					}
				}
				if (isdigit(kom1[0]) != 0)
				{
					if (kom2 == 'A') {
						if (kom3[0] == '?')
							liczba_att_sekcji(kom1);
						else
							wart_atryb_dla_sekcji(kom1, kom3);
					}
					else if (kom2 == 'S') {
						if (kom3[0] == '?')
							liczba_sel_sekcji(kom1);
						else if (isdigit(kom3[0]) != 0)
							selektor_dla_sekcji(kom1, kom3);

					}
					else if (kom2 == 'D') {
						if (kom3[0] == '*')
							usun_sekcje(kom1);
						else
							usun_atrybut(kom1, kom3);
					}

				}
				else
				{
					if (kom2 == 'S') {
						if (kom3[0] == '?')
							wystapienia_selektora(kom1);
					}
					else if (kom2 == 'A') {
						if (kom3[0] == '?')
							wystapienia_atrybutu(kom1);
					}
					else if (kom2 == 'E')
						atrybut_dla_sel(kom1, kom3);

				}
				delete[] kom1;
				delete[] kom3;
			}
		}

	}
	void readd()
	{
		while (char c = (char)getchar())
		{
			if (c <= ' ')
				continue;
			if (c == '?')
				trybkomend();
			else if (c == EOF)
				exit(0);
			else
				add_sek(c);
		}
	}
};
int main() {
	css a;
	a.readd();
}