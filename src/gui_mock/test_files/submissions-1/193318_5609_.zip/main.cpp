#include <iostream>


#define BUFFOR_SIZE 32
#define ESSA_T 29

using namespace std;


struct commas
{
    int first;
    int second;
};

bool is_digit(char c)
{
    char digits[10] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

    for (int i = 0; i < 10; i++)
    {
        if (c == digits[i])   return true;
    }

    return false;
}

int to_int_char(char c)
{
    char digits[10] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

    for (int i = 0; i < 10; i++)
    {
        if (c == digits[i]) return i;
    }
    return -1;
}

class myString
{
private:
    char* str;
    int len;
public:
    myString()
    {
        str = nullptr;
        len = 0;
    }

    myString(const char* text)
    {
        len = 0;
        while (text[len] != '\0')
        {
            len++;
        }

        str = new char[len + 1];

        for (int i = 0; i < len; i++)
        {
            str[i] = text[i];
        }

        str[len] = '\0';
    }

    int get_len()
    {
        return len;
    }

    myString get_part(int begin, int end)
    {
        myString part;
        int length = end - begin;
        char* char_part = new char[length + 1];
        for (int i = 0; i < length; i++)
        {
            char_part[i] = str[begin + i];
        }
        char_part[length] = '\0';

        part = char_part;

        return part;
    }

    myString cut_white()
    {
        while (str[0] <= ' ' && len > 0)
        {
            *this = this->get_part(1, len);
        }
        while (str[len - 1] <= ' ' && len > 0)
        {
            *this = this->get_part(0, len - 1);
        }

        return *this;
    }

    commas find_commas()
    {
        commas indexes;
        int i = 0;
        for (i; i < len; i++)
        {
            if (str[i] == ',')
            {
                indexes.first = i;
                i++;
                break;
            }
        }
        for (i; i < len; i++)
        {
            if (str[i] == ',')
            {
                indexes.second = i;
                return indexes;
            }
        }

        indexes.first = -1;
        indexes.second = -1;
        return indexes;
    }

    bool contains(char c)
    {
        for (int i = 0; i < len; i++)
        {
            if (str[i] == c)
            {
                return true;
            }
        }

        return false;
    }

    bool is_number()
    {
        for (int i = 0; i < len; i++)
        {
            if (!is_digit(str[i])) return false;
        }

        return true;
    }

    int to_int()
    {
        int result = 0;
        int x = 1;
        for (int i = len - 1; i >= 0; i--)
        {
            result += x * to_int_char(str[i]);
            x *= 10;
        }

        return result;
    }

    char* get_str()
    {
        return str;
    }

    char operator[](int index) const
    {
        return str[index];
    }

    myString& operator=(const char* text)
    {

        str = nullptr;

        len = 0;
        while (text[len] != '\0')
        {
            len++;
        }

        str = new char[len + 1];


        for (int i = 0; i < len; i++)
        {
            str[i] = text[i];
        }

        str[len] = '\0';

        return *this;
    }

    myString& operator=(const myString& other)
    {
        if (this != &other)
        {
            delete[] str;
            len = other.len;
            str = new char[len + 1];
            for (int i = 0; i < len; ++i)
            {
                str[i] = other.str[i];
            }
            str[len] = '\0';
        }
        return *this;
    }

    myString& operator+=(const char* text)
    {
        int text_len = 0;
        while (text[text_len] != '\0')
        {
            text_len++;
        }

        char* temp = new char[len + 1];

        for (int i = 0; i < len; i++)
        {
            temp[i] = str[i];
        }
        temp[len] = '\0';

        delete[] str;

        str = new char[text_len + len + 1];

        for (int i = 0; i < len; i++)
        {
            str[i] = temp[i];
        }
        int j = 0;
        for (int i = len; i < (len + text_len); i++)
        {
            str[i] = text[j];
            j++;
        }

        len = text_len + len;
        str[len] = '\0';

        return *this;

    }

    bool operator==(const char* text)
    {
        int i = 0;
        while (str[i] != '\0' || text[i] != '\0')
        {
            if (str[i] != text[i])
            {
                return false;
            }
            i++;
        }
        return true;
    }

    bool operator==(const myString other)
    {
        int i = 0;
        while (str[i] != '\0' || other.str[i] != '\0')
        {
            if (str[i] != other.str[i])
            {
                return false;
            }
            i++;
        }
        return true;
    }

    friend ostream& operator<<(ostream& os, const myString& s)
    {
        for (int i = 0; i < s.len; i++)
        {
            //if(s.str[i] < 126 && s.str[i] >= 32)
            os << s.str[i];
        }
        return os;
    }
};

class selectorNode
{
public:
    myString selector;
    selectorNode* next;

    selectorNode(myString name)
    {
        selector = name;
        next = nullptr;
    }
};

class selectorsList
{
public:
    selectorNode* head;
    selectorNode* tail;

    selectorsList()
    {
        head = nullptr;
        tail = nullptr;
    }

    void add(myString name)
    {
        name.cut_white();
        selectorNode* newNode = new selectorNode(name);
        selectorNode* node = head;
        bool e = false;

        while (node != nullptr)
        {
            if (node->selector == name)
            {
                e = true;
                break;
            }
            node = node->next;
        }

        if (!e)
        {
            if (head == nullptr)
            {
                head = newNode;
                tail = newNode;
            }
            else
            {
                tail->next = newNode;
                tail = newNode;
            }
        }
    }
};

class attributeNode
{
public:
    myString name;
    myString value;
    attributeNode* next;

    attributeNode(myString new_name, myString new_value)
    {
        name = new_name;
        value = new_value;
        next = nullptr;
    }
};

class attributesList
{
public:
    attributeNode* head;
    attributeNode* tail;

    attributesList()
    {
        head = nullptr;
        tail = nullptr;
    }

    void add(myString name, myString value)
    {
        name.cut_white();
        value.cut_white();
        attributeNode* newNode = new attributeNode(name, value);


        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            attributeNode* node = head;

            while (node != nullptr)
            {
                if (node->name == newNode->name)
                {
                    node->value = newNode->value;
                    break;
                }

                node = node->next;
            }


            if (node == nullptr)
            {
                tail->next = newNode;
                tail = newNode;
            }

        }
    }
};

struct sect
{
    bool taken = false;
    selectorsList selectors;
    attributesList attributes;
};

sect create_section(selectorsList selectors_list, attributesList attributes_list)
{
    sect section;
    section.selectors = selectors_list;
    section.attributes = attributes_list;
    section.taken = true;

    return section;
}

class mainListNode
{
public:
    sect section[ESSA_T];
    int index;
    int counter;
    mainListNode* next;
    mainListNode* prev;


    mainListNode(mainListNode* previous)
    {
        index = 0;
        counter = 0;
        next = nullptr;
        prev = previous;

    }

    void add_section(sect new_section)
    {
        section[index] = new_section;
        index++;
        counter++;
    }

};

selectorsList create_selectorsList(myString string_selectors)
{
    selectorsList selectors;
    int begin = 0;

    string_selectors.cut_white();

    if (string_selectors == "") return selectors;

    for (int i = 0; i < (string_selectors.get_len()); i++)
    {
        if (string_selectors[i] == ',')
        {
            selectors.add(string_selectors.get_part(begin, i));
            begin = i + 1;
        }
        else
        {
            if (i == string_selectors.get_len() - 1)
            {
                selectors.add(string_selectors.get_part(begin, i + 1));
            }
        }
    }

    return selectors;
}

attributesList create_attributesList(myString string_attributes)
{
    attributesList attributes;
    int name_begin = 0;
    int name_end = 0;


    for (int i = 0; i < (string_attributes.get_len()); i++)
    {
        if (string_attributes[i] == ':')
        {
            name_end = i;
        }
        else
        {
            if (string_attributes[i] == ';')
            {
                attributes.add(string_attributes.get_part(name_begin, name_end), string_attributes.get_part(name_end + 1, i));
                name_begin = i + 1;
            }
            else
            {
                if (i == string_attributes.get_len() - 1 && string_attributes.get_part(name_begin, i).contains(':'))
                {
                    attributes.add(string_attributes.get_part(name_begin, name_end), string_attributes.get_part(name_end + 1, i));
                    name_begin = i + 1;
                }
            }
        }
    }

    return attributes;
}

struct section_pointer
{
    mainListNode* node;
    int index;
};

class mainList
{
public:
    mainListNode* head;
    mainListNode* tail;
    int counter;
    int node_counter;

    mainList()
    {
        head = nullptr;
        tail = nullptr;
        counter = 0;
        node_counter = 0;
    }

    void add_node()
    {
        mainListNode* newNode = new mainListNode(tail);

        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        node_counter++;
    };

    void add_section(sect new_section)
    {

        if (tail == nullptr || tail->index == (ESSA_T))
        {
            add_node();
        }

        tail->add_section(new_section);
        counter++;
    }

    mainListNode* get_node(int index)
    {
        int node_id = 0;
        mainListNode* node_pointer = head;

        while (node_id < index)
        {
            node_pointer = node_pointer->next;
            node_id++;
        }

        return node_pointer;
    }


    section_pointer get_section(int index)
    {
        mainListNode* node_pointer = head;
        section_pointer section;


        int checked = head->counter;
        int taken_counter = 0;
        int inside_id = index - 1;



        while (checked < index)
        {
            node_pointer = node_pointer->next;
            inside_id = index - checked - 1;
            checked += node_pointer->counter;
        }



        section.node = node_pointer;

        for (int i = 0; i < ESSA_T; i++)
        {
            if (node_pointer->section[i].taken)
            {
                if (inside_id == taken_counter)
                {
                    section.index = i;
                    break;
                }

                taken_counter++;
            };
        }


        return section;
    }
};

void clear_input_text(char* input_text)
{
    for (int i = 0; i < BUFFOR_SIZE; i++)
    {
        if (input_text[i] != '\0')
            input_text[i] = '\0';
        else
            break;
    }
}

struct commandSections
{
    myString first;
    myString second;
    myString third;
};

commandSections parse_command(myString command)
{
    commas indexes;
    indexes = command.find_commas();

    commandSections command_sections;
    command_sections.first = command.get_part(0, indexes.first);
    command_sections.second = command.get_part(indexes.first + 1, indexes.second);
    command_sections.third = command.get_part(indexes.second + 1, command.get_len());

    return command_sections;
}

int command_recognition(myString command)
{

    if (command == "****") return 0;
    if (command == "?") return 1;

    commandSections command_sections;
    command_sections = parse_command(command);


    if (command_sections.second == "S")
    {
        if (command_sections.first.is_number())
        {
            if (command_sections.third == "?") return 2;
            return 3;
        }

        return 4;
    }

    if (command_sections.second == "A")
    {
        if (command_sections.first.is_number())
        {
            if (command_sections.third == "?") return 5;
            return 6;
        }

        return 7;
    }


    if (command_sections.second == "D")
    {
        if (command_sections.third == "*") return 8;
        return 9;
    }


    if (command_sections.second == "E") return 10;


    return -1;
}

int count_selectors(sect* section)
{
    if (section->selectors.head == nullptr) return 0;

    int counter = 1;

    selectorNode* node = section->selectors.head;

    while (node != section->selectors.tail)
    {
        node = node->next;
        counter++;
    }

    return counter;
}

void print_selector(sect* section, int selector_index, commandSections parsed_command)
{
    if (section->selectors.head == nullptr) return;
    int counter = 0;

    selectorNode* node = section->selectors.head;

    while (node != nullptr)
    {
        counter++;
        if (counter == selector_index)
        {
            cout << parsed_command.first << ",S," << parsed_command.third << " == ";
            cout << node->selector;
            cout << "\n";
            break;
        }
        node = node->next;
    }
}

int count_selectors(sect* section, myString selector_name)
{
    if (section->selectors.head == nullptr) return 0;

    int counter = 0;

    selectorNode* node = section->selectors.head;

    while (node != section->selectors.tail)
    {
        if (node->selector == selector_name) counter++;
        node = node->next;
    }

    if (node->selector == selector_name) counter++;

    return counter;
}

int count_all_selectors(mainList* list, myString selector_name)
{
    if (list->counter == 0) return 0;

    int selectors_counter = 0;
    bool t = true;

    mainListNode* node = list->head;

    do
    {
        for (int i = 0; i < ESSA_T; i++)
        {
            t = *(&node->section[i].taken);
            if (t)
            {
                selectors_counter += count_selectors(&node->section[i], selector_name);
            }
        }

        node = node->next;
    } while (node != nullptr);

    return selectors_counter;
}

int count_attributes(sect* section)
{
    if (section->attributes.head == nullptr) return 0;

    int counter = 1;

    attributeNode* node = section->attributes.head;

    while (node != section->attributes.tail)
    {
        node = node->next;
        counter++;
    }

    return counter;
}

myString attribute_value(sect* section, myString attribute_name)
{
    if (section->attributes.head == nullptr) return "";

    attributeNode* node = section->attributes.head;

    while (node != nullptr)
    {
        if (node->name == attribute_name)
        {

            return node->value;
        }
        node = node->next;
    }

    return "";
}

char* attribute_value_1(sect* section, myString attribute_name)
{
    if (section->attributes.head == nullptr) return nullptr;

    attributeNode* node = section->attributes.head;

    while (node != nullptr)
    {
        if (node->name == attribute_name)
        {

            return node->value.get_str();
        }
        node = node->next;
    }

    return nullptr;
}

int count_attributes(sect* section, myString attribute_name)
{
    if (section->attributes.head == nullptr) return 0;

    int counter = 0;

    attributeNode* node = section->attributes.head;

    while (node != section->attributes.tail)
    {
        if (node->name == attribute_name) counter++;
        node = node->next;
    }

    if (node->name == attribute_name) counter++;

    return counter;
}

int count_all_attributes(mainList* list, myString selector_name)
{
    if (list->counter == 0) return 0;

    int attributes_counter = 0;
    bool t = true;

    mainListNode* node = list->head;

    do
    {
        for (int i = 0; i < ESSA_T; i++)
        {
            t = *(&(node)->section[i].taken);
            if (t)   attributes_counter += count_attributes(&node->section[i], selector_name);
        }

        node = node->next;
    } while (node != nullptr);

    return attributes_counter;
}

bool delete_section(mainList* list, int index)
{
    if (list->counter < index || index < 1)
        return false;

    section_pointer section = list->get_section(index);

    section.node->section[section.index].taken = 0;
    list->counter--;
    section.node->counter--;
    return true;
}

bool delete_attribute(mainList* list, int index, myString attribute_name)
{
    if (list->counter < index || index < 1)
        return false;

    section_pointer section = list->get_section(index);

    attributeNode* node = section.node->section[section.index].attributes.head;
    attributeNode* prev_node = nullptr;
    int counter = 1;
    int attributes_number = count_attributes(&section.node->section[section.index]);

    while (node != nullptr)
    {
        if (node->name == attribute_name)
        {
            if (attributes_number == 1)
            {
                return delete_section(list, index);;
            }
            else
            {
                if (counter == 1)
                {
                    section.node->section[section.index].attributes.head = node->next;
                    return true;
                }
                else
                {
                    if (counter == attributes_number)
                    {
                        section.node->section[section.index].attributes.tail = prev_node;
                        prev_node->next = nullptr;
                        return true;
                    }
                    else
                    {
                        prev_node->next = node->next;
                        return true;
                    }
                }
            }
        }

        prev_node = node;
        node = node->next;
        counter++;
    }

    return false;

}

myString attribute_value(mainList* list, myString attribute_name, myString selector_name)
{
    myString value = "";
    for (int i = 0; i < list->node_counter; i++)
    {
        for (int j = 0; j < ESSA_T; j++)
        {
            if (&list->get_node(i)->section[j] != nullptr && *(&list->get_node(i)->section[j].taken) && (count_selectors(&list->get_node(i)->section[j], selector_name) > 0))
            {
                value = attribute_value(&list->get_node(i)->section[j], attribute_name);
            }
        }
    }

    return value;
}



void command_1(mainList* list, myString command)
{
    cout << "? == ";
    cout << list->counter;
    cout << "\n";
}

void command_2(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    int first = parsed_command.first.to_int();
    if (first > list->counter) return;

    section_pointer section = list->get_section(first);

    cout << parsed_command.first << ",S,? == ";


    cout << count_selectors(&section.node->section[section.index]);

    cout << "\n";
}

void command_3(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    int first = parsed_command.first.to_int();
    int third = parsed_command.third.to_int();

    if (first > list->counter) return;

    section_pointer section = list->get_section(first);

    print_selector(&section.node->section[section.index], third, parsed_command);
}

void command_4(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);


    cout << parsed_command.first << ",S,? == ";
    cout << count_all_selectors(list, parsed_command.first);
    cout << "\n";
}

void command_5(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    int first = parsed_command.first.to_int();
    if (first > list->counter) return;

    section_pointer section = list->get_section(first);

    int counted = 0;
    counted = count_attributes(&section.node->section[section.index]);

    if (counted > 0)
    {
        cout << parsed_command.first << ",A,? == ";
        cout << counted;
        cout << "\n";
    }
}

void command_6(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    int first = parsed_command.first.to_int();
    if (first > list->counter) return;

    section_pointer section = list->get_section(first);

    myString value = "";
    value = attribute_value(&section.node->section[section.index], parsed_command.third);
    //attribute_value_1(&section.node->section[section.index], parsed_command.third);

    if (!(value == ""))
    {
        cout << parsed_command.first << ",A," << parsed_command.third << " == ";
        cout << value;
        cout << "\n";
    }
}

void command_7(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    cout << parsed_command.first << ",A,? == ";
    cout << count_all_attributes(list, parsed_command.first);
    cout << "\n";
}

void command_8(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);
    int first = parsed_command.first.to_int();
    bool deleted = false;


    deleted = delete_section(list, first);

    if (deleted)
    {
        cout << parsed_command.first << ",D,* == ";
        cout << "deleted";
        cout << "\n";
    }
}

void command_9(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    int first = parsed_command.first.to_int();


    if (delete_attribute(list, first, parsed_command.third))
    {
        cout << parsed_command.first << ",D," << parsed_command.third << " == ";
        cout << "deleted";
        cout << "\n";
    }


}

void command_10(mainList* list, myString command)
{
    commandSections parsed_command = parse_command(command);

    myString value = attribute_value(list, parsed_command.third, parsed_command.first);

    if (!(value == ""))
    {
        cout << parsed_command.first << ",E," << parsed_command.third << " == ";
        cout << value;
        cout << "\n";
    }
}

bool commands(mainList* list)
{
    myString input_string;
    char* input_text = new char[BUFFOR_SIZE];
    clear_input_text(input_text);
    char c = ' ';
    int command_id;
    int i = 0;

    while (c != EOF)
    {
        c = getchar();
        if (c == 10 || c == EOF)
        {
            input_string += input_text;
            clear_input_text(input_text);
            i = 0;
            command_id = command_recognition(input_string);

            switch (command_id)
            {
            case 0:
                return false;
                break;
            case 1:
                command_1(list, input_string);
                break;
            case 2:
                command_2(list, input_string);
                break;
            case 3:
                command_3(list, input_string);
                break;
            case 4:
                command_4(list, input_string);
                break;
            case 5:
                command_5(list, input_string);
                break;
            case 6:
                command_6(list, input_string);
                break;
            case 7:
                command_7(list, input_string);
                break;
            case 8:
                command_8(list, input_string);
                break;
            case 9:
                command_9(list, input_string);
                break;
            case 10:
                command_10(list, input_string);
                break;
            default:
                break;
            }

            input_string = "";
        }
        else
        {
            if (i == BUFFOR_SIZE - 1)
            {
                input_string += input_text;
                clear_input_text(input_text);
                i = 0;
            }
            input_text[i] = c;
            i++;
        }
    }

    return true;
}

void input(mainList* list)
{
    myString input_string;
    sect section;
    char* input_text = new char[BUFFOR_SIZE];
    clear_input_text(input_text);

    bool flag = false;
    int i = 0;
    char c = ' ';

    while (c != EOF)
    {
        c = getchar();


        if (c == '{')
        {
            input_string += input_text;
            section.selectors = create_selectorsList(input_string);
            input_string = "";

            clear_input_text(input_text);
            i = 0;
        }
        else
        {
            if (c == '}')
            {
                input_string += input_text;
                section.attributes = create_attributesList(input_string);
                input_string = "\0";
                clear_input_text(input_text);
                i = 0;

                section.taken = true;
                list->add_section(section);
            }
            else
            {
                if (c == '?')
                {
                    int ctr = 1;
                    for (int j = 0; j < 3; j++)
                    {
                        c = getchar();
                        if (c == '?')
                        {
                            if (i == BUFFOR_SIZE - 1)
                            {
                                input_string += input_text;
                                clear_input_text(input_text);
                                i = 0;
                            }
                            ctr++;
                        }
                        else break;
                    }
                    if (ctr == 4)
                    {
                        c = getchar();
                        input_string = "\0";
                        flag = commands(list);
                        if (flag) break;
                    }
                }

                if (i == BUFFOR_SIZE - 1)
                {
                    input_string += input_text;
                    clear_input_text(input_text);
                    i = 0;
                }
                input_text[i] = c;
                i++;

            }
        }

    }
}

int main()
{

    mainList lista;
    sect section;
    selectorsList select;
    attributesList attr;

    lista.add_node();
    lista.add_section(create_section(select, attr));
    lista.add_section(section);
    cout << "";

    mainList css;

    input(&css);

    cout << "";

    return 0;
}