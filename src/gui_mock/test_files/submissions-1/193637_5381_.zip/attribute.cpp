#include "attribute.h"

Attribute::Attribute()
{
	deleted = false;
}

Custom_string Attribute::getName()
{
	return name;
}

Custom_string Attribute::getValue()
{
	return value;
}

std::ostream& operator<<(std::ostream& os, Attribute& s)
{
	os << "Nazwa: " << s.name << " Wartosc: " << s.value;
	return os;
}

Attribute::~Attribute()
{
}

