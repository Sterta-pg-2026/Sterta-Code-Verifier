#include "attributenode.h"

AttributeNode::AttributeNode()
{
	next = nullptr;
	prev = nullptr;
}

std::ostream& operator<<(std::ostream& os, Attribute a)
{
	os << a.name << " : " << a.value;
	return os;
}

AttributeNode::~AttributeNode()
{

}