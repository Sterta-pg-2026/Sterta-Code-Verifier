#pragma once

#include "custom_string.h"

class Attribute
{
	public:
		Custom_string name;
		Custom_string value;
		bool deleted;
		Attribute();
		Attribute(Custom_string name, Custom_string value) : name(name), value(value) {}
		Custom_string getName();
		Custom_string getValue();
		friend std::ostream& operator<<(std::ostream& os, Attribute& s);
		~Attribute();
};

