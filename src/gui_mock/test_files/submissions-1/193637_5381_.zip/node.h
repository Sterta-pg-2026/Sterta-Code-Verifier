#pragma once
#include "custom_string.h"
#include "section.h"
#define T 19
class Node
{
    public:
        short int removed;
        short int size=0;
        Section* data;
        Node* prev;
        Node* next;
        Node();
        Node(Section s);
        //void add(Section val);
        friend std::ostream& operator<<(std::ostream& os, const Node& node);
        ~Node();
};

