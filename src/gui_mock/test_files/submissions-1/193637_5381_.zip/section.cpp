#include "section.h"

Section::Section()
{
	deleted = false;
}

//Section& Section::operator=(const Section& other) {
//    if (this != &other) {
//        // skopiuj pola z obiektu other do obiektu this
//        // uyj operatora przypisania dla kadego pola
//    }
//    return *this;
//}

//std::ostream& operator<<(std::ostream& os, Section& a)
//{
//	os << "Sekcja:\n";
//	for (int i = 0; i < a.AttrList.size; i++)
//	{
//		SelectorNode* seleNode = a.SeleList.head;//<------ ?!?!?!?!?!? ...
//		for (int k =0; k<a.SeleList.size; k++)
//			os << seleNode->value.name << ":\n";
//		seleNode = seleNode->next;
//		AttributeNode* attrNode = a.AttrList.head;
//		for (int j = 0; j < a.AttrList.size; j++)
//		{
//			os << '\t'<<  attrNode->value.name << ':' << attrNode->value.value << '\n';
//			attrNode = attrNode->next;
//		}
//	}
//	return os;
//}



std::ostream& operator<<(std::ostream& os, Section& a)
{
	AttributeList attrlist = a.AttrList;
	AttributeNode* attrnode= attrlist.head;
	SelectorList selelist = a.SeleList;
	SelectorNode* selenode = selelist.head;
	for (int i = 0; i < selelist.size; i++)
	{
		os << selenode->value.name << ' ';
		selenode = selenode->next;
	}
	os << ':';
	for (int i = 0; i < attrlist.size; i++)
	{
		os << "\n\t" << attrnode->value.name << ':' << attrnode->value.value;
		attrnode = attrnode->next;
	}
	return os;
}

Section& Section::operator=(const Section& a)
{
	if (this != &a) {
		AttrList = a.AttrList;
		SeleList = a.SeleList;
	}
	return *this;
}

void Section::push_back(AttributeList Attr, SelectorList Sele)
{
	AttrList = Attr;
	SeleList = Sele;
}

void Section::clear()
{
	AttrList.clear();
	SeleList.clear();
}



Section::~Section()
{

}