#include "attributelist.h"

AttributeList::AttributeList()
{
    head = nullptr;
    tail = nullptr;
    size = 0;
}

bool AttributeList::doesExist(Custom_string attr_name)
{
    AttributeNode* node = head;
    for (int i = 0; i < size; i++)
    {
        if (node->value.name == attr_name)
            return true;
        node = node->next;
    }
    return false;
}

void AttributeList::addElement(AttributeNode Node)
{
    if (head == nullptr)
    {
        AttributeNode* temp = new AttributeNode;
        temp->value = Node.value;//????
        temp->next = nullptr;
        temp->prev = nullptr;
        head = temp;
        tail = temp;
    }
    else
    {
        AttributeNode* current = head;
        while (current->next != nullptr)
        {
            current = current->next;
        }
        current->next = new AttributeNode;
        current->next->prev = current;
        current->next->value.name = Node.value.name;
        current->next->value.value = Node.value.value;
        tail = current;
    }
    size++;
}

void AttributeList::insert(Custom_string name, Custom_string value)
{
    AttributeNode Node;
    Attribute attr;
    attr.name = name;
    attr.value = value;
    AttributeNode* node = head;
    for (int i = 0; i < size; i++)
    {
        if (node->value.name == name)
        {
            node->value.value = value;
            return;
        }
        node = node->next;
    }
    Node.value = attr;
    addElement(Node);
}

void AttributeList::printList()
{
    AttributeNode* Node = head;
    std::cout << "\nLista atrybutow:";
    for (int i = 0; i < size; i++)
    {
        std::cout << '\t' << i << ':';
        std::cout << Node->value.name << " == " << Node->value.value << '\n';
        Node = Node->next;
    }
}

void AttributeList::clear()
{
    AttributeNode* current = head;
    while (current != nullptr)
    {
        AttributeNode* temp = current;
        current = current->next;
        temp = nullptr;
        //delete temp;
    }
    size = 0;
    head = nullptr;
    tail = nullptr;
}

AttributeList::~AttributeList()
{
}
