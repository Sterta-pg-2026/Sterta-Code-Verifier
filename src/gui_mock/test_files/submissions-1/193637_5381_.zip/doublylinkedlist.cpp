#include "doublylinkedlist.h"

DoublyLinkedList::DoublyLinkedList()
{
	head = nullptr;
	tail = nullptr;
	size = 0;
}

void DoublyLinkedList::push_back(Section section)
{
	Node* node = new Node();
	if (head == nullptr)
	{
		node->size++;
		node->data[0] = section;
		head = node;
		head->next = tail;
		tail = node;
		tail->next = nullptr; //!!!
		tail->prev = head;
		size++;
	}
	else
	{
		node = head;
		bool added = false;
		while (!added)
		{
			if (node->size < T)
			{
				node->data[node->size] = section;
				node->size++;
				added = true;
				/*if (node->size == T && tail==head)
				{
					Node* temp = new Node();
					temp->data[0] = section;
					node->size++;
					temp->prev = tail;
					tail->next = temp;
					tail=temp;
					added = true;
				}*/
			}
			else
			{
				if(node->next!=nullptr)
					node = node->next;
				else
				{
					node = new Node();
					node->data[0] = section;
					node->size++;
					tail->next = node;
					node->prev = tail;
					tail = node;
					size++;
					added = true;
				}
			}

		}
		if(head->prev!=nullptr)
			head->prev = nullptr;
	}
}


void DoublyLinkedList::printList()
{
	std::cout << "\nLista:";
	if (head == nullptr)
		return;
	Node* node = head;
	Section section;
	AttributeList attrlist;
	SelectorList selelist;
	SelectorNode* selenode;
	AttributeNode* attrnode;
	for (int i = 0; i < size; i++)//wypisywanie node
	{
		std::cout << "\nNode["<<i<<"]";
		for (int j = 0; j < node->size; j++)//wypisanie sekcji
		{
			std::cout << "\n\nSekcja " << j+1 << ".\n";
			section = node->data[j];
			selelist = section.SeleList;
			attrlist = section.AttrList;
			selenode = selelist.head;
			attrnode = attrlist.head;
			std::cout << '\n';
			for (int k = 0; k < selelist.size; k++)//wypisywanie selektorów
			{
				std::cout << selenode->value.name;
				if (k != selelist.size-1)
					std::cout << ',';
				selenode = selenode->next;
			}
			for (int k = 0; k < attrlist.size; k++)//wypisywanie atrybutów
			{
				if (!attrnode->value.deleted)
				{
					std::cout << '\n' << attrnode->value.name << ':' << attrnode->value.value;
				}
				attrnode = attrnode->next;
			}
		}
		node = node->next;
	}
}


bool DoublyLinkedList::isSectionDeleted(int index)
{
	if (index > sectionsCount())
		return true;
	index--;
	Node* node = head;
	while (index >= (node->size - node->removed)) //znajduje node w ktorym jest ta sekcja
	{
		index -= (node->size - node->removed);
		node = node->next;
	}
	if (node->removed != 0)
	{
		for (int i = 0; i <= index; i++)
		{
			if (node->data[i].deleted)
				index++;
		}
	}
	
	if (node->data[index].deleted)
		return true;
	return false;
}

bool DoublyLinkedList::isAttributeDeleted(int index, Custom_string attribute_name)
{

	if (index > sectionsCount())
		return true;
	index--;


	Node* node = head;
	while (index >= (node->size - node->removed)) //znajduje node w ktorym jest ta sekcja
	{
		index -= (node->size - node->removed);
		node = node->next;
	}
	if (node->removed != 0)//korekta indeksu po usuniętych
	{
		for (int i = 0; i <= index; i++)
		{
			if (node->data[i].deleted)
				index++;
		}
	}

	Section section = node->data[index];
	AttributeNode* attrnode = section.AttrList.head;
	for (int i = 0; i < section.AttrList.size; i++)
	{
		if (attrnode->value.name == attribute_name)
		{
			if (attrnode->value.deleted)
				return true;
		}
		attrnode = attrnode->next;
	}

	return false;
}

bool DoublyLinkedList::shouldSectionBeDeleted(AttributeList List)
{
	int counter = 0;
	AttributeNode* node = List.head;
	for (int i = 0; i < List.size; i++)
	{
		if (node->value.deleted)
			counter++;
		node = node->next;
	}
	if (counter == List.size)
		return true;
	return false;
}

int DoublyLinkedList::sectionsCount()
{
	int counter = 0;
	Node* temp= head;
	while (temp != nullptr)
	{
		counter += (temp->size-temp->removed);
		temp = temp->next;
	}/*
	if (counter == 706)
		counter++;*/
	return counter;
}

int DoublyLinkedList::selectorsInSection(int i)
{
	int counter=0;
	Node* temp = head;

	if (i>this->sectionsCount())
		return -1;

	//throw; ///!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	i--;

	if (head == nullptr)
		return -1;//?
	if (i < 0)
		return - 1;
	else
	{
		while (i >= (temp->size - temp->removed)) //znajduje node w ktorym jest ta sekcja (i-1?)
		{
			i -= (temp->size - temp->removed);
			temp = temp->next;
			if (temp->size - temp->removed != 0)
				continue;
		}
		
		if (temp->removed != 0)//korekta indeksu po usuniętych
		{
			for (int k = 0; k <= i; k++)
			{
				if (temp->data[i].deleted)
					i++;
			}
		}
		SelectorList selTemp = temp->data[i].SeleList;
		counter += selTemp.size;
	}
	return counter;
}



int DoublyLinkedList::attributesInSection(int i)
{
	int counter = 0;
	Node* temp = head;


	if (i > this->sectionsCount()) //chyba taka kolejnosc
		return -1;

	i--; 

	if (i < 0)
		return -1;
	else
	{
		while (i >= (temp->size - temp->removed)) //znajduje node w ktorym jest ta sekcja
		{
			i -= (temp->size - temp->removed);
			temp = temp->next;
		}

		if (temp->removed != 0)//korekta indeksu po usuniętych
		{
			for (int k = 0; k <= i; k++)
			{
				if (temp->data[k].deleted)
					i++;
			}
		}

		AttributeList attrTemp = temp->data[i].AttrList;
		AttributeNode* node = attrTemp.head;
		//counter += attrTemp.size - attrTemp.removed;
		for (int j = 0; j < attrTemp.size;j++)
		{
			if (!node->value.deleted)
			{
				counter++;
			}
			node = node->next;
		}
		//dostac sie do sekcji, sprawdajac kolejno czy zadna nie jest usunieta
		//dodac do countera temp->data[i].SeleList.size;
	}
	return counter;
}


Custom_string DoublyLinkedList::selectorByIndexAndSection(int selector, int section)
{
	Custom_string selector_name;
	int counter = 0;
	Node* temp = head;
	if (section > this->sectionsCount())
		return "";
	section--;
	selector--;
	if (section < 0)
		return "";
	else
	{
		while (section >= (temp->size - temp->removed)) //znajduje node w ktorym jest ta sekcja
		{
			section -= (temp->size - temp->removed);
			temp = temp->next;
		}
		SelectorList list = temp->data[section].SeleList;
		SelectorNode* sele = list.head;
		if (selector+1 > list.size)
			return "";
		for (int i = 0; i < selector; i++)
		{
			sele = sele->next;
		}
		selector_name = sele->value.name;
	}
	return selector_name;
}

Custom_string DoublyLinkedList::valueBySectionAndName(int section, Custom_string name)
{
	Custom_string value="";
	if (section > this->sectionsCount())
		return "";
	section--;
	if (section < 0)
		return "";
	else
	{
		Node* temp = head;
		while (section >= (temp->size - temp->removed)) //znajduje node w ktorym jest ta sekcja
		{
			section -= (temp->size - temp->removed);
			temp = temp->next;
		}
		if (temp->removed != 0)//korekta indeksu po usuniętych
		{
			for (int k = 0; k <= section; k++)
			{
				if (temp->data[section].deleted)
					section++;
			}
		}
		AttributeList list = temp->data[section].AttrList;
		AttributeNode* attr = list.head;
		for (int i = 0; i<list.size; i++)
		{
			if (!attr->value.deleted && attr->value.name == name)
				value = attr->value.value;
			attr=attr->next;
		}
	}

	return value;
}

int DoublyLinkedList::countAttributeOccurances(Custom_string name)
{
	int counter = 0;
	if (size == 0)
		return counter;
	Node* node = head;
	AttributeList lista;
	AttributeNode* attrnode;
	for (int k = 0; k < size; k++)
	{
		for (int i = 0; i < node->size; i++)
		{
			lista = node->data[i].AttrList;
			attrnode= lista.head;
			for (int j = 0; j < lista.size; j++)
			{
				if (!attrnode->value.deleted && attrnode->value.name == name)
					counter++;
				attrnode = attrnode->next;
			}
		}
		node = node->next;
	}
	return counter;
}


int DoublyLinkedList::countSelectorOccurances(Custom_string name)
{
	int counter = 0;

	if (size == 0)
		return counter;

	Node* node = head;
	SelectorList lista;
	SelectorNode* selenode;
	for (int k = 0; k < size; k++)
	{
		for (int i = 0; i < node->size; i++)
		{
			lista = node->data[i].SeleList;
			selenode = lista.head;
			for (int j = 0; j < lista.size; j++)
			{
				if (selenode->value.name == name)
					counter++;
				selenode = selenode->next;
			}
		}
		node = node->next;
	}

	return counter;
}

Custom_string DoublyLinkedList::attributeValueBySelector(Custom_string attribute_name, Custom_string selector_name)
{
	Custom_string value="";

	if (head == nullptr)
		return value;
	Node* node = tail;
	Section section;
	for (int j = 0; j < size; j++)
	{
		for (int i = node->size-1; i >= 0; i--)
		{
			section = node->data[i];
			SelectorNode* selenode = section.SeleList.head;
			for (int k = 0; k < section.SeleList.size; k++)
			{
				if (selenode->value.name == selector_name)
				{
					AttributeNode* attrnode = section.AttrList.head;
					for (int z = 0; z < section.AttrList.size; z++)
					{
						if (attrnode->value.name == attribute_name && !attrnode->value.deleted)
						{
							value = attrnode->value.value;
							return value;
						}
						attrnode = attrnode->next;
					}
				}
				selenode = selenode->next;
			}
		}
		node = node->prev;
	}
	return value;
}

void DoublyLinkedList::deleteSectionByIndex(int index)
{
	if (index > sectionsCount())
		return;
	index--;
	Node* node = head;
	while (index>=(node->size-node->removed)) //znajduje node w ktorym jest ta sekcja
	{
		index -= (node->size - node->removed);
		node = node->next;
	}
	if (node->removed != 0)
	{
		for (int i = 0; i < index; i++)
		{
			if (node->data[i].deleted)
				index++;
		}
	}
	node->data[index].clear();
	node->data[index].deleted = true;
	node->removed++;
}

void DoublyLinkedList::deleteAttributeByNameAndIndex(int index, Custom_string attribute_name)
{
	int main_index = index;
	index--;

	if (index > sectionsCount())
		return;

	Node* node = head;
	while (index >= (node->size - node->removed)) //znajduje node w ktorym jest ta sekcja
	{
		index -= (node->size - node->removed);
		node = node->next;
	}
	if (node->removed != 0)//korekta indeksu po usuniętych
	{
		for (int i = 0; i <= index; i++)
		{
			if (node->data[i].deleted)
				index++;
		}
	}

	Section section = node->data[index];
	AttributeNode* attrnode = section.AttrList.head;
	for (int i = 0; i < section.AttrList.size; i++)
	{
		if (attrnode->value.name == attribute_name)
		{
			attrnode->value.deleted = true;
			//attrnode->value.value = "deleted";
			section.AttrList.removed++;
			if (shouldSectionBeDeleted(section.AttrList))
				deleteSectionByIndex(main_index);
			return;
		}
		attrnode = attrnode->next;
	}

}


