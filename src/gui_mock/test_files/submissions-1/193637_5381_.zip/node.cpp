#include "node.h"
#include <iostream>

Node::Node()
    {
        data = new Section[T];
        removed = 0;
        prev = nullptr;
        next = nullptr;
    }

Node::Node(Section s)
{
    if (data == nullptr)
        data = new Section[T];
    removed = 0;
    data[size++] = s;
    prev = nullptr;
    next = nullptr;
}

//
//void Node::add(Section S)
//{
//    if (current_size < T - 1)
//    {
//        data[current_size] = ;
//        current_size++;
//        next = nullptr;
//        prev = nullptr;
//    }
//}
//
//size_t Node::getSize()
//{
//    return current_size;
//}

std::ostream& operator<<(std::ostream& os, const Node& node)
{
    for (int i = 0; i < T; i++)
    {
        os << node.data[i] << ' ';
    }
    return os;
}


Node::~Node()
{

}