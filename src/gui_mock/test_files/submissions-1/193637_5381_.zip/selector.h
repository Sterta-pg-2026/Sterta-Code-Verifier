#pragma once
#include "custom_string.h"
class Selector
{
	public:
		Custom_string name;
		Selector();
		Custom_string getName();
		///void insert(Custom_string string);
		friend std::ostream& operator<<(std::ostream& os,const Selector& s);
		~Selector();
};

