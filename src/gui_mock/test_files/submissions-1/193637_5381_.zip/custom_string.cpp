#include "custom_string.h"
#include <iostream>

Custom_string::Custom_string() : tab(nullptr), size(0) {}

Custom_string::Custom_string(const char* temp)
{
    /*if (this->tab == nullptr)
    {
        this->size = 0;
        this->tab = new char[1];
        this->tab[0] = '\0';
    }
    else
    {*/
    this->size = strlen(temp);
    this->tab = new char[size];
    for (int i = 0; i < size; i++)
    {
        this->tab[i] = temp[i];
    }
    this->tab[size] = '\0';
}

void Custom_string::despace()
{
    while (tab[size-1] == ' ')
    {
        tab[size-1] = '\0';
        size--;
    }
    for (int i = 0; i < size; i++)
    {
        if (tab[0] == ' ')
        {
            for (int j = 0; j < size - 1; j++)
                tab[j] = tab[j + 1];
            size--;
            tab[size] = '\0';
        }
        else
            break;
    }
}

void Custom_string::decolon()
{
    while (tab[size - 1] == ';')
    {
        tab[size - 1] = '\0';
        size--;
        tab[size] = '\0';
    }
}

bool Custom_string::isClear()
{
    if (tab == nullptr)
        return true;
    return false;
}

bool Custom_string::isInt()
{
    for (int i = 0; i < size; i++)
        if (tab[i] < '0' || tab[i]>'9')
            return false;
    return true;
}

int Custom_string::toInt()
{
    int result = 0;
    for (int i = 0; i < size; i++)
        result += (tab[i] - '0')*pow(10,size-i-1);
    return result;
}

Custom_string& Custom_string::operator+(const Custom_string& string) {
    
    Custom_string result = { "\0" };
    
    result.size = this->size + strlen(string.tab);
    result.tab = new char[this->size + strlen(string.tab)];

    for (int i = 0; i < this->size; i++)
    {
        result.tab[i] = this->tab[i];
    }

    for (int i = this->size; i <(this->size+strlen(string.tab)); i++)
    {
        result.tab[i] = string.tab[i-this->size];
    }
    
    result.tab[result.size] = '\0';
    return result;
}

Custom_string& Custom_string::operator+=(char c)
{
    char* temp = new char[size + 1];
    if (size != 0)
    {
        for (int i = 0; i < size; i++)
        {
            temp[i] = tab[i];
        }
    }
    temp[size] = c;
    temp[size + 1] = '\0';
    size++;
    //delete tab;
    tab = temp;
    return *this;
}

bool Custom_string::operator==(Custom_string c)
{
    if (size != c.size)
        return false;
    for (int i = 0; i < size; i++)
    {
        if (c.tab[i] != tab[i])
            return false;
    }
    return true;
}


size_t Custom_string::getSize(){ //Zwraca liczb liter, nie uwzglednia \0
    return size;
}

char* Custom_string::getString() {
    return tab;
}

void Custom_string::clear()
{ 
    tab = nullptr;
    size = 0;
}

std::istream& operator>>(std::istream& is,Custom_string& str)
{
    char* buffer = new char[2048];
    is >> buffer;
    str = Custom_string(buffer);
    delete[] buffer;
    return is;
}

std::ostream& operator<<(std::ostream& os, const Custom_string& str)
{
    //os << "Wyraz: ";
    for (int i = 0; i < str.size; i++)
    {
        os << str.tab[i];
    }
	return os;
}

Custom_string::~Custom_string()
{
    //std::cout << "Usuwam string";
}
