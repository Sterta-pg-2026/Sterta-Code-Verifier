#pragma once
#include "attributenode.h"
class AttributeList
{
	public:
		AttributeList();
		AttributeNode* head;
		AttributeNode* tail;
		short int size=0;
		short int removed;//?????
		bool doesExist(Custom_string attr_name);
		void addElement(AttributeNode Node);
		void insert(Custom_string name, Custom_string value);
		void printList();
		void clear();
		~AttributeList();
};

