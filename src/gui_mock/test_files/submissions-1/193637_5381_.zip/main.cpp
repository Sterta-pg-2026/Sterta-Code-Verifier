#include <iostream>

#include "custom_string.h"
#include "node.h"
#include "doublylinkedlist.h"
#include "selectorlist.h"
#include "attributelist.h"
using namespace std;




struct Procesor_CSS {

	void main() {

		Custom_string name, value, temp;
		DoublyLinkedList MainList;
		Node node;
		Section section;
		AttributeList attrlist;
		SelectorList selelist;


		char znak = NULL;
		int word = 0;

		word = 0;

		bool gettingSelectors = true;
		bool gettingAttributes = false;

		int temp_int = -1;

		while (znak = getchar())
		{
			if (znak == EOF)
				break;
			if (znak <' ' && znak != '\n')
				continue;
 			if (!name.isClear() &&znak == '\n' && gettingSelectors)
			{
				name.despace(); // dodane pozniej
				gettingSelectors = false;
				selelist.insert(name);
				name.clear();
			}
			if (!name.isClear() && gettingSelectors && znak == ',') //wczytanie selektora
			{
				name.despace();
				selelist.insert(name);
				name.clear();
				continue;
			}
			if (znak == '{' && !name.isClear()) //rozpoczęcie wczytywania atrybutów 1
			{
				name.despace();
				selelist.insert(name);
				name.clear();
				gettingSelectors = false;
				gettingAttributes = true;
				continue;
			}
			if (znak == '{') //rozpoczęcie wczytywania atrybutów 2
			{
				gettingSelectors = false;
				gettingAttributes = true;
				continue;
			}
			if (znak == '}')
			{
				section.push_back(attrlist, selelist);
				MainList.push_back(section);
				gettingSelectors = true;
				gettingAttributes = false;
				section.clear();
				selelist.clear();
				attrlist.clear();
				continue;
			}
			if (znak == ':' && gettingAttributes)//wczytanie wartości atrybutu
			{
				word++;
				continue;
			}
			if (znak == '\n' && !name.isClear() && gettingSelectors)//wczytanie selektora 2
			{
				name.despace();
				selelist.insert(name);
				name.clear();
				continue;
			}
			if (!name.isClear() && !value.isClear() && (znak == '\n' || znak == ';') && gettingAttributes)//wczytanie atrybutu
			{
				name.despace();
				value.decolon();
				value.despace();
				attrlist.insert(name,value);
				name.clear();
				value.clear();
				word = 0;
				continue;
			}
 			if (znak != '\n' && word == 0)
			{
				name += znak;
			}
			if (znak != '\n' && word == 1)
			{
				value += znak;
			}
			if (name == "????")
			{
				name.clear();
				Custom_string tab[3];
				int i = 0, num=0;
				while (znak = getchar())
				{
					if (znak == EOF)
						return;
					if (znak < ' ' && znak != '\n')
						continue;
					if (znak == ',')
					{
						tab[i] = name;
						name.clear();
						i++;
						continue;
					}
					if (znak != '\n')
						name += znak;
					if (znak == '\n')
					{
 						tab[i] = name;
						name.clear();
						if(tab[0].isInt()) /// i
						{
							num = tab[0].toInt();
							if (tab[1] == "S")
							{
								if (tab[2] == "?")
								{
									temp_int = -1;
									temp_int = MainList.selectorsInSection(num);
									if(temp_int>=0)
										cout << num << ",S,? == " << temp_int << '\n';
								}
								if (tab[2].isInt())
									temp = MainList.selectorByIndexAndSection(tab[2].toInt(), num);
								if (temp == "") {}
								else
								{
									cout << num << ",S," << tab[2].toInt() << " == " << temp << '\n';
									temp.clear();
								}
							}
							if (tab[1] == "A")
							{
								if (tab[2] == "?")
								{
									temp_int = -1;
									temp_int = MainList.attributesInSection(num);
									if(temp_int>=0)
										cout << num << ",A,? == " << temp_int << '\n';//????
								}
								else if (!tab[2].isInt())
								{
									temp = MainList.valueBySectionAndName(num, tab[2]);
									if(temp==""){}
									else
									{
										cout << num << ",A," << tab[2] << " == " << temp << '\n';
										temp.clear();
									}
								}
							}
							if (tab[1] == "D")
							{
								if (tab[2] == "*")
								{
									if (!MainList.isSectionDeleted(num))
									{
										MainList.deleteSectionByIndex(num);//czy usunieta
										cout << num << ",D,* == deleted" << '\n';
									}
								}
								else
								{
									if (tab[2] == "border")
										num = num;
									if (!MainList.isAttributeDeleted(num, tab[2]) && (MainList.countAttributeOccurances(tab[2]))>0)
									{
										MainList.deleteAttributeByNameAndIndex(num, tab[2]);
										cout << num << ",D," << tab[2] << " == deleted" << '\n';
									}
								}
							}
						}
						else // name
						{
							if (tab[1] == "S")
							{
								if (tab[2] == "?")
								{
									cout << tab[0] << ",S,? == " << MainList.countSelectorOccurances(tab[0]) << '\n';
								}
							}
							else if (tab[1] == "A")
							{
								if (tab[2] == "?")
								{
									cout << tab[0] << ",A,? == " << MainList.countAttributeOccurances(tab[0]) << '\n';
								}
							}
							else if (tab[1] == "E")
							{
								temp = MainList.attributeValueBySelector(tab[2], tab[0]);
								if (temp == "") {}
								else
								{
									cout << tab[0] << ",E," << tab[2] << " == " << temp << '\n';
									temp.clear();
								}
								
							}
							else if (tab[0] == "****")
							{
								break;
							}
							else if (tab[0] == "?")
							{
								cout<< "? == " << MainList.sectionsCount() << '\n';
							}
						}
						for (int j = 0; j < 3; j++)
							tab[j].clear();
						i = 0;
					}
				}
				//break;
			}
		}
		
	}
	void tests()
	{

	}
};


int main()
{
	Procesor_CSS program;
	program.main();
 }