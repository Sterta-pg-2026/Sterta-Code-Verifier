#pragma once
#include "attributelist.h"
#include "selectorlist.h"
class Section
{
	public:
		Section();
		AttributeList AttrList;
		SelectorList SeleList;
		bool deleted;
		Section& operator=(const Section& a);
		friend std::ostream& operator<<(std::ostream& os, Section& a);
		void push_back(AttributeList attr, SelectorList sele);
		void clear();
		~Section();
};

