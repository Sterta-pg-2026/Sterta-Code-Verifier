#include "selectornode.h"

std::ostream& operator<<(std::ostream& os, Selector s)
{
    os << s.getName();
    return os;
}

SelectorNode::SelectorNode()
{
    prev = nullptr;
    next = nullptr;
}

SelectorNode::~SelectorNode()
{
}
