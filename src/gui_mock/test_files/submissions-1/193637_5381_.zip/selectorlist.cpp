#include "selectorlist.h"

void SelectorList::addElement(SelectorNode Node)
{
    if (head == nullptr)
    {
        SelectorNode* temp = new SelectorNode;
        temp->value = Node.value;
        head = temp;
        head->prev = nullptr;
        head->next = nullptr;
        tail = temp;
        //tail->prev = head; ///???????????????????????????
    }
    else
    {
        SelectorNode* current = new SelectorNode;
        current->value = Node.value;
        tail->next = current;
        current->prev = tail;
        tail = current;
    }
    size++;
}

void SelectorList::printList()
{
    SelectorNode* current = head;
	for (int i = 0; i < size; i++)
	{
        std::cout<<"\nLista [" << i <<"] = " << current->value.name;
        current = current->next;
	}
}

void SelectorList::insert(Custom_string name)
{
    SelectorNode node;
    Selector selector;
    selector.name = name;
    node.value = selector;
    addElement(node);
}

void SelectorList::clear()
{
    SelectorNode* Node = head;
    while (Node != nullptr)
    {
        SelectorNode* temp = Node;
        Node = Node->next;
        temp = nullptr;
        //delete temp;
    }
    size = 0;
    head = nullptr;
    tail = nullptr;
}


SelectorList::~SelectorList()
{

}

