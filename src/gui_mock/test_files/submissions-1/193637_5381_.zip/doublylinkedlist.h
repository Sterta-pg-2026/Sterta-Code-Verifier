#pragma once
#include "node.h"
class DoublyLinkedList
{
	private:
		Node* head;
		Node* tail;
		size_t size;
	public:
		DoublyLinkedList();
		void push_back(Section section);
		void printList();
		/*void printList2();
		void printList3();*/
		bool isSectionDeleted(int index);
		bool isAttributeDeleted(int index, Custom_string attribute_name);
		bool shouldSectionBeDeleted(AttributeList List);
		int sectionsCount();//"?"
		int selectorsInSection(int index);//"i,S,?"
		int attributesInSection(int index);//"i,A,?"
		Custom_string selectorByIndexAndSection(int selector, int section);//"i,S,j"
		Custom_string valueBySectionAndName(int section, Custom_string attribute_name);//"i,A,n" 
		int countAttributeOccurances(Custom_string name);//"n,A,?"
		int countSelectorOccurances(Custom_string name);//"z,S,?"
		Custom_string attributeValueBySelector(Custom_string attribute_name,Custom_string selector_name);//"z,E,n"
		void deleteSectionByIndex(int index);//"i,D,*"       <<< vvv NIE TESTOWANE vvv
		void deleteAttributeByNameAndIndex(int index, Custom_string attribute_name);//"i,D,n"
};