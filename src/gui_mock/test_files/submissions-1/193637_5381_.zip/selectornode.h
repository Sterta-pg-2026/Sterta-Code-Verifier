#pragma once
#include "selector.h"
class SelectorNode
{
	public:
		SelectorNode* prev;
		SelectorNode* next;
		Selector value;
		SelectorNode();
		friend std::ostream& operator<<(std::ostream& os, Selector s);
		~SelectorNode();
};

