#pragma once
#include "attribute.h"
class AttributeNode
{	
	public:
		AttributeNode* next;
		AttributeNode* prev;
		Attribute value;
		AttributeNode();
		friend std::ostream& operator<<(std::ostream& os, Attribute a);
		~AttributeNode();
};

