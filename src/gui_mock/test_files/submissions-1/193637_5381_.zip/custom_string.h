#pragma once
#include <iostream>
class Custom_string
{
	private: 
		char* tab;
		std::size_t size;


	public:

		friend std::ostream& operator<<(std::ostream& os, const Custom_string& str);
		friend std::istream& operator>>(std::istream& is, Custom_string& str);
		Custom_string();
		Custom_string(const char* str);
		void despace();
		void decolon();
		bool isClear();
		bool isInt();
		int toInt();
		Custom_string& operator+(const Custom_string& string);
		Custom_string& operator+=(char c);
		bool operator==(Custom_string c);
		size_t getSize();
		char* getString();
		void clear();
		~Custom_string();
};

