#include "selector.h"

Selector::Selector()
{
}

Custom_string Selector::getName()
{
    return name;
}

//void Selector::insert(Custom_string string)
//{
//    name = string;
//}

std::ostream& operator<<(std::ostream& os, const Selector& s)
{
    os << "Selektor: ";
    os << s.name;
    return os;
}

Selector::~Selector()
{

}
