#pragma once
#include "selectornode.h"
class SelectorList
{
	public:
		SelectorNode* head=nullptr;
		SelectorNode* tail=nullptr;
		short int size=0;
		void addElement(SelectorNode s);
		void printList();
		void insert(Custom_string name);
		void clear();
		~SelectorList();

};

