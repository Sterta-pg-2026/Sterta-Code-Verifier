#include "input_manager.h"

#include <iostream>

InputManager::InputManager() {
    for (int i = 0; i < MAX_BUFF_SIZE; i++)
        buff[i] = '\0';
}

InputManager& InputManager::getInstance() {
    static InputManager instance;
    return instance;
}

char InputManager::read() {
    buff[it] = (char)getchar();
    return buff[it++];
}

IMMode InputManager::getMode() {
    return mode;
}

void InputManager::setMode(IMMode mode) {
    this->mode = mode;
}

String InputManager::getString() {
    String res = String(buff, it - 1);  // adjust for delim character
    it = 0;
    return res;
}