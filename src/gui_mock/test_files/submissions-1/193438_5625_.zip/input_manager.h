#pragma once

#include <iostream>

#include "string.h"
#include "globals.h"

enum IMMode {
    selector,
    attribute,
    value,
    command,
};

class InputManager {
   private:
    char buff[MAX_BUFF_SIZE];
    int it = 0;
    IMMode mode = IMMode::selector;

   public:
    InputManager();

    static InputManager& getInstance();
    InputManager(InputManager const&) = delete;
    void operator=(InputManager const&) = delete;

    char read();
    IMMode getMode();
    void setMode(IMMode mode);
    String getString();
};