#pragma once

template <typename T>
struct Node {
    T value;
    Node* next;
    Node* prev;

    Node(T value);
};

template <typename T>
class List {
   private:
    Node<T>* head;
    Node<T>* tail;
    int m_size;

   public:
    template <typename U>
    class Iterator {
       private:
        Node<U>* current;

       public:
        Iterator(Node<U>* current) : current(current) {}

        Iterator operator++() {
            current = current->next;
            return *this;
        }

        bool operator!=(const Iterator& other) const {
            return current != other.current;
        }

        U& operator*() const {
            return current->value;
        }

        U* operator->() const {
            return &current->value;
        }
    };

    List();
    ~List();

    T& operator[](int index) const;

    void add(T value);
    bool remove(T value);
    int length();
    void clear();

    Iterator<T> begin() const;
    Iterator<T> last() const;
    Iterator<T> end() const;
};
