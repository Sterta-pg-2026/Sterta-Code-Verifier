#pragma once

#include <cstring>
#include <iostream>

#include "list.h"

class String {
   private:
    char* m_data;
    inline bool isWhitespace(char c) {
        return (c < '!' || c > '~');
    }

   public:
    String(const char* str = "");
    String(const char* str, int lenght);
    String(const String& other);
    String(int num);
    ~String();

    String& operator=(const String& other);
    String& operator+=(const String& other);
    String& operator+=(const char c);
    char& operator[](size_t index);
    const char& operator[](size_t index) const;
    bool operator==(const String& other);
    bool operator==(const String& other) const;

    const char* c_str() const;
    size_t size() const;
    bool empty() const;

    void parse();
    void clear();
    void pop_back();
    List<String> splitByChar(char delim);

    friend std::ostream& operator<<(std::ostream& os, const String& str);
};
