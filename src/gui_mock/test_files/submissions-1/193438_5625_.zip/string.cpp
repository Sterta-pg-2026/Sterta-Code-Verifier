#include "string.h"

#include <stdexcept>

#include "list.h"
#include "globals.h"

String::String(const char* str) {
    m_data = new char[std::strlen(str) + 1];
    std::strcpy(m_data, str);
}

String::String(const char* str, int lenght) {
    m_data = new char[lenght];
    std::strncpy(m_data, str, lenght);
}

String::String(const String& other) {
    m_data = new char[std::strlen(other.m_data) + 1];
    std::strcpy(m_data, other.m_data);
}

String::String(int num) {
    int temp = snprintf(nullptr, 0, "%d", num);
    m_data = new char[temp + 1];
    snprintf(m_data, temp + 1, "%d", num);
}

String::~String() {
    delete[] m_data;
}

String& String::operator=(const String& other) {
    if (this != &other) {
        delete[] m_data;
        m_data = new char[std::strlen(other.m_data) + 1];
        std::strcpy(m_data, other.m_data);
    }
    return *this;
}

String& String::operator+=(const String& other) {
    char* new_data = new char[std::strlen(m_data) + std::strlen(other.m_data) + 1];
    std::strcpy(new_data, m_data);
    std::strcat(new_data, other.m_data);
    delete[] m_data;
    m_data = new_data;
    return *this;
}

String& String::operator+=(const char c) {
    char* new_data = new char[std::strlen(m_data) + 1 + 1];
    std::strcpy(new_data, m_data);
    new_data[std::strlen(m_data)] = c;
    new_data[std::strlen(m_data) + 1] = '\0';
    delete[] m_data;
    m_data = new_data;
    return *this;
}

char& String::operator[](size_t index) {
    if (index >= std::strlen(m_data)) {
        throw std::out_of_range("String::operator[] index out of range.");
    }
    return m_data[index];
}

const char& String::operator[](size_t index) const {
    if (index >= std::strlen(m_data)) {
        throw std::out_of_range("String::operator[] index out of range.");
    }
    return m_data[index];
}

bool String::operator==(const String& other) {
    return strcmp(this->m_data, other.m_data) == 0;
}

bool String::operator==(const String& other) const {
    return strcmp(this->m_data, other.m_data) == 0;
}

const char* String::c_str() const {
    return m_data;
}

List<String> String::splitByChar(char delim) {
    List<String> result;
    String current;

    for (int i = 0; i < std::strlen(m_data); i++) {
        if (m_data[i] == delim) {
            if (!current.empty()) {
                result.add(current);
                current.clear();
            }
        } else {
            current += m_data[i];
        }
    }

    if (!current.empty()) {
        result.add(current);
    }

    return result;
}

void String::parse() {
    String res = "";
    bool isSpaceToAdd = false;
    for (int i = 0; i < std::strlen(m_data); i++) {
        if (!isWhitespace(m_data[i])) {
            res += m_data[i];
            isSpaceToAdd = true;
        } else {
            if (isSpaceToAdd) {
                res += ' ';
                isSpaceToAdd = false;
            }
        }
    }
    if (!res.empty() && res[res.size() - 1] == ' ')
        res.pop_back();
    std::strcpy(this->m_data, res.c_str());
}

void String::clear() {
    delete[] m_data;
    m_data = new char[1];
    m_data[0] = '\0';
}

bool String::empty() const {
    return (std::strlen(m_data) == 0);
}

void String::pop_back() {
    size_t len = std::strlen(m_data);
    if (len > 0) {
        char* new_data = new char[len];
        std::strncpy(new_data, m_data, len - 1);
        new_data[len - 1] = '\0';
        delete[] m_data;
        m_data = new_data;
    } else {
        throw std::out_of_range("String::pop_back() called on empty string.");
    }
}

size_t String::size() const {
    return std::strlen(m_data);
}

std::ostream& operator<<(std::ostream& os, const String& str) {
    os << str.c_str();
    return os;
}
