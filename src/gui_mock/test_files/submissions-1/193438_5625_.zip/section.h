#pragma once

#include <iostream>

#include "list.h"
#include "string.h"
#include "utils.h"

struct Attribute {
    String property;
    String value;

    Attribute() {
    }
    Attribute(String property, String value) : property(property), value(value) {}

    friend std::ostream& operator<<(std::ostream& os, const Attribute& attribute) {
        os << attribute.property << ": " << attribute.value << ";\n";
        return os;
    }

    bool operator==(const Attribute& other) const {
        return (property == other.property);
    }
};

typedef String Selector;

struct Section {
    List<Selector> selectors;
    List<Attribute> attributes;

    Section() {}
    Section(List<Selector> selectors, List<Attribute> attributes) : selectors(selectors), attributes(attributes) {}

    Response<String> getSelector(int id) {
        if (id > selectors.length())
            return Response(String(""), FAILURE);
        return Response(selectors[id - 1], SUCCESS);
    }

    Response<String> getSelector(String q) {
        for (auto& selector : selectors) {
            if (selector == q)
                return Response(selector, SUCCESS);
        }
        return Response(String(""), FAILURE);
    }

    Response<String> queryAttributes(String q) {
        for (auto& attribute : attributes) {
            if (attribute.property == q)
                return Response(attribute.value, SUCCESS);
        }
        return Response(String(""), FAILURE);
    }

    Response<String> removeAttribute(String name) {
        if (attributes.remove(Attribute(name, name)))
            return Response(String("deleted"), SUCCESS);
        return Response(String(""), FAILURE);
    }
};