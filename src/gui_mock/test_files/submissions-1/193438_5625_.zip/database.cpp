#include "database.h"

#include "list.h"
#include "string.h"
#include "block.h"
#include "section.h"

Database::Database() {
    blocks.add(Block());
    currentBlock = blocks.begin();
}

Database::~Database() {
}

Section* Database::_getSectionByID(int id) {
    if (id > totalSections) {
        return nullptr;
    }

    auto it = blocks.begin();
    int index = 0;
    for (; id > it->sectionsCount; id -= it->sectionsCount)
        ++it;
    for (; id > 0 && index < SECTIONS_IN_BLOCK; index++) {
        if (it->sections[index] != nullptr)
            --id;
    }
    return it->sections[index - 1];  // check
}

Section* Database::_getSectionByID(String name) {
    int cnt = 0;
    for (auto& block : blocks) {
        for (int i = 0; i < SECTIONS_IN_BLOCK; i++) {
            if (block.sections[i] != nullptr &&
                block.sections[i]->getSelector(name).errcode == SUCCESS) {
                return block.sections[i];
            }
        }
    }
    return nullptr;
}

Response<int> Database::addSection(List<Selector>& selectors, List<Attribute>& attributes) {
    for (auto& selector : selectors) {
        auto ptr = _getSectionByID(selector);
        if (ptr != nullptr) {
            ptr->selectors = selectors;
            ptr->attributes = attributes;
            // for (auto& attribute : attributes) {
            //     ptr->attributes.remove(attribute);
            //     ptr->attributes.add(attribute);
            // }
            return Response(0, SUCCESS);
        }
    }

    currentBlock->sections[currentSection++] = new Section(selectors, attributes);
    currentBlock->sectionsCount++;
    totalSections++;
    if (currentSection >= 8) {
        ++currentBlock;
        currentSection = 0;
    }
    return Response(0, SUCCESS);
}

Response<int> Database::getSectionCnt() {
    return Response(totalSections, SUCCESS);
}

Response<int> Database::getSelectorsCnt(int ID) {
    if (_getSectionByID(ID) != nullptr)
        return Response(_getSectionByID(ID)->selectors.length(), SUCCESS);
    return Response(0, FAILURE);
}

Response<int> Database::getAttributesCnt(int ID) {
    if (_getSectionByID(ID) != nullptr)
        return Response(_getSectionByID(ID)->attributes.length(), SUCCESS);
    return Response(0, FAILURE);
}

Response<String> Database::getSelectorByID(int selectorID, int ID) {
    if (_getSectionByID(ID) != nullptr)
        return _getSectionByID(ID)->getSelector(selectorID);
    return Response(String(""), FAILURE);
}

Response<String> Database::getAttributeByName(String name, int ID) {
    if (_getSectionByID(ID) != nullptr)
        return _getSectionByID(ID)->queryAttributes(name);
    return Response(String(""), FAILURE);
}

Response<int> Database::countSelector(String name) {
    int cnt = 0;
    for (auto& block : blocks) {
        for (int i = 0; i < SECTIONS_IN_BLOCK; i++) {
            if (block.sections[i] != nullptr &&
                block.sections[i]->getSelector(name).errcode == SUCCESS) {
                ++cnt;
            }
        }
    }
    return Response(cnt, SUCCESS);
}

Response<int> Database::countAttribute(String name) {
    int cnt = 0;
    for (auto& block : blocks) {
        for (int i = 0; i < SECTIONS_IN_BLOCK; i++) {
            if (block.sections[i] != nullptr &&
                block.sections[i]->queryAttributes(name).errcode == SUCCESS) {
                ++cnt;
            }
        }
    }
    return Response(cnt, SUCCESS);
}

Response<String> Database::queryByName(String selector, String Attribute) {
    for (auto& block : blocks) {
        for (int i = 0; i < SECTIONS_IN_BLOCK; i++) {
            if (block.sections[i] != nullptr && block.sections[i]->getSelector(selector).errcode == SUCCESS) {
                return block.sections[i]->queryAttributes(Attribute);
            }
        }
    }
    return Response(String(""), FAILURE);
}

Response<String> Database::deleteSection(int id) {
    if (id > totalSections) {
        return Response(String(""), FAILURE);
    }

    auto it = blocks.begin();
    int index = 0;
    for (; id > it->sectionsCount; id -= it->sectionsCount)
        ++it;
    for (; id > 0 && index < SECTIONS_IN_BLOCK; index++) {
        if (it->sections[index] != nullptr)
            --id;
    }
    delete it->sections[index - 1];
    it->sections[index - 1] = nullptr;
    it->sectionsCount--;
    totalSections--;
    return Response(String("deleted"), SUCCESS);
}

Response<String> Database::deleteAttribute(String name, int id) {
    if (_getSectionByID(id) != nullptr) {
        auto res = _getSectionByID(id)->removeAttribute(name);
        if (_getSectionByID(id)->attributes.length() == 0)
            deleteSection(id);
        return res;
    }
    return Response(String(""), FAILURE);
}
