#pragma once

#include "list.h"
#include "string.h"
#include "database.h"

String interpret(List<String>& args, Database& db) {
    String res = "";
    bool isSuccess = false;
    Response<String> buffStr = Response(String(""), FAILURE);
    Response<int> buffInt = Response(0, FAILURE);

    if (args.length() == 1 && args[0] == "?") {  // ?
        Response<int> buff = db.getSectionCnt();
        isSuccess = buff.errcode == SUCCESS;
        res = buff.res;
    } else if (args.length() == 3) {
        int i;
        switch (args[1][0]) {
            case 'S':
                i = strtol(args[0].c_str(), nullptr, 10);
                if (args[2] == "?") {
                    if (i == 0) {  // z,S,?
                        buffInt = (db.countSelector(args[0]));
                    } else {  // i,S,?
                        buffInt = (db.getSelectorsCnt(i));
                    }
                    isSuccess = buffInt.errcode == SUCCESS;
                    res = String(buffInt.res);
                } else {  // i,S,j
                    int j = strtol(args[2].c_str(), nullptr, 10);
                    buffStr = db.getSelectorByID(j, i);
                    isSuccess = buffStr.errcode == SUCCESS;
                    res = buffStr.res;
                }
                break;

            case 'A':
                i = strtol(args[0].c_str(), nullptr, 10);
                if (args[2] == "?") {
                    buffInt = Response(0, 0);
                    if (i == 0) {  // n,A,?
                        buffInt = db.countAttribute(args[0]);
                    } else {  // i,A,?
                        buffInt = db.getAttributesCnt(i);
                    }
                    isSuccess = buffInt.errcode == SUCCESS;
                    res = buffInt.res;  // cast?
                } else {                // i,A,n
                    buffStr = db.getAttributeByName(args[2], i);
                    isSuccess = buffStr.errcode == SUCCESS;
                    res = buffStr.res;
                }
                break;

            case 'D':
                buffStr = Response(String(""), 0);
                i = strtol(args[0].c_str(), nullptr, 10);
                if (args[2] == "*") {  // i,D,*
                    buffStr = db.deleteSection(i);
                } else {  // i,D,n
                    buffStr = db.deleteAttribute(args[2], i);
                }
                isSuccess = buffStr.errcode == SUCCESS;
                res = buffStr.res;
                break;

            case 'E':
                buffStr = db.queryByName(args[0], args[2]);
                isSuccess = buffStr.errcode == SUCCESS;
                res = buffStr.res;
                break;

            default:
                break;
        }
    }
    if (isSuccess) {
        String toPrint = "";
        for (String& arg : args) {
            toPrint += arg;
            toPrint += String(",");
        }
        toPrint.pop_back();
        toPrint += String(" == ");
        toPrint += res;
        toPrint += String("\n");
        return toPrint;
    }
    return "";
}