#pragma once

#include "globals.h"
#include "section.h"

struct Block {
    int sectionsCount = 0;
    Section* sections[SECTIONS_IN_BLOCK];
    Block() {
        for (int i = 0; i < SECTIONS_IN_BLOCK; i++)
            sections[i] = nullptr;
    }
    bool operator==(const Block& other) const {
        return (sectionsCount == other.sectionsCount && sections == other.sections);
    }
};
