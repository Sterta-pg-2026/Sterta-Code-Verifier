#include <iostream>

#include "string.h"
#include "database.h"
#include "input_manager.h"
#include "interpreter.h"
#include "section.h"

int main(int argc, char const* argv[]) {
    InputManager& im = InputManager::getInstance();
    Database db;

    List<Selector> selectrosBuff;
    List<Attribute> attributeBuff;
    int reps = 0;
    char current = im.read();
    bool toSkip = false;
    while (current != EOF) {
        switch (im.getMode()) {
            case selector:
                if (current == '{') {
                    List<String> l = im.getString().splitByChar(',');
                    for (String& x : l) {
                        x.parse();
                        if (!x.empty() && selectrosBuff.length() > 0) {
                            for (auto& selector : selectrosBuff) {
                                if (selector == x) {
                                    toSkip = true;
                                    break;
                                }
                            }
                        }
                        if (toSkip)
                            toSkip = false;
                        else
                            selectrosBuff.add(x);
                    }
                    im.setMode(attribute);
                }

                if (current == '?')
                    ++reps;
                else
                    reps = 0;

                if (reps == 4) {
                    reps = 0;
                    im.getString();  // reset buffor
                    im.setMode(command);
                }
                break;
            case attribute:
                if (current == ';' || current == '\n') {
                    List<String> l = im.getString().splitByChar(':');
                    if (l.length() == 2) {
                        for (int i = 0; i < l.length(); i++)
                            l[i].parse();
                        if (attributeBuff.length() > 0) {
                            for (auto& attribute : attributeBuff) {
                                if (attribute.property == l[0]) {
                                    toSkip = true;
                                    break;
                                }
                            }
                        }
                        if (toSkip)
                            toSkip = false;
                        else
                            attributeBuff.add({l[0], l[1]});
                    }
                } else if (current == '}') {
                    im.getString();
                    db.addSection(selectrosBuff, attributeBuff);
                    selectrosBuff.clear();
                    attributeBuff.clear();
                    im.setMode(selector);
                }

                break;
            case command: {
                if (current == '\n') {
                    List<String> command = im.getString().splitByChar(',');
                    if (command.length() > 3)
                        break;
                    std::cout << interpret(command, db);
                }

                if (current == '*')
                    ++reps;
                else
                    reps = 0;
                if (reps == 4) {
                    reps = 0;
                    im.getString();        // reset buffor
                    im.setMode(selector);  // maybe handle switching in middle of section?
                }
            }
            default:
                break;
        }
        current = im.read();
    }

    // TODO: handle EOF (EOF -> parse remaining input accordingly)
    switch (im.getMode()) {
        case command: {
            List<String> command = im.getString().splitByChar(',');
            if (command.length() > 3)
                break;
            std::cout << interpret(command, db);
        }
        default:
            break;
            return 0;
    }
