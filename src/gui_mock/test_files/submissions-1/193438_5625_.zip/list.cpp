#include "list.h"

#include <iostream>

#include "string.h"
#include "block.h"
#include "section.h"

template <typename T>
Node<T>::Node(T value) {
    this->value = value;
    this->next = nullptr;
    this->prev = nullptr;
}

template <typename T>
List<T>::List() {
    head = nullptr;
    tail = nullptr;
    m_size = 0;
}

template <typename T>
List<T>::~List() {
    clear();
}

template <class T>
T& List<T>::operator[](int index) const {
    Node<T>* current = head;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }
    return current->value;
}

template <typename T>
void List<T>::add(T value) {
    Node<T>* node = new Node<T>(value);

    if (head == nullptr) {
        head = node;
        tail = node;
    } else {
        node->prev = tail;
        tail->next = node;
        tail = node;
    }

    ++m_size;
}

template <typename T>
bool List<T>::remove(T value) {
    Node<T>* node = head;

    while (node != nullptr) {
        if (node->value == value) {
            if (node == head && node == tail) {  // list has only one element
                head = tail = nullptr;
            } else if (node == head) {
                head = node->next;
                head->prev = nullptr;
            } else if (node == tail) {
                tail = node->prev;
                tail->next = nullptr;
            } else {
                node->prev->next = node->next;
                node->next->prev = node->prev;
            }

            delete node;
            m_size--;
            return true;
        }

        node = node->next;
    }

    return false;
}

template <typename T>
int List<T>::length() {
    return m_size;
}

template <typename T>
void List<T>::clear() {
    Node<T>* node = head;

    while (node != nullptr) {
        Node<T>* nextNode = node->next;
        // TODO: fix memory leak
        // delete node;
        node = nextNode;
    }

    head = nullptr;
    tail = nullptr;
    m_size = 0;
}

template <typename T>
typename List<T>::template Iterator<T> List<T>::begin() const {
    return Iterator<T>(head);
}

template <typename T>
typename List<T>::template Iterator<T> List<T>::last() const {
    return Iterator<T>(tail);
}

template <typename T>
typename List<T>::template Iterator<T> List<T>::end() const {
    return Iterator<T>(tail->next);  // equivalent to nullptr
}

template class List<Selector>;
template class List<Attribute>;
template class List<Block>;