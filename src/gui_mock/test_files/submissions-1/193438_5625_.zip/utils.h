#pragma once

#define SUCCESS 0
#define FAILURE -1

template <typename T>
struct Response {
    T res;
    int errcode;
    Response(T res, int errcode) : res(res), errcode(errcode) {}
};