#pragma once

#include <iostream>

#include "list.h"
#include "string.h"
#include "section.h"
#include "block.h"
#include "utils.h"

class Database {
   private:
    List<Block> blocks;
    Section* _getSectionByID(int ID);
    Section* _getSectionByID(String ID);
    
    List<Block>::Iterator<Block> currentBlock = nullptr;
    int currentSection = 0;
    int totalSections = 0;

   public:
    Database(/* args */);
    ~Database();

    Response<int> addSection(List<Selector>& selectors, List<Attribute>& attributes);
    Response<int> getSectionCnt();
    Response<int> getSelectorsCnt(int ID);
    Response<int> getAttributesCnt(int ID);
    Response<String> getSelectorByID(int selectorID, int ID);
    Response<String> getAttributeByName(String name, int ID);
    Response<int> countSelector(String name);
    Response<int> countAttribute(String name);
    Response<String> queryByName(String selector, String Attribute);
    Response<String> deleteSection(int ID);
    Response<String> deleteAttribute(String name, int ID);

    void print() {
        std::cout << blocks[0].sectionsCount << std::endl
                  << blocks[0].sections[0]->attributes.length() << std::endl
                  << blocks[0].sections[0]->selectors.length() << std::endl;
    }
};
