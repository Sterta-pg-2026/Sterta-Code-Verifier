#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include"list.h"
#include"string.h"
using namespace std;

	void List::add(const String &str) {
		if (first == nullptr || size < 1) {
			first = new Node;
			last = first;
			first->strings[0] = str;
			first->used[0] = true;
			first->used_count = 1;
			size = 1;
		}
		else if (size > 0 && last->used_count != NULL && last->used_count < 8 && last->used_count > 0) {
			last->strings[last->used_count] = str;
			last->used[last->used_count] = true;
			last->used_count++;
			size++;
		}
		else {
			if (&str != nullptr){
				Node* tempNode = new Node;
				tempNode->strings[0] = str;
				tempNode->used[0] = true;
				tempNode->used_count = 1;
				tempNode->prev = last;
				last->next = tempNode;
				last = tempNode;
				size++;
			}
		}
	}

	String* List::read(int index) const {
		Node* temp = first;
		int loops = index / 8;
		int slot = index % 8;
		if (index < size) {
			for (int i = 0; i < loops; i++) {
				temp = temp->next;
			}
			return &(temp->strings[slot]);
		}
		String error = "error";
		return &error;
	}

	int List::getSize() const {
		return size;
	}

	void List::replace(const List& list2) {
		if (first != nullptr) {
			clear();
		}
		if (list2.size > 0) {
			for (int i = 0; i < (list2.getSize()-1); i++) {
				if (&(*list2.read(i)) != nullptr) {
					add(*list2.read(i));
				}
			}
		}
	}

	void List::import(const List& list2) {
		if (list2.size > 0) {
			for (int i = 0; i < (list2.getSize() - 1); i++) {
				add(*list2.read(i));
			}
		}
	}

	int List::findIndex(const String& str) {
		for (int i = size - 1; i >= 0; i--) {
			if (*read(i) == str) {
				return i;
			}
		}
		return -1;
	}

	int List::countAttributes() {
		int count = 0;
		String temp;
		for (int i = size - 1; i >= 0; i--) {
			temp = *read(i);
			if (temp.getLastString() == ";") {
				count++;
			}
		}
		return count;
	}

	void List::deleteIndex(int index) {
		if (size > 0 && size >= index && index >= 0) {
			Node* temp = first;
			int loops = (index) / 8;
			int slot = (index) % 8;
			for (int i = 0; i < loops; i++) {
				temp = first->next;
			}
			if (temp != nullptr) {
				temp->strings[slot] = temp->strings[temp->used_count-1];
			}
		}
	}

	void List::remove(int index) {
		if (size > 0 && size >= index && index >= 0) {
			Node* temp = first;
			int loops = (index) / 8;
			int loops2 = (size - (index)) / 8;
			int slot = (index) % 8;
			if (index < size) {
				for (int i = 0; i <= loops; i++) {
					temp = first->next;
				}
				for (int i = slot; i < 7; i++) {
					if (temp != nullptr && &(temp->strings[i + 1]) != nullptr) {
						temp->strings[i] = (temp->strings[i + 1]);
					}
				}
				for (int i = 0; i < loops2; i++) {
					temp = first->next;
					if (temp != nullptr && temp->used[0] == true) {
						temp->prev->strings[7] = temp->strings[0];
					}
					for (int i = 0; i < 7; i++) {
						if (temp != nullptr) {
							temp->strings[i] = temp->strings[i + 1];
						}
					}
				}
				temp = last;
				for (int i = 7; i > 0; i--) {
					if (temp->used[i] == true && &(temp->strings[i]) == nullptr) {
						temp->used[i] = false;
						temp->used_count--;
						break;
					}
				}
				size--;
			}
		}
	}

	void List::clear() {
		size = 0;
		Node* temp;
		while (last != first) {
			temp = last;
			if(last->prev != nullptr)
			last = last->prev;
			delete temp;
		}
		delete first;
		first = nullptr;
		last = nullptr;
	}
