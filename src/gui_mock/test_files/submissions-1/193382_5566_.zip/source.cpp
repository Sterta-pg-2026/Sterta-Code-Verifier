#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include"list.h"
using namespace std;

struct segment_struct {
    List selectors, attributes, attribute_names;
    int selectors_count = 0, attributes_count = 0;
};

int main() {

    String str, start_commands = "????", end_commands = "****", selector, j, n, attribute_value, plus = "+";
    segment_struct* T = new segment_struct[8];
    char arr[256], temparr[256];
    char command;
    int segments = 1, attributes = 0, commands = 0, a, execute = 0, selectors = 1, current_segment_count = 0, slots = 8, tempint, counter = 0, temp_int_j, number = 0, double_command = 0;
    char* double_selector;

    while (cin >> arr) {
        str = arr;

        if (*(str.getLastString()) == ';' || (str.getSize() > 1 && *(str.get2ndLastString()) == ';')) {                  //attributes in a segment counter
            attributes++;
        }
        else if (*(str.getFirstString()) == '{') {
            selectors = 0;
        }

        if (!strcmp(str.getString(), end_commands.getString())) {
            commands = 0;
        }

        if (&str != nullptr && commands == 0) {
            //saving selectors into a list
            if (selectors == 1) {
                if (strcmp(str.getString(), start_commands.getString()) && strcmp(str.getString(), end_commands.getString())) {
                    if (*(str.getLastString()) == ',') {
                        str = strtok(str.getString(), ",");
                        if (str.getSize() > 0 && T[segments - 1].selectors.findIndex(str) == -1) {
                            T[segments - 1].selectors.add(str);
                            T[segments - 1].selectors_count++;
                        }
                    }
                    else if (*(str.getLastString()) == '{') {
                        selectors = 0;
                        attributes = 1;
                        str = strtok(str.getString(), "{");
                        str = strtok(str.getString(), ",");
                        if (str.getSize() > 1 && T[segments - 1].selectors.findIndex(str) == -1) {
                            T[segments - 1].selectors.add(str);
                            T[segments - 1].selectors_count++;
                        }
                    }
                    else {
                        cin >> temparr;
                        attribute_value = temparr;
                        while (&attribute_value != nullptr && attribute_value.isThereChar(",") == 0 && attribute_value.isThereChar("{") == 0) {
                            str = str.join(&attribute_value);
                            cin >> temparr;
                            attribute_value = temparr;
                        }
                        if (*(attribute_value.getLastString()) == '{' && *(attribute_value.getFirstString()) == '{') {
                            selectors = 0;
                            attributes = 1;
                            str = strtok(str.getString(), "{");
                            str = strtok(str.getString(), ",");
                            if (str.getSize() > 0 && T[segments - 1].selectors.findIndex(str) == -1) {
                                T[segments - 1].selectors.add(str);
                                T[segments - 1].selectors_count++;
                            }
                        }
                        else if (*(attribute_value.getFirstString()) == '{') {
                            selectors = 0;
                            attributes = 1;
                            str = strtok(str.getString(), "{");
                            str = strtok(str.getString(), ",");
                            if (str.getSize() > 1 && T[segments - 1].selectors.findIndex(str) == -1) {
                                T[segments - 1].selectors.add(str);
                                T[segments - 1].selectors_count++;
                            }
                            str = attribute_value;
                            str = str.lastSegment("{");
                            if (*(str.getLastString()) == ':' || *(str.get2ndLastString()) == ':') {
                                str = strtok(str.getString(), ":");
                                T[segments - 1].attribute_names.add(str);
                                T[segments - 1].attributes_count++;
                                T[segments - 1].attributes.add(str);
                            }
                            else {
                                attribute_value = str.lastSegment(":");
                                str = strtok(str.getString(), ":");
                                T[segments - 1].attribute_names.add(str);
                                T[segments - 1].attributes_count++;
                                T[segments - 1].attributes.add(str);
                                T[segments - 1].attributes.add(attribute_value);
                            }
                        }
                        else if (*(attribute_value.getLastString()) == '{') {
                            selectors = 0;
                            attributes = 1;
                            attribute_value = strtok(attribute_value.getString(), "{");
                            tempint = 0;
                            str = str.join(&attribute_value);
                            T[segments - 1].selectors.add(str);
                            T[segments - 1].selectors_count++;
                        }
                        else {
                            tempint = 0;
                            str = str.join(&attribute_value);
                            str = strtok(str.getString(), ",");
                            T[segments - 1].selectors.add(str);
                            T[segments - 1].selectors_count++;
                        }
                    }
                }
            }
            //saving attributes into a list
            else {
                if (*(str.getLastString()) != '}' && *(str.getFirstString()) != '{') {
                    if (*(str.getLastString()) == ':' || (str.getSize() > 1 && *(str.get2ndLastString()) == ':')) {
                        str = strtok(str.getString(), ":");
                        if (T[segments - 1].attribute_names.findIndex(str) == -1) {
                            T[segments - 1].attributes_count++;
                            T[segments - 1].attribute_names.add(str);
                        }
                        T[segments - 1].attributes.add(str);
                    }
                    else if (str.isThereChar(":")) {
                        attribute_value = str.lastSegment(":");
                        str = strtok(str.getString(), ":");
                        if (T[segments - 1].attribute_names.findIndex(str) == -1) {
                            T[segments - 1].attribute_names.add(str);
                            T[segments - 1].attributes_count++;
                        }
                        T[segments - 1].attributes.add(str);
                        T[segments - 1].attributes.add(attribute_value);
                    }
                    else {
                        T[segments - 1].attributes.add(str);
                    }
                }
                else {
                    if (*(str.getFirstString()) == '{') {                            //check for beginning of attributes
                        if (*(str.getLastString()) != '{') {
                            str = str.lastSegment("{");
                            if (*(str.getLastString()) == ':' || *(str.get2ndLastString()) == ':') {
                                str = strtok(str.getString(), ":");
                                T[segments - 1].attribute_names.add(str);
                                T[segments - 1].attributes_count++;
                                T[segments - 1].attributes.add(str);
                            }
                            else {
                                attribute_value = str.lastSegment(":");
                                str = strtok(str.getString(), ":");
                                T[segments - 1].attribute_names.add(str);
                                T[segments - 1].attributes_count++;
                                T[segments - 1].attributes.add(str);
                                T[segments - 1].attributes.add(attribute_value);
                            }
                        }
                    }
                    else if (*(str.getLastString()) == '}' || (str.getSize() > 1 && *(str.get2ndLastString()) == '}')) {                        //check for end of segment
                        if (*(str.getFirstString()) != '}') {
                            str = strtok(str.getString(), "}");
                            T[segments - 1].attributes.add(str);
                        }
                        attributes = 0;
                        selectors = 1;
                        segments++;
                        if (segments >= slots) {
                            segment_struct* temp = new segment_struct[slots];                       //expanding the array of segments
                            for (int i = 0; i < slots; i++) {
                                temp[i] = T[i];
                            }
                            slots = slots * 2;
                            delete[] T;
                            T = new segment_struct[slots];
                            for (int i = 0; i < slots / 2; i++) {
                                T[i] = temp[i];
                            }
                            delete[] temp;

                        }
                    }
                }
            }
        }

        //reading commands
        if (commands == 1) {
            if (*str.getFirstString() == '?') {
                cout << "? == " << segments - 1 << endl;                        //cout amount of segments
            }
            else {
                if (str.isThereChar(",") == 0) {
                    cin >> temparr;
                    attribute_value = temparr;
                    double_command = 1;
                }
                while (double_command == 1) {
                    if (attribute_value.isThereChar(",") == 0) {
                        str = str.join(&attribute_value);
                        cin >> temparr;
                        attribute_value = temparr;
                    }
                    else {
                        str = str.join(&attribute_value);
                        double_command = 0;
                    }
                }
                if (str.countChar(",") == 1) {
                    cin >> temparr;
                    execute = 0;
                }
                else {
                    n = str.split(",", 1);
                    if (n.toInt() > 0) {                                                                     //is the first command segmnt an int
                        a = n.toInt();
                        n = str.split(",", 2);                                          //what to do
                        command = *n.getFirstString();
                        n = str.lastSegment(",");                                          //how many/which
                        j = n;
                        execute = 1;
                        number = 1;
                    }
                    else {                                                                                           //the first command segment is a name
                        selector = n;
                        n = str.split(",", 2);
                        command = *n.getFirstString();
                        n = str.lastSegment(",");                                          //how many/which
                        j = n;
                        execute = 1;
                        number = 0;
                    }
                }
            }
        }



        if (!strcmp(str.getString(), start_commands.getString())) {
            commands = 1;
        }

        //processing commands:
        if (execute == 1 && &command != nullptr) {
            execute = 0;
            if (command == 'D') {
                if (*j.getFirstString() == '*') {
                    //delete segment
                    if (segments > 1 && a < segments) {
                        segments--;
                        for (int i = a; i < slots; i++) {
                            T[i - 1] = T[i];
                        }
                        T[slots - 1].selectors.clear();
                        T[slots - 1].attributes.clear();
                        T[slots - 1].attribute_names.clear();
                        T[slots - 1].attributes_count = 0;
                        T[slots - 1].selectors_count = 0;
                        cout << a << "," << command << "," << j << " == deleted" << endl;
                    }
                }
                else {
                    //delete attribute j
                    if (T[a - 1].attribute_names.findIndex(j) != -1) {
                        a--;
                        tempint = T[a].attributes.findIndex(j);
                        tempint++;
                        str = (T[a].attributes).read(tempint);
                        while (*str.getLastString() != ';' && &str != nullptr) {
                            T[a].attributes.remove(tempint);
                            tempint++;
                            if ((T[a].attributes).getSize() >= tempint) {
                                str = (T[a].attributes).read(tempint);
                            }
                            else {
                                break;
                            }
                        }
                        if ((T[a].attributes).getSize() >= tempint) {
                            T[a].attributes.remove(tempint);
                        }
                        T[a].attributes.remove(T[a].attributes.findIndex(j));
                        tempint = T[a].attribute_names.findIndex(j);
                        T[a].attribute_names.deleteIndex(tempint);
                        T[a].attributes_count--;
                        if (T[a].attributes_count == 0 && segments > 1) {
                            segments--;
                            for (int i = a; i < slots - 1; i++) {
                                T[i] = T[i + 1];
                            }
                            T[slots - 1].selectors.clear();
                            T[slots - 1].attributes.clear();
                            T[slots - 1].attribute_names.clear();
                            T[slots - 1].attributes_count = 0;
                            T[slots - 1].selectors_count = 0;
                        }
                        a++;
                        cout << a << "," << command << "," << j << " == deleted" << endl;
                    }
                }
            }
            else if (command == 'S') {
                if (*j.getFirstString() == '?') {
                    if (number == 1) {
                        //cout amount of selectors in a
                        if (segments > a) {
                            cout << a << "," << command << "," << j << " == " << T[a - 1].selectors_count << endl;
                        }
                    }
                    else {
                        //cout amount of selectors in the whole css file
                        counter = 0;

                        for (int i = 0; i < segments; i++) {

                            if (&T[i] != nullptr && T[i].selectors.findIndex(selector) != -1) {
                                counter++;
                            }
                        }
                        cout << selector << "," << command << "," << j << " == " << counter << endl;

                    }
                }
                else {
                    //cout j-th selector for a 
                    temp_int_j = j.toInt();
                    if (a <= segments && &(T[a - 1].selectors) != nullptr && T[a - 1].selectors.getSize() >= temp_int_j && (T[a - 1].selectors).read(temp_int_j - 1) != nullptr) {
                        str = (T[a - 1].selectors).read(temp_int_j - 1);
                        if (&str == NULL || str == "error" || a > segments || T[a - 1].selectors.getSize() < temp_int_j) {
                        }
                        else {
                                cout << a << "," << command << "," << j << " == " << str << endl;
                            
                        }
                    }
                }
            }
            else if (command == 'E') {
                tempint = -1;
                for (int i = 0; i < segments; i++) {
                    if (T[i].selectors.findIndex(selector) != -1 && T[i].attributes.findIndex(j) != -1) {
                        a = i + 1;
                        tempint = T[i].attributes.findIndex(j);
                    }
                }
                if (tempint != -1) {
                    tempint++;
                    str = (T[a - 1].attributes).read(tempint);
                    if (str.getString() != "error" && &str != nullptr) {
                        cout << selector << "," << command << "," << j << " == ";
                        while (*str.getLastString() != ';') {
                            if (str.getString() == "error") {
                                break;
                            }
                            cout << str << " ";
                            tempint++;
                            str = (T[a - 1].attributes).read(tempint);
                        }
                        str = strtok(str.getString(), ";");
                        cout << str << endl;
                    }
                }
            }
            else if (command == 'A') {
                if (*j.getFirstString() == '?') {
                    if (number == 1) {
                        //cout amount of attributes in a
                        if (T[a - 1].attributes_count > 0) {
                            cout << a << "," << command << "," << j << " == " << T[a - 1].attributes_count << endl;
                        }
                    }
                    else {
                        //cout amount of attributes in the whole css file
                        counter = 0;
                        for (int i = 0; i < segments; i++) {
                            if (&T[i] != nullptr && T[i].attribute_names.findIndex(selector) != -1) {
                                counter++;
                            }
                        }
                        cout << selector << "," << command << "," << j << " == " << counter << endl;
                    }
                }
                else if (number == 1) {
                    //cout attribute values of an attribute 
                    tempint = T[a - 1].attributes.findIndex(j);
                    if (tempint != -1) {
                        tempint++;
                        str = (T[a - 1].attributes).read(tempint);
                        if (str.getString() != "error") {
                            cout << a << "," << command << "," << j << " == ";
                            while (*str.getLastString() != ';') {
                                if (str.getString() == "error") {
                                    break;
                                }
                                cout << str << " ";
                                tempint++;
                                str = (T[a - 1].attributes).read(tempint);
                            }
                            str = strtok(str.getString(), ";");
                            cout << str << endl;
                        }
                    }
                }
            }
        }
    }

    return 0;
}