#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class String {
private:
	char* string = nullptr;
	unsigned int size = 0;

public:

	String();

	String(const char* str);

	String(const String* str);

	unsigned int getSize() const;

	char* getString() const;

	char* getLastString() const;

	char* get2ndLastString() const;

	char* getFirstString() const;

	char* getStringByIndex(int i) const;

	int isThereChar(const char* divider);

	int compare(const String* str);

	int toInt();

	String split(const char* divider, int index);

	String lastSegment(const char* divider);

	int countChar(const char* symbol);

	void copy(const String* str);

	String join(const String* str);

	String& operator=(const String& str);

	String& operator=(const char* str);

	friend bool operator==(const String& lstring, const String& rstring);

	friend ostream& operator<<(ostream& ostr, const String& str);
};