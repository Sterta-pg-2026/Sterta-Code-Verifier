#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include"string.h"
using namespace std;

const int slots = 8;

class List {
private:
	struct Node {
		String strings[slots];
		bool used[slots]{};
		int used_count = 0;
		Node* prev = nullptr;
		Node* next = nullptr;
	};
	Node* first = nullptr;
	Node* last = nullptr;
	int size = 0;

public:

	void add(const String &str);

	String* read(int index) const;

	int getSize() const;

	void replace(const List& list2);

	void import(const List& list2);

	int findIndex(const String& str);

	int countAttributes();

	void deleteIndex(int index);

	void remove(int index);

	void clear();
};