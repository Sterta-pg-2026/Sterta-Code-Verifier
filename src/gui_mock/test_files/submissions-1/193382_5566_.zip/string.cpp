#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "string.h"
using namespace std;


String::String() {
	size = 0;
	string = nullptr;
}

String::String(const char* str) {
	size = strlen(str);
	string = new char[size + 1];
	strncpy_s(string, size + 1, str, size);
}

String::String(const String* str) {
	size = str->getSize();
	string = new char[size + 1];
	strncpy_s(string, size + 1, (*str).getString(), size);
}

unsigned int String::getSize() const {
	return size;
}

char* String::getString() const {
	return string;
}

char* String::getLastString() const {
	return &string[size - 1];
}

char* String::get2ndLastString() const {
	return &string[size - 2];
}

char* String::getFirstString() const {
	return &string[0];
}

char* String::getStringByIndex(int i) const {
	return &string[i];
}

int String::isThereChar(const char* divider) {
	for (int i = 0; i < size; i++) {
		if (*getStringByIndex(i) == *divider) {
			return 1;
		}
	}
	return 0;
}

int String::countChar(const char* symbol) {
	int counter = 0;
	for (int i = 0; i < size; i++) {
		if (string[i] == *symbol) {
			counter++;
		}
	}
	return counter;
}

int String::compare(const String* str) {
	if (size == (*str).getSize()) {
		for (int i = 0; i < size; i++) {
			if (&string[i] != (*str).getStringByIndex(i)) {
				return 0;
			}
		}
		return 1;
	}
	return 0;
}

int String::toInt() {
	int intstr = 0;
	if (!isdigit(string[0])) {
		return -1;
	}
	for (int i = 0; i < size; i++) {
		if (isdigit(string[i])) {
			intstr = intstr * 10 + (int(string[i]) - 48);
		}
		else {
			return intstr;
		}
	}
	return intstr;
}

String String::split(const char* divider, int index) {
	int local_index = 1;
	int deleted = 0, counter = 0;
	String return_string;
	for (int i = 0; i < size; i++) {
		if (*getStringByIndex(i) != *divider) {
			counter++;
		}
		else {
			if (local_index == index) {
				break;
			}
			else {
				counter++;
				local_index++;
				deleted = counter;
			}
		}
	}
	if (counter > 1) {
		if (counter - deleted > 1) {
			char* output = new char[counter - deleted];
			for (int i = 0; i < counter - deleted; i++) {
				output[i] = string[deleted + i];
			}
			output[counter - deleted] = 0;
			return_string = output;
		}
		else {
			char output[2] = { string[deleted], 0 };
			return_string = output;
		}
	}
	else {
		char output[2] = { *getFirstString(), 0 };
		return_string = output;
	}
	return return_string;
}

String String::lastSegment(const char* divider) {
	char* output;
	int counter = 0, temp_start;
	String final;
	for (int i = size - 1; i >= 0; i--) {
		if (string[i] != *divider) {
			counter++;
		}
		else {
			break;
		}
	}
	if (counter > 1) {
		output = new char[counter + 1];
		temp_start = size - counter;
		for (int i = 1; i <= counter; i++) {
			output[counter - i] = string[size - i];
		}
		output[counter] = 0;
	}
	else {
		output = new char[2];
		output[0] = string[size - 1];
		output[1] = '\0';
	}
	final = output;
	return final;
}

void String::copy(const String* str) {
	if (string == nullptr) {
		size = (*str).getSize();
		string = new char[size + 1];
	}
	else {
		delete[] string;
		size = (*str).getSize();
		string = new char[size + 1];
	}
	for (int i = 0; i < size; i++) {
		string[i] = *((*str).getStringByIndex(i));
	}
	string[size] = 0;
}

String String::join(const String* str) {
	if (str != nullptr) {
		int local_size = size + (*str).getSize() ;
		char* arr = new char[local_size];
		String final;
		for (int i = 0; i < size; i++) {
			arr[i] = string[i];
		}
		arr[size] = ' ';
		for (int i = 0; i < (*str).getSize(); i++) {
			arr[size + 1 + i] = *(*str).getStringByIndex(i);
		}
		arr[size + (*str).getSize() + 1] = 0;
		final = arr;
		return final;
	}
	return this;
}

String& String::operator=(const String& str) {
	if (&str != nullptr && str.getSize() > 0) {
		if (string == nullptr) {
			size = str.getSize();
			string = new char[size + 1];
		}
		else {
			delete[] string;
			size = str.getSize();
			string = new char[size + 1];
		}
		copy(&str);
		string[size] = 0;
		return *this;
	}
	else {
		return *this;
	}
}

String& String::operator=(const char* str) {
	size = strlen(str);
	string = new char[size + 1];
	for (int i = 0; i < size; i++) {
		string[i] = str[i];
	}
	string[size] = 0;
	return *this;
}

bool operator==(const String& lstring, const String& rstring) {
	if (!strcmp(lstring.getString(), rstring.getString())) {
		return 1;
	}
	return 0;
}

ostream& operator<<(ostream& ostr, const String& str) {
	ostr << str.getString();
	return ostr;
}

