#pragma once
#include "mystring.h"
#include "sllist.h"

constexpr size_t BLOCK_SIZE = 17;

struct Attribute {
	MyString name;
	MyString value;
};

struct Section {
	SLList<MyString> selectorlist;
	SLList<Attribute> attributeList;
};

struct Block {
	Section section[BLOCK_SIZE];
	size_t lastPos = 0;
	size_t size = 0;
};
