#pragma once
#include"blocklist.h"

class CSS_Parser
{ 
	enum class Mode {
		SELECTORS,
		ATTRIBUTE_NAME,
		ATTRIBUTE_VALUE,
		COMMAND
	} mode;
	Section sectionBuffer;
	MyString buffer1, buffer2;
	bool ignorews;
	List<Section> css;

	void clearSectionBuffer();
	bool isCharWS(char thisChar);

	void addSelector();
	void addAttribute();
	void handleCommand();
	bool CheckForAttributeDuplicate(const Attribute& checked);

	MyString getAttValueByName(size_t sectionIndex, const MyString& name);
	int getAttributeOccurances(const MyString& attributeName);
	int getSelectorOccurances(const MyString& selectorName);
	MyString getAttributeValueForSelector(const MyString & selectorName, const MyString & attributeName);

	void printAmountOfSections();
	void printAmountOfSelectorsForSection(size_t sectionIndex);
	void printAmountOfAttributesForSection(size_t sectionIndex);
	void printSelectorFromSection(size_t sectionIndex, size_t selectorIndex);
	void printAttributeValueFromSection(size_t sectionIndex, const MyString& attributeName);
	void printAttributeOccurances(const MyString& attributeName);
	void printSelectorOccurances(const MyString& selectorName);
	void printAttributeValueForSelector(const MyString& selectorName, const MyString& attributeName);

	void deleteSection(size_t sectionIndex);
	void deleteAttribute(size_t sectionIndex, const MyString& attributeName);

public:
	void getChar(char nextChar);
	CSS_Parser();
	~CSS_Parser();

};

