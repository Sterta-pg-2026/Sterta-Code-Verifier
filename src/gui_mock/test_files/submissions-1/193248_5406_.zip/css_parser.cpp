#include "css_parser.h"

CSS_Parser::CSS_Parser()
	: mode(Mode::SELECTORS), sectionBuffer(), buffer1(), buffer2(), ignorews(true), css()
{ }

void CSS_Parser::clearSectionBuffer()
{
	Section temp;
	temp.attributeList = static_cast<SLList<Attribute>&&>(sectionBuffer.attributeList);
	temp.selectorlist = static_cast<SLList<MyString>&&>(sectionBuffer.selectorlist);
}

bool CSS_Parser::isCharWS(char thisChar)
{
	if(thisChar == ' ' || thisChar == '\n' || thisChar == '\t' || thisChar == '\0')
		return true;
	return false;
}

void CSS_Parser::addSelector()
{
	buffer1.removeEdgeWS();
	if (buffer1.getSize() == 0)
		return;
	sectionBuffer.selectorlist.push_back(static_cast<MyString&&>(buffer1));
	buffer1.clear();
}

bool CSS_Parser::CheckForAttributeDuplicate(const Attribute& checked) {
	SLList<Attribute>::Node* curAttributeNode = sectionBuffer.attributeList.getFirstNode();

	for (int i = 0; i < sectionBuffer.attributeList.getSize(); i++) {
		if (curAttributeNode->value.name == checked.name) {
			curAttributeNode->value.value.clear();
			curAttributeNode->value.value = checked.value;
			return true;
		}
		curAttributeNode = SLList<Attribute>::getNextNode(curAttributeNode);
	}
	return false;
}

MyString CSS_Parser::getAttValueByName(size_t sectionIndex, const MyString & name)
{
	Section* curSection = &css[sectionIndex];
	SLList<Attribute>::Node* curAttributeNode = curSection->attributeList.getFirstNode();

	for (int i = 0; i < curSection->attributeList.getSize(); i++) {
		if (curAttributeNode->value.name == name)
			return curAttributeNode->value.value;
		curAttributeNode = SLList<Attribute>::getNextNode(curAttributeNode);
	}
	return MyString();
}

int CSS_Parser::getAttributeOccurances(const MyString & attributeName)
{
	int amount = 0;
	List<Section>::Node* curNode = css.getLastNode();
	Block* curBlock;
	SLList<Attribute>::Node* curAttributeNode;

	for (int i = css.getRealSize() - 1; i >= 0; i--) {
		curBlock = &curNode->value;
		for (int j = 0; j < BLOCK_SIZE; j++) {
			curAttributeNode = curBlock->section[j].attributeList.getFirstNode();
			for (int k = 0; k < curBlock->section[j].attributeList.getSize(); k++) {
				if (curAttributeNode->value.name == attributeName) {
					amount++;
					break;
				}
				curAttributeNode = SLList<Attribute>::getNextNode(curAttributeNode);
			}
		}
		curNode = css.getPrevNode(curNode);
	}
	return amount;
}

int CSS_Parser::getSelectorOccurances(const MyString& selectorName)
{
	int amount = 0;
	List<Section>::Node* curNode = css.getLastNode();
	Block* curBlock;
	SLList<MyString>::Node* curSelectorNode;

	for (int i = css.getRealSize()-1; i >= 0; i--) {
		curBlock = &curNode->value;
		for (int j = 0; j < BLOCK_SIZE; j++) {
			curSelectorNode = curBlock->section[j].selectorlist.getFirstNode();

			for (int k = 0; k < curBlock->section[j].selectorlist.getSize(); k++) {
				if (curSelectorNode->value == selectorName) {
					amount++;
					break;
				}
				curSelectorNode = SLList<MyString>::getNextNode(curSelectorNode);
			}
		}
		curNode = css.getPrevNode(curNode);
	}
	return amount;
}

MyString CSS_Parser::getAttributeValueForSelector(const MyString& selectorName, const MyString& attributeName)
{
	MyString value;
	List<Section>::Node* curNode = css.getLastNode();
	Block* curBlock;
	SLList<MyString>::Node* curSelectorNode;
	SLList<Attribute>::Node* curAttributeNode;

	for (int i = css.getRealSize() - 1; i >= 0; i--) {
		curBlock = &curNode->value;
		for (int j = BLOCK_SIZE-1; j >= 0; j--) {
			curSelectorNode = curBlock->section[j].selectorlist.getFirstNode();
			curAttributeNode = curBlock->section[j].attributeList.getFirstNode();

			// if no section under j index, continue
			if (curBlock->section[j].selectorlist.getSize() == 0 && curBlock->section[j].attributeList.getSize() == 0)
				continue;
			// global attributes:
			if (curBlock->section[j].selectorlist.getSize() == 0) {
				for (int attIndex = 0; attIndex < curBlock->section[j].attributeList.getSize(); attIndex++) {
					if (curAttributeNode->value.name == attributeName) {
						return curAttributeNode->value.value;
					}
					curAttributeNode = SLList<Attribute>::getNextNode(curAttributeNode);
				}
			}
			// normal section:
			for (int k = 0; k < curBlock->section[j].selectorlist.getSize(); k++) {
				if (curSelectorNode->value == selectorName) {
					for (int attIndex = 0; attIndex < curBlock->section[j].attributeList.getSize(); attIndex++) {
						if (curAttributeNode->value.name == attributeName) {
							return curAttributeNode->value.value;
						}
						curAttributeNode = SLList<Attribute>::getNextNode(curAttributeNode);
					}
				}
				curSelectorNode = SLList<MyString>::getNextNode(curSelectorNode);
			}
		}
		curNode = css.getPrevNode(curNode);
	}
	return MyString();
}


void CSS_Parser::addAttribute()
{
	Attribute attributeBuffer;
	buffer1.removeEdgeWS();
	attributeBuffer.name = static_cast<MyString&&>(buffer1);

	buffer2.removeEdgeWS();
	attributeBuffer.value = static_cast<MyString&&>(buffer2);

	buffer1.clear();
	buffer2.clear();

	if (CheckForAttributeDuplicate(attributeBuffer))
		return;

	sectionBuffer.attributeList.push_back(static_cast<Attribute&&>(attributeBuffer));
}

void CSS_Parser::printAmountOfSections() {
	std::cout << buffer1 << " == " << css.getSize() << '\n';
}

void CSS_Parser::printAmountOfSelectorsForSection(size_t sectionIndex) {
	sectionIndex -= 1;
	if (sectionIndex >= css.getSize()) {
		return;
	}
	std::cout << buffer1 << " == " << css[sectionIndex].selectorlist.getSize() << '\n';
}

void CSS_Parser::printAmountOfAttributesForSection(size_t sectionIndex)
{
	sectionIndex -= 1;
	if (sectionIndex >= css.getSize()) {
		return;
	}	
	std::cout << buffer1 << " == " << css[sectionIndex].attributeList.getSize() << '\n';
}

void CSS_Parser::printSelectorFromSection(size_t sectionIndex, size_t selectorIndex)
{
	sectionIndex -= 1;
	selectorIndex -= 1;
	if (sectionIndex >= css.getSize() || selectorIndex >= css[sectionIndex].selectorlist.getSize())
		return;
	std::cout << buffer1 << " == " << css[sectionIndex].selectorlist[selectorIndex] << '\n';
}

void CSS_Parser::printAttributeValueFromSection(size_t sectionIndex, const MyString & attributeName)
{
	sectionIndex -= 1;
	if (sectionIndex >= css.getSize())
		return;
	MyString value = getAttValueByName(sectionIndex, attributeName);
	if (value.getSize() == 0)
		return;
	std::cout << buffer1 << " == " << value << '\n';
}

void CSS_Parser::printAttributeOccurances(const MyString & attributeName)
{
	std::cout << buffer1 << " == " << getAttributeOccurances(attributeName) << '\n';
}

void CSS_Parser::printSelectorOccurances(const MyString & selectorName)
{
	std::cout << buffer1 << " == " << getSelectorOccurances(selectorName) << '\n';
}

void CSS_Parser::printAttributeValueForSelector(const MyString & selectorName, const MyString & attributeName)
{
	MyString value = getAttributeValueForSelector(selectorName, attributeName);
	if (value.getSize() == 0)
		return;
	std::cout << buffer1 << " == " << value << '\n';
}

void CSS_Parser::deleteSection(size_t sectionIndex)
{
	sectionIndex -= 1;
	if (sectionIndex >= css.getSize())
		return;
	css.deleteOne(sectionIndex);
	std::cout << buffer1 << " == deleted\n";
}

void CSS_Parser::deleteAttribute(size_t sectionIndex, const MyString & attributeName)
{
	sectionIndex -= 1;
	bool deleted = false;
	if (sectionIndex >= css.getSize())
		return;
	Section* curSection = &css[sectionIndex];
	for (int i = curSection->attributeList.getSize()-1; i >= 0; i--) {
		if (curSection->attributeList[i].name == attributeName) {
			curSection->attributeList.deleteOne(i);
			deleted = true;
			break;
		}
	}
	if(deleted && curSection->attributeList.getSize() == 0)
		css.deleteOne(sectionIndex);
	if(deleted)
		std::cout << buffer1 << " == deleted\n";
}


void CSS_Parser::handleCommand()
{
	buffer1.removeEdgeWS();

	MyString firstPart = buffer1.getFieldBySeparator(',', 0);
	MyString secondPart = buffer1.getFieldBySeparator(',', 1);
	MyString thirdPart = buffer1.getFieldBySeparator(',', 2);
	
	if (firstPart == "?")
		printAmountOfSections();
	else if (firstPart.isNumber()) {
		if (secondPart == "S" && thirdPart == "?")
			printAmountOfSelectorsForSection(firstPart.toNumber());
		else if (secondPart == "S" && thirdPart.isNumber())
			printSelectorFromSection(firstPart.toNumber(), thirdPart.toNumber());
		else if (secondPart == "A" && thirdPart == "?")
			printAmountOfAttributesForSection(firstPart.toNumber());
		else if (secondPart == "A")
			printAttributeValueFromSection(firstPart.toNumber(), thirdPart);
		else if (secondPart == "D", thirdPart == "*")
			deleteSection(firstPart.toNumber());
		else if (secondPart == "D")
			deleteAttribute(firstPart.toNumber(), thirdPart);
	}
	else if (secondPart == "A" && thirdPart == "?")
		printAttributeOccurances(firstPart);
	else if (secondPart == "S" && thirdPart == "?")
		printSelectorOccurances(firstPart);
	else if (secondPart == "E")
		printAttributeValueForSelector(firstPart, thirdPart);
	buffer1.clear();
}

void CSS_Parser::getChar(char nextChar)
{
	if (ignorews && isCharWS(nextChar))
		return;
	ignorews = false;

	if (mode != Mode::COMMAND) {
		switch (nextChar) {
		case '{': mode = Mode::ATTRIBUTE_NAME;
			addSelector();
			ignorews = true;
			return;
		case '}': mode = Mode::SELECTORS;
			if (buffer2.getSize() != 0)
				addAttribute();
			css.push_back(sectionBuffer);
			clearSectionBuffer();
			ignorews = true;
			return;
		case ';': mode = Mode::ATTRIBUTE_NAME;
			addAttribute();
			ignorews = true;
			return;
		case ':':
			if (mode != Mode::ATTRIBUTE_NAME)
				break;
			mode = Mode::ATTRIBUTE_VALUE;
			ignorews = true;
			return;
		case ',':
			if (mode != Mode::SELECTORS)
				break;
			addSelector();
			ignorews = true;
			return;
		}
	}

	switch (mode) {
	case Mode::SELECTORS:
	case Mode::ATTRIBUTE_NAME:
	case Mode::COMMAND:
		buffer1.push_back(nextChar);
		break;
	case Mode::ATTRIBUTE_VALUE:
		buffer2.push_back(nextChar);
		return;
	}

	if (buffer1.getSize() == 4) {
		if (buffer1 == "????") {
			mode = Mode::COMMAND;
			buffer1.clear();
			buffer2.clear();
			ignorews = true;
		}
		else if (buffer1 == "****") {
			mode = Mode::SELECTORS;
			buffer1.clear();
			buffer2.clear();
			ignorews = true;
		}
	}

	if (mode == Mode::COMMAND && isCharWS(nextChar) && nextChar != ' ') {
		handleCommand();
		buffer1.clear();
		ignorews = true;
		return;
	}
}

CSS_Parser::~CSS_Parser()
{
	if (mode == Mode::COMMAND)
		handleCommand();
}
