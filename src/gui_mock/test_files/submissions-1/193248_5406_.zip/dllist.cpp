#include"dllist.h"
#include <iostream>

template<typename T>
List<T>::List(const List& right) : List<T>::List()
{
	const Node* curNode = &right.first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		push_back(curNode->value);
	}
}

template<typename T>
List<T>::List(List && right) : List<T>::List()
{
	size = right.size;
	first.next = right.first.next;
	right.size = 0;
	right.first.next = nullptr;
	if (size >= 1) {
		this->first.next->prev = &this->first;
	}
}

template<typename T>
List<T>& List<T>::operator=(const List& right)
{
	List<T> temp(right);
	size = temp.size;
	first.next = temp.first.next;
	temp.size = 0;
	temp.first.next = nullptr;
	if (size >= 1) {
		this->first.next->prev = &this->first;
	}
	return *this;
}

template<typename T>
List<T>& List<T>::operator=(List&& right)
{
	size = right.size;
	first.next = right.first.next;
	right.size = 0;
	right.first.next = nullptr;
	if (size >= 1) { 
		first.next->prev = &first;
	}
	return *this;
}

template<typename T>
typename List<T>::Node* List<T>::getLastNode() {
	Node* last = &first;
	while (last->next != nullptr) {
		last = last->next;
	}
	return last;
}

template<typename T>
T& List<T>::operator[](size_t index) {
	Node* element = &first;
	if (index >= size)
		throw;
	do {
		element = element->next;
	} while (index--);
	return element->value;
}

template<typename T>
void List<T>::deleteOne(size_t index)
{
	Node* deletedNode = &first;
	if (index >= size)
		throw;
	do {
		deletedNode = deletedNode->next;
	} while (index--);
	deletedNode->prev->next = deletedNode->next;
	if (deletedNode->next != nullptr)
		deletedNode->next->prev = deletedNode->prev;
	delete deletedNode;
	size--;
}

template<typename T>
void List<T>::pop_back() {
	if (size == 0)
		return;
	if (size == 1)
		first.next->prev = &first;
	Node* last = getLastNode();
	last->prev->next = nullptr;
	delete last;
	size--;
}

template<typename T>
List<T>::~List() {
	while (size && first.next != nullptr) {
		pop_back();
	}
}

template<typename T>
void List<T>::push_back(const T& pushedValue) {
	Node* newNode = new Node;
	Node* last = getLastNode();
	last->next = newNode;
	newNode->next = nullptr;
	newNode->prev = last;
	newNode->value = pushedValue;
	size++;
}


template<typename T>
bool operator==(const List<T>& left, const List<T>& right)
{
	if (left.size != right.size)
		return false;
	const typename List<T>::Node* leftNode = &left.first;
	const typename List<T>::Node* rightNode = &right.first;
	while (leftNode->next != nullptr) {
		leftNode = leftNode->next;
		rightNode = rightNode->next;
		if (leftNode->value != rightNode->value)
			return false;
	}
	return true;
}

template<typename T>
bool operator!=(const List<T>& left, const List<T>& right)
{
	if (left == right)
		return false;
	return true;
}


template<typename T>
std::ostream& operator<<(std::ostream& stream, const List<T>& list)
{
	const typename List<T>::Node* curNode = &list.first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		stream << curNode->value << ',';
	}
	std::cout << std::endl;
	return stream;
}

