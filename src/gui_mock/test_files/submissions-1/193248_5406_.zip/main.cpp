#include<iostream>
#include"css_parser.h"

#define MAX_LINE_SIZE 256

int main()
{
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(NULL);
	CSS_Parser parser;
	char buf[MAX_LINE_SIZE];
	int i = 0;
	while (std::cin.getline(buf, MAX_LINE_SIZE, '\n')) {
		for (i = 0; buf[i] != '\0'; i++) {
			parser.getChar(buf[i]);
		}
		parser.getChar(buf[i]);
	}
	return 0;
}