#include "mystring.h"
#include"cmath"

MyString::MyString(MyString&& orig)
{
	size = orig.size;
	string = orig.string;
	orig.string = nullptr;
	orig.size = 0;
}

MyString::MyString(const MyString& orig)
{
	size = orig.size;
	string = new char[size];
	for (size_t i = 0; i < size; i++)
		string[i] = orig.string[i];
}

bool MyString::isWS(char thisChar)
{
	if (thisChar == '\r' || thisChar == '\n' || thisChar == '\t' || thisChar == ' ' || thisChar == '\0')
		return true;
	return false;
}

void MyString::removeEdgeWS()
{
	size_t newSize = size;
	size_t offset = 0;
	while (newSize > 0 && isWS(string[newSize - 1]))
		newSize--;
	while (offset < newSize && isWS(string[offset]))
		offset++;
	if (newSize == 0) {
		delete[] string;
		string = nullptr;
		size = 0;
	}
	newSize -= offset;
	char* buf = new char[newSize];
	size = newSize;
	for (size_t i = 0; i < newSize; i++)
		buf[i] = string[i+offset];
	delete[] string;
	string = buf;
}

void MyString::push_back(const char& character)
{
	char* buf = new char[size + 1];
	for (size_t i = 0; i < size; i++)
		buf[i] = string[i];
	buf[size] = character;
	delete[] string;
	string = buf;
	size++;
}

void MyString::clear()
{
	if (string == nullptr)
		return;
	delete[] string;
	string = nullptr;
	size = 0;
}

bool MyString::isNumber() const
{
	for (size_t i = 0; i < size; i++) {
		if (string[i] < '0' || string[i] > '9')
			return false;
	}
	return true;
}

int MyString::toNumber()
{
	if (!isNumber() || size == 0)
		throw;
	int value = 0;
	for (int i = size-1; i >= 0; i--) {
		value += (string[i] - '0') * round(pow(10, size-1-i));
	}
	return value;
}

MyString MyString::getFieldBySeparator(char separator, size_t field)
{
	size_t fieldSize, curField = 0;	
	MyString returnedString;

	for (fieldSize = 0; fieldSize < size; fieldSize++) {
		if (string[fieldSize] == separator) {
			if (curField == field)
				break;
			curField++;
			continue;
		}
		if(curField == field)
			returnedString.push_back(string[fieldSize]);
	}
	returnedString.removeEdgeWS();
	return returnedString;
}

char& MyString::operator[](size_t index)
{
	if (string == nullptr || index >= size)
		throw;
	return string[index];
}

MyString & MyString::operator=(const MyString & right)
{
	MyString temp(right);
	size = temp.size;
	string = temp.string;
	temp.size = 0;
	temp.string = nullptr;
	return *this;
}

MyString & MyString::operator=(MyString && right)
{
	size = right.size;
	string = right.string;
	right.size = 0;
	right.string = nullptr;
	return *this;
}


MyString::~MyString()
{
	if (string == nullptr)
		return;
	delete[] string;
}

std::ostream& operator<<(std::ostream& stream, const MyString& object)
{
	for (size_t i = 0; i < object.size; i++)
		stream << object.string[i];
	return stream;
}

bool operator==(const MyString& left, const MyString& right) 
{
	if (left.size != right.size)
		return false;
	for (size_t i = 0; i < left.size; i++) {
		if (left.string[i] != right.string[i])
			return false;
	}
	return true;
}

bool operator==(const MyString& left, const char* right) {
	for (size_t i = 0; i < left.size; i++) {
		if (right[i] == '\0')
			return false;
		if (left.string[i] != right[i])
			return false;
	}
	if (right[left.size] != '\0')
		return false;
	return true;
}

