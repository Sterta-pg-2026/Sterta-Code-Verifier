#include"blocklist.h"

List<Section>::List(List<Section>&& right) : List<Section>::List()
{
	size = right.size;
	first.next = right.first.next;
	right.size = 0;
	right.first.next = nullptr;
	if (size >= 1) {
		first.next->prev = &first;
	}
}


List<Section>& List<Section>::operator=(const List<Section>& right)
{
	List<Section> temp(right);
	size = temp.size;
	first.next = temp.first.next;
	temp.size = 0;
	temp.first.next = nullptr;
	if (size >= 1) {
		first.next->prev = &first;
	}
	return *this;
}


List<Section>& List<Section>::operator=(List<Section>&& right)
{
	size = right.size;
	first.next = right.first.next;
	right.size = 0;
	right.first.next = nullptr;
	if (size >= 1) {
		first.next->prev = &first;
	}
	return *this;
}


typename List<Section>::Node* List<Section>::getLastNode() {
	Node* last = &first;
	while (last->next != nullptr) {
		last = last->next;
	}
	return last;
}

void List<Section>::setCorrectLastPos(Node* curNode)
{
	while (curNode->value.lastPos != 0) {
		curNode->value.lastPos--;
		if (curNode->value.section[curNode->value.lastPos].attributeList.getSize() != 0
			|| curNode->value.section[curNode->value.lastPos].selectorlist.getSize() != 0) {
			break;
		}
	}
}

typename List<Section>::Node* List<Section>::getCurrentNode(size_t index) {
	Node* element = first.next;
	if (index >= getSize())
		throw;
	while (index >= element->value.size) {
		index -= element->value.size;
		element = element->next;
	}
	return element;
}

typename List<Section>::Node* List<Section>::getPrevNode(List<Section>::Node* curNode) {
	if (curNode->prev == nullptr)
		throw;
	return curNode->prev;
}


size_t List<Section>::getCurrentSectionIndex(size_t index) const
{
	Node* curNode = first.next;
	if (index >= getSize())
		throw;
	while (index >= curNode->value.size) {
		index -= curNode->value.size;
		curNode = curNode->next;
	}
	if (index >= curNode->value.size)
		throw;
	for (size_t i = 0; i <= curNode->value.lastPos; i++) {
		if (curNode->value.section[i].attributeList.getSize() != 0
			|| curNode->value.section[i].selectorlist.getSize() != 0) {
			if (index == 0) {
				return i;
			}
			index--;
		}
	}
	throw;
}

List<Section>::List(const List<Section>& right) : List<Section>::List()
{
	const Node* curNode = &right.first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		for (size_t i = 0; i < curNode->value.lastPos; i++) {
			push_back(curNode->value.section[i]);
		}
	}
}

Section& List<Section>::operator[](size_t index) {
	Node* element = &first;
	if (index >= getSize())
		throw;
	element = getCurrentNode(index);
	int _index = getCurrentSectionIndex(index);
	return element->value.section[_index];
}

inline size_t List<Section>::getSize() const {
	size_t realSize = 0;
	const Node* curNode = &first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		realSize += curNode->value.size;
	}
	return realSize;
}


void List<Section>::deleteOne(size_t index)
{
	if (index >= getSize())
		throw;
	Node* deletedNode = getCurrentNode(index);
	size_t currentSectionIndex = getCurrentSectionIndex(index);

	// swap lists with empty lists so that destructors work properly
	Section temp;
	temp.attributeList = static_cast<SLList<Attribute>&&>(deletedNode->value.section[currentSectionIndex].attributeList);
	temp.selectorlist = static_cast<SLList<MyString>&&>(deletedNode->value.section[currentSectionIndex].selectorlist);

	deletedNode->value.size--;

	if (deletedNode->value.lastPos == currentSectionIndex)
		setCorrectLastPos(deletedNode);

	if (deletedNode->value.size > 0)
		return;

	// if node is empty, delete the node
	deletedNode->prev->next = deletedNode->next;
	if (deletedNode->next != nullptr)
		deletedNode->next->prev = deletedNode->prev;
	delete deletedNode;
	size--;
}

void List<Section>::pop_back() {
	if (size == 0)
		return;
	if (size == 1 && first.next->value.lastPos == 0) 
		first.next->prev = &first;
	Node* last = getLastNode();

	// swap lists with empty lists so that destructors work properly
	Section temp;
	temp.attributeList = static_cast<SLList<Attribute>&&>(last->value.section[last->value.lastPos].attributeList);
	temp.selectorlist = static_cast<SLList<MyString>&&>(last->value.section[last->value.lastPos].selectorlist);

	last->value.size--;
	setCorrectLastPos(last);

	if (last->value.size > 0)
		return;

	size--;
	last->prev->next = nullptr;
	delete last;
}


List<Section>::~List() {

	while (size && first.next != nullptr) {
		pop_back();
	}
}

void List<Section>::push_back(const Section& pushedValue) {
	Node* last = getLastNode();
	Section temp(pushedValue);

	if (last->value.lastPos != (BLOCK_SIZE-1) && size != 0) {
		last->value.section[last->value.lastPos + 1] = static_cast<Section&&>(temp);
		last->value.lastPos++;
		last->value.size++;
		return;
	}

	Node* newNode = new Node;
	last->next = newNode;
	newNode->next = nullptr;
	newNode->prev = last;
	newNode->value.section[0] = static_cast<Section&&>(temp);
	newNode->value.size = 1;
	newNode->value.lastPos = 0;
	size++;
}
