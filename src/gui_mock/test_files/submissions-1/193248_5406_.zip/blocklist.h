#pragma once
#include<iostream>
#include"dllist.h"

template<>
class List<Section> {
public:
	struct Node {
		Node* next;
		Node* prev;
		Block value;
	};
private:
	Node first;
	size_t size; // refers to num_of_blocks

	// sets the lastPos value in a Block to last elements index
	void setCorrectLastPos(Node* curNode);
	Node* getCurrentNode(size_t index);
	// gets (index) section's real index (the one inside the Block->section[] array) in its specific block/node
	size_t getCurrentSectionIndex(size_t index) const;
public:

	List() : first({ nullptr, nullptr, {} }), size(0) {};
	List(const List<Section>& right);
	List(List<Section>&& right);
	List<Section>& operator=(const List<Section>& right);
	List<Section>& operator=(List<Section>&& right);

	Node* getLastNode();
	Node* getPrevNode(Node* curNode);
	void push_back(const Section& pushedValue);
	void pop_back();
	void deleteOne(size_t index);
	Section& operator[](size_t index);
	// returns number of non-empty Sections in the List
	size_t getSize() const;
	// returns number of Nodes/Blocks in the List
	size_t getRealSize() const { return size; };
	~List();
};
