#pragma once
#include<iostream>
#include"structs.h"

template<typename T>
class List {
	struct Node {
		Node* next;
		Node* prev;
		T value;
	} first;
	size_t size;
public:
	List() : first({ nullptr, nullptr, {} }), size(0) {};
	List(const List& right);
	List(List&& right);
	List& operator=(const List& right);
	List& operator=(List&& right);

	Node* getLastNode();
	void push_back(const T& pushedValue);
	void pop_back();
	void deleteOne(size_t index);
	T& operator[](size_t index);
	size_t getSize() const { return size; };
	~List();
	friend bool operator==(const List<T>& left, const List<T>& right);
	friend bool operator!=(const List<T>& left, const List<T>& right);
	template<typename _T>
	friend std::ostream& operator<<(std::ostream& stream, const List<_T>& list);
};


