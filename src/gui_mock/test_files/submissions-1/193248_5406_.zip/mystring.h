#pragma once
#include<iostream>

class MyString {
	char* string;
	size_t size;
public:
	MyString() : string(nullptr), size(0) {};
	MyString(MyString&& orig);
	MyString(const MyString& orig);

	bool isWS(char thisChar);
	void removeEdgeWS();
	void push_back(const char& character);
	void clear();
	bool isNumber() const;
	int toNumber();
	MyString getFieldBySeparator(char separator, size_t field);
	size_t getSize() { return size; };
	char& operator[](size_t index);
	MyString& operator=(const MyString& right);
	MyString& operator=(MyString&& right);
	friend bool operator==(const MyString& left, const MyString& right);
	friend bool operator==(const MyString& left, const char* right);
	friend std::ostream& operator<<(std::ostream& stream, const MyString& object);


	~MyString();
};
