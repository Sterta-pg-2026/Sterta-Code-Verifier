#pragma once
#include<iostream>

template<typename T>
class SLList {
public:
	struct Node {
		Node* next;
		T value;
	};
private:
	Node first;
	size_t size;
public:
	SLList() : first({ nullptr, {} }), size(0) {};
	SLList(const SLList& right);
	SLList(SLList&& right);
	SLList& operator=(const SLList& right);
	SLList& operator=(SLList&& right);

	Node* getFirstNode() { return first.next; };
	Node* getAlmostLastNode();
	static Node* getNextNode(Node* curNode) { return curNode->next; };
	void push_back(const T& pushedValue);
	void push_back(T&& pushedValue);
	void pop_back();
	void deleteOne(size_t index);
	T& operator[](size_t index);
	size_t getSize() const { return size; };
	~SLList();
	friend bool operator==(const SLList<T>& left, const SLList<T>& right);
	friend bool operator!=(const SLList<T>& left, const SLList<T>& right);
	template<typename _T>
	friend std::ostream& operator<<(std::ostream& stream, const SLList<_T>& list);
};

template<typename T>
SLList<T>::SLList(const SLList& right) : SLList<T>::SLList()
{
	const Node* curNode = &right.first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		push_back(curNode->value);
	}
}

template<typename T>
SLList<T>::SLList(SLList && right) : size(right.size), first(right.first)
{
	right.size = 0;
	right.first.next = nullptr;
}

template<typename T>
SLList<T>& SLList<T>::operator=(const SLList& right)
{
	SLList<T> temp(right);
	first.next = temp.first.next;
	size = temp.size;
	temp.size = 0;
	temp.first.next = nullptr;
	return *this;
}

template<typename T>
SLList<T>& SLList<T>::operator=(SLList&& right)
{
	first.next = right.first.next;
	size = right.size;
	right.size = 0;
	right.first.next = nullptr;
	return *this;
}

template<typename T>
T& SLList<T>::operator[](size_t index) {
	Node* element = &first;
	if (index >= size)
		throw;
	do {
		element = element->next;
	} while (index--);
	return element->value;
}


template<typename T>
void SLList<T>::push_back(const T & pushedValue)
{
	Node* newNode = new Node;
	Node* last = getAlmostLastNode()->next;
	if (size == 0)
		last = &first;
	last->next = newNode;
	newNode->next = nullptr;
	newNode->value = pushedValue;
	size++;
}

template<typename T>
void SLList<T>::push_back(T && pushedValue)
{
	Node* newNode = new Node;
	Node* last = getAlmostLastNode()->next;
	if (size == 0)
		last = &first;
	last->next = newNode;
	newNode->next = nullptr;
	newNode->value = static_cast<T&&>(pushedValue);
	size++;
}

template<typename T>
void SLList<T>::pop_back()
{
	if (size == 0)
		return;
	Node* preLast = getAlmostLastNode();
	delete preLast->next;
	preLast->next = nullptr;
	size--;
}

template<typename T>
void SLList<T>::deleteOne(size_t index)
{
	Node* nodeBeforeDeleted = &first;
	if (index >= size)
		throw;
	while (index--) {
		nodeBeforeDeleted = nodeBeforeDeleted->next;
	}
	Node* trash = nodeBeforeDeleted->next;
	nodeBeforeDeleted->next = nodeBeforeDeleted->next->next;
	delete trash;

	size--;
}

template<typename T>
typename SLList<T>::Node* SLList<T>::getAlmostLastNode() {
	Node* preLast = &first;
	if (size == 0)
		return preLast;
	while (preLast->next->next != nullptr) {
		preLast = preLast->next;
	}
	return preLast;
}

template<typename T>
SLList<T>::~SLList() {
	while (size) {
		pop_back();
	}
}

template<typename T>
bool operator==(const SLList<T>& left, const SLList<T>& right)
{
	if (left.size != right.size)
		return false;
	const typename SLList<T>::Node* leftNode = &left.first;
	const typename SLList<T>::Node* rightNode = &right.first;
	while (leftNode->next != nullptr) {
		leftNode = leftNode->next;
		rightNode = rightNode->next;
		if (!(leftNode->value == rightNode->value))
			return false;
	}
	return true;
}

template<typename T>
bool operator!=(const SLList<T>& left, const SLList<T>& right)
{
	if (left == right)
		return false;
	return true;
}


template<typename T>
std::ostream& operator<<(std::ostream& stream, const SLList<T>& list)
{
	const typename SLList<T>::Node* curNode = &list.first;
	while (curNode->next != nullptr) {
		curNode = curNode->next;
		stream << curNode->value << ',';
	}
	std::cout << std::endl;
	return stream;
}
