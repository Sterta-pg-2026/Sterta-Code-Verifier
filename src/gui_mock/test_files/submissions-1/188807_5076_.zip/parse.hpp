#pragma once
#include "config.hpp"
#include "css.hpp"
#include "helpers.cpp"
#include <iostream>
#include <string.h>

namespace Parse {

void reallocBuilder(char **builder, int times);
    
char **tokenize(char *input, const char *keychars, bool insideBrackets);

} // namespace Parse