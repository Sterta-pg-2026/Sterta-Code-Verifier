#pragma once
inline const int T = 111; 
inline const int MAX_DEFAULT_LENGTH = 250;
inline const int REALLOC_EVERY = 50;
inline const char *delimiters = ",";
