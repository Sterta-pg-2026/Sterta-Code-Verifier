#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include <new>
#define MAXSIZE 17
#define BUFFERSIZE 150
#define ARGS 2
using namespace std;

struct CSSselector {
	char* name;
	CSSselector* next;
};

struct CSSattribute {
	char* property;
	char* value;
	CSSattribute* next;
};

struct CSSsection {
	int selectors_size;
	int attributes_size;
	CSSselector* selectors;
	CSSattribute* attributes;
};

struct CSSlist {
	int taken_cells;
	CSSsection* sections[MAXSIZE];
	CSSlist* previous;
	CSSlist* next;
};

struct CSSlast {
	CSSselector* selector;
	CSSattribute* attribute;
};

struct CSScommand {
	bool full;
	bool command;
	int n[ARGS];
	char type;
	char* string[ARGS];
};

CSSselector* init_selector(char* name = '\0', CSSselector* next = nullptr) {
	CSSselector* tmp = new CSSselector;
	if (tmp == nullptr) return nullptr;
	tmp->name = name;
	tmp->next = next;
	return tmp;
}

CSSattribute* init_attribute(char* property = '\0', char* value = '\0', CSSattribute* next = nullptr) {
	CSSattribute* tmp = new CSSattribute;
	if (tmp == nullptr) return nullptr;
	tmp->property = property;
	tmp->value = value;
	tmp->next = next;
	return tmp;
}

CSSsection* init_section(CSSselector* selectors = nullptr, CSSattribute* attributes = nullptr, const int selector_counter = 0, const int attribute_counter = 0) {
	CSSsection* tmp = new CSSsection;
	if (tmp == nullptr) return nullptr;
	tmp->selectors_size = selector_counter;
	tmp->attributes_size = attribute_counter;
	tmp->selectors = selectors;
	tmp->attributes = attributes;
	return tmp;
}

CSSlist* init_list(CSSlist* previous = nullptr, CSSlist* next = nullptr, CSSsection* sections = nullptr, const int taken_cells = 0) {
	CSSlist* tmp = new CSSlist;
	if (tmp == nullptr) return nullptr;
	tmp->taken_cells = taken_cells;
	for (int i = 0; i < MAXSIZE; i++) tmp->sections[i] = new CSSsection;
	tmp->sections[0] = sections;
	tmp->previous = previous;
	tmp->next = next;
	return tmp;
}

CSSlast init_last(CSSselector* last_selector, CSSattribute* last_attribute) {
	CSSlast tmp;
	tmp.selector = last_selector;
	tmp.attribute = last_attribute;
	return tmp;
}

CSScommand* init_command(const bool full = false, const bool command = false, const char type = '\0') {
	CSScommand* tmp = new CSScommand;
	if (tmp == nullptr) return nullptr;
	tmp->full = full;
	tmp->command = command;
	tmp->type = type;
	for (int i = 0; i < ARGS; i++) {
		tmp->n[i] = 0;
		tmp->string[i] = new char[BUFFERSIZE];
		strcpy(tmp->string[i], "\0");
	}
	return tmp;
}

CSSselector* add_after(CSSselector* begining, char* name) {
	begining->next = init_selector(name);
	return begining->next;
}

CSSattribute* add_after(CSSattribute* begining, char* property, char* value) {
	begining->next = init_attribute(property, value);
	return begining->next;
}

CSSselector* make_copy(CSSselector* original) {
	return init_selector(original->name, original->next);
}

CSSattribute* make_copy(CSSattribute* original) {
	return init_attribute(original->property, original->value, original->next);
}

void delete_selector(CSSselector* selectors) {
	CSSselector* tmp = init_selector();
	while (selectors != nullptr) {
		tmp = selectors;
		selectors = selectors->next;
		delete tmp;
	}
}

void delete_attribute(CSSattribute* attributes) {
	CSSattribute* tmp = init_attribute();
	while (attributes != nullptr) {
		tmp = attributes;
		attributes = attributes->next;
		delete tmp;
	}
}

void delete_section(CSSsection* section) {
	delete_selector(section->selectors);
	delete_attribute(section->attributes);
	delete section;
}

void delete_command(CSScommand* cmd) {
	for (int i = 0; i < ARGS; i++) delete[] cmd->string[i];
	delete cmd;
}

void delete_list(CSSlist* list) {
	CSSlist* tmp = init_list();
	while (list != nullptr) {
		tmp = list;
		for (int i = 0; i < list->taken_cells; i++) delete_section(tmp->sections[i]);
		list = list->next;
		delete tmp;
	}
}

#ifdef PRINT
ostream& operator<<(ostream& out, CSSselector* element) {
	out << element->name;
	return out;
}

ostream& operator<<(ostream& out, CSSattribute* element) {
	out << element->property << ": " << element->value;
	return out;
}

ostream& operator<<(ostream& out, CSSsection* section) {
	for (int i = 0; i < section->selectors_size; i++) {
		section->selectors = section->selectors->next;
		out << section->selectors << ' ';
	}
	out << endl;
	for (int i = 0; i < section->attributes_size; i++) {
		section->attributes = section->attributes->next;
		out << section->attributes << endl;
	}
	return out;
}

ostream& operator<<(ostream& out, CSSlist* list) {
	while (list->next != nullptr) {
		list = list->next;
		for (int i = 0; i < list->taken_cells; i++) out << list->sections[i] << endl;
	}
	return out;
}
#endif

bool remove_duplicate(CSSselector* selector, CSSselector* last) {
	CSSselector* previous = selector;
	selector = selector->next;
	while (strcmp(selector->name, last->name) && selector->next != nullptr) {
		previous = selector;
		selector = selector->next;
	}
	if (selector == last) return false;
	previous->next = selector->next;
	delete selector;
	return true;
}

CSSselector* write_selector(CSSselector* selector, CSSselector* last, char* buffer, int* selector_counter, int* i) {
	if (*i == 0) return last;
	char* name = new char[*i];
	while (isspace(buffer[*i - 1])) (*i)--;
	buffer[*i] = '\0';
	strcpy(name, buffer);
	memset(buffer, '\0', BUFFERSIZE);
	*i = 0;
	CSSselector* new_last = add_after(last, name);
	if (!remove_duplicate(selector, new_last)) (*selector_counter)++;
	return new_last;
}

bool remove_duplicate(CSSattribute* attribute, CSSattribute* last) {
	CSSattribute* previous = attribute;
	attribute = attribute->next;
	while (strcmp(attribute->property, last->property) && attribute->next != nullptr) {
		previous = attribute;
		attribute = attribute->next;
	}
	if (attribute == last) return false;
	previous->next = attribute->next;
	delete attribute;
	return true;
}

CSSattribute* write_attribute_p(CSSattribute* attribute, CSSattribute* last, char* buffer, int* attribute_counter, int* i) {
	char* property = new char[*i];
	buffer[*i] = '\0';
	strcpy(property, buffer);
	memset(buffer, '\0', BUFFERSIZE);
	*i = 0;
	CSSattribute* new_last = add_after(last, property, nullptr);
	if (!remove_duplicate(attribute, new_last)) (*attribute_counter)++;
	return new_last;
}

void write_attribute_v(CSSattribute* last, char* buffer, int* i) {
	char* value = new char[*i];
	buffer[*i] = '\0';
	strcpy(value, buffer);
	last->value = value;
	memset(buffer, '\0', BUFFERSIZE);
	*i = 0;
}

void write_section(CSSlist* list, CSSselector* selectors, CSSattribute* attributes, int* selector_counter, int* attribute_counter) {
	CSSsection* section = init_section(selectors, attributes, *selector_counter, *attribute_counter);
	*selector_counter = 0;
	*attribute_counter = 0;
	while (list->next != nullptr) list = list->next;
	if (list->taken_cells < MAXSIZE) {
		list->sections[list->taken_cells] = section;
		list->taken_cells++;
	}
	else list->next = init_list(list, nullptr, section, 1);
}

void write_command(CSScommand* cmd, char* buffer, const bool full, int* i) {
	static int j;
	if (buffer[0] >= '0' && buffer[0] <= '9') cmd->n[j] = atoi(buffer);
	else strcpy(cmd->string[j], buffer);
	cmd->full = full;
	memset(buffer, '\0', BUFFERSIZE);
	*i = 0;
	j = (j + 1) % ARGS;
}

char write_command_type(char cmd_type, char* buffer, int* i) {
	cmd_type = *buffer;
	*i = 0;
	buffer[0] = '\0';
	return cmd_type;
}

bool change_input_type(char* buffer, bool type, int* i) {
	memset(buffer, '\0', 4);
	*i = 0;
	return type;
}

void update_command(CSScommand* cmd) {
	for (int i = 0; i < ARGS; i++) {
		cmd->n[i] = 0;
		memset(cmd->string[i], '\0', BUFFERSIZE);
	}
	cmd->type = '\0';
}

void count_sections(CSSlist* list, char* buffer, int* i) {
	int sections = 0;
	while (list->next != nullptr) {
		list = list->next;
		sections += list->taken_cells;
	}
	cout << *buffer << " == " << sections << endl;
	*i = 0;
	buffer[0] = '\0';
}

CSSlist* find_section(CSSlist* list, int* n0, int cmd_n) {
	while (list->next != nullptr) {
		list = list->next;
		cmd_n -= list->taken_cells;
		if (cmd_n <= 0) {
			*n0 = cmd_n + list->taken_cells;
			return list;
		}
	}
	return nullptr;
}

void find_elements_number(CSSlist* list, CSScommand* cmd) {
	int n0 = 0;
	list = find_section(list, &n0, cmd->n[0]);
	if (list == nullptr) return;
	cout << cmd->n[0] << ',' << cmd->type << ',' << *cmd->string[1] << " == ";
	if (cmd->type == 'S') cout << list->sections[n0 - 1]->selectors_size;
	else cout << list->sections[n0 - 1]->attributes_size;
	cout << endl;
}

void find_element_in_section(CSSlist* list, CSScommand* cmd) {
	int n0 = 0;
	list = find_section(list, &n0, cmd->n[0]);
	if (list == nullptr) return;
	CSSsection* section = list->sections[n0 - 1];
	if (cmd->type == 'S') {
		if (section->selectors_size < cmd->n[1]) return;
		CSSselector* selector = make_copy(section->selectors);
		for (int i = 0; i < section->selectors_size; i++) {
			selector = selector->next;
			if (i + 1 == cmd->n[1]) {
				cout << cmd->n[0] << ',' << cmd->type << ',' << cmd->n[1] << " == " << selector->name << endl;
				return;
			}
		}
	}
	else {
		CSSattribute* attribute = make_copy(section->attributes);
		for (int i = 0; i < section->attributes_size; i++) {
			attribute = attribute->next;
			if (!strcmp(attribute->property, cmd->string[1])) {
				cout << cmd->n[0] << ',' << cmd->type << ',' << cmd->string[1] << " == " << attribute->value << endl;
				return;
			}
		}
	}
}

void find_element_in_sections(CSSlist* list, CSScommand* cmd) {
	int elements = 0;
	char type = cmd->type;
	while (list->next != nullptr) {
		list = list->next;
		for (int i = 0; i < list->taken_cells; i++) {
			CSSsection* section = list->sections[i];
			if (type == 'S') {
				CSSselector* selector = make_copy(section->selectors);
				for (int j = 0; j < section->selectors_size; j++) {
					selector = selector->next;
					if (!strcmp(selector->name, cmd->string[0])) elements++;
				}
			}
			else {
				CSSattribute* attribute = make_copy(section->attributes);
				for (int j = 0; j < section->attributes_size; j++) {
					attribute = attribute->next;
					if (!strcmp(attribute->property, cmd->string[0])) elements++;
				}
			}
		}
	}
	cout << cmd->string[0] << ',' << cmd->type << ',' << cmd->string[1] << " == " << elements << endl;
}

void find_attribute_for_selector(CSSlist* list, CSScommand* cmd) {
	while (list->next != nullptr) list = list->next;
	while (list->previous != nullptr) {
		for (int i = list->taken_cells - 1; i >= 0; i--) {
			CSSsection* section = list->sections[i];
			CSSselector* selector = make_copy(section->selectors);
			for (int j = section->selectors_size - 1; j >= 0; j--) {
				selector = selector->next;
				if (!strcmp(selector->name, cmd->string[0])) {
					CSSattribute* attribute = make_copy(section->attributes);
					for (int e = 0; e < section->attributes_size; e++) {
						attribute = attribute->next;
						if (!strcmp(attribute->property, cmd->string[1])) {
							cout << cmd->string[0] << ',' << cmd->type << ',' << cmd->string[1] << " == " << attribute->value << endl;
							return;
						}
					}
				}
			}
		}
		if (list->previous->previous == nullptr) break;
		list = list->previous;
	}
}

void remove_node(CSSlist* list) {
	if (list->previous->previous == nullptr && list->next == nullptr) list->previous->next = init_list(list->previous);
	else {
		if (list->next != nullptr) {
			list->previous->next = list->next;
			list->next->previous = list->previous;
		}
		else list->previous->next = nullptr;
	}
	delete list;
}

void remove(CSSlist* list, const int n0) {
	CSSsection* tmp = list->sections[n0 - 1];
	for (int i = n0 - 1; i < list->taken_cells - 1; i++) list->sections[i] = list->sections[i + 1];
	list->sections[list->taken_cells - 1] = tmp;
	delete_section(list->sections[list->taken_cells - 1]);
	list->taken_cells--;
	if (list->taken_cells == 0) remove_node(list);
}

void remove_section(CSSlist* list, CSScommand* cmd) {
	int n0 = 0;
	list = find_section(list, &n0, cmd->n[0]);
	if (list == nullptr) return;
	remove(list, n0);
	cout << cmd->n[0] << ',' << cmd->type << ',' << cmd->string[1] << " == " << "deleted\n";
}

bool remove_node(CSSsection* section, CSSattribute* node, char* property) {
	for (int i = 0; i < section->attributes_size; i++) {
		CSSattribute* previous = node;
		node = node->next;
		if (!strcmp(node->property, property)) {
			if (node->next != nullptr) previous->next = node->next;
			else previous->next = nullptr;
			section->attributes_size--;
			delete node;
			return true;
		}
	}
	return false;
}

void remove_attribute(CSSlist* list, CSScommand* cmd) {
	int n0 = 0;
	list = find_section(list, &n0, cmd->n[0]);
	if (list == nullptr) return;
	CSSsection* section = list->sections[n0 - 1];
	if (remove_node(section, section->attributes, cmd->string[1])) cout << cmd->n[0] << ',' << cmd->type << ',' << cmd->string[1] << " == deleted\n";
	if (section->attributes_size == 0) remove(list, n0);
}

int main()
{
	CSSselector* selectors = init_selector();
	CSSattribute* attributes = init_attribute();
	CSSlast last = init_last(selectors, attributes);
	CSSlist* list = init_list();
	list->next = init_list(list);
	CSScommand* cmd = init_command();
	char c, buffer[BUFFERSIZE];
	int i = 0, selector_counter = 0, attribute_counter = 0;
	bool end = false, attribute = false;
	while (!end) {
		cin >> noskipws >> c;
		if (cin.eof()) end = true;
		if (cmd->command) {
			if (c == ',') {
				if (!cmd->full) write_command(cmd, buffer, true, &i);
				else cmd->type = write_command_type(cmd->type, buffer, &i);
			}
			else if ((c == '\n' || end) && i != 0) {
				if (!strcmp(buffer, "****")) cmd->command = change_input_type(buffer, false, &i);
				else if (!strcmp(buffer, "?") && !cmd->full) count_sections(list, buffer, &i);
				else {
					write_command(cmd, buffer, false, &i);
					if (cmd->type == 'E') find_attribute_for_selector(list, cmd);
					else if (cmd->type == 'D') {
						if (!strcmp(cmd->string[1], "*")) remove_section(list, cmd);
						else remove_attribute(list, cmd);
					}
					else if (cmd->n[0] && !strcmp(cmd->string[1], "?")) find_elements_number(list, cmd);
					else if (cmd->n[0] && cmd->n[1]) find_element_in_section(list, cmd);
					else if (cmd->n[0]) find_element_in_section(list, cmd);
					else if (!strcmp(cmd->string[1], "?")) find_element_in_sections(list, cmd);
					update_command(cmd);
				}
			}
			else {
				if (isspace(c) && i == 0) {}
				else {
					buffer[i] = c;
					i++;
				}
			}
		}
		else {
			switch (c) {
			case '{':
				last.selector = write_selector(selectors, last.selector, buffer, &selector_counter, &i);
				attribute = true;
				break;
			case ':':
				if (!attribute) {
					buffer[i] = c;
					i++;
				}
				else last.attribute = write_attribute_p(attributes, last.attribute, buffer, &attribute_counter, &i);
				break;
			case '}':
				if (i != 0) write_attribute_v(last.attribute, buffer, &i);	//if last attribute was without comma
				write_section(list->next, selectors, attributes, &selector_counter, &attribute_counter);
				selectors = init_selector();
				attributes = init_attribute();
				last = init_last(selectors, attributes);
				attribute = false;
				break;
			case ';':
				write_attribute_v(last.attribute, buffer, &i);
				break;
			case ',':
				if (!attribute) {
					last.selector = write_selector(selectors, last.selector, buffer, &selector_counter, &i);
					break;
				}
			default:
				if (isspace(c) && i == 0) break;
				buffer[i] = c;
				i++;
				if (!strcmp(buffer, "????")) cmd->command = change_input_type(buffer, true, &i);
			}
		}
	}
	delete_command(cmd);
	delete_list(list);
}