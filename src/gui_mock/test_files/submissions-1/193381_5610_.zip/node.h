#pragma once
#include <iostream>
#include"cusstr.h"

using namespace std;
struct selektor {
    cusstr data;
    struct selektor* next;
    cusstr znajdzselek(selektor* sel, int h);
};
cusstr znajdzselek(selektor* sel, int h) {
    struct selektor* m = sel;
    for (int v = 0; v < h; v++) {
        m = m->next;
    }
    return m->data;
}
    void pushs(struct selektor** head, cusstr datas)
    {
        struct selektor* newNode = new selektor;
        newNode->data = datas;
        newNode->next = (*head);
        (*head) = newNode;
    }
   
    struct atrybut {
    public:
        cusstr data;
        cusstr wartosc;
        struct atrybut* next;
        cusstr getdata();
        void znajdzwartosc(atrybut* atr,cusstr s);
    };
        void pusha(struct atrybut** head, cusstr data, cusstr wartosc)
        {
            struct atrybut* newNode = new atrybut;
            newNode->data = data;
            newNode->next = (*head);
            (*head) = newNode;
        }
        cusstr atrybut::getdata() {
            return data;
        }
        void znajdzwartosc(atrybut* atr, cusstr s) {
            atrybut* atrybut = atr;
            while (atrybut != NULL) {
                if (atrybut->data == s) {
                    cout << atr->wartosc << endl;
                }
                atrybut = atrybut->next;
            }
        }
    struct Blok {
        atrybut** atrybut;
        selektor** selektor;
        int sele;
        int atryb;
    };
    struct Node {
        int count;
        struct Node* next;
        struct Node* prev;
        Blok data[8];
    };
    void push(struct Node** head, struct atrybut** atr, struct selektor** sel, int zajete, int atry, int sele) {
        struct Blok b { atr, sel, atry, sele };
        if (zajete % 8 == 0) {
            (*head)->count = zajete % 8;
            (*head)->data[zajete % 8] = b;
        }
        else {
            struct Node* newNode = new Node;
            newNode->count = zajete % 8;
            newNode->data[0] = b;
            newNode->next = (*head);
            newNode->prev = NULL;
            if ((*head) != NULL)
                (*head)->prev = newNode;
            (*head) = newNode;
        }
    }
    void deleteNode(struct Node** head, struct Node* del_node) {
        if (*head == NULL || del_node == NULL)
            return;
        if (*head == del_node)
            *head = del_node->next;
        if (del_node->next != NULL)
            del_node->next->prev = del_node->prev;
        if (del_node->prev != NULL)
            del_node->prev->next = del_node->next;
        free(del_node);
    }
    void displayList(struct Node* node) {
        struct Node* last;
        while (node != NULL) {
            last = node;
            node = node->next;
        }
    }
    void counts(struct Node* node,int i) {
        struct Node* current = node;
        for (int h = 0; h < (i - i % 8) / 8; h++) {
            current = current->next;
        }
        cout << current->data[i % 8].sele << endl;
   }
    void counta(struct Node* node, int i) {
        struct Node* current = node;
        for (int h = 0; h < (i - i % 8) / 8; h++) {
            current = current->next;
        }
        cout << current->data[i % 8].atryb << endl;
    }
    int findc(struct Node* node, cusstr c) {
        int f = 0;
        while (node) {
            for (int i = 0; i < 7; i++) {
                struct atrybut *atrybut = *(node->data[i].atrybut);
                while (atrybut) {
                    if (atrybut->data == c) {
                        f++; 
                    } 
                    atrybut = atrybut->next;
                }
            }
            node = node->next;
        }
        return f;
   }
    cusstr finds(struct Node* node, int j, int i) {
        Node* current = node;
        for (int h = 0; h < (i - i % 8) / 8; h++) {
            current = current->next;
        }
        return znajdzselek(*current->data[i % 8].selektor, j);
    }
    void finda(struct Node* node, cusstr c,int i) {
        Node* current = node;
        for (int h = 0; h < (i - i % 8) / 8; h++) {
            current = current->next;
        }
        znajdzwartosc(*node->data[i % 8].atrybut, c);
    }
    
    int countsz(struct Node* node, cusstr z) {
        int f = 0;
        while (node) {
            for (int i = 0; i < node->count; i++) {
                struct selektor *selektor =*node->data[i].selektor;
                while (selektor) {
                    if (selektor->data == z) {
                        f++;
                    }
                    selektor = selektor->next;
                }
            }
            node = node->next;
        }
        return f;
    }