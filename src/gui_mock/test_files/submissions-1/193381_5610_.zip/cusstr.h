#pragma once
#pragma warning(suppress : 4996)
#include <cstring>
#include <iostream>
using namespace std;

class cusstr {
    friend ostream& operator<<(  ostream& os, const cusstr& obj);
    friend istream& operator>>( istream& is,cusstr& obj);
    friend cusstr operator+(  const cusstr& lhs, const cusstr& rhs);
    friend int operator==(const cusstr& lhs, const cusstr& rhs);
    char* str;

public:
    cusstr();
    int get_length();
    void copy(char s[], int len, int pos);
    void swp(cusstr& rhs);
    cusstr(char* val);
    void pop_bk();
    void push_bk(char a);
    cusstr(const cusstr& source);
    cusstr(cusstr&& source);
    cusstr& operator=(
        const cusstr& rhs);
    ~cusstr() { delete str; }
};
cusstr& cusstr::operator=(const cusstr& rhs)
{
    if (this == &rhs)
        return *this;
    delete[] str;
    str = new char[strlen(rhs.str) + 1];
    strcpy(str, rhs.str);
    return *this;
}
void cusstr::push_bk(char a)
{
    int length = strlen(str);
    char* buff = new char[length + 2];
    for (int i = 0; i < length; i++) {
        buff[i] = str[i];
    }
    buff[length] = a;
    buff[length + 1] = '\0';
    *this = cusstr{ buff };
    delete[] buff;
}
void cusstr::pop_bk()
{
    int length = strlen(str);
    char* buff = new char[length];
    for (int i = 0; i < length - 1; i++)
        buff[i] = str[i];
    buff[length - 1] = '\0';
    *this = cusstr{ buff };
    delete[] buff;
}
cusstr operator+(const cusstr& lhs, const cusstr& rhs)
{
    int length = strlen(lhs.str) + strlen(rhs.str);
    char* buff = new char[length + 1];
    strcpy(buff, lhs.str);
    strcat(buff, rhs.str);
    buff[length] = '\0';
    cusstr temp{ buff };
    delete[] buff;
    return temp;
}
istream& operator>>(istream& is, cusstr& obj)
{
    char* buff = new char[1000];
    memset(&buff[0], 0, sizeof(buff));
    is >> buff;
    obj = cusstr{ buff };
    delete[] buff;
    return is;
}
ostream& operator<<(ostream& os,  const cusstr& obj)
{
    os << obj.str;
    return os;
}
void cusstr::swp(cusstr& rhs)
{
    cusstr temp{ rhs };
    rhs = *this;
    *this = temp;
}
int operator==(const cusstr& lhs, const cusstr& rhs) {
    return  strcmp(lhs.str, rhs.str);
        
}
void cusstr::copy(char s[], int len, int pos)
{
    for (int i = 0; i < len; i++) {
        s[i] = str[pos + i];
    }
    s[len] = '\0';
}
int cusstr::get_length()
{
    return strlen(str);
}
cusstr::cusstr()
    : str{ nullptr }
{
    str = new char[1];
    str[0] = '\0';
}
cusstr::cusstr(char* val)
{
    if (val == nullptr) {
        str = new char[1];
        str[0] = '\0';
    }
    else{
        str = new char[strlen(val) + 1];
        strcpy(str, val);
        str[strlen(val)] = '\0';
    }
}
cusstr::cusstr(const cusstr& source)
{
    str = new char[strlen(source.str) + 1];
    strcpy(str, source.str);
}

cusstr::cusstr(cusstr&& source)
{
    str = source.str;
    source.str = nullptr;
}
