#include<iostream>
#include<list>
#include"cusstr.h"
#include"node.h"
using namespace std;

int main() {
	struct selektor* selektor=NULL;
	struct atrybut*  atrybut = NULL;
	struct Node* Node = NULL;
	cusstr string, string1;
	char str[100];
	int i = 0, sel = 0, atr = 0,blok=1;
	char a, e;
	int b = 0, c = 0, d = 0;
	while (cin >> a && a != '/n') {
		if (d == 0) {
			string.push_bk(a);
			i++;
			if (a == ',')
			{
				string.pop_bk();
				pushs(&selektor, string);
				for (int j = 1; j < i; j++) {
					string.pop_bk();
				}
				i = 0;
			}
			if (a == '{') {
				string.pop_bk();
				sel++;
				blok++;
				pushs(&selektor, string);
				for (int j = 1; j < i; j++) {
					string.pop_bk();
				}
				i = 0;
				while (a != '}') {
					cin >> a;
					if (a != '}') {
						string.push_bk(a);
						i++;
						if (a == ':') {
							atr++;
							string.pop_bk();
							string1 = string;
							for (int j = 1; j < i; j++) {
								string.pop_bk();
							}
							i = 0;
						}
						if (a == ';') {
							string.pop_bk();
							pusha(&atrybut, string1, string);
							for (int j = 1; j < i; j++) {
								string.pop_bk();
							}
							i = 0;
						}
					}
					else {
						push(&Node, &atrybut, &selektor,blok, sel,atr);
						selektor = NULL;
						atrybut = NULL;

					}
				}
			}
			if (a == '?') {
				cin >> e;
				cin >> e;
				cin >> e;
				d = 1;
			}
		}
		else {
			struct Node* p=Node;
			while (p->prev != NULL) {
				p = Node->prev;
			}
			if (a == '*') {
				cin >> e;
				cin >> e;
				cin >> e;
				d = 0;
			}
			else {
				if (a == '?') {
					cout << "? == " << sel << endl;
				}
				else {
					if (a <= 'z' && a >= 'a') {
						string1.push_bk(a);
						cin.getline(str, 100, ',');
						string = { cusstr(str) };
						string = string1 + string;
						cin >> e;
						if (e == 'A') {
							cin >> e;
							cin >> e;
							cout << string << ",A,? == " << endl;
							for (int t = 0; t < string.get_length()+1; t++) {
								string.pop_bk();
							}
							string1.pop_bk();
						}
						else {
							if (e == 'S'){
								cout << string << endl;
								cin >> e;
								cin >> e;
								cout << string << ",S,? == " << countsz(p,string) << endl;
								string1.pop_bk();
							}
							else {
								cin >> e;
								cin.getline(str, 100);
								string1 = { cusstr(str) };
								string.pop_bk();
							}
						}
					}
					else {
						b = int(a) - 48;
						cin >> e;
						cin >> e;
						if (e == 'S')
						{
							cin >> e;
							cin >> e;
							if (e == '?' && b < sel) {
								cout << b << ",S,? == ";
								counts(p, b);
							}
							else {
								c = int(e) - 48;
									cout << b << ",S," << c << " == ";
									
							}
						}
						else {
							if (e == 'A') {
								cin >> e;
								cin >> e;
								if (e == '?' && b < sel) {
									cout << b << ",A,? == ";
									counta(p, b);
								}
								else {
									if (e <= 'z' && e >= 'a') {
										string.pop_bk();
										string1.push_bk(e);
										cin.getline(str, 100);
										string = { cusstr(str) };
										string = string1 + string;
											for (int l = 0; l < string.get_length(); l++) {
												string.pop_bk();
											}
											string1.pop_bk();
										}
									}
							}
							else {
								if (e == 'D') {
									cin >> e;
									cin >> e;
									if (e == '*') {
										cout << a << ",D,* == deleted" << endl;
										sel--;
									}
									else {
										string.pop_bk();
										string1.push_bk(e);
										cin.getline(str, 100);
										string = { cusstr(str) };
										string = string1 + string;
										cout << a << ",D," << string << " == deleted" << endl;
										sel--;
										for (int p = 0; p < string.get_length(); p++) {
											string.pop_bk();
										}
										string1.pop_bk();
									}
								}
							}
						}
					}
				}
			}
			for (int k = 0; k < string.get_length(); k++) {
				string.pop_bk();
			}
			for (int f = 0; f < string1.get_length(); f++) {
				string1.pop_bk();
			}
		}
		cout << Node->data[2].sele << endl;
	}
	return 0;
}