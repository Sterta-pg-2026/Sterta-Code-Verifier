#pragma once
#include "mysinglelist.h"
#include "nodes.h"

class SectionNode
{
public:
	MySingleList<SelectorNode> selectors;
	MySingleList<AttributeNode> attributes;
};

