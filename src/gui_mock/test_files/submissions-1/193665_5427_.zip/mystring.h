#pragma once
#include <iostream>
#define MYSTRING_BUFFER_SIZE 100

class Mystring
{
private:
	char*  text;
	int length; // counts "\0"
	friend  std::ostream& operator<<(std::ostream& out, const Mystring& input);
	friend bool operator==(const Mystring& left, const Mystring& right);
public:
	Mystring();

	Mystring(const char* input);

	Mystring(char* input);

	Mystring(char input);

	Mystring( const Mystring& input);

	Mystring( Mystring&& input);

	Mystring& operator=(const Mystring& input);

	 Mystring& operator=( Mystring&& input);

	 Mystring& operator=(const char* input);

	 Mystring& operator=( char input);

	 Mystring& operator+=(const Mystring& input);

	 char& operator[](int index);
	 char  operator[](int index) const;

	 ~Mystring();

	 int getLength() const;
	 char* getText() const;

	//reads from stdin using cin.getline. Stops  reading at delim(default: newline) 
	 void getLine(char delim);

	 //extracts text in specified substring( including start and stop ).
	 Mystring subString(int start, int stop) const;
};
std::ostream& operator<<(std::ostream& out, const Mystring& input);
std::istream& operator>>(std::istream& in, Mystring& input);
bool operator==(const Mystring& left, const Mystring& right);
bool operator!=(const Mystring& left, const Mystring& right);
Mystring operator+(Mystring left, const Mystring& right);


int CheckLength(const char * input);

