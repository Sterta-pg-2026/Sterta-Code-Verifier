#include "utils.h"
void swap(char*& a, char*& b)
{
	char* temp = a;
	a = b;
	b = temp;

}

void swap(int& a, int& b)
{
	const int temp = a;
	a = b;
	b = temp;

}