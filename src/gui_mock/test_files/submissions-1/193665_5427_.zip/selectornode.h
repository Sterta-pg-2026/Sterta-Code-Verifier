#pragma once
#include "mystring.h"
class SelectorNode 
{
	Mystring name;

public:

	SelectorNode* next;

	SelectorNode(const char* name);

	SelectorNode(Mystring name);

	Mystring getName() const;

	void setName(const Mystring& input);
};