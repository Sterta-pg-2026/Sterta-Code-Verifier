#pragma once
#include <iostream>
#include "attributenode.h"

//indexed from 0
template <class T>
class MySingleList
{
private:
	T* head;
	int size;
public:

	MySingleList() : head(nullptr), size(0){}

	MySingleList(const T& input) :head(new T(input)), size(1){}


	MySingleList(MySingleList&& input) : head(input.head), size(input.size)
	{
		input.head = nullptr;

	}

	int getSize() const
	{
		return size;
	}

	//gets first node
	const T* getNode()
	{
		if (size > 0)
		{
			return head;
		}
		return nullptr;
	}
	

	T* getNode(int index)
	{
		if (size >= index + 1)
		{
			T* temp = head;
			for (int i = 0; i < index; i++)
			{
				temp = temp->next;
			}
			return  temp;
		}
		return nullptr;
	}

	void addFirst(T node)
	{
		T* temp = new T(node);

		if (size > 0)
		{
			temp->next = head;
			head = temp;
		}
		else
		{
			head = temp;

		}
		size++;
	}

	void addLast(T node)
	{
		T* temp = new T(node);


		if (size > 0)
		{
			getNode(size - 1)->next = temp;
		}
		else
		{
			head = temp;
		}
		size++;
	}

	void removeNode(int index)
	{
		if (size >= index + 1)
		{
			T* temp = getNode(index);
			if (index == 0)
			{
				head = head->next;
			}
			else if (index == size - 1)
			{
				getNode(index - 1)->next = nullptr;
			}
			else
			{
				getNode(index - 1)->next = getNode(index + 1);
			}

			size--;
			delete temp;
		}

	}
	//optionally accepts int pointer to return index of found node
	T* findNode(const Mystring& input, int* index = nullptr)
	{
		T* temp = head;
		int i = 0;
		while (temp!=nullptr)
		{

			if(temp->getName()==input)
			{
				if(index!=nullptr) *index = i;

				return temp;
			}

			temp = temp->next;
			i++;
		}
		return nullptr;
	}

	~MySingleList()
	{
		T* to_delete = head;
		while (to_delete) {
			T* next_node = to_delete->next;
			delete to_delete;
			to_delete = next_node;
		}
	}
};
