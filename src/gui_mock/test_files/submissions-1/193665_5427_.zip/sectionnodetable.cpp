#include "sectionnodetable.h"

SectionNodeTable::SectionNodeTable(): table() , next(nullptr) , prev(nullptr) , taken(0)
{
	for (SectionNode* i : table)
	{
		i = nullptr;
	}
}

SectionNodeTable::~SectionNodeTable()
{
	for (SectionNode* i : table)
	{
		delete i;
	}
}
