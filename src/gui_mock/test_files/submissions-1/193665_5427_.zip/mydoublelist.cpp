#include "mydoublelist.h"
MyDoubleList::MyDoubleList(): head(nullptr), tail(nullptr), size(0), node_num(0)
{
		
}

int MyDoubleList::getSize() const
{
	return size;
}

int MyDoubleList::getNodeNum() const
{
	return node_num;
}

SectionNode* MyDoubleList::getSection(int index, SectionNodeTable** node, int* section_index)
{
	if(index<0 || index>size-1)
	{
		return nullptr;
	}

	SectionNodeTable* temp = head;

	//skips list nodes
	int current_index = 0;
	while(current_index+temp->taken-1<index)
	{
		current_index += temp->taken;
		temp = temp->next;
	}

	//finds element in table
	int i=0,j = 0;
	while(current_index+j!=index+1)
	{
		if(temp->table[i++]!=nullptr)
		{
			j++;
		}

	}

	//optional return values
	if (node != nullptr) {
		*node = temp;
		*section_index = i - 1;
	}

	return temp->table[i - 1];

}

SectionNodeTable* MyDoubleList::getNode(int node_index)
{

	SectionNodeTable* temp = head;
	for (int i = 0; i < node_index; i++)
	{
		temp = temp->next;
	}
	return  temp;

}

void MyDoubleList::addLast(SectionNode* node)
{
	if (size != 0)
	{
		
		if(tail->taken>=TABLE_SIZE)
		{
			SectionNodeTable* new_node = new SectionNodeTable;
			node_num++;
			new_node->prev = tail;
			tail->next = new_node;
			tail = new_node;

			new_node->table[0] = node;
			new_node->taken++;
		}
		else
		{
			tail->table[tail->taken] = node;
			tail->taken++;
		}

	}
	else
	{
		
		head = new SectionNodeTable;
		tail = head;
		node_num++;
		head->table[head->taken]=node;
		head->taken++;
	}
	size++;
}

int  MyDoubleList::removeNode(int index)
{
	if (size < 1 || node_num<1) return -1;

	SectionNodeTable* temp_node=nullptr;
	int to_delete_index = 0;
	SectionNode* to_delete = getSection(index,&temp_node,&to_delete_index);
	if (to_delete== nullptr) return -1;
	size--;
	delete to_delete;
	temp_node->table[to_delete_index] = nullptr;
	temp_node->taken--;
	if(temp_node->taken==0)
	{
		if(temp_node==head)
		{
			if(size==0)
			{
				head = nullptr;
				tail = nullptr;
			}
			else
			{
				
				head = head->next;
				head->prev = nullptr;
			}
			
			
		}
		else if(temp_node==tail)
		{

			tail = tail->prev;
			tail->next = nullptr;

		}
		else
		{
			temp_node->prev->next = temp_node->next;
			temp_node->next->prev = temp_node->prev;
		}
		delete temp_node;
		node_num--;
	}
	else
	{
		fixTable(temp_node);
	}
	return  0;
}

void MyDoubleList::fixTable(SectionNodeTable* node)
{
	for(int i=0;i<TABLE_SIZE-1;i++)
	{
		if (node->table[i] == nullptr)
		{
			int j=i+1;
			while(j < TABLE_SIZE && node->table[j]==nullptr)
			{
				j++;
			}
			if (j >= TABLE_SIZE) j = TABLE_SIZE - 1;
			node->table[i] = node->table[j];
			node->table[j] = nullptr;
		}
	}
}


int MyDoubleList::countOccurrences(const Mystring& input,bool mode)
{
	SectionNodeTable* temp = head;
	int counter = 0;
	for(int i=0;i<node_num;i++)
	{
		for(SectionNode* section : temp->table)
		{
			if (mode == ATTRIBUTE_MODE) {
				if (section != nullptr && section->attributes.findNode(input) != nullptr)
				{
					counter++;
				}
			}
			else //SELECTOR_MODE
			{
				if (section != nullptr && section->selectors.findNode(input) != nullptr)
				{
					counter++;
				}
			}
		}
		temp = temp->next;
	}
	return counter;
}

AttributeNode* MyDoubleList::findLast(const Mystring& selector_name, const Mystring& attribute_name)
{
	SectionNodeTable* temp = tail;
	for (int i = 0; i < node_num; i++)
	{
		for (int j = TABLE_SIZE-1; j >=0; j--)
		{
				
			if (temp->table[j] != nullptr && temp->table[j]->selectors.findNode(selector_name) != nullptr)
			{
				AttributeNode* temp_attribute = temp->table[j]->attributes.findNode(attribute_name);
				if (temp_attribute != nullptr) {
					return temp_attribute;
				}
			}
				
		}
		temp = temp->prev;
	}
	return nullptr;
}

MyDoubleList::~MyDoubleList()
{
	SectionNodeTable* to_delete = head;
	while (to_delete) 
	{
		SectionNodeTable* next_node = to_delete->next;
		to_delete->prev = nullptr;
		delete to_delete;
		to_delete = next_node;
	}
}
