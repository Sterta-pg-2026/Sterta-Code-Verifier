#include "processor.h"



int main()
{
	Processor proc;
	proc.start();
	return 0;

}