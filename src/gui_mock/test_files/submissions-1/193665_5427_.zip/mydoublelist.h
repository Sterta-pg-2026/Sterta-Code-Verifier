#pragma once
#include "sectionnodetable.h"
#define ATTRIBUTE_MODE false
#define SELECTOR_MODE true

class MyDoubleList
{
	SectionNodeTable* head;
	SectionNodeTable* tail;
	int size;
	int node_num;

public:
	MyDoubleList();

	int getSize() const;

	int getNodeNum() const;

	//returns single section. Optionally accepts pointers to list node containing section and section index
	SectionNode* getSection(int index, SectionNodeTable** node=nullptr,int* section_index=nullptr);
	//returns list node
	SectionNodeTable* getNode(int node_index);

	void addLast(SectionNode* node);
	//returns -1 if no node was deleted, 0 on success
	int removeNode(int index);
	//gets rid of empty spaces, stable algorithm
	static void fixTable(SectionNodeTable* node);
	//works in two modes : 1)ATTRIBUTE_MODE , 2)SELECTOR_MODE 
	int countOccurrences( const Mystring& input, bool mode);

	AttributeNode* findLast(const Mystring& selector_name, const Mystring& attribute_name);

	~MyDoubleList();
};

