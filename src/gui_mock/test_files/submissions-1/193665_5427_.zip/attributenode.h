#pragma once
#include "mystring.h"
class AttributeNode 
{
private:
	Mystring name;
	Mystring value;
public:

	AttributeNode* next;

	AttributeNode();

	AttributeNode(const char* name, const char * value);

	AttributeNode(Mystring& name, Mystring& value);

	Mystring getName() const;

	void setName(Mystring& input);

	Mystring getValue() const;

	void setValue(Mystring& input);
};


