#pragma once
#include "mystring.h"

class command_t
{
public:
	int i;//left number
	int j;//right number
	char middle; 
	Mystring n;// left string
	Mystring z;// right strings


	command_t();

	//sets default values
	void reset();
};

