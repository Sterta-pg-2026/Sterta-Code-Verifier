#include "mystring.h"
#include "utils.h"



Mystring::Mystring(): text(new char[1]), length(1)
{
	text[0] = '\0';
}

Mystring::Mystring(const char* input): text(nullptr), length(0)
{
	length = CheckLength(input);
	text = new char[length];

	for (int i = 0; i < length; i++)
	{
		text[i] = input[i];
	}
}

Mystring::Mystring(char* input) : text(nullptr), length(0)
{
	length = CheckLength(input);
	text = new char[length];

	for (int i = 0; i < length; i++)
	{
		text[i] = input[i];
	}
	delete[] input;
	input = nullptr;
}

Mystring::Mystring(const char input): text(new char[2]), length(2)
{
	text[0] = input;
	text[1] = '\0';
}

Mystring::Mystring(const Mystring& input): text(new char[input.length]) , length(input.length)
{
	for(int i=0;i<length;i++)
	{
		text[i] = input.text[i];
	}
	
}

Mystring::Mystring(Mystring&& input): text(input.text), length(input.length)
{
	input.text = nullptr;
	input.length = 0;
}

Mystring& Mystring::operator=(const Mystring& input)
{
	Mystring temp = input;
	swap(text, temp.text);
	swap(length, temp.length);

	return *this;
}

Mystring& Mystring::operator=(Mystring&& input)
{
	swap(text, input.text);
	swap(length, input.length);

	return *this;
}

Mystring& Mystring::operator=(const char* input)
{
	Mystring temp = input;
	swap(text, temp.text);
	swap(length, temp.length);

	return *this;
}

Mystring& Mystring::operator=(const char input)
{
	Mystring temp = input;
	swap(text, temp.text);
	swap(length, temp.length);

	return *this;
}

Mystring& Mystring::operator+=(const Mystring& input)
{
	char* temp = new char[length + input.length];

	int j = 0;
	for(;j<length-1;j++)
	{
		temp[j] = text[j];
	}

	for (int i = 0; i < input.length; i++,j++)
	{
		temp[j] = input.text[i];
	}

	delete[] text;
	text = temp;
	length += input.length-1;

	return *this;
}

char& Mystring::operator[](int index)
{
	return text[index];
}

char Mystring::operator[](int index) const
{
	return text[index];
}

Mystring::~Mystring()
{
	delete[] text;
}

int Mystring::getLength() const
{
	return length;
}

 char* Mystring::getText() const
 {
	return text;
}

void Mystring::getLine(char delim='\n')
{
	char* buffer = new char[MYSTRING_BUFFER_SIZE];
	std::cin.getline(buffer, MYSTRING_BUFFER_SIZE, delim);

	//buffer reallocation and resuming of reading
	int size_multiplier = 2;
	while (std::cin.fail() && std::cin.gcount()>0)
	{
		
		char* temp_buffer = buffer;
		buffer = new char[MYSTRING_BUFFER_SIZE * size_multiplier - 1];

		int i = 0;
		while(temp_buffer[i]!='\0')
		{
			buffer[i] = temp_buffer[i];
			i++;
		}

		delete[] temp_buffer;

		char* temp_pointer = buffer + i;
		std::cin.clear();
		std::cin.getline(temp_pointer, MYSTRING_BUFFER_SIZE, delim);

		size_multiplier++;

	}

	*this = buffer;
	delete[] buffer;
}

Mystring Mystring::subString(int start, int stop) const
{
	int temp_length = (stop - start + 1) + 1;//number of characters + '\0'
	char* temp = new char[temp_length];

	for (int dest_iter = 0,source_iter=start; dest_iter < temp_length-1; dest_iter++,source_iter++)
	{
		temp[dest_iter] = text[source_iter];
	}
	temp[temp_length-1] = '\0';

	Mystring new_string = temp;

	return new_string;
}

std::ostream& operator<<(std::ostream& out, const Mystring& input)
{
	out << input.text;

	return out;
}

std::istream& operator>>(std::istream& in, Mystring& input)
{
	char* temp = new char[MYSTRING_BUFFER_SIZE];
	std::cin >> temp;
	input = temp;
	delete[] temp;
	return in;
}

bool operator==(const Mystring& left, const Mystring& right)
{
	if (left.length != right.length) return false;
	for(int i=0;i<left.length;i++)
	{
		if (left.text[i] != right.text[i]) return false;
	}

	return true;

}

bool operator!=(const Mystring& left, const Mystring& right)
{
	return !operator==(left,right);
}

Mystring operator+(Mystring left, const Mystring& right)
{
	left += right;
	return left;
}

int CheckLength(const char* input)
{
	int  length = 0;

	while( input[length]!='\0'){
		length++;
	}
	return length + 1;
}
