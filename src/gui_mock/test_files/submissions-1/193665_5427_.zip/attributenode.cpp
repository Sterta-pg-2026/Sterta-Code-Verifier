#include "attributenode.h"

AttributeNode::AttributeNode() :name() , value() , next(nullptr)
{

}

AttributeNode::AttributeNode(const char* name, const char* value): name(name) , value(value) , next(nullptr)
{

}

AttributeNode::AttributeNode(Mystring& name, Mystring& value) : name(name), value(value), next(nullptr)
{

}

Mystring AttributeNode::getName() const
{
	return name;
}

void AttributeNode::setName(Mystring& input)
{
	name = input;
}

Mystring AttributeNode::getValue() const
{
	return value;
}

void AttributeNode::setValue(Mystring& input)
{
	value = input;
}
