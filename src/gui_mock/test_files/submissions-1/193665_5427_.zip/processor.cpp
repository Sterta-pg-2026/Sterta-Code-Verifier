#include "processor.h"
#include <cctype>
void Processor::start()
{
	bool mode = READ_SECTION_MODE;
	do
	{
		if (mode == READ_SECTION_MODE) 
		{
			readSection();
		}
		else //READ_COMMAND_MODE
		{
			processCommand();
		}

		//mode switch
		std::cin >> std::ws;
		int c = std::cin.peek();
		if (mode==READ_SECTION_MODE && c=='?')
		{
			mode = READ_COMMAND_MODE;
			std::cin.ignore(4, '\n');
		}
		else if(mode==READ_COMMAND_MODE && c=='*')
		{
			mode = READ_SECTION_MODE;
			std::cin.ignore(4, '\n');
		}

	} while (!std::cin.eof());

}

void Processor::readSection()
{
	current_section = new SectionNode;
	std::cin >> std::ws;
	readSelectors();
	std::cin >> std::ws;
	readAttributes();
	section_list.addLast(current_section);
}

void Processor::readSelectors()
{
	//checks for global selector
	if (std::cin.peek() == '{') return;

	buffer.getLine('{');
	for(int i=0,start=0;i<buffer.getLength();i++)
	{
		//checks for end of selector name
		if(buffer[i]==',' || buffer[i] == ' ' && (buffer[i+1]=='\0'|| buffer[i + 1] == '\n' ) || buffer[i] == '\0' || buffer[i] == '\n')
		{
			if(buffer[i] == ' ')
			{
				
			}
			if (current_section->selectors.findNode(buffer.subString(start, i - 1)) == nullptr)
			{
				current_section->selectors.addLast(buffer.subString(start, i - 1));
			}

			skipWhiteSpace(i, start);
				
		}
	}
}

void Processor::readAttributes()
{
	buffer.getLine('}');
	bool mode = ATTRIBUTE_NAME_MODE;
	Mystring temp_name;
	Mystring temp_value;
	for (int i = 0, start = 0; i < buffer.getLength(); i++)
	{
		if(mode==ATTRIBUTE_NAME_MODE)
		{
			if(buffer[i]==':')
			{
				temp_name = buffer.subString(start, i - 1);
				skipWhiteSpace(i, start);
				mode = ATTRIBUTE_VALUE_MODE;
			}
		}
		else //ATTRIBUTE_VALUE_MODE
		{
			if(buffer[i]==';' || buffer[i]=='}')
			{
				temp_value = buffer.subString(start, i - 1);
				if (current_section->attributes.findNode(temp_name) == nullptr) 
				{
					current_section->attributes.addLast({ temp_name,temp_value });
				}
				else
				{
					current_section->attributes.findNode(temp_name)->setValue(temp_value);
				}
				skipWhiteSpace(i, start);
				mode = ATTRIBUTE_NAME_MODE;

			}
		}
	}
}

void Processor::processCommand()
{
	command.reset();
	std::cin >> std::ws;
	//checks for print number of selectors command
	int c = std::cin.peek();
	if(c=='?')
	{
		std::cin.ignore(1);
		command.middle = '?';
		chooseCommand();
		return;
	}

	std::cin >> std::ws;

	//read left value
	buffer.getLine(',');
	if(isdigit(buffer[0]))
	{
		command.i = atoi(buffer.subString(0, buffer.getLength() - 1).getText());
	}
	else
	{
		command.z = buffer;
	}
	//read middle
	buffer.getLine(',');
	command.middle = buffer[0];

	//read right value
	buffer.getLine('\n');
	if (isdigit(buffer[0]))
	{
		command.j = atoi(buffer.subString(0, buffer.getLength() - 1).getText());
	}
	else
	{
			command.n = buffer;
	}
	chooseCommand();

}

void Processor::chooseCommand()
{

	switch (command.middle)
	{
	case '?':
		printNumberOfSections();
		break;

	case 'S':
		if(command.i==-1)
		{
			countSelectors();
		}
		else if(command.j==-1)
		{
				
			printNumberOfSelectors();
		}
		else
		{
			printSelector();
		}
		break;

	case 'A':
		if (command.i == -1)
		{
			countAttributes();
		}
		else if (command.n[0] == '?')
		{
			printNumberOfAttributes();
		}
		else
		{
			printValueOfAttribute();
		}
		break;
	case 'E':
		findAttributeValueForSelector();
		break;

	case 'D':
		if(command.n[0]=='*')
		{
			deleteSection();
		}
		else
		{
			deleteAttribute();
		}
		break;
		
	}

}

void Processor::printNumberOfSections()
{
	std::cout <<"? == "<< section_list.getSize()<< std::endl;
}

void Processor::printNumberOfSelectors()
{
	SectionNode* temp=section_list.getSection(command.i - 1);

	if(temp!=nullptr)
	{
		std::cout << command.i << ',' << command.middle << ",? == " << temp->selectors.getSize() << std::endl;
	}
}

void Processor::printNumberOfAttributes()
{
	SectionNode* temp = section_list.getSection(command.i - 1);

	if (temp != nullptr)
	{
		std::cout << command.i << ',' << command.middle << ",? == " << temp->attributes.getSize() << std::endl;
	}
}

void Processor::printSelector()
{
	SectionNode* temp_section = section_list.getSection(command.i - 1);

	if (temp_section != nullptr)
	{
		SelectorNode* temp_selector = temp_section->selectors.getNode(command.j - 1);
		if (temp_selector != nullptr) 
		{
			std::cout << command.i << ',' << command.middle << ','<<command.j<<" == " << temp_selector->getName() << std::endl;
		}
	}
}

void Processor::deleteSection()
{
	if(section_list.removeNode(command.i - 1)!=-1)
	std::cout << command.i << ',' << command.middle << ",* == deleted" << std::endl;
}

void Processor::printValueOfAttribute()
{
	SectionNode* temp_section = section_list.getSection(command.i - 1);

	if(temp_section!=nullptr)
	{
		AttributeNode* temp_attribute = temp_section->attributes.findNode(command.n);
		if (temp_attribute != nullptr) 
		{
			std::cout << command.i << ',' << command.middle << ',' << command.n << " == " << temp_attribute->getValue() << std::endl;
		}
	}
}

void Processor::deleteAttribute()
{
	SectionNode* temp_section = section_list.getSection(command.i - 1);

	if (temp_section != nullptr)
	{
		int index=-1;
		temp_section->attributes.findNode(command.n,&index);
		if (index != -1) 
		{
			temp_section->attributes.removeNode(index);
			if (temp_section->attributes.getSize() == 0)
			{
				section_list.removeNode(command.i - 1);
			}
			std::cout << command.i << ',' << command.middle << ',' << command.n << " == deleted"<< std::endl;
		}
	}
}

void Processor::countAttributes()
{
	int count = section_list.countOccurrences(command.z,ATTRIBUTE_MODE);
	std::cout << command.z << ',' << command.middle << ',' << command.n << " == " << count << std::endl;
}

void Processor::countSelectors()
{
	int count = section_list.countOccurrences(command.z,SELECTOR_MODE);
	std::cout << command.z << ',' << command.middle << ',' << command.n << " == " << count << std::endl;
}

void Processor::findAttributeValueForSelector()
{
	AttributeNode* temp= section_list.findLast(command.z, command.n);
	if (temp != nullptr) 
	{
		std::cout << command.z << ',' << command.middle << ',' << command.n << " == " << temp->getValue() << std::endl;
	}

}

void Processor::skipWhiteSpace(int& i, int& start)
{
	do
	{
		i++;
		if (buffer[i] == '\0') break;
	} while (isspace(buffer[i]));
	start = i;
}

