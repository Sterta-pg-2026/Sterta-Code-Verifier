#include "selectornode.h"

SelectorNode::SelectorNode(const char* name): name(name)
{
	next = nullptr;
}

SelectorNode::SelectorNode(Mystring name) : name(name)
{
	next = nullptr;
}

Mystring SelectorNode::getName() const
{
	return name;
}

void SelectorNode::setName(const Mystring& input)
{
	name = input;
}
