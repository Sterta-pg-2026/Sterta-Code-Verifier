#include "command_t.h"

command_t::command_t(): i(-1), j(-1) , middle('\0') , n() , z()
{
		
}

void command_t::reset()
{
	i = -1;
	j = -1;
	middle = '\0';
	n = "";
	z = "";
}
