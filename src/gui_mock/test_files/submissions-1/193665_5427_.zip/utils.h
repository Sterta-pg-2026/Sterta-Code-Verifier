﻿#pragma once
void swap(char*& a, char*& b);
void swap(int& a, int& b);

