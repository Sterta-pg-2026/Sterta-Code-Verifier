#pragma once
#include "sectionnode.h"

constexpr int TABLE_SIZE=8;

class SectionNode;

class SectionNodeTable
{
public:
	SectionNode* table[TABLE_SIZE];
	SectionNodeTable* next;
	SectionNodeTable* prev;
	int taken;

	SectionNodeTable();

	~SectionNodeTable();
};

