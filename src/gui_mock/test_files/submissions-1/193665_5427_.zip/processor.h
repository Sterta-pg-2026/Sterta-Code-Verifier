#pragma once
#include "mydoublelist.h"
#include "command_t.h"

#define ATTRIBUTE_NAME_MODE false
#define ATTRIBUTE_VALUE_MODE true
#define READ_SECTION_MODE false
#define READ_COMMAND_MODE true



class Processor
{
	MyDoubleList section_list;
	Mystring buffer;
	SectionNode* current_section = nullptr;
	command_t command;
public:
	//stops processing at EOF
	void start();

	void readSection();

	void readSelectors();

	void readAttributes();
	//-1 in int and "" in strings indicates no value
	void processCommand();

	void chooseCommand();

	void printNumberOfSections();

	void printNumberOfSelectors();

	void printNumberOfAttributes();

	void printSelector();

	void deleteSection();

	void printValueOfAttribute();

	void deleteAttribute();

	void countAttributes();

	void countSelectors();

	void findAttributeValueForSelector();

	//skips white spaces in buffer, returns new buffer iterator and start values
	void skipWhiteSpace(int& i,int& start);
};

