#include <iostream>
#include "string.h"
#include "vector.h"
String::String(): m_Size(0), m_Data(nullptr) {};

String::String(const char* string){
  m_Size = strlen(string);
  m_Data = new char[m_Size];
  strcpy(m_Data, string);
}

String::String(uint32_t size): m_Size{size}, m_Data(new char[size]){

};

String::String(const String& other){
  m_Size = other.m_Size;
  m_Data = new char[m_Size];
  strcpy(m_Data, other.m_Data);
}

String::String(String&& other) noexcept{
  m_Size = other.m_Size;
  m_Data = other.m_Data; 

  other.m_Size = 0;
  other.m_Data = nullptr;
}

String::String(Vector<char> &vector){
  this->m_Size = (uint32_t) vector.getSize();
  
  this->m_Data = new char[this->m_Size+1];
  
  for(int i = 0; i < this->m_Size; i++){
    this->m_Data[i] = vector[i];
  }
  this->m_Data[this->m_Size] = '\0';
}

String::String(StringVector &vector){
  this->m_Size = (uint32_t) vector.getSize();
  
  this->m_Data = new char[this->m_Size+1];
  
  for(int i = 0; i < this->m_Size; i++){
    this->m_Data[i] = vector[i];
  }
}


int String::length() noexcept{
  return this->m_Size;
}

std::ostream &operator<<(std::ostream &os, const String &string){
  os << string.m_Data;
  return os;
}

std::istream &operator>>(std::istream &is, String &string){
  std::istream::sentry sentry(is);
  if(!sentry){
    return is;
  }

  int next;
  Vector<char> temp;
  while((next = is.get()) != is.eof() && next != ' '){
    temp.push(next);
  }
  temp.push('\0');
  string = &temp[0];
  return is;
}

char& String::operator[](std::size_t index){
  return m_Data[index];
};
const char& String::operator[](std::size_t index) const {
  return m_Data[index];
}

String &String::operator=(const String &right) {
  String tmp = right;
  std::swap(m_Size, tmp.m_Size);
  std::swap(m_Data, tmp.m_Data);
  return *this;
}

String &String::operator=(String &&right) {
  std::swap(m_Size, right.m_Size);
  std::swap(m_Data, right.m_Data);
  return *this;
}

String::~String(){
  if(m_Data != nullptr){
    delete[] m_Data;
  }
}
