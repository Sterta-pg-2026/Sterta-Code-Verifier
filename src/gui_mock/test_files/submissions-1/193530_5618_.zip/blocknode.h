#pragma once
#include "section.h"
#include "vector.h"
#include <iostream>
#define SECTIONSIZE 8

class BlockNode {
private:
  Section sections[SECTIONSIZE];
  int occupiedSections;

public:
  BlockNode *next;
  BlockNode *prev;
  BlockNode() {
    this->next = nullptr;
    this->prev = nullptr;
    this->occupiedSections = 0;
  }
  void insertSection(String &selectors, String &attributes) {
    Vector<String> stringVector = this->divideSelectors(selectors);
    Vector<String> attributesVector = this->divideAttributes(attributes);
    short int insertedSections = 0;
    short int insertedAttributes = 0;
    if (this->occupiedSections < SECTIONSIZE){
      while(insertedSections < stringVector.getSize()){
        this->sections[this->occupiedSections].insertSelector(stringVector[insertedSections]);
        insertedSections++;
      }
      while(insertedAttributes < attributesVector.getSize()){
        this->sections[this->occupiedSections].insertAttribute(attributesVector[insertedAttributes]);
        insertedAttributes++;
      }
      this->occupiedSections++;
    }else if(this->next == nullptr){
      this->createNewBlockNode()->insertSection(selectors, attributes);
    }else{
      this->next->insertSection(selectors, attributes);
    }
  }

  void displaySectionsCount(int sectionsCount = 0) {
    int sectionsOccupied = this->occupiedSections + sectionsCount;
    if (this->next == nullptr)
      std::cout << "? == " << sectionsOccupied << std::endl;
    else
      this->next->displaySectionsCount(sectionsOccupied);
  }

  BlockNode *createNewBlockNode() {
    BlockNode *newBlockNode = new BlockNode;
    newBlockNode->prev = this;
    this->next = newBlockNode;
    return newBlockNode;
  }

  void displaySections() {
    for (int i = 0; i < this->occupiedSections; i++) {
      this->sections[i].displaySelectors();
      this->sections[i].displayAttributes();
      std::cout << std::endl;
    }
    if (this->next != nullptr) {
      this->next->displaySections();
    }
  }

  Vector<String> divideSelectors(String &selectors) {
    Vector<String> selectorVector;
    StringVector tempString;
    for (int i = 0; i < selectors.length(); i++) {
      if (selectors[i] != ',' && selectors[i] != ' ' && selectors[i] != '\n' && selectors[i] != '\r') {
        tempString.push(selectors[i]);
      } else if(tempString.getSize() > 0){
        String tmp(tempString);
        selectorVector.push(tmp);
        tempString.clear();
      }
    }
    return selectorVector;
  }

  Vector<String> divideAttributes(String &attributes){
    Vector<String> attributesVector;
    StringVector tempString;
    for(int i = 0; i < attributes.length(); i++){
      if(attributes[i] != ';'){
          tempString.push(attributes[i]);
      } else {
        tempString.push(';');
        for(int k = 0; k < tempString.getSize(); k++){
          if(tempString[k] == '\n' || tempString[k] == ' ' || tempString[k] == '\t' || tempString[k] == '\r'){
            tempString.popFromIndex(k);
          }
        }
        String tmp(tempString);
        attributesVector.push(tmp);
        tempString.clear();
      }
    }
    return attributesVector;
  }
  
  int displayAttributesCount(int &&index){
    if(index < this->occupiedSections){
      int attributesCounted = this->sections[index].countAttributes();
      return attributesCounted;
    }
    return 0;
  }

  int countAttributesForISection(int &&index){
    if(index <= SECTIONSIZE-1){
      return this->displayAttributesCount(index-1);
    }else if(this->next != nullptr){
      return this->next->countAttributesForISection(index - SECTIONSIZE);
    }
    return 0;
  }

  int displaySelectorCount(int &&index){
     if(index < this->occupiedSections){
      int selectorsCounted = this->sections[index].countSelectors();
      return selectorsCounted;
    }
    return 0;
  }

  int displaySelectorCountForISection(int &&index){
    if(index <= SECTIONSIZE){
      return this->displaySelectorCount(index-1);
    }else if(this->next != nullptr){
      return this->next->displaySelectorCountForISection(index-SECTIONSIZE);
    }
    return 0;
  }

  String displayJSelectorForISection(int &&sectionIndex, int &&index){
    if(sectionIndex <= SECTIONSIZE){
      String tmp = this->sections[sectionIndex-1].getIthSelector(index);
      if(tmp.length() > 0)
        return tmp;
      return String("");
    }else if(this->next != nullptr){
      this->next->displayJSelectorForISection(sectionIndex - SECTIONSIZE, index - 0);
    }
    return String("");
  }

  String getIthSectionAttributeValue(int &&sectionIndex, String &attributeName){
    if(sectionIndex <= SECTIONSIZE){
      return this->sections[sectionIndex-1].getAttributeValueByName(attributeName);
    } else if(this->next != nullptr){
      return this->next->getIthSectionAttributeValue(sectionIndex - SECTIONSIZE, attributeName);
    }
    return String("");
  } 
};
