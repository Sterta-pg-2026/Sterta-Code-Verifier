#pragma once
#include "blocknode.h"
#include <iostream>

class BlockList {
private:
  BlockNode *head;

public:
  BlockList() { head = new BlockNode(); }
  void insertTop() {
    BlockNode *newBlockNode = new BlockNode();
    newBlockNode->next = head;
    head->prev = newBlockNode;
    head = newBlockNode;
    return;
  }
  ~BlockList() {
    BlockNode *temp;
    while (head != nullptr) {
      temp = head;
      head = head->next;
      delete temp;
    }
  }

  void insertBottom() {
    BlockNode *newBlockNode = new BlockNode();
    newBlockNode->prev = this->getBottomBlockNode();
    this->getBottomBlockNode()->next = newBlockNode;
    return;
  }

  BlockNode *getNext(BlockNode *node) {
    if (node->next != nullptr)
      return node->next;
    return node;
  }
  BlockNode *getBottomBlockNode() {
    if (head->next == nullptr) {
      return head;
    }
    return getNextBlockNode(head);
  }

  BlockNode *getNextBlockNode(BlockNode *node) {
    if (node->next == nullptr) {
      return node;
    }
    return getNextBlockNode(node->next);
  }

  BlockNode *getHead() { return this->head; }
};
