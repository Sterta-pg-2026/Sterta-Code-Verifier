#include "block.h"
#include "blocklist.h"
#include "blocknode.h"
#include "doublylinkedlist.h"
#include "string.h"
#include "stringvector.h"
#include "vector.h"
#include <ctype.h>
#include <iostream>

void displaySectionsCommand(StringVector &command, BlockList &blockList);
void displayAttributesCommand(StringVector &command, BlockList &blockList);
void displayJSelectorForISection(StringVector &command, BlockList &blockList);
void displayIthSectionAttributeValue(StringVector &command, BlockList &blockList);
int main() {
  BlockList blockList;
  char in;
  StringVector tempString;
  StringVector commandString;
  StringVector command;
  while (std::cin.get(in)) {
    switch (in) {
    case '{': {
      String selectors(tempString);
      tempString.clear();
      while (std::cin.get(in) && in != '}') {
        tempString.push(in);
      }
      String attributes(tempString);
      tempString.clear();
      blockList.getHead()->insertSection(selectors, attributes);
      tempString.clear();
      break;
    }
    case '?': {
      short int commandFlag = 0;
      for (int i = 0; i < 3; i++) {
        if (std::cin.get(in) && in == '?')
          commandFlag++;
      }
      if (commandFlag != 3)
        break;
      while (std::cin.get(in)) {
        commandString.push(in);
      }
      for (int i = 0; i < commandString.getSize(); i++) {
        if (commandString[i] != '\n') {
          command.push(commandString[i]);
        } else {
          if (command[0] == '?') {
            blockList.getHead()->displaySectionsCount();
          } else if (isdigit(command[0])) {
            switch (command[2]) {
            case 'S': {
              switch (command[4]) {
              case '?': {
                displaySectionsCommand(command, blockList);
                break;
              }
              default: {
                if (isdigit(command[4])) {
                  displayJSelectorForISection(command, blockList);
                } else {
                }
              }
              }
              break;
            }
            case 'A': {
              switch (command[4]) {
              case '?': {
                displayAttributesCommand(command, blockList);
                break;
              }
              default: {
                displayIthSectionAttributeValue(command, blockList); 
              }
              }
              break;
            }
            case 'D': {
              std::cout << "komenda D" << std::endl;
              break;
            }
            }
          } else if (command[0] != '\r') {
            std::cout << "to to->" << (int)command[0] << "<- to to";
            std::cout << "tu jakis selektor" << std::endl;
          }
          command.clear();
        }
      }
      break;
    }
    default:
      tempString.push(in);
      break;
    }
  }
  //blockList.getHead()->displaySections();
  return 0;
}

void displaySectionsCommand(StringVector &command, BlockList &blockList) {
  int s =
      blockList.getHead()->displaySelectorCountForISection(command[0] - '0');
  if (s) {
    for (int i = 0; i < command.getSize(); i++) {
      if (command[i] != '\r') {
        std::cout << command[i];
      }
    }
    std::cout << " == " << s << std::endl;
  }
}

void displayAttributesCommand(StringVector &command, BlockList &blockList) {
  int a = blockList.getHead()->countAttributesForISection(command[0] - '0');
  if (a) {
    for (int i = 0; i < command.getSize(); i++) {
      if (command[i] != '\r') {
        std::cout << command[i];
      }
    }
    std::cout << " == " << a << std::endl;
  }
}

void displayJSelectorForISection(StringVector &command, BlockList &blockList) {
  // command[0] = j, command[4] = i
  String d = blockList.getHead()->displayJSelectorForISection(command[0] - '0',
                                                 command[4] - '0');
  if(d.length() >0){
  for (int i = 0; i < command.getSize(); i++) {
    if (command[i] != '\r') {
      std::cout << command[i];
    }
  }
  std::cout << " == " << d;
  std::cout << std::endl;
  }
}

void displayIthSectionAttributeValue(StringVector &command, BlockList &blockList){
  for(int i = 0; i < command.getSize(); i++){
    if(command[i] != '\r'){
      std::cout << command[i];
    }
  }
  int commaCounter = 0;
  StringVector tmp;
  for(int i = 0; i < command.getSize(); i++){
    if(command[i] == ','){
      commaCounter++;
      continue;
    }
    if(commaCounter == 2 && command[i] != '\r'){
      tmp.push(command[i]);
    }
  }
  String attribute(tmp);
  String attributeValue = blockList.getHead()->getIthSectionAttributeValue(command[0] - '0', attribute);
}
