#pragma once
#include <iostream>

template<typename DT> class Node{
  public:
    Node* next;
    Node* prev;
    DT data;
    Node(){
      next = nullptr;
      prev = nullptr;
    }
};
