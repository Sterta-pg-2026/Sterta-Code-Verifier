#pragma once
#include <iostream>
#include "vector.h"
#include "stringvector.h"

class String{
  private:
    char* m_Data;
    uint32_t m_Size;
    friend std::ostream &operator<<(std::ostream &os, const String &string);
    friend std::istream &operator>>(std::istream &is, String &string); 
  protected:
  public:
    String();
    String(uint32_t size);
    String(const char* string);
    String(const String& other);
    String(String&& other) noexcept;
    String(Vector<char> &vector);
    String(StringVector &vector);
    int length() noexcept;
    char& operator[](std::size_t index);
    const char& operator[](std::size_t index) const;
    String& operator=(const String& right);
    String& operator=(String&& right); 
    ~String();
};
