#pragma once
#include "node.h"
#include <iostream>

template <typename DT> class DoublyLinkedList {
private:
  Node<DT> *head;

public:
  DoublyLinkedList() { this->head = nullptr; }

  void insertTop(DT newData) {
    Node<DT> *newNode = new Node<DT>();
    newNode->data = newData;
    if (this->head == nullptr) {
      this->head = newNode;
    } else {
      newNode->next = head;
      this->head->prev = newNode;
      this->head = newNode;
    }
    return;
  }

  ~DoublyLinkedList() {
    Node<DT> *temp;
    while (head != nullptr) {
      temp = head;
      head = head->next;
      delete temp;
    }
  }

  void insertBottom(DT newData) {
    Node<DT> *newNode = new Node<DT>(); 
    newNode->data = newData;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    if (this->head == nullptr){
      this->head = newNode;
    }
    else{
      newNode->prev = this->getBottomNode();
      this->getBottomNode()->next = newNode;
    }
    return;
  }

  Node<DT> *getNext(Node<DT> *node) {
    if (node->next != nullptr)
      return node->next;
    return node;
  }
  Node<DT> *getBottomNode() {
    if(this->head == nullptr){
      return nullptr;
    }
    Node<DT> *ptr = this->head;
    while(ptr->next != nullptr){
      ptr = ptr->next;
    }
    return ptr;
  }

  Node<DT> *getNextNode(Node<DT> *node) {
    if (node->next == nullptr) {
      return node;
    }
    return getNextNode(node->next);
  }

  Node<DT> *getHead() { return this->head; }
};
