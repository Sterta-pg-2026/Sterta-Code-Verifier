#pragma once
#include <iostream>

template <typename DT> class Vector {
private:
  DT *data;
  size_t capacity;
  size_t size;

public:
  Vector() {
    data = new DT[32];
    capacity = 31;
    size = 0;
  }
  ~Vector() { delete[] data; }

  void push(DT newData) {
    if (this->size == this->capacity) {
      this->resize();
    }
    this->data[this->size] = newData;
    this->size++;
  }

  void pop() { this->size--; }

  void resize() {
    DT *temp = new DT[2 * this->capacity];
    for (int i = 0; i < this->size; i++) {
      temp[i] = this->data[i];
    }
    delete[] data;
    this->capacity *= 2;
    data = temp;
  }

  void clear() {
    if (typeid(DT) == typeid(char)) {
      for (int i = 0; i < this->size; i++) {
        this->data[i] = ' ';
      }
    } else {
      for (DT *d = this->data; d != this->data + this->size; ++d) {
        d->~DT();
      }
    }

    this->size = 0;
  }

  DT &operator[](size_t index) { return this->data[index]; }

  const DT &operator[](size_t index) const { return this->data[index]; };

  size_t getSize() { return this->size; }
};
