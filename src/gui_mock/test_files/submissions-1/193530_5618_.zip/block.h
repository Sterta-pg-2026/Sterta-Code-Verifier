#pragma once
#include "doublylinkedlist.h"
#include "section.h"
#include "string.h"
#include <iostream>

#define BLOCKSIZE 8

class Block {
private:
  Section *sectionArr;
  Block* prev;
  Block* next;
  short int occupiedSpace;
public:
  Block(Block* next, Block* prev){
    this->next = nullptr;
    this->prev = nullptr;
    this->sectionArr = new Section[BLOCKSIZE];
    this->occupiedSpace = 0;
  }
  String getSection(size_t index) { return "asd"; }
  void insertToSection(String selector, String attribute){
    this->sectionArr[this->occupiedSpace].insertSelector(selector);
    this->sectionArr[this->occupiedSpace++].insertAttribute(attribute);
  }
};
