#pragma once
#include <iostream>

class StringVector {
private:
  char *data;
  size_t capacity;
  size_t size;

public:
  StringVector() {
    data = new char[32];
    capacity = 31;
    size = 0;
    this->clear();
  }
  ~StringVector() { delete[] data; }

  void push(char newData) {
    if (this->size == this->capacity) {
      this->resize();
    }
    this->data[this->size] = newData;
    this->size += 1;
  }

  void pop() { this->size--; }

  void popFromIndex(int index){
    for(int i = index; i < this->size-1; i++){
      this->data[i] = this->data[i+1];
    }
    this->size--;
  }

  void resize() {
    char *temp = new char[2 * this->capacity];
    strcpy(temp, this->data);
    delete data;
    this->capacity *= 2;
    data = temp;
  }

  void clear() {
    for (int i = 0; i < this->capacity; i++) {
      this->data[i] = ' ';
    }
    this->size = 0;
  }

  char &operator[](size_t index) { return this->data[index]; }

  const char &operator[](size_t index) const { return this->data[index]; };

  size_t getSize() { return this->size; }

  friend std::ostream &operator<<(std::ostream &os, const StringVector &stringVector) {
    for(int i = 0; i < stringVector.size; i++){
      os << stringVector.data[i];
    }
    return os;
  }
};
