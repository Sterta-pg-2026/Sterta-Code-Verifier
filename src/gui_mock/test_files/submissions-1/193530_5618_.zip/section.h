#pragma once
#include "doublylinkedlist.h"
#include "string.h"
#include <iostream>
class Section {
private:
  DoublyLinkedList<String> *selectorList;
  DoublyLinkedList<String> *attributeList;
  int attributesCount;
  int selectorsCount;

public:
  Section() {
    this->selectorList = new DoublyLinkedList<String>();
    this->attributeList = new DoublyLinkedList<String>();
    this->attributesCount = 0;
    this->selectorsCount = 0;
  }
  void insertSelector(String selector) {
    this->selectorList->insertBottom(selector);
    this->selectorsCount++;
  }
  void insertAttribute(String attribute) {
    this->attributeList->insertBottom(attribute);
    this->attributesCount++;
  }
  void displaySelectors() {
    std::cout << selectorList->getHead()->data << std::endl;
  }
  void displayAttributes() {
    std::cout << attributeList->getHead()->data << std::endl;
  }

  String getIthSelector(int &index) {
    if (this->selectorList->getHead() != nullptr &&
        index <= this->selectorsCount) {
      if (index == 1) {
        return this->selectorList->getHead()->data;
      } else {
        int selectorCounter = 1;
        Node<String> *tmp = this->selectorList->getHead();
        while (selectorCounter != index && tmp->next != nullptr) {
          tmp = tmp->next;
          selectorCounter++;
        }
        if (selectorCounter == index) {
          return tmp->data;
        }
        tmp = nullptr;
        return String("");
      }
    }
    return String("");
  }

  String getAttributeValueByName(String &attributeName) {
    if (this->attributeList->getHead() != nullptr) {
      Node<String> *tempNode = this->attributeList->getHead();
      String tmp = tempNode->data;
      if(compareAttributes(attributeName, tmp))
              return true;
      while(tempNode->next != nullptr){
        tempNode = tempNode->next;
        tmp = tempNode->data;
        if(compareAttributes(attributeName, tmp)){
          std::cout << "znaleziono";
          return String("");
        }
      }
      return String("");
    }
    return String("");
  }

  bool compareAttributes(String &attr1, String &attr2) {
    if (attr1.length() >= attr2.length()) {
      for (int i = 0; i < attr2.length(); i++) {
        if (attr1[i] != attr2[i])
          return false;
        return true;
      }
    } else {
      for (int i = 0; i < attr1.length(); i++) {
        if (attr1[i] != attr2[i])
          return false;
        return true;
      }
    }
    return false;
  }

  int countAttributes() { return this->attributesCount; }

  int countSelectors() { return this->selectorsCount; }
};
