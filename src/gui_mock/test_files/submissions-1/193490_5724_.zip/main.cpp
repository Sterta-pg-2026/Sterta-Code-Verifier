#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <cstring>
#include <sstream>
#define T 8
#define MAX_WORDS 100
#define klamra1 '{'
#define klamra2 '}'
using namespace std;

// obliczanie dlugosci stringa
int length(char* str)
{
    int l = 0;
    while (*str++)
    {
        l++;
    }
    return l;
}

// klasa string
class myString
{
public:
    char* mystring;
    int size;

    friend ostream& operator<<(ostream& os, const myString& str);
    friend istream& operator>>(istream& is, myString& str);


public:
    // Function to illustrate Constructor with no argument
    myString()
    {
        size = 0;
        mystring = new char[size + 1];
        mystring[0] = '\0';
    }
    // constructor
    myString( char* str)
    {

        
        size = length(str);
        mystring = new char[size + 1];

        int i = 0;
        while (str[i] != '\0')
        {
            mystring[i] = str[i];
            i++;
        }

        mystring[size] = char('\0');
        
    }
    void PrintString()
    {
        for (int i = 0; i < size; i++)
        {
            cout << mystring[i];
        }
    }


    // Substring function
    myString substring(int start, int end) const {
        if (start < 0 || start >= size || end < 0 || end > size || start >= end) {
            // Invalid start and/or end indices
            return myString();
        }
        
        int len = end - start;
        char* buffer = new char[len + 1];
        
        for (int i = 0; i < len; i++) {
            buffer[i] = mystring[start + i];
        }
        buffer[len] = '\0';
        //delete buffer;
        return myString(buffer);
    }

    myString& operator=(const myString& other)
    {
        if (this != &other) {
            // allocate memory for new data
            char* new_string = new char[other.size + 1];

            // copy data from other object
            for (int i = 0; i < other.size; i++) {
                new_string[i] = other.mystring[i];
            }
            new_string[other.size] = '\0';

            // delete existing data and update the pointer
            delete[] mystring;
            mystring = new_string;
            size = other.size;
        }

        return *this;
    }

    char& operator[](int index)
    {
        if (index >= 0 && index < size) {
            return mystring[index];
        }
        else {
            throw out_of_range("Index out of range");
        }
    }

    const char& operator[](int index) const
    {
        if (index >= 0 && index < size) {
            return mystring[index];
        }
        else {
            throw out_of_range("Index out of range");
        }
    }

    myString& operator+=(const myString& other)
    {
        int new_size = size + other.size;
        char* new_string = new char[new_size + 1];

        // copy data from current object
        for (int i = 0; i < size; i++) {
            new_string[i] = mystring[i];
        }

        // copy data from other object
        for (int i = 0; i < other.size; i++) {
            new_string[size + i] = other.mystring[i];
        }
        new_string[new_size] = '\0';

        // delete existing data and update the pointer
        delete[] mystring;
        mystring = new_string;
        size = new_size;

        return *this;
    }

    bool operator==(const myString& other) const {
        if (size != other.size) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (mystring[i] != other.mystring[i]) {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const myString& other) const {
        return !(*this == other);
    }


};

ostream& operator<<(ostream& os, const myString& str)
{
    for (int i = 0; i < str.size; i++)
    {
        cout << str.mystring[i];
    }
    return os;
}

istream& operator>>(istream& is, myString& str)
{
    char buffer[1024];
    is >> buffer;
    myString temp(buffer);
    str = temp;
    return is;
}




struct SingleNode
{
    myString data;
    SingleNode* next;
};


/*class List
{
public:
    SingleNode* head ;
    List()
    {
        head = nullptr;
        head = new SingleNode();
    }


    int length() const {
        int count = 0;
        SingleNode* current = head;
        while (current != nullptr) {
            count++;
            current = current->next;
        }
        return count;
    }

    
};




struct Block {

    List* attributeValue;
    List* attributeName;
    List* selector;

    Block() {
        attributeValue = new List();
        attributeName = new List();
        selector = new List();
    }

    int countSelectors() const {
        int count = 0;
        SingleNode* current = selector->head;
        while (current != nullptr) {
            count++;
            current = current->next;
        }
        return count;
    }

    int countAttributeNames() const {
        int count = 0;
        SingleNode* current = attributeName->head;
        while (current != nullptr) {
            count++;
            current = current->next;
        }
        return count;
    }

    ~Block() {
        delete[] attributeValue;
        delete[] attributeName;
        delete[] selector;
    }
}; */

// node structure
struct DoubleNode
{
    DoubleNode* next;
    DoubleNode* prev;

};


class DoubleLinkedList
{
public:
    DoubleNode* head; //dorob tail
    DoubleNode* tail;

    // constructor to create an empty LinkedList
    DoubleLinkedList()
    {
        head = nullptr;
        tail = nullptr;

        head = new DoubleNode();

    }



    DoubleNode* get_block(int block_no) {

        DoubleNode* temp = head;
        int cnt = 0;
        if (temp != nullptr)
        {
            while (temp != nullptr)
            {
                if (cnt == block_no) {
                    return temp;
                }
                temp = temp->next;
                cnt++;
            }
        }
        return nullptr;
    }

    void push_back(DoubleNode* newNode)
    {
        if (head == nullptr)
        {
            newNode->next = nullptr;
            newNode->prev = head;
        }
        else
        {
            DoubleNode* temp = head;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newNode;
            newNode->prev = temp;
        }
    }


    void PrintList()
    {
        DoubleNode* temp = head;
        if (temp != nullptr)
        {
            while (temp != nullptr)
            {
                cout << temp << " " << endl;
                temp = temp->next;
            }

        }
        else
        {
            cout << "The list is empty.\n";
        }
    }

    ~DoubleLinkedList()
    {
        DoubleNode* temp = head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
            delete[] temp;
        }
    }
};

struct NewListNode
{
    NewListNode* next;
    NewListNode* prev;
    myString data;
};

class NewList
{
public:
    NewListNode* head; //dorob tail


    // constructor to create an empty LinkedList
    NewList()
    {
        head = nullptr;

    }


    void push_back(NewListNode* newNode)
    {
        if (head == nullptr)
        {
            head = new NewListNode();
            this->head->next = nullptr;
            this->head->prev = nullptr;
            this->head->data = newNode->data;
            
        }
        else
        {
            NewListNode* temp = this->head;
            while (temp->next != nullptr)
                temp = temp->next;

            temp->next = new NewListNode();
            temp->next->data = newNode->data;
            temp->prev = temp;
            //newNode->prev = temp;
        }
    }

    int length() {
        int count = 0;
        NewListNode* temp = this->head;
        while (temp != nullptr)
        {
            temp = temp->next;
            count++;
        }
        return count;
    
    }

    void clear() {



        this->head = nullptr;

    }

    void PrintList()
    {
        NewListNode* temp = this->head;
        int i = 0;
        if (temp != nullptr)
        {
            while (temp != nullptr)
            {
                cout << i<<" : " << temp->data  << endl;
                temp = temp->next;
                i++;
            }

        }
        else
        {
            cout << "The list is empty.\n";
        }
    }

     NewListNode& operator[](int index)
    {
        if (index >= 0 && index < this->length()) {
            int count = 0;
            NewListNode* temp = this->head;
            while (count != index)
            {
                temp = temp->next;
                count++;
            }
            return *temp;
        }
        else {
            throw out_of_range("Index out of range");
        }
    }

};


struct NewBlock
{
    NewBlock* next;
    NewBlock* prev;

	// ===== data =====
    //NewList selectors;
    myString selector;
    NewList attributes;
    NewList values;
};

class NewBlockList
{
public:
    NewBlock* head; //dorob tail


    // constructor to create an empty LinkedList
    NewBlockList()
    {
        head = nullptr;


        //head = new NewListNode();

    }


    void push_back(NewBlock* newNode)
    {
        if (head == nullptr)
        {
            head = new NewBlock();
            this->head->next = nullptr;
            this->head->prev = nullptr;
            // == copy data ==
            this->head->selector = newNode->selector;
            this->head->attributes = newNode->attributes;
            this->head->values = newNode->values;

        }
        else
        {
            NewBlock* temp = this->head;
            while (temp->next != nullptr)
                temp = temp->next;

            temp->next = new NewBlock();
           
            // == copy data ==
            temp->next->selector = newNode->selector;
            temp->next->attributes = newNode->attributes;
            temp->next->values = newNode->values;

            temp->prev = temp;
            //newNode->prev = temp;
        }
    }

    int length() {
        int count = 0;
        NewBlock* temp = this->head;
        while (temp != nullptr)
        {
            temp = temp->next;
            count++;
        }
        return count;

    }

    void clear() {

        this->head = nullptr;

    }


    NewBlock& operator[](int index)
    {
        if (index >= 0 && index < this->length()) {
            int count = 0;
            NewBlock* temp = this->head;
            while (count != index)
            {
                temp = temp->next;
                count++;
            }
            return *temp;
        }
        else {
            throw out_of_range("Index out of range");
        }
    }

    ~NewBlockList()
    {
        NewBlock* temp = this->head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
            delete[] temp;
        }
    }
};




bool isNumber(char st)
{
    int i = 0;
    if (st < 48 || st > 57)
        return false;
    i++;
    return true;
}


///////////////////////////////////////////////// MAIN //////////////////////////////////////////////////////
int main()
{
    
    char arr[200] = "";
    myString data(arr);

	NewBlockList blocks;

    
    int selektory_w_sekcji;
    int atrybuty_w_sekcji;

    bool wczytywanie_css = true;
    bool wczytywanie_komend = false;
    bool procesuj_css = false;
    bool wypisz_dane = true;

    int sekcje = 0;

    int bloki = 0;



    
    while (1) {

        while (1) {
            char tab[100] = " ";
            myString s(tab);
            cin >> s;

            char c1[] = "????";
            char c2[] = "****";
            char c3[] = "DDDD";

            myString a(c1);
            myString b(c2);
            myString c(c3);
            
            if (s == a) {
                wczytywanie_css = false;
                wczytywanie_komend = true;
                procesuj_css = true;
                
                //cout << "Otrzymalem: " << endl << data << endl<<endl;
                break;
            }
            if (s == b) {
                wczytywanie_css = true;
                wczytywanie_komend = false;
                break;

            }
            if (s == c) {
                wypisz_dane = true;
                wczytywanie_komend = false;
                wczytywanie_css = false;
                break;
            }

            if (wczytywanie_css) {
          
                data += s;
            }

        }



        // ========================== PARSOWANIE CSSa =============================

        int last_delm = 0;

        bool klasa = true;
        bool atrybut = false;
        bool wartosc = false;

        //Block* processBlock = new Block();
        
        NewList selectors ;
        NewList attributes;
        NewList values;

        if (procesuj_css) {
            for (int i = 0; i < length(data.mystring); i++) {  // parsuj CSSa

                if (klasa) {

                    if (data[i] == ',') {
                        myString s = data.substring(last_delm, i);

                        NewListNode nln;
                        nln.data = s;
                        selectors.push_back(&nln);

                        
                        last_delm = i + 1;

                    }

                    if (data[i] == '{') {
                        myString s = data.substring(last_delm, i);


                        NewListNode nln;
                        nln.data = s;
                        selectors.push_back(&nln);

                        
                        last_delm = i + 1;

                        klasa = false;
                        atrybut = true;
                        wartosc = false;

                    }



                }

                if (atrybut) {
                    if (data[i] == ':') {
                        myString s = data.substring(last_delm, i);

                        NewListNode nln;
                        nln.data = s;
                        attributes.push_back(&nln);
                        
                        last_delm = i + 1;

                        klasa = false;
                        atrybut = false;
                        wartosc = true;
                    }




                }

                if (wartosc) {
                    if (data[i] == ';') {
                        myString s = data.substring(last_delm, i);


                        NewListNode nln;
                        nln.data = s;
                        values.push_back(&nln);

                        last_delm = i + 1;

                        klasa = false;
                        atrybut = true;
                        wartosc = false;
                    }


                }

                if (data[i] == '}') { // koniec bloku
                    last_delm = i + 1;
                    sekcje++;
                    cout << "Mam sekcje: " << sekcje << endl;

                    
                    for (int i = 0; i < selectors.length(); i++) {  // iterujemy po klasach
                        
                        

                        //cout << "Selektor: " << selectors[i].data << endl;
                        for (int j = 0; j < attributes.length(); j++) {		// wyświetlamy dla debugu

                           // cout << "     " << attributes[j].data << " ---->  " << values[j].data << endl;

                        }
                        int index_selektora = 0;
                        bool brak_selektora = true;
                        for (int j = 0; j < blocks.length(); j++) {		// sprawdzamy czy selektor istnieje


                                if (blocks[j].selector == selectors[i].data) {
                                    brak_selektora = false;
                                    index_selektora = j;
                                    break;
                                }
                            
                            
                        }
                    
                    
                        
                        if (brak_selektora) {	// tworzymy nowy selektor

							NewBlock nb ;
							nb.selector = selectors[i].data;
                            nb.attributes = attributes;
							nb.values = values;
                            
                            //cout << "Zapisuje nowy selektor: " << selectors[i].data << endl;
                            
							blocks.push_back(&nb);
                           


                        }
                        else { // selektor istnieje o indexie index_selektora

                            // znajdź czy któryś z atrybutów się powtarza
                            
                            for (int k = 0; k < attributes.length(); k++) {		// iterujemy po atrybutach


                                bool brak_atrybutu = true;
                                int index_atrubutu = 0;
                                for (int j = 0; j < blocks[index_selektora].attributes.length(); j++) { // sprawdzamy czy atrybut istnieje

                                    if (blocks[index_selektora].attributes[j].data == attributes[k].data) {

                                        
                                        blocks[index_selektora].values[index_atrubutu].data = values[k].data;

                                        brak_atrybutu = false;
                                        index_atrubutu = j;
                                        //break;
                                    }
                                }



                                if (brak_atrybutu) {

                                    NewListNode nln1;
                                    nln1.data = attributes[k].data;
                                    NewListNode nln2;
                                    nln2.data = values[k].data;

                                    blocks[index_selektora].attributes.push_back(&nln1);
                                    blocks[index_selektora].values.push_back(&nln2);

                                }
                
                            }


                        }

                    }
                    
                    // koniec sekcji



                    // koniec wczytywanego bloku czyścimy dane
                     
                    selectors.clear();
                    attributes.clear();
                    values.clear();

                    

                    // koniec sekcji

                   

                    klasa = true;
                    atrybut = false;
                    wartosc = false;
                }


            }

            procesuj_css = false;

        }
        // koniec wczytywania CSS - wy�wietlamy dane

        if (wypisz_dane) {
            

            for (int j = 0; j < blocks.length(); j++) {

                cout << blocks[j].selector << endl;


            }

            cout << endl << endl << endl;

            for (int i = 0; i < blocks.length(); i++) {


                for (int k = 0; k < blocks[i].attributes.length(); k++) {
                    cout <<"        " << blocks[i].attributes[k].data << " posiada wartosc: " << blocks[i].values[k].data << endl;
                }

                cout << endl << "---------------------------------------------------------" << endl;


            }

            cout << endl << endl << endl;



            wypisz_dane = false;
            //while (1);
        }



        // ========================= KOMENDY =====================================

        while (wczytywanie_komend) {
            myString s;
            cin >> s;

            char c1[] = "**";
            myString a(c1);
            myString b(c1);

            if (s == a) { // ewentualny powr�t do wczytywania CSS
                wczytywanie_css = true;
                wczytywanie_komend = false;
            }


            // =========================== KOMENDA 1 =======================================
            // ? - print the number of CSS sections; 
            char c2[] = "?";
            a = c2;
            
            if (s == a) {

                cout << " == " << sekcje << endl;

            }
            else {
                char tmp[] = "";
                myString s1(tmp), s2(tmp), s3(tmp);
                int dlm = 0;
                int cnt = 0;

                for (int i = 0; i < length(arr); i++) {


                    if (s[i] == ',') {
                        myString tmp = s.substring(dlm, i - dlm);

                        if (cnt == 0)
                            s1 = tmp;
                        if (cnt == 1)
                            s2 = tmp;
                        dlm = i + 1;
                        cnt++;

                    }
                    s3 = s.substring(dlm, 1000);
                }

                //cout << "Mam: " << s1 << " | " << s2 << " | " << s3 << endl;

            // =========================== KOMENDA 2 =======================================
            // i,S,? - print the number of selectors for section number i 
            // (section and attribute numbers start from 1), if there is no such block, skip;
                
                char c2[] = "?";
                a = c2;
                
                char c3[] = "S";
                b = c3;

                if (s2 == b && a == a) {
                    stringstream ss;
                    ss << s1;
                    int i = 0;
                    ss >> i;

                    //cout << " == " << blocks[i].selectors.length() << endl;
                }

                // =========================== KOMENDA 3 =======================================
                //i,A,? - print the number of attributes for section number i, if there is no such block or section,skip;

                char c4[] = "?";
                a = c4;

                char c5[] = "S";
                b = c5;

                if (s2 == b && s3 == a) {
                    stringstream ss;
                    ss << s1;
                    int i = 0;
                    ss >> i;

                    //cout << " == " << blocks[i].attributes.length() << endl;
                }


                // ============================== KOMENDA 4 ========================================

                // i,S,j - print j-th selector for the i-th block, if there is no section or selector, skip
                

            }





        }



        

    }



    return 0;
}