#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include"doublelinkedlist.h"
using namespace std;

typedef enum {
	START,
	SELECTORS,
	SELSPACE,
	ATTRIBUTESNAME,
	ATTRIBUTESVALUE,
	COMMANDS,
	NEWBLOCK,
	SECTIONEND,
	SELECTORSEND,
	ATTSPACE
} Mode;


struct sections {
	DoubleLinkedList<attribute>* attr;
	DoubleLinkedList<char*>* sel;
};

char* copy(char* tmp) {
	char* result = new char[CSS_NAME];
	for (int i = 0; tmp[i - 1] != '\0'; i++) result[i] = tmp[i];
	return result;
}
char* copy(char* source, char* destination) {
	for (int i = 0; source[i-1] != '\0'; i++) destination[i] = source[i];
	return destination;
}

int isLetter(char* tab) {
	if (atoi(tab) == 0) return 1;
	return 0;
}

char* removeWhiteSpaces(char* tab, int i) {
	while (tab[i] <= ' ') {
		tab[i] = '\0';
		i--;
	}
	return tab;
}
void getName(char  tab[CSS_NAME], int& i, char nextletter) {
	tab[i] = nextletter;
	i++;
	while (true) {
		char a = getchar();
		if (a == '\n') break;
		tab[i] = a;
		i++;
	}
	tab[i] = '\0';
}

int countAllSel(DoubleLinkedList<sections>* first, char* tab) {
	int sum = 0;
	for (int i = 0; i < first->getSecNumber(first); i++) {
		sum += first->getElement(i).sel->countRepSel(first->getElement(i).sel, tab);
	}
	return sum;

}

int countAllAttr(DoubleLinkedList<sections>* first, char* tab) {
	int sum = 0;
	for (int i = 0; i < first->getSecNumber(first); i++) {
		sum += first->getElement(i).attr->countRepAttr(first->getElement(i).attr, tab);
	}
	return sum;

}

void addSelectors(Mode& state, sections& section, DoubleLinkedList<char*>*& firstSel, char* tab) {
	DoubleLinkedList<char*>* nodeSel;
	if (tab[0] == '\0') {
		if (state == SECTIONEND || state == NEWBLOCK) {
			section.attr = new DoubleLinkedList<attribute>(1);
		}
		else if (state == START) {
			 section.sel=NULL;
		}
		return;
	}
	if (state == SECTIONEND || state == NEWBLOCK) {
		section.sel = new DoubleLinkedList<char*>(CSS_NAME);
		section.attr = new DoubleLinkedList<attribute>(1);
		firstSel = section.sel;
		section.sel->insertSel(copy(tab), firstSel);
	}
	else if (state != START) {
		nodeSel = section.sel->seekSelName(section.sel, tab);
		if (nodeSel == NULL) {
			firstSel = section.sel->addLast(section.sel);
			section.sel->insertSel(copy(tab), firstSel);
		}
		else section.sel->insertSel(copy(tab), nodeSel);
	}
	else {
		section.sel->insertSel(copy(tab), firstSel);
	}

}

void addAttributes(DoubleLinkedList<attribute>*& nodeAttr, sections& section, attribute& at, bool rep, DoubleLinkedList<attribute>*& firstAttr) {
	nodeAttr = section.attr->seekAttrName(section.attr, at.name);
	if (nodeAttr == NULL) {
		if (rep != false) {
			section.attr->addLast(section.attr);
		}
		firstAttr = section.attr->getLast(section.attr);
		section.attr->insertAttr(at, firstAttr);
	}
	else section.attr->insertAttr(at, nodeAttr);
}

void readCSS(Mode& state, char  tab[CSS_NAME], int& i) {
	if (state == COMMANDS) {
		tab[i - 1] = '\0';
		char second = getchar();
		char third = getchar();
		char fourth = getchar();
		if (second == '*' && third == '*' && fourth == '*' && state == COMMANDS) state = NEWBLOCK;
		i = 0;
	}
}

void findLastOccurence(const Mode& state, int& i, char  tab[CSS_NAME], DoubleLinkedList<sections>* first, DoubleLinkedList<sections>* last) {// komenda E
	if (state == COMMANDS) {
		if (i >= 2 && tab[i - 2] == ',') {
			tab[i - 2] = '\0';
			char* sel = copy(tab);
			char letter = getchar();
			if (letter == ',') {
				i = 0;
				char nextletter = getchar();
				if ((nextletter >= 'a' && nextletter <= 'z') || (nextletter >= 'A' && nextletter <= 'Z')) {
					tab[i] = nextletter;
					i++;
					while (true) {
						char a = getchar();
						if (a == '\n') break;
						tab[i] = a;
						i++;
					}
					tab[i] = '\0';
					if (first->findNodeFromEnd(last, sel, tab) != NULL)
						cout << sel << ",E," << tab << " == " << first->findNodeFromEnd(last, sel, tab) << endl;
				}
			}
			delete[] sel;
		}
		i = 0;
	}
}

void deleteElements(const Mode& state, char  tab[CSS_NAME], int& i, DoubleLinkedList<sections>* first) {// komenda D
	if (state == COMMANDS) {
		tab[i - 1] = '\0';
		if (i >= 2 && tab[i - 2] == ',') {
			tab[i - 2] = '\0';
			int sectionNumber = atoi(tab);
			char letter = getchar();
			if (letter == ',') {
				i = 0;
				char nextletter = getchar();
				if (nextletter == '*' && first->contain(sectionNumber-1 )) {
					first->removeElement(sectionNumber - 1);
					cout << sectionNumber << ",D,* == deleted" << endl;
				}
				if ((nextletter >= 'a' && nextletter <= 'z') || (nextletter >= 'A' && nextletter <= 'Z')) {
					getName(tab, i, nextletter);
					if (first->contain(sectionNumber - 1) && first->getElement(sectionNumber - 1).attr->findNode(first->getElement(sectionNumber - 1).attr, tab) != -1) {
						sections currentSection = first->getElement(sectionNumber - 1);
						int attributeNumber = currentSection.attr->findNode(first->getElement(sectionNumber - 1).attr, tab);
						currentSection.attr->removeElement(attributeNumber);
						if (currentSection.attr->getLen(currentSection.attr) == 0) {
							first->removeElement(sectionNumber - 1);
						}
						cout << sectionNumber << ",D," << tab << " == deleted" << endl;
					}
				}
			}
		}
		i = 0;
	}
}

void manageSelectors(const Mode& state, char  tab[CSS_NAME], int& i, DoubleLinkedList<sections>* first) { //komenda S
	if (state == COMMANDS) {
		tab[i - 1] = '\0';
		if (i >= 2 && tab[i - 2] == ',') {
			tab[i - 2] = '\0';
			int sign = isLetter(tab);
			if (sign == 0) {
				int sectionNumber = atoi(tab);
				char letter = getchar();
				if (letter == ',') {
					i = 0;
					char nextletter = getchar();
					if (nextletter >= '0' && nextletter <= '9') {
						tab[i] = nextletter;
						i++;
						while (getchar() != '\n') {
							tab[i] = getchar();
							i++;
						}
						tab[i] = '\0';
						int selectorNumber = atoi(tab);
						if ((first->contain(sectionNumber - 1) == false) || (first->getElement(sectionNumber - 1).sel->contain(first->getElement(sectionNumber - 1).sel, selectorNumber - 1) == false)) {
							i = 0;
							 return;
						}
						cout << sectionNumber << ",S," << selectorNumber << " == " << first->getElement(sectionNumber - 1).sel->getElement(first->getElement(sectionNumber - 1).sel, selectorNumber - 1) << endl;
					}
					else if (nextletter == '?') {
						if (first->SelInSection(first, atoi(tab)) == -1) {
							i = 0;
							return;
						}
						cout << atoi(tab) << ",S,? == " << first->SelInSection(first, atoi(tab)) << endl;
					}
				}
			}
			else {
				char letter = getchar();
				char nextletter = getchar();
				if (letter == ',' && nextletter == '?') {
					cout << tab << ",S,? == " << countAllSel(first, tab) << endl;
				}
			}
		}
		i = 0;
	}
}

void manageAttributes(const Mode& state, char  tab[CSS_NAME], int& i, DoubleLinkedList<sections>* first){ //komenda A
	if (state == COMMANDS) {
		tab[i - 1] = '\0';
		if (i >= 2 && tab[i - 2] == ',') {
			tab[i - 2] = '\0';
			int check = isLetter(tab);
			if (check == 0) {
				int sectionNumber = atoi(tab);
				char letter = getchar();
				if (letter == ',') {
					i = 0;
					char nextletter = getchar();
					if ((nextletter >= 'a' && nextletter <= 'z') || (nextletter >= 'A' && nextletter <= 'Z')) {
						getName(tab, i, nextletter);
						if ((first->contain(sectionNumber - 1) == false) || first->getElement(sectionNumber - 1).attr->findNode(first->getElement(sectionNumber - 1).attr, tab) == -1) {
							i = 0;
							 return;
						}
						int attributeNumber = first->getElement(sectionNumber - 1).attr->findNode(first->getElement(sectionNumber - 1).attr, tab);
						cout << sectionNumber << ",A," << tab << " == " << first->getElement(sectionNumber - 1).attr->getElement(first->getElement(sectionNumber - 1).attr, attributeNumber).value << endl;
					}
					else if (nextletter == '?') {
						if (first->AttrInSection(first, atoi(tab)) == -1) {
							i = 0;
							return;
						}
						cout << atoi(tab) << ",A,? == " << first->AttrInSection(first, atoi(tab)) << endl;
					}
				}
			}
			else {
				char letter = getchar();
				char nextletter = getchar();
				if (letter == ',' && nextletter == '?') {
					cout << tab << ",A,? == " << countAllAttr(first, tab) << endl;
				}
			}
		}
		i = 0;
	}
}

void saveAttributeName(Mode& state, char  tab[CSS_NAME], int& i, attribute& at) {
	if (state == COMMANDS || state == START || state == SELECTORS || state == SECTIONEND) return;
	state = ATTSPACE;
	tab[i - 1] = '\0';
	copy(tab, at.name);
	i = 0;
}

void saveAttributeValue(Mode& state, char  tab[CSS_NAME], int& i, attribute& at, DoubleLinkedList<attribute>*& nodeAttr, sections& section, bool& rep, DoubleLinkedList<attribute>*& firstAttr){
	if (state == COMMANDS)  return;
	state = ATTRIBUTESNAME;
	tab[i - 1] = '\0';
	copy(tab, at.value);
	addAttributes(nodeAttr, section, at, rep, firstAttr);
	i = 0;
	rep = true;
}

void endSection(Mode& state, char  tab[CSS_NAME], int& i, attribute& at, DoubleLinkedList<attribute>*& nodeAttr, sections& section, bool& rep,
	DoubleLinkedList<attribute>*& firstAttr, DoubleLinkedList<sections>* first, DoubleLinkedList<sections>*& last){
	if (state == COMMANDS)  return; 
	if (state == ATTRIBUTESVALUE) {
		tab[i - 1] = '\0';
		copy(tab, at.value);
		addAttributes(nodeAttr, section, at, rep, firstAttr);
		i = 0;
		rep = false;
	}
	first->insertSection(section, first, &last);
	state = SECTIONEND;
	i = 0;
}

void readAttributes(bool& rep, Mode& state, char  tab[CSS_NAME], int& i, sections& section, DoubleLinkedList<char*>*& firstSel){
	rep = false;
	if (state == COMMANDS)  return;
	tab[i - 1] = '\0';
	addSelectors(state, section, firstSel, removeWhiteSpaces(tab, i - 1));
	state = SELECTORSEND;
	i = 0;
}

void saveSelector(Mode& state, char  tab[110], int& i, sections& section, DoubleLinkedList<char*>*& firstSel){
	if (state == ATTRIBUTESVALUE || state == COMMANDS)  return;
	tab[i - 1] = '\0';
	addSelectors(state, section, firstSel, removeWhiteSpaces(tab, i - 1));
	state = SELSPACE;
	i = 0;
}

void readCommands(char  tab[CSS_NAME], int& i, Mode& state, DoubleLinkedList<sections>* first){
	tab[i - 1] = '\0';
	if (state == COMMANDS) {
		if (i < 2 || tab[i - 2] != ',') {
			cout << "? == " << first->getSecNumber(first) << endl;
		}
	}
	else {
		char second = getchar();
		char third = getchar();
		char fourth = getchar();
		if (second == '?' && third == '?' && fourth == '?') {
			state = COMMANDS;
		}
	}
	i = 0;
}

int main() {
	bool rep = false;
	Mode state = START;
	DoubleLinkedList<sections>* first = new DoubleLinkedList<sections>(SIZE);
	DoubleLinkedList<sections>* last = first;

	sections section;
	section.sel = new DoubleLinkedList<char*>(CSS_NAME);
	section.attr = new DoubleLinkedList<attribute>(1);

	attribute at;
	char tab[CSS_NAME];
	int i = 0;

	DoubleLinkedList<char*>* nodeSel;
	DoubleLinkedList<attribute>* nodeAttr;

	while (cin.peek() != EOF) {
		char input = getchar();
		DoubleLinkedList<char*>* firstSel = NULL;
		if(section.sel!=NULL && state!=SECTIONEND)
			firstSel = section.sel->getLast(section.sel);
		DoubleLinkedList<attribute>* firstAttr;
		tab[i] = input;
		if (tab[i] > ' ' || state == ATTRIBUTESVALUE || ((state == START || state == NEWBLOCK || state == SECTIONEND || state == SELECTORS) && tab[i] != '\n' && tab[i] != '\t')) i++;
		else continue;
		if (state == ATTSPACE) state = ATTRIBUTESVALUE;
		if (state == SELSPACE) state = SELECTORS;
		switch (input) {
		case ',':
			saveSelector(state, tab, i, section, firstSel);
			break;
		case '{':
			readAttributes(rep, state, tab, i, section, firstSel);
			break;
		case '}':
			endSection(state, tab, i, at, nodeAttr, section, rep, firstAttr, first, last);
			break;
		case ';':
			saveAttributeValue(state, tab, i, at, nodeAttr, section, rep, firstAttr);
			break;
		case ':':
			saveAttributeName(state, tab, i, at);
			break;
		case '?':
			readCommands(tab, i, state, first);
			break;
		case '*':
			readCSS(state, tab, i);
			break;
		case 'E':
			findLastOccurence(state, i, tab, first, last);
			break;
		case 'S':
			manageSelectors(state, tab, i, first);
			break;
		case 'A':
			manageAttributes(state, tab, i, first);
			break;
		case 'D':
			deleteElements(state, tab, i, first);
			break;
		}
	}
	first->deleteList(first);
}
