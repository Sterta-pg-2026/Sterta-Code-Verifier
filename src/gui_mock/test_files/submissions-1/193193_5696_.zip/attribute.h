#pragma once
#include "mystring.h"

enum AttributePart {
	NAME,
	VALUE
};

class Attribute
{
private:
	MyString* name;
	MyString* value;

public:
	Attribute();

	Attribute(Attribute& other);

	~Attribute();

	Attribute& operator=(Attribute& other);
	
	void AddCharacter(char character, AttributePart part);

	void Trim();

	void Reset();


	bool IsEmpty() const;

	bool DoesMatchName(Attribute* other) const;
	bool DoesMatchName(MyString& otherName) const;


	MyString& GetValue();
};
