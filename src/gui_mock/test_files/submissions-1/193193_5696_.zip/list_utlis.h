#pragma once

#include "list.h"
#include "mystring.h"
#include "attribute.h"
#include "section.h"


MyString* FindSelectorByName(MyString& selectorName, List<MyString>::ListNode* node);

MyString* FindSelectorByName(MyString& selectorName, List<MyString>* list);

MyString* FindSelectorByName(MyString& selectorName, List<Section>::ListNode* node);


Attribute* FindAttributeByName(MyString& attributeName, List<Attribute>::ListNode* node);

Attribute* FindAttributeByName(MyString& attributeName, List<Attribute>* list);

Attribute* FindAttributeByName(MyString& attributeName, List<Section>::ListNode* node);



bool RemoveAttributeByName(MyString& attributeName, List<Attribute>* list);
