﻿#pragma once

#include "list.h"
#include "mystring.h"
#include "reader.h"

int main()
{
	Reader* reader = new Reader();

	reader->ReadAll();

	delete reader;
}