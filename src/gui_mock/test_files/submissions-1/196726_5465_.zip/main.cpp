//
//  main.cpp
//  Project1_AlDS
//
//  Created by YiXun Wang on 29/03/2023.
//

#include <iostream>
#include <ostream>
#include <cstring>
using namespace std;
#define MAX_LEN 1000
#define T 8

class my_string
{
private:
    char * buf = nullptr;
    size_t size = 0;
    
public:
   /* int my_strlen(const char* str) {
        int len = 0;
        while (str[len] != '\0') {
            len++;
        }
        return len;
    }
    */
    void my_strcpy(char* dest, const char* src) {
        int i = 0;
        while (src[i] != '\0') {
            dest[i] = src[i];
            i++;
        }
        dest[i] = '\0';
    }
    int my_strncpy_s(char* dest, size_t dest_size, const char* src, size_t count)
    {
        if (dest == NULL || src == NULL) {
            return -1;
        }
        size_t i;
        for (i = 0; i < count && i < dest_size - 1; i++) {
            dest[i] = src[i];
        }
        dest[i] = '\0';
        if (i == count && src[count] != '\0') {
            return -2;
        }
        return 0;
    }
    
    my_string() : buf(nullptr), size(0) // default constructor
    {
        
    }
 /*
    my_string(const char * const buffer) // constructor
    {
        size = strlen(buffer);
        buf = new char[size + 1]; // + 1 for the keeping the null character
        my_strncpy_s(buf, size + 1, buffer, size); // copy from the incoming buffer to character buffer of the new object
    }
  */
    my_string(const char* const buffer) : buf(nullptr), size(0)
    {
        if (buffer != nullptr)
        {
            size = strlen(buffer);
            buf = new char[size + 1];
            my_strncpy_s(buf, size + 1, buffer, size);
        }
    }
    my_string(const my_string & obj) // copy constructor
    {
        size = obj.size;
        buf = new char[size + 1]; // + 1 for the keeping the null character
        my_strncpy_s(buf, size + 1, obj.buf, size); // copy from the incoming buffer to character buffer of the new object
    }
    
    my_string& operator=(const my_string & obj) // copy assignment
    {
        __cleanup__(); // cleanup any existing data
        
        // Copy data from the newly assigned my_string object
        size = obj.size;
        buf = new char[size + 1]; // + 1 for the keeping the null character
        my_strncpy_s(buf, size + 1, obj.buf, size); // copy from the incoming buffer to character buffer of the new object
        return *this;
    }
    
    
    my_string(my_string && dyingObj) // move constructor
    // && is a reference operator defined in the C++11 standard
    // which means "dyingObj" is an r-value reference.
    // Compiler calls this constructor when the object passed in the argument
    // is about to die due to scope end or such
    {
        __cleanup__(); // cleanup any existing data
        
        // Copy data from the incoming object
        size = dyingObj.size;
        
        // Transfer ownership of underlying char buffer from incoming object to this object
        buf = dyingObj.buf;
        dyingObj.buf = nullptr;
    }
    
    my_string& operator=(my_string && dyingObj) // move assignment
    {
        __cleanup__(); // cleanup any existing data
        
        // Copy data from the incoming object
        size = dyingObj.size;
        
        // Transfer ownership of underlying char buffer from incoming object to this object
        buf = dyingObj.buf;
        dyingObj.buf = nullptr;
        
        return *this;
    }
    
    my_string operator+(const my_string & obj) // concatenation
    {
        my_string s; // create a new string named 's'
        s.size = this->size + obj.size;
        s.buf = new char[s.size + 1]; // allocate memory to keep the concatenated string
        my_strncpy_s(s.buf, this->size + 1, this->buf, this->size); // copy the 1st string
        my_strncpy_s(s.buf + this->size, obj.size + 1, obj.buf, obj.size);
        
        return s;
    }
    /*
     char& operator[](unsigned int index)
     {
     if (index >= size) {
     // throw an exception or handle the error in some other way
     }
     return buf[index];
     }
     
     const char& operator[](unsigned int index) const
     {
     if (index >= size) {
     // throw an exception or handle the error in some other way
     }
     return buf[index];
     }
     */
    my_string convert(char* arr) {
        size_t len = strlen(arr);
        delete[] buf;
        buf = new char[len + 1];
        my_strcpy(buf, arr);
        size = len;
        return *this;
    }

    // Equality operator
    bool operator==(const my_string& other) const {
        if (size != other.size) {
            return false;
        }
        for (size_t i = 0; i < size; ++i) {
            if (buf[i] != other.buf[i]) {
                return false;
            }
        }
        return true;
    }
    
    // Inequality operator
    bool operator!=(const my_string& other) const {
        return !(*this == other);
    }
    
    
    size_t length()
    {
        return size;
    }
    
    const char * c_str() const
    {
        return buf;
    }
    
    ~my_string() // destructor
    {
        __cleanup__();
    }
    
private:
    void __cleanup__()
    {
        if (buf != nullptr)
        {
            delete[] buf;
        }
        size = 0;
    }
};

std::ostream& operator<<(std::ostream& cout, const my_string & obj)
{
    cout << obj.c_str();
    return cout;
}

struct Attribute {
    my_string Attri_name;
    my_string value;
    Attribute* prev;
    Attribute* next;
};

class Selector {
public:
    
    my_string name;
    Selector* next;
    Attribute* Head;
    Attribute* Tail;
    
    
    Selector() {
        this->name = nullptr;
        next = nullptr;
        Head = nullptr;
        Tail = nullptr;
    }
    
    Selector(my_string name) {
        this->name = name;
        Head = nullptr;
        Tail = nullptr;
    }
    
    
    void add_attribute(my_string Attri_name, my_string value) {
        Attribute* attribute = new Attribute;
        attribute->Attri_name = Attri_name;
        attribute->value = value;
        attribute->prev = Tail;
        attribute->next = NULL;
        if (Tail != NULL) {
            Tail->next = attribute;
        } else {
            Head = attribute;
        }
        Tail = attribute;
    }
    
    
    
    int count_attributes() {
        int count = 0;
        Attribute* current_attribute = Head;
        while (current_attribute != NULL) {
            count++;
            current_attribute = current_attribute->next;
        }
        return count;
    }
    
    void print_attributes() {
        cout << name << " has " << count_attributes() << " attributes:" << endl;
        Attribute* current_attribute = Head;
        while (current_attribute != NULL) {
            cout << "  " << current_attribute->Attri_name << ": " << current_attribute->value << endl;
            current_attribute = current_attribute->next;
        }
    }
};

void getInput(){
    
    
}

int main() {
    
    char input[MAX_LEN];
    char temp[MAX_LEN];
    
    my_string ConvertStr;
    Selector section[T];
    
    
    cin.getline(input,MAX_LEN,'}');
    int i = 0;
    int j = 0;
    int temp_lenth = 0;
    my_string NameOfSec;
    my_string Attribute;
    my_string Value;
    while (input[i]!= '\0' && input [i] != '}')
    {
        temp[temp_lenth++] = input[i++];
        switch (input[i])
        {
            case '{':{
                temp[temp_lenth] = '\0';
                my_string NameOfSec = ConvertStr.convert(temp);// convert a char array to a string, and pass the string to selector, cause I dont have this kind of constructor in selector.
                section[j] = Selector(NameOfSec);
                temp_lenth = 0;
                break;}
            case ':':{
                temp[temp_lenth] ='\0';
                Attribute = ConvertStr.convert(temp);
                temp_lenth = 0;
                break;}
            case ';':{
                temp[temp_lenth] ='\0';
                Value = ConvertStr.convert(temp);
                temp_lenth = 0;
                section[j].add_attribute(Attribute,Value);
                break;}
                
        }
    }
    
    cout << section->count_attributes() << endl;
    
    getline(input,MAX_LEN,)
    
    
    /*
     cin.getline(input,MAX_LEN,'\n');
     int i = 0;
     int temp_lenth = 0;
     while(input[i]!= '\0' && input [i] != '\n')
     {
     temp[temp_lenth++] = input[i++];
     }
     temp[temp_lenth] = '\0';
     my_string NameOfBlock = tempStr.convert(temp);// convert a char array to a string, and pass the string to selector, cause I dont have this kind of constructor in selector.
     Selector section = Selector(NameOfBlock);
     
     temp_lenth = 0;
     
     cin.getline(input,MAX_LEN,'}');
     while(input[i] != '\0')
     {
     if (input[i] == '}'){
     
     
     if(input[i] == ':'){
     temp[temp_lenth] = '\0';
     tempStr.convert(temp);
     section.add_attribute(<#my_string Attri_name#>, <#my_string value#>)
     temp_lenth = 0;
     
     }
     }
     else{
     temp[temp_lenth++] = input[i++];
     
     }
     }
     */
    
    
    
    
    
    
    
    
    /*    char arr[100];
     my_string tempStr;
     while(!(arr[0]= '?')){
     cin.getline(arr,100,'\n');
     my_string NameOfBlock = tempStr.convert(arr);
     Selector section = Selector(NameOfBlock);
     
     //delete array?
     cin.getline(arr,100,'}');
     for(int i = 0; i <sizeof(arr)/sizeof(arr[0]);i++){
     char* tempArr = new char[sizeof(arr)/sizeof(arr[0])];
     tempArr[i] = arr[i];
     
     if (arr[i] == ':'){
     my_string Attri_name = tempStr.convert(tempArr);
     }
     section.add_attribute(Attri_name, <#my_string value#>)
     delete[] tempArr;
     }
     }
     */
    
    
    
    
    
    
    
    /*
     my_string a("FirstName");
     my_string b("LastName");
     my_string c = a + b;
     cout << c << endl;
     
     Selector* selector = new Selector("h1");
     selector->add_attribute("color", "red");
     selector->add_attribute("font-size", "24px");
     selector->add_attribute("text-align", "center");
     selector->print_attributes();
     */
    return 0;
}

