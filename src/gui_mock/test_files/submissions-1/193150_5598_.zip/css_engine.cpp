#include <iostream>
#include <string.h>
#include "sections.h"
#include "blocks.h"
#include "attributes.h"
#include "selectors.h"
#include "customstring.h"
#include "functions.h"
using namespace std;
int main()
{
    BlockList mainList;
    CustomString command("");
    CustomString buffer("");
    CustomString att("");
    CustomString sel("");
    bool attribute = 0;
    bool commands = 0;
    bool load = 1;


    //FILE* fname{};
    //const char* filename = "test_input.txt";
    int ch;

    //fname = fopen(filename, "r");
    while ((ch = getchar()) != EOF) {
    if (ch < ' ' && ch != 10)
            continue;
         char znak = (char)ch;
        if (ch < ' ' && ch != 10)
            continue;
        
        switch (znak) {
            case '{':
                attribute = 1;
                continue;
                break;

            case '}':
                AttributeList AttributeL;
                SelectorList SelectorL;
                

                attribute = 0;
                DissectAndAppendSelectors(&SelectorL, &sel);
                DissectAndAppendAttributes(&AttributeL, &att, ";");
                Section Section(AttributeL, SelectorL);

                mainList.AppendNode(Section);

                att.EmptyString();
                sel.EmptyString();
                continue;
                break;
            }
        if (ch != '\t') {
            if (strcmp(sel.str, "????") == 0) {
                commands = 1;
                sel.EmptyString();
            }
            else if (strcmp(command.str, "****") == 0) {
                commands = 0;
                command.EmptyString();
            }

            if (commands == 0 && ch != '\n' ) {
                if (attribute) {
                    att.PushChar(znak);
                }
                else if(true) {
                    sel.PushChar(znak);
                }
            }
            else if(commands == 1) {
                if (ch == '\n' || ch == EOF || ch == '\b') {
                    ParseCommand(&command, &mainList);
                    command.EmptyString();
                }
                else {
                    command.PushChar(znak);
                }
            }
        }
        

    }
    if(ch == EOF)
   	ParseCommand(&command, &mainList);
}

