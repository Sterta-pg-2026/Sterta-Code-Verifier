#pragma once
#include "attributes.h"
#include "selectors.h"
#include "sections.h"

class Section;

struct BlockNode {
	char reached_max;
	char deleted;
	int holding;
	BlockNode* next;
	BlockNode* prev;
	Section *sectionList;
	~BlockNode();
	BlockNode();
	void AppendSection(Section section);
};


class BlockList {
public:
	BlockList();
	void AppendNode(Section section);
	void PrintList();
	BlockNode* head;
	BlockNode* tail;
	int CountSections();
	int CountSelectorsInSection(int section_num);
	int CountAttributesInSection(int section_num);
	char* SelectorNameInSection(int section_num, int selector_num);
	char* GetAttributeValueInSection(int section_num, const char* attribute_name);
	int CountAttributesByName(const char* name);
	int CountSelectorsByName(const char* name);
	char* GetLastAttributeValue(const char* attribute_name, const char* selector_name);
	Section *FindSection(int section_num);
	bool DeleteSection(int section_num);
	bool DeleteAttribute(int section_num, const char* name);
	~BlockList();
};