#pragma once
#include "attributes.h"
#include "selectors.h"
class Section {
public:
	char added;
	char deleted;
	AttributeList AttList;
	SelectorList SelList;
	Section(AttributeList AttList, SelectorList SelList);
	Section();
	void PrintSection();
};