#pragma once
#include <iostream>
#include "string.h"

#define ONE 1
using namespace std;


//one element of a list
struct Node {
    String name;
    String value;
    Node* next;
};

class SList
{
    //head pointer
    Node* head;
    size_t size;

public:

    //initializing head pointer with deafult constructor
    SList() :head(nullptr) {
        size = NULL;
    }

    //printing n-th element name
    void prinNth(int n) const {
        Node* tmp = head;
        int i = ONE;
        while (i < n) {
            tmp = tmp->next;
            i++;
        }
        cout << (tmp->name);
    }

    Node* getNode() {
        return head;
    }

    //counting current length of a list
    size_t getSize() const {
        return size;
    }

    //adding new element to list
    void addLast(String name, String* value) {
        //allocating memory
        Node* newNode = (Node*)malloc(sizeof(Node));
        
        newNode->name.setName(name);
        newNode->value.setName(*value);
        newNode->next = NULL;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            //for attributes we need to look whether there already is attribute with the same name
            Node* tmp = head;
            while (tmp != nullptr) {
                //len > NULL means we are dealing with list of attributes not selectors!
                if (value->getLength() > NULL && name == tmp->name) {
                    //we are not adding element -> only exchange value of already existing attribute
                    tmp->value = *value;
                    void* x = newNode;
                    free(x);
                    return;
                }
                if (tmp->next == nullptr) {
                    tmp->next = newNode;
                    break;
                }
                tmp = tmp->next;

            }
            
        }
        size++;

    }

    //removing one element after given node
    void removeAfter(Node* l) {
        if (l->next != nullptr) {
            void* x = l->next;
            l->next = l->next->next;
            free(x);
        }
        size--;
    }

    //returning node at given position
    Node* getAtPos(size_t n) {
        Node* tmp = head;

        if (n <= size) {
            n--;
            for (size_t i = NULL; i < n; i++) {
                tmp = tmp->next;
            }
            return tmp;
        }

        return NULL;
        
    }

    //removing first element
    void removeFirst() {
        head = head->next;
        size--;
    }

};