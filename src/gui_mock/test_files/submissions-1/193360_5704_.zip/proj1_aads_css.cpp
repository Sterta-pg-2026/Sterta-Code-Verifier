#include <iostream>
#include "slist.h"
#include "string.h"
#include "dblist.h"

#define DEAFULT_SIZE 10
#define SIZE_MULTIPLICATION 2
#define CHANGE_CHAR_LEN 4
#define MAX_COMMA 2
#define ONE 1
#define TEN 10
#define COMMA ','
#define ENTER '\n'
#define END_OF_WORD '\0'
#define SPACE ' '
#define SEMICOLON ';'
#define COLON ':'
#define TAB '\t'
#define COMMANDS_STR "????"
#define CSS_STR "****"
#define ALL_SELECTORS_ATT "*"
#define BRACES_OP '{'
#define BRACES_CL '}'

//state in reading css
struct currentAction {
    bool readingSel = true;
    bool readingAtt = false;
    bool readingAttVal = false;
};

//info about current line, char
struct lineInfo {
    char ch, last;
    char* line;
    int len;
    int size;
    bool wordEnded = true;
};

//basic strings to "keep" some values
struct listValues {
    String a;
    String b;
};

//state of program
enum state {READINGCSS = 1, COMMANDS = 2, END_PROGRAM = 3};

using namespace std;

bool isSpecialChar(char c);
void addSizeToBuffer(lineInfo* currLine);
bool toInt(String txt, int* n);
bool compareChars(char* a, const char* b);
bool charToOmmit(lineInfo* currLine);
void safeGetChar(lineInfo* currLine, state* currState);
void deleteUnnecessaryCharacters(lineInfo* currLine);

void readCss(DBList* sections, SList* sel, SList* att, listValues* values, lineInfo* currLine, state* currState);
void readCommands(DBList* sections, listValues* values, lineInfo* currLine, state* currState);
bool lookForStateChange(lineInfo* currLine, state* currState);

//functions responsible for reading the user's input
void performAction(DBList* sections, listValues* values, char action);
void handleSpecialChar(SList* sel, SList* att, currentAction* action, lineInfo* currLine, listValues* values);
void handleSectionBraces(DBList* sections, SList* sel, SList* att, currentAction* action, lineInfo* currLine,
    listValues* values);

//functions performing commands
bool lookForAttValue(Section* s, String* whatAttribute, String* value);
int countOccurrences(DBList* list, String* whatName, char action);
bool getAttValueForGivenSelector(DBList* list, String* whatName, String* whatAttribute, String* outputValue);
bool lookForAttAndDelete(DBList* sections, Section* s, String* whatAttribute, int pos);

int main()
{
    //preparing start values, lists...
    DBList sections;
    SList sel, att;
    lineInfo currentLine;
    listValues values;

    //defining start state
    state currentState = READINGCSS;
    
    //line for reading chars
    currentLine.line = new char[DEAFULT_SIZE];
    currentLine.len = NULL;
    currentLine.size = DEAFULT_SIZE;
    
    //we are reading till the end of file
    while (currentState != END_PROGRAM) {
        safeGetChar(&currentLine, &currentState);
        switch (currentState) {

        case READINGCSS:
            readCss(&sections, &sel, &att, &values, &currentLine, &currentState);
            break;
        case COMMANDS:
            readCommands(&sections, &values, &currentLine, &currentState);
        }
        
    }

    delete[] currentLine.line;

}

//reading css, assinging selectors and attributes as one section to the list of blocks
void readCss(DBList* sections, SList* sel, SList* att, listValues* values, lineInfo* currLine, state* currState) {

    currentAction currAction;
    currLine->last = NULL;

    while (*currState == READINGCSS) {

        //not "reacting" on chars till we got some that may represent beginning of next word
        while (currLine->wordEnded) {
            if (!charToOmmit(currLine)) {
                currLine->wordEnded = false;
                break;
            }
            safeGetChar(currLine, currState);
        }

        //looking whether char is COMMA or SEMICOLON or COLON - > that mean we ended the word for sure
        if (isSpecialChar(currLine->ch)) {
            
            handleSpecialChar(sel, att, &currAction, currLine, values);
        }
        else if (currLine->ch == BRACES_OP || currLine->ch == BRACES_CL) {
            
            handleSectionBraces(sections, sel, att, &currAction, currLine, values);
        }
        else {
            currLine->line[(currLine->len)++] = currLine->ch;
        }

        //looking if we dont have to make our array of chars bigger
        while (currLine->len >= currLine->size) {
            addSizeToBuffer(currLine);
        }
        
        //looking if we are not changing the "state of reading"
        if(lookForStateChange(currLine, currState)) break;

        //assinging last and getting new char
        currLine->last = currLine->ch;
        safeGetChar(currLine, currState);
        
    }

}

//handle char such as '{' and '}' for opening and closing section
void handleSectionBraces(DBList* sections, SList* sel, SList* att, currentAction* action,
    lineInfo* currLine, listValues* values) {

    currLine->ch = currLine->line[currLine->len - ONE];
    deleteUnnecessaryCharacters(currLine);

    //ending current line
    currLine->line[currLine->len] = END_OF_WORD;
    currLine->len = NULL;

    //ending reading selectors or attributes, or attributes values
    if (action->readingSel) {
        //there is no value in selectors
        values->b = "";
        sel->addLast(currLine->line, &values->b);
        action->readingSel = false;
        action->readingAtt = true;
        currLine->wordEnded = true;

    }
    else {
        //adding last attribute value
        if (action->readingAttVal) {
            //assign value from line to string
            values->b = currLine->line;
            action->readingAttVal = false;
            att->addLast(values->a, &values->b);
        }

        //adding both selectors and attributes as one section
        sections->addLast(sel, att);
        action->readingSel = true;
        action->readingAtt = false;
        currLine->wordEnded = true;

        //creating new lists for new values
        *sel = SList();
        *att = SList();
    }

}

//handling event when a char becomes a sign that means we ended a word for sure, assigning word to proper list
void handleSpecialChar(SList* sel, SList* att, currentAction* action, lineInfo* currLine, listValues* values) {

    //looking whether we need to still read value
    if (action->readingAttVal && currLine->ch == COMMA) {
        currLine->line[(currLine->len)++] = currLine->ch;
    }
    else if (action->readingSel && currLine->ch != COMMA) {
        currLine->line[(currLine->len)++] = currLine->ch;
    }
    else {

        //deleting not important last chars
        deleteUnnecessaryCharacters(currLine);

        currLine->line[currLine->len] = END_OF_WORD;
        currLine->len = NULL;
        currLine->wordEnded = true;

        //looking what kind of word we ended reading
        if (action->readingSel) {

            values->b = "";
            sel->addLast(currLine->line, &values->b);
        }
        //reading attribute
        else if (action->readingAtt) {

            //setting value from a line to string
            values->a = currLine->line;
            action->readingAtt = false;
            action->readingAttVal = true;
        }
        //reading attribute value
        else {

            values->b = currLine->line;
            att->addLast(values->a, &values->b);
            action->readingAtt = true;
            action->readingAttVal = false;

        }
    }
}

//comparing current line with chars that needs to occur to change state of reading
bool lookForStateChange(lineInfo* currLine, state* currState) {
    
    state newState;
    const char* strToCheck;
    if (*currState == READINGCSS) {
        newState = COMMANDS;
        strToCheck = COMMANDS_STR;
    }
    else {
        newState = READINGCSS;
        strToCheck = CSS_STR;
    }

    if (currLine->len != NULL) {
        if (compareChars(currLine->line, strToCheck)) {
            *currState = newState;
            currLine->len = NULL;
            currLine->line[NULL] = '\0';
            currLine->wordEnded = true;
            return true;
        }
    }

    return false;
}

//function used to compare given char with char that changes the state od reading
bool compareChars(char* a, const char* b) {
    char ch1 = *a, ch2 = *b;
    int j = CHANGE_CHAR_LEN, i = NULL;

    //if the j-th chars are the same true, otherwise false
    for (i; i < j; i++) {
        ch1 = a[i];
        ch2 = b[i];
        
        if (ch1 != ch2) {
            return false;
        }
        
    }
    return true;

}

//identify character meaning end of a word
bool isSpecialChar(char c) {
    if (c == COMMA || c == COLON || c == SEMICOLON) return true;
    return false;
}

//deleting non necessary characters at the end of word
void deleteUnnecessaryCharacters(lineInfo* currLine) {
    while (charToOmmit(currLine)) {
        currLine->len--;
        currLine->ch = currLine->line[currLine->len - ONE];
    }
}

//function provides not reading chars after the EOF
void safeGetChar(lineInfo* currLine, state* currState) {
    if (*currState != END_PROGRAM) {
        char ch2 = getchar();
        currLine->ch = ch2;
        if (ch2 == EOF) {
            *currState = END_PROGRAM;
        }
    }
}

//function multiplies buffer size
void addSizeToBuffer(lineInfo* currLine) {
    int s = currLine->size * SIZE_MULTIPLICATION;
    char* newBuffer = new char[s];

    //push the content of old buffer to new one
    for (int i = NULL; i < currLine->size; i++) {
        newBuffer[i] = currLine->line[i];
    }

    currLine->line = newBuffer;
    currLine->size = s;

}

//look whether given char is a char that we can ommitt
bool charToOmmit(lineInfo* currLine) {
    if (currLine->ch <= SPACE) return true;
    return false;
}

//reading sequance of commands
void readCommands(DBList* sections, listValues* values, lineInfo* currLine, state* currState) {

    int commaCnt = NULL;
    char action = NULL;
    currLine->last = NULL;

    while (*currState == COMMANDS) {
        safeGetChar(currLine, currState);

        //basic command '?' - showing number of sections
        if (currLine->ch == '?' && commaCnt == NULL) {
            cout << "? == " << sections->getListOcc() << endl;
        }
        else {

            //building the command line
            if (currLine->ch == ENTER) {
                //look if there is proper number of commas
                if (commaCnt > NULL && commaCnt <= MAX_COMMA) {

                    currLine->line[currLine->len] = END_OF_WORD;
                    values->b = currLine->line;
                    currLine->len = NULL;
                    commaCnt = NULL;
                    performAction(sections, values, action);

                }
            }
            else {

                //adding char to line
                currLine->line[(currLine->len)++] = currLine->ch;
                //checking number of commas
                if (currLine->ch == COMMA) {
                    commaCnt++;
                    if (commaCnt == ONE) {
                        currLine->line[currLine->len - ONE] = END_OF_WORD;
                        values->a = currLine->line;
                    }
                    else if (commaCnt == MAX_COMMA) {
                        action = currLine->last;
                    }
                    else {
                        //ommitting chars till the next line
                        while (currLine->ch != ENTER) {
                            safeGetChar(currLine, currState);
                        }
                        commaCnt = NULL;

                    }
                    currLine->len = NULL;

                }

            }


        }

        currLine->last = currLine->ch;
        while (currLine->len > currLine->size) {
            addSizeToBuffer(currLine);
        }

        if (lookForStateChange(currLine, currState)) break;

    }
}

//performing given action
void performAction(DBList* sections, listValues* values, char action) {
    int pos1 = NULL, pos2 = NULL;
    int resultNumber = NULL;
    String value = "";

    //looking whether the string "a" is a number
    if (toInt(values->a, &pos1)) {

        //position1 refers to section on a list
        if (pos1 <= sections->getListOcc()) {

            Section* s = sections->getSecAtPos(pos1);

            //both parameters are numbers
            if (toInt(values->b, &pos2)) {

                //two numbers only for S - command
                //printing n-th selector
                if (pos2 <= s->sel.getSize() && action == 'S') {
                    Node* n = s->sel.getAtPos(pos2);
                    //if the selector exists
                    if (n->name.getLength() > NULL) {
                        cout << values->a << "," << action << "," << values->b << " == ";
                        s->sel.prinNth(pos2);
                        cout << endl;
                    }
                    
                }

            }
            //second parameter is not a number
            else {

                //number of selectors/attributes for section nr pos1
                if (values->b == "?") {
                    
                    SList elementList;
                    if (action == 'S') {
                        elementList = s->sel;
                        Node* n = s->sel.getNode();
                        //selectors list might be empty
                        if (n->name.getLength() == NULL) resultNumber = NULL;
                        else {
                            resultNumber = elementList.getSize();
                        }
                    }
                    else{
                        elementList = s->att;
                        resultNumber = elementList.getSize();
                        
                    }
                    cout << values->a << "," << action << "," << values->b << " == " << resultNumber << endl;

                }
                else if (values->b == "*") {
                    if (action == 'D') {
                        //deleting the section number a, meaning on pos1
                        sections->removeSection(pos1);
                        cout << values->a << "," << action << "," << values->b << " == deleted" << endl;
                    }
                }
                else {

                    //we passed name of attribute as the second parameter named - b
                    if (action == 'A') {
                        
                        //if there is an attribute of given name
                        if (lookForAttValue(s, &values->b, &value)) {
                            cout << values->a << "," << action << "," << values->b << " == " << value << endl;
                        }
                    }
                    //deleting b - attribute from section a -> on pos1
                    else if (action == 'D') {
                        
                        if(lookForAttAndDelete(sections, s, &values->b, pos1)){
                            cout << values->a << "," << action << "," << values->b << " == deleted" << endl;

                        }
                    }

                }
            }

        }


    }
    //first parameter is not a number
    else {
        
        if (action == 'E') {
            //a - selector, b - attribute, get last value of given attribute of given selector
            if (getAttValueForGivenSelector(sections, &values->a, &values->b, &value)) {
                cout << values->a << "," << action << "," << values->b << " == " << value << endl;
            }
        }
        //count occurences of selector or attribute
        if ((action == 'S' || action == 'A') && values->b == "?") {
            //spr czy w ogole taki jest atrybut czy sekcja
            cout << values->a << "," << action << "," << values->b << " == " << countOccurrences(sections, &values->a, action) << endl;
        }

    }
}

//if succesfully converted - true, otherwise false -> the txt is a text not a number
bool toInt(String txt, int* n) {

    *n = NULL;
    int size = txt.getLength();
    if (size == NULL) return false;
    int c = ONE;
    for (int i = size - ONE; i >= NULL; i--) {
        if (txt[i] >= '0' && txt[i] <= '9') {
            *n += (int(txt[i] - '0') * c);
            c *= TEN;
        }
        else {
            return false;
        }
    }
    return true;

}

//looking for given attribute and deleting "it" from list
bool lookForAttAndDelete(DBList* sections, Section* s, String* whatAttribute, int pos) {
    //head of a list of given selector
    Node* tmp = s->att.getNode();
    Node* last = nullptr;
    while (tmp != NULL) {

        //searchoing for given name
        if (tmp->name == *whatAttribute) {
            if (last == nullptr) {
                s->att.removeFirst();
            }
            else {
                s->att.removeAfter(last);
            }
            if (s->att.getSize() == NULL) {
                //that means we also need to delete whole section
                sections->removeSection(pos);
            }
            return true;
            
        }
        last = tmp;
        tmp = tmp->next;
    }

    return false;
}

//looking if there is such attribute, and if so passing the value to ptr value
bool lookForAttValue(Section* s, String* whatAttribute, String *value) {

    //head of a list, first element
    Node* tmp = s->att.getNode();
    int occ = NULL;
    while(tmp != NULL){
        //comparing with name we are looking for
        if (tmp->name == *whatAttribute) {
            *value = tmp->value;
            //count occurences
            occ++;
        }
        tmp = tmp->next;
    }

    if (occ > NULL) return true;
    return false;
}

//counting occurences of an attribute or selector in whole list
int countOccurrences(DBList* list, String* whatName, char action) {
    Block* tmp = list->getHead();
    int tSize = list->getT(), occ = NULL;
    SList elementsList;

    while (tmp != nullptr) {
        //get first section from block
        Section* s = tmp->Node;
        //look whether section is free or not
        int i = NULL;
        while (i < tSize) {

            if (!s[i].free) {
                if (action == 'S') {
                    elementsList = s[i].sel;
                }
                else {
                    elementsList = s[i].att;
                }

                //operating on a given list
                Node* tmp1 = elementsList.getNode();
                while (tmp1 != nullptr) {
                    if (tmp1->name == *whatName) {
                        occ++;
                        break;
                    }
                    tmp1 = tmp1->next;
                }
            }
            i++;
        }
        
        tmp = tmp->next;
    }

    return occ;

}

//getting the last value of given attribute assigned to given selector
//function returns true if such attribute & selector exist, otherwise false
bool getAttValueForGivenSelector(DBList* list, String* whatName, String* whatAttribute, String* outputValue) {
    
    //starting from last block
    Block* tmp = list->getLast();
    unsigned int t = list->getT();
    SList elementsListS, elementsListA;

    while (tmp != nullptr) {
        //first section
        Section* s = tmp->Node;
        //searching section
        for (int i = t - ONE; i >= NULL; i--) {

            if (!(s[i]).free) {
                //looking for last occurence of given selector
                elementsListS = s[i].sel;
                Node* tmp1 = elementsListS.getNode();

                while (tmp1 != nullptr) {
                    //if name is the same we are searching a list of attributes
                    if (tmp1->name == *whatName || tmp1->name == "") {
                        elementsListA = s[i].att;
                        Node* tmp2 = elementsListA.getNode();

                        while (tmp2 != nullptr) {
                            if (tmp2->name == *whatAttribute) {
                                *outputValue = tmp2->value;
                                return true;
                            }
                            tmp2 = tmp2->next;
                        }
                    }
                    tmp1 = tmp1->next;
                }
            }
        }

        tmp = tmp->prev;
    }

    return false;

}
