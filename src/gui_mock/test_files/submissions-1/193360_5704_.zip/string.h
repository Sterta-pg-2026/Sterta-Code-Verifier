#pragma once
#include <iostream>
#define ONE 1

using namespace std;

//preparing self-implemented string class
class String {

    //initializing array of chars
    char* str = nullptr;
    //size of a buffer
    size_t size = NULL;
    //actual length of a string
    size_t length = NULL;

    //function used to clean & delete string
    void cleanBuffer() {
        if (str != nullptr)
            delete[] str;
        str = nullptr;
    }
    friend std::ostream& operator<<(std::ostream& os, const String& s);
    friend std::istream& operator>>(std::istream& is, String& s);

public:

    //deafult constructor
    String(){
        str = new char[ONE];
        str[NULL] = '\0';
        size = ONE;
        length = NULL;
    }

    //constructor with char*
    String(const char* buffer)
    {   
        size_t s = strlen(buffer);
        
        length = s;
        size = s + ONE;
        str = new char[size];

        strcpy(str, buffer);
        str[length] = '\0';
        
    }

    //constructor with const String
    String(const String& buffer)
    {   
        size_t s = buffer.getLength();
        length = s;
        size = s + ONE;
        str = new char[size];

        strcpy(str, buffer.str);
        str[length] = '\0';
    }

    //copy assignment operator with const char* buffer
    String& operator=(const char* buffer) noexcept
    {   
        String tmp(buffer);
        //gettery??????
        //swap(tmp);
        swap(str, tmp.str);
        swap(size, tmp.size);
        swap(length, tmp.length);

        return *this;
    }

    //copy assignment operator with const String buffer
    String& operator=(const String& buffer) noexcept
    {   
        String tmp(buffer);
        //swap(tmp);
        swap(str, tmp.str);
        swap(size, tmp.size);
        swap(length, tmp.length);
        
        return *this;
    }

    //comparing str with const char* buffer
    bool operator==(const char* buffer) const
    {
        if (length != strlen(buffer)) {
            return false;
        }
       
        for (size_t i = NULL; i < length; i++) {
            if (str[i] != buffer[i]) {
                return false;
            }
        }

        return true;
    }

    //comparing str with const char* buffer
    bool operator!=(const char* buffer) const
    {
        return !(str == buffer);
    }

    //comparing object with const String buffer
    bool operator==(const String& buffer) const
    {
        if (length != buffer.getLength()) {
            return false;
        }

        for (size_t i = NULL; i < length; i++) {
            if (str[i] != buffer[i]) {
                return false;
            }
        }

        return true;
    }

    //comparing object with const String buffer
    bool operator!=(const String& buffer) const
    {
        return !(*this == buffer);
    }

    //getting index of a str array
    char& operator[](std::size_t index) {
        
        return str[index];
    }

    const char& operator[](std::size_t index) const {
        return str[index];
    }

    size_t getLength() const {
        return length;
    }

    const char* getName() const
    {
        return str;
    }

    size_t getSize() const
    {
        return size;
    }

    //setting name of a non existing object
    void setName(const String& s){
        length = s.getLength();
        size = length + ONE;
        str = new char[size];
        strcpy(str, s.str);
        str[length] = '\0';
    }


    //destructor of the class
    ~String() { 

        //deleting assigned memory
        cleanBuffer();
    }

};

//handling cout<< operator
std::ostream& operator<<(std::ostream& os, const String& s)
{
    os << s.str;
    return os;
}

//handling cin>> operator
std::istream& operator>>(std::istream& is, String& s)
{   
    is >> s.str;

    size_t len = strlen(s.str);
    s.size = len + ONE;
    s.length = len;
 
    //handling given string, using proper constructor
    if (is) s = String(s);
    else    s = String();

    return is;
}