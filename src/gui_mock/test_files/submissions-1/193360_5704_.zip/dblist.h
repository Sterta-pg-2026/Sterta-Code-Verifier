#pragma once
#include <iostream>
#include "string.h"
#include "slist.h"

#define DEAFULT_ARRAY_SIZE 8
using namespace std;

typedef struct list {
    //lists for attributes and selectors
    SList sel;
    SList att;
    bool free = true;
    //constructor, deafult value of bool is free
} Section;

typedef struct dblist {

    //pointer to array of sections
    Section* Node;

    //links to next 8-th element block
    struct dblist* next;
    struct dblist* prev;

    //start occupation of a block
    size_t occBlock = NULL;

} Block;



class DBList {

    //head of the block
    Block* head;

    //current occupation of whole list
    size_t occList;
    size_t T = DEAFULT_ARRAY_SIZE;

public:

    //deafult constructor
    DBList() {
        occList = NULL;
        head = nullptr;
    }

    //adding new section to list
    void addLast(SList* sel, SList* att) {

        Section* newElem = nullptr;

        Block* last = getLast();
        int cap;
        if (head == nullptr) {
            cap = NULL;
        }
        else {
            cap = (last->occBlock);
        }
        
        //that means we need to add new block with 8-th elemnt array
        if(cap % T == NULL){
            
            Block* newNode = (Block*)malloc(sizeof(Block));
            //allocate new array of size T
            newElem = new Section[T];
            newNode->Node = newElem;
            
            //assigning lists to newElement
            newElem->free = false;
            newElem->sel = *sel;
            newElem->att = *att;
            newNode->next = NULL;

            newNode->occBlock = 1;
            //newNode->occPtr = &newNode->occB;

            if (head == nullptr) {
                head = newNode;
                head->prev = NULL;
            }
            else {
                //allocate node in the and of a list
                newNode->prev = last;
                last->next = newNode;
            }

        }
        else {
            
            newElem = last->Node;

            //looking for the "free" space to allocate my new element
            while (!newElem->free) {
                newElem++;
            }
            //assign values
            newElem->free = false;
            newElem->att = *att;
            newElem->sel = *sel;

            (last->occBlock)++;
        }
        occList++;

    }

    //removing section number - n
    void removeSection(size_t n) {

        //looking whether element is on a list, exist
        if (n <= occList && n != NULL) {

            Section* l = getSecAtPos(n);
            Block* b = getBlockBySecPos(n);
            l->free = true;
            
            (b->occBlock)--;
            occList--;

            //looking if current block is not empty, if so we need to also delete it
            if (b->occBlock == NULL) {

                if (b->next != nullptr) {

                    b->next->prev = b->prev;
                }

                if (b->prev == nullptr) {
                    head = b->next;
                }
                else {
                    b->prev->next = b->next;
                }
                b = nullptr;
                free(b);
                return;
            }

            int posInBlock = occList - b->occBlock + ONE;
            size_t posInArray = NULL;
            
            //checking what is the posiiton in array of given section
            while (posInBlock < n) {
                posInArray++;
                posInBlock++;
            }
            if (posInArray != b->occBlock) {

                size_t i = NULL;
                
                //switching the values, till the ones which are free (the one we are removing) are at the and of the block
                for (i = posInArray; i + ONE < T; i++) {
                   
                    b->Node[i] = b->Node[i + ONE];
                    if ((b->Node[i]).free) return;
                }
                b->Node[i].free = true;

            }
           
        }
       
    }

    //return section on given position n
    Section* getSecAtPos(int n) {
        Block* btmp = head;
        int occ = NULL;

        //while we are not above the final position
        while (occ < n) {
            occ += btmp->occBlock;
            if (occ >= n) break;
            btmp = btmp->next;
        }

        occ -= btmp->occBlock;
        Section* tmp = btmp->Node;
        for (size_t i = NULL; i < T; i++) {

            //counting only occupied fields
            if (!tmp->free) {
                occ++;
                //returning selector at given position
                if (occ == n) {
                    return tmp;
                }
            }
            tmp++;
        }

        return NULL;
    }

    //reutrning pointer to a block where for sure is the section at given pos
    Block* getBlockBySecPos(int n) {
        Block* tmp = head;
        int occ = NULL;

        while (occ < n) {
            occ += tmp->occBlock;
            if (occ >= n) break;
            tmp = tmp->next;
        }

        return tmp;

    }
    
    //returning the last element of doubly linked list
    Block* getLast() {
        if (head == nullptr) {
            return NULL;
        }
        Block* tmp = head;
        while (tmp->next != NULL) {
            tmp = tmp->next;
        }
        return tmp;
    }

    Block* getHead() {
        return head;
    }

    size_t getT() const {
        return T;
    }

    //function returns number of blocks, occList is a number of all elements
    int getListLen() const{
        int cnt = NULL;
        Block* tmp = head;
        while (tmp != NULL) {
            cnt++;
            tmp = tmp->next;
        }
        return cnt;
    }

    size_t getListOcc() const {
        return occList;
    }

};