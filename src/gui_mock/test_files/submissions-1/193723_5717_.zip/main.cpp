#include <iostream>
#include <stdio.h>
#include <ctype.h>
#define STOP '}'
#define MaxSizeOfOneElement 10000
using namespace std;
#define Active 1
#define NonActive 0
#define TRUE 1
#define FALSE 0
#define NotYet 0
#define Selector 1
#define Atribut 2
#define AtributValue 3
#define StrartOfComandMode 4
#define EndOfComandMode 5
#define PlaceHolderKomendy 6
#define JustCleanArr 7
#define COMMAND_ 8
#define COMMAND_iS 9
#define COMMAND_iA 10
#define COMMAND_iSj 11
#define COMMAND_iAn 12
#define COMMAND_nA 13
#define COMMAND_zS 14
#define COMMAND_ZEn 15
#define COMMAND_ID 16
#define COMMAND_IDn 17
#define NEWBLOCK 0
#define WEAREINSIDEOFBLOCK 1
#define YouJustEnteredAttribute 2
#define WeAreInsideCommandMode 3
#define SizeOfT 8
#define DelletedSegment 1280
#define NotYetUsedSegment 1
#define UsedSegment 0

struct Atributes
{
    char ArrForAtribut[MaxSizeOfOneElement];
    int HowMuchCharsTakenInAtribut = 0; // dodac ile juz zajetych
    char ArrForAtributValue[MaxSizeOfOneElement];
    int HowMuchCharsTakenInAtributValue = 0;
    Atributes *next = NULL;
    Atributes *prev = NULL;
};

struct Selectors
{
    char ArrForSelectors[MaxSizeOfOneElement];
    int HowMuchCharsTakenInSelector = 0;
    Selectors *next = NULL; // dodac ile juz zajetych
    Selectors *prev = NULL;
};

struct BlockOfTwoNodes
{
    Atributes *ListForAtrributes = NULL;
    Selectors *ListForSelectors = NULL;
    int IsItNotUsed = NotYetUsedSegment;

};

struct Node
{
    int counter;
    BlockOfTwoNodes ArrForAtrybutesAndSelectors[SizeOfT];
    Node *prev = NULL;
    Node *next = NULL;
};

int ChangeCharToInt(char *ArrForBuffror, int Ktory)
{
    int output = atoi(&ArrForBuffror[Ktory]);
    return output;
}

int numberOfSections(Node **NodeHead)
{
    int counter = 0;
    BlockOfTwoNodes *temp;
    Node *TempHead;
    TempHead = *NodeHead;

    for (int i = 0; i < SizeOfT; i++)
    {
        temp = &((TempHead)->ArrForAtrybutesAndSelectors[i]);
        if (((temp)->ListForAtrributes) != NULL)
        {
            if (((temp)->ListForSelectors) != NULL)
            {
                counter++;
            }
        }
    }

    TempHead = TempHead->next;

    if (TempHead != NULL)
    {
        while ((TempHead) != NULL)
        {
            for (int i = 0; i < SizeOfT; i++)
            {
                //*temp = (TempHead)->ArrForAtrybutesAndSelectors[i];
                temp = &((TempHead)->ArrForAtrybutesAndSelectors[i]);

                if (((temp)->ListForAtrributes) != NULL)
                {
                    if (((temp)->ListForSelectors) != NULL)
                    {
                        counter++;
                    }
                }
            }

            TempHead = TempHead->next;
        }
    }
    return counter;
}

void PrintNumberOfSelectorsForSection(char *ArrForBuffror, Node **NodeHead)
{
    int section;
    section = ChangeCharToInt(ArrForBuffror, 0);
    int counter = 0;

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;

    while ((TempHead->next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    CounterForNullJump++;
                }
            }
        }
        TempHead = (TempHead->next);
    }
    int CounterPlusSection;

    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

    Selectors *SelectorHead;

    SelectorHead = List->ListForSelectors;

    while ((SelectorHead) != NULL)
    {
        counter++;
        SelectorHead = SelectorHead->next;
    }
    section++;
    cout << section << ",S,? == " << counter << endl;
    return;
}

void PrintNumberOfAttributesForSection(char *ArrForBuffror, Node **NodeHead)
{
    int section;
    section = ChangeCharToInt(ArrForBuffror, 0);
    int counter = 0;

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;
    while ((TempHead->next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    CounterForNullJump++;
                }
            }
        }
        TempHead = (TempHead->next);
    }

    int CounterPlusSection;

    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {

        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

    Atributes *AtributesHead;

    AtributesHead = List->ListForAtrributes;

    while ((AtributesHead) != NULL)
    {
        counter++;
        AtributesHead = AtributesHead->next;
    }
    section++;
    cout << section << ",A,? == " << counter << endl;
    return;
}

int INTPrintNumberOfSelectorsForSection(char *ArrForBuffror, Node **NodeHead)
{
    int section;
    section = ChangeCharToInt(ArrForBuffror, 0);
    int counter = 0;

    int number = numberOfSections(NodeHead);

    if (section > number)
        return counter;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;

    while ((TempHead->next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    CounterForNullJump++;
                }
            }
        }
        TempHead = (TempHead->next);
    }
    int CounterPlusSection;
    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

    Selectors *SelectorHead;

    SelectorHead = List->ListForSelectors;

    while ((SelectorHead) != NULL)
    {
        counter++;
        SelectorHead = SelectorHead->next;
    }
    section++;
    return counter;
}

void PrintTheJthSelectroFromIthBlock(char *ArrForBuffror, Node **NodeHead)
{
    int section;
    section = ChangeCharToInt(ArrForBuffror, 0);

    int counter = 0;

    int whichOne;
    whichOne = ChangeCharToInt(ArrForBuffror, 4);

    int numberOfSection = numberOfSections(NodeHead);

    if (section > numberOfSection)
        return;
    section--;

    int numberOfSelectors = INTPrintNumberOfSelectorsForSection(ArrForBuffror, NodeHead);

    if (whichOne > numberOfSelectors)
    {
        return;
    }
    whichOne--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;

    while ((TempHead->next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    CounterForNullJump++;
                }
            }
        }
        TempHead = (TempHead->next);
    }
    int CounterPlusSection;
    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

    Selectors *SelectorHead;

    SelectorHead = List->ListForSelectors;

    // if(SelectorHead->ArrForSelectors != NULL){
    while ((SelectorHead->next) != NULL)
    {
        SelectorHead = (SelectorHead->next);
    }
    //}
    for (int i = 0; i < whichOne; i++)
    {
        SelectorHead = (SelectorHead->prev);
    }
    section++;
    whichOne++;

    int licz = 0;
    cout << section << ",S," << whichOne << " == ";
    while (SelectorHead->HowMuchCharsTakenInSelector > licz)
    {
        cout << SelectorHead->ArrForSelectors[licz];
        licz++;
    }
    cout << endl;
    // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
}
void DeleteSection(char *ArrForBuffor, Node **NodeHead, int PrintOrNot)
{

    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int counter = 0;

    int whichOne;
    whichOne = ChangeCharToInt(ArrForBuffor, 4);

    int numberOfSection = numberOfSections(NodeHead);

    if (section > numberOfSection)
        return;
    section--;

    int numberOfSelectors = INTPrintNumberOfSelectorsForSection(ArrForBuffor, NodeHead);

    if (whichOne > numberOfSelectors)
    {
        return;
    }
    whichOne--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;

    while ((TempHead->next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    CounterForNullJump++;
                }
            }
        }

        TempHead = (TempHead->next);
    }

    int CounterPlusSection;
    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);
    (List->ListForAtrributes->HowMuchCharsTakenInAtribut) = DelletedSegment;
    (List->ListForAtrributes) = NULL;
    (List->ListForSelectors) = NULL;
    section++;
    if (PrintOrNot == TRUE)
        cout << section << ",D,* == deleted" << endl;
}

void DeleteAttribute(char *ArrForBuffor, Node **NodeHead)
{

    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int SizeOfAtrribute = 0;
    while (1)
    {
        if (ArrForBuffor[SizeOfAtrribute] == '\0')
            break;
        else
            SizeOfAtrribute++;
    }


    int CounterForNullJump = 0;
    BlockOfTwoNodes *temp;

    if((TempHead-> next) == NULL){
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    if((temp->IsItNotUsed == NotYetUsedSegment)){

                    }else
                    CounterForNullJump++;
                }
            }
        }
    }

    while ((TempHead-> next) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            temp = &(TempHead->ArrForAtrybutesAndSelectors[i]);
            if ((temp->ListForAtrributes) == NULL)
            {
                if ((temp->ListForSelectors) == NULL)
                {
                    if((temp->IsItNotUsed == NotYetUsedSegment)){

                    }else
                    CounterForNullJump++;
                }
            }
        }
        TempHead = (TempHead->next);
    }


    int CounterPlusSection;
    CounterPlusSection = CounterForNullJump + section;

    for (int i = 0; i < (CounterPlusSection / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

    Atributes *AtributesHead;

    AtributesHead = List->ListForAtrributes;

    while ((AtributesHead) != NULL)
    {
        for (int i = 0; i < SizeOfAtrribute; i++)
        {
            // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
            if (ArrForBuffor[4 + i] != (AtributesHead->ArrForAtribut[i])) // COFFFFAJ A NIE DO PRZODUU
                break;
            if (i == (SizeOfAtrribute - 6))
            {

                section++;
                cout << section << ",D,";
                for (int j = 0; j < SizeOfAtrribute - 5; j++)
                {
                    cout << ArrForBuffor[4 + j];
                }
                cout << " == ";

                cout << "deleted" << endl;

                section--;
                if (AtributesHead->next == NULL)
                {
                    if (AtributesHead->prev == NULL)
                    {
                        DeleteSection(ArrForBuffor, (&TempHead), FALSE);
                        return;
                    }
                }

                Atributes *PreviusInList = AtributesHead->prev;
                Atributes *NextInList = AtributesHead->next;

                if (AtributesHead->prev != NULL)
                    (PreviusInList->next) = AtributesHead->next;

                if (AtributesHead->next != NULL)
                    (NextInList->prev) = AtributesHead->prev;

                //Lista musi sie zmienic na NextInList
                
                BlockOfTwoNodes* TempBlock;

                TempBlock = &(TempHead->ArrForAtrybutesAndSelectors[CounterPlusSection % SizeOfT]);

                TempBlock->ListForAtrributes = NextInList;

                AtributesHead->next = NULL;
                AtributesHead->prev = NULL;

                
                return;
            }
        }

        AtributesHead = AtributesHead->next;
    }

    return;
}

void PrintTheValueOfAttribute(char *ArrForBuffor, Node **NodeHead)
{
    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int SizeOfAtrribute = 0;
    while (1)
    {
        if (ArrForBuffor[SizeOfAtrribute] == '\0')
            break;
        else
            SizeOfAtrribute++;
    }

    while ((TempHead->next) != NULL)
    {
        TempHead = (TempHead->next);
    }

    for (int i = 0; i < (section / SizeOfT); i++)
    {
        TempHead = (TempHead->prev);
    }

    BlockOfTwoNodes *List;

    List = &(TempHead->ArrForAtrybutesAndSelectors[section % SizeOfT]);

    Atributes *AtributesHead;

    AtributesHead = List->ListForAtrributes;

    while ((AtributesHead) != NULL)
    {
        for (int i = 0; i < SizeOfAtrribute; i++)
        {
            // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
            if (ArrForBuffor[4 + i] != (AtributesHead->ArrForAtribut[i])) // COFFFFAJ A NIE DO PRZODUU
                break;
            if (i == (SizeOfAtrribute - 6))
            {

                section++;
                cout << section << ",A,";
                for (int j = 0; j < SizeOfAtrribute - 5; j++)
                {
                    cout << ArrForBuffor[4 + j];
                }
                cout << " == ";
                // cout << AtributesHead->ArrForAtributValue;
                for (int j = 0; j < AtributesHead->HowMuchCharsTakenInAtributValue; j++)
                {
                    cout << AtributesHead->ArrForAtributValue[j];
                }
                cout << endl;
            }
        }

        AtributesHead = AtributesHead->next;
    }

    return;
}

void PrintNumbersOfOccurencesSelector(char *ArrForBuffor, Node **NodeHead, int i, int CounterOfArrForBuffor)
{
    int counter = 0;

    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int SizeOfAtrribute = 0;
    while (1)
    {
        if (ArrForBuffor[SizeOfAtrribute] == '\0')
            break;
        else
            SizeOfAtrribute++;
    }
    if (TempHead->next == NULL)
    {
        BlockOfTwoNodes *List;
        for (int j = 0; j < SizeOfT; j++)
        {
            List = &(TempHead->ArrForAtrybutesAndSelectors[j]);

            Selectors *AtributesHead;

            AtributesHead = List->ListForSelectors;

            while ((AtributesHead) != NULL)
            {
                for (int k = 0; k < (i - 1); k++)
                {
                    // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
                    if (ArrForBuffor[k] != (AtributesHead->ArrForSelectors[k])) // COFFFFAJ A NIE DO PRZODUU
                        break;
                    if (k == (i - 2))
                    {

                        counter++;
                    }
                }

                AtributesHead = AtributesHead->next;
            }
        }
    }
    else
        while ((TempHead->next) != NULL)
        {
            BlockOfTwoNodes *List;
            for (int j = 0; j < SizeOfT; j++)
            {
                List = &(TempHead->ArrForAtrybutesAndSelectors[j]);

                Selectors *AtributesHead;

                AtributesHead = List->ListForSelectors;

                while ((AtributesHead) != NULL)
                {
                    for (int k = 0; k < (i - 1); k++)
                    {
                        // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
                        if (ArrForBuffor[k] != (AtributesHead->ArrForSelectors[k])) // COFFFFAJ A NIE DO PRZODUU
                            break;
                        if (k == (i - 2))
                        {

                            counter++;
                        }
                    }

                    AtributesHead = AtributesHead->next;
                }

                TempHead = (TempHead->next);
            }
        }
    for (int j = 0; j < i - 1; j++)
    {
        cout << ArrForBuffor[j];
    }
    cout << ",S,? == " << counter << endl;
    return;
}

void PrintNumbersOfOccurencesAttributes(char *ArrForBuffor, Node **NodeHead, int i, int CounterOfArrForBuffor)
{
    int counter = 0;

    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int SizeOfAtrribute = 0;
    while (1)
    {
        if (ArrForBuffor[SizeOfAtrribute] == '\0')
            break;
        else
            SizeOfAtrribute++;
    }
    if (TempHead->next == NULL)
    {
        BlockOfTwoNodes *List;
        for (int j = 0; j < SizeOfT; j++)
        {
            List = &(TempHead->ArrForAtrybutesAndSelectors[j]);

            Atributes *AtributesHead;

            AtributesHead = List->ListForAtrributes;

            while ((AtributesHead) != NULL)
            {
                for (int k = 0; k < (i - 1); k++)
                {
                    // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
                    if (ArrForBuffor[k] != (AtributesHead->ArrForAtribut[k])) // COFFFFAJ A NIE DO PRZODUU
                        break;
                    if (k == (i - 2))
                    {

                        counter++;
                    }
                }

                AtributesHead = AtributesHead->next;
            }
        }
    }
    else
        while ((TempHead->next) != NULL)
        {
            BlockOfTwoNodes *List;
            for (int j = 0; j < SizeOfT; j++)
            {
                List = &(TempHead->ArrForAtrybutesAndSelectors[j]);

                Atributes *AtributesHead;

                AtributesHead = List->ListForAtrributes;

                while ((AtributesHead) != NULL)
                {
                    for (int k = 0; k < (i - 1); k++)
                    {
                        // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
                        if (ArrForBuffor[k] != (AtributesHead->ArrForAtribut[k])) // COFFFFAJ A NIE DO PRZODUU
                            break;
                        if (k == (i - 2))
                        {

                            counter++;
                        }
                    }

                    AtributesHead = AtributesHead->next;
                }

                TempHead = (TempHead->next);
            }
        }
    for (int j = 0; j < i - 1; j++)
    {
        cout << ArrForBuffor[j];
    }
    cout << ",A,? == " << counter << endl;
    return;
}

void PrintValueOfAttributFromSelector(char *ArrForBuffor, Node **NodeHead, int i, int CounterOfArrForBuffor)
{

    int counter = 0;

    int section;
    section = ChangeCharToInt(ArrForBuffor, 0);

    int number = numberOfSections(NodeHead);

    if (section > number)
        return;
    section--;

    Node *TempHead = *NodeHead;
    BlockOfTwoNodes *TempArr;

    int SizeOfAtrribute = 0;
    while (1)
    {
        if (ArrForBuffor[SizeOfAtrribute] == '\0')
            break;
        else
            SizeOfAtrribute++;
    }
    if (TempHead->next == NULL)
    {
        BlockOfTwoNodes *List;
        for (int j = 0; j < SizeOfT; j++)
        {
            List = &(TempHead->ArrForAtrybutesAndSelectors[SizeOfT - j - 1]);

            Selectors *SelectorsHead;
            Atributes *AtributesHead;

            SelectorsHead = List->ListForSelectors;
            AtributesHead = List->ListForAtrributes;

            while ((SelectorsHead) != NULL)
            {
                for (int k = 0; k < (i - 1); k++)
                {
                    // cout << endl << "wazna transmisja ->" << ArrForBuffor[4+i] << "<-" << endl;
                    if (ArrForBuffor[k] != (SelectorsHead->ArrForSelectors[k])) // COFFFFAJ A NIE DO PRZODUU
                        break;
                    if (k == (i - 2))
                    {

                        while ((AtributesHead) != NULL)
                        {
                            for (int m = (i + 2); m < (CounterOfArrForBuffor); m++)
                            {
                                //cout << endl << "wazna transmisja ->" << ArrForBuffor[m] << "<-" << endl;
                                if (ArrForBuffor[m] != (AtributesHead->ArrForAtribut[m-i-2])) // COFFFFAJ A NIE DO PRZODUU
                                    break;
                                if (m == (CounterOfArrForBuffor - 3))
                                {
                                for(int z = 0; z < SelectorsHead->HowMuchCharsTakenInSelector; z++){
                                    cout << SelectorsHead->ArrForSelectors[z];
                                }
                                
                                cout << ",E,"; 
                                for(int z = 0; z < AtributesHead->HowMuchCharsTakenInAtribut; z++){
                                    cout << AtributesHead->ArrForAtribut[z];
                                }
                                                                
                                
                                cout << " == "; 
                                for(int z = 0; z < AtributesHead->HowMuchCharsTakenInAtributValue; z++){
                                    cout << AtributesHead->ArrForAtributValue[z];
                                }
                                     
                                }
                            }

                            AtributesHead = AtributesHead->next;
                        }

                        //ZobaczCzyMaTakiAtrybutJesliMaToGoWyprintuj();

                            return;
                    }
                }

                SelectorsHead = SelectorsHead->next;
            }
        }
    }
    else
        while ((TempHead->next) != NULL)
        {
            BlockOfTwoNodes *List;
            for (int j = 0; j < SizeOfT; j++)
            {
                List = &(TempHead->ArrForAtrybutesAndSelectors[j]);

                Selectors *SelectorsHead;
                Atributes *AtributesHead;

            SelectorsHead = List->ListForSelectors;
            AtributesHead = List->ListForAtrributes;

                while ((AtributesHead) != NULL)
                {
                    for (int k = 0; k < (i - 1); k++)
                    {
                        if (ArrForBuffor[k] != (SelectorsHead->ArrForSelectors[k])) // COFFFFAJ A NIE DO PRZODUU
                            break;
                        if (k == (i - 2))
                        {


                        while ((AtributesHead) != NULL)
                        {
                            for (int m = (i + 2); m < (CounterOfArrForBuffor); m++)
                            {
                                //cout << endl << "wazna transmisja ->" << ArrForBuffor[m] << "<-" << endl;
                                if (ArrForBuffor[m] != (AtributesHead->ArrForAtribut[m-i-2])) // COFFFFAJ A NIE DO PRZODUU
                                    break;
                                if (m == (CounterOfArrForBuffor - 3))
                                {
                                cout << SelectorsHead->ArrForSelectors << ",E," << AtributesHead->ArrForAtribut << " == " << AtributesHead->ArrForAtributValue;

                                }
                            }

                            AtributesHead = AtributesHead->next;
                        }
                        return;
                        }
                    }

                    AtributesHead = AtributesHead->next;
                }

                TempHead = (TempHead->next);
            }
        }
    for (int j = 0; j < i - 1; j++)
    {
        cout << ArrForBuffor[j];
    }
    cout << ",S,? == " << counter << endl;
    return;
}

void SanitizeInput(char *ArrForBuffor, int *counter)
{
    int temp = 0;
    while (1)
    {
        if (ArrForBuffor[temp] == '\0')
            break;
        else
            temp++;
    }

    for (int i = 0; i < *counter; i++)
    {
        if (ArrForBuffor[i] == ' ')
        {
            for (int j = 0; j < *counter - 1; j++)
            {
                ArrForBuffor[j] = ArrForBuffor[j + 1]; // zmienilem i na j powinno pomuc moze cos zepsulo
            }
            ArrForBuffor[*counter] = '\0';
            (*counter)--;
        }
        else
            break;
    }

    for (int i = 0; i < temp; i++)
    {
        if (ArrForBuffor[(temp)-i - 1] == ' ') // Poooooooooooooooooooooooooprostu januszowo obnizylem o jeden moze miec dalsze implikacje
        {
            ArrForBuffor[*counter] = '\0';
            (*counter)--;
        }
        else
            break;
    }
}

void CreateNewNodeAndPutPointerInFirstPlace(BlockOfTwoNodes **pointer, Node **NodeHead)
{
    Node *newnode = new Node;
    // Daj tu jeszcze double linkkkkkkkkkkkkkkkkkkk
    newnode->next = *NodeHead;
    if (*NodeHead != NULL)
    {
        (*NodeHead)->prev = newnode;
    }
    *NodeHead = newnode;

    *pointer = (*NodeHead)->ArrForAtrybutesAndSelectors;
    (*pointer)-> IsItNotUsed = UsedSegment;

}

int CheckIfAllSlotsAreEmpty(Node **NodeHead)
{

    for (int i = 0; i < SizeOfT; i++)
    {
        if (&((((*NodeHead)->ArrForAtrybutesAndSelectors)->ListForAtrributes[i])) == NULL)
        {
            if (&((((*NodeHead)->ArrForAtrybutesAndSelectors)->ListForSelectors[i])) == NULL)
            {
                return TRUE;
            }
        }
    }
    return FALSE;
}

int CheckWeatherInPreviousNodeThereIsSpace(Node **NodeHead)
{
    if (((*NodeHead)->next) == NULL)
    {
        return FALSE;
    }
    else
    {
        if ((&((*NodeHead)->next)->ArrForAtrybutesAndSelectors[(SizeOfT - 1)])->ListForAtrributes == NULL)
        {
            if ((&((*NodeHead)->next)->ArrForAtrybutesAndSelectors[(SizeOfT - 1)])->ListForAtrributes == NULL)
            {
                return TRUE;
            }
        }
    }
    return FALSE;
}

void GetAddresFromPreviusNode(BlockOfTwoNodes **pointer, Node **NodeHead)
{
    int counter = -1;
    for (int i = 0; i < SizeOfT; i++)
    {
        if ((&((*NodeHead)->next)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - i)])->ListForAtrributes == NULL)
        {
            if ((&((*NodeHead)->next)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - i)])->ListForAtrributes == NULL)
            {
                counter++;
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    *pointer = (&((*NodeHead)->next)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - counter)]);
    (*pointer)-> IsItNotUsed = UsedSegment;
}

int GetAndSetAddresFromCurrentNode(BlockOfTwoNodes **pointer, Node **NodeHead)
{
    int counter = 0;

    if ((&(*NodeHead)->ArrForAtrybutesAndSelectors[(SizeOfT - 1)])->ListForAtrributes != NULL)
    {
        if ((&(*NodeHead)->ArrForAtrybutesAndSelectors[(SizeOfT - 1)])->ListForAtrributes != NULL)
        {
            return FALSE;
        }
    }

    for (int i = 1; i < SizeOfT; i++)
    {

        if ((&(*NodeHead)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - i)])->ListForAtrributes != NULL)
        {
            if ((&(*NodeHead)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - i)])->ListForAtrributes != NULL)
            {
                break;
            }
        }
        counter++;
    }
    *pointer = (&(*NodeHead)->ArrForAtrybutesAndSelectors[(SizeOfT - 1 - counter)]);
    (*pointer)-> IsItNotUsed = UsedSegment;

    return TRUE;
}

void AddNewNodeSelector(Selectors **Head)
{
    Selectors *newnode = new Selectors;

    newnode->next = *Head;
    if (*Head != NULL)
    {
        (*Head)->prev = newnode;
    }
    *Head = newnode;
}

void AddNewNodeAtribut(Atributes **Head)
{
    Atributes *newnode = new Atributes;

    newnode->next = *Head;
    if (*Head != NULL)
    {
        (*Head)->prev = newnode;
    }
    *Head = newnode;
}

void AddNewMainNode(Node **Head)
{
    Node *newnode = new Node;

    newnode->next = *Head;
    if (*Head != NULL)
    {
        (*Head)->prev = newnode;
    }
    *Head = newnode;
}

void changePointerToNextBlock(BlockOfTwoNodes **Pointer, Node **NodeHead)
{

    if (CheckIfAllSlotsAreEmpty(NodeHead) == TRUE)
    {
        if (CheckWeatherInPreviousNodeThereIsSpace(NodeHead) == TRUE)
        {
            GetAddresFromPreviusNode(Pointer, NodeHead);
            return;
        }
    }

    if (GetAndSetAddresFromCurrentNode(Pointer, NodeHead) == FALSE)
    {
        CreateNewNodeAndPutPointerInFirstPlace(Pointer, NodeHead);
    }
}

void AddCharToCurrentAtribute(Atributes *CurrentAtribute, char NEXTCHAR)
{
    int HomMuchPlaceIsAlreadyTaken;
    HomMuchPlaceIsAlreadyTaken = (CurrentAtribute->HowMuchCharsTakenInAtribut);

    CurrentAtribute->ArrForAtribut[HomMuchPlaceIsAlreadyTaken] = NEXTCHAR;

    (CurrentAtribute->HowMuchCharsTakenInAtribut)++;

    //   cout << endl
    //      << "ADDED char to attribute ->" << NEXTCHAR << "<-" << endl
    //    << "CurrentSegment       ||" << (CurrentAtribute->ArrForAtribut) << "||" << endl;
}

void AddCharToCurrentAtributeValue(Atributes *CurrentAtribute, char NEXTCHAR)
{
    int HomMuchPlaceIsAlreadyTaken;
    HomMuchPlaceIsAlreadyTaken = (CurrentAtribute->HowMuchCharsTakenInAtributValue);

    CurrentAtribute->ArrForAtributValue[HomMuchPlaceIsAlreadyTaken] = NEXTCHAR;

    (CurrentAtribute->HowMuchCharsTakenInAtributValue)++;

    //   cout << endl
    //      << "ADDED char to attributeValue ->" << NEXTCHAR << "<-" << endl
    //    << "CurrentSegment       ||" << (CurrentAtribute->ArrForAtributValue) << "||" << endl;
}

void AddCharToCurrentSelector(Selectors *CurrentSelector, char NEXTCHAR)
{
    int HomMuchPlaceIsAlreadyTaken;
    HomMuchPlaceIsAlreadyTaken = (CurrentSelector->HowMuchCharsTakenInSelector);

    CurrentSelector->ArrForSelectors[HomMuchPlaceIsAlreadyTaken] = NEXTCHAR;

    (CurrentSelector->HowMuchCharsTakenInSelector)++;

    //   cout << endl
    //      << "ADDED char to selector ->" << NEXTCHAR << "<-" << endl
    //    << "CurrentSegment       ||" << (CurrentSelector->ArrForSelectors) << "||" << endl;
}

void CleanTempArr(char *Arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        Arr[i] = '\0';
    }
}

int CanIDeterminWhatItIs(char *ArrForBuffor, int CounterOfArrForBuffor, int *WhatIsExpectedSituation, BlockOfTwoNodes **PointerToCurrentBlock, Node **NodeHead)
{
    // Selectors

    if (*WhatIsExpectedSituation == NEWBLOCK)
    {
        if (ArrForBuffor[CounterOfArrForBuffor] == '{')
        {
            ArrForBuffor[CounterOfArrForBuffor] = '\0';
            *WhatIsExpectedSituation = WEAREINSIDEOFBLOCK;
            return Selector;
        }
        if (ArrForBuffor[CounterOfArrForBuffor] == ',')
        {
            ArrForBuffor[CounterOfArrForBuffor] = '\0';

            return Selector;
        }
    }

    // Atributes
    if (*WhatIsExpectedSituation == WEAREINSIDEOFBLOCK)
    {
        if (ArrForBuffor[CounterOfArrForBuffor] == ':')
        {
            ArrForBuffor[CounterOfArrForBuffor] = '\0';

            *WhatIsExpectedSituation = YouJustEnteredAttribute;
            return Atribut;
        }
    }

    if (*WhatIsExpectedSituation == YouJustEnteredAttribute)
    {
        if (ArrForBuffor[CounterOfArrForBuffor] == ';') // tuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu
        {
            ArrForBuffor[CounterOfArrForBuffor] = '\0';

            *WhatIsExpectedSituation = WEAREINSIDEOFBLOCK;
            return AtributValue;
        }
    }

    if (ArrForBuffor[CounterOfArrForBuffor] == '}') // tu koniec bloku
    {
        *WhatIsExpectedSituation = NEWBLOCK;

        changePointerToNextBlock(PointerToCurrentBlock, NodeHead);
        // I TU TEZ NA NOWY NODE
        return JustCleanArr;
    }

    //????
    if (*WhatIsExpectedSituation == NEWBLOCK)
    {
        if (CounterOfArrForBuffor > 2)
        {
            if (ArrForBuffor[CounterOfArrForBuffor] == '?')
            {
                if (ArrForBuffor[CounterOfArrForBuffor - 1] == '?')
                {
                    if (ArrForBuffor[CounterOfArrForBuffor - 2] == '?')
                    {
                        if (ArrForBuffor[CounterOfArrForBuffor - 3] == '?')
                        {
                            return StrartOfComandMode;
                        }
                    }
                }
            }
        }
    }

    //****
    if (*WhatIsExpectedSituation == WeAreInsideCommandMode)
    {
        if (CounterOfArrForBuffor > 2)
        {
            if (ArrForBuffor[CounterOfArrForBuffor] == '*')
            {
                if (ArrForBuffor[CounterOfArrForBuffor - 1] == '*')
                {
                    if (ArrForBuffor[CounterOfArrForBuffor - 2] == '*')
                    {
                        if (ArrForBuffor[CounterOfArrForBuffor - 3] == '*')
                        {
                            changePointerToNextBlock(PointerToCurrentBlock, NodeHead);
                            return EndOfComandMode;
                        }
                    }
                }
            }
        }
    }

    // placeHolder
    if (*WhatIsExpectedSituation == WeAreInsideCommandMode)
    {
        if (CounterOfArrForBuffor > 2) // Januszowanie 100%
        {
            if (ArrForBuffor[CounterOfArrForBuffor - 1] == '?')
            {
                if (ArrForBuffor[CounterOfArrForBuffor - 2] == '?')
                {
                    if (ArrForBuffor[CounterOfArrForBuffor - 3] == '?')
                    {
                        if (ArrForBuffor[CounterOfArrForBuffor - 4] == '?')
                        {
                            return JustCleanArr;
                        }
                    }
                }
            }
        }
        if (CounterOfArrForBuffor != 0)
        {
            if (ArrForBuffor[CounterOfArrForBuffor] == '\n')
            {
                // cout << endl
                //      << "Just enntered command" << endl;
                if (ArrForBuffor[0] == '?')
                {
                    cout << "? == " << numberOfSections(NodeHead) << endl;
                }
                if (ArrForBuffor[0] > '/')
                {
                    if (ArrForBuffor[0] < ':')
                    {
                        if (ArrForBuffor[2] == 'S')
                        {
                            if (ArrForBuffor[4] == '?')
                            {
                                PrintNumberOfSelectorsForSection(ArrForBuffor, NodeHead);
                            }
                            else
                            {
                                PrintTheJthSelectroFromIthBlock(ArrForBuffor, NodeHead);
                            }
                        }
                        if (ArrForBuffor[2] == 'A')
                        {
                            if (ArrForBuffor[4] == '?')
                            {
                                PrintNumberOfAttributesForSection(ArrForBuffor, NodeHead);
                            }
                            else
                            {
                                PrintTheValueOfAttribute(ArrForBuffor, NodeHead);
                            }
                        }
                        if (ArrForBuffor[2] == 'D')
                        {
                            if (ArrForBuffor[4] == '*')
                            {
                                DeleteSection(ArrForBuffor, NodeHead, TRUE);
                            }
                            else
                            {
                                DeleteAttribute(ArrForBuffor, NodeHead);
                            }
                        }
                        // cout << endl << "Itsa a diggita";
                    }
                }
                if (ArrForBuffor[0] > '@')
                {
                    if (ArrForBuffor[0] < '{')
                    {
                        for (int i = 1; i < CounterOfArrForBuffor - 1; i++)
                        {
                            if (ArrForBuffor[i] == 'S')
                            {
                                if (ArrForBuffor[i + 1] == ',')
                                {
                                    if (ArrForBuffor[i - 1] == ',')
                                    {
                                        PrintNumbersOfOccurencesSelector(ArrForBuffor, NodeHead, i, CounterOfArrForBuffor);
                                    }
                                }
                            }
                        }
                        for (int i = 1; i < CounterOfArrForBuffor - 1; i++)
                        {
                            if (ArrForBuffor[i] == 'A')
                            {
                                if (ArrForBuffor[i + 1] == ',')
                                {
                                    if (ArrForBuffor[i - 1] == ',')
                                    {
                                        PrintNumbersOfOccurencesAttributes(ArrForBuffor, NodeHead, i, CounterOfArrForBuffor);
                                    }
                                }
                            }
                        }
                        for (int i = 1; i < CounterOfArrForBuffor - 1; i++)
                        {
                            if (ArrForBuffor[i] == 'E')
                            {
                                if (ArrForBuffor[i + 1] == ',')
                                {
                                    if (ArrForBuffor[i - 1] == ',')
                                    {
                                        PrintValueOfAttributFromSelector(ArrForBuffor, NodeHead, i, CounterOfArrForBuffor);
                                    }
                                }
                            }
                        }                         
                    }
                }

                return JustCleanArr;
            }
        }
    }

    return NotYet;
}

int main(void)
{
    char x;
    char ArrForBuffor[MaxSizeOfOneElement];
    int CounterOfArrForBuffor = 0;
    int DecisionConcerningInput = 0;
    int WhatIsExpectedSituation = NEWBLOCK;
    int *WhatIsPtr = &WhatIsExpectedSituation;
    int FlagIncreseCounterOfArrForBuffor = 0;

    char ArrForSelectors[MaxSizeOfOneElement];
    char ArrForAtributes[MaxSizeOfOneElement];
    char ArrForAtributesValues[MaxSizeOfOneElement];
    int CounterForArrForSelectors = 0;
    int CounterForArrForAtributes = 0;
    int CounterForArrForAtributesValuse = 0;

    Node FirstNode;
    Node *NodeHead;
    NodeHead = &FirstNode;

    BlockOfTwoNodes *PointerToCurrentBlock;

    PointerToCurrentBlock = &(FirstNode.ArrForAtrybutesAndSelectors[0]);

    while ((x = getchar()) != EOF)
    {
        if (WhatIsExpectedSituation != WeAreInsideCommandMode)
        {
            if (x != '\n')
            {
                if (x != '\t')
                {
                    if (WhatIsExpectedSituation == NEWBLOCK)
                    {

                        ArrForBuffor[CounterOfArrForBuffor] = x;
                        FlagIncreseCounterOfArrForBuffor++;
                    }
                    else
                    {
                        ArrForBuffor[CounterOfArrForBuffor] = x;
                        FlagIncreseCounterOfArrForBuffor++;
                    }
                }
            }
        }
        else
        {
            ArrForBuffor[CounterOfArrForBuffor] = x;
            FlagIncreseCounterOfArrForBuffor++;
        }

        DecisionConcerningInput = CanIDeterminWhatItIs(ArrForBuffor, CounterOfArrForBuffor, &WhatIsExpectedSituation, &PointerToCurrentBlock, &NodeHead);
        if (FlagIncreseCounterOfArrForBuffor == 1)
        {
            CounterOfArrForBuffor++;
            FlagIncreseCounterOfArrForBuffor--;
        }

        if (DecisionConcerningInput != NotYet)
        {
            SanitizeInput(ArrForBuffor, &CounterOfArrForBuffor);

            if (DecisionConcerningInput == Selector)
            {

                AddNewNodeSelector(&(PointerToCurrentBlock->ListForSelectors));

                for (int i = 0; i < (CounterOfArrForBuffor - 1); i++)
                {
                    ArrForSelectors[CounterForArrForSelectors] = ArrForBuffor[i];
                    AddCharToCurrentSelector(PointerToCurrentBlock->ListForSelectors, ArrForBuffor[i]);
                    // put char in the right spot
                    CounterForArrForSelectors++;
                }
                // ZROB TU PRZESKOCZENIE NA KOLEJNEGO NODA

                CleanTempArr(ArrForBuffor, CounterOfArrForBuffor);
                CounterOfArrForBuffor = 0;
            }
            else if (DecisionConcerningInput == Atribut)
            {

                AddNewNodeAtribut(&(PointerToCurrentBlock->ListForAtrributes));

                for (int i = 0; i < (CounterOfArrForBuffor - 1); i++)
                { // przerzut na strukture danych
                    ArrForAtributes[CounterForArrForAtributes] = ArrForBuffor[i];
                    AddCharToCurrentAtribute((PointerToCurrentBlock->ListForAtrributes), ArrForBuffor[i]);
                    CounterForArrForAtributes++;
                }

                CleanTempArr(ArrForBuffor, CounterOfArrForBuffor);
                CounterOfArrForBuffor = 0;
            }
            else if (DecisionConcerningInput == AtributValue)
            {
                for (int i = 0; i < (CounterOfArrForBuffor - 1); i++) // tu
                {

                    ArrForAtributesValues[CounterForArrForAtributesValuse] = ArrForBuffor[i];
                    AddCharToCurrentAtributeValue((PointerToCurrentBlock->ListForAtrributes), ArrForBuffor[i]);
                    CounterForArrForAtributesValuse++; // i to ruzne czarne listy dla ruznych danych
                }

                CleanTempArr(ArrForBuffor, CounterOfArrForBuffor);
                CounterOfArrForBuffor = 0;
            }
            else if (DecisionConcerningInput == StrartOfComandMode)
            {
                WhatIsExpectedSituation = WeAreInsideCommandMode;
            }
            else if (DecisionConcerningInput == EndOfComandMode)
            {
                WhatIsExpectedSituation = NEWBLOCK;
                CleanTempArr(ArrForBuffor, CounterOfArrForBuffor);
                CounterOfArrForBuffor = 0;
            }
            else if (DecisionConcerningInput == JustCleanArr)
            {
                CleanTempArr(ArrForBuffor, CounterOfArrForBuffor);
                CounterOfArrForBuffor = 0;
            }
            /*else if (DecisionConcerningInput == PlaceHolderKomendy)
            {
            }*/
            // czyszczenie tablicy i CounterOfArrForSegments na 0 zpowrotem
        }
    }

    // WykonajEwentualnaKomendeBezEnteraNaKoncu();

   // cout << endl
     //    << "koniec";

    // testowanie komend
    /*
    Node *TempHead = NodeHead;
    BlockOfTwoNodes *TempArr;

    while ((TempHead->next) != NULL)
    {
        TempHead = (TempHead->next);
    }
    while ((TempHead->prev) != NULL)
    {
        for (int i = 0; i < SizeOfT; i++)
        {
            // cout << endl << TempHead->ArrForAtrybutesAndSelectors->ListForSelectors->ArrForSelectors;
            // cout << endl << TempHead->ArrForAtrybutesAndSelectors->ListForSelectors->ArrForSelectors;
            TempArr = TempHead->ArrForAtrybutesAndSelectors;
            // cout << endl
            //     << (&(TempArr[i]))->ListForSelectors->ArrForSelectors;
        }
        TempHead = (TempHead->prev);
    }

    int counter = 0;

    Node *TempHead2 = NodeHead;
    while ((TempHead2->next) != NULL)
    {
        TempHead2 = (TempHead2->next);
    }

    while ((TempHead2->prev) != NULL)
    {

        TempHead2 = (TempHead2->prev);
    }

    /*    cout << endl
             << "now output" << endl
             << "selectors  ||" << ArrForSelectors << endl
             << "atributes   ||" << ArrForAtributes << endl
             << "atributes values   ||" << ArrForAtributesValues << "||eeeeeeeeeeeeesssssssssssssssssssiiiiiiiiiiiiiiiiieeeeeeeeeeeeeerrrrrrrrrrrrrrrrtttttttttttttttoooooooooooooossssssssssssppppppppppppppppoooooooooooottttttttttt";
    */
}
// cztery do tyu i na koniec wykonuje trzy?
//  https://stackoverflow.com/questions/8657702/what-do-t-and-b-do
// czy moge juz zdeterminowac co to jest
// jesli tak akcja i czyszczenie
//
// WhatIsExpected situation warzne