#pragma once
#include <iostream>

class String
{
public:
	char t1[32];
	char* t2 = nullptr;
	int size = 0;
	//int sizeOnT2 = 0;
	int capacity = 32;

	String(){}
	~String(){delete[] t2;}

	void dodajLiterke(char c)
	{
		// t1 do 32
		// 33 element w t2 juz

		if (size < 32)
		{
			t1[size] = c;
			size++;
		}
		else if (size == 32)
		{
			t2 = new char[capacity];
			t2[0] = c;
			size++;
		}
		else // 16 
		{
			int liczbaElementowWT2 = size - 32;
			if (liczbaElementowWT2 >= capacity)	// jesli tablica t2 nie zmiesci nowego chara, tworzymy wieksza tablice
			{
				capacity *= 1.5;
				char* nowaTablica = new char[capacity];
				for (int i = 0; i < liczbaElementowWT2; i++)
				{
					nowaTablica[i] = t2[i];
				}
				delete[] t2;
				t2 = nowaTablica;
				t2[liczbaElementowWT2] = c;
				size++;
			}
			else
			{
				int liczbaElementowWT2 = size - 32;
				t2[liczbaElementowWT2] = c;
				size++;
			}
		}
	}

	bool operator== (String& drugiString)
	{
		if (this->size != drugiString.size)
		{
			return false;
		}
		for (int i = 0; i < size; i++)
		{
			if (i < 32)
			{
				if (this->t1[i] != drugiString.t1[i])
				{
					return false;
				}
			}
			else
			{
				int liczbaElementowWT2 = i - 32;
				if (this->t2[liczbaElementowWT2] != drugiString.t2[liczbaElementowWT2])
				{
					return false;
				}
			}
		}
		return true;
	}

	int toInt()
	{
		int liczba = 0;

		for (int i = 0; i < size; i++)
		{
			liczba *= 10;
			liczba += t1[i] - '0';
		}
		return liczba;
	}

	String& operator=(const String& drugiString)
	{

		this->size = drugiString.size;
		if (this->t2 != nullptr)
		{
			delete[]t2;
			t2 = nullptr;
		}
		if (drugiString.t2 != nullptr)
		{
			this->capacity = drugiString.capacity;
			this->t2 = new char[capacity];
		}
		for (int i = 0; i < size; i++)
		{
			if (i < 32)
			{
				this->t1[i] = drugiString.t1[i];
			}
			else
			{
				int indeksElementowWT2 = i - 32;
				this->t2[indeksElementowWT2] = drugiString.t2[indeksElementowWT2];
			}
		}
		return *this;
	}
};
