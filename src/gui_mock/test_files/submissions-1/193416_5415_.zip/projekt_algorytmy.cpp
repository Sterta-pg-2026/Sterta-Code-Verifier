﻿#include <iostream>
#include "mystring.h"
#define ROZMIAR 8

using namespace std;

using uint = unsigned int;

ostream& operator<<(ostream& out, String& string)
{
	for (int i = 0; i < string.size; i++)
	{
		if (i < 32)
		{
			out << string.t1[i];
		}
		else
		{
			int indeksWT2 = i - 32;
			out << string.t2[indeksWT2];
		}
	}
	return out;
}

class Atrybut {
public:
	String nazwa;
	String wartosc;
};

class WezelAtrybut {
public:
	WezelAtrybut* nastepny = nullptr;
	Atrybut* element;

	WezelAtrybut(Atrybut* wartosc)
	{
		this->element = wartosc;
	}
	~WezelAtrybut() { delete element; }
};

class ListaAtrybutow {
public:
	WezelAtrybut* head = nullptr;
	WezelAtrybut* tail = nullptr;
	int suma = 0;

	void dodajElement(Atrybut* wartosc) 
	{
		suma++;
		WezelAtrybut* nowyAtrybut = new WezelAtrybut(wartosc);
		if (head == nullptr)
		{
			head = nowyAtrybut;
			tail = nowyAtrybut;
		}
		else
		{
			WezelAtrybut* tmpTail = tail;
			tail = nowyAtrybut;
			tmpTail->nastepny = nowyAtrybut;
		}
	}
	~ListaAtrybutow() {
		WezelAtrybut* wezel = head;
		for (int i = 0; i < suma; i++)
		{
			if (wezel != nullptr) {
				WezelAtrybut* wezelNastepny = wezel->nastepny;
				delete wezel;
				wezel = wezelNastepny;
			}
			
		}
	}
};

class Selektor {
public:
	String nazwa;
};

class WezelSelektor {
public:
	WezelSelektor* nastepny = nullptr;
	Selektor* wartosc;

	WezelSelektor(Selektor* wartosc)
	{
		this->wartosc = wartosc;
	}
	~WezelSelektor() 
	{
		delete wartosc;
	}
};

class ListaSelektorow {
public:
	WezelSelektor* head = nullptr;
	WezelSelektor* tail = nullptr;
	int suma = 0;

	void dodajElement(Selektor* wartosc) 
	{
		suma++;
		WezelSelektor* nowySelektor = new WezelSelektor(wartosc);
		if (head == nullptr)
		{
			head = nowySelektor;
			tail = nowySelektor;
		}
		else
		{
			WezelSelektor* tmpTail = tail;
			tail = nowySelektor;
			tmpTail->nastepny = nowySelektor;
		}
	}
	~ListaSelektorow() {
		WezelSelektor* wezel = head;
		for (int i = 0; i < suma; i++)
		{
			if (wezel != nullptr)
			{
				WezelSelektor* wezelNastepny = wezel->nastepny;
				delete wezel;
				wezel = wezelNastepny;
			}
			
		}
	}
};

class Sekcja {
public:
	ListaSelektorow selektory;
	ListaAtrybutow atrybuty;
};

class WezelSekcji {
public:
	WezelSekcji* nastepny = nullptr;
	WezelSekcji* poprzedni = nullptr;
	Sekcja* tablica[ROZMIAR] = { nullptr };
	uint licznik = 0;

	WezelSekcji() {}

	void dodajElement(Sekcja* wartosc) {
		tablica[licznik] = wartosc;
		licznik++;
	}
	~WezelSekcji() {
		for (int i = 0; i < licznik; i++)
		{
			delete tablica[i];
		}
	}
};

class ListaSekcji {
public:
	WezelSekcji* head = nullptr;
	WezelSekcji* tail = nullptr;
	int n = 0;
	ListaSekcji() {}

	void dodajElementNaKoniec(Sekcja* wartosc) 
	{
		n++;

		if (head == nullptr)
		{
			WezelSekcji* nowyWezel = new WezelSekcji();
			nowyWezel->dodajElement(wartosc);
			head = nowyWezel;
			tail = nowyWezel;
		}
		else 
		{
			if (tail->licznik == ROZMIAR)
			{
				WezelSekcji* nowyWezel = new WezelSekcji();
				WezelSekcji* staryTail = tail;
				tail = nowyWezel;

				staryTail->nastepny = nowyWezel;
				tail->poprzedni = staryTail;
				nowyWezel->dodajElement(wartosc);
			}
			else 
			{
				tail->dodajElement(wartosc);
			}
		}
	}

	~ListaSekcji()
	{
		WezelSekcji* wezel = head;
		for (int i = 0; i < n; i++)
		{
			if (wezel != nullptr)
			{
				WezelSekcji* wezelNastepny = wezel->nastepny;
				delete wezel;
				wezel = wezelNastepny;
			}
			
		}
	}

	//komendy

	void wypiszLiczbeSekcji()
	{
		cout << "? == " << n << endl;
	}

	void wypiszLiczbeSelektorowDlaSekcjiNri(int i)
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;

		}

		cout << numerSekcji << ",S,? == " << wezel->tablica[i-1]->selektory.suma << endl;
	}

	void wypiszLiczbeAtrybutowDlaSekcjiNri(int i) 
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;

		}
		cout << numerSekcji << ",A,? == " << wezel->tablica[i-1]->atrybuty.suma << endl;
	}

	void wypiszJtySelektorDlaItegoBloku(int i, int j) 
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;

		}

		int numerSelektora = j;

		WezelSelektor* wezelSelektor = wezel->tablica[i-1]->selektory.head;

		if (numerSelektora <= wezel->tablica[i-1]->selektory.suma)
		{
			for (int i = 0; i < numerSelektora - 1; i++)
			{
				wezelSelektor = (wezelSelektor->nastepny);
			}
			cout << numerSekcji << ",S," << j << " == " << wezelSelektor->wartosc->nazwa << endl;
		}
	}

	void wypiszDlaItejSekcjiWartoscAtrybutuN(int i, String& n)
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;

		}

		int sumaAtrybutow = wezel->tablica[i-1]->atrybuty.suma;

		WezelAtrybut* wezelAtrybut = wezel->tablica[i-1]->atrybuty.head;

		for (int i = 1; i <= sumaAtrybutow; i++)
		{
			if (wezelAtrybut->element->nazwa == n)
			{
				cout << numerSekcji << ",A," << n << " == " << wezelAtrybut->element->wartosc << endl;
				return;
			}
			else
			{
				wezelAtrybut = (wezelAtrybut->nastepny);
			}
		}
	}

	void wypiszLiczbeWystapienSelektoraZ(String& z)
	{
		int sumaSekcji = n;
		int suma = 0;

		WezelSekcji* wezel = head;

		while (wezel != nullptr)
		{
			for (int i = 0; i < ROZMIAR; i++)
			{
				if (wezel->tablica[i] != nullptr)
				{
					WezelSelektor* wezelSelektor = wezel->tablica[i]->selektory.head;
					while (wezelSelektor != nullptr)
					{
						if (wezelSelektor->wartosc->nazwa == z)
						{
							suma++;
							break;
						}
						wezelSelektor = wezelSelektor->nastepny;
					}
				}
			}
			wezel = wezel->nastepny;
		}
		cout << z << ",S,? == " << suma << endl;
	}

	void usunSekcjeNrI(int i)
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;

		}

		delete wezel->tablica[i - 1];

		for (int j=i-1; j < ROZMIAR - 1; j++)
		{
			wezel->tablica[j] = wezel->tablica[j+ 1];
		}
		wezel->tablica[ROZMIAR - 1]=nullptr;
		wezel->licznik--;
		this->n--;
		
		cout << numerSekcji << ",D,* == deleted" << endl;
	}

	void usunAtrybutNZSekcjiI(int i, String& n)
	{
		int numerSekcji = i;
		if (i > this->n)
		{
			return;
		}

		WezelSekcji* wezel = head;

		while (i > wezel->licznik)
		{
			i = i - wezel->licznik;
			wezel = wezel->nastepny;
		}
		WezelAtrybut* wezelAtrybut = wezel->tablica[i - 1]->atrybuty.head;
		WezelAtrybut* staryWezel = nullptr;

		while (wezelAtrybut != nullptr)
		{
			if (wezelAtrybut->element->nazwa == n)
			{
				if (wezelAtrybut == wezel->tablica[i - 1]->atrybuty.head && wezelAtrybut == wezel->tablica[i - 1]->atrybuty.tail)
				{
					wezel->tablica[i - 1]->atrybuty.head = nullptr;
					wezel->tablica[i - 1]->atrybuty.tail = nullptr;
					wezel->tablica[i - 1]->atrybuty.suma--;
					delete wezelAtrybut;
				}
				else if (wezelAtrybut == wezel->tablica[i - 1]->atrybuty.head)
				{
					wezel->tablica[i - 1]->atrybuty.head = wezel->tablica[i - 1]->atrybuty.head->nastepny;
					wezel->tablica[i - 1]->atrybuty.suma--;
					delete wezelAtrybut;
				}
				else if (wezelAtrybut == wezel->tablica[i - 1]->atrybuty.tail)
				{
					wezel->tablica[i - 1]->atrybuty.tail = staryWezel;
					wezel->tablica[i - 1]->atrybuty.tail->nastepny = nullptr;
					wezel->tablica[i - 1]->atrybuty.suma--;
					delete wezelAtrybut;
				}
				else
				{
					staryWezel->nastepny = wezelAtrybut->nastepny;
					wezel->tablica[i - 1]->atrybuty.suma--;
					delete wezelAtrybut;
				}
				if (wezel->tablica[i - 1]->atrybuty.suma == 0)
				{
					delete wezel->tablica[i - 1];

					for (int j = i - 1; j < ROZMIAR - 1; j++)
					{
						wezel->tablica[j] = wezel->tablica[j + 1];
					}
					wezel->tablica[ROZMIAR - 1]=nullptr;
					wezel->licznik--;
					this->n--;
				}
				cout << numerSekcji<<",D,"<<n<<" == deleted" << endl;
				return;
			}
			staryWezel = wezelAtrybut;
			wezelAtrybut = wezelAtrybut->nastepny;
		}
	}

	void wypiszLiczbeWystapienAtrybutuN(String& n)
	{
		int suma = 0;

		WezelSekcji* wezel = head;

		while (wezel != nullptr)
		{
			for (int i = 0; i < ROZMIAR; i++)
			{
				if (wezel->tablica[i] != nullptr)
				{
					WezelAtrybut* wezelAtrybut = wezel->tablica[i]->atrybuty.head;
					while (wezelAtrybut != nullptr)
					{
						//cout << "NAZWA: " << wezelAtrybut->element->nazwa << endl;
						if (wezelAtrybut->element->nazwa==n)
						{
							suma++;
							break;
						}
						wezelAtrybut = wezelAtrybut->nastepny;
					}
				}

			}
			wezel = wezel->nastepny;
		}
		cout << n << ",A,? == " << suma << endl;


	}

	void wypiszWartoscAtrybutuNDlaSelektoraZ(String& n, String& z)
	{
		WezelSekcji* wezel = tail;

		while (wezel != nullptr)
		{
			for (int i = ROZMIAR -1; i >=0; i--)
			{
				if (wezel->tablica[i] != nullptr)
				{
					WezelSelektor* wezelSelektor = wezel->tablica[i]->selektory.head;
					while (wezelSelektor != nullptr)
					{
						if (wezelSelektor->wartosc->nazwa == z)
						{
							if (wezel->tablica[i] != nullptr)
							{
								WezelAtrybut* wezelAtrybut = wezel->tablica[i]->atrybuty.head;
								while (wezelAtrybut != nullptr)
								{
									if (wezelAtrybut->element->nazwa == n)
									{
										cout << z<<",E,"<<n<<" == "<<wezelAtrybut->element->wartosc << endl; 
										return;
									}
									wezelAtrybut = wezelAtrybut->nastepny;
								}
							}
							break;
						}
						wezelSelektor = wezelSelektor->nastepny;
					}
				}
			}
			wezel = wezel->poprzedni;
		}
	}
};

void czytajSelektor(char c, Selektor& selektor, bool& czyKoniecSelektorow) {
	selektor.nazwa.dodajLiterke(c);

	while (true)
	{
		cin.get(c);
		if (c == '\n' || c == '{')
		{
			czyKoniecSelektorow = true;
			return;
		}
		else if (c == ' ')
		{
			char c2;
			cin.get(c2);
			if (c2 == '{' || c2 == '\n')
			{
				if (c2 == '\n')
				{
					cin >> c2;
				}
				czyKoniecSelektorow = true;
				return;
			}
			else
			{
				selektor.nazwa.dodajLiterke(c);
				selektor.nazwa.dodajLiterke(c2);
			}
		}
		else if (c == ',')
		{
			czyKoniecSelektorow = false;
			return;
		}
		else
		{
			selektor.nazwa.dodajLiterke(c);
		}
	}
}

void czytajListeSelektorow(char& c, ListaSelektorow& listaSelektorow) {

	bool czyKoniecListySelektorow = false;

	while (czyKoniecListySelektorow == false)
	{
		Selektor* selektor = new Selektor;
		
		czytajSelektor(c, *selektor, czyKoniecListySelektorow);
		
		listaSelektorow.dodajElement(selektor);
		cin >> c;
	}
}

void czytajAtrybut(char& c, Atrybut& atrybut) {
	atrybut.nazwa.dodajLiterke(c);

	while (c != ':')
	{
		cin >> c;
		if (c != ':')
		{
			atrybut.nazwa.dodajLiterke(c);
		}
	}

	cin >> c;
	atrybut.wartosc.dodajLiterke(c);

	while (c != ';')
	{
		cin.get(c);
		if (c != ';' && c!='}')
		{
			atrybut.wartosc.dodajLiterke(c);
		}
	}
}

void czytajListeAtrybutow(char& c, ListaAtrybutow& listaAtrybutow)
{
	if (c == '{')
	{
		cin >> c;
	}

	while (true)
	{
		bool czyDodacAtrybut = true;
		Atrybut* atrybut = new Atrybut;
		czytajAtrybut(c, *atrybut);
		cin >> c;
		WezelAtrybut* wezelAtrybut = listaAtrybutow.head;
		while (wezelAtrybut != nullptr)
		{
			if (wezelAtrybut->element->nazwa == atrybut->nazwa)
			{
				czyDodacAtrybut = false;
				wezelAtrybut->element->wartosc = atrybut->wartosc;
				break;
			}
			wezelAtrybut = wezelAtrybut->nastepny;
		}
		if (czyDodacAtrybut)
		{
			listaAtrybutow.dodajElement(atrybut);
		}		
		if (c == '}')
		{
			break;
		}
	}
}

void czytajSekcje(char c, ListaSekcji& listaSekcji) {

	Sekcja* sekcja = new Sekcja;
	listaSekcji.dodajElementNaKoniec(sekcja);
	if (c == '{')
	{
		czytajListeAtrybutow(c, sekcja->atrybuty);
		return;
	}
	czytajListeSelektorow(c, sekcja->selektory);
	czytajListeAtrybutow(c, sekcja->atrybuty);

}

void parsowanieKomend(char& c, ListaSekcji& listaSekcji)
{
	if (c == '?')
	{
		listaSekcji.wypiszLiczbeSekcji();
		return;
	}
	else if (c >= '0' && c <= '9')
	{
		String liczba;
		liczba.dodajLiterke(c);
		cin >> c;
		while (c != ',')
		{
			liczba.dodajLiterke(c);
			cin >> c;
		}
		int numerSekcji = liczba.toInt();
		cin >> c;
		if (c == 'A')
		{
			cin >> c;
			cin >> c;
			if (c == '?')
			{
				listaSekcji.wypiszLiczbeAtrybutowDlaSekcjiNri(numerSekcji);
				return;
			}
			else
			{
				String nazwaAtrybutu;
				nazwaAtrybutu.dodajLiterke(c);
				cin.get(c);
				while (c != '\n')
				{
					nazwaAtrybutu.dodajLiterke(c);
					cin.get(c);
				}
				listaSekcji.wypiszDlaItejSekcjiWartoscAtrybutuN(numerSekcji, nazwaAtrybutu);
				return;
			}
		}
		else if (c == 'S')
		{
			cin >> c;
			cin >> c;
			if (c == '?')
			{
				listaSekcji.wypiszLiczbeSelektorowDlaSekcjiNri(numerSekcji);
				return;
			}
			else
			{
				String jString;
				jString.dodajLiterke(c);
				cin.get(c);
				while (c != ' ' && c != '\n')
				{
					jString.dodajLiterke(c);
					cin.get(c);
				}
				int j = jString.toInt();
				listaSekcji.wypiszJtySelektorDlaItegoBloku(numerSekcji, j);
				return;
			}
		}
		else //D
		{
			cin >> c;
			cin >> c;
			if (c == '*')
			{
				listaSekcji.usunSekcjeNrI(numerSekcji);
				return;
			}
			else
			{
				String nazwaAtrybutu;
				nazwaAtrybutu.dodajLiterke(c);
				cin.get(c);
				while (c != '\n' && c != ' ')
				{
					nazwaAtrybutu.dodajLiterke(c);
					cin.get(c);
				}
				listaSekcji.usunAtrybutNZSekcjiI(numerSekcji, nazwaAtrybutu);
				return;
			}
		}
	}
	else //nazwy
	{
		String nazwa;
		nazwa.dodajLiterke(c);
		cin.get(c);
		while (c != ',')
		{
			nazwa.dodajLiterke(c);
			cin.get(c);
		}
		cin >> c;
		if (c == 'A')
		{
			cin >> c; //,
			cin >> c; //?
			listaSekcji.wypiszLiczbeWystapienAtrybutuN(nazwa);
			return;
		}
		else if (c == 'S')
		{
			cin >> c; //,
			cin >> c; //?
			listaSekcji.wypiszLiczbeWystapienSelektoraZ(nazwa);
			return;
		}
		else //E
		{
			cin >> c; //,
			cin >> c;
			String nazwaAtrybutu;
			while (c != '\n')
			{
				nazwaAtrybutu.dodajLiterke(c);
				cin.get(c);
			}
			listaSekcji.wypiszWartoscAtrybutuNDlaSelektoraZ(nazwaAtrybutu, nazwa);
			return;
		}
	}
}

void wczytajInput()
{
	ListaSekcji lista;
	char c;

	bool czyCzytamySekcjeCSS = true;
	while (cin.get(c))
	{
		if (c <= ' ')
		{
			continue;
		}
		if (c == '?')
		{
			if (czyCzytamySekcjeCSS == true)
			{
				cin >> c;
				cin >> c;
				cin >> c; // ???
				czyCzytamySekcjeCSS = false;
				continue;
			}
		}
		if (c == '*')
		{
			if (czyCzytamySekcjeCSS == false)
			{
				cin >> c;
				cin >> c;
				cin >> c; //*
				czyCzytamySekcjeCSS = true;
				continue;
			}
		}
		if (czyCzytamySekcjeCSS)
		{
			czytajSekcje(c, lista);
		}
		else
		{
			parsowanieKomend(c, lista);
		}
	}
}

int main()
{
	wczytajInput();

	return 0;
}