#pragma once
#include "string.h"

namespace css {

struct Attribute
{
  public:
    String name;
    String value;
};

}
