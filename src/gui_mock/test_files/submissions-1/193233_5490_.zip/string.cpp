#include "string.h"
using namespace std;

String::String(const char* s) {
	this->setString(s);
}
void String::clear() const {
	delete[] str;
}
String::String() {
	this->setString("\0");
}
void String::setString(const char* s) {
	int l = 0;
	while (s[l] != '\0' && s[l] != '\n') l++;
		length = l;
		int r = (l + 20) * 2;
		str = new char[r];
		for (int i = 0; i < l; i++) {
			str[i] = s[i];
		}
		str[l] = '\0';
}
int String::getLength() const {
	return length;
}
char String::getType() const {
	return type;
}
char String::checkType() {
	if (str[0] > 47 && str[0] < 58) {
		type = NUMBER;
		return NUMBER;
	}
	else if (str[0] == '?') {
		type = QUESTION;
		return QUESTION;
	}
	else {
		type = WORD;
		return WORD;
	}
}
int String::toInt() const {
	int integer = 0;
	for (int i = 0; i < length; i++) {
		integer = integer * 10 + (this->str[i] - '0');
	}
	return integer;
}
String* String::splitAtComma() {
	String string[3];
	int sNum = 0;
	for (int i = 0, j = 0; i < length; i++, j++) {
		if (str[i] == ',') {
			sNum++;
			j = -1;
		}
		else {
			if (sNum > 2) {
				return 0;
			}
			else {
				string[sNum].str[j] = str[i];
				string[sNum].length++;
			}
		}
	}
	if (sNum < 2) return 0;
	return string;
}

char String::operator[](int index) const {
	return this->str[index];
}
int String::operator!=(String right) const {
	if (length != right.length) return 1;
	for (int i = 0; i < length; i++) {
		if (this->str[i] != right[i]) {
			return 1;
		}
	}
	return 0;
}

int String::operator==(String right) const {
	if (*this != right) return 0;
	return 1;
}
ostream& operator<<(ostream& ostr, const String& s) {
	for (int i = 0; i < s.length && s.str[i] != '\0'; i++) {
		ostr << s.str[i];
	}
	return ostr;
}
istream& operator>>(istream& istr, String& s) {
	char c, a[300] = "";
	static bool val = 0, atr = 0, commandSection = 0;
	int com = 0, l = 0;
	if (commandSection) {
		int switchMode = 0;
		while (c = getchar()) {
			if (c == EOF) {
				s.eof = 1;
				if (a[0] != '\0') s.setString(a);
				s.length = l;
				if (s.str[0] == '?' && s.length == 1) {
					s.type = QUESTION;
				}
				return istr;
			}
			else if (c == 10) {
				if (a[0] != '\0') s.setString(a);
				s.length = l;
				if (switchMode == 4) commandSection = 0;
				if (s.str[0] == '?' && s.length == 1) {
					s.type = QUESTION;
				}
				return istr;
			}
			else {
				if (c == '*') {
					switchMode++;
				}
				a[l] = c;
				l++;
			}
		}
		return istr;
	}
	else {
		while (c = getchar()) {
			if (c == EOF) {
				s.eof = 1;
				if (a[0] != '\0') s.setString(a);
				return istr;
			}
			else if (c == ':' && atr == 1) {
				val = 1;
				s.type = 'a';
				if (a[0] != '\0') s.setString(a);
				return istr;
			}
			else if (c == '}') {
				atr = 0;
				val = 0;
				s.type = 'e';
				if (a[0] != '\0') s.setString(a);
				return istr;
			}
			else if ((c == ',' || c == '{' || c == '}') && val == 0 && l > 0) {
				if (c == '{') atr = 1;
				int i = 1;
				while (a[l - i] < 33) {
					a[l - i] = '\0';
					i++;
				}
				s.type = 's';
				if (a[0] != '\0') s.setString(a);
				return istr;
			}
			else if (c == '{') {
				atr = 1;
			}
			else if (val == 1 && c == ' ' && l > 0) {
				a[l] = c;
				l++;
			}
			else if (val == 1 && (c == ';' || c == '}')) {
				if (c == ';') {
					s.type = 'v';
				}
				val = 0;
				if (a[0] != '\0') s.setString(a);
				return istr;
			}
			else if (c > 32 && c != 133 && c != '{' && c != '}' && c != ';') {
				if (c == '?') {
					com += 1;
				}
				else {
					com = 0;
				}
				a[l] = c;
				l++;
				if (com == 4) {
					com = 0;
					s.type = 'c';
					commandSection = 1;
					if (a[0] != '\0') s.setString(a);
					return istr;
				}
			}
			else if (c == 32 && atr == 0 && l > 0) {
				a[l] = c;
				l++;
			}
		}
		return istr;
	}
}