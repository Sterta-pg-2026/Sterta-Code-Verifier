#include "elementnode.h"
String ElementNode::getName() const {
	if (this != nullptr) {
		return name;
	}
	else {
		return "";
	}
}
String ElementNode::getValue() const {
	if (this != nullptr) {
		return value;
	}
	else {
		return "";
	}
}
void ElementNode::setValue(const String& value) {
	this->value = value;
}
ElementNode* ElementNode::find(const String& name) {
	ElementNode* currentNode = this->last();
	while (currentNode != nullptr) {
		if (currentNode->getName() == name) {
			return currentNode;
		}
		currentNode = currentNode->prev;
	}
	return 0;
}
int ElementNode::elementCount() {
	int count = 0;
	if (this != nullptr && this->next != nullptr) {
		ElementNode* currentNode = this->next;
		while (currentNode != nullptr) {
			currentNode = currentNode->next;
			count++;
		}
	}
	return count;
}
int ElementNode::howMany(const String& name) {
	int count = 0;
	if (this != nullptr) {
		ElementNode* currentNode = this->next;
		while (currentNode != nullptr) {
			if (currentNode->getName() == name) {
				count++;
			}
			currentNode = currentNode->next;
		}
	}
	return count;
}
ElementNode* ElementNode::last() {
	ElementNode* currentNode = this;
	if (this != nullptr) {
		while (currentNode->next != nullptr) {
			currentNode = currentNode->next;
		}
	}
	return currentNode;
}
ElementNode* ElementNode::add(const String& name, const String& value) {
	this->removeRepeated(name);
	ElementNode* newNode = new ElementNode(name, value);
	newNode->prev = this->last();
	this->last()->next = newNode;
	return newNode;
}
ElementNode* ElementNode::add(const String& name) {
	this->removeRepeated(name);
	ElementNode* newNode = new ElementNode(name);
	newNode->prev = this->last();
	this->last()->next = newNode;
	return newNode;
}
void ElementNode::removeRepeated(const String& name) {
	ElementNode* currentNode = this->next;
	while (currentNode != nullptr) {
		if (currentNode->name == name) {
			currentNode->remove();
			return;
		}
		currentNode = currentNode->next;
	}
}
void ElementNode::remove() {
	if (prev == nullptr) {
		name = next->name;
		value = next->value;
		next = next->next;
		prev = nullptr;
	}
	else {
		if (next != nullptr) next->prev = prev;
		prev->next = next;
	}
	delete this;
}
void ElementNode::show() const {
	ElementNode* currentNode = this->next;
	while (currentNode != nullptr) {
		cout << currentNode->getName();
		if (currentNode->getValue() != "") cout << ": " << currentNode->getValue();
		cout << endl;
		currentNode = currentNode->next;
	}
}
ElementNode* ElementNode::getElement(int index) {
	if (this != nullptr) {
		ElementNode* currentNode = this->next;
		for (int i = 0; i < index && currentNode != nullptr; i++) {
			currentNode = currentNode->next;
		}
		return currentNode;
	}
	return nullptr;
}

ElementNode* ElementNode::operator[](int index) {
	ElementNode* currentNode = this;
	for (int i = 0; i < index && currentNode != nullptr; i++) {
		currentNode = currentNode->next;
	}
	return currentNode;
}