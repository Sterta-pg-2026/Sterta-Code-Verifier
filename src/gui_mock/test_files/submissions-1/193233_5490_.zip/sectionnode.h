#include "elementnode.h"
#define SECTION_NUM 29
struct Section {
	ElementNode* selNode = nullptr;
	ElementNode* atrNode = nullptr;
};
class SectionNode {
	struct Section sectionT[SECTION_NUM];
	int count = 0;
public:
	SectionNode* next = nullptr;
	SectionNode* prev = nullptr;

	SectionNode* addNew(ElementNode* selectors, ElementNode* attributes);
	SectionNode(ElementNode* selectors, ElementNode* attributes);
	void add(ElementNode* selectors, ElementNode* attributes);
	SectionNode();
	SectionNode* last();
	int getSectionNumber();
	void decrementCount();
	Section* getSection(int index);
	SectionNode* getSectionBlock(int index);
	SectionNode* getSectionBlock(String attribute);
	ElementNode* findValue(String selector, String attribute);
	int howMany(String name, char x);
	void remove();
	bool removeSection(int index);
	void show();
	void show(int index);

	SectionNode* operator[](int index);

	~SectionNode() {}
};

