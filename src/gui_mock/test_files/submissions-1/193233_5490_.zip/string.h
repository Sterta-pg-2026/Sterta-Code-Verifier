#pragma once
#include <iostream>
using namespace std;
#define NUMBER		'n'
#define QUESTION	'q'
#define WORD		'w'

class String {
	char* str = nullptr;
	int length;
	char type = '\0';
public:
	bool eof = 0;
	String(const char* s);
	String();
	void clear() const;
	void setString(const char *s);
	int getLength() const;
	char getType() const;
	char checkType();
	int toInt() const;
	String* splitAtComma();

	char operator[](int index) const;
	int operator!=(String right) const;
	int operator==(String right) const;
	friend istream& operator>>(istream& istr, String& s);
	friend ostream& operator<<(ostream& ostr, const String& str);

	~String() {}
};