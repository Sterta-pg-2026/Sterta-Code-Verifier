#include "string.h"
#include "sectionnode.h"
#include "elementnode.h"

#define COMMAND			1
using namespace std;
bool readCommands(SectionNode* firstSection) {
	String action = "";
	String actionTable[3];
	Section* section = nullptr;
	while (action != "****" && !action.eof) {
		cin >> action;
		if (action.getLength() > 0) {
			if (action.checkType() == QUESTION) {
				cout << action << " == " << firstSection->getSectionNumber() << endl;
			}
			else {
				String* T = action.splitAtComma();
				if (T) {
					for (int i = 0; i < 3; i++) {
						actionTable[i] = T[i];
					}
					char type1, type2;
					type1 = actionTable[0].checkType();
					type2 = actionTable[2].checkType();
					switch (type1) {
					case NUMBER:
						section = firstSection->getSection(actionTable[0].toInt());
						if (section != nullptr) {
							switch (actionTable[COMMAND][0]) {
							case 'A':
								if (type2 == QUESTION) {
									if (section->atrNode != nullptr) {
										cout << action << " == " << section->atrNode->elementCount() << endl;
									}
								}
								else if (type2 == WORD) {
									ElementNode* el = section->atrNode->find(actionTable[2]);
									if (el->getValue() != "") {
										cout << action << " == " << el->getValue() << endl;
									}
								}
								break;

							case 'S':
								if (type2 == QUESTION) {
									if (section->selNode != nullptr) {
										cout << action << " == " << section->selNode->elementCount() << endl;
									}
								}
								else if (type2 == NUMBER) {
									ElementNode* sel = section->selNode->getElement(actionTable[2].toInt() - 1);
									if (sel->getName() != "") {
										cout << action << " == " << sel->getName() << endl;
									}
								}
								break;

							case 'D':
								if (actionTable[2] == "*") {
									if (firstSection->removeSection(actionTable[0].toInt())) {
										cout << action << " == " << "deleted" << endl;
									}
								}
								else if (type2 == WORD) {
									ElementNode* fSec = section->atrNode->find(actionTable[2]);
									if (fSec != nullptr) {
										SectionNode* sec = firstSection->getSectionBlock(actionTable[2]);
										fSec->remove();
										if (section->atrNode->next == nullptr) {
											section->selNode->next = nullptr;
											sec->decrementCount();
										}
										cout << action << " == " << "deleted" << endl;
									}
								}
								break;

							}
						}
						break;
					case WORD:
						if (actionTable[COMMAND][0] == 'S' || actionTable[COMMAND][0] == 'A') {
							if (type2 == QUESTION) {
								cout << action << " == " << firstSection->howMany(actionTable[0], actionTable[COMMAND][0]) << endl;
							}
						}
						else if (actionTable[COMMAND][0] == 'E') {
							if (firstSection->findValue(actionTable[0], actionTable[2])->getValue() != "") {
								cout << action << " == " << firstSection->findValue(actionTable[0], actionTable[2])->getValue() << endl;
							}
						}
						break;
					}
				}
				else {
					if (action[0] == 'S') {
						int ind;
						cout << "Section to show:";
						cin >> ind;
						firstSection->show(ind);
					}
				}
			}
		}
		if (action.eof && action != "****" && !action.eof) {
			action.clear();
		}
	}
	if (action.eof) {
		return 0;
	}
	else {
		return 1;
	}
}
bool readCSS(SectionNode* firstSection) {
	String css = "\0";
	ElementNode* newSelNode = new ElementNode();
	ElementNode* newAtrNode = new ElementNode();
	while (css != "????" && !css.eof) {
		cin >> css;
		if (css.getLength() > 0) {
			switch (css.getType()) {
			case 's':
				newSelNode->add(css);
				break;
			case 'a':
				newAtrNode->add(css);
				break;
			case 'v':
				newAtrNode->last()->setValue(css);
				break;
			case 'e':
				if (newAtrNode->last()->getValue() == "") {
					newAtrNode->last()->setValue(css);
				}
				firstSection->add(newSelNode, newAtrNode);
				newSelNode = new ElementNode();
				newAtrNode = new ElementNode();
				break;
			}
		}
		if (css.eof && css != "????" && !css.eof) {
			css.clear();
		}
	}
	if (css.eof) {
		return 0;
	}
	return 1;
}
int main() {
	bool end = 1;
	SectionNode* firstSection = new SectionNode();
	while (end != 0) {

		end = readCSS(firstSection);
		if (end) {
			end = readCommands(firstSection);
		}
	}		
	delete firstSection;
	return 0;
}