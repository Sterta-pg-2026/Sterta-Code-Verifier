#pragma once
#include "string.h"
class ElementNode {
	String name;
	String value;
public:
	ElementNode* next = nullptr;
	ElementNode* prev = nullptr;

	ElementNode(const String& name, const String& value) : name(name), value(value) {}
	ElementNode(const String& name) : name(name), value("") {}
	ElementNode() : name(""), value("") {}
	String getName() const;
	String getValue() const;
	void setValue(const String& value);
	int howMany(const String& name);
	int elementCount();
	void removeRepeated(const String& name);
	ElementNode* find(const String& name);
	ElementNode* last();
	ElementNode* add(const String& name, const String& value);
	ElementNode* add(const String& name);
	void remove();
	void show() const;
	ElementNode* getElement(int index);

	ElementNode* operator[](int index);

	~ElementNode() {}
};							