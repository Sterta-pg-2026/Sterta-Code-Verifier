#include "sectionnode.h"
SectionNode::SectionNode(ElementNode* selectors, ElementNode* attributes) {
	sectionT[0].selNode = selectors;
	sectionT[0].atrNode = attributes;
	count = 1;
}
void SectionNode::add(ElementNode* selectors, ElementNode* attributes) {
	if (this->last()->count < SECTION_NUM) {
		this->last()->sectionT[this->last()->count].selNode = selectors;
		this->last()->sectionT[this->last()->count].atrNode = attributes;
		this->last()->count++;
	}
	else {
		this->addNew(selectors, attributes);
	}
}
SectionNode* SectionNode::addNew(ElementNode* selectors, ElementNode* attributes) {
	SectionNode* newNode = new SectionNode(selectors, attributes);
	newNode->prev = this->last();
	this->last()->next = newNode;
	newNode->count = 1;
	return newNode;
}
SectionNode* SectionNode::operator[](int index) {
	SectionNode* currentNode = this;
	for (int i = 0; i <= index && currentNode != nullptr; i++) {
		currentNode = currentNode->next;
	}
	return currentNode;
}
SectionNode::SectionNode() {
	next = nullptr;
	prev = nullptr;
	count = SECTION_NUM;
}
int SectionNode::howMany(String name, char x) {
	int counter = 0;
	SectionNode* currentNode = this;
	while (currentNode->next != nullptr) {
		currentNode = currentNode->next;
		if (x == 'S') {
			for (int i = 0; i < SECTION_NUM; i++) {
				counter += currentNode->sectionT[i].selNode->howMany(name);
			}
		}
		else {
			for (int i = 0; i < SECTION_NUM; i++) {
				counter += currentNode->sectionT[i].atrNode->howMany(name);
			}
		}
	}
	return counter;
}
ElementNode* SectionNode::findValue(String selector, String attribute) {
	SectionNode* currentNode = this->last();
	while (currentNode != nullptr) {
		for (int i = SECTION_NUM - 1; i >= 0; i--) {
			if (currentNode->sectionT[i].selNode->find(selector)) {
				if (currentNode->sectionT[i].atrNode->find(attribute)) {
					return currentNode->sectionT[i].atrNode->find(attribute);
				}
			}
		}
		currentNode = currentNode->prev;
	}
	return nullptr;
}
int SectionNode::getSectionNumber() {
	int counter = 0;
	SectionNode* currentNode = this;
	while (currentNode->next != nullptr) {
		currentNode = currentNode->next;
		counter += currentNode->count;
	}
	return counter;
}
void SectionNode::decrementCount() {
	this->count--;
	if (this->count <= 0) {
		this->remove();
	}
}
Section* SectionNode::getSection(int index) {
	int indexCounter = index;
	SectionNode* currentNode = this->next;
	if (index == 1) {
		for (int i = 0; i < SECTION_NUM; i++) {
			if (currentNode->sectionT[i].atrNode->next != nullptr) return &currentNode->sectionT[i];
		}
	}
	while (indexCounter > 0 && indexCounter > currentNode->count) {
		if (currentNode->next == nullptr) {
			return nullptr;
		}
		indexCounter -= currentNode->count;
		currentNode = currentNode->next;
	}
	int counted = 0, i = 0;
	while (counted < indexCounter) {
		if (currentNode->sectionT[i].atrNode->next != nullptr) {
			counted++;
		}
		i++;
	}
	return &currentNode->sectionT[i - 1];
}

bool SectionNode::removeSection(int index) {
	Section* currentSection = this->getSection(index);
	if (currentSection != nullptr) {
		if (currentSection->selNode != nullptr) {
			currentSection->selNode->next = nullptr;
		}
		currentSection->atrNode->next = nullptr;
		SectionNode* currentNode = this->getSectionBlock(index);
		currentNode->count--;
		if (currentNode->count <= 0) {
			currentNode->remove();
		}
		return 1;
	}
	else {
		return 0;
	}
}
SectionNode* SectionNode::getSectionBlock(int index) {
	int indexCounter = index;
	SectionNode* currentNode = this->next;
	while (indexCounter > 0) {
		if (indexCounter > currentNode->count) {
			if (currentNode->next == nullptr) {
				return nullptr;
			}
			indexCounter -= currentNode->count;
			currentNode = currentNode->next;
		}
		else {
			break;
		}
	}
	return currentNode;
}
SectionNode* SectionNode::getSectionBlock(String attribute) {
	SectionNode* currentNode = this->last();
	while (currentNode != nullptr) {
		for (int i = SECTION_NUM - 1; i >= 0; i--) {
			if (currentNode->sectionT[i].atrNode->find(attribute)) {
				return currentNode;
			}
		}
		currentNode = currentNode->prev;
	}
	return currentNode;
}
SectionNode* SectionNode::last() {
	SectionNode* currentNode = this;
	while (currentNode->next != nullptr) {
		currentNode = currentNode->next;
	}
	return currentNode;
}
void SectionNode::remove() {
	if (next != nullptr) next->prev = prev;
	prev->next = next;
	delete this;
}
void SectionNode::show() {
	SectionNode* currentNode = this->next;
	while (currentNode != nullptr) {
		for (int i = 0; i < SECTION_NUM; i++) {
			if (currentNode->sectionT[i].atrNode != nullptr) {
				currentNode->sectionT[i].selNode->show();
				currentNode->sectionT[i].atrNode->show();
				cout << endl;
			}
		}
		currentNode = currentNode->next;
	}
}
void SectionNode::show(int index) {
	Section* currentNode = this->getSection(index);
	currentNode->selNode->show();
	currentNode->atrNode->show();
	cout << endl;
}