#include <iostream>

using namespace std;

const int BUFOR_CHAR = 1000;
const int ATTR_SEL_CHAR = 300;
const int T = 29;

int BlockIndex = 0;

struct SelectorNode
{
    char *selector;
    SelectorNode* next;
    SelectorNode* prev;
};

struct AttributeNode
{
    char *name;
    char *volue;
    AttributeNode* next;
    AttributeNode* prev;
};

class SelectorsList
{
private:
    int counter;
    SelectorNode *front, *back;
public:
    SelectorsList()
    {
        front = NULL;
        back = NULL;
        counter = 0;
    }

    ~SelectorsList()
    {
        SelectorNode *tmp;
        if (front)
        {
            tmp = front;
            while (tmp)
            {
                front = tmp->next;
                delete tmp->selector;
                delete tmp;
                tmp = front;
            }
        }
        counter = 0;
    }

    void DeleteList()
    {
        SelectorNode *tmp = front;
        while (tmp)
        {
            front = tmp->next;
            delete tmp->selector;
            delete tmp;
            tmp = front;
        }
        front = NULL;
        back = NULL;
        counter = 0;
    }

    unsigned int size()
    {
        return counter;
    }

    void ChangeCounter(int i)
    {
        counter += i;
    }

    SelectorNode *First()
    {
        return front;
    }

    SelectorNode *Last()
    {
        return back;
    }

    void addBack(SelectorNode *a)
    {
        a->prev = back;
        a->next = NULL;
        if(back) back->next = a;
        back = a;
        if(!front) front = a;
        counter++;
    }

    void Showlist()
    {
        int i = 0;
        SelectorNode *tmp = front;
        while (tmp)
        {
            cout << i << ". " << tmp->selector << ";\n";
            tmp = tmp->next;
            i++;
        }
    }
};

class AttributesList
{
private:
    int counter;
    AttributeNode *front, *back;
public:
    AttributesList()
    {
        front = NULL;
        back = NULL;
        counter = 0;
    }

    ~AttributesList()
    {
        AttributeNode *tmp;
        if (front)
        {
            tmp = front;
            while (tmp)
            {
                front = tmp->next;
                delete tmp->name;
                delete tmp->volue;
                delete tmp;
                tmp = front;
            }
        }
        counter = 0;
    }

    void ChangeCounter(int i)
    {
        counter += i;
    }

    void DeleteList()
    {
        counter = 0;
        AttributeNode *tmp = front;
        while (tmp)
        {
            front = tmp->next;
            delete tmp->name;
            delete tmp->volue;
            delete tmp;
            tmp = front;
        }
        front = NULL;
        back = NULL;
    }

    int size()
    {
        return counter;
    }

    AttributeNode *Last()
    {
        return back;
    }

    void addBack(AttributeNode *a)
    {
        a->prev = back;
        a->next = NULL;
        if(back) back->next = a;
        back = a;
        if(!front) front = a;
        counter++;
    }

    void Showlist()
    {
        int i = 0;
        AttributeNode *tmp = front;
        while (tmp)
        {
            cout << i << ". " << tmp->name << ":" << tmp->volue << ";\n";
            tmp = tmp->next;
            i++;
        }
    }
};

struct SegmentBlock
{
    AttributesList Attributes_list;
    SelectorsList Selectors_list;
};

struct Node
{
    unsigned int BlockCounter;
    SegmentBlock block[T];
    Node* next;
    Node* prev;
};

Node *LastNodeToSave;

Node *CreateNewNode()
{
    Node *tmp;
    tmp = new Node;
    tmp->BlockCounter = 0;
    tmp->prev = NULL;
    tmp->next = NULL;
    return tmp;
}

class List
{
private:
    int counter;
    Node *front, *back;
public:

    List()
    {
        front = NULL;
        back = NULL;
        counter = 0;
    }

    ~List()
    {
        Node *tmp = front;
        while (tmp)
        {
            for (int i = 0; i < T; i++)
            {
                if (tmp->block[i].Attributes_list.size()) tmp->block[i].Attributes_list.~AttributesList();
                if (tmp->block[i].Selectors_list.size()) tmp->block[i].Selectors_list.~SelectorsList();
            }
            tmp = tmp->next;
            delete front;
            front = tmp;
        }
    } 

    Node *Last()
    {
        return back;
    }

    unsigned int size()
    {
        return counter;
    }

    void addFront(Node *a)
    {
        a->next = front;
        a->prev = NULL;
        if (front) front->prev = a;
        front = a;
        if (!back) back = a;
        counter++;
    }

    void addBack(Node *a)
    {
        if(back) back->next = a;
        a->prev = back;
        a->next = NULL;
        back = a;
        if(!front) front = back;
        counter++;
    }

    void DeleteNode(Node * tmp)
    {
        if(tmp->next) tmp->next->prev = tmp->prev;
        else back = tmp->prev;
        if(tmp->prev) tmp->prev->next = tmp->next;
        else front = tmp->next;
        counter--;
        delete tmp;
    }

    int deleteSection(int Section, char* comend)
    {
        Node *tmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0;
        while (i + tmp->BlockCounter < Section) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = Section - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;
        tmp->block[BlockIndex1].Attributes_list.DeleteList();
        tmp->block[BlockIndex1].Selectors_list.DeleteList();
        if (tmp->BlockCounter == 1) DeleteNode(tmp);
        else tmp->BlockCounter--;
        cout << comend << " == deleted" << endl;
        return 0;
    }

    int deleteAtrribute(int Section, char* AttributeName, char* comend)
    {
        char *newChar;
        char newChar1[8] = "deleted";
        Node *tmp;
        AttributeNode *AttrTmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0, z = 0;

        while (i + tmp->BlockCounter < Section) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = Section - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;

        AttrTmp = tmp->block[BlockIndex1].Attributes_list.Last();
        while (AttrTmp)
        {
            if (strcmp(AttributeName,AttrTmp->name) == 0) 
            {
                if (strcmp(newChar1,AttrTmp->volue) == 0) return 1;
                else if (tmp->block[BlockIndex1].Attributes_list.size() == 1) 
                {
                    tmp->block[BlockIndex1].Attributes_list.DeleteList();
                    tmp->block[BlockIndex1].Selectors_list.DeleteList();
                    tmp->BlockCounter--;
                    cout << comend << " == deleted" << endl;
                    return 0;
                }
                else
                {
                    newChar = new char[8];
                    strcpy(newChar,newChar1);
                    delete AttrTmp->volue;
                    AttrTmp->volue = newChar;
                    tmp->block[BlockIndex1].Attributes_list.ChangeCounter(-1);
                    cout << comend << " == deleted" << endl;
                    return 0;
                }
            }
            AttrTmp = AttrTmp->prev;
        }
        return 1;
    }

    void ShowList()
    {
        Node *n = front;
        for (int i = 0; i < counter; i++)
        {
            for (int x = 0; x < T; x++)
            {
                cout << "Node " << i << ".   " << x << endl;
                n->block[x].Selectors_list.Showlist();
                cout << endl;
                n->block[x].Attributes_list.Showlist();
                cout << "---" << endl;
            }
            n = n->next;
        } 
    }

    int BlocksNumber ()
    {
        int number = 0;
        Node *tmp = front;
        while (tmp)
        {
            number += tmp->BlockCounter;
            tmp = tmp->next;
        }
        return number;
    }

    int NumberOfSelectorsInSection(int Section, char *comend)
    {
        Node *tmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0;

        while (i + tmp->BlockCounter < Section) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = Section - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;

        cout << comend << " == " << tmp->block[BlockIndex1].Selectors_list.size() << endl;
        return 0;
    }
    
    int SelectorNameInSection(int Section, int Selector, char *comend)
    {
        Node *tmp;
        SelectorNode *SelTmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0;

        while (i + tmp->BlockCounter < Section) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = Section - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;

        if (Selector <= tmp->block[BlockIndex1].Selectors_list.size())
        {
            SelTmp = tmp->block[BlockIndex1].Selectors_list.First();
            for (int y = 1; y < Selector; y++)
            {
                SelTmp = SelTmp->next;
            }
            cout << comend << " == " << SelTmp->selector << endl;
        }
        return 0;
    }

    int SelectorAppearanceCounter(char *SelectorName)
    {
        int result = 0;
        Node *NodeTmp;
        SelectorNode *SelTmp;
        NodeTmp = front;
        for (int i = 0; i < counter; i++)
        {
            for (int y = 0; y < T ; y++)
            {
                SelTmp = NodeTmp->block[y].Selectors_list.First();
                while (SelTmp)
                {
                    if (strcmp(SelTmp->selector,SelectorName) == 0)
                    {
                        result++;
                        break;
                    }
                    SelTmp = SelTmp->next;
                }
            }  
            NodeTmp = NodeTmp->next;
        } 
        return result;
    }

    int NumberOfAttributesInSection(int Section, char *comend)
    {
        Node *tmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0;

        while (i + tmp->BlockCounter < Section) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = Section - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;

        cout << comend << " == " << tmp->block[BlockIndex1].Attributes_list.size() << endl;
        return 0;
    }
    
    int AttributeNameInSection(int SectionNumber, char *AttributeName, char *comend)
    {
        Node *tmp;
        AttributeNode *AttrTmp;
        tmp = front;
        int i = 0, BlockIndex1 = 0;

        while (i + tmp->BlockCounter < SectionNumber) 
        {
            i += tmp->BlockCounter;
            if(tmp->next) tmp = tmp->next;
            else return 1;
        }
        i = SectionNumber - i;
        while (i != 0)
        {
            if (tmp->block[BlockIndex1].Attributes_list.size() != 0) i--;
            BlockIndex1++;
        }
        BlockIndex1--;

        AttrTmp = tmp->block[BlockIndex1].Attributes_list.Last();
        while (AttrTmp)
        {
            if (strcmp(AttributeName,AttrTmp->name) == 0) 
            {
                cout << comend << " == " << AttrTmp->volue << endl;
                return 0;
            }
            AttrTmp = AttrTmp->prev;
        }
        return 1;
    }

    int AttributeAppearanceCounter(char *AttributeName)
    {
        int result = 0;
        char deleteChar[8] = "deleted";
        Node *NodeTmp;
        AttributeNode *AttrTmp;
        NodeTmp = front;
        while (NodeTmp)
        {
            for (int y = 0; y < T ; y++)
            {
                AttrTmp = NodeTmp->block[y].Attributes_list.Last();
                if (NodeTmp->block[y].Attributes_list.size())
                {
                    while (AttrTmp)
                    {
                        if (strcmp(AttrTmp->name,AttributeName) == 0)
                        {
                            if (strcmp(AttrTmp->volue,deleteChar) != 0) result++;
                            break;
                        }
                        AttrTmp = AttrTmp->prev;
                    }
                }
            }  
            NodeTmp = NodeTmp->next;
        } 
        return result;
    }

    int LastAttributeAppearance(char *SelectorName, char *AttributeName, char *comend)
    {
        int result = 0, i = T - 1;
        char deleteChar[8] = "deleted";
        Node *tmp;
        SelectorNode *SelTmp;
        AttributeNode *AttrTmp;
        tmp = back;
        while (tmp)
        {
            for (i = T - 1; i > -1; i--)
            {
                SelTmp = tmp->block[i].Selectors_list.Last();
                while (SelTmp)
                {
                    if (strcmp(SelTmp->selector,SelectorName) == 0) 
                    {
                        AttrTmp = tmp->block[i].Attributes_list.Last();
                        while (AttrTmp)
                        {
                            if (strcmp(AttrTmp->name,AttributeName) == 0 && strcmp(AttrTmp->volue,deleteChar) != 0) 
                            {
                                cout << comend << " == " << AttrTmp->volue << endl;
                                return 0;
                            }
                            AttrTmp = AttrTmp->prev;
                        }
                    }       
                    SelTmp = SelTmp->prev;
                }                
            }
            tmp = tmp->prev;
        }
        return 1;
    }
};

void GetAttributesNames(char *s, AttributesList *list)
{
    int i = 0, y = 0, x = 0;
    char *ctmp;
    char cName[300], cValue[300];
    AttributeNode *tmp, *tmp1;
    while (true)
    {
        while (s[i] < 33) i++;
        while (s[i] != ':')
        {
            cName[y] = s[i];
            i++;
            y++; 
        }
        cName[y] = '\0';
        tmp1 = list->Last();
        if (tmp1)
        {
            tmp1 = tmp1->prev;
            while (tmp1)
            {
                if (strcmp(cName,tmp1->name) == 0)
                {
                    list->ChangeCounter(-1);
                    break;
                } 
                tmp1 = tmp1->prev;
            }
        }
        ctmp = new char[y + 1];
        strcpy(ctmp,cName);
        tmp = new AttributeNode;
        tmp->name = ctmp;
        y = 0;
        i++;
        if (s[i] == 32) i++;
        while (s[i] != ';' && s[i] != '}')
        {
            cValue[y] = s[i];
            i++;
            y++; 
        }
        ctmp = new char[y + 1];
        cValue[y] = '\0';
        strcpy(ctmp,cValue);
        tmp->volue = ctmp;
        list->addBack(tmp);

        if (s[i] == '}' || s[i+1] == '}' || s[i+2] == '}'|| s[i+3] == '}') break;
        y = 0;
        i++;
        x++;
    }
}

void GetSegmentNames(char *s,SelectorsList *list)
{
    int i = 0, y = 0, n = 1;
    char c[300];
    char *ctmp;
    SelectorNode *tmp;
    SelectorNode *tmp1;   
    while (s[i] < 33) i++;
    while (true)
    {
        if (s[i] == ',') n++;
        else if (s[i] == '{') break;
        i++;
    }
    i = 0;
    for (int x = 0; x < n; x++)
    {
        if (s[i + 1] == 32 || s[i + 1] == 10) i+=2;
        y = 0;
        while (y < ATTR_SEL_CHAR)
        {
            if (s[i] == ',' || s[i] == '{' || s[i] < 32 || (s[i] == 32 && s[i+1] == '{')) break;
            c[y] = s[i];
            i++;
            y++;
        }
        c[y] = '\0';
        if (c[y - 1] == 32) c[y - 1] = '\0';
        ctmp = new char[y + 1];
        strcpy(ctmp,c);
        tmp = new SelectorNode;
        tmp->selector = ctmp;
        list->addBack(tmp);
    }
}

void GetFirstPart(char *bufor, char *FirstPart)
{
    int i = 0;
    while (bufor[i] != ',')
    {
        i++;
    }
    for (int y = 0; y < i; y++) FirstPart[y] = bufor[y];
    FirstPart[i] = '\0';  
}

void GetThirdPart(char *bufor, char *ThirdPart)
{
    int i = 0, x = 0;
    while (bufor[x] != ',') x++;
    x++;
    while (bufor[x] != ',') x++;
    x++;
    while (bufor[i + x] > 31)
    {
        i++;
    }
    for (int y = 0; y < i; y++) ThirdPart[y] = bufor[y + x];
    ThirdPart[i] = '\0';
}

void AComend(char *firstPart,char *thirdPart,List *list, char *comend)
{
    int FirstPartInt = atoi(firstPart);
    if (FirstPartInt != 0)
    {
        if (thirdPart[0] == '?') list->NumberOfAttributesInSection(FirstPartInt, comend);
        else if (atoi(thirdPart) == 0) list->AttributeNameInSection(FirstPartInt,thirdPart,comend);
    }
    else 
    {
        cout << comend << " == " << list->AttributeAppearanceCounter(firstPart) << endl;
    }
}

void SComend(char *firstPart,char *thirdPart,List *list, char *comend)
{
    int FirstPartInt = atoi(firstPart);
    if (FirstPartInt != 0)
    {
        if (thirdPart[0] == '?') list->NumberOfSelectorsInSection(FirstPartInt,comend);
        else list->SelectorNameInSection(FirstPartInt,atoi(thirdPart),comend);
    }
    else 
    {
        cout << comend << " == " << list->SelectorAppearanceCounter(firstPart) << endl;
    }
}

void DComend(char *firstPart,char *thirdPart,List *list, char *comend)
{
    if (thirdPart[0] == '*') list->deleteSection(atoi(firstPart),comend);
    else list->deleteAtrribute(atoi(firstPart),thirdPart,comend);
}

void EComend(char *firstPart,char *thirdPart,List *list, char *comend)
{
    list->LastAttributeAppearance(firstPart,thirdPart,comend);
}

void ComendController(char *bufor, List *list)
{
    char ComandType, firstPart[300], thirdPart[300];
    int i = 0;
    if (bufor[0] == '?') cout << "? == " << list->BlocksNumber() << endl;
    else if (bufor[0])
    {
        GetFirstPart(bufor,firstPart);
        GetThirdPart(bufor,thirdPart);
        while (bufor[i] != ',') i++;
        ComandType = bufor[i+1];
        switch (ComandType)
        {
        case 'A':
            AComend(firstPart,thirdPart,list,bufor);
            break;
        case 'S':
            SComend(firstPart,thirdPart,list,bufor);
            break;
        case 'D':
            if (list->size() > 0) DComend(firstPart,thirdPart,list,bufor);
            break;
        case 'E':
            EComend(firstPart,thirdPart,list,bufor);
            break;
        default:
            break;
        }
    }
}

void SectionParsing(int *quit, List *list, char *bufor)
{
    int i = 0;
    bufor[0] = 0;
    while (bufor[0] < 33 || bufor[0] == '*')
    {
        std::cin >> bufor[0];
    }

    if (bufor[0] == '?') 
    {
        std::cin >> bufor[0] >> bufor[0] >> bufor[0];
        *quit = 2;
    }
    else 
    {
        if (bufor[0] != '{')
        {
            while (bufor[i] != '{') 
            {
                std::cin >> noskipws >> bufor[i + 1];
                i++;
            }
            i = 0;
            GetSegmentNames(bufor,&LastNodeToSave->block[BlockIndex].Selectors_list);
        }
        std::cin >> bufor[0];
        while (bufor[i] != '}') 
        {
            std::cin >> noskipws >> bufor[i + 1];
            i++;
        }
        i = 0;
        GetAttributesNames(bufor,&LastNodeToSave->block[BlockIndex].Attributes_list);
        BlockIndex++;
        LastNodeToSave->BlockCounter++;
        if (BlockIndex == T)
        {
            LastNodeToSave = CreateNewNode();
            list->addBack(LastNodeToSave);
            BlockIndex = 0;
        }
    }
}

void ComendParsingController(int *quit, List *list, char *bufor)
{
    while (*quit == 2)
    {
        if (!(std::cin >> noskipws >> bufor[0])) *quit = 0;
        while (std::cin.getline(bufor, 999)) 
        {
            if (bufor[0] < 32) std::cin.getline(bufor, 999);
            if (bufor[3] == '*') 
            {
                *quit = 1;
                break;
            }
            ComendController(bufor,list); 
        }
    }
}

void Controller(int *quit, List *list)
{
    int i = 0, y = 0;
    char bufor[BUFOR_CHAR];
    if (list->size() == 0) 
    {
        LastNodeToSave = CreateNewNode();
        BlockIndex = 0;
    }
    while (*quit == 1)
    {
        SectionParsing(quit,list,bufor);
    }
    while (*quit == 2)
    {
        ComendParsingController(quit,list,bufor);
    }
}

int main() 
{
    int quit = 1, LastBlockIndex = 0;
    List *list = new List;
    Node *NodeTmp = CreateNewNode();
    LastNodeToSave = NodeTmp;
    list->addFront(NodeTmp);

    while (quit)
    {
        Controller(&quit, list);
    }

    delete list;
    return 0;
}