#include <iostream>
#include "createstring.h"
#include "defines.h"
using namespace std;

CreateString::CreateString() {
    this->s = new char[1];
    s[0] = '\0';
}

CreateString::CreateString(char* sign)
{
    if (sign == nullptr) {
        s = new char[1];
        s[0] = '\0';
    }
    else {
        int length = charsLength(sign);
        this->s = new char[length];
        for (int i = 0; i < length; i++) {
            s[i] = sign[i];
        }
    }
}

CreateString::CreateString(const CreateString& obj) 
{    
    int strLength = obj.objLength() + 1;
    if (this != &obj) {
        char* arr = new char[strLength];

        for (int i = 0; i < strLength; i++) {
            arr[i] = obj.s[i];
        }
        swap(arr, s);
    }
}

istream& operator>>(istream& istr, CreateString& obj)
{
    char* arr = new char[STRING_LONG];
    istr >> arr;
    obj = CreateString(arr);
    delete[] arr;
    return istr;
}

ostream& operator<<(ostream& ostr, const CreateString& obj)
{
    ostr << obj.s;
    return ostr;
}

CreateString& CreateString::operator=(const CreateString& obj)
{
    int strLength = obj.objLength() + 1;
    if (this != &obj) {
        char* arr = new char[strLength];
        
        for (int i = 0; i < strLength; i++) {
            arr[i] = obj.s[i];
        }
        swap(arr, s);
    }
    return *this;
}

CreateString& CreateString::operator=(const char* chars)
{
    int length = charsLength(chars);
    char* arr = new char[length];

    for (int i = 0; i < length; i++) {
        arr[i] = chars[i];
    }
    swap(arr, s);
    return *this;
}

bool CreateString::operator==(const CreateString& obj) const
{
    if(obj.s == nullptr) return false;

    int strLength = obj.objLength() + 1;
    for (int i = 0; i < strLength; i++) {
        if (obj.s[i] != s[i]) {
            return false;
        }
    }
    return true;
}

bool CreateString::operator==(const char* chars) const
{
    if (chars == nullptr) return false;

    int strLength = 0;
    while (true) {
        if (chars[strLength] != s[strLength]) {
            return false;
        }
        if (s[strLength] == '\0') {
            break;
        }
        strLength++;
    }
    return true;
}

bool CreateString::operator!=(const CreateString& obj) const
{
    return !(*this == obj);

}

bool CreateString::operator!=(const char* chars) const
{
    return !(*this == chars);
}

int CreateString::objLength() const
{
    int length = 0;
    while (true) {
        if (this->s[length] != '\0') {
            length++;
        }
        else {
            return length;
        }
    }
}

int CreateString::charsLength(const char* sign) const 
{
    int length = 0;
    while (true) {
        if (sign[length] == '\0') {
            length++;
            break;
        }
        length++;
    }
    return length;
}

char& CreateString::operator[](size_t index)
{
    return s[index];
}

CreateString::~CreateString() 
{
    delete[] s;
    this->s = nullptr;
}
