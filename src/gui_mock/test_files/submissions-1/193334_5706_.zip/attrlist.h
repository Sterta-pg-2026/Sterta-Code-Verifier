#pragma once
#include <iostream>
#include "createstring.h"
using namespace std;

struct NodeAttribute {
	CreateString propertyAtr;
	CreateString valAtr;
	NodeAttribute* next;
	NodeAttribute* prev;
};

class AttrList {
	NodeAttribute* head;
	NodeAttribute* tail;
public:

	AttrList();
	void addToListAttr(CreateString valAtr, CreateString propertyAtr);
	int numAttr() const;
	CreateString findValueByName(CreateString name) const;
	bool countByName(CreateString propertyAtr) const;
	bool deleteAttrByName(CreateString name);
	void popFront();
	void popBack();
	~AttrList();
};


