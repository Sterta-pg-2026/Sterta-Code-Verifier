#include <iostream>
#include "createstring.h"
#include "selectlist.h"
#include "defines.h"
using namespace std;

SelectList::SelectList() {
	this->head = nullptr;
	this->tail = nullptr;
}

void SelectList::addToListSelect(CreateString name) {
	if (name != nullptr) {
		NodeSelector* new_node = new NodeSelector();
		new_node->nameSelect = name;

		if (this->head == nullptr) {
			this->head = new_node;
			this->tail = new_node;
			head->prev = nullptr;
			tail->next = nullptr;
		}
		else {
			tail->next = new_node;
			new_node->prev = tail;
			tail = new_node;
			tail->next = nullptr;
		}
	}
}

CreateString SelectList::findSelectOfIndex(int index) const{
	NodeSelector* temp = head;
	int tempNum = 0;

	while (temp != nullptr) {
		tempNum++;
		if (tempNum == index) {
			return temp->nameSelect;
		}
		temp = temp->next;
	}
	return nullptr;
}

int SelectList::numSelect() const{
	NodeSelector* temp = head;
	int count = 0;

	while (temp != nullptr) {
		count++;
		temp = temp->next;
	}
	return count;
}

bool SelectList::countByName(CreateString propertySelect) const{
	NodeSelector* temp = head;

	while (temp != nullptr) {
		if (temp->nameSelect == propertySelect) {
			return true;
		}
		temp = temp->next;
	}
	return false;
}

bool SelectList::findSelectByName(CreateString name) const{
	NodeSelector* temp = head;

	while (temp != nullptr) {
		if (temp->nameSelect == name) {
			return true;
		}
		temp = temp->next;
	}
	return false;
}

SelectList::~SelectList() {
	NodeSelector* temp = nullptr;

	while (this->head) {
		temp = head;
		head = head->next;
		delete temp;
	}
	head = nullptr;
}