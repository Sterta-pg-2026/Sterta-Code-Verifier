#pragma once
#include<iostream>
using namespace std;
class CreateString {
    char* s;

    friend ostream& operator<<(ostream& ostr, const CreateString& obj);
    friend istream& operator>>(istream& istr, CreateString& obj);
public:
    CreateString();
    CreateString(char* sign);
    CreateString(const CreateString& obj);
    int objLength() const;
    int charsLength(const char* sign) const;
    bool operator==(const CreateString& obj) const;
    bool operator==(const char* chars) const;
    bool operator!=(const CreateString& obj) const;
    bool operator!=(const char* chars) const;
    CreateString& operator=(const CreateString& obj);
    CreateString& operator=(const char* chars);
    char& operator[](size_t index);
    ~CreateString();
};