#include <iostream>
#include "createstring.h"
#include "attrlist.h"
#include "defines.h"
using namespace std;

AttrList::AttrList() {
	this->head = nullptr;
	this->tail = nullptr;
}

void AttrList::addToListAttr(CreateString valAtr, CreateString propertyAtr) {

	NodeAttribute* new_node = new NodeAttribute();
	new_node->propertyAtr = propertyAtr;
	new_node->valAtr = valAtr;
	int swap = 0;

	if (this->head == nullptr) {
		this->head = new_node;
		this->tail = new_node;
		head->prev = nullptr;
		tail->next = nullptr;
	}
	else {
		NodeAttribute* temp = head;
		while (temp != nullptr) {
			if (temp->propertyAtr == new_node->propertyAtr) {
				temp->valAtr = new_node->valAtr;
				swap = 1;
				break;
			}
			temp = temp->next;
		}

		if (swap == 0) {
			tail->next = new_node;
			new_node->prev = tail;
			tail = new_node;
			tail->next = nullptr;
		}
	}
}

int AttrList::numAttr() const{
	NodeAttribute* temp = head;
	int count = 0;

	while (temp != nullptr) {
		count++;
		temp = temp->next;
	}
	return count;
}

CreateString AttrList::findValueByName(CreateString name) const{
	NodeAttribute* temp = head;

	while (temp != nullptr) {
		if (temp->propertyAtr == name) {
			return temp->valAtr;
		}
		temp = temp->next;
	}
	return nullptr;
}

bool AttrList::countByName(CreateString propertyAtr) const{
	NodeAttribute* temp = head;

	while (temp != nullptr) {
		if (temp->propertyAtr == propertyAtr) {
			return true;
		}
		temp = temp->next;
	}
	return false;
}


bool AttrList::deleteAttrByName(CreateString name) {
	NodeAttribute* temp = head;

	while (temp != nullptr) {
		if (temp->propertyAtr == name) {
			if (temp -> prev == nullptr) {
				popFront();
				return true;
			}
			else if (temp->next == nullptr) {
				popBack();
				return true;
			}
			else {
				NodeAttribute* tempNode = temp->next;
				temp->prev->next = tempNode;
				tempNode = temp->prev;
				temp->next->prev = tempNode;
				temp->next = nullptr;
				temp->prev = nullptr;
				delete temp;
				return true;
			}
		}
		temp = temp->next;
	}
	return false;
}

void AttrList::popFront() {
	if (head->next != nullptr) {
		head->next->prev = nullptr;
	}

	NodeAttribute* temp = head->next;
	delete head;
	head = temp;
}

void AttrList::popBack() {
	if (tail->prev != nullptr) {
		tail->prev->next = nullptr;
	}

	NodeAttribute* temp = tail->prev;
	delete tail;
	tail = temp;
}

AttrList::~AttrList() {
	NodeAttribute* temp = nullptr;

	while (this->head){
		temp = head;
		head = head->next;
		delete temp;
	}
	head = nullptr;
}
