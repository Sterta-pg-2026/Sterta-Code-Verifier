#include <iostream>
#include "createstring.h"
#include "selectlist.h"
#include "attrlist.h"
#include "sectionslist.h"
#include "defines.h"
using namespace std;

SectionList::SectionList() {
	this->head = nullptr;
	this->tail = nullptr;
}

void SectionList::addNodeToListSection() {
	NodeSection* new_node = new NodeSection();
	new_node->arr = new arrElement[T];

	for (int i = 0; i < T; i++) {
		new_node->arr[i].attrList = nullptr;
		new_node->arr[i].selectList = nullptr;
	}
	new_node->counter = 0;

	if (this->head == nullptr) {
		this->head = new_node;
		this->tail = new_node;
		head->prev = nullptr;
		tail->next = nullptr;
	}
	else {
		tail->next = new_node;
		new_node->prev = tail;
		tail = new_node;
		tail->next = nullptr;
	}
}

void SectionList::addToArrInSection(SelectList* selectList, AttrList* attrList) {
	if (this->head==nullptr) {
		addNodeToListSection();
	}
	
	NodeSection* temp = this->tail;
	if (temp->counter == T) {
		addNodeToListSection();
	}
	temp = this->tail;

	for (int i = 0; i < T; i++) {
		if (temp->arr[i].attrList == nullptr) {
			temp->arr[i].attrList = attrList;
			temp->arr[i].selectList = selectList;
			temp->counter++;
			break;
		}
	}
}

int SectionList::numOfSections() const{
	NodeSection* temp = head;
	int numSect = 0;

	while (temp != nullptr) {
		numSect += temp->counter;
		temp = temp->next;
	}
	return numSect;
}

int SectionList::numSelectInSection(int index) const{
	NodeSection* temp = head;
	int out=-1;

	while (temp != nullptr) {
		if (index - temp->counter <= 0) {
			out = temp->arr[index - 1].selectList->numSelect();
			return out;
		}
		index -= temp->counter;
		temp = temp->next;
	}
	return out;
}

CreateString SectionList::findSelectOfIndexInGivenBlock(int indexBlock, int indexSelect) const{
	NodeSection* temp = head;
	CreateString out;

	while (temp != nullptr) {
		if (indexBlock - temp->counter <= 0) {
			out = temp->arr[indexBlock - 1].selectList->findSelectOfIndex(indexSelect);
			if ((out != nullptr)&&(out != NULL_SIGN)) return out;
			return nullptr;
		}
		indexBlock -= temp->counter;
		temp = temp->next;
	}
	return nullptr;
}

int SectionList::countSelectByName(CreateString name) const{
	int count = 0;
	NodeSection* temp = head;

	while (temp != nullptr) {
		for (int i = 0; i < T; i++) {
			if (temp->arr[i].selectList == nullptr) continue;
			else if (temp->arr[i].selectList->countByName(name)) {
				count++;
			}
		}
		temp = temp->next;
	}
	return count;
}

int SectionList::numAttrInSection(int index) const {
	NodeSection* temp = head;

	while (temp != nullptr) {
		if (index - temp->counter <= 0) {
			return temp->arr[index - 1].attrList->numAttr();
		}
		index -= temp->counter;
		temp = temp->next;
	}
	return NULL;
}

CreateString SectionList::valuAttrInSection(int index, CreateString name) const{
	CreateString val;
	NodeSection* temp = head;

	while (temp != nullptr) {
		if (index - temp->counter <= 0) {
			val = temp->arr[index - 1].attrList->findValueByName(name);
			return val;
		}
		index -= temp->counter;
		temp = temp->next;
	}
	return nullptr;
}

int SectionList::countAttrByName(CreateString name) const {
	int count = 0;
	NodeSection* temp = head;

	while (temp != nullptr) {
		for (int i = 0; i < T; i++) {
			if (temp->arr[i].attrList == nullptr) continue;
			else if (temp->arr[i].attrList->countByName(name)) {
				count++;
			}
		}
		temp = temp->next;
	}
	return count;
}

CreateString SectionList::AttrValueForGivenSelector(CreateString selector, CreateString attr) const{
	NodeSection* temp = tail;

	while (temp != nullptr) {
		for (int i = T-1; i >= 0; i--) {
			if (temp->arr[i].selectList == nullptr) continue;
			else if (temp->arr[i].selectList->findSelectByName(selector)) {
				return temp->arr[i].attrList->findValueByName(attr);
			}
		}
		temp = temp->prev;
	}
	return nullptr;
}

bool SectionList::deteleSection(int index) {
	NodeSection* temp = head;

	while (temp != nullptr) {
		if (index - temp->counter <= 0) {
			temp->arr[index - 1].attrList = nullptr;
			temp->arr[index - 1].selectList = nullptr;
			temp->counter--;
			if (temp->counter == 0) {
				deleteNodeSection(temp);
			}
			else {
				checkIfEmptyMove(index, temp->arr);
			}
			return true;
		}
		index -= temp->counter;
		temp = temp->next;
	}
	return false;
}

void SectionList::deleteNodeSection(NodeSection* temp) {
	if (temp->prev == nullptr) {
		popFront();
	}
	else if (temp->next == nullptr) {
		popBack();
	}
	else {
		NodeSection* tempNode = temp->next;
		temp->prev->next = tempNode;
		tempNode = temp->prev;
		temp->next->prev = tempNode;
		temp->next = nullptr;
		temp->prev = nullptr;
		delete temp;
	}
}

void SectionList::popFront() {
	if (head->next != nullptr) {
		head->next->prev = nullptr;
	}

	NodeSection* temp = head->next;
	delete head;
	head = temp;
}

void SectionList::popBack() {
	if (tail->prev != nullptr) {
		tail->prev->next = nullptr;
	}

	NodeSection* temp = tail->prev;
	delete tail;
	tail = temp;
}

void SectionList::checkIfEmptyMove(int index, arrElement* arr) {
	arrElement temp;

	if ((arr[index - 1].attrList == nullptr)&&(index!=8)) {
		for (int i = index - 1; i < T-1; i++) {
			temp = arr[i+1];
			arr[i] = temp;
			arr[i + 1].attrList = nullptr;
			arr[i + 1].selectList = nullptr;
		}
	}
}

bool SectionList::deleteAttr(int index, CreateString name) {
	NodeSection* temp = head;
	int i = index;

	while (temp != nullptr) {
		if (index - temp->counter <= 0) {
			if (temp->arr[index - 1].attrList->deleteAttrByName(name)) {
				if (temp->arr[index - 1].attrList->numAttr() == 0) {
					deteleSection(i);
				}
				return true;
			}
		}
		index -= temp->counter;
		temp = temp->next;
	}
	return false;
}

SectionList::~SectionList() {
	NodeSection* temp = nullptr;

	while (this->head) {
		if (head->arr != nullptr) {
			delete[] head->arr;
		}
		temp = head;
		head = head->next;
		delete temp;
	}
	head = nullptr;
}