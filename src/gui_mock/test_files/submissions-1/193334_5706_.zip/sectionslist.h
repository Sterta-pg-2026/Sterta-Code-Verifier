#pragma once
#include <iostream>
#include "createstring.h"
#include "selectlist.h"
#include "attrlist.h"
using namespace std;

struct arrElement {
	SelectList* selectList;
	AttrList* attrList;
};

struct NodeSection{
	arrElement* arr;
	int counter;
	NodeSection* next;
	NodeSection* prev;
};

class SectionList {
	NodeSection* head;
	NodeSection* tail;
public:

	SectionList();
	void addNodeToListSection();
	void addToArrInSection(SelectList* selectList,AttrList* attrList);
	int numOfSections() const;
	int numSelectInSection(int index) const;
	CreateString findSelectOfIndexInGivenBlock(int indexBlock, int indexSelect) const;
	int countSelectByName(CreateString name) const;
	int numAttrInSection(int index) const;
	CreateString valuAttrInSection(int index, CreateString name) const;
	int countAttrByName(CreateString name) const;
	CreateString AttrValueForGivenSelector(CreateString selector, CreateString attr) const;
	bool deteleSection(int index);
	void deleteNodeSection(NodeSection* temp);
	void popFront();
	void popBack();
	void checkIfEmptyMove(int index, arrElement* arr);
	bool deleteAttr(int index, CreateString name);
	~SectionList();
};