
#define COMA ','
#define SEMICOLON ';'
#define	ENTER '\n'
#define COLON ':'
#define SPACE ' '
#define OP_BRACKET_CHAR '{'
#define OP_BRACKET "{"
#define CL_BRACKET_CHAR '}'
#define CL_BRACKET "}"
#define BACKSLASH '\t'
#define START_COMMANDS "????"
#define START_CSS "****"
#define STRING_LONG 256
#define NULL_SIGN_CHAR '\0'
#define NULL_SIGN "\0"
#define CARR_RETURN '\r'
#define STAR "*"
#define QUESTION_MARK "?"
#define COMMAND_A "A"
#define COMMAND_S "S"
#define COMMAND_E "E"
#define COMMAND_D "D"
#define T 8
