#pragma once
#include <iostream>
#include "createstring.h"
using namespace std;

struct NodeSelector {
	CreateString nameSelect;
	NodeSelector* next;
	NodeSelector* prev;
};

class SelectList {
	NodeSelector* head;
	NodeSelector* tail;
public:

	SelectList();
	void addToListSelect(CreateString name);
	CreateString findSelectOfIndex(int index) const;
	int numSelect() const;
	bool countByName(CreateString propertySelect) const;
	bool findSelectByName(CreateString name) const;
	~SelectList();
};