#include <iostream>
#include <math.h>
#include "createstring.h"
#include "attrlist.h"
#include "selectlist.h"
#include "sectionslist.h"
#include "defines.h"
using namespace std;

CreateString getText(char sign1, char sign2, char sign3);
void getData(SectionList* section);
void getSelectors(CreateString data, SelectList* selectors);
void getAttributes(CreateString data, AttrList* attributes);
void getCommands(SectionList* section, CreateString data);
void Acommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line);
void Scommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line);
void Ecommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line);
void Dcommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line);
int StringToInteger(CreateString data);
void skipLine();


int main() {
	SectionList* section = new SectionList;
	getData(section);
	return 0;
}

void getData(SectionList* section) {
	CreateString data;

	data = getText(COMA, ENTER, OP_BRACKET_CHAR);
	while (true) {
		SelectList* selectors = new SelectList;
		AttrList* attributes = new AttrList;

		//get selectors list
		getSelectors(data, selectors);

		data = getText(COLON, ENTER, CL_BRACKET_CHAR);

		//get attributes list
		getAttributes(data, attributes);
		//add to section list (attributes and selectors from one block)
		section->addToArrInSection(selectors, attributes);

		data = getText(COMA,  ENTER, OP_BRACKET_CHAR);

		if (data == START_COMMANDS) {
			getCommands(section, data);
			data = getText(COMA,  ENTER, OP_BRACKET_CHAR);
		}
	}
}


void getCommands(SectionList* section, CreateString data) {
	CreateString a, b, c;
	static int new_line = 1;
	data = getText(COMA,  ENTER, OP_BRACKET_CHAR);

	while ((data != START_CSS) ) {
		a = data;

		if (a == QUESTION_MARK) {
			if (new_line == 0)cout << endl;
			cout  << a << " == " <<section->numOfSections();
			new_line = 0;
		}
		else {
			b = getText(COMA,  ENTER, NULL);
			c = getText(COMA,  ENTER, NULL);

			if (b == COMMAND_A) {
				Acommand(a, b, c, section, &new_line);
			}
			else if (b == COMMAND_S) {
				Scommand(a, b, c, section, &new_line);
			}
			else if (b == COMMAND_E) {
				Ecommand(a, b, c, section, &new_line);
			}
			else if (b == COMMAND_D) {
				Dcommand(a, b, c, section, &new_line);
			}
			else if (b.objLength() > 1 || b == NULL) {
				skipLine();
			}
		}
		data = getText(COMA,  ENTER, OP_BRACKET_CHAR);
	}
}


void Acommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line) {
	int text_to_int = StringToInteger(a);
	int out;
	CreateString valueAnsw;

	if (text_to_int != NULL) {
		if (c == QUESTION_MARK) {
			out = section->numAttrInSection(text_to_int);
			if (out != NULL) {
				if (*new_line == 0) cout << endl;
				cout << a << "," << b << "," << c << " == " << out;
				*new_line = 0;
			}
		}
		else {
			valueAnsw = section->valuAttrInSection(text_to_int, c);
			if ((valueAnsw != nullptr) && (valueAnsw != NULL_SIGN)) {
				if (*new_line == 0) cout << endl;
				cout << a << "," << b << "," << c << " == " << valueAnsw;
				*new_line = 0;
			}
		}
	}
	else {
		out = section->countAttrByName(a);
		if (*new_line == 0)cout << endl;
		cout << a << "," << b << "," << c << " == " << out ;
		*new_line = 0;
	}
}


void Scommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line) {
	int text_to_int = StringToInteger(a);
	int out;
	CreateString valueAnsw;

	if (text_to_int != NULL) {
		if (c == QUESTION_MARK) {
			out = section->numSelectInSection(text_to_int);
			if (out != -1) {
				if (*new_line == 0) cout << endl;
				cout << a << "," << b << "," << c << " == " << out;
				*new_line = 0;
			}
		}
		else {
			int text_to_int_2 = StringToInteger(c);
			valueAnsw = section->findSelectOfIndexInGivenBlock(text_to_int, text_to_int_2);
			if ((valueAnsw != nullptr) && (valueAnsw != NULL_SIGN)) {
				if (*new_line == 0)cout << endl;
				cout << a << "," << b << "," << c << " == " << valueAnsw;
				*new_line = 0;
			}
		}
	}
	else {
		out = section->countSelectByName(a);
		if (*new_line == 0)cout << endl;
		cout  << a << "," << b << "," << c << " == " << out ;
		*new_line = 0;
	}
}


void Ecommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line) {
	CreateString valueAnsw;
	valueAnsw = section->AttrValueForGivenSelector(a, c);

	if ((valueAnsw != nullptr) && (valueAnsw != NULL_SIGN)) {
		if (*new_line == 0)cout << endl;
		cout << a << "," << b << "," << c << " == " << valueAnsw;
		*new_line = 0;
	}
}

void Dcommand(CreateString a, CreateString b, CreateString c, SectionList* section, int *new_line) {
	int text_to_int = StringToInteger(a);

	if (c == STAR) {
		if (section->deteleSection(text_to_int)) {
			if (*new_line == 0)cout << endl;
			cout << a << "," << b << "," << c << " == deleted";
			*new_line = 0;
		}
	}
	else {
		if (section->deleteAttr(text_to_int, c)) {
			if (*new_line == 0)cout << endl;
			cout << a << "," << b << "," << c << " == deleted";
			*new_line = 0;
		}
	}
}


void getSelectors(CreateString data, SelectList* selectors) {
	int stop = 1;

	while (data != OP_BRACKET) {
		if (data[data.objLength() - 1] == OP_BRACKET_CHAR && data.objLength() > 1) {
			if (data[data.objLength() - 2] == ' ') {
				data[data.objLength() - 2] = NULL_SIGN_CHAR;
			}
			else data[data.objLength() - 1] = NULL_SIGN_CHAR;
			stop = 0; // if after the last selector we ommited enter sign the bracket is connected to this last selector. We have to fix it
		}
		if (data != NULL_SIGN) {
			selectors->addToListSelect(data);
		}
		if (stop == 0) break;
		data = getText(COMA,  ENTER, OP_BRACKET_CHAR);
	}
}


void getAttributes(CreateString data, AttrList* attributes) {
	CreateString nameAttr;
	int  stop = 1;

	while (data != CL_BRACKET) {
		if (data != NULL_SIGN ) {
			nameAttr = data;
		}

		data = getText(SEMICOLON, ENTER, CL_BRACKET_CHAR);
		if (data[data.objLength() - 1] == CL_BRACKET_CHAR && data.objLength() > 1) {
			if (data[data.objLength() - 2] == ' ') {
				data[data.objLength() - 2] = NULL_SIGN_CHAR;
			}
			else data[data.objLength() - 1] = NULL_SIGN_CHAR;
			stop = 0;// fixing the same problem like in selectors - problem with bracket connected to the last word
		}

		if (data != NULL_SIGN) {
			attributes->addToListAttr(data, nameAttr);
		}
		if (stop == 0)break;

		data = getText(COLON,  ENTER, CL_BRACKET_CHAR);
	}
}


CreateString getText(char sign1, char sign2, char sign3) {
	int i = 0;
	char c;
	int temp = 1;
	char* arr = (char*)malloc(STRING_LONG * sizeof(char));
	static int end = 1;

	do {
		c = getchar();
		if (end == 0 && (c == EOF)) exit(0);
		else end = 1;

		if ((c == sign1 || c == sign2 || c == sign3 || c == BACKSLASH || c == SPACE) && temp == 1) {
			if (c == OP_BRACKET_CHAR || c == CL_BRACKET_CHAR) {
				arr[i] = c;
				i++;
				break;
			}
			c = NULL;
			continue;
		}
		temp = 0;
		arr[i] = c;
		i++;
	} while (c != sign1 && c != sign2 && c != sign3 && c!=EOF && c!= CARR_RETURN && c!= 0x0D0A);

	if (c == EOF || c == NULL) {
		end = 0;
	}

	if (arr[i - 1] == OP_BRACKET_CHAR || arr[i - 1] == CL_BRACKET_CHAR) {
		arr[i] = NULL_SIGN_CHAR;
	}
	else if (arr[i - 2] == SPACE) {
		arr[i - 2] = NULL_SIGN_CHAR;
	}
	else arr[i - 1] = NULL_SIGN_CHAR;// cutting special signs
	return arr;
}

void skipLine() {
	char temp;

	do {
		temp=getchar();
	} while (temp != ENTER);
}

int StringToInteger(CreateString data) {
	int number = 0;
	int temp;

	for (int i = 0; i < data.objLength(); i++) {
		//int from 0 to 9
		if (char(data[i]) >= 48 && char(data[i]) <= 57) {
			temp = char(data[i] - 48);
			number += (temp * pow(10, data.objLength() - 1 - i));
		}
		else {
			return NULL;
		}
	}
	return number;
}