#include<iostream>
#include <sstream>
using namespace std;
#define T 8
#define NULLCHAR (char)(0)
#define RESERVESTRING 8

class String {
public:
	char* arr;
	int allocatedSpace;
	String() {
		this->allocatedSpace = 0;
		this->arr = nullptr;
	}

	int length() const {
		if (allocatedSpace == 0) {
			return 0;
		}
		for (int i = 0; i < allocatedSpace; i++) {
			if (arr[i] == NULLCHAR) {
				return i;
			}
		}
	}

	void add(char toAdd) {
		if (allocatedSpace == 0) {
			allocatedSpace += RESERVESTRING;
			arr = (char*)malloc(sizeof(char) * allocatedSpace);
			arr[0] = toAdd;
			arr[1] = NULLCHAR;
		}
		else if (allocatedSpace < this->length() + 1) {
			allocatedSpace += RESERVESTRING;
			arr = (char*)realloc(arr, (sizeof(char) * allocatedSpace));
			arr[length()] = NULLCHAR;
			arr[length() - 1] = toAdd;
		}
		else {
			arr[length()] = NULLCHAR;
			arr[length() - 1] = toAdd;
		}
	}

	friend::ostream& operator<<(ostream& os, const String& str)
	{
		for (int i = 0; i < str.length(); i++)
		{
			cout << str.arr[i];
		}
		return os;
	}
	friend::istream& operator>>(istream& is, const String& str)
	{
		
		for (int i = 0; i < str.length(); i++)
		{
			cin >> str.arr[i];
		}
	
		
		return is;
	}


	bool operator==(const String& other) const {
		if (allocatedSpace - 1 != other.length()) {
			//cout << "Inna dlugosc" << endl;
			return false;
		}
		for (int i = 0; i < allocatedSpace; i++) {
			if (arr[i] != other.arr[i]) {
				return false;
			}
		}
		return true;
	}

	bool is_nullptr() const {
		if (arr == nullptr) {
			return true;
		}
		return false;
	}



	String& operator+=(const String& other) {
		
		int newLength = this->length() + other.length() ;
		int poprzedniaDlugosc = this->length();
		//cout << "Nowa dlugosc stringa: " << newLength << endl;
		
		if (this->allocatedSpace < newLength + 1) {
			this->allocatedSpace = newLength ;
			this->arr = (char*)realloc(this->arr, sizeof(char) * this->allocatedSpace );
			//cout << "Realokuje pamiec do: " << this->allocatedSpace << endl;
		}

		//cout << "Sklejam stringi: " << this->arr << " i " << other.arr << endl;

		for (int i = 0; i < other.length(); i++) {
			this->arr[poprzedniaDlugosc + i] = other.arr[i];
		}

		this->arr[newLength] = NULLCHAR;

		return *this;
	}

	String(const char* str) {
		int len = 0;
		while (str[len] != '\0') {
			len++;
		}
		allocatedSpace = len + 1;
		arr = (char*)malloc(sizeof(char) * allocatedSpace);
		for (int i = 0; i < len; i++) {
			arr[i] = str[i];
		}
		arr[len] = '\0';
	}

	String substr(int start, int len) const {
		if (start >= length() || len <= 0) {
			cout << "Poza indeksem!" << endl;
			return String();
		}

		int subLen = min(len, length() - start);
		/*
		String subStr;
		subStr.allocatedSpace = subLen + 1;
		subStr.arr = (char*)malloc(sizeof(char) * subStr.allocatedSpace);
		*/
		
		char* buf = new char[subLen + 1];
		
		for (int i = 0; i < subLen; i++) {
			//cout << "Kopiuje: " << arr[start + i] << endl;
			//subStr.arr[i] = arr[start + i];
			buf[i] = arr[start + i];
		}

		buf[subLen] = NULLCHAR;

		return String(buf);
	}
	/*
	~String() {
		free(arr);
	}
	*/
	

};

struct MyListElement
{
	MyListElement* next;

	String value;

};

class MyList {
public:

	MyListElement* head;

	MyList() {
		head = nullptr;
	}


	MyListElement*& operator[](int index) {
		MyListElement* tmp = this->head;
		for (int i = 0; i < index; i++) {
			tmp = tmp->next;

		}
		return tmp;
	}

	int length() {

		int cnt = 1;
		MyListElement* temp = this->head;
		while (temp->next != nullptr)
		{
			temp = temp->next;
			cnt++;
		}

		return cnt;

	}

	void clear() {
		head = nullptr;
	}


	void printList() {

		MyListElement* temp = this->head;
		while (temp->next != nullptr)
		{
			//cout << "Uwaga coutuje: ";
			cout << temp->value << endl;
			temp = temp->next;
		}

	}


	void addNode(String values) {
		//cout << "Dodaje element: " << values << endl;
		if (head == nullptr)
		{
			//cout << "Lista pusta tworze pierwszy element" << endl;

			this->head = new MyListElement();
			this->head->value = values;
			this->head->next = nullptr;


		}
		else {
			//cout << "Dodaje nowy element" << endl;

			MyListElement* newNode = this->head;
			while (newNode->next != nullptr)
				newNode = newNode->next;

			newNode->next = new MyListElement();

			newNode->next->value = values;
			newNode->next->next = nullptr;


		}

	}


};




class SingleNode {
public:
	String values;
	SingleNode* next;

	SingleNode(SingleNode* next = nullptr) {

		this->values = new char[T];
		this->next = next;

	}

	SingleNode*& operator[](int index) {
		SingleNode* tmp = this->next;
		for (int i = 0; i < index; i++) {
			tmp = tmp->next;
			if (tmp->next == nullptr) {
				return tmp;
			}
		}
		return tmp;

	}

	void addNode(String values) {
		SingleNode* newNode = new SingleNode();
		newNode->values = values;
		newNode->next = this->next;
		this->next = newNode;
	}

	~SingleNode() {
		if (next != nullptr) {
			delete next;
		}
		values = 0;
	}
};

struct Block {
	String selector;
	
	MyList attributes;
	MyList values;

};


class Node {
public:
	Block* values;
	Node* next;
	Node* prev;
	
	int current_block = 0;
	int places_in_block = 0;

	Node() {

		this->values = new Block[T];
		this->next = nullptr;
		this->prev = nullptr;

	}

	int all_block_length() {
		int cnt = 0;

		Node* tmp_node = this->next;
		while (tmp_node->next != nullptr)
			tmp_node = tmp_node->next;

		for (int i = 0; i < T; i++) {
			if (tmp_node->values[i].selector.is_nullptr() == false) {
				cnt++;
			}
		}
		

		return cnt + current_block*T;
	}

	int length() {
		int cnt = 0;

		for (int i = 0; i < T; i++) {
			if (this->values[i].selector.is_nullptr() == false) {
				cnt++;
			}
		}


		return cnt;
	}
	
	Node* add_new_node() {
		Node* newNode = new Node();
		newNode->prev = this;
		this->next = newNode;
		return newNode;
	}

	void push_back_block(Block values) {
		if (this->length() < T) {
			//cout << "Dodaje do Noda" << endl;
			places_in_block++;
			this->values[this->length()] = values;
		}
		else {
			//cout << "Tworze nowy node, przekorczono rozmiar T" << endl;
			
			this->values[this->length()] = values;
		}
	}

	
	

	Node*& operator[](int index) {
		if (index >= 0) {
			Node* tmp = this->next;
			for (int i = 0; i < index; i++) {
				tmp = tmp->next;
				if (tmp->next == nullptr) {
					return tmp;
				}
			}
			return tmp;
		}
		else {
			Node* tmp = this->prev;
			for (int i = 0; i < index * (-1); i++) {
				tmp = tmp->prev;
				if (tmp->prev == nullptr) {
					return tmp;
				}
			}
			return tmp;
		}
	}

	~Node() {
		prev->next = next;
		next->prev = prev;
		delete[] values;
	}
};





int main() {
	String data = "";
	char* buf = new char[4096];



	bool wczytywanie_css = true;

	bool wczytywanie_komend = false;

	bool procesuj_css = false;

	int sekcje = 0;

	Node node_1;

	MyList lista_selektorow;
	MyList lista_atrybutow;
	MyList lista_wartosci;
	
	
	int* ile_selektorow_w_sekcji = new int[300];

	for (int i = 0; i < 300; i++) {
		ile_selektorow_w_sekcji[i] = 0;
	}





	while (1) {

		while (1) {
			
			cin >> buf;
			String data_s (buf);
			


			if (data_s == "????") {
				wczytywanie_css = false;
				wczytywanie_komend = true;
				procesuj_css = true;
				
				

				break;
			}
			if (data_s.arr == "****") {
				wczytywanie_css = true;
				wczytywanie_komend = false;
				break;

			}

			if (wczytywanie_css) {
				data += data_s;				
			}

		}

		//cout << data << endl;

		//while (1);

		// ========================== PARSOWANIE CSSa =============================

		
		int last_delm = 0;
		
		

		bool klasa = true;
		bool atrybut = false;
		bool wartosc = false;

		if (procesuj_css) {
			for (int i = 0; i < data.length(); i++) {  // parsuj CSSa

				if (klasa) {

					if (data.arr[i] == ',') {
						String s = data.substr(last_delm, i - last_delm);
						//cout << "Selektor: " << s << endl;
						lista_selektorow.addNode(s);
						ile_selektorow_w_sekcji[sekcje]++;
						
						last_delm = i + 1;

					}

					if (data.arr[i] == '{') {
						String s = data.substr(last_delm, i - last_delm);
						//cout << "Selektor: " << s << endl;
						lista_selektorow.addNode(s);
						ile_selektorow_w_sekcji[sekcje]++;
						last_delm = i + 1;
						

						klasa = false;
						atrybut = true;
						wartosc = false;

					}



				}

				if (atrybut) {
					if (data.arr[i] == ':') {
						String s = data.substr(last_delm, i - last_delm);
						//cout << "	Atrybut: " << s << endl;
						lista_atrybutow.addNode(s);
						//cout << s << endl;
						last_delm = i + 1;

						klasa = false;
						atrybut = false;
						wartosc = true;
					}




				}

				if (wartosc) {
					if (data.arr[i] == ';') {
						String s = data.substr(last_delm, i - last_delm);
						//cout << "	Value: " << s << endl;
						lista_wartosci.addNode(s);
						last_delm = i + 1;

						klasa = false;
						atrybut = true;
						wartosc = false;
					}


				}

				if (data.arr[i] == '}') { // koniec bloku
					last_delm = i + 1;
					sekcje++;
					//cout << "Mam sekcje: " << sekcje << endl;
					
					for (int i = 0; i < lista_selektorow.length(); i++) {  // iterujemy po klasach
						bool brak_selektora = true;
						int index_selektora = 0;
						
						for (int j = 0; j < node_1.length(); j++) {		// sprawdzamy czy selektor istnieje
							if (node_1.values[j].selector == lista_selektorow[i]->value) {
								//cout << "Selektor: " << lista_selektorow[i]->value << " istnieje" << endl;
								brak_selektora = false;
								index_selektora = j;
								break;
							}
						}


						if (brak_selektora) {	// tworzymy nowy selektor

							//cout << "Tworzymy nowy selektor w nodzie" << endl;

							Block tmp;
							tmp.selector = lista_selektorow[i]->value;
							for (int j = 0; j < lista_atrybutow.length(); j++) {
								tmp.attributes.addNode(lista_atrybutow[j]->value);
								tmp.values.addNode(lista_wartosci[j]->value);
						
							}
							node_1.push_back_block(tmp);
							


						}
						else { // selektor istnieje o indexie index_selektora
							
							for (int i = 0; i < lista_atrybutow.length(); i++) { // iterujemy po atrybutach

								bool brak_atrybutu = true;
								int index_atrybutu = 0;
								

								for (int j = 0; j < node_1.values[index_selektora].attributes.length(); j++) { // szukamy czy atrybut istnieje
									if (node_1.values[index_selektora].attributes[j]->value == lista_atrybutow[i]->value) {
										index_atrybutu = j;
										brak_atrybutu = false;
										break;
									}

								}
								

								if (brak_atrybutu) { // podany atrybut nie istnieje w selektorze

									node_1.values[index_selektora].attributes.addNode(lista_atrybutow[i]->value);
									node_1.values[index_selektora].values.addNode(lista_wartosci[i]->value);

								}
								else {	// podany atrybut istnieje wewn�trz selektora

									//dane_str[index_selektora].atrybuty[index_atrybutu].parametry = opcje[i];
									node_1.values[index_selektora].values[index_atrybutu]->value = lista_wartosci[i]->value;
									
								}


							}
							

						}
						

					}

					// koniec sekcji

					//selektory_w_sekcji.addNode(selectors.values);
					//atrybuty_w_sekcji.addNode(attributes.values);

					// koniec wczytywanego bloku czy�cimy dane
					lista_atrybutow.clear();
					lista_selektorow.clear();
					lista_wartosci.clear();


					klasa = true;
					atrybut = false;
					wartosc = false;
				}


			}

			procesuj_css = false;

		}
		// koniec wczytywania CSS - wy�wietlamy dane


		if (false) {
			cout << endl << endl << endl;
			cout << "Wczytane klasy:" << endl;

			
			for (int i = 0; i < node_1.length(); i++) {

				cout << node_1.values[i].selector << endl;

			}

			cout << endl << endl << endl;

			for (int i = 0; i < node_1.length(); i++) {
				cout << "Selektor " << node_1.values[i].selector << " zawiera atrybuty:" << endl;
				
				for (int j = 0; j < node_1.values[i].attributes.length(); j++) {
					cout << node_1.values[i].attributes[j]->value << " posiada wartosc: " << node_1.values[i].values[j]->value << endl;
				}

				cout << endl << "---------------------------------------------------------" << endl;

			}

			cout << endl << endl << endl;

			

			
		}



		// ========================= KOMENDY =====================================

		while (wczytywanie_komend) {
			
			cin >> buf;
			String s(buf);
			

			if (s == "****") { // ewentualny powr�t do wczytywania CSS
				wczytywanie_css = true;
				wczytywanie_komend = false;
			}


			// =========================== KOMENDA 1 =======================================
			// ? - print the number of CSS sections; 
			if (s == "?") {

				cout << " == " << sekcje << endl;

			}
			else {
				String s1 = "", s2 = "", s3 = "";
				int dlm = 0;
				int cnt = 0;

				for (int i = 0; i < s.length(); i++) {

					// string s = "test12345678"
					// s.substr(3,5) => "12345"

					if (s.arr[i] == ',') {
						String tmp = s.substr(dlm, i - dlm);

						if (cnt == 0)
							s1 = tmp;
						if (cnt == 1)
							s2 = tmp;
						dlm = i + 1;
						cnt++;

					}
					s3 = s.substr(dlm, 1000);
				}

				//cout << "Mam: " << s1 << " | " << s2 << " | " << s3 << endl;

			// =========================== KOMENDA 2 =======================================
			// i,S,? - print the number of selectors for section number i 
			// (section and attribute numbers start from 1), if there is no such block, skip;

				if (s2 == "S" && s3 == "?") {
					stringstream ss;
					ss << s1.arr;
					int a = 0;
					ss >> a;



					if (0 <= a && a < sekcje) {
						cout << " == " << ile_selektorow_w_sekcji[a - 1] << endl;
					}


				}

				// =========================== KOMENDA 3 =======================================
				//i,A,? - print the number of attributes for section number i, if there is no such block or section,skip;

				if (s2 == "A" && s3 == "?") {
					stringstream ss;
					ss << s1;
					int i = 0;
					ss >> i;

					//cout << " == " << atrybuty_w_sekcji[i - 1] << endl;
				}

			}





		}





	}

}
