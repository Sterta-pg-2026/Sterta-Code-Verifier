#pragma once
#include "string.h"
using namespace std;

class Attribute {
public:
	String name;
	String value;

	Attribute();
};