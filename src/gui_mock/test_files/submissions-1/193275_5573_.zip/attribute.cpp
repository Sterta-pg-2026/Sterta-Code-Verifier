#include <iostream>
#include "attribute.h"

Attribute::Attribute() {
	name = "";
	value = "";
}