#pragma once
#include "string.h"
#include "attribute.h"
#include "dl_list.h"
using namespace std;

class Section {
public:
	DL_List <String>* selectors;
	DL_List <Attribute>* attributes;

	Section();
	~Section();
};