#define _USE_MATH_DEFINES
#include<math.h>
#include<iostream>
#include<stdio.h>
#include<string.h>

using namespace std;

/*
	? == 3
	1,S,? == 1
	1,S,1 == #breadcrumb
	1,A,? == 2
	2,A,font-family == "Trebuchet MS", "Lucida Grande", Arial

*/
int main() {
	cout << "test" << endl;
	
}