#include<iostream>
#include <cstring>
#include <cstdlib>
#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)

using namespace std;

const int SIZE = 8;
const int MAX_CHARACTERS = 60;
const int RES_CHARACTERS = 2;


template <typename T>
class Node {
private:
	T data[SIZE];
	int lastIndex;
	Node* next;
	Node* prev;

public:
	Node() {
		next = nullptr;
		prev = nullptr;
		lastIndex = -1;
	}

	~Node() {}

	void setLastIndex(int index) {
		lastIndex = index;
	}

	int getLastIndex() {
		return lastIndex;
	}
	
	T getData(int index) {
		if (index >= 0 && index <= lastIndex) {
			return data[index];
		}
		else {
			return T();
		}
	}

	Node* getNext() {
		return next;
	}

	Node* getPrev() {
		return prev;
	}

	template <typename T>
	friend class List;
};
	
	

template <typename T>
class List {
private:
	Node<T>* first;
	Node<T>* last;
	int size;
public:

	List() {
		first = nullptr;
		last = nullptr;
		size = 0;
	}

	void nullify()
	{
		first = nullptr;
		last = nullptr;
		size = NULL;
	}

	T& operator[](int index) {
		Node<T>* current = first;
		while (current != nullptr && index > current->lastIndex) {
			index -= current->lastIndex + 1;
			current = current->next;
		}
		if (current == nullptr) {
			static T default_val;
			return default_val;
		}
		return current->data[index];
	}

	List& operator=(const List& other) {
		if (this != &other) {
			while (first != nullptr) {
				Node<T>* temp = first;
				first = first->next;
				delete temp;
			}
			last = nullptr;
			size = 0;

			Node<T>* temp = other.first;
			while (temp != nullptr) {
				for (int i = 0; i <= temp->lastIndex; i++) {
					pushBack(temp->data[i]);
				}
				temp = temp->next;
			}
		}
		return *this;
	}

	void remove(int index) {

		Node<T>* current = first;
		int nodeIndex = 0;
		while (current != nullptr && index >= current->lastIndex + 1) {
			index -= current->lastIndex + 1;
			current = current->next;
			nodeIndex++;
		}

		if (current != nullptr) {

			current->data[index].attributes.nullify();
			current->data[index].selectors.nullify();
			current->lastIndex--;
			std::cout << "deleted"<<endl;
		}
	}

	void removeAttribute(int indexSec, int indexAttr) {
		
		Node<T>* current = first;
		int nodeIndex = 0;
		while (current != nullptr && indexSec >= current->lastIndex + 1) {
			indexSec -= current->lastIndex + 1;
			current = current->next;
			nodeIndex++;
		}

		if (current != nullptr) {


			current->data[indexSec].attributes[indexAttr].name = NULL;
			current->data[indexSec].attributes[indexAttr].value = NULL;
			current->lastIndex--;
			std::cout << "deleted" << endl;
		}
	}

	void pushBack(const T& data) {
		if (last == nullptr || last->lastIndex == SIZE - 1) {

			Node<T>* newNode = new Node<T>();
			newNode->prev = last;

			if (last != nullptr) {
				last->next = newNode;
			}
			else {
				first = newNode;
			}

			last = newNode;
			size++;
		}


		last->lastIndex++;
		last->data[last->lastIndex] = data;
	}

	int getLastIndex() {
		if (last == nullptr) {
			return -1;
		}
		return last->lastIndex;
	}

	int getSize() const {
		return size;
	}

	Node<T>* getFirst() {
		return first;
	}

	Node<T>* getLast() {
		return last;
	}



};

struct Attribute {
	char *name, *value;

	Attribute() : name(new char[MAX_CHARACTERS]), value(new char[MAX_CHARACTERS]) {
		name[0] = '\0';
		value[0] = '\0';
	};

	Attribute(char* name, char* value) : Attribute() {
		strncpy(this->name, name, MAX_CHARACTERS);
		strncpy(this->value, value, MAX_CHARACTERS);
	}

	Attribute(const Attribute& attr) : Attribute() {
		strncpy(this->name, attr.name, MAX_CHARACTERS);
		strncpy(this->value, attr.value, MAX_CHARACTERS);
	}

	Attribute& operator=(const Attribute& attr) {
		if (this != &attr) {
			delete[] name;
			delete[] value;

			int nameLen = strlen(attr.name);
			int valueLen = strlen(attr.value);

			name = new char[nameLen + 1];
			strncpy(name, attr.name, nameLen + 1);

			value = new char[valueLen + 1];
			strncpy(value, attr.value, valueLen + 1);
		}
		return *this;
	}

	void setName(const char* name) {
		delete[] this->name;
		this->name = new char[strlen(name) + 1];
		strcpy(this->name, name);
	}
	void setValue(const char* value) {
		delete[] this->value;
		this->value = new char[strlen(value) + 1];
		strcpy(this->value, value);
	}
	const char* getName() const {
		return name;
	}
	const char* getValue() const {
		return value;
	}

	~Attribute() {
		delete[] name;
		delete[] value;
	}
};

struct Section {
	List<Attribute> attributes;
	List<const char*> selectors;


	void pushBack(const Attribute& attribute) {
		attributes.pushBack(attribute);
	}
	 
	void pushBack(const char* selector) {
		selectors.pushBack(selector);
	}

	List<const char*> getSelectors() const {
		return selectors;
	}

	List<Attribute> getAttributes() const {
		return attributes;
	}
};

char* resizeCharArray(char* arr, int index, int& oldSize)
{
	if (index >= oldSize) {
		oldSize = oldSize * 2;
		char* newArr = new char[oldSize];
		memcpy(newArr, arr, oldSize);
		delete[] arr;
		return newArr;
	}
	return arr;
}



char* readSelector(char& lastchar) {
	char character;
	int selectorIndex = 0;
	int selectorCurrentSize = RES_CHARACTERS;
	char* selector = new char[selectorCurrentSize];

	while (((character = getchar()) != '{')) {
		if (character == '?')
		{
			lastchar = character;
			break;
		}
		if (!isspace(character)) {
			if (character != ',') {
				selector = resizeCharArray(selector, selectorIndex, selectorCurrentSize);
				selector[selectorIndex] = character;
				selectorIndex++;
				lastchar = character;
			}
			else {
				lastchar = character;
				selector = resizeCharArray(selector, selectorIndex, selectorCurrentSize);
				selector[selectorIndex] = '\0';
				return selector;
			}
		}
	}
	lastchar = character;
	selector = resizeCharArray(selector, selectorIndex, selectorCurrentSize);
	selector[selectorIndex] = '\0';
	return selector;
}

Attribute readAttribute(char& lastchar) {
	char* name = new char[MAX_CHARACTERS];
	char* value = new char[MAX_CHARACTERS];
	char character;
	int name_index = 0;
	int value_index = 0;
	bool is_value = false;
	while ((character = getchar()) != '}') {
		if (!isspace(character)) {
			if (!is_value) {
				if (character != ':') {

					name[name_index] = character;
					name_index++;
				}
				else {
					is_value = true;
					name[name_index] = '\0';
					name_index = 0;
				}
			}
			else {
				if (character == ',') {
					value[value_index] = character;
					value_index++;
					value[value_index] = ' ';
					value_index++;
				}
				else if (character != ';') {
					value[value_index] = character;
					value_index++;
				}
				else {
					is_value = false;
					value[value_index] = '\0';
					value_index = 0;
					Attribute attr = { name, value };
					lastchar = character;
					return attr;
				}
			}
		}
		character = '\t';
		lastchar = character;
	}
	name[0] = '\0';
	value[0] = '\0';
	Attribute attr = { name, value };
	lastchar = character;
	return attr;
}

Section readSection(char& lastCharacterTop) {
	Section new_section;
	char lastCharacter = ' ';


	while (lastCharacter != '{') {

		char* selector = readSelector(lastCharacter);
		
		if (lastCharacter == '?') { 
			lastCharacterTop = lastCharacter;
			return new_section; 
		}

		new_section.selectors.pushBack(selector);
	}

	char nameVerifier[1] = {'\0'};
	char valueVerifier[1] = {'\0'};
	
	Attribute verifier = { nameVerifier,valueVerifier };
	while (lastCharacter != '}') {
		Attribute attr = readAttribute(lastCharacter);
		int indexAttr = 0;
		if (new_section.getAttributes().getFirst() != NULL && lastCharacter != '}')
		{
			Node<Attribute>* current = new_section.getAttributes().getFirst();

			while ((current->getLastIndex()) > indexAttr  && strcmp(current->getData(indexAttr).name,attr.name) != 0)
			{
				indexAttr++;
			}

			if (strcmp(current->getData(indexAttr).name, attr.name) != 0)
			{
				new_section.attributes.pushBack(attr);
			}
			else if (strcmp(current->getData(indexAttr).name, attr.name) == 0) {
				new_section.attributes[indexAttr].value = strdup(attr.value);
			}
		}
		else if(lastCharacter != '}')
		{
			new_section.attributes.pushBack(attr);
		}
	}
	lastCharacterTop = lastCharacter;
	return new_section;

}

char* readCommand() {
	char character;
	int index = 0;
	int commandSize = 3;
	char* command = new char[commandSize];
	while ((character = getchar()) != EOF) {
		if (index == 0 && character == '*') {
			command[index] = character;
			command[index + 1] = '\0';
			return  command;
		}
		if (index == 0 && character == '?') {
			command[index] = character;
			command[index + 1] = '\0';
			return  command;
		}

		if (!isspace(character))
		{
			command = resizeCharArray(command, index, commandSize);
			command[index] = character;
			index++;
		}
		else {
			command = resizeCharArray(command, index, commandSize);
			command[index] = '\0';
			return command;
		}
	}
	return command;
}

void processCommand(List<Section>& sections) {
	int index = 0;
	int indexPars = 0;
	int commandSize = 3;
	bool continueCommands = true;

	while (continueCommands) {
		char* command = readCommand();

		if (!command[0] == '\0')
		{
			if (command[0] == '*') {
				continueCommands = false;
			}
			else if (command[0] == '?') {
				//?
				int count = 0;
				int blocks = sections.getLastIndex();
				bool continueCounting = true;
				Node<Section>* current = sections.getFirst();
				while(continueCounting){
					count += current->getLastIndex()+1;
				if (current->getNext() != NULL)
				{
					current = current->getNext();
				}
				else {
					continueCounting = false;
				}
			}
				count -= 1;
				std::cout << command << " == "<< count <<endl;
			}
			else {

				char* commandP1 = new char[commandSize];
				char* commandP2 = new char[commandSize];
				char* commandP3 = new char[commandSize];

				while (command[index] != ',')
				{
					commandP1 = resizeCharArray(commandP1, indexPars, commandSize);
					commandP1[indexPars] = command[index];
					index++;
					indexPars++;
				}
				commandP1[indexPars] = '\0';
				index++;
				indexPars = 0;


				while (command[index] != ',')
				{
					commandP2 = resizeCharArray(commandP2, indexPars, commandSize);
					commandP2[indexPars] = command[index];
					index++;
					indexPars++;
				}
				commandP2[indexPars] = '\0';
				index++;
				indexPars = 0;

				while (command[index] != '\0')
				{
					commandP3 = resizeCharArray(commandP3, indexPars, commandSize);
					commandP3[indexPars] = command[index];
					index++;
					indexPars++;
				}
				commandP3[indexPars] = '\0';
				indexPars = 0;


				if (isdigit(commandP1[0]))
				{
					if (commandP2[0] == 'S')
					{
						if (commandP3[0] == '?')
						{
							//i,S,?

							int selectionIndex = (atoi(commandP1) % SIZE);
							int selectionNodeIndex = ((atoi(commandP1) - selectionIndex) / SIZE);
							bool TooBigIndex = false;

							Node<Section>* currentSec = sections.getFirst();
							for (int i = 0; i < selectionNodeIndex; i++)
							{
								if (currentSec->getNext() != NULL) {
									currentSec = currentSec->getNext();
								}
								else {
									TooBigIndex = true;
								}
							}
							if (!TooBigIndex) {
								Node<const char*>* current = currentSec->getData(selectionIndex - 1).getSelectors().getFirst();
								int count = current->getLastIndex() + 1;
								bool continueCounting = true;
								while (continueCounting) {
									if (current->getNext() != NULL)
									{
										current = current->getNext();
										count += current->getLastIndex() + 1;
									}
									else {
										continueCounting = false;
									}
								}
								std::cout << command << " == " << count << endl;
							}
						
						}
						else
						{
							//i,S,j

								int selectionIndex = (atoi(commandP1) % SIZE);
								int selectionNodeIndex = ((atoi(commandP1) - selectionIndex) /SIZE);
								bool TooBigIndex = false;
								
								Node<Section>* currentSec = sections.getFirst();
								for (int i = 0; i < selectionNodeIndex; i++)
								{
									if (currentSec->getNext()!=NULL) {
										currentSec = currentSec->getNext();
									}
									else {
										TooBigIndex = true;
									}
								}
								if (!TooBigIndex)
								{
									Node<const char*>* currentSel = currentSec->getData(selectionIndex - 1).getSelectors().getFirst();
									int selector = (atoi(commandP3) % SIZE);
									int block = ((atoi(commandP3) - selector) / SIZE);
									for (int i = 0; i < block; i++)
									{
										if (currentSec->getNext() != NULL) {
										currentSel = currentSel->getNext();
										}
										else {
											TooBigIndex = true;
											break;
										}
									}

									if (!TooBigIndex) {
										selector--;
										if (currentSel->getData(selector) != NULL)
										{
											std::cout << command << " == " << currentSel->getData(selector) << endl;
										}
									}
								}
						}
					}
					else if (commandP2[0] == 'A')
					{
						if (commandP3[0] == '?')
						{
							//i,A,?
							int selectionIndex = (atoi(commandP1) % SIZE);
							int selectionNodeIndex = ((atoi(commandP1) - selectionIndex) / SIZE);
							bool TooBigIndex = false;

							Node<Section>* currentSec = sections.getFirst();
							for (int i = 0; i < selectionNodeIndex; i++)
							{
								if (currentSec->getNext() != NULL) {
									currentSec = currentSec->getNext();
								}
								else {
									TooBigIndex = true;
								}
							}
							if (!TooBigIndex)
							{
								Node<Attribute>* current = currentSec->getData(selectionIndex - 1).getAttributes().getFirst();
								int count = current->getLastIndex() + 1;
								bool continueCounting = true;
								while (continueCounting) {
									if (current->getNext() != NULL)
									{
										current = current->getNext();
										count += current->getLastIndex() + 1;
									}
									else {
										continueCounting = false;
									}
								}
								std::cout << command << " == " << count << endl;
							}
							
						}
						else
						{
							//i,A,n

							int selectionIndex = (atoi(commandP1) % SIZE);
							int selectionNodeIndex = ((atoi(commandP1) - selectionIndex) / SIZE);
							bool TooBigIndex = false;

							Node<Section>* currentSec = sections.getFirst();
							for (int i = 0; i < selectionNodeIndex; i++)
							{
								if (currentSec->getNext() != NULL) {
									currentSec = currentSec->getNext();
								}
								else {
									TooBigIndex = true;
								}
							}
							if (!TooBigIndex)
							{
								Node<Attribute>* current = currentSec->getData(selectionIndex - 1).getAttributes().getFirst();
								const char* toFind = commandP3;
								int indexToFind = 0;
								int count = 0;
								bool flagStop = false;

								while ((strcmp(current->getData(indexToFind).name, toFind) != 0) && current->getData(indexToFind).name != NULL && flagStop == false)
								{
									if ((indexToFind + 1) % SIZE == 0)
									{
										if (current->getNext() != NULL)
										{
											current = current->getNext();
											indexToFind = 0;
										}
										else {
											flagStop = true;
										}
									}
									indexToFind++;
									count++;
								}


								if (current->getData(indexToFind).name != NULL && flagStop == false)
								{
									std::cout << command << " == " << current->getData(indexToFind).value << endl;
								}
							}
						}

						

					}
					else {
						if (commandP3[0] == '*')
						{
							
							//i,D,*

								sections.remove(atoi(commandP1)-1);
								std::cout << command << " == deleted" << endl;
							
						}
						else
						{
							
							//i,D,n
							int selectionIndex = (atoi(commandP1) % SIZE);
							int selectionNodeIndex = ((atoi(commandP1) - selectionIndex) / SIZE);
							bool TooBigIndex = false;

							Node<Section>* currentSec = sections.getFirst();
							for (int i = 0; i < selectionNodeIndex; i++)
							{
								if (currentSec->getNext() != NULL) {
									currentSec = currentSec->getNext();
								}
								else {
									TooBigIndex = true;
								}
							}
							if (!TooBigIndex)
							{
								Node<Attribute>* current = currentSec->getData(selectionIndex - 1).getAttributes().getFirst();
								const char* toFind = commandP3;
								int indexToFind = 0;
								int count = 0;
								bool flagStop = false;

								while ((strcmp(current->getData(indexToFind).name, toFind) != 0) && current->getData(indexToFind).name != NULL && flagStop == false)
								{
									if ((indexToFind + 1) % SIZE == 0)
									{
										if (current->getNext() != NULL)
										{
											current = current->getNext();
											indexToFind = 0;
										}
										else {
											flagStop = true;
										}
									}
									indexToFind++;
									count++;
								}


								if (current->getData(indexToFind).name != NULL && flagStop == false)
								{
									sections.removeAttribute(atoi(commandP1) - 1, indexToFind);
								}
							}
							
						}
					}
				}
				else
				{
					if (commandP2[0] == 'S')
					{
						//z,S,?

						Node<Section>* currentSec = sections.getLast();
						Node<const char*>* currentSel = currentSec->getData(sections.getLastIndex() - 1).getSelectors().getLast();


						const char* selector = commandP1;
						int indexSelectors = currentSel->getLastIndex();
						int indexData = (currentSec->getLastIndex()) - 1;
						int countSection = sections.getSize();
						int amountOfSelectors = 0;
						bool continueSearching = true;

						while (continueSearching)
						{
							if (strcmp(currentSel->getData(indexSelectors), selector) == 0) {
								amountOfSelectors++;
							}
							if (indexSelectors == 0)
							{
								if (currentSel->getPrev() == NULL)
								{
									if (indexData == 0) {
										if (currentSec->getPrev() == NULL)
										{
												continueSearching = false;
										}
										else {
											currentSec = currentSec->getPrev();
											indexData = (currentSec->getLastIndex());
											currentSel = currentSec->getData(indexData).getSelectors().getLast();
										}
									}
									else {
										indexData--;
										currentSel = currentSec->getData(indexData).getSelectors().getLast();
									}
								}
								else {
									currentSel = currentSel->getPrev();
								}

								indexSelectors = currentSel->getLastIndex();
							}
							else {
								indexSelectors--;
							}

						}
						std::cout << command << " == " << amountOfSelectors << endl;

						
					}
					else if (commandP2[0] == 'A')
					{
						
						//n, A, ?

						Node<Section>* currentSec = sections.getLast();
						Node<Attribute>* currentAttr = currentSec->getData(sections.getLastIndex() - 1).getAttributes().getLast();


						const char* attribute = commandP1;
						int indexAttributes = currentAttr->getLastIndex();
						int indexData = (currentSec->getLastIndex()) - 1;
						int countSection = sections.getSize();
						int amountOfAttributes = 0;
						bool continueSearching = true;

						while (continueSearching)
						{
							if (strcmp(currentAttr->getData(indexAttributes).name, attribute) == 0) {
								amountOfAttributes++;
							}
							if (indexAttributes == 0)
							{
								if (currentAttr->getPrev() == NULL)
								{
									if (indexData == 0) {
										if (currentSec->getPrev() == NULL)
										{
												continueSearching = false;
										}
										else {
											currentSec = currentSec->getPrev();
											indexData = (currentSec->getLastIndex());
											currentAttr = currentSec->getData(indexData).getAttributes().getLast();
										}
									}
									else {
										indexData--;
										currentAttr = currentSec->getData(indexData).getAttributes().getLast();
									}
								}
								else {
									currentAttr = currentAttr->getPrev();
								}

								indexAttributes = currentAttr->getLastIndex();
							}
							else {
								indexAttributes--;
							}

						}
						std::cout << command << " == " << amountOfAttributes << endl;

					}
					else {

						//z, E, n
							Node<Section>* currentSec = sections.getLast();
							Node<const char*>* currentSel = currentSec->getData(sections.getLastIndex() - 1).getSelectors().getLast();
							
							
							const char* attribute = commandP3;
							const char* selector = commandP1;
							int indexSelectors = currentSel->getLastIndex();
							int indexData = (currentSec->getLastIndex())-1;
							int countSection = sections.getSize();
							bool continueSearching = true;

							while ((strcmp(currentSel->getData(indexSelectors), selector) != 0) && continueSearching)
							{
								if (indexSelectors == 0)
								{
									if (currentSel->getPrev() == NULL)
									{
										if (indexData == 0) {
											if (currentSec->getPrev() == NULL)
											{
													continueSearching = false;
											}
											else {
												currentSec = currentSec->getPrev();
												indexData = (currentSec->getLastIndex());
												currentSel = currentSec->getData(indexData).getSelectors().getLast();
											}
										}
										else {
											indexData--;
											currentSel = currentSec->getData(indexData).getSelectors().getLast();
										}
									}
									else {
										currentSel = currentSel->getPrev();
									}
									
									indexSelectors = currentSel->getLastIndex();
								}
								else {
									indexSelectors--;
								}
								
							}
							

							Node<Attribute>* currentAtr = currentSec->getData(indexData).getAttributes().getFirst();;
							const char* toFind = commandP3;
							int indexToFind = 0;
							int count = 0;
							bool stopSearch = false;

							while ((strcmp(currentAtr->getData(indexToFind).name, toFind) != 0) && stopSearch == false)
							{
								if ((indexToFind + 1) % 8 == 0)
								{
									if (currentAtr->getNext() != NULL)
									{
										currentAtr = currentAtr->getNext();
										indexToFind = 0;
									}
									else {
										stopSearch = true;
									}
								}
								indexToFind++;
								count++;
							}


							if (currentAtr->getData(indexToFind).name != NULL && stopSearch == false)
							{
								std::cout << command << " == " << currentAtr->getData(indexToFind).value << endl;
							}
					}
				}
				index = 0;
				indexPars = 0;
				commandSize = 3;
			}
		}
	}
}

void readFull(List<Section>& sections) {
	char lastCharacter = ' ';
	while (!feof(stdin)) {

		while (lastCharacter != '?') {
			sections.pushBack(readSection(lastCharacter));
		}
		while ((lastCharacter = getchar()) == '?') {}
		processCommand(sections);
		while ((lastCharacter = getchar()) == '*') {}
	}

}

int main() {
	List<Section> sections;

	Section mySection;

	readFull(sections);

	return 0;
}