#pragma once

#include <functional>

template <typename E, int T = 1> class List {
  public:
    class Node {
      public:
        Node(Node *prev, Node *next) : prev{prev}, next{next}, count{} {
        }

        size_t get_count() const {
            return count;
        }

        void add(E element) {
            array[count] = element;
            count++;
        }

        E &get(size_t index) {
            return array[index];
        }

        void remove(size_t index) {
            for (size_t i = index; i < count - 1; i++) {
                array[i] = array[i + 1];
            }
            count--;
        }

        Node *prev;
        Node *next;

      private:
        E array[T];
        size_t count;
    };

    class Iterator {
      public:
        Iterator(Node *node, size_t index) : node{node}, index{index} {
        }

        E &operator*() {
            return node->get(index);
        }

        E *operator->() {
            return &node->get(index);
        }

        Iterator &operator++() {
            index++;
            if (index >= node->get_count()) {
                node = node->next;
                index = 0;
            }
            return *this;
        }

        bool operator==(const Iterator &other) {
            return node == other.node && index == other.index;
        }

        bool operator!=(const Iterator &other) {
            return node != other.node || index != other.index;
        }

        Node *get_node() {
            return node;
        }

        size_t get_index() {
            return index;
        }

      private:
        Node *node;
        size_t index;
    };

    List() : size{}, head{}, tail{} {
    }

    ~List() {
        Node *node = head;
        while (node != nullptr) {
            Node *next = node->next;
            delete node;
            node = next;
        }
    }

    size_t get_size() {
        return size;
    }

    void add(E element) {
        if (tail == nullptr) {
            tail = new Node(nullptr, nullptr);
            head = tail;
        } else if (tail->get_count() == T) {
            tail->next = new Node(tail, nullptr);
            tail = tail->next;
        }
        tail->add(element);
        size++;
    }

    E &get(size_t index) {
        Node *node = head;
        while (index >= node->get_count()) {
            index -= node->get_count();
            node = node->next;
        }
        return node->get(index);
    }

    void remove(size_t index) {
        Node *node = head;
        while (index >= node->get_count()) {
            index -= node->get_count();
            node = node->next;
        }
        remove(node, index);
    }

    void remove(Iterator iterator) {
        remove(iterator.get_node(), iterator.get_index());
    }

    bool contains(E &element) {
        return find(element) != end();
    }

    Iterator find(E &element) {
        Node *node = head;
        while (node != nullptr) {
            for (size_t i = 0; i < node->get_count(); i++) {
                if (node->get(i) == element) {
                    return Iterator(node, i);
                }
            }
            node = node->next;
        }
        return end();
    }

    Iterator find_if(std::function<bool(E &)> predicate) {
        Node *node = head;
        while (node != nullptr) {
            for (size_t i = 0; i < node->get_count(); i++) {
                if (predicate(node->get(i))) {
                    return Iterator(node, i);
                }
            }
            node = node->next;
        }
        return end();
    }

    Iterator begin() {
        return Iterator(head, 0);
    }

    Iterator end() {
        return Iterator(nullptr, 0);
    }

  private:
    void remove(Node *node, size_t index) {
        node->remove(index);
        if (node->get_count() == 0) {
            if (node->prev != nullptr) {
                node->prev->next = node->next;
            } else {
                head = node->next;
            }
            if (node->next != nullptr) {
                node->next->prev = node->prev;
            } else {
                tail = node->prev;
            }
            delete node;
        }
        size--;
    }

    size_t size;

    Node *head;
    Node *tail;
};
