#pragma once

#include "parser.hpp"

class Processor {
  public:
    void start();

  private:
    bool switch_sections(const String &line);
    void read_css(const String &line);
    void exec_command(const String &line);
    void exec_composite_command(const String &line);

    void start_commands();
    void resume_css();
    void print_sections_count();
    void print_selectors_count(size_t section);
    void print_attributes_count(size_t section);
    void print_selector(size_t section, size_t selector);
    void print_attribute(size_t section, const String &name);
    void print_attribute_occurrences(const String &name);
    void print_selector_occurrences(const String &selector);
    void print_attribute_for_selector(const String &selector, const String &name);
    void remove_section(size_t section);
    void remove_attribute_from_section(size_t section, const String &name);

    bool css_section;
    Parser *parser;
    List<Ptr<Section>, 8> sections;
};
