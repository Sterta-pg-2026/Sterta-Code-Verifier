#include "processor.hpp"

int main() {
    Processor processor;
    processor.start();
}
