#include "processor.hpp"

#include <algorithm>
#include <iostream>

void Processor::start() {
    css_section = true;
    parser = new Parser();
    String line;
    while (getline(std::cin, line)) {
        if (line.is_empty() || switch_sections(line)) {
            continue;
        }
        if (css_section) {
            read_css(line);
        } else {
            exec_command(line);
        }
    }
}

bool Processor::switch_sections(const String &line) {
    if (line == "****") {
        resume_css();
        return true;
    }
    if (line == "????") {
        start_commands();
        return true;
    }
    return false;
}

void Processor::read_css(const String &line) {
    parser->push_string(line);
    if (line.find('}') != String::npos) {
        sections.add(parser->next_section());
        parser->clear();
    }
}

void Processor::exec_command(const String &line) {
    if (line == "?") {
        print_sections_count();
    } else {
        exec_composite_command(line);
    }
}

void Processor::exec_composite_command(const String &line) {
    String first = line.substr(0, line.find(','));
    char type = line[line.find(',') + 1];
    String second = line.substr(line.rfind(',') + 1, String::npos);

    switch (type) {
    case 'S':
        if (first.is_number()) {
            if (second == "?") {
                print_selectors_count((size_t)first.to_int());
            } else {
                print_selector((size_t)first.to_int(), (size_t)second.to_int());
            }
        } else {
            print_selector_occurrences(first);
        }
        break;
    case 'A':
        if (first.is_number()) {
            if (second == "?") {
                print_attributes_count((size_t)first.to_int());
            } else {
                print_attribute((size_t)first.to_int(), second);
            }
        } else {
            print_attribute_occurrences(first);
        }
        break;
    case 'E':
        print_attribute_for_selector(first, second);
        break;
    case 'D':
        if (second == "*") {
            remove_section((size_t)first.to_int());
        } else {
            remove_attribute_from_section((size_t)first.to_int(), second);
        }
        break;
    }
}

void Processor::start_commands() {
    while (Ptr<Section> section = parser->next_section()) {
        sections.add(section);
    }
    css_section = false;
}

void Processor::resume_css() {
    parser->clear();
    css_section = true;
}

void Processor::print_sections_count() {
    std::cout << "? == " << sections.get_size() << std::endl;
}

void Processor::print_selectors_count(size_t section) {
    if (section > sections.get_size()) {
        return;
    }
    std::cout << section << ",S,? == " << sections.get(section - 1)->selectors.get_size()
              << std::endl;
}

void Processor::print_attributes_count(size_t section) {
    if (section > sections.get_size()) {
        return;
    }
    std::cout << section << ",A,? == " << sections.get(section - 1)->attributes.get_size()
              << std::endl;
}

void Processor::print_selector(size_t section, size_t selector) {
    if (section > sections.get_size()) {
        return;
    }
    Ptr<Section> section_ptr = sections.get(section - 1);
    if (selector > section_ptr->selectors.get_size()) {
        return;
    }
    std::cout << section << ",S," << selector << " == " << section_ptr->selectors.get(selector - 1)
              << std::endl;
}

void Processor::print_attribute(size_t section, const String &name) {
    if (section > sections.get_size()) {
        return;
    }
    Ptr<Section> section_ptr = sections.get(section - 1);
    for (auto &attribute : section_ptr->attributes) {
        if (attribute.name == name) {
            std::cout << section << ",A," << name << " == " << attribute.value << std::endl;
            return;
        }
    }
}

void Processor::print_attribute_occurrences(const String &name) {
    int occurrences = 0;
    for (auto &section : sections) {
        for (auto &attribute : section->attributes) {
            if (attribute.name == name) {
                occurrences++;
            }
        }
    }
    std::cout << name << ",A,? == " << occurrences << std::endl;
}

void Processor::print_selector_occurrences(const String &selector) {
    int occurrences = 0;
    for (auto &section : sections) {
        for (auto &section_selector : section->selectors) {
            if (section_selector == selector) {
                occurrences++;
            }
        }
    }
    std::cout << selector << ",S,? == " << occurrences << std::endl;
}

void Processor::print_attribute_for_selector(const String &selector, const String &name) {
    String value;
    for (auto &section : sections) {
        for (auto &section_selector : section->selectors) {
            if (section_selector == selector) {
                for (auto &attribute : section->attributes) {
                    if (attribute.name == name) {
                        value = attribute.value;
                    }
                }
            }
        }
    }
    if (!value.is_empty()) {
        std::cout << selector << ",E," << name << " == " << value << std::endl;
    }
}

void Processor::remove_section(size_t section) {
    if (section > sections.get_size()) {
        return;
    }
    sections.remove(section - 1);
    std::cout << section << ",D,* == deleted" << std::endl;
}

void Processor::remove_attribute_from_section(size_t section, const String &name) {
    if (section > sections.get_size()) {
        return;
    }
    Ptr<Section> section_ptr = sections.get(section - 1);

    auto it = section_ptr->attributes.find_if(
        [&name](Attribute &attribute) { return attribute.name == name; });

    if (it == section_ptr->attributes.end()) {
        return;
    }
    section_ptr->attributes.remove(it);

    if (section_ptr->attributes.get_size() == 0) {
        sections.remove(section - 1);
    }
    std::cout << section << ",D," << name << " == deleted" << std::endl;
}
