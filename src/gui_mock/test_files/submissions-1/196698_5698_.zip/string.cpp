#include "string.hpp"

#include <cstring>
#include <limits>

const size_t String::npos = std::numeric_limits<size_t>::max();

String::String() {
    size = 0;
    capacity = 0;
    string = copy_string("");
}

String::String(String &&other) {
    size = other.size;
    capacity = other.capacity;
    string = other.string;
    other.size = 0;
    other.capacity = 0;
    other.string = NULL;
}

String::String(const char *string) {
    size = strlen(string);
    capacity = size;
    this->string = copy_string(string);
}

String::String(const String &other) {
    size = other.size;
    capacity = other.size;
    string = copy_string(other.string);
}

String::~String() {
    if (string != NULL) {
        delete[] string;
    }
}

String &String::operator=(String &&other) {
    size = other.size;
    capacity = other.capacity;
    free(string);
    string = other.string;
    other.size = 0;
    other.capacity = 0;
    other.string = NULL;
    return *this;
}

String &String::operator=(const String &other) {
    size = other.size;
    capacity = other.size;
    delete[] string;
    string = copy_string(other.string);
    return *this;
}

bool String::is_empty() const {
    return size == 0;
}

size_t String::get_size() const {
    return size;
}

bool String::operator==(const String &other) const {
    return strcmp(string, other.string) == 0;
}

void String::trim() {
    size_t first = 0;
    while (isspace(string[first])) {
        first++;
    }
    size_t len = size - first;
    while (len > 0 && isspace(string[first + len - 1])) {
        len--;
    }
    *this = substr(first, len);
}

void String::append(const String &other) {
    char *orig = string;

    size_t new_capacity = size + other.size;
    if (capacity < new_capacity) {
        if (new_capacity < capacity * 4) {
            new_capacity = capacity * 4;
        }
        string = new char[new_capacity + 1];
        capacity = new_capacity;
    }

    string[size + other.size] = '\0';
    strcpy_s(string, size + other.size + 1, orig);
    strcpy_s(string + size, other.size + 1, other.string);
    size = size + other.size;
    if (string != orig) {
        delete[] orig;
    }
}

char String::operator[](size_t pos) const {
    return string[pos];
}

String String::substr(size_t pos, size_t len) const {
    if (len > size - pos) {
        len = size - pos;
    }
    char *substr = new char[len + 1];
    substr[len] = '\0';
    strncpy_s(substr, len + 1, string + pos, len);
    String result(substr);
    delete[] substr;
    return result;
}

size_t String::find(char ch, size_t start) const {
    char *pos = strchr(string + start, ch);
    if (pos == NULL) {
        return npos;
    }
    return (size_t)(pos - string);
}

size_t String::rfind(char ch, size_t start) const {
    char *pos = strrchr(string + start, ch);
    if (pos == NULL) {
        return npos;
    }
    return (size_t)(pos - string);
}

size_t String::find_first_of(const char *chars, size_t start) const {
    size_t pos = start;
    size_t count = strlen(chars);
    while (pos != size) {
        bool found = false;
        for (size_t i = 0; i < count; i++) {
            if (string[pos] == chars[i]) {
                found = true;
                break;
            }
        }
        if (found) {
            break;
        }
        pos++;
    }
    if (pos == size) {
        return npos;
    }
    return pos;
}

bool String::is_number() const {
    for (size_t i = 0; i < size; i++) {
        if (!isdigit(string[i])) {
            return false;
        }
    }
    return true;
}

int String::to_int() const {
    return atoi(string);
}

char *String::copy_string(const char *string) {
    size_t len = strlen(string);
    char *result = new char[len + 1];
    result[len] = '\0';
    strcpy_s(result, len + 1, string);
    return result;
}

std::ostream &operator<<(std::ostream &os, const String &string) {
    os << string.string;
    return os;
}

std::istream &getline(std::istream &is, String &string) {
    static const size_t bufsize = 512;
    char buf[bufsize];

    string = String("");

    is.getline(buf, bufsize);
    string.append(String(buf));
    while (!is.eof() && is.fail()) {
        is.clear();
        is.getline(buf, bufsize);
        string.append(String(buf));
    }
    return is;
}
