#pragma once

#include <cstddef>

template <typename T> class Ptr {
  public:
    Ptr() : ptr{nullptr}, counter{nullptr} {
    }

    Ptr(T *ptr) : ptr{ptr}, counter{new size_t{1}} {
    }

    Ptr(const Ptr &other) : ptr{other.ptr}, counter{other.counter} {
        (*counter)++;
    }

    Ptr(Ptr &&other) : ptr{other.ptr}, counter{other.counter} {
        other.ptr = nullptr;
        other.counter = nullptr;
    }

    ~Ptr() {
        free();
    }

    Ptr &operator=(const Ptr &other) {
        if (this != &other) {
            free();
            ptr = other.ptr;
            counter = other.counter;
            (*counter)++;
        }
        return *this;
    }

    Ptr &operator=(Ptr &&other) {
        if (this != &other) {
            free();
            ptr = other.ptr;
            counter = other.counter;
            other.ptr = nullptr;
            other.counter = nullptr;
        }
        return *this;
    }

    T &operator*() {
        return *ptr;
    }

    T *operator->() {
        return ptr;
    }

    operator bool() const {
        return ptr != nullptr;
    }

  private:
    void free() {
        if (counter != nullptr) {
            (*counter)--;
            if (*counter == 0) {
                delete ptr;
                delete counter;
            }
        }
    }

    T *ptr;
    size_t *counter;
};