#pragma once

#include <iostream>

class String {
  public:
    static const size_t npos;

    String();
    String(String &&other);
    String(const char *string);
    String(const String &other);
    ~String();

    String &operator=(String &&other);
    String &operator=(const String &other);

    bool is_empty() const;
    size_t get_size() const;

    bool operator==(const String &other) const;

    void trim();
    void append(const String &other);

    char operator[](size_t pos) const;
    String substr(size_t pos, size_t len) const;

    size_t find(char ch, size_t start = 0) const;
    size_t rfind(char ch, size_t start = 0) const;
    size_t find_first_of(const char *chars, size_t start = 0) const;

    bool is_number() const;
    int to_int() const;

    friend std::ostream &operator<<(std::ostream &os, const String &string);

  private:
    char *copy_string(const char *string);

    size_t size;
    size_t capacity;
    char *string;
};

std::istream &getline(std::istream &is, String &string);
