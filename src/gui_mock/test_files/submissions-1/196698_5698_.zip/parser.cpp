#include "parser.hpp"

void Parser::push_string(const String &string) {
    buffer.append(string);
}

Ptr<Section> Parser::next_section() {
    section = Ptr<Section>(new Section());

    if (!parse_section()) {
        return nullptr;
    }

    return section;
}

void Parser::clear() {
    buffer = String();
    pos = 0;
}

void Parser::skip_whitespace() {
    while (pos < buffer.get_size() && isspace(buffer[pos]) != 0) {
        pos++;
    }
}

bool Parser::parse_section() {
    skip_whitespace();

    parse_selectors();
    if (buffer[pos] != '{') {
        return false;
    }
    pos++;

    parse_attributes();
    skip_whitespace();
    if (buffer[pos] != '}') {
        return false;
    }
    pos++;

    return true;
}

void Parser::parse_selectors() {
    while (buffer[pos] != '{' && parse_selector()) {
        if (buffer[pos] == ',') {
            pos++;
        }
        skip_whitespace();
    }
}

void Parser::parse_attributes() {
    while (buffer[pos] != '}' && parse_attribute()) {
        if (buffer[pos] == ';') {
            pos++;
        }
        skip_whitespace();
    }
}

bool Parser::parse_selector() {
    size_t delim = buffer.find_first_of(",{", pos);
    if (delim == String::npos) {
        return false;
    }

    String selector = buffer.substr(pos, delim - pos);
    selector.trim();

    if (selector.is_empty()) {
        return false;
    }

    pos = delim;

    if (!section->selectors.contains(selector)) {
        section->selectors.add(selector);
    }

    return true;
}

bool Parser::parse_attribute() {
    size_t delim = buffer.find(':', pos);
    if (delim == String::npos) {
        return false;
    }

    String name = buffer.substr(pos, delim - pos);
    name.trim();

    if (name.is_empty()) {
        return false;
    }

    pos = delim + 1;
    delim = buffer.find_first_of(";}", pos);
    if (delim == String::npos) {
        return false;
    }

    String value = buffer.substr(pos, delim - pos);
    value.trim();

    if (value.is_empty()) {
        return false;
    }

    pos = delim;

    auto it =
        section->attributes.find_if([&name](const Attribute &attr) { return attr.name == name; });

    if (it != section->attributes.end()) {
        it->value = value;
        return true;
    }
    section->attributes.add({name, value});

    return true;
}
