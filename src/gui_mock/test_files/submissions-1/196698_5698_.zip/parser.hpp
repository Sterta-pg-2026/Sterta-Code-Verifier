#pragma once

#include "list.hpp"
#include "ptr.hpp"
#include "string.hpp"

struct Attribute {
    String name;
    String value;
};

struct Section {
    List<String> selectors;
    List<Attribute> attributes;
};

class Parser {
  public:
    void push_string(const String &string);
    Ptr<Section> next_section();
    void clear();

  private:
    void skip_whitespace();
    bool parse_section();
    void parse_selectors();
    void parse_attributes();
    bool parse_selector();
    bool parse_attribute();

    size_t pos;
    String buffer;
    Ptr<Section> section;
};
