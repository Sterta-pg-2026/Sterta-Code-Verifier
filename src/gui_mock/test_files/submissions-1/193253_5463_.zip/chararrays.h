#pragma once
#include <cstring>

//Additional cstring (char* array) functions for needs of the project

//Casual getline, but for char* instead of string container
char* chArrGetLine(FILE* stream, char del) {
	int chArrLen = 8;
	char* line = (char*)malloc(sizeof(char) * chArrLen);
	char ch = getc(stream);
	int i = 0;
	while (ch != '\n' && ch != EOF && ch!=del) {
		if (i == chArrLen) {
			chArrLen++;
			line = (char*)realloc(line, (sizeof(char)*chArrLen)+8);
		}
		line[i] = ch;
		i++;
		ch = getc(stream);
	}
	line[i] = '\0';
	return line;
}

//This function works similarly as getline, but it is not limited by newlines
//In other words: it reads input char by char until delimiter or EOF
char* chArrGetAll(FILE* stream, char del) {
	int chArrLen = 8;
	char* arr = (char*)malloc(sizeof(char) * chArrLen);
	char ch = getc(stream);
	int i = 0;
	while (ch != EOF && ch != del) {
		if (i == chArrLen) {
			chArrLen++;
			arr = (char*)realloc(arr, sizeof(char) * chArrLen+8);
		}
		arr[i] = ch;
		i++;
		ch = getc(stream);
	}
	arr[i] = '\0';
	return arr;
}

//Counting occurence of a given char in a string,
//Useful for establishing amount of items on list
int chArrCount(char* arr, char ch, char del) {
	int i = 0, j = 0;
	while (arr[i]) {
		if (arr[i] == del) {
			break;
		}
		i++;
		if (arr[i] == ch) {
			j++;
		}
	}
	return j;
}

//Here removing every occurence of a given character,
//With this, program removes /n and /t from CSS input
void chArrPurify(char* arr, char ch) {
	int i, j, length = strlen(arr);
	for (i = 0; i < length; i++) {
		if (arr[i] == ch) {
			for (j = i; j < length; j++) {
				arr[j] = arr[j + 1];
			}
			length--;
			i--;
		}
	}
}

//Removing useless spaces at the end of string, useful for further comparison with
//e.g. search pattern
void chArrRemoveSpacesFromEnd(char* arr) {
	int i = strlen(arr) - 1;
	while (i >= 0 && arr[i] == ' ') {
		i--;
	}
	arr[i + 1] = '\0';
	
}