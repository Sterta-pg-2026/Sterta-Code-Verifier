#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstring>
#include "structs.h"
#include "chararrays.h"

using namespace std;

//Main parsing part - given string is transformed into a block structure before
//putting it into doubly-linked list
block transformStringToBlock(char* string) {
	block b;
	b.selectors = initializeNode();
	b.attrs = initializeNode();
	b.vals = initializeNode();
	int nofSel = chArrCount(string, ',','{');
	int nofAttsVals = 2*chArrCount(string, ':','\0');
	string = strtok(string, ",{");
	for (int i = 0; i < nofSel; i++) {
		if (chArrCount(string, ':', '\0') > 0) {
			nofAttsVals -= 2;
		}
		chArrRemoveSpacesFromEnd(string);
		singleListPush(&(b.selectors), string, SEL);
		string = strtok(NULL, ",{");
	}
	if (chArrCount(string, ':', '\0') > 0) {
		nofAttsVals -= 2;
	}
	chArrRemoveSpacesFromEnd(string);
	singleListPush(&(b.selectors), string, SEL);
	readType type = ATT;
	char* del = (char*)":";
	listNode** list = &(b.attrs);
	bool duplicate;
	for (int j = 0; j < nofAttsVals; j++) {
		if (type == ATT) {
			del = (char*)":";
			list = &(b.attrs);
		}
		else {
			del = (char*)";}";
			list = &(b.vals);
		}
		string = strtok(NULL, del);
		if (string != NULL) {
			chArrRemoveSpacesFromEnd(string);
			if (type == ATT) {
				duplicate = isDuplicate(list, string);
				if (duplicate == false) {
					singleListPush(list, string, type);
				}
			}
			else if (type == VAL) {
				if (duplicate == false) {
					singleListPush(list, string, type);
				}
				duplicate = false;
			}
		}
		type = switchType(type);
	}
	return b;
}

//Adding extra CSS blocks to the list from given stream after **** signal
void addCSS(FILE* stream, dblNode** css) {
	char* rawCSS = chArrGetAll(stream, '?');
	chArrPurify(rawCSS,'\n');
	chArrPurify(rawCSS,'\t');
	char* rawBlock = strtok(rawCSS, "}");
	char* restOfData = strtok(NULL, "?");
	block* blk = new block;
	dblNode* node = *css;
	while (rawBlock != NULL) {
		*blk = transformStringToBlock(rawBlock);
		while (node->usedBlocks == MAX_BLOCKS) {
			if (node->nxt != NULL) {
				node = node->nxt;
			}
			else {
				node->nxt = initializeDblNode();
				dblListPush(css,node->nxt);
				node = node->nxt;
				break;
			}
		}
		for (int i = 0; i < MAX_BLOCKS; i++) {
			if (i == node->usedBlocks) {
				node->blocks[i] = *blk;
				node->usedBlocks++;
				break;
			}
		}
		rawBlock = strtok(restOfData, "}");
		restOfData = strtok(NULL, "?");
	}
}

//"?" command for calculating amount of blocks in the list
int countBlocks(dblNode** list) {
	dblNode* n = *list;
	int res = n->usedBlocks;
	while (true) {
	if (n->nxt != NULL) {
		n = n->nxt;
		res += n->usedBlocks;
	}
	else break;
}
return res;
}

//Counting amount of selectors/attributes which I name as items in a single block 
int countItemsInBlock(int i, dblNode** list, readType type) {
	dblNode* tmp = *list;
	listNode* tmp2 = initializeNode();
	tmp2 = findBlock(i, tmp2, list, type);
	int res = 1;
	while (tmp2->nxt != NULL) {
		res++;
		tmp2 = tmp2->nxt;
	}
	return res;
}

//Counting occurences of a given item (selector or attribute)
int countOccurencesByName(char* name, dblNode** list, readType type) {
	dblNode* tmp = *list;
	listNode* tmp2 = initializeNode();
	int nofBlks = countBlocks(list);
	int res = 0;
	for (int i = 1; i <= nofBlks; i++) {
		tmp2 = findBlock(i, tmp2, list, type);
		if (tmp2->data == NULL) {
			continue;
		}
		while (tmp2->nxt != NULL) {
			chArrRemoveSpacesFromEnd(tmp2->data);
			if (strcmp(tmp2->data, name) == 0) {
				res++;
			}
			tmp2 = tmp2->nxt;
		}
		chArrRemoveSpacesFromEnd(tmp2->data);
		if (strcmp(tmp2->data, name) == 0) {
			res++;
		}
	}
	return res;
}

//Finding an item (selector or attribute) of a given index j in the i=th block
char* findItem(int i, int j, dblNode** list, readType type) {
	dblNode* tmp = *list;
	listNode* tmp2 = initializeNode();
	tmp2 = findBlock(i, tmp2, list, type);
	if (tmp2->data == NULL) {
		return NULL;
	}
	int k = 1;
	while (tmp2->nxt != NULL) {
		if (k == j) {
			break;
		}
		k++;
		tmp2 = tmp2->nxt;
	}
	if (k == j) {
		char* dest = new char[strlen(tmp2->data)];
		dest = strcpy(dest, tmp2->data);
		return dest;
	}
	return NULL;
}

//Finding a value of a prticular attribute
char* findValueByAttribute(int i, char* attName, dblNode** list) {
	dblNode* tmp = *list;
	listNode* tmp2 = initializeNode();
	tmp2 = findBlock(i, tmp2, list, ATT);
	if (tmp2->data == NULL) {
		return NULL;
	}
	int k = 1;
	while (tmp2->nxt != NULL && strcmp(tmp2->data,attName)!=0) {
		k++;
		if (strcmp(attName, tmp2->data) == 0) {
			break;
		}
		tmp2 = tmp2->nxt;
	}
	if (strcmp(attName, tmp2->data) == 0) {
		tmp2 = initializeNode();
		tmp2 = findBlock(i, tmp2, list, VAL);
		if (tmp2->data == NULL) {
			return NULL;
		}
		for (int l = 1; l < k; l++) {
			if (tmp2->nxt == NULL) {
				return NULL;
			}
			tmp2 = tmp2->nxt;
		}
		char* dest = new char[strlen(tmp2->data)];
		dest = strcpy(dest, tmp2->data);
		return dest;

	}
	return NULL;
}

//As the name suggests ;) , performing the search for a value of a given attribute in
//block containing given selector
char* E_Command(char* selector, char* attribute, dblNode** list) {
	listNode* tmp2 = initializeNode();
	int nofBlks = countBlocks(list), j;
	char* dest = NULL;
	for (int i = 1; i <= nofBlks; i++) {
		tmp2 = findBlock(i, tmp2, list, SEL);
		if (tmp2->data == NULL) {
			continue;
		}
		while (tmp2->nxt != NULL) {
			if (strcmp(tmp2->data, selector) == 0) {
				break;
			}
			tmp2 = tmp2->nxt;
		}
		if (strcmp(tmp2->data, selector)!=0) {
			continue;
		}	
		tmp2 = findBlock(i, tmp2, list, ATT);
		j = 1;
		while (tmp2->nxt != NULL) {
			if (strcmp(tmp2->data, attribute) == 0) {
				break;
			}
			j++;
			tmp2 = tmp2->nxt;
		}
		if (strcmp(tmp2->data, attribute) != 0) {
			continue;
		}
		tmp2 = findBlock(i, tmp2, list, VAL);
		for (int k = 1; k < j; k++) {
			tmp2 = tmp2->nxt;
		}
		dest = new char[strlen(tmp2->data)];
		dest = strcpy(dest, tmp2->data);
	}
	return dest;
}

//Deletion (zeroing) of a given attribute (includes deletion of its value)
bool deleteAttribute(int i, char* name, dblNode** list) {
	listNode* tmp = initializeNode();
	listNode* tmpValue = initializeNode();
	listNode* listHead = initializeNode();
	listNode* valListHead = initializeNode();
	listNode* beforeTmp = initializeNode();
	listNode* beforeTmpVal = initializeNode();
	int j;
	tmp = findBlock(i, tmp, list, ATT);
	tmpValue = findBlock(i, tmp, list, VAL);
	if (strcmp(tmp->data, name) == 0) {
		deleteNode(&tmp, tmp, NULL);
		deleteNode(&tmpValue, tmpValue, NULL);
		return true;
	}
	else if (tmp->nxt == NULL && strcmp(tmp->data, name) != 0) {
		return false;
	}
	j = 1;
	listHead = tmp;
	valListHead = tmpValue;
	while (tmp->nxt != NULL) {
		if (strcmp(tmp->data, name) == 0) {
			deleteNode(&listHead, tmp, beforeTmp);
			for (int k = 1; k < j; k++) {
				beforeTmpVal = tmpValue;
				tmpValue = tmpValue->nxt;
			}
			deleteNode(&valListHead, tmpValue, beforeTmpVal);
			return true;
		}
		beforeTmpVal = tmpValue;
		beforeTmp = tmp;
		tmpValue = tmpValue->nxt;
		tmp = tmp->nxt;
		j++;
	}
	if (strcmp(tmp->data, name) == 0) {
		deleteNode(&listHead, tmp, beforeTmp);
		deleteNode(&valListHead, tmpValue, beforeTmpVal);
		return true;
	}
	return false;
}

//Checking if the given block can be nulled because of being empty
bool checkBlockIfEmpty(int i, dblNode** list) {
	listNode* tmp = initializeNode();
	tmp = findBlock(i, tmp, list, ATT);
	if (tmp->data == NULL) {
		return true;
	}
	else return false;
}

//Main function for reading starting css list and handling input for
//commands with their arguments
int main() {
	//Starting CSS
	char* cssStr = chArrGetAll(stdin, '?');
	chArrPurify(cssStr, '\n');
	chArrPurify(cssStr, '\t');
	char* blkStr = strtok(cssStr, "}");
	char* rest = strtok(NULL, "?");
	block b;
	dblNode* css;
	dblNode* cssHead;
	cssHead = initializeDblNode();
	while (blkStr != NULL) {
		css = initializeDblNode();
		b = transformStringToBlock(blkStr);
		if (b.attrs->data != NULL && css->usedBlocks == 0) {
			css->usedBlocks++;
			css->blocks[0] = b;
		}
		for (int i = 1; i < MAX_BLOCKS; i++) {
			blkStr = strtok(rest, "}");
			rest = strtok(NULL, "?");
			if (blkStr != NULL) {
				b = transformStringToBlock(blkStr);
				css->usedBlocks++;
				css->blocks[i] = b;
			}
			else break;
		}
		dblListPush(&(cssHead), css);
		blkStr = strtok(rest, "}");
		rest = strtok(NULL, "?");
	}
	//Command handling inside a loop, continue is used here for preparing
	//program for the next command by skipping the current one if necessary
	//This part handles also output of the commands
	char* command = chArrGetLine(stdin, '\0');
	char* commArgs[2];
	bool oneEmpty = false;
	while (true) {
		command = chArrGetLine(stdin, '\n');
		if (strcmp(command,"") == 0) {
			if (oneEmpty == true) {
				return 0;
			}
			else {
				oneEmpty = true;
				continue;
			}
		}
		else {
			oneEmpty = false;
		}
		if (strcmp("?", command) == 0) {
			cout << "? == " << countBlocks(&(cssHead)) << endl;
		}
		else if (strcmp("****", command) == 0) {
			addCSS(stdin, &(cssHead));
			command = chArrGetLine(stdin, '\n');
			continue;
		}
		else {
			commArgs[0] = strtok(command, ",");
			command = strtok(NULL, ",");
			if (command == NULL) {
				return 0;
			}
			commArgs[1] = strtok(NULL, ",");
			if (strtok(NULL, ",") != NULL) {
				continue;
			}
			if (strcmp("S", command) == 0 || strcmp("A", command)==0) {
				if (((*(commArgs[0]) - '0') >= 0) &&(*(commArgs[0]) - '0') <= countBlocks(&(cssHead))) {
					readType type;
					if (strcmp("S", command) == 0) {
						type = SEL;
					}
					else {
						type = ATT;
					}
					if (strcmp("?", commArgs[1]) == 0) {
						int nofOccs = countItemsInBlock(atoi(commArgs[0]), &(cssHead), type);
						if (nofOccs == 0) {
							continue;
						}
						cout << commArgs[0] << "," << command << "," << commArgs[1] << " == " << nofOccs << endl;
					}
					else if (*(commArgs[1]) - '0' >= 0 && *(commArgs[1]) - '0' <= 9) {
						char* s = NULL;
						s = findItem(*(commArgs[0])-'0', *(commArgs[1]) - '0', &(cssHead), type);
						if (s == NULL) {
							continue;
						}
						else {
							cout << commArgs[0] << "," << command << "," << commArgs[1] << " == " << s << endl;
						}
					}
					else {
						char* s = NULL;
						s = findValueByAttribute(*(commArgs[0]) - '0', commArgs[1], &(cssHead));
						if (s == NULL) {
							continue;
						}
						else {
							cout << commArgs[0] << "," << command << "," << commArgs[1] << " == " << s << endl;
						}
					}
				}
				else if (strcmp(commArgs[0],"") != 0 && (*(commArgs[0])<'0' || *(commArgs[0])>'9')) {
					readType type2 = SEL;
					if (strcmp("S", command) == 0) {
						type2 = SEL;
					}
					else if (strcmp("A", command) == 0) {
						type2 = ATT;
					}
					int nofOccs = 0;
					nofOccs = countOccurencesByName(commArgs[0], &(cssHead), type2);
					cout << commArgs[0] << "," << command << "," << commArgs[1] << " == " << nofOccs << endl;
				}
				else continue;
			}
			else if (strcmp("E", command) == 0) {
				char* s = NULL;
				s = E_Command(commArgs[0], commArgs[1], &(cssHead));
				if (s == NULL) {
					continue;
				}
				cout << commArgs[0] << "," << command << "," << commArgs[1] << " == " << s << endl;
			}
			else if (strcmp("D", command) == 0) {
				bool deleted = false;
				if (strcmp(commArgs[1], "*") == 0) {
					deleteBlock(*(commArgs[0]) - '0', &(cssHead));
					deleted = true;
				}
				else if (strcmp(commArgs[1], "") != 0) {
					deleted = deleteAttribute(*(commArgs[0]) - '0', commArgs[1], &(cssHead));
					if (checkBlockIfEmpty(*(commArgs[0]) - '0', &(cssHead))==true) {
						deleteBlock(*(commArgs[0]) - '0', &(cssHead));
						deleted = true;
					}
				}
				else continue;
				if (deleted==true) {
					cout << commArgs[0] << "," << command << "," << commArgs[1] << " == deleted" << endl;
				}
			}
		}
	}
	return 0;
}