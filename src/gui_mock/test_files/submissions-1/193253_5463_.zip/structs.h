#pragma once
#include "chararrays.h"
#include <cstring>

#define MAX_BLOCKS 8

using namespace std;

enum readType {
	ATT=0,
	VAL=1,
	SEL=2
};

readType switchType(int type) {
	if (type == ATT) {
		return VAL;
	}
	else return ATT;
}
//Structures representing a singly-linked list node;
struct listNode {
	char* data;
	listNode* nxt;
};

//Structure representing a block (array element)
struct block {
	listNode* selectors = NULL;
	listNode* attrs = NULL;
	listNode* vals = NULL;
};

//doubly-liked list node including pointer to an array of and the counter of currently used block structure fields
struct dblNode {
	dblNode* prv;
	int usedBlocks;
	block* blocks;
	dblNode* nxt;
};
//linked list implementation for listNode's:

//node initialization, these two act as contructors
//preventing (partially) from read access vialation exceptions
listNode* initializeNode() {
	listNode* node = new listNode;
	node->data = NULL;
	node->nxt = NULL;
	return node;
}

dblNode* initializeDblNode() {
	dblNode* node = new dblNode;
	node->blocks = new block[MAX_BLOCKS];
	node->nxt = NULL;
	node->prv = NULL;
	node->usedBlocks = 0;
	return node;
}

//pushing a data into a node which is placed at the end of the list
void singleListPush(listNode** head, char* data, readType type) {
	listNode* node = new listNode;
	node->data = new char;
	node->data = data;
	node->nxt = NULL;
	if ((*head)->data == NULL) {
		*head = node;
	}
	else {
		listNode* tmp = *head;
		while (tmp->nxt != NULL) {
			tmp = tmp->nxt;
		}
		tmp->nxt = node;
	}
}

void dblListPush(dblNode** head, dblNode* n) {
	if ((*head)->usedBlocks == NULL) {
		n->prv = NULL;
		n->nxt = NULL;
		*head = n;
	}
	else if ((*head)->nxt == NULL) {
		n->prv = *head;
		n->nxt = NULL;
		(*head)->nxt = n;
	}
	else {
		dblNode* tmp = initializeDblNode();
		tmp = *head;
		while (tmp->nxt != NULL) {
			tmp = tmp->nxt;
		}
		tmp->nxt = n;
		n->prv = tmp;
		n->nxt = NULL;
	}
}

//Find i-th block on the whole list, very useful for commands such as i,S,?
listNode* findBlock(int i, listNode* tmp , dblNode** list, readType type) {
	dblNode* node = initializeDblNode();
	node = *list;
	while (i > MAX_BLOCKS) {
		if (node->nxt != NULL) {
			node = node->nxt;
		}
		else return NULL;
		i -= MAX_BLOCKS;
	}
	for (int j = 0; j < i; j++) {
		if (type == SEL && node->blocks[j].selectors != NULL) {
			tmp = node->blocks[j].selectors;
		}
		else if (type == ATT && node->blocks[j].attrs != NULL) {
			tmp = node->blocks[j].attrs;
		}
		else if (type == VAL && node->blocks[j].vals != NULL) {
			tmp = node->blocks[j].vals;
		}
		else break;
	}
	return tmp;
}

//Singly-linked list node deletion (or more certainly zeroing its data)
void deleteNode(listNode** list, listNode* n, listNode* prv) {
	if (prv != NULL) {
		prv->nxt = n->nxt;
	}
	else if (n->nxt!=NULL) {
		*list = n->nxt;
	}
	n->data = NULL;
	n = NULL;
}

//list nodes clearance by changing data pointer into 0 (NULL)
void deleteList(block* b, readType type) {
	listNode* list = initializeNode();
	listNode* next = initializeNode();
	switch (type) {
	case SEL: list = b->selectors;
	case ATT: list = b->attrs;
	case VAL: list = b->vals;
	}
	while (list->nxt != NULL) {
		next = list->nxt;
		list->data = NULL;
		list = next;
	}
	list->data = NULL;
}

//same deletion formula for blocks - includes list deletion
void deleteBlock(int i, dblNode** list) {
	dblNode* tmp = *list;
	while (i >= MAX_BLOCKS) {
		if (tmp->nxt != NULL) {
			tmp = tmp->nxt;
		}
		i -= MAX_BLOCKS;
	}
	if (i >= MAX_BLOCKS) {
		return;
	}
	deleteList(&(tmp->blocks[i]), SEL);
	deleteList(&(tmp->blocks[i]), ATT);
	deleteList(&(tmp->blocks[i]), VAL);
 	tmp->usedBlocks--;
	if (i != (MAX_BLOCKS-1)) {
		for (int j = i; j < (MAX_BLOCKS - 1); j++) {
			if (tmp->blocks[j+1].attrs != NULL) {
				tmp->blocks[j] = tmp->blocks[j + 1];
			}
		}
	}
}

//checks if the particular data (certainly attribute) is already existing on a given list
bool isDuplicate(listNode** list, char* data) {
	listNode* tmp = initializeNode();
	tmp = *list;
	if (tmp->data == NULL) {
		return false;
	}
	while (tmp->nxt != NULL) {
		if (strcmp(tmp->data, data) == 0) {
			return true;
		}
		tmp = tmp->nxt;
	}
	if (strcmp(tmp->data, data) == 0) {
		return true;
	}
	else return false;
}