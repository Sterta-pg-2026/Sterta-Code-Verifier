//
//  Block.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 31/03/2023.
//

#pragma once
#include "section.h"

struct blockNode: public Section {
    sectionNode **sections;
    struct blockNode *next;
    struct blockNode *prev;
};

class Block {
public:
    sectionNode **sections;
    struct blockNode *head;
    int len;
    int section_counter;
    int TABLESIZE;

    Block(int size, int TABLESIZE);
//    void addSection(sectionNode sectionPtr);
    Block(blockNode *ptr);
    void setLen(int len);
    int countSections();
    int countAttributes(int i);
    int countSelectors(int i);
    String getSelector(int i, int j);
    String getAttribute(int i,const String& name);
    void countAttributeName(const String& name);
    void countSelectorName(const String& name);
    int sectionNumber(const String& name);
    void deleteSection(int i);
    void deleteAttribute(int i, const String& name);
//    ~Block();

    void endPush(sectionNode **sections);
   void showList() const;
};
