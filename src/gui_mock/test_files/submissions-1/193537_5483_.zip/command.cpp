//
//  Command.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 04/04/2023.
//

#include "command.h"
#include <iostream>
using namespace std;

Command::Command(){
    stage1 = new String("");
    stage2 = new String("");
    stage3 = new String("");
}

Command::~Command(){
}

void Command::addStage1(char symbol){
    stage1->addChar(symbol);
}
void Command::addStage2(char symbol){
    stage2->addChar(symbol);
}
void Command::addStage3(char symbol){
    stage3->addChar(symbol);
}
char* Command::getStage1(){
    return stage1->c_str();
}
char* Command::getStage2(){
    return stage2->c_str();
}
char* Command::getStage3(){
    return stage3->c_str();
}

void Command::removeCommandSpaces() {
    stage1->removeSpaces();
    stage2->removeSpaces();
    stage3->removeSpaces();
}
void Command::showCommand(){
    if(stage1->c_str()[0] == '?' && stage2->c_str()[0] == '?' && stage3->c_str()[0] == '?'  ){
        cout<<"? == ";
    }
    else{
        cout<<stage1->c_str()<<","<<stage2->c_str()<<","<<stage3->c_str()<<" == ";
    }
}
