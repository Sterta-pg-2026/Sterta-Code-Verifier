//
//  Section.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 30/03/2023.
//
#pragma once
#include "selector.h"
#include "attribute.h"

//struct node
//{
//    char *data = nullptr;
//    struct node *next;
//    struct node *prev;
//};

struct sectionNode{
    selectorNode *selectorPtr;
    attributeNode *attributePtr;
};

class Section: public Selector{
public:
    struct sectionNode *sectionPtr;
    Section();
    Section(sectionNode *ptr);
    void addAttributeList(attributeNode *ptr);
    void addSelectorList(selectorNode *ptr);
    void showSection();
    sectionNode* getPtrSection();
    int startCountSelector();
    int startCountAttribute();
    attributeNode* getAttributePtr();
    selectorNode* getSelectorPtr();
    void deleteSectionExe();
    

    //selectorNode getSelectorPtr();

    //attributeNode getSelectorPtr();
};

