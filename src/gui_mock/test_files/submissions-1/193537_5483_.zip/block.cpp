
#include "block.h"
#include <iostream>
#include <math.h>
using namespace std;



Block::Block(int size, int TABLESIZE) {
    len = size;
    this->TABLESIZE = TABLESIZE;
    head = new blockNode;
    section_counter = 0;
    head->sections = new sectionNode*[TABLESIZE];
    head->next = nullptr;
    head->prev = nullptr;
}

Block::Block(blockNode *ptr) {
    head = ptr;
}

void Block::setLen(int len){
    this->len = len;
}

//Block::~Block() {
//    blockNode *cur = head;
//    while (cur != nullptr) {
//        blockNode *next = cur->next;
//        delete[] cur->sections;
//        delete cur;
//        cur = next;
//    }
//}
//

//void Block::addSection(sectionNode sectionPtr){
//    if(section_counter == len){
//        section_counter = 0;
//        endPush();
//    }
//    else{
//        sections[section_counter] = sectionPtr;
//        section_counter +=1;
//    }
//
//}
//void Block::endPush() {
//    blockNode *cur = new blockNode;
//    cur->sections = sections;
//    cur->next = nullptr;
//    if (head == nullptr) {
//        cur->prev = nullptr;
//        head = cur;
//    } else {
//        blockNode *tmp = head;
//        while (tmp->next != nullptr) {
//            tmp = tmp->next;
//        }
//        tmp->next = cur;
//        cur->prev = tmp;
//    }
//}

void Block::endPush(sectionNode **sections) {
    blockNode *cur = new blockNode;
    cur->sections = sections;
    cur->next = nullptr;
    if (head == nullptr) {
        cur->prev = nullptr;
        head = cur;
    } else {
        blockNode *tmp = head;
        while (tmp->next != nullptr) {
            tmp = tmp->next;
        }
        tmp->next = cur;
        cur->prev = tmp;
    }
}

void Block::showList() const {
    blockNode *tmp = head->next;
    int i = 0;
    while (tmp != nullptr) {
        cout<<endl;
        cout << "--->Block " << i++ <<endl;
        if(tmp->next == nullptr){
            for (int j = 0; j < len; j++) {
                if(tmp->sections[j] != nullptr){
                    cout << "-->Section " << j << endl;
                    Section sec(tmp->sections[j]);
                    sec.showSection();
                }
            }
        }
        else{
            for (int j = 0; j < TABLESIZE; j++) {
                if(tmp->sections[j] != nullptr){
                    cout << "-->Section " << j << endl;
                    Section sec(tmp->sections[j]);
                    sec.showSection();
                }
            }
        }
     
        tmp = tmp->next;
      
    }
}

int Block::countSections(){
    int counter = 0;
    blockNode *tmp = head->next;
    while (tmp != nullptr) {
        if(tmp->next == nullptr){
            for (int j = 0; j < len; j++) {
                if (tmp->sections[j] != nullptr) {
                    counter += 1;
                }
            }
        }
        else{
            for (int j = 0; j < TABLESIZE; j++) {
                if(tmp->sections[j] != nullptr){
                    counter += 1;
                }
            }
        }
     
        tmp = tmp->next;
      
    }
    return counter;
}

int Block::countAttributes(int i){
    int counter = 0;
    blockNode *tmp = head->next;
    
    while (tmp != nullptr) {
      
        if(tmp->next == nullptr){
            for (int j = 0; j < len; j++) {
                if (tmp->sections[j] != nullptr) {
                    if (counter == i - 1) {
                        Section sec(tmp->sections[j]);
                        return sec.startCountAttribute() + 1;
                    }
                    counter += 1;
                }
            }
        }
        else{
            for (int j = 0; j < TABLESIZE; j++) {
                if(tmp->sections[j] != nullptr){
                    if(counter == i - 1){
                        Section sec(tmp->sections[j]);
                        return sec.startCountAttribute()+1;
                    }
                    counter += 1;
                }
            }
        }
     
        tmp = tmp->next;
      
    }
    return 0;
}

int Block::countSelectors(int i){
    int counter = 0;
    blockNode *tmp = head->next;
    
    while (tmp != nullptr) {
      
        if(tmp->next == nullptr){
            for (int j = 0; j < len; j++) {
                if (tmp->sections[j] != nullptr) {
                    if (counter == i - 1) {                    
                        Section sec(tmp->sections[j]);
         //               sec.showSection();
         //               Selector sel(sec.getListPtr());
   //                     return sel.countSelector() + 1;
                        //Selector sel(tmp->sections[counter].selectorPtr);
                        //sel.showList();
                        return sec.startCountSelector() + 1;
                    }
                    counter += 1;
                }
            }
        }
        else{
            for (int j = 0; j < TABLESIZE; j++) {
                if(tmp->sections[j] != nullptr){
               
                    if(counter == i - 1){
                        Section sec(tmp->sections[j]);
                    //    sec.showSection();
                        //               Selector sel(sec.getListPtr());
                  //                     return sel.countSelector() + 1;
                                       //Selector sel(tmp->sections[counter].selectorPtr);
                                       //sel.showList();
                        return sec.startCountSelector() + 1;
                    }
                    counter += 1;
                }
            }
        }
        tmp = tmp->next;
    }
    return 0;
}

String Block::getSelector(int i, int k) {
    int j_alt = 0;
    int selector_len = 0;
    int selector_counter = 0;
    int z = 0;

    blockNode* tmpBl = head->next;
    int block_index = ceil(float(i) / TABLESIZE - 1);
    int section_counter = i - (block_index * TABLESIZE);
    //cout << "blok " << block_index << "secja: " << section_counter << "i: "<<i<<"j: "<<k<<endl;
    int endLen = 0;

    while (tmpBl != nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        if (z == block_index) {
    //        cout << "Blok " << z << endl;
            for (int j = 0; j < endLen; j++) {
                if (tmpBl->sections[j] != nullptr) {
                    if (j == section_counter - 1) {
                      // cout << "Sekcja " << j << endl;
                        Section sec(tmpBl->sections[j]);
                        Selector sel(sec.getSelectorPtr());
                        selectorNode* tmp;
                        tmp = sel.getListPtr();
                       //elector_len = sel.countSelector() + 1;
                        selector_counter = 0;
                        if (tmp->next != NULL) {
    //                        cout << "elo" << endl;
                            while (tmp->next != NULL) {
                              //  cout << selector_counter << endl;
                                //  cout << tmp->name.c_str() << " == " << name.c_str() << endl;
                                if (selector_counter == k-1) {
                                    return tmp->data.c_str();
                                }
                                selector_counter++;
                                tmp = tmp->next;
                            }
                            if (selector_counter == k - 1) {
                                return tmp->data.c_str();
                            }
                            selector_counter++;
       
                        }
                        else {
  //                          cout << "halo" << endl;
                            if (selector_counter == k-1) {
                                return tmp->data.c_str();
                            }

                        }
                     
                    }
                    //j_alt++;*/
                }
            }
        }
        z++;
        tmpBl = tmpBl->next;
    }

    return NULL;
}


    //if (tmpBl->sections[j] != nullptr) {
    //    //selector_counter = 0;
    //    Section sec(tmpBl->sections[j]);
    //    Selector sel(sec.getSelectorPtr());
    //    selectorNode* tmp;
    //    tmp = sel.getListPtr();
    //    section_len = sel.countSelector() + 1;
    //    for (int l = 0; l < section_len; l++) {
    //        if (selector_counter == k - 1) {
    //            //
    //            return tmp->data.c_str();
    //            end = true;
    //            break;
    //        }
    //        selector_counter++;
    //        tmp = tmp->next;
    //    }
    //    if (end) {
    //        break;
    //    }
    //    counter++;
    //}

String Block::getAttribute(int i,const String& name) {
    int j_alt = 0;
    int counter = 0;
    int att_counter = 0;
    int z = 0;
    blockNode* tmpBl = head->next; 
    int block_index = ceil(float(i)/TABLESIZE-1);
    int attribute_index = i - (block_index * TABLESIZE);
    int endLen = 0;
    while (tmpBl != nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        if (z == block_index) {
                for (int j = 0; j < endLen; j++) {
                    if (tmpBl->sections[j] != nullptr) {
                        if (j_alt == attribute_index-1) {
                            Section sec(tmpBl->sections[j]);
                            Attribute att(sec.getAttributePtr());
                            attributeNode* tmp;
                            tmp = att.getListPtr();
                            if (tmp->next != NULL) {
                                while (tmp->next != NULL) {
                                  //  cout << tmp->name.c_str() << " == " << name.c_str() << endl;
                                    att_counter = 0;
                                    if (tmp->name.length() - 1 == name.length()) {
                                        for (int i = 0; i < name.length(); i++) {
                                            if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                                att_counter++;
                                            }
                                        }
                                        if (att_counter == name.length()) {
                                           // cout << tmp->value << endl;
                                           // return NULL;
                                            return tmp->value.c_str();
                                        }
                                    }
                                    tmp = tmp->next;
                                }
                                att_counter = 0;
                                if (tmp->name.length() - 1 == name.length()) {
                                    for (int i = 0; i < name.length(); i++) {
                                        if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                            att_counter++;
                                        }
                                    }
                                    if (att_counter == name.length()) {
                                        //cout << tmp->value << endl;
                                        //return NULL;
                                        return tmp->value.c_str();
                                    }
                                }
                            }
                            else {
                                att_counter = 0;
                                if (tmp->name.length() - 1 == name.length()) {
                                    for (int i = 0; i < name.length(); i++) {
                                        if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                            att_counter++;
                                        }
                                    }
                                    if (att_counter == name.length()) {
                                        //cout << tmp->value << endl;
                                        //return NULL;
                                        return tmp->value.c_str();
                                    }
                                }
                            }

                        }
                        j_alt++;
                    }
                }
        }
        z++;
        tmpBl = tmpBl->next;
    }
    return NULL;
}

void Block::countAttributeName(const String & name) {
    int counter = 0;
    int att_counter = 0;
    int master_counter = 0;
    blockNode* tmpBl = head->next;
    int endLen = 0;
    
    while (tmpBl != nullptr) {
            //if (tmpBl->next == nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
                for (int j = 0; j < endLen; j++) {
                    if (tmpBl->sections[j] != nullptr) {
                            Section sec( tmpBl->sections[j]);
                            Attribute att(sec.getAttributePtr());
                            attributeNode* tmp;
                            tmp = att.getListPtr();
  //                          cout << "master counter: " << master_counter << " -> "<<name.c_str()<<endl;
                            if (tmp->next != NULL) {
                                while (tmp->next != NULL) {
                                    att_counter = 0;
                                    if (tmp->name.length() - 1 == name.length()) {
                                        for (int i = 0; i < name.length(); i++) {
                                            if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                                att_counter++;
                                            }
                                        }
                                        if (att_counter == name.length()) {
                                            master_counter++;
                                        }
                                    }
                                    tmp = tmp->next;
                                }
                                att_counter = 0;
                                if (tmp->name.length() - 1 == name.length()) {
                                    for (int i = 0; i < name.length(); i++) {
                                        if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                            att_counter++;
                                        }
                                    }
                                    if (att_counter == name.length()) {
                                        master_counter++;
                                    }
                                }
                            }
                            else {
                                att_counter = 0;
                                if (tmp->name.length() - 1 == name.length()) {
                                    for (int i = 0; i < name.length(); i++) {
                                        if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                            att_counter++;
                                        }
                                    }
                                    if (att_counter == name.length()) {
                                        master_counter++;
                                    }
                                }
                            }
                    }
                }
        
        tmpBl = tmpBl->next;
    }
    cout << master_counter << endl;

}




void Block::countSelectorName(const String& name) {

    int counter = 0;
    int att_counter = 0;
    int master_counter = 0;
    blockNode* tmpBl = head->next;
    int endLen = 0;

    while (tmpBl != nullptr) {
        //if (tmpBl->next == nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        for (int j = 0; j < endLen; j++) {
            if (tmpBl->sections[j] != nullptr) {
                Section sec(tmpBl->sections[j]);
                Selector sel(sec.getSelectorPtr());
                selectorNode* tmp;
                tmp = sel.getListPtr();
                if (tmp->next != NULL) {
                    while (tmp->next != NULL) {
                        att_counter = 0;
                        if (tmp->data.length() - 1 == name.length()) {
                            for (int i = 0; i < name.length(); i++) {
                                if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                    att_counter++;
                                }
                            }
                            if (att_counter == name.length()) {
                                master_counter++;
                            }
                        }
                        tmp = tmp->next;
                    }
                    att_counter = 0;
                    if (tmp->data.length() - 1 == name.length()) {
                        for (int i = 0; i < name.length(); i++) {
                            if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                att_counter++;
                            }
                        }
                        if (att_counter == name.length()) {
                            master_counter++;
                        }
                    }
                }
                else {
                    att_counter = 0;
                    if (tmp->data.length() - 1 == name.length()) {
                        for (int i = 0; i < name.length(); i++) {
                            if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                att_counter++;
                            }
                        }
                        if (att_counter == name.length()) {
                            master_counter++;
                        }
                    }
                }

            }
        }
        tmpBl = tmpBl->next;
    }
    cout << master_counter << endl;
}


int Block::sectionNumber(const String& name) {
    int counter = 0;
    int att_counter = 0;
    int section_counter = 0;
    blockNode* tmpBl = head->next;
    int endLen = 0;

    while (tmpBl != nullptr) {
        //if (tmpBl->next == nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        for (int j = 0; j < endLen; j++) {
            if (tmpBl->sections[j] != nullptr) {
                Section sec(tmpBl->sections[j]);
                Selector sel(sec.getSelectorPtr());
                selectorNode* tmp;
                tmp = sel.getListPtr();
                if (tmp->next != NULL) {
                    while (tmp->next != NULL) {
                        att_counter = 0;
                        if (tmp->data.length() - 1 == name.length()) {
                            for (int i = 0; i < name.length(); i++) {
                                if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                    att_counter++;
                                }
                            }
                            if (att_counter == name.length()) {
                                section_counter = counter;
                   //
                            }
                        }
                        tmp = tmp->next;
                    }
                    att_counter = 0;
                    if (tmp->data.length() - 1 == name.length()) {
                        for (int i = 0; i < name.length(); i++) {
                            if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                att_counter++;
                            }
                        }
                        if (att_counter == name.length()) {
                            section_counter = counter;
           //
                        }
                    }
                }
                else {
                    att_counter = 0;
                    if (tmp->data.length() - 1 == name.length()) {
                        for (int i = 0; i < name.length(); i++) {
                            if (tmp->data.c_str()[att_counter] == name.c_str()[att_counter]) {
                                att_counter++;
                            }
                        }
                        if (att_counter == name.length()) {
                            section_counter = counter;
               //
                        }
                    }
                }
            }
            counter++;

        }
        tmpBl = tmpBl->next;
    }
    return section_counter;
}



void Block::deleteSection(int i) {
    int counter = 0;
    int att_counter = 0;
    int z = 0;
    blockNode* tmpBl = head->next;
    int block_index = ceil(float(i) / TABLESIZE - 1);
    int attribute_index = i - (block_index * TABLESIZE);
    int endLen = 0;
    while (tmpBl != nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        if (z == block_index) {
            for (int j = 0; j < endLen; j++) {
                if (tmpBl->sections[j] != nullptr) {
                    if (j == attribute_index - 1) {

                        tmpBl->sections[j] = nullptr;
                    }
                }
            }
        }
        z++;
        tmpBl = tmpBl->next;
    }
}


void Block::deleteAttribute(int i, const String& name) {
    int j_alt = 0;
    int section_counter = 0;
    int att_counter = 0;
    int z = 0;
    blockNode* tmpBl = head->next;
    int block_index = ceil(float(i) / TABLESIZE - 1);
    int attribute_index = i - (block_index * TABLESIZE);
    int endLen = 0;
    while (tmpBl != nullptr) {
        if (tmpBl->next == nullptr) {
            endLen = len;
        }
        else {
            endLen = TABLESIZE;
        }
        if (z == block_index) {
            for (int j = 0; j < endLen; j++) {
                if (tmpBl->sections[j] != nullptr) {
                    if (j_alt == attribute_index - 1) {
                        Section sec(tmpBl->sections[j]);
                        Attribute att(sec.getAttributePtr());
                        attributeNode* tmp, *head;
                        head = att.getListPtr();
                        tmp = att.getListPtr();
                        if (tmp->next != NULL) {
                            while (tmp->next != NULL) {
                                att_counter = 0;
                                if (tmp->name.length() - 1 == name.length()) {
                                    for (int i = 0; i < name.length(); i++) {
                                        if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                            att_counter++;
                                        }
                                    }
                                    if (att_counter == name.length()) {
                                        if (head == NULL || tmp == NULL)
                                            return;

                                        if (head == tmp)
                                            head = tmp->next;

                                        if (tmp->next != NULL)
                                            tmp->next->prev = tmp->prev;


                                        if (tmp->prev != NULL)
                                            tmp->prev->next = tmp->next;
                                        free(tmp);
                                        if (head == NULL) {
                                            deleteSection(section_counter+1);
                                        }
                                    }
                                }
                                tmp = tmp->next;
                            }
                            att_counter = 0;
                            if (tmp->name.length() - 1 == name.length()) {
                                for (int i = 0; i < name.length(); i++) {
                                    if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                        att_counter++;
                                    }
                                }
                                if (att_counter == name.length()) {
                                    if (head == NULL || tmp == NULL)
                                        return;

                                    if (head == tmp)
                                        head = tmp->next;

                                    if (tmp->next != NULL)
                                        tmp->next->prev = tmp->prev;


                                    if (tmp->prev != NULL)
                                        tmp->prev->next = tmp->next;
                                    free(tmp);
                                    if (head == NULL) {
                                        deleteSection(section_counter + 1);
                                    }
                                }
                            }
                        }
                        else {
                            att_counter = 0;
                            if (tmp->name.length() - 1 == name.length()) {
                                for (int i = 0; i < name.length(); i++) {
                                    if (tmp->name.c_str()[att_counter] == name.c_str()[att_counter]) {
                                        att_counter++;
                                    }
                                }
                                if (att_counter == name.length()) {
                                    if (head == NULL || tmp == NULL)
                                        return;

                                    if (head == tmp)
                                        head = tmp->next;

                                    if (tmp->next != NULL)
                                        tmp->next->prev = tmp->prev;


                                    if (tmp->prev != NULL)
                                        tmp->prev->next = tmp->next;
                                    free(tmp);
                                    if (head == NULL) {
                                        deleteSection(section_counter + 1);
                                    }
                                }
                            }
                        }

                    }
                    j_alt++;
                }
                section_counter++;
            }
        }
        z++;
        tmpBl = tmpBl->next;
    }
}

