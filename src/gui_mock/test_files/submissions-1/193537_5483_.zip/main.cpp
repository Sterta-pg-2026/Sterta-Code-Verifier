//
//  main.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 26/03/2023.
//

#include <iostream>
#include "mode.h"
#include "string.h"
using namespace std;

Mode mode(true);

int main() {
  //  cout << "halo" << endl;
    char symbol = '\0';
    char prev_symbol = '\0';
    char prev_prev_symbol = '\0';
    while (cin.get(symbol)) {
      //  cout << "halo" << endl;
        //      cout<<symbol<<endl;
        prev_prev_symbol = prev_symbol;
        prev_symbol = symbol;
        //            cin.get(symbol);

        //if (symbol < ' ') {
        //    continue;
        //}
        //else {
            //cout << "halo" << endl;
            mode.cssInputModeCheck(symbol, prev_symbol, prev_prev_symbol);

            //&& mode.getMode() == mode.getModePrev()
            if (mode.getMode() && symbol != '\n') {
                mode.cssModeExe();
            }


        /*    if(!mode.getMode() && mode.getMode() != mode.getModePrev()){
                cout<<"------------ZMIANA---------"<<endl;
                mode.blockDebug();

            }
            if(mode.getMode() && mode.getMode() != mode.getModePrev()){
                cout<<"------------ZMIANA---------"<<endl;
                mode.blockDebug();

            }*/


            if (!mode.getMode() && mode.getMode() == mode.getModePrev()) {
                mode.commandsModeExe();
            }
      //  }

    }
    
    return 0;

}


//
//
//String *string = new String("");
//string->addChar(' ');
//string->addChar(' ');
//string->addChar('d');
//string->addChar('d');
//string->addChar('d');
//string->addChar(' ');
//string->addChar(' ');
//cout<<"start:"<<string->c_str()<<":end"<<endl;
//string->removeSpaces();
//cout<<"start:"<<string->c_str()<<":end"<<endl;
//
//



//String s1("body ");
//String s2("#container");
//
//String a1("height ");
//String a2("min-width");
//
//String v1("22px");
//String v2("64px");
//
//Selector selector;
//Attribute *attribute = new Attribute;
////
//
//selector.endPush(s1);
//attribute->endPush(a1, v1);
//selector.endPush(s2);
//attribute->endPush(a2, v2);
////    attribute->showList();
//attribute->showList();
////    delete attribute;
//
//Section section1;
//section1.addAttributeList(attribute->getListPtr());
//section1.addSelectorList(selector.getListPtr());
//
//
//
//sectionNode listaSekcji[1] = {section1.getPtrSection()};
//Block blok(1);
//blok.endPush(listaSekcji);
//blok.showList();
