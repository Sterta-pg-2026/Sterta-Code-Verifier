//
//  SelectorModeExe.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 28/03/2023.
//

#include "selector.h"
#include <iostream>
using namespace std;

Selector::Selector() {
    head = new selectorNode;
    head->data = NULL;
    head->next = NULL;
    head->prev = NULL;
}

Selector::Selector(selectorNode *ptr){
     head = ptr;
}

//void Selector::frontPush(char *data)
//{
//    selectorNode *tmp = new selectorNode;
//    tmp->next = head;
//    tmp->prev = NULL;
//    tmp->data = data;
//    head = tmp;
//}

void Selector::endPush(String &data)
{
//    cout<<data;
    if(head->data.length() == 0){
        head->data = data;
    }
    else{
        selectorNode *tmp;
        selectorNode *cur = new selectorNode;
        cur->data = data;
        cur->next = NULL;
        tmp = head;
        while (tmp->next != NULL){
            tmp = tmp->next;
        };
        cur->prev = tmp;
        tmp->next = cur;
    }
}

void Selector::showList(){
    selectorNode *tmp;
    tmp = head;
    int i = 0;

    cout<<" Nazwa: "<<i<<" ";
    cout<<tmp->data<<endl;
    while(tmp->next != NULL){
        tmp = tmp->next;
        i++;
        cout<<" Nazwa: "<<i<<" ";
        cout<<tmp->data<<endl;
    };
}

selectorNode *Selector::getListPtr(){
    return head;
}

int Selector::countSelector() {
    selectorNode* tmp;
    tmp = head;
    int i = 0;
    //cout << " Nazwa: " << i << " ";
    //cout << tmp->data << endl;
    while (tmp->next != NULL) {
        tmp = tmp->next;
        i++;
        //cout << " Nazwa: " << i << " ";
        //cout << tmp->data << endl;
    };
    return i;
}