//
//  Attribute.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 30/03/2023.
//
#include "attribute.h"
#include <iostream>
using namespace std;

Attribute::Attribute(){
     head = new attributeNode;
     head->name = "";
     head->value = "";
     head->next = NULL;
     head->prev = NULL;
}

Attribute::Attribute(attributeNode *ptr){
     head = ptr;
}

Attribute::~Attribute()
{
//    delete head;
//    cout<<"->destruktor"<<endl;
//    attributeNode* current = head;
//    while (current != nullptr) {
//        attributeNode* next = current->next;
//        delete current;
//        current = next;
//    }
}

//void Attribute::frontPush(char *name, char *value)
//{
//    attributeNode *tmp = new attributeNode;
//    tmp->next = head;
//    tmp->prev = NULL;
//    tmp->name = name;
//    tmp->value = value;
//    head = tmp;
//}

void Attribute::endPush(String& name, String& value)
{

    if (head->name.length() == 0 && head->value.length() == 0) {
        head->name = name;
        head->value = value;
    }
    else {
        attributeNode* tmp = head;
        attributeNode* cur = new attributeNode;
        cur->name = name;
        cur->value = value;
        cur->next = NULL;

        while (tmp->next != NULL) {
            tmp = tmp->next; 
        }

        cur->prev = tmp;
        tmp->next = cur;
    }
}

void Attribute::showList(){
    attributeNode *tmp;
    tmp = head;
    int i = 0;
    cout<<" Nazwa: "<<i<<" ";
    cout<<tmp->name<<endl;
    cout<<" Wartosc: "<<i<<" ";
    cout<<tmp->value<<endl;
    while(tmp->next != NULL){
        tmp = tmp->next;
        i++;
//        cout<<"List num: "<<i<<", Data: "<<tmp->data<<endl;
        cout<<" Nazwa: "<<i<<" ";
        cout<<tmp->name<<endl;
        cout<<" Wartosc: "<<i<<" ";
        cout<<tmp->value<<endl;
    };
}

int Attribute::countAttribute(){
    attributeNode *tmp;
    tmp = head;
    int i = 0;
    while(tmp->next != NULL){
        tmp = tmp->next;
        i++;
    }
    return i;
}

attributeNode *Attribute::getListPtr(){
    return head;
}
