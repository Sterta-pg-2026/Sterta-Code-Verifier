//
//  Mode.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 26/03/2023.
//

#include "mode.h"
//#include "Selector.hpp"
#include <iostream>
using namespace std;

String questionMark = "?";
String letterA = "A";
String letterS = "S";
String letterE = "E";
String letterD = "D";
String starSymbol = "*";

const int TABLESIZE = 17;

bool isNumber(const String& str)
{
    for (int i = 0; i < str.length(); ++i)
    {
        if (!isdigit(str.c_str()[i]))
        {
            return false;
        }
    }
    return true;
}

//int stringToInt(const String& str) {
//    int result = 0;
//    int sign = 1;
//
//    if (str.c_str()[0] == '-') { // sprawdzenie znaku liczby
//        sign = -1;
//    }
//
//    for (int i = (str.c_str()[0] == '-' ? 1 : 0); i < str.length(); i++) { // iteracja przez każdy znak łańcucha znaków
//        if (str.c_str()[i] >= '0' && str.c_str()[i] <= '9') { // sprawdzenie, czy znak jest cyfrą
//            result = result * 10 + (str.c_str()[i] - '0'); // konwersja znaku na wartość liczbową i dodanie jej do wyniku
//        }
//        else { // jeśli jakiś znak w łańcuchu nie jest cyfrą, to przerywamy działanie funkcji
//            break;
//        }
//    }
//
//    return sign * result;
//}

int stringToInt(const char* str) {
    int result = 0;
    int sign = 1;

    if (*str == '-') { // sprawdzenie znaku liczby
        sign = -1;
        str++; // pominięcie znaku minus
    }

    while (*str) { // iteracja przez każdy znak łańcucha znaków
        if (*str >= '0' && *str <= '9') { // sprawdzenie, czy znak jest cyfrą
            result = result * 10 + (*str - '0'); // konwersja znaku na wartość liczbową i dodanie jej do wyniku
        } else { // jeśli jakiś znak w łańcuchu nie jest cyfrą, to przerywamy działanie funkcji
            break;
        }
        str++;
    }

    return sign * result;
}

Mode::Mode(bool state){
    css_input_mode = state;
    selector_mode = true;
    attribute_name_mode = true;
    prev_css_input_mode = state;
    
    commmand_stage = 4;
    section_counter = 0;
    new_command = true;

    selector_name = new String("");
    attribute_name = new String("");
    attribute_value = new String("");
    
    attribute = new Attribute();
    selector = new Selector();
    section = new Section();
    block = new Block(TABLESIZE,TABLESIZE);
    command = new Command();
    
    sections = new sectionNode*[TABLESIZE];
    block->endPush(sections);
//    *sections = new Section();
}

void Mode::cssInputModeCheck(char symbol, char prev_symbol, char prev_prev_symbol){
    prev_css_input_mode = css_input_mode;
//    char unused[4];
    this->symbol = symbol;
    this->prev_symbol = prev_symbol;
    this->prev_prev_symbol = prev_prev_symbol;
//    && prev_prev_symbol == '}'
////
//    if(symbol == '?' &&  prev_symbol == 13){
//        cout<<"chuj"<<symbol<<endl;
//        css_input_mode = false;
//        cin.get(unused, 4);
//    }
//    else if (symbol == '*' && css_input_mode == false && prev_symbol == '\n' ){
//        cout<<"dupa"<<symbol<<endl;
//        css_input_mode = true;
//        selector_mode = true;
//        cin.get(unused, 4);
//    }
}

bool Mode::getMode(){
    return css_input_mode;
}

bool Mode::getModePrev(){
    return prev_css_input_mode;
}

void Mode::blockDebug(){
    block->showList();
}

void Mode::commandsModeExe(){
    int response = 0;
    int qestion_mark_counter = 0;
//    cout<<"<-- Command Mode --> "<<int(symbol)<<endl;
    if(symbol == '\n' && commmand_stage != 4 && prev_prev_symbol != 10){
//        cout<<int(symbol)<<
        new_command = true;
        commmand_stage = 1;
//        cout<<int(prev_prev_symbol)<<endl;
//        cout<<int(prev_symbol)<<endl;
//        cout<<int(symbol)<<endl;
//        cout<<"Nowa Komenda"<<endl;
        command->removeCommandSpaces();
 

        if (isNumber(command->getStage1())) {
            //    ---->  i,A,? <------
            if (command->getStage2() == letterA && command->getStage3() == questionMark) {
                
                response =  block->countAttributes(stringToInt(command->getStage1()));
                if (response != 0) {
                    command->showCommand();
                    cout << response << endl;
                }
            }
            //    ---->  i,S,? <------
            else if (command->getStage2() == letterS && command->getStage3() == questionMark) {
       //         block->showList();
                response = block->countSelectors(stringToInt(command->getStage1()));
                if (response != 0) {
                    command->showCommand();
                    cout << block->countSelectors(stringToInt(command->getStage1())) << endl;
                }
                
            }
            //    ---->  i,S,j <------
            else if (command->getStage2() == letterS && isNumber(command->getStage3())) {
                String stringResponse(block->getSelector(stringToInt(command->getStage1()), stringToInt(command->getStage3())));
                if (!(stringResponse == NULL)) {
                    command->showCommand();
                    cout << stringResponse.c_str()<<endl;
                }
            }
            //    ---->  i,A,n <------
            else if (command->getStage2() == letterA && !isNumber(command->getStage3())) {
                String stringResponse(block->getAttribute(stringToInt(command->getStage1()), command->getStage3()).c_str());
                if (!(stringResponse == NULL)) {
                    command->showCommand();
                    cout << stringResponse << endl;
                }
            }
            else if (command->getStage2() == letterD && command->getStage3() == starSymbol){
                command->showCommand();
                block->deleteSection(stringToInt(command->getStage1()));
                cout << "deleted" << endl;
                //block->showList();
            }
            else if (command->getStage2() == letterD) {
                command->showCommand();
                //block->deleteSection(stringToInt(command->getStage1()));
                block->deleteAttribute(stringToInt(command->getStage1()), command->getStage3());
               // block->deleteAttribute(stringToInt(command->getStage1()), command->getStage3()).c_str());
                cout << "deleted" << endl;
            }
        }
        else {
            if (command->getStage1() == questionMark && command->getStage2() == questionMark && command->getStage3() == questionMark) {
                command->showCommand();
                cout << block->countSections() << endl;
            }
            //cout<<"n, A, ?"<<endl; // – wypisz łączną(dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n. (W ramach pojedynczego bloku duplikaty powinny zostać usunięte na etapie wczytywania).Możliwe jest 0;
            else if (command->getStage2() == letterA && command->getStage3() == questionMark) {
                command->showCommand();
                block->countAttributeName(command->getStage1());         
            }
            // cout<<"z, S, ?"<<endl;  //wypisz łączną(dla wszystkich bloków) liczbę wystąpień selektora z.Możliwe jest 0;
            else if (command->getStage2() == letterS && command->getStage3() == questionMark) {
                command->showCommand();
                block->countSelectorName(command->getStage1());
            }
            else if (command->getStage2() == letterE) {
                int response = block->sectionNumber(command->getStage1());
                String stringResponse = block->getAttribute(response +1, command->getStage3());
                if (!(stringResponse == NULL) && response != 0) {
                    command->showCommand();
                    cout << stringResponse.c_str() << endl;
                }
        //       cout<< block->sectionNumber(command->getStage1())<<endl;
            }
             
        }

        
//        && command->getStage3() == questionMark
    
        //else {
        //    cout << endl;
        //}
        
    
        
            delete command;
            command = new Command();
        }
        else if (symbol == ',' && commmand_stage == 1){
            commmand_stage = 2;
        }
        else if (symbol == ',' && commmand_stage == 2){
            commmand_stage = 3;
        }

        if(new_command){
            new_command = false;
            commmand_stage =1;
     
        }
        else if (symbol != 10){
             if (commmand_stage == 1 && symbol == '?'){
//                 cout<<"STAGE --> "<<symbol<<endl;
                command->addStage1(symbol);
                command->addStage2(symbol);
                command->addStage3(symbol);
            }
             else if(commmand_stage == 1 && symbol != ','){
//                 cout<<"STAGE 1 --> "<<symbol<<endl;
                 if(symbol == '*'){
                     prev_css_input_mode = css_input_mode;
                     css_input_mode = true;
                     selector_mode = true;
                     cin.get(symbol);
                     cin.get(symbol);
                     cin.get(symbol);
                 }
                 else{
                     command->addStage1(symbol);
                 }
            }
          
            else if (commmand_stage == 2 && symbol != ','){
//                cout<<"STAGE 2 --> "<<symbol<<endl;
                command->addStage2(symbol);
            }
            else if (commmand_stage == 3 && symbol != ','){
//                cout<<"STAGE 3 --> "<<symbol<<endl;
               command->addStage3(symbol);
            }
        
    }
}

int qestion_mark_counter = 0;
void Mode::cssModeExe(){

    if(symbol == '{'){
        selector_mode = false;
        selector_name->removeSpaces();
        selector->endPush(*selector_name);
    }
    // NEW SECTION
    else if(symbol == '}'){
        commmand_stage = 4;
        selector_mode = true;
        //NEW BLOCK
        
//        cout<<"///////////////////////////////"<<endl;
        
        if(section_counter == TABLESIZE){
            section_counter = 0;
            block->setLen(TABLESIZE);
            
  //          block->showList();
  //          cout<<"///////////////////////////////"<<endl;
            
            sections = new sectionNode*[TABLESIZE];
            block->endPush(sections);
        }
        //ADD SECTION
            section->addSelectorList(selector->getListPtr());
            section->addAttributeList(attribute->getListPtr());
            sections[section_counter] = section->getPtrSection();

            section = new Section();
            section_counter +=1;
            block->setLen(section_counter);
        
//            block->showList();

        selector_name = new String("");
        attribute = new Attribute();
        selector = new Selector();
    }
    //SELECTOR MODE
    if(selector_mode && symbol!='}'){
        
            if(symbol == ','){
                selector_name->removeSpaces();
                selector->endPush(*selector_name);
                selector_name = new String("");
            }
            else{
                selector_name->addChar(symbol);
                //cout << "SEL ->" <<selector_name->c_str()<<"<- "<< endl;
                if (symbol == '?') {
                    qestion_mark_counter++;
                }
                else {
                    qestion_mark_counter = 0;
                }
                if (qestion_mark_counter == 4) {
                    prev_css_input_mode = css_input_mode;
                    css_input_mode = false;
                    new_command = true;
                    delete selector_name;
                    selector_name = new String("");
                }
           /*     if(selector_name->c_str()[0] == '?' &&selector_name->c_str()[1] == '?' &&selector_name->c_str()[2] == '?' &&selector_name->c_str()[3] == '?'  ){
                    
                }*/
            }
    }
    //ATTRIBUTE MODE
    else if(!selector_mode && symbol != '{'){
   //     cout << "ATT" << endl;
        int att_counter = 0;
        bool change_value = false;
        if(symbol == ':'){
            attribute_name_mode = false;
        }
        else if (symbol == ';') {
            
            attribute_name_mode = true;
            attribute_name->removeSpaces();
            attribute_value->removeSpaces();
            attributeNode* tmpAttribute;
            tmpAttribute = attribute->getListPtr();
            if (tmpAttribute->next != NULL) {
                while (tmpAttribute->next != NULL) {
                    att_counter = 0;
                    if (tmpAttribute->name.length() == attribute_name->length()) {
                        for (int i = 0; i < attribute_name->length(); i++) {
                            if (tmpAttribute->name.c_str()[att_counter] == attribute_name->c_str()[att_counter]) {
                                att_counter++;
                            }
                        }
                        if (att_counter == attribute_name->length()) {
                            change_value = true;
                            break;
                        }
                    }
                    //    attribute->endPush(*attribute_name, *attribute_value);
                    //   tmpAttribute->value = *attribute_value; 
                    tmpAttribute = tmpAttribute->next;
                }
                att_counter = 0;
                for (int i = 0; i < attribute_name->length(); i++) {
                  //  cout << tmpAttribute->name.c_str()[att_counter] << " == " << attribute_name->c_str()[att_counter] << endl;
                    if (tmpAttribute->name.c_str()[att_counter] == attribute_name->c_str()[att_counter]) {
                        att_counter++;
                    }
                }
                if (att_counter == attribute_name->length()) {
                    tmpAttribute->value = *attribute_value;
                    //   cout << "kopia" << endl;
                }
                else {
                    attribute->endPush(*attribute_name, *attribute_value);
                    //cout << "nie kopia" << endl;
                }
            }
 
            else {
                //               cout << "POR -> " << tmpAttribute->name.length() << " == " << attribute_name->length() << endl;
                att_counter = 0;
                for (int i = 0; i < attribute_name->length(); i++) {
                   // cout << tmpAttribute->name.c_str()[att_counter] << " == "<< attribute_name->c_str()[att_counter] <<endl;
                    if (tmpAttribute->name.c_str()[att_counter] == attribute_name->c_str()[att_counter]) {
                        att_counter++;
                    }
                }
                if (att_counter == attribute_name->length()) {
                    tmpAttribute->value = *attribute_value;
                  //   cout << "kopia" << endl;
                }
                else {
                    attribute->endPush(*attribute_name, *attribute_value);
                    //cout << "nie kopia" << endl;
                }
            }
   
            attribute_name = new String("");
            attribute_value = new String("");
          
        }

        else{
            if(attribute_name_mode){
                attribute_name->addChar(symbol);
            }
            else{
                attribute_value->addChar(symbol);
            }
        }
    }
    
}
