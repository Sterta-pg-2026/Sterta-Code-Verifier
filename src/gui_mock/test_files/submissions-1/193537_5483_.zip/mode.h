//
//  Mode.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 26/03/2023.
//
#pragma once
#include "selector.h"
#include "attribute.h"
#include "section.h"
#include "string.h"
#include "block.h"
#include "command.h"

class Mode{
protected:
    bool css_input_mode;
    bool prev_css_input_mode;
    bool selector_mode;
    bool attribute_name_mode;
    bool new_command;
    
    int commmand_stage;
    
    char symbol;
    char prev_symbol;
    char prev_prev_symbol;
    
    int section_counter;
 
    String *selector_name;
    String *attribute_name;
    String *attribute_value;
    
    Selector *selector;
    Attribute *attribute;
    Section *section;
    Block *block;
    Command *command;
    
    sectionNode **sections;
//    Section sections[8];
    
    
//    char buff[120];
public:
    Mode(bool state);
    void cssInputModeCheck(char symbol, char prev_symbol, char prev_prev_symbol);
    bool getMode();
    bool getModePrev();
    void cssModeExe();
    void commandsModeExe();
    void blockDebug();
};
