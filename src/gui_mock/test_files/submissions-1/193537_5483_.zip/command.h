//
//  Command.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 04/04/2023.
//


#pragma once
#include "string.h"

class Command{
private:
    String *stage1;
    String *stage2;
    String *stage3;
public:
    Command();
    ~Command();
    void addStage1(char symbol);
    void addStage2(char symbol);
    void addStage3(char symbol);
    char* getStage1();
    char* getStage2();
    char* getStage3();
    void showCommand();
    void removeCommandSpaces();
};
