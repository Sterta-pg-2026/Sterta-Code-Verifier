//
//  SelectorModeExe.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 28/03/2023.
//
#pragma  once
#include "string.h"

struct selectorNode
{
    String data = nullptr;
    struct selectorNode *next;
    struct selectorNode *prev;
};

class Selector{
public:

    struct selectorNode *head;
    
    Selector();
    Selector(selectorNode *ptr);
    
    selectorNode *getListPtr();
    
    int countSelector();
    
//    void frontPush(char *data);

    void endPush(String &data);

    void showList();

};
