//
//  Section.cpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 30/03/2023.
//

#include "section.h"
#include <iostream>
using namespace std;

Section::Section(){
    sectionPtr = new sectionNode;
}

Section::Section(sectionNode *ptr){
    sectionPtr = ptr;
}

void Section::addAttributeList(attributeNode *ptr){
    sectionPtr->attributePtr = ptr;
}
void Section::addSelectorList(selectorNode *ptr){
    sectionPtr->selectorPtr = ptr;
}
sectionNode* Section::getPtrSection(){
    return sectionPtr;
}


//selectorNode Section::getSelectorPtr() {
//    return sectionPtr->selectorPtr;
//}
//attributeNode Section::getSelectorPtr() {
//    return sectionPtr->attributePtr;
//}
int Section::startCountSelector() {
    Selector sel(sectionPtr->selectorPtr);
    return sel.countSelector();
}
int Section::startCountAttribute() {
    Attribute att(sectionPtr->attributePtr);
    return att.countAttribute();
}

attributeNode *Section::getAttributePtr() {
    return sectionPtr->attributePtr;
}
selectorNode *Section::getSelectorPtr() {
    return sectionPtr->selectorPtr;
}

void Section::showSection(){
    if (&sectionPtr->selectorPtr != nullptr) {
        Selector Sel(sectionPtr->selectorPtr);
        Attribute Att(sectionPtr->attributePtr);
        cout << "->Selektory: " << endl;
        Sel.showList();
        cout << "->Atrybuty: " << endl;
        Att.showList();
    }
    else {
        cout << "Sekcja usunieta" << endl;
    }
   
}

void Section::deleteSectionExe() {
    //delete [] sectionPtr->attributePtr;
    //delete[] sectionPtr->selectorPtr;
    sectionPtr->attributePtr = nullptr;
    sectionPtr->selectorPtr = nullptr;
}