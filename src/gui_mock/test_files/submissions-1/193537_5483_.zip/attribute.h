//
//  Attribute.hpp
//  PROJECT-CSS-v2
//
//  Created by Tymon Muszynski on 30/03/2023.
//
#pragma  once
#include "string.h"

struct attributeNode
{
    String name;
    String value;
    struct attributeNode *next;
    struct attributeNode *prev;
};

class Attribute{
public:
    struct attributeNode *head = NULL;
    
    Attribute();
    Attribute(attributeNode *ptr);
    ~Attribute();
    attributeNode *getListPtr();
    int countAttribute();
    
//    void frontPush(char *name, char *value);

    void endPush(String &data, String &value);

    void showList();

};
