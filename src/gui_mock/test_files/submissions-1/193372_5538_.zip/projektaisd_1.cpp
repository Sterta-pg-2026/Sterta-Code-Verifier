#include <iostream>
#include <cmath>

#include "dllist.h"
#include "section.h"
#include "string.h"
#include "attribute.h"

using namespace std;

int convertToInt(String* e) {
	int result = 0;
	for (int i = 0; i < e->valueSize-1; i++){
		result += int((int(e->value[i])-48)*pow(10, e->valueSize-2-i));
	}
	return result;
}

int main() {
	char isCommand = 0;
	char openBracket = 0;
	char isValue = 0; //for attributes
	char isStartedSelector = 0;
	char c;
	char* buffer = new char[150];
	int index = 0;
	int count = 0;
	int count2 = 0;
	int T = 17;

	DLList* mainList = new DLList(T);
	Section* currentSection = new Section();

	String* part1 = new String();
	char part2 = 0;
	String* part3 = new String();

	while (cin) {
		c = cin.get();
		if (!isCommand) {
			if (c > ' ' || isValue || (c == ' ' && isStartedSelector)) {
				if (openBracket) {
					if (c == '}') {
						openBracket = 0;

						mainList->addSection(currentSection);
						currentSection = new Section();
					}
					else if (c == ':') {
						isValue = 1;

						buffer[index] = '\0';
						String* name = new String(buffer, index + 1);
						Attribute* tempAttr = currentSection->findAttribute(name);
						if (tempAttr != nullptr)
							currentSection->deleteAttribute(name);
						currentSection->addAttribute(new Attribute(name));
						//cout << currentSection->attributes->tail->altContent->name->value << endl;
						index = 0;
					}
					else if (c == ';') {
						isValue = 0;

						buffer[index] = '\0';
						if (buffer[0] == ' ') {
							for (int i = 0; i < index; i++){
								buffer[i] = buffer[i + 1];
							}
						}
						String* value = new String(buffer, index + 1);
						currentSection->attributes->tail->altContent->addValue(value); //clears buffer as well
						//cout << currentSection->attributes->tail->altContent->value->value << endl;
						index = 0;
					}
					else {
						buffer[index] = c;
						index++;
					}
				}
				else {
					if (c == '{') {
						isStartedSelector = 0;
						openBracket = 1;
						count2 = 0;
						
						if (index > 0){
							buffer[index] = '\0';
							String* name = new String(buffer, index + 1);
							String* tempSel = currentSection->findSelector(name);
							if (tempSel != nullptr)
								currentSection->deleteSelector(name);
							currentSection->addSelector(name); //clears buffer as well
							//cout << currentSection->selectors->tail->content->value << endl;
							index = 0;
						}
					}
					else if (c == ',') {
						isStartedSelector = 0;
						count2 = 0;

						buffer[index] = '\0';
						String* name = new String(buffer, index + 1);
						String* tempSel = currentSection->findSelector(name);
						if (tempSel != nullptr)
							currentSection->deleteSelector(name);
						currentSection->addSelector(name);
						//cout << currentSection->selectors->tail->content->value << endl;
						index = 0;
					}
					else if(c == '?') {
						count++;
						if (count == 4) {
							isCommand = 1;
							count = 0;
						}
					}
					else if (c == ' ') {
						count2++;
					}
					else {
						isStartedSelector = 1;
						if (count2 > 0) {
							buffer[index] = ' ';
							index++;
							count2 = 0;
						}
						buffer[index] = c;
						index++;
					}
				}
			}
		}
		else { //komendy
			if (c == '\n') {
				if (buffer[0] != 0) {
					buffer[index] = '\0';
					part3 = new String(buffer, index + 1);
					index = 0;
					count2 = 0;
					if (part2 == 'S') {
						if (part3->value[0] == '?') {
							if (part1->value[0] >= 48 && part1->value[0] <= 57) { //digits //i,S,? command
								Section* temp = mainList->findSection(convertToInt(part1));
								if (temp != nullptr) {
									cout << part1->value << "," << part2 << "," << part3->value << " == " << temp->selectors->length << endl;
								}
							}
							else { //z,S,? command
								int selCount = mainList->countSelector(part1);
								cout << part1->value << "," << part2 << "," << part3->value << " == " << selCount << endl;
							}
						}
						else { //i,S,j command
							Section* temp = mainList->findSection(convertToInt(part1));
							if (temp != nullptr) {
								String* tempEle = temp->findSelector(convertToInt(part3));
								if (tempEle != nullptr)
									cout << part1->value << "," << part2 << "," << part3->value << " == " << tempEle->value << endl;
							}
						}
					}
					else if (part2 == 'A') {
						if (part3->value[0] == '?') {
							if (part1->value[0] >= 48 && part1->value[0] <= 57) { //i,A,? command
								Section* temp = mainList->findSection(convertToInt(part1));
								if (temp != nullptr) {
									cout << part1->value << "," << part2 << "," << part3->value << " == " << temp->attributes->length << endl;
								}
							}
							else { //n,A,? command
								int attrCount = mainList->countAttribute(part1);
								cout << part1->value << "," << part2 << "," << part3->value << " == " << attrCount << endl;
							}
						}
						else { //i,A,n command
							Section* temp = mainList->findSection(convertToInt(part1));
							if (temp != nullptr) {
								Attribute* tempAttr = temp->findAttribute(part3);
								if (tempAttr != nullptr)
									cout << part1->value << "," << part2 << "," << part3->value << " == " << tempAttr->value->value << endl;
							}
						}
					}
					else if (part2 == 'E') { //z,E,n command
						Section* temp = mainList->findSectionBySelector(part1);
						if (temp != nullptr) {
							Attribute* tempAttr = temp->findAttribute(part3);
							if (tempAttr != nullptr)
								cout << part1->value << "," << part2 << "," << part3->value << " == " << tempAttr->value->value << endl;
						}
					}
					else {
						if (part3->value[0] == '*') { //i,D,* command
							int success = mainList->deleteSection(convertToInt(part1));
							if(success)
								cout << part1->value << "," << part2 << "," << part3->value << " == deleted" << endl;
						}
						else { //i,D,n command
							Section* temp = mainList->findSection(convertToInt(part1));
							if (temp != nullptr) {
								int success = temp->deleteAttribute(part3);
								if(success == 2)
									success = mainList->deleteSection(convertToInt(part1));
								if (success)
									cout << part1->value << "," << part2 << "," << part3->value << " == deleted" << endl;
							}
						}
					}
				}
			}
			else if (c == ',') {
				count2++;
				if (count2 == 1) {
					buffer[index] = '\0';
					part1 = new String(buffer, index + 1);
					index = 0;
				}
				else if (count2 == 2) {
					part2 = buffer[0];
					buffer[0] = 0;
					index = 0;
				}
			}
			else if (c == '?' && count2 == 0) {
				cout << c << " == " << mainList->sectionCount << endl;
			}
			else if (c == '*' && count2 == 0) {
				count++;
				if (count == 4) {
					isCommand = 0;
					count = 0;
				}
			}
			else {
				buffer[index] = c;
				index++;
			}
		}
	}

	delete mainList;
	delete currentSection;
	delete[] buffer;

	return 0;
}
