#pragma once

class String { //selector is juat an element 
public:
	char* value;
	int valueSize; // '\0' is included in size

	String();
	String(char* buffer, int size);

	int equals(String* e);

	~String();

};
