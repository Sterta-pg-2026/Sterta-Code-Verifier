#pragma once
#include "linkedlist.h"
#include "string.h"

class Section {
public:
	LinkedList* selectors;
	LinkedList* attributes;

	Section();

	void addSelector(String* e);
	void addAttribute(Attribute* e);
	int deleteAttribute(String* e);
	int deleteSelector(String* e);
	String* findSelector(int number);
	String* findSelector(String* name);
	Attribute* findAttribute(String* name);
	int countAttribute(String* name);

	~Section();

};
