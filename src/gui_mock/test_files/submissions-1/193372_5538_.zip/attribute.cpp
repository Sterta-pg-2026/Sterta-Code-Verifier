#include "attribute.h"

Attribute::Attribute(String* name) {
	this->name = name;
	this->value = nullptr;
}

void Attribute::addValue(String* value) {
	this->value = value;
}