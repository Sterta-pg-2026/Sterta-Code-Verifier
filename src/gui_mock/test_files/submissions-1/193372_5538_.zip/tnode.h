#pragma once
#include "section.h"

class TNode {
	public:
		TNode* next;
		TNode* previous;
		Section** sections;
		int T;
		int fullness;

		TNode(int T);

		//~TNode();
	
};