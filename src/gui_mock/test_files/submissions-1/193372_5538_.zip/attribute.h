#pragma once
#include "string.h"

class Attribute {
public:
	String* name;
	String* value;

	Attribute(String* name);

	void addValue(String* value);
};
