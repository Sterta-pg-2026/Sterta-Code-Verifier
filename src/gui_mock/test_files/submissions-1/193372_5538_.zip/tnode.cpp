#include "tnode.h"

TNode::TNode(int T) {
	this->T = T;
	fullness = 0;
	next = nullptr;
	previous = nullptr;
	sections = new Section*[T];
}

/*TNode::~TNode() {
	for (int i = 0; i < T; i++){
		delete sections[i];
	}
}
*/