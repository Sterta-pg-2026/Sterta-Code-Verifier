#include "string.h"

String::String() {
	valueSize = 0;
	value = nullptr;
}

String::String(char* buffer, int size) { // '\0' is included in size
	this->valueSize = size;
	value = new char[size];
	for (int i = 0; i < size; i++){
		value[i] = buffer[i];
		buffer[i] = 0;
	}
}

int String::equals(String* e) { // '\0' is included in size
	if (this->valueSize == e->valueSize) {
		for (int i = 0; i < valueSize; i++){
			if (this->value[i] != e->value[i]) {
				return 0;
			}
		}
	}
	else {
		return 0;
	}
	return 1;
}

String::~String() {
	delete[] value;
}