#include "node.h"

Node::Node(String* c) {
	content = c;
	altContent = nullptr;
	next = nullptr;
}

Node::Node(Attribute* c) {
	altContent = c;
	content = nullptr;
	next = nullptr;
}

Node::~Node() {

}