#pragma once
#include "node.h"
#include "string.h"

class LinkedList {
	public:
		Node* head;
		Node* tail;
		int length;

		LinkedList();

		void addElement(String* e);
		void addElement(Attribute* e);

		~LinkedList();
	
};
