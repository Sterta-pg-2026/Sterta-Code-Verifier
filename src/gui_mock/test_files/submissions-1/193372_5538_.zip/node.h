#pragma once
#include "string.h"
#include "attribute.h"

class Node {
public:
	Node* next;
	String* content;
	Attribute* altContent;

	Node(String* c);
	Node(Attribute* c);
	~Node();

};