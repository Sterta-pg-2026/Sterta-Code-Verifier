#include "section.h"

Section::Section() {
	selectors = new LinkedList();
	attributes = new LinkedList();
}

void Section::addSelector(String* e) {
	selectors->addElement(e);
}

void Section::addAttribute(Attribute* e) {
	attributes->addElement(e);
}

int Section::deleteAttribute(String* name) {
	Node* previous = attributes->head;
	Node* current = attributes->head;
	for (int i = 0; i < attributes->length; i++) {
		if (current->altContent->name->equals(name)) {
			if (current == attributes->head && current == attributes->tail) {
				attributes->head = nullptr;
				attributes->tail = nullptr;
				return 2;
			}
			else if (current == attributes->head) {
				attributes->head = current->next;
			}
			else if (current == attributes->tail)
				attributes->tail = previous;
			previous->next = current->next;
			attributes->length--;
			return 1;
		}
		previous = current;
		current = current->next;
	}
	return 0;
}

int Section::deleteSelector(String* name) {
	Node* previous = selectors->head;
	Node* current = selectors->head;
	for (int i = 0; i < selectors->length; i++) {
		if (current->content->equals(name)) {
			if (current == selectors->head && current == selectors->tail) {
				selectors->head = nullptr;
				selectors->tail = nullptr;
			}
			else if (current == selectors->head) {
				selectors->head = current->next;
			}
			else if (current == selectors->tail)
				selectors->tail = previous;
			previous->next = current->next;
			selectors->length--;
			return 1;
		}
		previous = current;
		current = current->next;
	}
	return 0;
}


String* Section::findSelector(int number) {
	Node* current = selectors->head;
	if (number > selectors->length)
		return nullptr;
	for (int i = 1; i < number; i++) {
		current = current->next;
	}
	return current->content;
}

Attribute* Section::findAttribute(String* name) {
	if (attributes->head != nullptr) {
		Node* current = attributes->head;
		for (int i = 0; i < attributes->length; i++) {
			if (current != nullptr) {
				if (current->altContent->name->equals(name)) {
					return current->altContent;
				}
				current = current->next;
			}
		}
	}
	return nullptr;
}

String* Section::findSelector(String* name) {
	if (selectors->head != nullptr) {
		Node* current = selectors->head;
		for (int i = 0; i < selectors->length; i++) {
			if (current != nullptr) {
				if (current->content->equals(name)) {
					return current->content;
				}
				current = current->next;
			}
		}
	}
	return nullptr;
}


int Section::countAttribute(String* name) {
	int sum = 0;
	if (attributes->head != nullptr) {
		Node* current = attributes->head;
		for (int i = 0; i < attributes->length; i++) {
			if (current != nullptr) {
				if (current->altContent->name->equals(name)) {
					sum++;
				}
				current = current->next;
			}
		}
	}
	return sum;
}


Section::~Section() {

}