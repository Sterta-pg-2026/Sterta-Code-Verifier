#include "dllist.h"

DLList::DLList(int T) {
	head = nullptr;
	tail = nullptr;
	sectionCount = 0;
	length = 0;
	this->T = T;
}

void DLList::addSection(Section* s) {
	TNode* node;
	if (head == nullptr) {
		node = new TNode(T);
		node->sections[node->fullness] = s;
		node->fullness++;
		head = node;
		tail = node;
		length++;
	}
	else {
		node = tail;
		if (node->fullness > T) {
			TNode* node2 = new TNode(T);
			node2->sections[node2->fullness] = s;
			node2->fullness++;
			node->next = node2;
			node2->previous = node;
			tail = node2;
			length++;
		}
		else {
			node->sections[node->fullness] = s;
			node->fullness++;
		}
	}
	sectionCount++;
}

int DLList::deleteSection(int number) {
	TNode* current = head;
	int n = 0;
	if (number > sectionCount) {
		return 0;
	}
	for (int i = 1; i <= length; i++) {
		if (number <= current->fullness) {
			n = number - 1;
			break;
		}
		else {
			number = number - current->fullness;
			current = current->next;
		}
	}
	for (int i = n; i < current->fullness; i++) {
		current->sections[i] = current->sections[i + 1];
	}
	current->sections[current->fullness] = nullptr;
	current->fullness--;
	sectionCount--;

	return 1;
}

Section* DLList::findSection(int number) {
	if (head != nullptr) {
		TNode* current = head;
		for (int i = 0; i < this->length; i++) {
			if (number <= current->fullness) {
				return current->sections[number - 1];
			}
			else {
				number = number - current->fullness;
				current = current->next;
			}
		}
	}
	return nullptr;
}

Section* DLList::findSectionBySelector(String* e) {
	TNode* current = head;
	Node* cSmallNode = current->sections[0]->selectors->head;
	Section* result = nullptr;
	for (int i = 0; i < length; i++) { //node
		for (int j = 0; j < current->fullness; j++) { //section
			cSmallNode = current->sections[j]->selectors->head;
			for (int k = 0; k < current->sections[j]->selectors->length; k++) { //selector
				if (cSmallNode->content->equals(e)) {
					result = current->sections[j];
				}
				cSmallNode = cSmallNode->next;
			}
		}
		current = current->next;
	}
	return result;
}

int DLList::countSelector(String* e) {
	TNode* current = head;
	Node* cSmallNode = current->sections[0]->selectors->head;
	int count = 0;
	for (int i = 0; i < length; i++) { //node
		for (int j = 0; j < current->fullness; j++){ //section
			cSmallNode = current->sections[j]->selectors->head;
			for (int k = 0; k < current->sections[j]->selectors->length; k++) { //selector
				if (cSmallNode->content->equals(e)) {
					count++;
				}
				cSmallNode = cSmallNode->next;
			}
		}
		current = current->next;
	}
	return count;
}

int DLList::countAttribute(String* e) {
	TNode* current = head;
	int count = 0;
	for (int i = 0; i < length; i++) { //node
		for (int j = 0; j < current->fullness; j++) { //section
			count += current->sections[j]->countAttribute(e);
		}
		current = current->next;
	}
	return count;
}


DLList::~DLList() {
	if (head != nullptr) {
		TNode* current = head;
		TNode* next = current->next;
		for (int i = 0; i < length; i++) {
			delete current;
			if (next != nullptr) {
				current = next;
				next = current->next;
			}
		}
	}
}

