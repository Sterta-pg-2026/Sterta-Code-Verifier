#include "linkedlist.h"

LinkedList::LinkedList() {
	head = nullptr;
	tail = nullptr;
	length = 0;
}

void LinkedList::addElement(String* e) {
	Node* node = new Node(e);
	if (head == nullptr) {
		head = node;
		tail = node;
	}
	else {
		tail->next = node;
		tail = node;
	}
	length++;
}

void LinkedList::addElement(Attribute* e) {
	Node* node = new Node(e);
	if (head == nullptr) {
		head = node;
		tail = node;
	}
	else {
		tail->next = node;
		tail = node;
	}
	length++;
}

LinkedList::~LinkedList() {
	if (head != nullptr) {
		Node* current = head;
		Node* next = current->next;
		for (int i = 0; i < length; i++) {
			delete current;
			if (next != nullptr) {
				current = next;
				next = current->next;
			}
		}
	}
}