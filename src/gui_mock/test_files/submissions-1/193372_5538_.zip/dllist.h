#pragma once
#include "tnode.h"
#include "section.h"
#include "string.h"

class DLList {
	public:
		TNode* head;
		TNode* tail;
		int sectionCount;
		int length; //how many nodes
		int T; //size of one node

		DLList(int T);

		void addSection(Section* s);
		int deleteSection(int number);
		Section* findSection(int number);
		Section* findSectionBySelector(String* e);
		int countSelector(String* e);
		int countAttribute(String* e);

		~DLList();
};


