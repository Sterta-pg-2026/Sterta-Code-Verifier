#include "linkedlist.h"
#include <cstring>

template <class T> int LinkedList<T>::count() const {
  int count = 0;
  Node<T> *node = head;

  while (node != nullptr) {
    if (!node->data.isEmpty())
      count++;
    node = node->next;
  }

  return count;
}

template <class T> int LinkedList<T>::countWhere(const String &value) const {
  int count = 0;
  Node<T> *node = head;

  while (node != nullptr) {
    if (node->data == value) {
      count++;
      break;
    }
    node = node->next;
  }

  return count;
}

template <>
bool LinkedList<Attribute>::handleDuplicate(Node<Attribute> *node,
                                            const Attribute &value) {
  if (node->data.name == value.name || node->data.isEmpty()) {
    node->data.value = value.value;
    return true;
  }
  return false;
};
template <>
bool LinkedList<String>::handleDuplicate(Node<String> *node,
                                         const String &value) {
  return node->data == value;
};
template <class T> void LinkedList<T>::append(const T &value) {
  if (head == nullptr) {
    head = new Node<T>(value);
    return;
  }

  Node<T> *prev = head, *temp = head;
  while (temp != nullptr) {
    if (handleDuplicate(temp, value))
      return;

    prev = temp;
    temp = temp->next;
  }
  prev->next = new Node<T>(value);
}

template <class T> void LinkedList<T>::removeAll() {
  Node<T> *node = head;

  while (node != nullptr) {
    Node<T> *tmp = node;
    node = node->next;
    delete tmp;
  }

  head = nullptr;
}

template <class T> Node<T> *LinkedList<T>::operator[](int index) {
  if (head == nullptr)
    return nullptr;

  Node<T> *node = head;
  for (int i = 0; i < index; i++) {
    node = node->next;
    if (node == nullptr)
      return nullptr;
  }

  return node;
}

template <class T> LinkedList<T>::~LinkedList() { removeAll(); }

template class LinkedList<String>;
template class LinkedList<Attribute>;
