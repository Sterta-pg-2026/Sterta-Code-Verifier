#include "commands.h"

void countBlocks(const DoublyLinkedList &data) {
  DoublyNode *tmp = data.head;
  int sum = 0;

  while (tmp != nullptr) {
    sum += tmp->count;
    tmp = tmp->next;
  }

  std::cout << "? == " << sum << std::endl;
};

void countInBlock(const Command &command, const DoublyLinkedList &data) {
  int i = command.left.toInt() - 1;

  Block *block = data[i];
  if (block == nullptr || block->isEmpty())
    return;

  int count = command.name == 'S' ? block->selectors.count()
                                  : block->attributes.count();
  command.printResult(count);
};

void countAllWhere(const Command &command, const DoublyLinkedList &data) {
  int count = 0;

  DoublyNode *node = data.head;

  while (node != nullptr) {
    for (int i = 0; i < node->used; i++) {
      Block *block = &node->blocks[i];
      if (block->isEmpty())
        continue;
      count += command.name == 'S' ? block->selectors.countWhere(command.left)
                                   : block->attributes.countWhere(command.left);
    }
    node = node->next;
  }

  command.printResult(count);
};

void findAttributeInBlock(const Command &command,
                          const DoublyLinkedList &data) {
  int i = command.left.toInt() - 1;

  Block *block = data[i];
  if (block == nullptr)
    return;
  Node<Attribute> *attribute = block->attributes.head;
  while (attribute != nullptr) {
    if (attribute->data.name == command.right)
      break;
    attribute = attribute->next;
  }

  if (attribute == nullptr)
    return;

  command.printResult(attribute->data.value);
};

void findAttributeForSelector(const Command &command,
                              const DoublyLinkedList &data) {
  DoublyNode *node = data.tail;

  while (node != nullptr) {
    for (int i = node->count - 1; i >= 0; i--) {
      Block *block = &node->blocks[i];
      if (block->isEmpty())
        continue;

      Node<String> *selector = block->selectors.head;
      while (selector != nullptr) {
        if (selector->data == command.left || selector->data.isEmpty()) {
          break;
        }
        selector = selector->next;
      }
      if (selector == nullptr)
        continue;

      Node<Attribute> *attribute = block->attributes.head;
      while (attribute != nullptr) {
        if (attribute->data.name == command.right) {
          command.printResult(attribute->data.value);
          return;
        }
        attribute = attribute->next;
      }
    }
    node = node->prev;
  }
};

void findSelectorInBlock(const Command &command, const DoublyLinkedList &data) {
  int i = command.left.toInt() - 1;
  int j = command.right.toInt() - 1;

  Block *block = data[i];
  if (block == nullptr || block->isEmpty())
    return;
  Node<String> *selector = block->selectors[j];
  if (selector == nullptr || selector->data.isEmpty())
    return;

  command.printResult(selector->data);
};

void deleteWhere(const Command &command, DoublyLinkedList &data) {
  int i = command.left.toInt() - 1;
  bool hasDeleted =
      command.right == "*" ? data.remove(i) : data.remove(i, command.right);

  if (!hasDeleted)
    return;

  command.printResult("deleted");
};
