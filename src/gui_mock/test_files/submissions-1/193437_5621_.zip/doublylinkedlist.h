#pragma once
#include "linkedlist.h"

struct Block {
  LinkedList<String> selectors;
  LinkedList<Attribute> attributes;

  bool isEmpty() const { return attributes.head == nullptr; };
};

class DoublyNode {
public:
  static const int T = 27;
  int count = 0;
  int used = 0;

  Block blocks[T];
  DoublyNode *prev;
  DoublyNode *next;

  DoublyNode() : prev(nullptr), next(nullptr){};

  void append(const String &value);
  void append(const Attribute &value);
};

class DoublyLinkedList {
private:
  struct NodeBlock {
    DoublyNode *node = nullptr;
    Block *block = nullptr;
  };
  NodeBlock getNodeBlock(int index) const;
  bool remove(const NodeBlock &nodeBlock);

public:
  DoublyNode *head;
  DoublyNode *tail;

  DoublyLinkedList() : head(new DoublyNode()), tail(head){};
  DoublyLinkedList(const DoublyLinkedList &) = delete;
  DoublyLinkedList &operator=(const DoublyLinkedList &) = delete;

  template <class T> void append(const T &value);
  void updateBlockCount();
  bool remove(int index);
  bool remove(int index, const String &n);

  Block *operator[](int index) const;

  ~DoublyLinkedList();
};
