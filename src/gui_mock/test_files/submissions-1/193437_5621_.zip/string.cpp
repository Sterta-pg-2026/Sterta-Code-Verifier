#include "string.h"
#include <cstring>

String::String() {
  m_length = 0;
  m_capacity = DEFAULLT_SIZE;
  m_value = new char[m_capacity];
}
String::String(const String &other) {
  m_length = other.m_length;
  m_capacity = other.m_length + 1;
  m_value = new char[m_capacity]{};
  strcpy(m_value, other.m_value);
}

int String::length() const { return m_length; }
bool String::isEmpty() const { return m_length == 0; }
void String::clear() {
  m_length = 0;
  m_value[0] = '\0';
}

void String::trimEnd() {
  int i = m_length - 1;

  while (i >= 0 && m_value[i] <= SPACE_CHAR)
    i--;

  m_value[i + 1] = '\0';
  m_length = i + 1;
}

bool String::isNumber() const { return isdigit(m_value[0]); }
int String::toInt() const { return atoi(m_value); }

char &String::operator[](int i) { return m_value[i]; }

std::ostream &operator<<(std::ostream &os, const String &str) {
  os << str.m_value;
  return os;
};

bool operator==(const String &left, const String &right) {
  return std::strcmp(left.m_value, right.m_value) == 0;
}
bool operator==(const String &left, const char *right) {
  return std::strcmp(left.m_value, right) == 0;
}

String &String::operator=(const String &right) {
  if (this == &right)
    return *this;

  delete[] m_value;
  m_length = right.m_length;
  m_capacity = right.m_length + 1;
  m_value = new char[m_capacity];

  strcpy(m_value, right.m_value);
  return *this;
}

String &String::operator+=(const char &ch) {
  if (m_length + 1 >= m_capacity)
    reallocate(m_capacity * 2);

  m_value[m_length] = ch;
  m_value[m_length + 1] = '\0';
  m_length++;
  return *this;
}

void String::reallocate(int capacity) {
  if (capacity > m_capacity) {
    char *tmp = new char[capacity];
    strcpy(tmp, m_value);
    delete[] m_value;
    m_value = tmp;
    m_capacity = capacity;
  }
}

String::~String() { delete[] m_value; }
