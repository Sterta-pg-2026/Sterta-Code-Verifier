#include "string.h"

struct Attribute {
  String name;
  String value;

  Attribute() : name(String()), value(String()) {}
  Attribute(const Attribute &other) : name(other.name), value(other.value){};
  Attribute &operator=(const Attribute &right) = delete;

  bool isEmpty() const { return name.isEmpty(); }

  friend bool operator==(const Attribute &left, const String &right) {
    return left.name == right;
  }
};

template <class T> class Node {
public:
  T data;
  Node *next;

  explicit Node(const T &value) : data(value), next(nullptr){};
};

template <class T> class LinkedList {
private:
  bool handleDuplicate(Node<T> *node, const T &value);

public:
  Node<T> *head;

  LinkedList() : head(nullptr){};

  void append(const T &value);
  void removeAll();
  int count() const;
  int countWhere(const String &value) const;

  Node<T> *operator[](int index);

  ~LinkedList();
};
