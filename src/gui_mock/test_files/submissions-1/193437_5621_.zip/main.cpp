#include "commands.h"
#include "doublylinkedlist.h"
#include "string.h"
#include <iostream>

enum Mode { SELECTOR, ATTRIBUTE_NAME, ATTRIBUTE_VALUE, COMMAND };

void handleDataInput(DoublyLinkedList &data, String &buffer, char &ch,
                     Mode &mode, Attribute &attribute);
void handleCommandInput(DoublyLinkedList &data, String &buffer, char &ch,
                        Mode &mode, Command &command);

int main() {
  char ch;
  String buffer;
  Command command{};
  Mode mode = SELECTOR;
  Attribute attribute;
  bool isRunning = true;

  DoublyLinkedList data;

  while (isRunning) {
    if (!std::cin.get(ch)) {
      ch = '\n';
      isRunning = false;
    }

    if (mode != COMMAND)
      handleDataInput(data, buffer, ch, mode, attribute);
    else
      handleCommandInput(data, buffer, ch, mode, command);
  };

  return 0;
}

void handleDataInput(DoublyLinkedList &data, String &buffer, char &ch,
                     Mode &mode, Attribute &attribute) {
  if ((ch <= SPACE_CHAR && buffer.isEmpty()) ||
      (ch < SPACE_CHAR && !buffer.isEmpty()))
    return;

  if (mode == SELECTOR && (ch == ',' || ch == '{')) {
    buffer.trimEnd();
    data.append(buffer);
    if (ch == '{')
      mode = ATTRIBUTE_NAME;
  } else if (mode == ATTRIBUTE_NAME && ch == ':') {
    buffer.trimEnd();
    attribute.name = buffer;
    mode = ATTRIBUTE_VALUE;
  } else if (mode == ATTRIBUTE_VALUE && (ch == ';' || ch == '}')) {
    buffer.trimEnd();
    attribute.value = buffer;
    data.append(attribute);
    mode = ATTRIBUTE_NAME;

    if (ch == '}') {
      mode = SELECTOR;
      data.updateBlockCount();
    }
  } else if (ch == '}') {
    mode = SELECTOR;
    data.updateBlockCount();
  } else if (ch == '?' && buffer == "???") {
    mode = COMMAND;
  } else {
    buffer += ch;
    return;
  }

  buffer.clear();
}

void handleCommandInput(DoublyLinkedList &data, String &buffer, char &ch,
                        Mode &mode, Command &command) {
  if (ch == ',') {
    if (command.argCount == 0) {
      command.clear();
      command.left = buffer;
    } else if (command.argCount == 1 && buffer.length() == 1) {
      command.name = buffer[0];
    } else {
      command.clear();
      command.argCount--;
    }
    command.argCount++;

    buffer.clear();
    return;
  }

  if (ch > '\n') {
    buffer += ch;
    return;
  }

  if (command.argCount == 2) {
    command.right = buffer;

    if (command.left.isNumber() &&
        (command.name == 'S' || command.name == 'A') && command.right == "?") {
      // i,S,?
      // i,A,?
      countInBlock(command, data);
    } else if (!command.left.isNumber() &&
               (command.name == 'S' || command.name == 'A') &&
               command.right == "?") {
      // n,A,?
      // z,S,?
      countAllWhere(command, data);
    } else if (command.left.isNumber() && command.name == 'A' &&
               !command.right.isNumber()) {
      // i,A,n
      findAttributeInBlock(command, data);
    } else if (command.left.isNumber() && command.name == 'S' &&
               command.right.isNumber()) {
      // i,S,j
      findSelectorInBlock(command, data);
    } else if (!command.left.isNumber() && command.name == 'E' &&
               !command.right.isNumber()) {
      // z,E,n
      findAttributeForSelector(command, data);
    } else if (command.left.isNumber() && command.name == 'D') {
      // i,D,*
      // i,D,n
      deleteWhere(command, data);
    }
  } else if (command.argCount == 0 && buffer == "?") {
    countBlocks(data);
  } else if (buffer == "****") {
    mode = SELECTOR;
  }

  command.argCount = 0;
  buffer.clear();
}
