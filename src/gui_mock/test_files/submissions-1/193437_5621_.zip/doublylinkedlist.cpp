#include "doublylinkedlist.h"
#include <cstring>

void DoublyNode::append(const String &value) {
  Block *block = &blocks[used];

  if (block->selectors.head == nullptr) {
    block->selectors.head = new Node<String>(value);
    return;
  }

  block->selectors.append(value);
};
void DoublyNode::append(const Attribute &value) {
  Block *block = &blocks[used];

  if (block->attributes.head == nullptr) {
    block->attributes.head = new Node<Attribute>(value);
    return;
  }

  block->attributes.append(value);
};

void DoublyLinkedList::updateBlockCount() {
  tail->count++;
  tail->used++;
}

template <class T> void DoublyLinkedList::append(const T &value) {
  if (head == nullptr) {
    DoublyNode *newNode = new DoublyNode();
    head = newNode;
    tail = newNode;
  } else if (tail->used >= DoublyNode::T) {
    DoublyNode *newNode = new DoublyNode();
    tail->next = newNode;
    newNode->prev = tail;
    tail = newNode;
  }

  tail->append(value);
}
template void DoublyLinkedList::append(const String &value);
template void DoublyLinkedList::append(const Attribute &value);

bool DoublyLinkedList::remove(const NodeBlock &nodeBlock) {
  DoublyNode *node = nodeBlock.node;
  Block *block = nodeBlock.block;

  if (block == nullptr)
    return false;

  node->count--;

  block->selectors.removeAll();
  block->attributes.removeAll();

  if (node->count == 0) {
    if (node == head)
      head = node->next;
    if (node == tail)
      tail = node->prev;
    if (node->prev != nullptr)
      node->prev->next = node->next;
    if (node->next != nullptr)
      node->next->prev = node->prev;

    delete node;
  }
  return true;
};
bool DoublyLinkedList::remove(int index) {
  NodeBlock nodeBlock = getNodeBlock(index);
  return remove(nodeBlock);
}
bool DoublyLinkedList::remove(int index, const String &n) {
  NodeBlock nodeBlock = getNodeBlock(index);
  Block *block = nodeBlock.block;

  if (block == nullptr)
    return false;

  Node<Attribute> *prev = nullptr, *attribute = block->attributes.head;

  while (attribute != nullptr) {
    if (attribute->data.name == n) {
      if (prev == nullptr) {
        if (attribute->next == nullptr) {
          return remove(nodeBlock);
        }
        block->attributes.head = attribute->next;
      } else
        prev->next = attribute->next;

      delete attribute;

      return true;
    }
    prev = attribute;
    attribute = attribute->next;
  }

  return false;
}
DoublyLinkedList::NodeBlock DoublyLinkedList::getNodeBlock(int index) const {
  NodeBlock nodeBlock{};
  nodeBlock.node = head;
  int sum = 0;

  while (nodeBlock.node != nullptr) {
    if (sum + nodeBlock.node->count >= index + 1)
      break;
    sum += nodeBlock.node->count;
    nodeBlock.node = nodeBlock.node->next;
  }

  if (nodeBlock.node == nullptr)
    return nodeBlock;

  for (int i = 0; i < nodeBlock.node->used; i++) {
    if (nodeBlock.node->blocks[i].isEmpty())
      continue;
    if (sum == index) {
      nodeBlock.block = &nodeBlock.node->blocks[i];
      break;
    }
    sum++;
  }

  return nodeBlock;
}

Block *DoublyLinkedList::operator[](int index) const {
  return getNodeBlock(index).block;
}

DoublyLinkedList::~DoublyLinkedList() {
  DoublyNode *node = head;

  while (node != nullptr) {
    DoublyNode *tmp = node;

    node = node->next;
    delete tmp;
  }
}
