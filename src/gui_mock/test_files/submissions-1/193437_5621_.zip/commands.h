#include "doublylinkedlist.h"
#include "string.h"

struct Command {
  String left;
  char name;
  String right;
  uint8_t argCount;

  void clear() {
    left.clear();
    name = '\0';
    right.clear();
    argCount = 0;
  }

  template <typename T> void printResult(const T &result) const {
    std::cout << left << ',' << name << ',' << right << " == " << result
              << std::endl;
  }
};

void countBlocks(const DoublyLinkedList &data);
void countInBlock(const Command &command, const DoublyLinkedList &data);
void countAllWhere(const Command &command, const DoublyLinkedList &data);
void findAttributeInBlock(const Command &command, const DoublyLinkedList &data);
void findAttributeForSelector(const Command &command,
                              const DoublyLinkedList &data);
void findSelectorInBlock(const Command &command, const DoublyLinkedList &data);
void deleteWhere(const Command &command, DoublyLinkedList &data);
