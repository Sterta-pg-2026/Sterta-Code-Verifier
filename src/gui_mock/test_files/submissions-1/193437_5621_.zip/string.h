#pragma once

#include <iostream>

#define SPACE_CHAR 32

class String {
private:
  char *m_value;
  int m_capacity;
  int m_length;

  void reallocate(int capacity);

public:
  static const int DEFAULLT_SIZE = 16;

  String();
  String(const String &other);

  bool isEmpty() const;
  int length() const;
  void trimEnd();
  void clear();
  bool isNumber() const;
  int toInt() const;

  char &operator[](int i);
  friend std::ostream &operator<<(std::ostream &os, const String &str);
  friend bool operator==(const String &left, const String &right);
  friend bool operator==(const String &left, const char *right);
  String &operator=(const String &right);
  String &operator+=(const char &ch);

  ~String();
};
