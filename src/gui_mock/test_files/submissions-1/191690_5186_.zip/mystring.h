#pragma once
#include "singlylinkedlist.h"

class MyString : public Sngl_Lst<char> {
public:
	MyString() : Sngl_Lst<char>() { }
	MyString(const char* str) : MyString() {
		for (int i = 0; str[i] != '\0'; i++) {
			Add(str[i]);
		}
	}
	void Append(const char* str) {
		for (int i = 0; str[i] != '\0'; i++) {
			Add(str[i]);
		}
	}
	void Append(char c) {
		Add(c);
	}
	bool Compare(const MyString& s) {
		if (this->NElements != s.NElements) return false;
		Sngl_Lst_Node<char>* temp1 = this->head;
		Sngl_Lst_Node<char>* temp2 = s.head;
		while (temp1 != nullptr && temp2 != nullptr) {
			if (temp1->data != temp2->data) return false;
			temp1 = temp1->next;
			temp2 = temp2->next;
		}
		return true;
	}
	friend std::ostream& operator<<(std::ostream&, const MyString&);
	friend std::ostream& operator>>(std::ostream&, const MyString&);
	
};

std::ostream& operator<<(std::ostream& os, const MyString& str) {
	Sngl_Lst_Node<char>* temp = str.head;
	while (temp != nullptr) {
		os << temp->data;
		temp = temp->next;
	}
	return os;
}

std::istream& operator>>(std::istream& is, MyString& str) {
	char input;
	is >> std::ws;
	while (is.get(input) && !is.fail() && !iswspace(input)) {
		str.Add(input);
	}
	return is;
}
