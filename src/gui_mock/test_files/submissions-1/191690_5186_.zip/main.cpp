#include <iostream>
#include "singlylinkedlist.h"
#include "doublylinkedlist.h"
#include "mystring.h"

enum Query_type {CSS_input, Sections_N, Selectors_N, Attributes_N,
Get_Selector, Get_Value, Count_Attr, Count_Sel, Get_Value_Spec, Del_Block, Del_Attr};

struct Attribute {
    MyString name;
    MyString value;
};

struct Section {
    Sngl_Lst<MyString> selectors;
    Sngl_Lst<Attribute> attributes;
};

bool IsANumber(MyString& s) {
    char digits[] = { 0,1,2,3,4,5,6,7,8,9 };
    auto temp = s.head;
    char curr;
    while (temp != nullptr) {
        curr = s.head->data;
        for (int i = 0; i < 10; i++) {
            if (curr == digits[i]) break;
            if (i == 9) return false;
        }
        temp = temp->next;
    }
    return true;
}

bool GetSelectors(Sngl_Lst<MyString>& list) {
    char input = 'x';
    MyString s;
    while (input != '{') {
        while (std::cin.get(input)) {
            if (input != '{' && input != ',' && !iswspace(input))
                s.Append(input);
            if (input == ',') {
                list.Add(s);
                MyString s;
                break;
            }
            if (input == '{') {
                list.Add(s);
                break;
            }
            // check if string is equal to ????
            // then return 0 if it is
            if (s.head != nullptr) {
                if (s.Compare("????")) return false;
            }
        }
    }
    return true;
}

void GetAttributes(Sngl_Lst<Attribute>& list) { 
    char input = 'x';
    Attribute a;
    while (input != '}') {
        while (std::cin.get(input)) {
            if (input != '}' && input != ';' && input != ':' && !iswspace(input)) {
                a.name.Append(input);
            }
            if (input == ':') {
                while (input != ';') {
                    while (std::cin.get(input)) {
                        if (input != ';') {
                            // don't add the space between the ':' and the values
                            if (!(input == ' ' && a.value.head == nullptr)) {
                                a.value.Append(input);
                            }
                        }
                        else break;
                    }
                }
            }
            if (input == ';') {
                list.Add(a);
                a.name.FreeList();
                a.value.FreeList();
            }
            if (input == '}') break; 
        }
    }
}

int AnalyseQuery(Sngl_Lst<MyString>& q) {
    //function determines what type of query needs to be executed
    //basing on each part of query
    Sngl_Lst_Node<MyString>* first_part = q.head;
    Sngl_Lst_Node<MyString>* second_part = first_part->next;
    Sngl_Lst_Node<MyString>* third_part = second_part->next;
    char command = second_part->data.head->data;
    char info = third_part->data.head->data;
    //determine whether the first element of a query 
    //is a number or a name of a selector
    if (IsANumber(first_part->data)) {
        if (command == 'S') {
            if (info == '?') return Selectors_N;
            else return Get_Selector;
        }
        if (command == 'A') {
            if (info == '?') return Attributes_N;
            else return Get_Value;
        }
        if (command = 'D') {
            if (info == '*') return Del_Block;
            else return Del_Attr;
        }
    }
    else {
        if (command == 'A') return Count_Attr;
        if (command == 'S') return Count_Sel;
        if (command == 'E') return Get_Value_Spec;
    }
    return 0;
}

int GetQuery(Sngl_Lst<MyString>& q) {
    char input = 'x'; 
    int part = 1;
    MyString s;
    while (part < 4) {
        while (std::cin.get(input)) {
            if (input != ',') s.Append(input);
            if (input == '?' && part == 1) {
                q.Add(s);
                return Sections_N;
            }
            if (input == ',') {
                q.Add(s);
                MyString s;
                part++;
                break;
            }
            // check if string is equal to ****
            // then return 0 if it is
            if (s.head != nullptr) {
                if (s.Compare("****")) return CSS_input;
            }
        }
    }
    return AnalyseQuery(q);
}

int main() {
    int q_type;
    bool get_css = true;
    Dbl_Lst<Section> css;
    Sngl_Lst<MyString> query;
    while (true) {
        Section sct;
        get_css = GetSelectors(sct.selectors);
        if (get_css) {
            GetAttributes(sct.attributes);
            css.Add(sct);
            sct.attributes.FreeList();
            sct.selectors.FreeList();
        }
        while (!get_css) {
            q_type = GetQuery(query);
            if (q_type == CSS_input) get_css = true;
            if (q_type == Sections_N) {
                query.Print();
                std::cout << " == " << css.NElements;
            }
            if (q_type == Selectors_N) {
                Dbl_Lst_Node<Section>* temp = css.head;
                MyString s = query.head->data;
                char c = s.head->data;
                int n = c + '0';
                for (int i = 1; i < n; i++) {
                    temp = temp->next;
                }
                query.Print();
                std::cout << " == " << temp->data.selectors.NElements;
            }
            query.FreeList();
        }
    }
    
}


