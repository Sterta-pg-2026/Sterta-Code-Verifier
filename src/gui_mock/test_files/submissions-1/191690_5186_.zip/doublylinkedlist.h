#pragma once
#include <iostream>

template <typename T>
struct Dbl_Lst_Node {
	T data;
	struct Dbl_Lst_Node<T>* next;
	struct Dbl_Lst_Node<T>* prev;
};

template <typename T>
class Dbl_Lst {
public:
	Dbl_Lst_Node<T>* head = nullptr;
	Dbl_Lst_Node<T>* tail = nullptr;
	int NElements = 0;

	Dbl_Lst() = default;
	Dbl_Lst(const Dbl_Lst<T>& l) : Dbl_Lst() {
		Dbl_Lst_Node<T>* temp = l.head;
		while (temp != nullptr) {
			Add(temp->data);
			temp = temp->next;
		}
	}
	void Add(const T& value) {
		if (head == nullptr) {
			head = new Dbl_Lst_Node<T>;
			head->data = value;
			head->next = nullptr;
			head->prev = nullptr;
			tail = head;
		}
		else {
			Dbl_Lst_Node<T>* temp = tail;
			temp->next = new Dbl_Lst_Node <T>;
			temp->next->data = value;
			temp->next->next = nullptr;
			temp->next->prev = tail;
			tail = temp->next;
		}
		NElements++;
	}
	void Add(const Dbl_Lst<T>& list) {
		auto it = list.head;
		while (it != nullptr) {
			Add(it->data);
			it = it->next;
		}
	}
	void Print() {
		Dbl_Lst_Node<T>* temp = head;
		while (temp != nullptr) {
			std::cout << temp->data << ',';
			temp = temp->next;
		}
	}
	void FreeList() {
		Dbl_Lst_Node<T>* temp = head;
		while (temp != nullptr) {
			temp = head->next;
			delete head;
			head = temp;
		}
		NElements = 0;
	}
	~Dbl_Lst() {
		FreeList();
	}
	inline int size() const {
		return NElements;
	}
	Dbl_Lst<T>& operator=(const Dbl_Lst<T>& list) {
		FreeList();
		Add(list);
		return *this;
	}
};
