#pragma once
#include <iostream>

template <typename T>
struct Sngl_Lst_Node {
	T data;
	struct Sngl_Lst_Node<T>* next;
};

template <typename T>
class Sngl_Lst {
public:
    Sngl_Lst_Node<T>* head = nullptr;
    Sngl_Lst_Node<T>* tail = nullptr;
    int NElements = 0;

    Sngl_Lst() = default;
	Sngl_Lst(const Sngl_Lst<T>& l) : Sngl_Lst() {
		Sngl_Lst_Node<T>* temp = l.head;
		while (temp != nullptr) {
			Add(temp->data);
			temp = temp->next;
		}
    }
    void Add(const T& value) {
        if (head == nullptr) {
            head = new Sngl_Lst_Node<T>;
            head->data = value;
            head->next = nullptr;
            tail = head;
        }
        else {
            Sngl_Lst_Node<T>* temp = tail;
            temp->next = new Sngl_Lst_Node <T>;
            temp->next->data = value;
            temp->next->next = nullptr;
            tail = temp->next;
        }
        NElements++;
    }
	void Add(const Sngl_Lst<T>& list) {
		auto temp = list.head;
		while (temp != nullptr) {
			Add(temp->data);
			temp = temp->next;
		}
	}
	void Print() {
		Sngl_Lst_Node<T>* temp = head;
		while (temp != nullptr) {
			std::cout << temp->data;
			if(temp->next != nullptr) std::cout << ',';
			temp = temp->next;
		}
	}
	void FreeList() {
		Sngl_Lst_Node<T>* temp = head;
		while (temp != nullptr) {
			temp = head->next;
			delete head;
			head = temp;
		}
		NElements = 0;
	}
	~Sngl_Lst() {
		FreeList();
	}
	inline int size() const {
		return NElements;
	}
	Sngl_Lst<T>& operator=(const Sngl_Lst<T>& list) {
		FreeList();
		Add(list);
		return *this;
	}
};
