#include <iostream>
#pragma warning(disable : 4996)

const int T = 17;
const int MAX_SIZE = 1000;
using namespace std;

struct mystring {
    char* str;
    int len;

    mystring(const char* string = "") {
        len = strlen(string);
        str = new char[len + 1];
        strcpy(str, string);
    }


    void assign(const mystring& string) {
        if (this == &string) return;
        if (str != nullptr) delete[] str;
        len = string.len;
        str = new char[len + 1];
        strcpy(str, string.str);
    }
};

void init_string(mystring *s, char *str) { //inicjalizacja tablicy charów do stringa
    s->str = str;
    s->len = strlen(str);
}

void remove_trailing_whitespace(mystring& str) {
    int i = str.len - 1;
    while (i >= 0 && isspace(str.str[i])) {
        str.str[i] = '\0';
        i--;
    }
    str.len = strlen(str.str);
}

void cleartab(char* tab, int n) {
    for (int i = 0; i < n; i++) {
        tab[i] = '\0';
    }
}

int is_numeric(mystring* str) {
    if (str == NULL || str->str == NULL || str->len == 0) {
        return -1;
    }
    int number = 0;
    for (int i = 0; i < str->len; i++) {
        if (isdigit(str->str[i])) {
            number = number * 10 + (str->str[i] - '0');
        }
        else {
            return -1;
        }
    }
    return number;
}


int compare_string(mystring s1, mystring s2) {
    return strcmp(s1.str, s2.str);
}

struct Selector{
	Selector* next = nullptr; 
	mystring *name; 

};

struct Attribute {
	Attribute* next = nullptr;
	mystring *name;
	mystring *value;
};



class Section {
	private:
		Selector* firstselect; //wskaźniki na pierwszy selektor i atrybut zeby potem ładnie sobie po nich iterować
		Attribute* firstattribut;
        int countSelect;
        int countAttri;

	public:
		Section() : firstselect(nullptr), firstattribut(nullptr), countAttri(0), countSelect(0){

        }

		void setSelector(Selector* selector) {
            firstselect = selector;
        }
        void setAttribute(Attribute* attribute) {
            firstattribut = attribute;
        }
        Selector* getSelector() const {
            return firstselect;
        }
        Attribute* getAttribute() const {
            return firstattribut;
        }

        int getACounter() const {
            return countAttri;
        }

        int getSCounter() const {
            return countSelect;
        }

        void printPointers() {
            cout << "selector: " << firstselect << endl << "attribute: " << firstattribut << endl;
        }

        void setSelectorName(Selector* selector, mystring name) {
            selector->name->assign(name);
        }
        
        void readSection(int c1) { 
            mystring namea, names;
            mystring value;
            char storebox1[MAX_SIZE] = { 0 }, storebox2[MAX_SIZE] = { 0 };
            int c, i = 0, j=0; // i - będzie długość stringa
            //wczytywanie selektorów
            c = c1;
            while (c != '{') {
                i = 0;
                if (c == ' ' || c=='\r') {
                    c = getchar();
                    continue;
                }
                while (c != ',' && c!='{' && c!='\r') {
                    if (c!= 9 && c!='\n' && c!=10) { 
                        storebox1[i++] = c;
                    }
                    c = getchar(); 
                }
                if (c != '{') {
                    c = getchar();
                }
               
                init_string(&names, storebox1);
                remove_trailing_whitespace(names);
                addSelector(names);
                cleartab(storebox1, i);
            }
            //wczytywanie atrybutów
            
            c = 'c';
            while (c != '}') {
                if ((c = getchar()) == '}') break;
                if (c == ' ' || c==9 || c==10 || c=='\r') continue;
                i = 0;
                if (c == '}') break;
                if (c !=9 && c!=10 && c!='\r') {
                    while (c != ':') {
                        if (c != '\n' && c!= 9) {
                            storebox1[i++] = c;
                        }
                        c = getchar();
                    }
                }
                else {
                    c = getchar();
                }   
                
                
                init_string(&namea, storebox1);
                j = 0;
                c = getchar();
                if (c == ' ') {
                    c = getchar();
                }
                
                while (c != ';' && c != '}') {
                    if (c!=9 and c!=10) {
                        storebox2[j++] = c;
                    }
                    if (c != '}') {
                        c = getchar();
                    }
                    else break;
                }
                init_string(&value, storebox2);
                addAttribute(namea, value);
                cleartab(storebox2, j);
                cleartab(storebox1, i);
                i = 0;
            }
        }
        

      
        void printSection() {
            cout << "Selektory: \n";
            Selector* tempSelector = firstselect;
            while (tempSelector) {
                cout << tempSelector->name->str << " ";
                tempSelector = tempSelector->next; 
            }
            cout << endl << "Atrybuty: \n";
            Attribute* tempAttribute = firstattribut;
            while (tempAttribute) {
                cout << tempAttribute->name->str << ":" << tempAttribute->value->str << endl;
                tempAttribute = tempAttribute->next;
            }
        }

        int howmanySelectors() {
            int howmany = 0;
            Selector* tempSelector = firstselect;
            while (tempSelector) {
                howmany += 1;
                tempSelector = tempSelector->next;
            }
            return howmany;
        }

        int howmanyAttributes() {
            int howmany = 0;
            Attribute* tempAttribute = firstattribut;
            while (tempAttribute) {
                howmany += 1;
                tempAttribute = tempAttribute->next;
            }
            return howmany;
        }
        const char* getnAttribute(const char* n) {
            Attribute* tempAttribute = firstattribut;
            while (tempAttribute) {
                if ((strcmp(n, tempAttribute->name->str)) == 0) {
                    return tempAttribute->value->str;
                }
                tempAttribute = tempAttribute->next;
            }
            return "-";
        }


        bool delA(const char* n) {
            Attribute* tempAttribute = firstattribut;
            Attribute* prevAttribute = nullptr; 
            while (tempAttribute) {
                if (strcmp(tempAttribute->name->str, n) == 0) {
                    if (prevAttribute) {
                        prevAttribute->next = tempAttribute->next;
                    }
                    else {
                        firstattribut = tempAttribute->next;
                    }
                    delete tempAttribute->name;
                    delete tempAttribute->value;
                    delete tempAttribute;
                    return true; 
                }
                prevAttribute = tempAttribute;
                tempAttribute = tempAttribute->next;
            }
            return false;
        }

        const char* getjSelector(int j) {
            j--;
            int howmany = 0;
            Selector* tempSelector = firstselect;
            while (tempSelector) {
                if (howmany == j) {
                    return tempSelector->name->str;
                }
                howmany++;
                tempSelector = tempSelector->next;
            } 
            return "0";
        }
        

        const char* findESelector(const char* selector, const char* attribute) { //kurde bierze mi pierwsze wystąpienie w bloku a nie ostatnie, hm
            Selector* tempSelector = firstselect;
            const char* result = "0";
            while (tempSelector) {
                if ((strcmp(selector, tempSelector->name->str)) == 0) {
                    Attribute* tempAttribute = firstattribut;
                    while (tempAttribute) {
                        if ((strcmp(attribute, tempAttribute->name->str)) == 0) {
                            result =  tempAttribute->value->str;
                        }
                        tempAttribute = tempAttribute->next;
                    }
                }
                tempSelector = tempSelector->next;
            }
            
            return result;
        }

        int countAttribute(const char* n) {
            Attribute* tempAttribute = firstattribut;
            int howmany = 0;
            while (tempAttribute) {
                if ((strcmp(n, tempAttribute->name->str)) == 0) {
                    howmany++;
                    break;
                }
                tempAttribute = tempAttribute->next;
            }
            return howmany;
        }

        int countSelector(const char* n) {
            Selector* tempSelector = firstselect;
            int howmany = 0;
            while (tempSelector) {
                if ((strcmp(n, tempSelector->name->str)) == 0) {
                    howmany++;
                }
                tempSelector = tempSelector->next;
            }
            return howmany;
        }

        void addSelector(mystring name) {
            Selector* newSelector = new Selector();
            newSelector->name = new mystring;
            newSelector->name->assign(name);
            if (firstselect) {
                Selector* temp = firstselect;
                while (temp->next) {
                    temp = temp->next;
                }
                temp->next = newSelector;
            }
            else {
                firstselect = newSelector;
            }
            countSelect++;
        }
        void addAttribute(mystring name, mystring value) {
            Attribute* newAttribute = new Attribute();
            newAttribute->name = new mystring;
            newAttribute->name->assign(name);
            newAttribute->value = new mystring;
            newAttribute->value->assign(value);
            if (firstattribut) {
                Attribute* temp = firstattribut;
                while (temp->next) {
                    temp = temp->next;
                }
                temp->next = newAttribute;
            }
            else {
                firstattribut = newAttribute;
            }
            countAttri++;
        }

        void removeDuplicateAttributes() {
            Attribute* curr = firstattribut;
            while (curr != nullptr) {
                Attribute* prev = curr;
                Attribute* next = curr->next;
                while (next != nullptr) {
                    if (strcmp(curr->name->str, next->name->str) == 0) {
                        prev->next = next->next;
                        curr->value->str = next->value->str;
                        delete next;
                        next = prev->next;
                    }
                    else {
                        prev = next;
                        next = next->next;
                    }
                }
                curr = curr->next;
            }
        }
        void removeDuplicateSelectors() {
            Selector* curr = firstselect;
            while (curr != nullptr) {
                Selector* prev = curr;
                Selector* next = curr->next;
                while (next != nullptr) {
                    if (strcmp(curr->name->str, next->name->str) == 0) {
                        prev->next = next->next;
                        delete next;
                        next = prev->next;
                    }
                    else {
                        prev = next;
                        next = next->next;
                    }
                }
                curr = curr->next;
            }
        }

};

class Block {
    private:
        Section* section[T];
        Block* prev;
        Block* next;
        //int howmany; //ile jest aktualanie sekcji w bloku
    public: 
        Block() {
            for (int i = 0; i < T; i++) {
                section[i] = new Section(); //iterowanie po indeksach nie musze sobie dodatkowego wskaznika nigdzie wyciągać
            }
            prev = nullptr;
            next = nullptr;
            
        }
        ~Block() {
            for (int i = 0; i < T; i++) {
                delete section[i];
            }
        }
        void printBlock() {
            for (int i = 0; i < T; i++) {
                if (section[i]->getAttribute()) {
                    cout << "Sekcja " << i << " : \n";
                    section[i]->printSection();
                    cout << endl;
                }
                
            }
        }

        bool isEmpty() {
            for (int i = 0; i < T; i++) {
                if (section[i]->getSelector() == NULL && section[i]->getAttribute() == NULL) {
                    return false;
                }
            }
            return true;
        }

        void removeifEmpty() { //po napisaniu komend zobaczyc czy to działa
            if (isEmpty()) { 
                if (prev) {
                    prev->next = next;
                }
                if (next) {
                    next->prev = prev;
                }
                delete this; 
            }
        }

        int howmanyS(int which, int where) {
            int howmany = 0;
            for (int i = 0; i < T; i++) {
                if (where + i == which) {
                    howmany = section[i]->howmanySelectors();
                }
            }
            return howmany;
        }
        
        int howmanyA(int which, int where) {  
            int howmany = 0;
            for (int i = 0; i < T; i++) {
                if (where*T + i == which) {
                    howmany = section[i]->howmanyAttributes();
                }
            }
            return howmany;
        }



        bool deleteSection(int x, int where) {
            bool deleted = false;
            x--;
            for (int i = 0; i < T;i++) {
                if (where * T + i == x) {
                    section[i] = nullptr;
                    deleted = true;
                    return deleted;
                }
            }
            return deleted;
        }

        int deleteAttribute(int x,const char* n, int where) { //0 - nic sie nie stalo 1 - usuniety atrybut, sekcja zostala, 2- usuniety atrybut pusta sekcja;
            bool deleted = false;
            x--;
            for (int i = 0; i < T; i++) {
                if (where * T + i == x) {
                    deleted = section[i]->delA(n);
                    if (deleted and !section[i]) {
                        return 2;
                    }
                    else if (deleted) return 1;
                }
            }
            return 0;
        }


        void shiftSections() {
            for (int i = 0; i < T - 1; i++) {
                if (section[i] == nullptr && section[i + 1] != nullptr) {
                    // przesunięcie sekcji w górę, tylko gdy kolejna sekcja jest niepusta
                    for (int j = i + 1; j < T; j++) {
                        if (section[j] != nullptr) {
                            section[i] = section[j];
                            section[j] = nullptr;
                            break;
                        }
                    }
                }
            }
        }



        const char* whichAttribute(int i, const char* n, int where) {
            const char* howmany = nullptr;
            for (int x = 0; x < T; x++) {
                if (where * T + x  == i) {
                    howmany = section[x]->getnAttribute(n);
                    if (strcmp(howmany, "-") != 0) {
                        return howmany;
                    }
                    else break;
                    
                }
            }
            if (howmany != nullptr) return howmany;
            else return "-";
        }

        const char* whichSelector(int i, int j, int where) {
            const char* howmany=nullptr;
            for (int x = 0; x < T; x++) {    
                 if (where*T + x == i) {
                    howmany = section[x]->getjSelector(j);
                    return howmany;
                }
                 if (where + x > i) {
                     return "#"; //przeszlo za daleko i break;
                 }
            }
            return "0";
        }

        

        const char* FindE(const char* selector, const char* attribute) {
            const char* value;
            for (int i = T-1; i > 0; i--) {
                value = section[i]->findESelector(selector, attribute);
                if (strcmp(value, "0") != 0) {
                    return value;
                }
            }
            return "0";
        }

        int CountSectionAttributes(const char* n) {
            int howmany = 0;
            for (int i = 0; i < T; i++) {
                howmany += section[i]->countAttribute(n);
            }
            return howmany;
        }

        int CountSectionSelectors(const char* n) {
            int howmany = 0;
            for (int i = 0; i < T; i++) {
                howmany += section[i]->countSelector(n);
            }
            return howmany;
        }




       Section* getSection(int i) {
            return section[i];
        }


        Block* getPrev() {
            return prev;
        }

        Block* getNext() {
            return next; 
        }

        /* int getHowMany() {
            return howmany;
        }*/

        void setPrev(Block* block) {
            prev = block;
        }

        void setNext(Block* block) {
            next = block;
        }

        void printLastSection(int where) {
            section[where]->printSection();
        }

        /*void readBlocks() {
            for (int i = 0; i < T; i++) {
                section[i]->readSection();
            }
        }*/

        void addSection(int where, int c) {
            section[where]->readSection(c);
        }
        

        //dodać metoda która mi zlicza ile miejsc w bloku jest zajętych, a potem w klasie BlockList metodę która mi sprawdza czy któryś z bloków ma 
        //pustą zawartość, jeśli ta to niech go usunie z węzła i ez

    
};


class BlockList {
    private:
        Block* head;
        Block* tail;
    public: 
        BlockList() {
            head = nullptr;
            tail = nullptr;
        }
        ~BlockList() {
            while (head != nullptr) {
                Block* temp = head;
                head = head->getNext();
                delete temp;
            }
        }

        void addBlock() {
            Block* newBlock = new Block();
            if (head == nullptr) {
                head = newBlock;
                tail = newBlock;
            }
            else {
                tail->setNext(newBlock);
                newBlock->setPrev(tail);
                tail = newBlock;
            }
        }

        Block* getHead() {
            return head;
        }

        Block* getTail() {
            return tail;
        }

        /*void removeBlock() {

        } ogólnie to dorobie to potem, bo teraz w sumie nie wiem na jakiej zasadzie to ma działac*/

        void printList() {
            Block* current = head;
            int whichblock = 0;
            while (current != nullptr) {
                cout << "Blok nr: " << whichblock<<endl;
                current->printBlock();
                cout << endl;
                current = current->getNext();
                whichblock++;
            }
            cout << endl;
        }

        int FindandCountSelectors(int which) {
            Block* current = head;
            which--;
            int currentindex = 0, howmany=0;
            while (current != nullptr) {
                howmany = current->howmanyS(which, currentindex);
                if (howmany == 0) {
                    currentindex += T;
                }
                else {
                    return howmany;
                }
                current = current->getNext();
            }
            return howmany; 
        }

        int FindandCountAttritbutes(int which) {
            Block* current = head;
            which--;
            int currentindex = 0, howmany = 0;
            while (current != nullptr) {
                howmany = current->howmanyA(which, currentindex);
                if (howmany == 0) {
                    currentindex++;
                }
                else {
                    return howmany;
                }
                current = current->getNext();
            }
            return howmany;
        }
        const char* FindandPrintAttribute(int i, const char* n) {
            Block* current = head;
            i--;
            int currentindex = 0;
            const char* howmany = nullptr;
            while (current != nullptr) {
                howmany = current->whichAttribute(i, n, currentindex);
                if (strcmp(howmany, "-") != 0) {
                    return howmany;

                }
                current = current->getNext();
                currentindex++;
            }
            return "-";
        }

        const char* FindandPrintSelector(int i, int j) {
            Block* current = head;
            i--;
            int currentindex = 0;
            const char* howmany = nullptr;
            while (current != nullptr) {
                howmany = current->whichSelector(i, j, currentindex);
                if (strcmp(howmany, "#") == 0 or strcmp(howmany, "0") == 0) return "";
                if (strcmp(howmany, "0") !=0) {
                    return howmany;
                }
                current = current->getNext();
                currentindex++;
            }
            return "";
        }

        


        const char* FindandPrintE(const char* selector, const char* attribute) {
            Block* current = tail;
            //int currentindex;
            const char* value = nullptr;
            while (current != nullptr) {
                value = current->FindE(selector, attribute);
                if (strcmp(value, "0") != 0) {
                    return value;
                }
                else current = current->getPrev();
            } 
            return "0";
        }

        int FindandCountCerAttributes(const char* n) {
            Block* current = head; 
            int howmany = 0;
            while (current != nullptr) {
                howmany += current->CountSectionAttributes(n);
                current = current->getNext();
            }
            return howmany;

        }

        int FindandCountCerSelectors(const char* n) {
            Block* current = head;
            int howmany = 0;
            while (current != nullptr) {
                howmany += current->CountSectionSelectors(n);
                current = current->getNext();
            }
            return howmany;

        }


        void removeEmptyBlocks() {
            Block* tempBlock = head;
            while (tempBlock) {
                bool allEmpty = true;
                for (int i = 0; i < T; i++) {
                    Section* tempSection = tempBlock->getSection(i);
                    if (tempSection != nullptr) allEmpty = false;
                }
                if (allEmpty) {
                    // usunięcie bloku
                    Block* prevBlock = tempBlock->getPrev();
                    Block* nextBlock = tempBlock->getNext();
                    if (prevBlock) {
                        prevBlock->setNext(nextBlock);
                    }
                    else {
                        head = nextBlock;
                    }
                    if (nextBlock) {
                        nextBlock->setPrev(prevBlock);
                    }
                    else {
                        tail = prevBlock;
                    }
                    delete tempBlock;
                }
                tempBlock = tempBlock->getNext();
            }
        }

        bool removeSection(int i) {
            Block* tempBlock = head;
            int currentindex = 0;
            while (tempBlock) {
                bool isdeleted = tempBlock->deleteSection(i, currentindex);
                if (isdeleted == true) {
                    tempBlock->shiftSections();
                    return true;
                }
                tempBlock = tempBlock->getNext();
            }
            return false;
        }

        int removeAfromSection(int i, const char* n) { //0 nic, 1-usuniety atrybut 2 - usuniety atrybut razem z sekcja
            Block* tempBlock = head;
            int currentindex = 0;
            while (tempBlock) {
                int isdeleted = tempBlock->deleteAttribute(i, n, currentindex);
                if (isdeleted == 1) return 1;
                if (isdeleted == 0) return 0;
                if (isdeleted == 2) {
                    if (tempBlock->deleteSection(i, currentindex)) {
                        tempBlock->shiftSections();
                        return 2;
                    }
                }
                tempBlock = tempBlock->getNext();
            }
            return 0;
        }

};


int main() {
	 
    BlockList myList;
    myList.addBlock(); 
    int SectionCounter = 0, BlockCounter = 1;
    int secorcomm=0; //wczytywanie sekcji czy komendy, gdzie 0 - sekcje, 1 - komendy
    Block* currentBlock = myList.getTail();
    int c=1; 
    mystring pom2;
    int operation = 0;
    bool correctcommand = true;
    while (c != EOF) { 
        if (secorcomm == 0) {
            c = getchar();
            if (c == EOF) break;
            if ((char)c != '?' and c!=10 and c!= 9) {
                if ((SectionCounter % T == 0 and SectionCounter!=0)) {
                    myList.addBlock();
                    currentBlock = myList.getTail();
                    BlockCounter += 1;
                    myList.getTail()->addSection(SectionCounter % T, c);
                    myList.getTail()->getSection(SectionCounter % T)->removeDuplicateAttributes();
                    myList.getTail()->getSection(SectionCounter % T)->removeDuplicateSelectors();
                    SectionCounter += 1;
                }
                else {
                    myList.getTail()->addSection(SectionCounter % T, c);
                    myList.getTail()->getSection(SectionCounter % T)->removeDuplicateAttributes();
                    myList.getTail()->getSection(SectionCounter % T)->removeDuplicateSelectors();
                    SectionCounter += 1;
                    

                }
                //myList.printList();
            }
            else if (c!=10 and c!=9){
                if ((char)(c == '?')) {
                    int countq = 0;
                    while (c == '?') {
                        countq++;
                        c = getchar();
                    }
                    if (countq == 4) secorcomm = 1;

                }
            }
        }
        else { //sekcja komend
            
            if (correctcommand == false) {
                while (c != '\n') c = getchar();
                correctcommand = true;
            }
            else c = getchar();
            if (c == '?') {
                //myList.printList();
                cout << "? == " << SectionCounter /* << " block: " << BlockCounter */ << endl;
                c = getchar();
            }
            else if (c == '*') {
                int countq = 0;
                while (c == '*') {
                    countq++;
                    c = getchar();
                }
                if (countq == 4) secorcomm = 0;
            }
            else if (c == '\n') continue;
            else {
                if (c == EOF) break;
                char pom[1000];
                int iter = 0;
                mystring komenda;
                cleartab(pom, 1000);
                while (c != ',') {
                    //jestem w tej petli 
                    if (c == EOF) break;
                    if (c != '\n') {
                        pom[iter] = c;
                        iter++;
                        c = getchar();
                    }
                    else {
                        c = getchar();
                    }
                }
                if (c == EOF) break;
                init_string(&komenda, pom);
                int i = is_numeric(&komenda);
                if (i!=-1) {
                    c = getchar();
                    if (c == 'A') { 
                        c = getchar();
                        if ((c = getchar()) == '?') {
                            //i,A,? 
                            correctcommand = true; 
                            if (i <= SectionCounter) {
                                int outcome = myList.FindandCountAttritbutes(i);
                                if (outcome != 0) {
                                    cout << i << ",A,? == " << outcome << endl;
                                }
                                else {
                                    cout << i << ",A,? == " << 0 << endl;
                                }
                            }
                            
                            
                        }
                        else {
                            //i,A,n
                            cleartab(pom,1000);
                            iter = 0;
                            while (c != '\n') {
                                pom[iter] = c;
                                iter++;
                                c = getchar();
                            }
                            const char* outcome = myList.FindandPrintAttribute(i, pom);
                            if (strcmp(outcome, "-") != 0) {
                                cout << i << ",A," << pom << " == " << outcome <<endl;
                            }
                           
                        }
                    }
                    else if (c == 'D') {
                        c = getchar();
                        if ((c = getchar()) == '*') {
                            //i,D,*
                          
                            bool ifdeleted = myList.removeSection(i);
                            myList.removeEmptyBlocks();
                            if (ifdeleted) {
                                cout << i << ",D,* == deleted\n";
                                SectionCounter--;
                            }

                        }
                        else {
                            //i,D,n;
                            cleartab(pom, 1000);
                            iter = 0;
                            while (c != '\n') {
                                pom[iter] = c;
                                iter++;
                                c = getchar();
                            }
                            int ifdeleted = myList.removeAfromSection(i,pom);
                            if (ifdeleted > 0) {
                                cout << i << ",D," << pom << " == deleted\n";
                                SectionCounter--;
                            }

                        }
 
                    }
                    else if (c == 'S') {
                        c = getchar();
                        if ((c = getchar()) == '?') {
                            //i,S,? 
                            int outcome = myList.FindandCountSelectors(is_numeric(&komenda));
                            if (outcome != 0) {
                                cout << i << ",S,? == " << outcome << endl;
                            }
                        }
                        else {
                            //i,S,j - i sekcja, j-ty selektor
                            char pomj[1000];
                            iter = 0;
                            mystring komendaj;
                            cleartab(pomj, 1000);
                            while (c != '\n') {
                                pomj[iter] = c;
                                iter++;
                                c = getchar();
                            }
                            init_string(&komendaj, pomj); 
                            int j = is_numeric(&komendaj);
                            const char* outcome = myList.FindandPrintSelector(i, j);
                            if (strcmp(outcome, "") != 0) {
                                cout << i << ",S," << j << " == " << outcome << endl;
                            }
                            
                        }   
                    }
                    else {
                        cleartab(pom, 1000);
                        iter = 0;
                        correctcommand = false;

                    }
                }
                else {
                    //wczytywanie n
                    c = getchar();
                    if (c == 'A') {
                        c = getchar();
                        if ((c = getchar()) == '?') {
                            //n,A,?
                            int outcome = myList.FindandCountCerAttributes(pom);

                            cout << pom << ",A,? == " << outcome << endl;
                        
                           
                        }
                    }
                    else if (c == 'S') {
                        c = getchar();
                        if ((c = getchar()) == '?') {
                            //n,S,?
                            int outcome = myList.FindandCountCerSelectors(pom);

                            cout << pom << ",S,? == " << outcome << endl;

                        }
                    }
                    else if (c == 'E') { 
                        //z,E,n
                        char pomj[1000];
                        mystring komendaj;
                        cleartab(pomj, 1000);
                        c = getchar();
                        c = getchar();
                        iter = 0;
                        while (c != '\n') {
                            pomj[iter] = c;
                            iter++;
                            c = getchar();
                        }
                        const char* outcome1 = myList.FindandPrintE(pom, pomj);
                        if (strcmp(outcome1, "0") != 0) {
                            cout << pom << ",E," << pomj << " == "<< outcome1  << endl;
                        } 

                    }
                    else {
                        cleartab(pom, 1000);
                        iter = 0;
                        correctcommand = false;
                        
                    }
                }

            }
        } 
    }
    
    
    
    
    
    /*while ((c = getchar()) != EOF && i < sizeof(css) - 1) {
        css[i++] = (char)c;
        //putchar(c);
    }
    css[i] = '\0';
    cout << css; 
    char* selector, * attribute;
    */

    /*while (operation != 5) {
        cout << "[1] Dodaj nowa sekcje \n[2] Wyswietl caly blok \n[3] Wyswietl ostatnia sekcje \n[4] Wyswietl cala lista\n[5] Zakoncz program  \n";
        cout << "ile sekcji: " << SectionCounter << " ile blokow: " << BlockCounter << endl;
        cin >> operation;
        if (operation == 1) {
            if ((SectionCounter % T < T and SectionCounter>T) or SectionCounter < T) {
                myList.getTail()->addSection(SectionCounter % T);
                SectionCounter += 1;
            }
            else {
                myList.addBlock();
                currentBlock = myList.getTail();
                BlockCounter += 1;
                myList.getTail()->addSection(SectionCounter % T);
                SectionCounter += 1;

            }
        }
        if (operation == 2) {
            myList.getTail()->printBlock();
        }
        if (operation == 3) {
            myList.getTail()->printLastSection(SectionCounter % T - 1);
        }
        if (operation == 4) {
            myList.printList();
        }
        if (operation == 6) {
            cout << "\nIlość sekcji css: " << SectionCounter << endl;
        }
        if (operation == 7) {
            cout << myList.FindandCountAttritbutes(1) << endl;
        }
        if (operation == 9) {
            cout << myList.FindandPrintSelector(1, 1) << endl;
        }
    }*/


	return 0;
}


