#include <iostream>

using namespace std;


#define OPEN_SELECTOR			'{'
#define CLOSE_SELECTOR			'}'
#define NEXT_ROW				';'
#define SEPARATOR_SELECTOR		','
#define VALUE_IN				':'
#define SPACE					' '

#define SAVING					1
#define MODIFYING				2

#define MAX_NAME_SIZE			15

#define BUFFER_SIZE				20

class text {
public:
	int charN;
	char* text;
};

class attribute {
public:

	text Name;
	text Value;

	attribute* previousNode;
	attribute* nextNode;
};

class selector {
public:
	text Name;

	attribute* Attributes;

	selector* previousNode;
	selector* nextNode;
};

text getText (text name) {

	char tempChar = 0;

	do {
		


	} while (tempChar != OPEN_SELECTOR);

	return name;
}

text getData() {
	char tempChar = 1;

	char Buffer[BUFFER_SIZE];

	text BuffData;

	text Data;

	Data.charN = 0;

	Data.text = new char[0];
	
	int i = 0;

	while (tempChar != NULL) {
		for (i = 0; i < BUFFER_SIZE; i++) {
			cin >> tempChar;

			if (tempChar == NULL) {
				BuffData = Data;
				Data.charN += i;
				Data.text = new char[Data.charN];

				for (int j = 0; j < BuffData.charN; j++) {
					Data.text[j] = BuffData.text[j];
				}
				for (int j = 0; j < i; j++) {
					Data.text[BuffData.charN + j] = Buffer[j];
				}
				return Data;
			}

			if (tempChar != ' ') {
				Buffer[i] = tempChar;
			}
		}

		BuffData = Data;
		Data.charN += i;
		Data.text = new char[Data.charN];

		for (int j = 0; j < BuffData.charN; j++) {
			Data.text[j] = BuffData.text[j];
		}
		for (int j = 0; j < BUFFER_SIZE; j++) {
			Data.text[BuffData.charN + j] = Buffer[j];
		}
	}

	return Data;
}

int main() {

	int mode;

	text Data;
	
	Data = getData();

	for (int i = 0; i < Data.charN;i++) {
		cout << Data.text[i];
	}

	return 0;
}