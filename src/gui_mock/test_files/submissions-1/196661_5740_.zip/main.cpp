#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LINE_LEN 1024
#define MAX_ATTRS 16
#define MAX_BLOCKS 8

struct css_attribute {
  char *name;
  char *value;
};

struct css_block {
  char **selectors;
  int num_selectors;
  struct css_attribute *attrs;
  int num_attrs;
};

struct css_section {
  struct css_block *blocks;
  int num_blocks;
};

void parse_css(char *css_text, struct css_section *section) {
  char *line, *token, *name, *value;
  int i, j, k, len;
  struct css_block *block;

  section->num_blocks = 0;
  line = strtok(css_text, "\n");
  while (line != NULL) {
    len = strlen(line);
    if (len > 0 && line[len - 1] == '\r') {
      line[len - 1] = '\0'; // remove trailing carriage return
    }
    if (line[0] == '#' || line[0] == '.') { // selector line
      block = &(section->blocks[section->num_blocks]);
      block->num_selectors = 0;
      block->selectors = (char **) malloc(MAX_ATTRS * sizeof(char *));
      token = strtok(line, ",");
      while (token != NULL) {
        block->selectors[block->num_selectors] = strdup(token);
        block->num_selectors++;
        token = strtok(NULL, ",");
      }
    } else { // attribute line
      name = strtok(line, ":");
      value = strtok(NULL, ";");
      // TODO: add attribute to current block
    }
    line = strtok(NULL, "\n");
  }
}

int main(int argc, char *argv[]) {
  char *css_text = "#breadcrumb\n{\nwidth: 80%;\nfont-size: 9pt;\n}\n\
h1, body {\nmin-width: 780px;\nmargin: 0;\npadding: 0;\nfont-family: \"Trebuchet MS\", \"Lucida Grande\", Arial;\nfont-size: 85%;\ncolor: #666666;\n}\n\
h1, h2, h3, h4, h5, h6 {color: #0066CB;}";
  struct css_section section;
  section.blocks = (struct css_block *) malloc(MAX_BLOCKS * sizeof(struct css_block));
  parse_css(css_text, &section);
  for (int i = 0; i < section.num_blocks; i++) {
    printf("Block %d:\n", i);
    for (int j = 0; j < section.blocks[i].num_selectors; j++) {
      printf("Selector %d: %s\n", j, section.blocks[i].selectors[j]);
    }
    for (int k = 0; k < section.blocks[i].num_attrs; k++) {
      printf("Attribute %s: %s\n", section.blocks[i].attrs[k].name, section.blocks[i].attrs[k].value);
    }
  }
  return 0;
}
