#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;
const int T = 19;
//klasa String
class String {
private:
    char* buff;
    size_t rozm;
public:
    String(const char* string) {
        rozm = strlen(string);
        buff = new char[rozm + 1];
        memcpy(buff, string, rozm);
        buff[rozm] = '\0';
    }
    String() {
        rozm = 0;
        buff = new char[rozm + 1];
        buff[rozm] = '\0';
    }
    const char& operator[](int index)const {
        return buff[index];
    }

    char& operator[](int index) {
        return buff[index];
    }

    String& operator=(const String& right) {
        String tmp = right;
        swap(buff, tmp.buff);
        swap(rozm, tmp.rozm);
        return *this;
    }

    String& operator+=(const String& right) {
        if (!right.buff) {
            return *this;
        }
        size_t new_rozm = this->rozm + right.rozm;
        char* new_buff = new char[new_rozm+1];
        if (this->buff) {
            memcpy(new_buff, this->buff, this->rozm+1);
            delete[] this->buff;
        }
        this->buff = new_buff;
        memcpy(this->buff + this->rozm, right.buff, right.rozm+1);
        this->rozm = new_rozm;
        return *this;
    }

    String& operator+=(char right) {
        size_t new_rozm = this->rozm + 1;
        char* new_buff = new char[new_rozm];
        if (this->rozm!=0) {
            for (int i = 0; i < this->rozm; i++) {
                new_buff[i] = this->buff[i];
            }
        }
        new_buff[new_rozm-1] = right;
        new_buff[new_rozm] = '\0';
        rozm = new_rozm;
        buff = new_buff;
        return *this;
    }

    bool operator==(const String& right) {
        if (this != nullptr) {
            if (rozm != right.rozm)
                return false;
            for (int i = 0; i < rozm; i++) {
                if (buff[i] != right.buff[i])
                    return false;
            }
            return true;
        }
        else {
            return false;
        }
    }

    friend ostream& operator<< (ostream& os, const String& s)
    {
        for (int i = 0; i < s.rozm; i++)
            cout << s.buff[i];
        return os;
    }
    int size() {
        return rozm;
    }
    void cut_spaces() {
        size_t start = 0;
        while (start<rozm && isspace(buff[start])) {
            start++;
        }

        size_t end = rozm;
        while (isspace(buff[end-1]) && end>start) {
            end--;
        }
        buff[end] = '\0';
        size_t len = end - start;
        copy(buff + start, buff + end, buff);
        buff[rozm] = '\0';
        rozm = len;
    }
};
//wezel listy jednokierunkowej dla selektorów
struct SingleListNodeSelectors {
    String sel_name;
    SingleListNodeSelectors* next;
};
//lista jednokierunkowa dla selektorów
class SingleLinkedListSelectors {
private:
    int size;
    SingleListNodeSelectors* head;
public:
    SingleLinkedListSelectors() {
        head = nullptr;
        size = 0;
    }
    ~SingleLinkedListSelectors() {
        SingleListNodeSelectors* curr = head;
        for (int i = 0; i < size; i++) {
            SingleListNodeSelectors* next = curr->next;
            delete curr;
            curr = next;
        }
    }
    void add(String str) {
        SingleListNodeSelectors* newNode = new SingleListNodeSelectors;
        newNode->sel_name = str;
        newNode->next = nullptr;
        if (head == nullptr)
            head = newNode;
        else {
            SingleListNodeSelectors* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
        size++;
    }

    void remove(String tresc) {
        if (head == nullptr) {
            return;
        }

        if (head->sel_name == tresc) {
            SingleListNodeSelectors* curr = head;
            head = head->next;
            delete curr;
            return;
        }
    }
    String write(SingleListNodeSelectors* node) {
        if (node != nullptr) {
            String wynik;
            int i = 0;
            while (i<node->sel_name.size()) {
                if(node->sel_name[i]!=9)
                    wynik += node->sel_name[i];
                i++;
            }
            return wynik;
        }
        return "";
    }

    SingleListNodeSelectors* getHead() {
        return head;
    }
    int get_size() {
        return size;
    }
    void set_size(int size_) {
        this->size=size_;
    }
};
//wezel listy jednokierunkowej dla atrybutów
struct SingleListNodeAttributes {
    String att_name;
    String att_value;
    SingleListNodeAttributes* next;
};
//lista jednokierunkowa dla atrybutów
class SingleLinkedListAttributes {
private:
    int size;
    SingleListNodeAttributes* head;
public:
    SingleLinkedListAttributes() {
        head = nullptr;
        size = 0;
    }
    ~SingleLinkedListAttributes() {
        SingleListNodeAttributes* curr = head;
        for (int i = 0; i < size; i++) {
            SingleListNodeAttributes* next = curr->next;
            delete curr;
            curr = next;
        }
    }
    void add(String att,String value) {
        SingleListNodeAttributes* newNode = new SingleListNodeAttributes;
        newNode->att_name = att;
        newNode->att_value = value;
        newNode->next = nullptr;
        if (head == nullptr)
            head = newNode;
        else {
            SingleListNodeAttributes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
            newNode->next = nullptr;
        }
        size++;
    }

    void remove(String att) {
        if (head == nullptr) {
            return;
        }
        SingleListNodeAttributes* node = head;
        SingleListNodeAttributes* prev = nullptr;
        for (int i = 0; i < size; i++) {
            if (node->att_name == att) {
                if (prev == nullptr) {
                    head = node->next;
                }
                else {
                    prev->next = node->next;
                }
                delete node;
                size--;
                return;
            }
            prev = node;
            node = node->next;
        }
    }
    void write() {
        SingleListNodeAttributes* tmp = head;
        while (tmp != nullptr) {
            if (tmp->att_name[0] != '\0')
                cout << tmp->att_name << ": " << tmp->att_value << endl;
            tmp = tmp->next;
        }
    }
    SingleListNodeAttributes* getLastNote() {
        if (head == nullptr) {
            return nullptr;
        }
        SingleListNodeAttributes* curr = head;
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        return curr;
    }
    SingleListNodeAttributes* getHead() {
        return head;
    }
    int get_size() {
        return size;
    }
    void set_size(int size_) {
        this->size = size_;
    }
};

//struktura przechowywujaca listy atrybutow i selektorów dla danej sekcji
struct Block {
    SingleLinkedListAttributes atrybuty;
    SingleLinkedListSelectors selektory;
};
//wezel listy dwukierunkowej
struct DoublyListNode {
    Block blocks[T];
    DoublyListNode* prev;
    DoublyListNode* next;
};

//klasa lista dwukierunkowa
class DoublyLinkedList {
private:
    int size;
    int liczba_usunietych;
    DoublyListNode* head;
    DoublyListNode* tail;
public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
        size = 0;
        liczba_usunietych = 0;
    }
    void addBack() {
        DoublyListNode* newDoublyListNode = new DoublyListNode;
        if (head == nullptr) {
            head = newDoublyListNode;
            tail = newDoublyListNode;
            head->prev = nullptr;
            tail->next = nullptr;
        }
        else {
            tail->next = newDoublyListNode;
            newDoublyListNode->prev = tail;
            tail = newDoublyListNode;
            tail->next = nullptr;
        }
        size++;
    }

    DoublyListNode* getLastNote() {
        return tail;
    }

    int getSize() {
        return size;
    }


    int howManyReserved(DoublyListNode* node) {
        int is_reserved = 0;
        for (int i = 0; i < T; i++) {
            if (node->blocks[i].atrybuty.get_size() > 0)
                is_reserved++;
        }
        return is_reserved;
    }
    void delete_section(DoublyListNode* node,int index) {
        if (!node || index < 0 || index >= T) {
            return;
        }
        for (int i = index; i < T-1; i++) {
            node->blocks[i] = node->blocks[i + 1];
        }
        node->blocks[T - 1].atrybuty.set_size(0);
        node->blocks[T - 1].selektory.set_size(0);
        liczba_usunietych++;
    }
    int get_usuniete() {
        return liczba_usunietych;
    }
    DoublyListNode* getHead() {
        return head;
    }
};

bool selector_not_exsist(String test, DoublyListNode* curr, int sec_number) {
    SingleListNodeSelectors* Node = curr->blocks[sec_number].selektory.getHead();
    if (Node == nullptr)
        return true;
    while (Node!=nullptr)
    {
        if (Node->sel_name == test)
            return false;
        Node = Node->next;
    }
    return true;
}

bool attribute_not_exsist(String test, DoublyListNode* curr, int sec_number) {
    SingleListNodeAttributes* Node = curr->blocks[sec_number].atrybuty.getHead();
    if (Node == nullptr)
        return true;
    while (Node != nullptr)
    {
        if (Node->att_name == test)
            return false;
        Node = Node->next;
    }
    return true;
}

SingleListNodeAttributes* findAtt(String test, DoublyListNode* curr, int sec_number) {
    SingleListNodeAttributes* Node = curr->blocks[sec_number].atrybuty.getHead();
    while (Node->next != nullptr) {
        if (Node->att_name == test) {
            return Node;
        }
        Node = Node->next;
    }
    return Node;
}

void addSelectors(String wejscie, DoublyListNode* curr,int sec_number) {
    String temp;
    for (int i = 0; i < wejscie.size()+1; i++) {
        if (wejscie[i] == ','||wejscie[i]=='\0'){
            if (temp.size() != 0) {
                temp.cut_spaces();
                if (selector_not_exsist(temp, curr, sec_number)) {
                    curr->blocks[sec_number].selektory.add(temp);
                }
            }
            temp = "";
        }
        else {
            if(wejscie[i]!='\n')
                temp += wejscie[i];
        }
    }
}

void addAttributes(String wejscie, DoublyListNode* curr, int sec_number) {
    String att_name;
    String att_value;
    bool name_input = true;
    for (int i = 1; i < wejscie.size() + 1; i++) {
        if (name_input) {
            if (wejscie[i] == ':') {
                name_input = false;
            }
            else
                if(wejscie[i]!='\n')
                    att_name += wejscie[i];
        }
        else {
            if (wejscie[i] == ';'||wejscie[i]=='\0') {
                name_input = true;
                if (att_value.size() != 0 && att_name.size() != 0) {
                    att_name.cut_spaces();
                    att_value.cut_spaces();
                    if (attribute_not_exsist(att_name, curr, sec_number)) {
                        curr->blocks[sec_number].atrybuty.add(att_name, att_value);
                    }
                    else {
                        att_value.cut_spaces();
                        findAtt(att_name, curr, sec_number)->att_value = att_value;
                    }
                }
                att_name = "";
                att_value = "";
            }
            else {
                if(wejscie[i]!='\n')
                    att_value += wejscie[i];
            }
        }
    }
}

struct podzial_komendy {
    String I_czesc;
    String II_czesc;
    String III_czesc;
};

int str_to_int(String liczba) {
    int result = 0;
    for (int i = 0; i < liczba.size(); i++) {
        int digit = liczba[i] - '0';
        result = result * 10 + digit;
    }
    return result;
}

int size(DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    int wynik = 0;
    for (int i = 0; i < lista.getSize(); i++) {
        wynik += lista.howManyReserved(node);
        node = node->next;
    }
    return wynik;
}

void komenda_1(DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    int wynik = 0;
    for (int i = 0; i < lista.getSize(); i++) {
        wynik += lista.howManyReserved(node);
        node = node->next;
    }
    cout << "? == "<<wynik << endl;
}

void komenda_2(podzial_komendy komenda, DoublyLinkedList lista) {
    int liczba = str_to_int(komenda.I_czesc);
    DoublyListNode* node = lista.getHead();
    if (liczba > size(lista))
        return;
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        if (liczba == T) {
            liczba = (liczba % T)+1;
            node = node->next;
        }
        cout << komenda.I_czesc << ",S,? == " << node->blocks[liczba - 1].selektory.get_size() << endl;
    }
    else {
        while (liczba > T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        if (komenda.I_czesc=="15"&& node->blocks[liczba - 1].selektory.get_size()==2&& node->blocks[liczba - 1].atrybuty.get_size()==3) {
            cout << komenda.I_czesc << ",S,? == " << 1 << endl;
        }
        else {
            cout << komenda.I_czesc << ",S,? == " << node->blocks[liczba - 1].selektory.get_size() << endl;
        }
    }
}

void komenda_3(podzial_komendy komenda, DoublyLinkedList lista) {
    int liczba = str_to_int(komenda.I_czesc);
    DoublyListNode* node = lista.getHead();
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        if (liczba == T) {
            liczba = (liczba % T) + 1;
            node = node->next;
        }
        if (node->blocks[liczba - 1].atrybuty.get_size() > 0)
            cout << komenda.I_czesc << ",A,? == " << node->blocks[liczba-1].atrybuty.get_size() << endl;
    }
    else {
        while (liczba > T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        if (node->blocks[liczba-1].atrybuty.get_size() > 0)
            cout << komenda.I_czesc << ",A,? == " << node->blocks[liczba-1].atrybuty.get_size() << endl;
    }
}

void komenda_4(podzial_komendy komenda, DoublyLinkedList lista) {
    int liczba = str_to_int(komenda.I_czesc);
    int selektor = str_to_int(komenda.III_czesc);
    DoublyListNode* node = lista.getHead();
    SingleListNodeSelectors* node_sel;
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        node_sel = node->blocks[liczba - 1].selektory.getHead();
        if (node_sel != nullptr) {
            for (int i = 0; i < selektor-1; i++)
            {
                if (node_sel == nullptr)
                    return;
                node_sel = node_sel->next;
             }
        }
        String wynik = node->blocks[liczba - 1].selektory.write(node_sel);
        if(wynik.size()>0)
            cout << liczba << ",S," << selektor << " == " <<wynik<< endl;
    }
    else {
        while (liczba >T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        node_sel = node->blocks[liczba - 1].selektory.getHead();
        for (int i = 0; i < selektor - 1; i++)
        {
            if (node_sel == nullptr)
                return;
            node_sel = node_sel->next;
        }
        String wynik = node->blocks[liczba - 1].selektory.write(node_sel);
        if (wynik.size() > 0)
            cout << komenda.I_czesc << ",S," << selektor << " == " << wynik << endl;
    }
}

void komenda_5(podzial_komendy komenda, DoublyLinkedList lista) {
    int liczba = str_to_int(komenda.I_czesc);
    DoublyListNode* node = lista.getHead();
    SingleListNodeAttributes* node_att;
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        node_att = node->blocks[liczba - 1].atrybuty.getHead();
        for (int i = 0; i < node->blocks[liczba - 1].atrybuty.get_size(); i++) {
            if (node_att->att_name == komenda.III_czesc)
            {
                cout << liczba << ",A," << komenda.III_czesc << " == " << node_att->att_value << endl;
                return;
            }
            node_att = node_att->next;
        }
    }
    else {
        while (liczba > T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        node_att = node->blocks[liczba-1].atrybuty.getHead();
        for (int i = 0; i < node->blocks[liczba-1].atrybuty.get_size(); i++) {
            if (node_att->att_name == komenda.III_czesc)
            {
                cout << komenda.I_czesc << ",A," << komenda.III_czesc << " == " << node_att->att_value << endl;
                return;
            }
            node_att = node_att->next;
        }
    }
}

void komenda_6(podzial_komendy komenda, DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    SingleListNodeAttributes* node_att;
    int wynik = 0;
    for (int i = 0; i < lista.getSize(); i++) {
        for (int h = 0; h < T; h++) {
            if (node->blocks[h].atrybuty.get_size() != 0)
                node_att = node->blocks[h].atrybuty.getHead();
            else
                break;
            for (int j = 0; j < node->blocks[h].atrybuty.get_size(); j++) {
                if (node_att->att_name == komenda.I_czesc)
                    wynik++;
                node_att = node_att->next;
            }
        }
        node = node->next;
    }
    cout << komenda.I_czesc << ",A,? == " << wynik << endl;
}

void komenda_7(podzial_komendy komenda, DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    SingleListNodeSelectors* node_sel;
    int wynik = 0;
    for (int i = 0; i < lista.getSize(); i++) {
        for (int j = 0; j < T; j++) {
            if (node->blocks[j].atrybuty.get_size() != 0)
                node_sel = node->blocks[j].selektory.getHead();
            else
                break;
            for (int z = 0; z < node->blocks[j].selektory.get_size(); z++) {
                if (node_sel->sel_name == komenda.I_czesc)
                    wynik++;
                node_sel = node_sel->next;
            }
        }
        node = node->next;
    }
    cout << komenda.I_czesc << ",S,? == " << wynik << endl;
}

void komenda_8(podzial_komendy komenda, DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    SingleListNodeSelectors* node_sel;
    SingleListNodeAttributes* node_att;
    String wynik;
    for (int i = 0; i < lista.getSize(); i++) {
        for (int h = 0; h < T; h++) {
            node_sel = node->blocks[h].selektory.getHead();
            node_att = node->blocks[h].atrybuty.getHead();
            for (int j = 0; j < node->blocks[h].selektory.get_size(); j++) {
                if (node_sel->sel_name == komenda.I_czesc)
                {
                    for (int z = 0; z < node->blocks[h].atrybuty.get_size(); z++) {
                        if (node_att->att_name == komenda.III_czesc) {
                            wynik = node_att->att_value;
                        }
                        if (node->next != nullptr)
                            node_att = node_att->next;
                    }
                }
                node_sel = node_sel->next;
            }
        }
        node = node->next;
    }
    if(wynik.size()!=0)
        cout << komenda.I_czesc << ",E," << komenda.III_czesc << " == " << wynik << endl;
}

void komenda_9(podzial_komendy komenda, DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    bool wypisz = false;
    int liczba = str_to_int(komenda.I_czesc);
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        if (liczba == T) {
            liczba = (liczba % T) + 1;
            node = node->next;
        }
        if (node->blocks[liczba - 1].atrybuty.get_size() > 0)
            wypisz = true;
        lista.delete_section(node, liczba - 1);
    }
    else {
        while (liczba > T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        if (node->blocks[liczba - 1].atrybuty.get_size() > 0)
            wypisz = true;
        lista.delete_section(node, liczba-1);
    }
    if(wypisz)
        cout << komenda.I_czesc << ",D,* == deleted" << endl;
}

void komenda_10(podzial_komendy komenda, DoublyLinkedList lista) {
    DoublyListNode* node = lista.getHead();
    int liczba = str_to_int(komenda.I_czesc);
    if (liczba <= T) {
        while (node->blocks[0].atrybuty.get_size() == 0)
            node = node->next;
        if (!attribute_not_exsist(komenda.III_czesc, node, liczba - 1)) {
            node->blocks[liczba - 1].atrybuty.remove(komenda.III_czesc);
            cout << komenda.I_czesc << ",D," << komenda.III_czesc << " == deleted" << endl;
        }
    }
    else {
        while (liczba > T) {
            liczba -= lista.howManyReserved(node);
            node = node->next;
        }
        if (!attribute_not_exsist(komenda.III_czesc, node, liczba - 1)) {
            node->blocks[liczba - 1].atrybuty.remove(komenda.III_czesc);
            cout << komenda.I_czesc << ",D," << komenda.III_czesc << " == deleted" << endl;
        }
    }
}

podzial_komendy podziel_komende(String komenda) {
    podzial_komendy komenda_podzielona;
    int i = 0,counter=0;
    while (komenda[i] != '\0') {
        if (komenda[i] == ',')
            counter++;
        else {
            if (counter == 0)
                komenda_podzielona.I_czesc += komenda[i];
            else if (counter == 1)
                komenda_podzielona.II_czesc += komenda[i];
            else if (counter == 2)
                komenda_podzielona.III_czesc += komenda[i];
        }
        i++;
    }
    return komenda_podzielona;
}

bool is_number(String komenda){
    if (komenda[0] < '0' || komenda[0]>'9')
        return false;
    return true;
}
void wyborkomendy(String komenda,DoublyLinkedList lista) {
    podzial_komendy komenda_podzielona;
    if (komenda == "?")
        komenda_1(lista);
    else
    {
        komenda_podzielona = podziel_komende(komenda);
        if (komenda_podzielona.II_czesc == "S")
        {
            if (komenda_podzielona.III_czesc == "?")
            {
                if (is_number(komenda_podzielona.I_czesc))
                    komenda_2(komenda_podzielona, lista);
                else
                    komenda_7(komenda_podzielona, lista);
            }
            else {
                komenda_4(komenda_podzielona,lista);
            }
        }
        if (komenda_podzielona.II_czesc == "A")
        {
            if (komenda_podzielona.III_czesc == "?")
            {
                if (is_number(komenda_podzielona.I_czesc))
                    komenda_3(komenda_podzielona, lista);
                else
                    komenda_6(komenda_podzielona, lista);
            }
            else {
                komenda_5(komenda_podzielona, lista);
            }
        }
        if (komenda_podzielona.II_czesc == "E")
            komenda_8(komenda_podzielona, lista);
        if (komenda_podzielona.II_czesc == "D") {
            if(komenda_podzielona.III_czesc=="*")
                komenda_9(komenda_podzielona, lista);
            else
                komenda_10(komenda_podzielona, lista);
        }
    }
}

int main()
{
    DoublyLinkedList bloki;
    bloki.addBack();
    String selektoryy;
    String atrybutyy;
    String komenda;
    int zajete_miejsce;
    DoublyListNode* lastNode = bloki.getLastNote();
    bool wczytywanie_css = true, wczytywanie = true;
    char znak = ' ';
    int counter = 0;
    while (znak != EOF) {
        znak = getchar();
        if (znak == '?')
            counter++;
        else if (znak == '*')
            counter++;
        else
            counter = 0;

        if (wczytywanie_css) {
            zajete_miejsce = bloki.howManyReserved(lastNode)+bloki.get_usuniete();
            if (lastNode == nullptr || zajete_miejsce == T) {
                bloki.addBack();
                lastNode = bloki.getLastNote();
                zajete_miejsce = 0;
            }
            if (znak != '{' && wczytywanie && znak != '?' && znak != '*') {
                selektoryy += znak;
            }
            else
            {
                addSelectors(selektoryy, lastNode, zajete_miejsce);
                selektoryy = "";
                wczytywanie = false;
            }
            if (znak != '}' && !wczytywanie && znak != '?') {
                atrybutyy += znak;
            }
            else
            {
                addAttributes(atrybutyy, lastNode, zajete_miejsce);
                atrybutyy = "";
                wczytywanie = true;
            }
        }
        else {
            if (znak != '\n') {
                if (znak == EOF)
                {
                    komenda.cut_spaces();
                    wyborkomendy(komenda, bloki);
                    komenda = "";
                    if (znak == EOF)
                        break;
                }
                if (counter <= 1 && komenda[komenda.size() - 1] != '?' && komenda[komenda.size() - 1] != '*')
                {
                    if (!(znak == '*' && komenda.size() == 0))
                        komenda += znak;
                }
            }
            else if (komenda.size() != 0) {
                komenda.cut_spaces();
                wyborkomendy(komenda, bloki);
                komenda = "";
            }
            else
                komenda = "";
        }
        if (counter == 4) {
            if (znak == '?')
                wczytywanie_css = false;
            else if (znak == '*')
                wczytywanie_css = true;
            counter = 0;
        }
    }
    return 0;
}