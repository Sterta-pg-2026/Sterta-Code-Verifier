#include <iostream>

#define T 17
#define START_INPUT_SIZE 500
#define PRIME_HASH_NUMBER_1 37
#define PRIME_HASH_NUMBER_2 7
#define PRIME_HASH_NUMBER_3 19

using namespace std;

struct Attribute
{
	int name_hash = 0;
	char* name = nullptr, * value = nullptr;
};

struct Selector
{
	int hash = 0;
	char* name = nullptr;
};

struct SelectorList
{
	SelectorList* next = nullptr;
	Selector* selector = nullptr;
};

struct AttributeList
{
	AttributeList* next = nullptr;
	Attribute* attribute = nullptr;
};

struct Block
{
	bool initialized = 0;
	int number = 0, selectors_amount = 0, attributes_amount = 0;
	SelectorList* selectors = nullptr;
	AttributeList* attributes = nullptr;
};

struct BlockList
{
	int places = T;
	BlockList* next = nullptr, * previous = nullptr;
	Block block[T];
};

struct BlocksInfo
{
	char* input;
	BlockList* blocklist;
	int blocks_amount = 0, input_size = 0;
};

BlocksInfo* SetBlocksInfo(char* input, int input_size)
{
	BlocksInfo* info = new BlocksInfo;
	info->input = input;
	info->blocklist = new BlockList;
	info->blocks_amount = 0;
	info->input_size = input_size;
	return info;
}

Selector* CreateSelector(char* name, int hash)
{
	Selector* selector = new Selector;
	selector->name = name;
	selector->hash = hash;
	return selector;
}
Attribute* CreateAttribute(char* name, char* value, int hash)
{
	Attribute* attribute = new Attribute;
	attribute->name = name;
	attribute->value = value;
	attribute->name_hash = hash;
	return attribute;
}
Block CreateBlock(AttributeList* attributes, SelectorList* selectors, int number)
{
	Block block;
	block.attributes = attributes;
	block.selectors = selectors;
	block.number = number;
	block.initialized = true;
	return block;
}

SelectorList* CreateSelectorNode(Selector* selector)
{
	SelectorList* list = new SelectorList;
	list->selector = selector;
	return list;
}
AttributeList* CreateAttributeNode(Attribute* attribute)
{
	AttributeList* list = new AttributeList;
	list->attribute = attribute;
	return list;
}

BlockList* FindLastBlockNode(BlockList* list)
{
	while (list->next != nullptr)
	{
		list = list->next;
	}
	return list;
}

BlockList* CreateBlockNode(BlockList* first, BlockList* last)
{
	try {
		BlockList* newlist = new BlockList;
		last->next = newlist;
		newlist->previous = last;
		first->previous = newlist;
		//last = FindLastBlockNode(list);
		//list->next = newlist;
		//newlist->previous = list;
		return newlist;
	}
	catch (std::bad_alloc& ba)
	{
		cout << "(" << ((last->block) + 0)->number << ")bad_alloc caught: " << ba.what() << '\n';
		exit(0);
	}
}

void InitialiseBlock(Block* block, BlockList* cur_list, int *block_number)
{
	cur_list->places--;
	block->initialized = true;
	block->number = ++(*block_number);
	if (*block_number == 9)
	{
		return;
	}
}

void AddSelectorNode(SelectorList* last, SelectorList* next)
{
	if (last != nullptr)
	{
		last->next = next;
	}
	else
	{
		last = next;
	}
}
void AddAttributeNode(AttributeList* last, AttributeList* next)
{
	if (last != nullptr)
	{
		last->next = next;
	}
	else
	{
		last = next;
	}
}
void AddBlockNode(BlockList* list, BlockList* next)
{
	list->next = next;
	next->previous = list;
}

SelectorList* FindLastSelectorNode(SelectorList* list)
{
	SelectorList* last = list;
	while (last->next != nullptr)
	{
		last = last->next;
	}
	return last;
}
AttributeList* FindLastAttributeNode(AttributeList* list)
{
	AttributeList* last = list;
	while (last->next != nullptr)
	{
		last = last->next;
	}
	return last;
}

void AddSelectorToBlock(Block* block, Selector* selector)
{
	if (block->selectors != nullptr)
	{
		SelectorList* new_node = CreateSelectorNode(selector), * last_node = FindLastSelectorNode(block->selectors);
		AddSelectorNode(last_node, new_node);
	}
	else
	{
		block->selectors = CreateSelectorNode(selector);
	}
	block->selectors_amount++;
}
void AddAttributeToBlock(Block* block, Attribute* attribute)
{
	if (block->attributes != nullptr)
	{
		AttributeList* new_node = CreateAttributeNode(attribute), * last_node = FindLastAttributeNode(block->attributes);
		AddAttributeNode(last_node, new_node);
	}
	else
	{
		block->attributes = CreateAttributeNode(attribute);
	}
	block->attributes_amount++;

}

BlockList* FindEmptyBlockNode(BlockList* list)
{
	/*while (list->places <= 0)
	{
		if (list->next == nullptr)
		{
			return CreateBlockNode(list);
		}
		list = list->next;
	}
	return list;
	*/
	/*if (!list->places && list->next == nullptr)
	{
		return CreateBlockNode(list, list);
	}
	else if (!list->places && list->next != nullptr)
	{
		return CreateBlockNode(list, list->previous);
	}
	else
	{
		return list;
	}
	*/
	if (list->places)
	{
		return list;
	}
	else
	{
		/*BlockList* buf = list->previous;
		while (buf != list && buf != nullptr)
		{
			if (buf->places)
			{
				return buf;
			}
			buf = buf->previous;
		}
		*/
		if (list->previous != nullptr && list->previous->places)
		{
			return list->previous;
		}
		else if (list->previous == nullptr)
		{
			return CreateBlockNode(list, list);
		}
		else
		{
			return CreateBlockNode(list, list->previous);
		}
	}
}
Block* FindBlock(BlockList* list)
{
	for (int i = 0; i < T; i++)
	{
		if (!((list->block)+i)->initialized)
		{
			return (list->block)+ i;
		}
	}
	return nullptr;
}
void FindNodeAndBlock(BlockList** cur_list, Block** cur_block, BlockList* list)
{
	if (!(*cur_list)->places)
	{
		*cur_list = FindEmptyBlockNode(list);
	}	
	*cur_block = FindBlock(*cur_list);
}

Block* GetBlockByNumber(int number, BlocksInfo* info)
{
	if (number <= info->blocks_amount && info->blocks_amount != 0)
	{
		Block* block;
		BlockList* list = info->blocklist;
		do
		{
			for (int i = 0; i < T; i++)
			{
				if (((list->block) + i)->number == number)
				{
					return (list->block) + i;
				}
			}
			list = list->next;
		} while (list != nullptr);
	}
	return nullptr;
}

char* FindAttributeValue(int attr_hash, AttributeList* list)
{
	do
	{
		if (list->attribute->name_hash == attr_hash)
		{
			return list->attribute->value;
		}
		list = list->next;
	} while (list != nullptr);
	return nullptr;
}

int FindAttributeAmountInList(int attr_hash, AttributeList* list)
{
	int rez = 0;
	while (list != nullptr)
	{
		if (list->attribute->name_hash == attr_hash)
		{
			rez++;
		}
		list = list->next;
	}
	return rez;
}

int FindAttributeAmount(int attr_hash, BlockList* list)
{
	int rez = 0;
	while (list != nullptr)
	{
		for (int i = 0; i < T; i++)
		{
			if (((list->block) + i)->initialized)
			{
				rez += FindAttributeAmountInList(attr_hash, ((list->block) + i)->attributes);
			}
		}
		list = list->next;
	}
	return rez;
}

Attribute* FindAttributeInList(int attr_hash, AttributeList* list)
{
	do
	{
		if (list->attribute->name_hash == attr_hash)
		{
			return list->attribute;
		}
		list = list->next;
	} while (list != nullptr);
	return nullptr;
}

int GetCharHash(char* arr, int size)
{
	int hash = 0;
	for (int i = 0; i < size; i++)
	{
		hash += PRIME_HASH_NUMBER_1 * (arr[i] + PRIME_HASH_NUMBER_2 * i) * ((i % PRIME_HASH_NUMBER_3) + 1);
	}
	return hash;
}

char* ResizeInputArray(char* arr, int* size)
{
	char* buf = new char[*size], *buf2;
	for (int i = 0; i < *size; i++)
	{
		buf[i] = arr[i];
	}
	buf2 = new char[*size * 2];
	for (int i = 0; i < *size; i++)
	{
		buf2[i] = buf[i];
	}
	*size *= 2;
	delete[] buf;
	delete[] arr;
	return buf2;
}

void IncreaseQuestionCounter(int* questions, bool* mode, char symbol)
{
	if (symbol == '?' && !(*mode))
	{
		(*questions)++;
		if (*questions == 4)
		{
			*questions = 0;
			*mode = true;
		}
	}
	else
	{
		*questions = 0;
	}
}

void IncreaseStarCounter(int* stars, bool* mode, char symbol)
{
	if (symbol == '*' && *mode)
	{
		(*stars)++;
		if (*stars == 4)
		{
			*stars = 0;
			*mode = false;
		}
	}
	else
	{
		*stars = 0;
	}
}

int CharToInt(char* arr, int size)
{
	int power = 1, rez = 0;
	for (int i = size - 1; i >= 0; i--)
	{
		rez += (arr[i] - 48) * power;
		power *= 10;
	}
	return rez;
}

char* GetInput(int* symbols)
{
	bool mode = false; // false - css, true - commands
	int array_size = START_INPUT_SIZE, questions = 0, stars = 0;
	char symbol, * input_array = new char[array_size];
	while ((symbol = getchar()) != EOF)
	{
		if (symbol < ' ' && !mode)
		{
			continue;
		}
		else
		{
			if (symbol == '\\')
			{
				break;
			}
			input_array[(*symbols)++] = symbol;
			IncreaseQuestionCounter(&questions, &mode, symbol);
			IncreaseStarCounter(&stars, &mode, symbol);
			if (*symbols == array_size - 1)
			{
				input_array = ResizeInputArray(input_array, &array_size);
			}
		}
	}
	return input_array;
}

char* CreateString(char* input, int start, int end)
{
	try
	{
		char* arr = new char[end - start + 2];
		for (int i = start; i <= end; i++)
		{
			arr[i - start] = input[i];
		}
		arr[end - start + 1] = '\0';
		return arr;
	}
	catch (bad_alloc& exception)
	{
		cout << "(end = " << end << ", start = " << start<< ")bad_alloc detected: " << exception.what();
		return nullptr;
	}
}

void CheckStartSpaceOrTab(int* start, char* input)
{
	while (input[*start] == ' ' || input[*start] == '\t')
	{
		(*start)++;
	}
	/*if (input[*start] == ' ' || input[*start] == '\t')
	{
		(*start)++;
	} */
}

int CheckEndSpace(int end, char* input)
{
	while (input[end] == ' ' || input[end] == '\t')
	{
		end--;
	}
	return end;
	/*if (input[end] == ' ')
	{
		return end - 1;
	}
	else
	{
		return end;
	} */
}

void CoutString(char* arr)
{
	int i = 0;
	while (arr[i] != '\0')
	{
		cout << arr[i];
		i++;
	}
	cout << '\n';
}

void CoutString(char* arr, int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << arr[i];
	}
}

void ParseCSS(BlocksInfo* info, int *index, bool *mode)
{
	char last = 0, * str = nullptr, *atr_name = nullptr, *input = info->input;
	bool attribute = 0, selector = 0, value = 0;
	int start = 0, *blocks_amount = &(info->blocks_amount), hash = 0, atr_name_size = 0, input_size = info->input_size, questions = 0;
	BlockList* cur_list = info->blocklist, *blocklist = info->blocklist;
	Block* cur_block = nullptr;
	Attribute* attr = nullptr;
	Selector* sel = nullptr;
	while (questions != 4 || *index < input_size)
	{
		//cout << input[*index];
		if (input[*index] == '?')
		{
			questions++;
			if (questions == 4)
			{
				*mode = !(*mode);
				//(*index)++;
				return;
			}
		}
		else
		{
			questions = 0;
		}
		if (input[*index] == '{' && (!last || last == '}')) //global attribute
		{
			FindNodeAndBlock(&cur_list, &cur_block, blocklist);
			InitialiseBlock(cur_block, cur_list, blocks_amount);
			start = *index;
			attribute = true;
		}
		else if (input[*index] != '{' && ((!last || last == '}') || (last == ',' && selector))) //selector start
		{
			start = *index;
			CheckStartSpaceOrTab(&start, input);
			selector = true;
			if (!last || last == '}')
			{
				if (input[*index] != '?')
				{
					FindNodeAndBlock(&cur_list, &cur_block, blocklist);
					InitialiseBlock(cur_block, cur_list, blocks_amount);
				}
			}
		}
		else if ((input[*index] == ',' || input[*index] == '{') && selector) //selector end
		{
			str = CreateString(input, start, CheckEndSpace(*index - 1, input));
			if (str == nullptr)
			{
				*index = 1000000;
				return;
			}
			hash = GetCharHash(str, CheckEndSpace(*index - 1, input) - start + 1);
			sel = CreateSelector(str, hash);
			AddSelectorToBlock(cur_block, sel);
			if (input[*index] == '{')
			{
				selector = false;
				attribute = true;
			}
		}
		else if ((last == '{' && attribute) || (last == ';' && input[*index] != '}')) //attribute start
		{
			attribute = true;
			start = *index;
			CheckStartSpaceOrTab(&start, input);
		}
		else if (input[*index] == ':' && attribute) //attribute end
		{
			atr_name = CreateString(input, start, CheckEndSpace(*index - 1, input));
			atr_name_size = *index - start;
			attribute = false;
			value = true;
		}
		else if (last == ':' && value) //value start
		{
			start = *index;
			CheckStartSpaceOrTab(&start, input);
		}
		else if (input[*index] == ';' || input[*index] == '}' && value) //value end
		{
			str = CreateString(input, start, CheckEndSpace(*index - 1, input));
			if (str == nullptr)
			{
				*index = 1000000;
				return;
			}
			hash = GetCharHash(atr_name, atr_name_size);
			//proverka na powtor
			if (cur_block->attributes == nullptr || !FindAttributeAmountInList(hash, cur_block->attributes))
			{
				attr = CreateAttribute(atr_name, str, hash);
				AddAttributeToBlock(cur_block, attr);
			}
			else
			{
				FindAttributeInList(hash, cur_block->attributes)->value = str;
			}
			value = false;
		}
		last = input[*index];
		(*index)++;
	}
}

int CheckNumberString(char* arr, int start, int end)
{
	for (int i = start; i < end; i++)
	{
		if (arr[i] < '0' || arr[i] > '9')
		{
			return 0;
		}
	}
	return 1;
}

int StringToNumber(char* arr, int start, int end)
{
	int power = 1, rez = 0;
	for (int i = end - 1; i >= start; i--)
	{
		rez += (arr[i] - 48) * power;
		power *= 10;
	}
	return rez;
}

void CommandA(int block_number, BlocksInfo* info)
{
	if (block_number > info->blocks_amount)
	{
		//cout << block_number << ",A,? == \n";
		return;
	}
	else
	{
		int attr_amount = GetBlockByNumber(block_number, info)->attributes_amount;
		cout << block_number << ",A,? == " << attr_amount << "\n";
	}
}

void CommandA(int block_number, BlocksInfo* info, char* attr, int attr_size)
{
	if (block_number > info->blocks_amount)
	{
		//cout << block_number << ",A," << attr......;
		return;
	}
	else
	{
		int attr_hash = GetCharHash(attr, attr_size);
		AttributeList* list = GetBlockByNumber(block_number, info)->attributes;
		char* value = FindAttributeValue(attr_hash, list);
		if (value == nullptr)
		{
			return;
		}
		else
		{
			cout << block_number << ",A,";
			CoutString(attr, attr_size);
			cout << " == " << value << "\n";
		}
	}
}

void CommandA(char* attr, BlocksInfo* info, int attr_size)
{
	int attr_hash = GetCharHash(attr, attr_size);
	int attr_amount = FindAttributeAmount(attr_hash, info->blocklist);
	CoutString(attr, attr_size);
	cout << ",A,? == " << attr_amount << "\n";
}

void CommandQuestion(BlocksInfo* info)
{
	cout << "? == " << info->blocks_amount<<"\n";
}

Selector* GetSelectorByNumber(int number, Block* block)
{
	SelectorList* list = block->selectors;
	int i = 0;
	for (int i = 0; i < number - 1; i++)
	{
		list = list->next;
	}
	return list->selector;
}

int CountSelectorInNode(int sel_hash, SelectorList* list)
{
	int counter = 0;
	while (list != nullptr)
	{
		if (list->selector->hash == sel_hash)
		{
			counter++;
		}
		list = list->next;
	}
	return counter;
}

int CountSelectorInBlocks(int sel_hash, BlockList* list)
{
	Block* block;
	int counter = 0;
	while (list != nullptr)
	{
		for (int i = 0; i < T; i++)
		{
			block = (list->block) + i;
			if (block->initialized)
			{
				counter += CountSelectorInNode(sel_hash, block->selectors);
			}
		}
		list = list->next;
	}
	return counter;
}

void CommandS(int block_number, BlocksInfo* info)
{
	if (block_number > info->blocks_amount)
	{
		//cout << block_number << ",A,? == \n";
		return;
	}
	else
	{
		int sel_amount = GetBlockByNumber(block_number, info)->selectors_amount;
		cout << block_number << ",S,? == " << sel_amount << "\n";
	}
}

void CommandS(int block_number, int selector_nubmer, BlocksInfo* info)
{
	if (block_number > info->blocks_amount)
	{
		return;
	}
	else
	{
		Block* block = GetBlockByNumber(block_number, info);
		int sel_amount = block->selectors_amount;
		if (selector_nubmer > sel_amount)
		{
			return;
		}
		else
		{
			char* sel_name = GetSelectorByNumber(selector_nubmer, block)->name;
			cout << block_number << ",S,"<<selector_nubmer << " == " << sel_name << "\n";
		}
	}
}

void CommandS(char* sel_name, int sel_size, BlocksInfo* info)
{
	int sel_hash = GetCharHash(sel_name, sel_size), sel_amount = CountSelectorInBlocks(sel_hash, info->blocklist);
	CoutString(sel_name, sel_size);
	cout<< ",S,? == " << sel_amount << "\n";
}

char* CutString(char* arr, int start, int end, bool at_start)
{
	if (!at_start)
	{
		char* rez = new char[end - start - 1];
		for (int i = start + 1, j = 0; i < end; i++, j++)
		{
			rez[j] = arr[i];
		}
		return rez;
	}
	else
	{
		char* rez = new char[end - start];
		for (int i = start, j = 0; i < end; i++, j++)
		{
			rez[j] = arr[i];
		}
		return rez;
	}

}

bool FindSelectorInList(int sel_hash, SelectorList* list)
{
	if (list == nullptr)
	{
		return 1;
	}
	else
	{
		do
		{
			if (list->selector->hash == sel_hash)
			{
				return 1;
			}
			list = list->next;
		} while (list != nullptr);
		return 0;
	}
}

void CommandE(char* sel_name, int sel_size, char* attr_name, int attr_size, BlocksInfo* info)
{
	int sel_hash = GetCharHash(sel_name, sel_size), attr_hash = GetCharHash(attr_name, attr_size);
	char* value = nullptr;
	BlockList* list = info->blocklist;
	do
	{
		for (int i = 0; i < T; i++)
		{
			if (((list->block) + i)->initialized)
			{
				if (FindSelectorInList(sel_hash, ((list->block) + i)->selectors) || ((list->block) + i)->selectors_amount == 0)
				{
					if (FindAttributeValue(attr_hash, ((list->block) + i)->attributes) != nullptr)
					{
						value = FindAttributeValue(attr_hash, ((list->block) + i)->attributes);
					}				
				}
			}
		}
		list = list->next;
	} while (list != nullptr);
	if (value == nullptr)
	{
		return;
	}
	else
	{
		CoutString(sel_name, sel_size);
		cout << ",E,";
		CoutString(attr_name, attr_size);
		cout << " == " << value << "\n";
	}
}

void DeleteAttribute(Attribute* attr)
{
	if (attr->name != nullptr)
	{
		delete[] attr->name;
	}
	if (attr->value != nullptr)
	{
		delete[] attr->value;
	}
	delete attr;
}

void DeleteAttributeList(AttributeList* list)
{
	AttributeList* buf = list, * buf2 = list->next;
	do
	{
		DeleteAttribute(buf->attribute);
		delete buf;
		buf = buf2;
		if (buf != nullptr)
		{
			buf2 = buf->next;
		}
	} while (buf != nullptr);
}

void DeleteSelector(Selector* sel)
{
	delete[] sel->name;
	delete sel;
}

void DeleteSelectorList(SelectorList* list)
{
	if (list != nullptr)
	{
		SelectorList* buf = list, * buf2 = list->next;
		do
		{
			DeleteSelector(buf->selector);
			delete buf;
			buf = buf2;
			if (buf != nullptr)
			{
				buf2 = buf->next;
			}
		} while (buf != nullptr);
	}
}

void DeleteBlock(Block* block)
{
	DeleteAttributeList(block->attributes);
	DeleteSelectorList(block->selectors);
	block->selectors = nullptr;
	block->attributes = nullptr;
	block->selectors_amount = 0;
	block->attributes_amount = 0;
	block->number = 0;
	block->initialized = false;
}

int DeleteBlockByNumber(int block_number, BlocksInfo* info)
{
	if (block_number == 9)
	{
		int a = 0;
	}
	Block* block = GetBlockByNumber(block_number, info);
	if (block != nullptr)
	{
		DeleteBlock(block);
		return 1;
	}
	return 0;
}

void UpdateBlocksNumbers(int deleted_number, BlocksInfo* info)
{
	BlockList* list = info->blocklist;
	bool deleted = false;
	info->blocks_amount--;
	do
	{
		for (int i = 0; i < T; i++)
		{
			if (((list->block)+i)->initialized)
			{
				if (((list->block) + i)->number > deleted_number)
				{
					((list->block) + i)->number--;
				}
				else if (((list->block) + i)->number == deleted_number && !deleted)
				{
					list->places++;
					deleted = true;
				}
			}
		}
		list = list->next;
	} while (list != nullptr);
}

bool DeleteAttributeNode(int attr_hash, Block* block, BlocksInfo* info)
{
	AttributeList* list = block->attributes, *buf = nullptr;
	do
	{
		if (list->attribute->name_hash == attr_hash)
		{
			block->attributes_amount--;
			if (block->attributes_amount == 0)
			{
				int block_number = block->number;
				DeleteBlockByNumber(block_number, info);
				UpdateBlocksNumbers(block_number, info);
				return true;
			}
			DeleteAttribute(list->attribute);
			if (buf == nullptr)
			{
				block->attributes = list->next;
				delete list;
			}
			else
			{
				buf->next = list->next;
				delete list;
			}
			return true;
		}
		else
		{
			buf = list;
			list = list->next;
		}
	} while (list != nullptr);
	return false;
}

void CommandD(int block_number, BlocksInfo* info)
{
	if (DeleteBlockByNumber(block_number, info))
	{
		UpdateBlocksNumbers(block_number, info);
		cout << block_number << ",D,* == deleted\n";
	}
}

void CommandD(char* attr, int attr_size, int block_number, BlocksInfo* info)
{
	int attr_hash = GetCharHash(attr, attr_size);
	Block* block = GetBlockByNumber(block_number, info);
	if (block != nullptr && block->initialized)
	{
		if (DeleteAttributeNode(attr_hash, block, info))
		{
			cout << block_number << ",D,";
			CoutString(attr, attr_size);
			cout << " == deleted\n";
		}
	}
}

void ExecuteCommand(BlocksInfo* info, int com_start, int com_end, int comma1, int comma2)
{
	char* input = info->input;
	/*for (int i = com_start; i < com_end; i++)
	{
		cout << input[i];
	}
	cout << " - command\n";
	*/
	if (input[com_start] == input[com_end-1] && input[com_start] == '?')
	{
		CommandQuestion(info);
	}
	else
	{
		char command = input[comma1 + 1];

		if (command == 'A')
		{
			if (CheckNumberString(input, com_start, comma1))
			{
				int block_number = StringToNumber(input, com_start, comma1);
				if (input[comma2 + 1] == input[com_end - 1] && input[comma2 + 1] == '?')
				{
					CommandA(block_number, info);
				}
				else
				{
					char* attr_name = CutString(input, comma2, com_end, false);
					CommandA(block_number, info, attr_name, com_end - comma2 - 1);
				}
			}
			else
			{
				char* attr_name = CutString(input, com_start, comma1, true);
				CommandA(attr_name, info, comma1 - com_start);
			}	
		}
		else if (command == 'S')
		{
			if (CheckNumberString(input, com_start, comma1))
			{
				int block_number = StringToNumber(input, com_start, comma1);
				if (input[comma2 + 1] == input[com_end - 1] && input[comma2 + 1] == '?')
				{
					CommandS(block_number, info);
				}
				else
				{
					int sel_number = StringToNumber(input, comma2+1, com_end); 
					CommandS(block_number, sel_number, info);
				}
			}
			else
			{
				char* sel_name = CutString(input, com_start, comma1, true);
				CommandS(sel_name, comma1 - com_start, info);
			}
		}
		else if (command == 'E')
		{
			char* sel_name = CutString(input, com_start, comma1, true), *attr_name = CutString(input, comma2, com_end, false);
			CommandE(sel_name, comma1 - com_start, attr_name, com_end - comma2 - 1, info);
		}
		else if (command == 'D')
		{
			int block_number = StringToNumber(input, com_start, comma1);
			if (input[comma2 + 1] == input[com_end - 1] && input[comma2 + 1] == '*')
			{
				CommandD(block_number, info);
			}
			else
			{
				char* attr_name = CutString(input, comma2, com_end, false);
				CommandD(attr_name, com_end - comma2 - 1, block_number, info);
			}
		}
	}

}

void ParseCommands(BlocksInfo* info, int* index, bool* mode)
{
	int stars = 0, input_size = info->input_size, com_start = 0, com_end = 0, comma1 = 0, comma2 = 0;
	char* input = info->input;
	while (stars != 4 && *index < input_size)
	{
		//cout << input[*index];
		com_start = *index;
		comma1 = 0;
		comma2 = 0;
		while (input[*index] != '\n' && *index < input_size)
		{
			if (input[*index] == '*')
			{
				stars++;
				if (stars == 4)
				{
					*mode = !(*mode);
					//(*index)++;
					return;
				}
			}
			else
			{
				stars = 0;
			}
			if (input[*index] == ',' && !comma1)
			{
				comma1 = *index;
			}
			else if (input[*index] == ',' && comma1)
			{
				comma2 = *index;
			}
			com_end = ++ (*index);
		}
		ExecuteCommand(info, com_start, com_end, comma1, comma2);
		(*index)++;
		
	}
}

void ParseInput(BlocksInfo* info)
{
	int size = info->input_size;
	bool mode = false;
	for (int i = 0; i < size; i++)
	{
		if (!mode)
		{
			ParseCSS(info, &i, &mode);
			continue;
		}
		else
		{
			ParseCommands(info, &i, &mode);
			continue;
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(0);
	int size = 0;
	char* input = GetInput(&size);
	BlocksInfo* info = SetBlocksInfo(input, size);
	ParseInput(info); //new node for every block xd
	return 0;
}