//
//  node.cpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 23/03/2023.
//

#include "node.hpp"
#include <iostream>
using namespace std;
#define T 8


block* findFreeElement(block blockArr[]) {
    for (int i = 0; i < T; i++) {
        if (blockArr[i].headSelector == nullptr && blockArr[i].headAttribute == nullptr) {
            return &blockArr[i];
        }
    }
    return nullptr;
}


void Node::addFirst(Node **head, block blockArr[]){
    Node* newNode = new Node; //allocating node
    for (int i = 0; i < T; i++) {
                newNode->blockArr[i] = blockArr[i];
            }
    newNode->next = (*head); //next node as head
    newNode->prev = nullptr; //its the first element so there is no previous element
    
    if((*head) != nullptr)
        (*head)->prev = newNode; //changing previous element of the head node to new node
    
    (*head) = newNode;
}


void Node::addAfter(Node *prevNode, block* blockArr){
    //checking if pointer to previous node is made
    if(prevNode == nullptr){
        cout << "previous node cannot be null";
        return;
    }
    
    Node* newNode = new Node();
    
    for (int i = 0; i < T; i++) {
                newNode->blockArr[i] = blockArr[i];
            }
    newNode->next = prevNode->next;
    prevNode->prev = newNode;
    newNode->prev = prevNode;
    
    if(newNode->next != nullptr)
        newNode->next->prev = newNode;
    
}

void Node::addLast(Node **head, block* blockArr){
    Node* newNode = new Node();
    Node* last = *head;
    for (int i = 0; i < T; i++) {
                newNode->blockArr[i] = blockArr[i];
            }
    newNode->next = nullptr;
    
    if(*head == nullptr){ //if linked list is empty then
        newNode->prev = nullptr; //use the new node as a head
        *head = newNode;
        return;
    }
    
    while (last->next != nullptr) //if linked list isn't empty then go till the last node
        last = last->next;
    
    last->next = newNode; //newNode is the new last node
    newNode->prev = last; //lest becomes one before last
    return;
        
}


Node* Node::getLastNode(Node** head) {
    Node* last = *head;
    if(last == nullptr)
        return 0;
    while (last->next != nullptr){ //if linked list isn't empty then go till the last node
        last = last->next;
    }
    return last;
}


