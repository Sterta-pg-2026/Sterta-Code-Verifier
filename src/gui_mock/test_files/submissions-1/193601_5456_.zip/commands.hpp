//
//  commands.hpp
//  AIDSproject1
//
//  Created by Aleksandra JaÅ¼dÅ¼ewska on 02/04/2023.
//
#pragma once
#ifndef commands_hpp
#define commands_hpp

#include <stdio.h>
#include <iostream>
#include "node.hpp"
#include "stringnode.hpp"
#include "block.hpp"

#endif /* commands_hpp */



using namespace std;


class command{
public:
    char* com1;
    char* com2;
    char* com3;
    bool isCom1=true, isCom2=false, isCom3=false;
    int i=0, size=1;
    char* word = new char[size+8];
    char letter;
    
    int getGlobalIndexFromExistingSection(int i, Node** head) {
        // get index, skip deleted block
        Node* localHead = *head;
        Node* last = localHead;
        char empty[] = { 'd', 'w', 'a' ,'\0' };  // placeholder in deleted blocks
        int index = 0;
        //int counter = 0;
        int globalIndex = 0;
        while (last->next != nullptr) {
            last = last->next;
        }
        //stringNode* attributer;
        stringNode* selector = localHead->blockArr[index].headSelector;
        while (index < T && selector != nullptr) {
            if (strcmp(selector->getData().property, empty)) {
                globalIndex++;
            }
            if (globalIndex == i) {
                return index;
            }
            index++;
            selector = localHead->blockArr[index].headSelector;
        }
        return NULL;
    }


   // int selectorsOfSection(int i, Node** head); //i,S,?
    int selectorsOfSection(int i, Node** head) {
        //i,S,? jesli 0 to skipowac
        i = i - 1; // instruction numeration from 1 not from 0;
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
            stringNode* selector;
            int moveHead = 0;
            if (i > (T-1)) {
                moveHead = i / (T-1);
                i = T % T;
        }
            for (int headp = 0; headp < moveHead; headp++) {
                if (localHead->next == nullptr) {
                    return 0;
                }
                else {
                    localHead = localHead->next;
                    current = localHead;
                }
        }
            if (current->blockArr[i].headSelector == nullptr) {
                return 0;
            }
            else {
                selector = current->blockArr[i].headSelector;
            }
            while (selector != nullptr)
            {
                count++;
                selector = selector->getLink();
            }
            return count;
    }
    
    
    int attributesOfSection(int i, Node** head) {
        //i,A,? if 0 then skip
        //i = i - 1; // instruction numeration from 1 not from 0;
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
        stringNode* attribute;
        int moveHead = 0;
        if (i > (T)) {
            moveHead = i / (T); // i = 25, T = 8, moveHead = 3 => 4
            if (i - moveHead * T > 0) moveHead++;
            if (i % T == 0) i = 7;
            else {
                i = (i % T)-1;
            }
            
        }
        else {
            i = i - 1;
        }
        for (int headp = 0; headp < moveHead-1; headp++) {
            if (localHead->next == nullptr) {
                return 0;
            }
            else{
            localHead = localHead->next;
            current = localHead;
            }
        }
        if (current->blockArr[i].headAttribute == nullptr) {
            return 0;
        }
        else{
            attribute = current->blockArr[i].headAttribute;
        }
        while (attribute != nullptr)
        {
            count++;
            attribute = attribute->getLink();
        }
        return count;
    }

    char* jSelectorOfiBlock(int j, int i, Node** head) {
        //i,S,j jesli 0 to skipowac
        i = i - 1; // instruction numeration from 1 not from 0;
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
        stringNode* selector;
        int moveHead = 0;
        if (i > (T-1)) {
            moveHead = i / (T-1);
            i = i % T;
        }
        for (int headp = 0; headp < moveHead; headp++) {
            if (localHead->next == nullptr) {
                return NULL;
            }
            else {
                localHead = localHead->next;
                current = localHead;
            }
        }
        if (current->blockArr[i].headSelector == NULL) {
            return NULL;
        }
        else {
            selector = current->blockArr[i].headSelector;
        }
        while (count < j-1 && selector != NULL)
        {
            count++;
            selector = selector->getLink();
        }
        if (selector == NULL) {
            // selector does not exists
            return NULL;
        }
        return selector->getData().property;
    }

    char* namedAttributeOfiBlock(char* n, int i, Node** head) {
        //i,A,n jesli 0 to skipowac
        Node* localHead = *head;
        Node* current = localHead;
        stringNode* attribute;
        int moveHead = 0;
        if (i > (T)) {
            moveHead = i / (T);
            if (i - moveHead * T > 0) moveHead++;
            if (i % T == 0) i = 7;
            else {
                i = (i % T) - 1;
            }
        }
        else {
            i = i - 1;
        }
        for (int headp = 0; headp < moveHead - 1; headp++) {
            if (localHead->next == nullptr) {
                return 0;
            }
            else {
                localHead = localHead->next;
                current = localHead;
            }
        }
        if (current->blockArr[i].headAttribute == nullptr) {
            return 0;
        }
        else {
            attribute = current->blockArr[i].headAttribute;
        }
        while (strcmp(attribute->getData().property, n))
        {
            if (attribute->getLink() == nullptr) {
                return NULL;
            }
            attribute = attribute->getLink();
        }
        return attribute->getData().value;
    }

    int totalAttributeOccur(char* n, Node** head) {
        //n,A,?
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
        stringNode* attributer;
        int index=0;
        bool sameBlock = true;
        while (current != NULL) {
            index = 0;
            while (current->blockArr[index].headAttribute != nullptr && index < 8) {
                attributer = current->blockArr[index].headAttribute;
                while (attributer != NULL) {
                    if (!strcmp(attributer->getData().property, n)) {
                        count++;
                        sameBlock = false;
                        break;
                    }
                    attributer = attributer->getLink();
               }
                index++;
                sameBlock = true;
            }
            current = current->next;
        }
        return (count);
    }

 
    int totalSelectorOccur(char* z, Node** head) {
        //z,S,? jesli
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
        stringNode* selector;
        int index = 0;
        while (current != nullptr) {
            index = 0;
            while (index < 8) {
                selector = current->blockArr[index].headSelector;
                while (selector != nullptr) {
                    if (!strcmp(selector->getData().property, z)) {
                        count++;
                        break;
                    }
                    selector = selector->getLink();
                    
                }
                index++;
            }
            current = current->next;
        }
        return (count);
    }

    char* latestAttributeForSelector(char* n, char* z, Node** head) {
        //z,E,n jesli z - selctor, n - atrybut
        // TODO: Poprawic
        Node* localHead = *head;
        Node* last = localHead;
        char* ans = NULL;
        int index = 0;
        stringNode* attributer;
        stringNode* selector;
        while (last->next != nullptr) {
            last = last->next;
        }
        do{
            if (last->next == nullptr) {
                index = 0;
                while (index < T) {
                    selector = last->blockArr[index].headSelector;
                    while (selector!= nullptr) {
                        if (!strcmp(selector->getData().property, z)) {
                            attributer = last->blockArr[index].headAttribute;
                            while (attributer != nullptr) {
                                if (!strcmp(attributer->getData().property, n)) {
                                    ans = attributer->getData().value;
                                }
                                attributer = attributer ->getLink();
                            }
                        }
                        selector = selector->getLink();
                    }
                    index++;
                }
                if (ans != NULL) {
                    return ans;
                }
            }
            else {
                index = 7;
                //selector = last->blockArr[index].headSelector;
                while (index >-1) {
                    selector = last->blockArr[index].headSelector;
                    while (selector != nullptr) {
                        if (!strcmp(selector->getData().property, z)) {
                            attributer = last->blockArr[index].headAttribute;
                            while (attributer != nullptr) {
                                if (!strcmp(attributer->getData().property, n)) {
                                    return attributer->getData().value;
                                }
                                attributer = attributer->getLink();
                            }
                        }
                        selector = selector->getLink();
                    }
                    index--;
                }
            }
            last = last->prev;
        } while (last != NULL);
        return ans;
    }

    int removeSection(int i, Node** head) {
        //i,D,*
        i = i - 1; // instruction numeration from 1 not from 0;
        Node* localHead = *head;
        Node* current = localHead;
        structNode attribute;
        structNode selector;
        int moveHead = 0;
        if (i > (T-1)) {
            moveHead = i / (T-1);
            i = i % T;
        }
        for (int headp = 0; headp < moveHead; headp++) {
            if (localHead->next == nullptr) {
                return -1;
            }
            else {
                localHead = localHead->next;
                current = localHead;
            }
        }
        i = getGlobalIndexFromExistingSection(i + 1, head);
        char empty[] = { 'd', 'w', 'a' ,'\0' };  // set placeholder instead of clear to better navigate trought blocks, knew that there are still blocks after this
        attribute.SetProperty(empty);
        selector.SetProperty(empty);
        current->blockArr[i].headAttribute->deleteList(current->blockArr[i].headAttribute);
        current->blockArr[i].headSelector->deleteList(current->blockArr[i].headSelector);
        current->blockArr[i].headSelector->headInsert(current->blockArr[i].headSelector, attribute);
        current->blockArr[i].headAttribute->headInsert(current->blockArr[i].headAttribute, selector);
       
        
        return 1;
     }
    
    int removeAttributeFromSection(int i, char* n, Node** head) {
        // i,D,n - i-th section, n - named atribute
        //i = i - 1; // instruction numeration from 1 not from 0;
        Node* localHead = *head;
        Node* current = localHead;
        int count = 0;
        int attrPosition = 0; // if pos == 0 i next = Null to delete
        stringNode* attribute;
        structNode attributeVal;
        structNode selectorVal;
        int moveHead = 0;
        if (i > (T)) {
            moveHead = i / (T);
            if (i - moveHead * T > 0) moveHead++;
            if (i % T == 0) i = (T-1);
            else {
                i = (i % T) - 1;
            }
        }
        else {
            i = i - 1;
        }
        i = getGlobalIndexFromExistingSection(i + 1, head);
        for (int headp = 0; headp < moveHead - 1; headp++) {
            if (localHead->next == nullptr) {
                return 0;
            }
            else {
                localHead = localHead->next;
                current = localHead;
            }
        }
        if (current->blockArr[i].headAttribute == nullptr) {
            return 0;
        }
        else {
            attribute = current->blockArr[i].headAttribute;
        }
        stringNode* prevAttribute = attribute;
        while (strcmp(attribute->getData().property, n) && attribute->getLink() != nullptr)
        {
            attrPosition++;
            prevAttribute = attribute;
            attribute = attribute->getLink();
        }
        if (attribute ==  nullptr) {
            return NULL;
        }
        else{
            if (attrPosition==0 && attribute->getLink() == nullptr){
                char empty[] = { 'd', 'w', 'a' ,'\0' };
                attributeVal.SetProperty(empty);
                selectorVal.SetProperty(empty);
                current->blockArr[i].headAttribute->deleteList(current->blockArr[i].headAttribute);
                current->blockArr[i].headSelector->deleteList(current->blockArr[i].headSelector);
                current->blockArr[i].headSelector->headInsert(current->blockArr[i].headSelector, attributeVal);
                current->blockArr[i].headAttribute->headInsert(current->blockArr[i].headAttribute, selectorVal);
                return 1;
            }
            else if (attribute->getLink() == nullptr) {
                current->blockArr[i].headAttribute->deleteTail(prevAttribute);
                return 1;
            }
            else if (attrPosition == 0) {
                prevAttribute->setLink(NULL);
                free(prevAttribute);
                return -1;
            }
            else {
                stringNode* nextAttribute = prevAttribute->getLink()->getLink();
                free(prevAttribute->getLink());
                prevAttribute->setLink(nextAttribute) ;
                return 1;
            }
        }

    }
    
    int findFirstEmptyBlock(Node** head) {
        Node* last = *head;
        char empty[] = { 'd', 'w', 'a' ,'\0' };
        int index = 0;
        stringNode* selector;
        if (last == nullptr) {
            return 8;
        }
        while (last->next != nullptr ) {
            last = last->next;
        }
        while (index < T) {
            selector = last->blockArr[index].headSelector;
            if (selector == nullptr || !strcmp(selector->getData().property, empty)) {
                return index;
            }
            index++;
        }
        return T;
    }

    int getCssSectoins(Node** head) {
        Node* localHead = *head;
        Node* last = localHead;
        char empty[] = { 'd', 'w', 'a' ,'\0' };
        int index = 0;
        int counter = 0;
        stringNode* selector;
        while (last->next != nullptr) {
            counter = counter + T;
            last = last->next;
        }
        while (index < T) {
            selector = last->blockArr[index].headSelector;
            if (selector == NULL) {
                return counter;
            }
            if (strcmp(selector->getData().property, empty)) {
                counter++;
            }
            index++;
        }
        return counter;
    }

    int checkFreeBlocks(Node** head) {
        Node* localHead = *head;
        Node* last = localHead;
        char empty[] = { 'd', 'w', 'a' ,'\0' };
        int index = 0;
        int counter = 0;
        stringNode* selector;
        while (last->next != nullptr) {
            last = last->next;
        }
        while (index < T) {
            selector = last->blockArr[index].headSelector;
            if (selector == nullptr || !strcmp(selector->getData().property, empty)) {
                counter++;
            }
            index++;
        }
        return counter;
    }

    void deleteUselessDLLNode(Node** head) {
        if (checkFreeBlocks(head) == T) {
            Node* localHead = *head;
            Node* last = localHead;
            while (last->next != nullptr) {
                last = last->next;
            }
            Node* prev = last->prev;
            prev->next = NULL;
            free(last);
        }
    }

    
    void clearArray(char* arr, int size){
         for (int j = 0; j < size; j++) { //clearing an array
             arr[j] = '\0';
         }
    }

    bool isNumber(char* arr){
        for(int i=0; arr[i] != '\0'; i++){
            if(arr[i] < '0' || arr[i] > '9')
                return false;
        }
        return true;
    }
    
    char* getCom(char* word, int i, int size){
        char* com = new char[size];
        word[--i] = '\0'; //we delete ',' from word array
        for(int j=0; j<size; j++){
            com[j]=word[j]; //we put inside of word into com1
        }
        return com;
        delete[] com;
    }
    
    void getCom2(bool isCom1=true, bool isCom2=false, bool isCom3=false){
        letter = getchar();
        word[i++] = letter;
        size++;
        if(letter==',' && isCom1){
            word[--i] = '\0'; //we delete ',' from word array
            for(int j=0; j<size; j++){
                com1[j]=word[j]; //we put the inside of word into com1
            }
            clearArray(word, size); //we clear word array
            i = 0; size = 1; //set word array variables to initial values
            isCom1 = false; //change bool to false cause we inserted first command
            isCom2 = true; //change bool cause now we are going to insert second command
        }
        else if(letter==',' && isCom2){
            word[--i] = '\0'; //we delete ',' from word array
            for(int j=0; j<size; j++){
                com2[j]=word[j]; //we put the inside of word into com2
            }
            clearArray(word, size); //we clear word array
            i = 0; size = 1; //set word array variables to initial values
            isCom2=false; //change bool to false cause we inserted second command
            isCom3=true; //change bool cause now we are going to insert third command
        }
        else if((letter==' ' || letter=='\n' ) && isCom3){
            word[--i] = '\0'; //we delete ',' from word array
            for(int j=0; j<size; j++){
                com3[j]=word[j]; //we put the inside of word into com2
            }
            clearArray(word, size); //we clear word array
            i = 0; size = 1; //set word array variables to initial values
            isCom3=false; //change bool to false cause we inserted second command
            isCom1=false; //change bool cause now we are going to insert third command
        }
        else if(letter == '?' && isCom1){
            com1[0]='?';
            clearArray(word, size); //we clear word array
            i = 0; size = 1; //set word array variables to initial values
            isCom3=false; //change bool to false cause we inserted second command
            isCom2=false; //change bool cause now we are going to insert third command
        }
    }
    
};
