//
//  stringNode.cpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 28/03/2023.
//

#include "stringnode.hpp"
#include <iostream>
using namespace std;

void stringNode::headInsert(stringNode* &head, structNode d)
{
    head = new stringNode(d, head);
}

void stringNode::insertLast(stringNode*& head, structNode d)
{
    stringNode* newNode = new stringNode(d, nullptr);
    stringNode* last = head;

    if (head == nullptr) { //if linked list is empty then
        head = newNode;
        return;
    }

    while (last->linkPtr != nullptr) //if linked list isn't empty then go till the last node
        last = last->linkPtr;

    last->linkPtr = newNode; //newNode is the new last node
}

void stringNode::deleteList(stringNode *& head)
{
    stringNode* current;
    stringNode* next =nullptr;
    current = head;

    // move tail to the last but one node

    while (current != nullptr) {
        next = current->getLink();
        free(current);
        current = next;
    }
    head = nullptr;
    delete current;
    delete next;
}

void stringNode::deleteTail(stringNode *head)
{
    stringNode *discard, *tail;
    tail = head;

    // move tail to the last but one node

    while ((tail->getLink())->getLink() != nullptr)
        tail = tail -> getLink();

    tail -> setLink(nullptr);
    discard = tail->getLink();
    delete discard;
}

void stringNode::printAll()
{
    if (this == nullptr)
        cout << "Empty list\n";

    else
    {
        int i = 1;
        stringNode *tempPtr = this;
        cout << "The list is: ";
        while (tempPtr != nullptr)
        {
            char* property = tempPtr->getData().property;
            char* value = tempPtr->getData().value;
            if(property != nullptr)
                cout << property;
            if(value != nullptr)
                cout << value;
            tempPtr = tempPtr->getLink();
        }
    }
}

void stringNode::changeValue(stringNode* node, char *str) //count length of str
{
    int l = 0;
    while (str[l++] != '\0') {} //mierzy dlugosc
    node->data.value = nullptr;
    while (str[l++] != '\0') {} //mierzy dlugosc
    node->data.value = new char[l];
    for (int i = 0; i < l; i++)
    {
        node->data.value[i] = str[i]; //copy str
    }
}

