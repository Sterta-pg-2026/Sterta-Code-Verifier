//
//  block.hpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 26/03/2023.
//
#pragma once
#ifndef block_hpp
#define block_hpp

#include <stdio.h>
//#include "nodeL.hpp"
#include "stringnode.hpp"
#endif /* block_hpp */



typedef struct block{
    stringNode *headSelector=nullptr;
    stringNode *headAttribute=nullptr;
}block;

