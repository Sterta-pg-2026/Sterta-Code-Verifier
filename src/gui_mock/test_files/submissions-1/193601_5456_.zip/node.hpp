//
//  node.hpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 23/03/2023.
//
#pragma once
#ifndef node_hpp
#define node_hpp

#include <stdio.h>
#include "stringnode.hpp"
#include "block.hpp"

#endif /* node_hpp */

#define T 8


class Node {
public:



    block blockArr[T];
    Node* next = nullptr;
    Node* prev = nullptr;
    
    block* freeElement(block* blockArr);
    void addFirst(Node** head, block* blockArr);
    void addAfter(Node* prev, block* blockArr);
    void addLast(Node** head, block* blockArr);
    Node* getLastNode(Node** head);
    void displayList(Node* node);

};



