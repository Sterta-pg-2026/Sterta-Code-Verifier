//
//  stringNode.hpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 28/03/2023.
//
#pragma once
#ifndef stringNode_hpp
#define stringNode_hpp

#include <iostream>

#endif /* stringNode_hpp */


class structNode{
public:
    char* property = nullptr;
    char* value = nullptr;
    structNode()
    {
        this->property = nullptr;
        this->value = nullptr;
    }
    void SetProperty(char* str) //count length of str
    {
        int l = 0;
        while (str[l++] != '\0') {} //mierzy dlugosc
        this->property = new char[l];
        for (int i = 0; i < l; i++)
        {
            this->property[i] = str[i]; //copy str
        }
    }
    void SetValue(char* str) //count length of str
    {
        int l = 0;
        while (str[l++] != '\0') {} //mierzy dlugosc
        this->value = new char[l];
        for (int i = 0; i < l; i++)
        {
            this->value[i] = str[i]; //copy str
        }
    }
    void clear()
    {
        delete[] property;
        this->property = nullptr;
        delete[] value;
        this->value = nullptr;
    }
};

class stringNode{
public:
    stringNode(){}
    stringNode(char* property, char* value, stringNode *lPtr) //constructor of attribute
    {
        structNode* temp = new structNode;
        temp->SetProperty(property);
        temp->SetValue(value);
        this->linkPtr=lPtr;
        this->data = *temp;
    }
    stringNode(char* property, stringNode *lPtr) //constructor of selextor
    {
        structNode* temp = new structNode;
        temp->SetProperty(property);
        linkPtr=lPtr;
        data = *temp;
        
    }
    stringNode(structNode d, stringNode *lPtr)
    {
        linkPtr=lPtr;
        data = d;
    }
    stringNode *getLink() const {return linkPtr;}
    structNode getData() {return data;}
    void setLink(stringNode *lPtr) {linkPtr = lPtr;}
    void headInsert(stringNode* &head, structNode d);
    void insertLast(stringNode*& lastNode, structNode d);
    void deleteList(stringNode*& head);
    void deleteTail (stringNode *before);
    void printAll();
    void changeValue(stringNode* node, char* str); //count length of str
    ~stringNode() {};
    
private:
    structNode data;
    stringNode *linkPtr;

};
