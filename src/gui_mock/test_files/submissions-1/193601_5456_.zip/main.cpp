//
//  node.cpp
//  AIDSproject1
//
//  Created by Aleksandra Jażdżewska on 23/03/2023.

#include "node.hpp"
//#include "nodeL.hpp"
//#include "String.hpp"
#include "stringnode.hpp"
//#include "DLList.hpp"
#include "block.hpp"
#include <iostream>
#include "commands.hpp"
#include <cctype>
#include <stdlib.h>


#define T 8
using namespace std;

void commandFilter(char* com1, char* com2, char* com3, command command, Node **head, int sectionCounter){
    int ans = 0;
    char* charAns = NULL;
        switch (com2[0]){
            case 'S':
                if(com3[0]=='?'){
                    if(command.isNumber(com1)){ //i,S,?
                        ans = command.selectorsOfSection(atoi(com1), head);
                        if(ans != 0){
                            cout << com1 << "," << com2 << "," << com3 << " == " << ans << endl;
                        ans = 0;}
                        else
                            break;
                    }
                    else{ //z,S,?
                        cout << com1 << "," << com2 << "," << com3 << " == " << command.totalSelectorOccur(com1, head) << endl;
                    }
                }
                else{ //i,S,j
                    charAns = command.jSelectorOfiBlock(atoi(com3), atoi(com1), head);
                    if (charAns != NULL) cout << com1 << "," << com2 << "," << com3 << " == " << charAns << endl;

                }
                 break;
            case 'A':
                if(com3[0]=='?'){
                    if(command.isNumber(com1)){ //i,A,?
                        ans = command.attributesOfSection(atoi(com1), head);
                        if(ans != 0)
                        cout << com1 << "," << com2 << "," << com3 << " == " << ans << endl;
                        else
                            break;
                    }
                    else{ //n,A,?
                        cout << com1 << "," << com2 << "," << com3 << " == " << command.totalAttributeOccur(com1, head) << endl;
                    }
                }
                else{ //i,A,n
                    charAns = command.namedAttributeOfiBlock(com3, atoi(com1), head);
                    if(charAns != NULL)
                        cout << com1 << "," << com2 << "," << com3 << " == " << charAns << endl;
                    else
                        break;
                }
                 break;
            case 'D':
                if(com3[0]=='*'){ //i,D,*
                    if(command.removeSection(atoi(com1), head) == 1){
                        cout << com1 << "," << com2 << "," << com3 << " == deleted" << endl;
                    }
                    else
                        break;
                }
                else{ //i,D,n
                    if(command.removeAttributeFromSection(atoi(com1), com3, head) == 1){
                        cout << com1 << "," << com2 << "," << com3 << " == deleted" << endl;
                    }
                    else
                        break;
                }
                break;
            case 'E':
                charAns = command.latestAttributeForSelector(com3, com1, head);
                if(charAns != NULL)
                    cout << com1 << "," << com2 << "," << com3 << " == " << command.latestAttributeForSelector(com3, com1, head) << endl;
                else
                    break;
                  break;
        }
}


int main(int argc, char* argv[])
{
    command command;
    Node* nodeDDL = new Node;
    Node* head = nullptr;
    int sectionCounter = 0;
    stringNode selectorsList;
    stringNode attributesList;
    char letter;
    bool isItAttr = false, isEndOfBlock=false, cssInput=true, commandInput=false;
    int i=0, size=1, blockCounter=0;
    char* word = new char[16];
    char* tempWord = NULL;
    char* com1 = NULL;
    char* com2 = NULL;
    char* com3 = NULL;
    bool blockInit = true;
    structNode attribute;
    structNode selector;
    bool isCom1=true, isCom2=false, isCom3=false;
    char empty[] = { 'd', 'w', 'a' ,'\0' };
    bool openedSection = false;
    stringNode* attributeNode = nullptr; //=nullptr zmiana
    bool added=false;
    nodeDDL->addLast(&head, nodeDDL->blockArr);
    
    //getting input
       do{
           letter = getchar();
           size++;
           if (!((i + 1) % 16)) {
                 tempWord = word;
                 tempWord = (char*)realloc(word, sizeof(char*)*(i + 1 + 16));
                 word = tempWord;
            }
           word[i++] = letter;
           if(cssInput){
               if (blockCounter == T) {
                   nodeDDL->addLast(&head, nodeDDL->blockArr);
                   delete nodeDDL;
                   nodeDDL = new Node;
                   blockCounter = command.findFirstEmptyBlock(&nodeDDL); //if the whole block is filled, we make blockcounter 0
               }
               if((letter == ',' || letter == '{') && !isItAttr){
                   word[--i] = '\0';
                       if (word[--i] == ' ') word[i] = '\0';
                       selector.SetProperty(word); //
                       if (head->getLastNode(&head)->blockArr[blockCounter].headSelector != nullptr && !strcmp(head->getLastNode(&head)->blockArr[blockCounter].headSelector->getData().property, empty))//check if the node was deleted before, if so:
                       {
                           head->getLastNode(&head)->blockArr[blockCounter].headAttribute->deleteList(head->getLastNode(&head)->blockArr[blockCounter].headAttribute); //we delte the list of att
                           head->getLastNode(&head)->blockArr[blockCounter].headSelector->deleteList(head->getLastNode(&head)->blockArr[blockCounter].headSelector); //we delete the list of selectors
                           head->getLastNode(&head)->blockArr[blockCounter].headSelector->insertLast(head->getLastNode(&head)->blockArr[blockCounter].headSelector, selector); //we put new list of selectors on their place
                       }
                       else{ //if not:
                           head->getLastNode(&head)->blockArr[blockCounter].headSelector->insertLast(head->getLastNode(&head)->blockArr[blockCounter].headSelector, selector); //we make a new node
                       }
                       i = 0; size = 1;
                       openedSection = true;
                       delete[] word;
                       word = new char[16];
               }
               else if (letter == ':' && openedSection){
                   word[--i] = '\0';
                   if (word[--i] == ' ') word[i] = '\0';
                   attribute.SetProperty(word);
                   attributeNode = head->getLastNode(&head)->blockArr[blockCounter].headAttribute;
                   while (attributeNode != nullptr)
                   {
                       if (!strcmp(attributeNode->getData().property, word)) { //if property already exist in the list => added true
                           added = true;
                           break;
                       }
                       attributeNode = attributeNode->getLink();
                   }
                   i = 0; size = 1;
                   isItAttr = true;
                   delete[] word;
                   word = new char[16];
               }
               else if( (letter == ';' || letter == '\n') && isItAttr){
                   word[--i] = '\0';
                   if (word[--i] == ' ') word[i] = '\0'; // "x45 " => "x45"
                   if (word[0] == ' ') { // " x45" => "x45"
                       for (int index = 0; index < i; index++) {
                           word[index] = word[index+1];
                       }
                       word[i] = '\0';
                   }
                   attribute.SetValue(word);
                   
                  if(added){ //we iterate till the end of list and if find the attribute property then replace value
                      attributeNode = head->getLastNode(&head)->blockArr[blockCounter].headAttribute;
                      while (attributeNode != nullptr)
                      {
                          if (!strcmp(attributeNode->getData().property, attribute.property)) {
                              attributeNode->changeValue(attributeNode, word);
                              added = false;
                              break;
                          }
                          attributeNode = attributeNode->getLink();
                      }
                  }
               else { //if property doesnt exist we make new node
                       head->getLastNode(&head)->blockArr[blockCounter].headAttribute->insertLast(head->getLastNode(&head)->blockArr[blockCounter].headAttribute, attribute);
                       added = false;
                   }
                  // attributeNode;
                   i = 0; size = 1;
                   isItAttr = false;
                   delete[] word;
                   word = new char[16];
               }
               else if(letter == '\n' || letter == '\t'){
                   word[--i] = '\0';
               }
               else if(letter == '}' ){ //if end of block
                   word[--i]='\0';
                   sectionCounter++;
                   blockCounter = command.findFirstEmptyBlock(&head);
                   openedSection = false;
               }
               else if(letter == '?'){
                   int questionMarkCounter=0;
                   for(int j=0; j<4; j++){
                       if(word[j]=='?'){
                           questionMarkCounter++;
                       }
                   }
                   if(questionMarkCounter==4){
                       command.clearArray(word, size);
                       i=0; size=1;
                       cssInput=false;
                       commandInput=true;
                       isCom1=true; isCom2=false; isCom3=false;
                   }
                   else
                       questionMarkCounter=0;
               }
           }
           else if (commandInput){
               if(letter == '?' && isCom1){
                   cout << "? == " << command.getCssSectoins(&head) << endl;
                   command.clearArray(word, size); //we clear word array
                   i = 0; size = 1; //set word array variables to initial values
                   isCom1=true;
                   isCom3=false; //change bool to false cause we inserted second command
                   isCom2=false; //change bool cause now we are going to insert third comman
               }
               else if(letter==',' && isCom1){
                   com1 = command.getCom(word, i, size);
                   i = 0; size = 1; //set word array variables to initial values
                   isCom1 = false; //change bool to false cause we inserted first command
                   isCom2 = true; //change bool cause now we are going to insert second command
                   delete[] word; //!!!!!!
                   word = new char[16];
               }
               else if(letter==',' && isCom2){
                   com2 = command.getCom(word, i, size);
                   i = 0; size = 1; //set word array variables to initial values
                   isCom2=false; //change bool to false cause we inserted second command
                   isCom3=true; //change bool cause now we are going to insert third command
                   delete[] word; //!!!!!!
                   word = new char[16];
               }
               else if((letter==' ' || letter=='\n' ) && isCom3){
                   com3 = command.getCom(word, i, size);
                   i = 0; size = 1; //set word array variables to initial values
                   isCom3=false; //change bool to false cause we inserted second command
                   isCom1=false; //change bool cause now we are going to insert third command
                   delete[] word;
                   word = new char[16];
               }
               else if(letter=='*' && isCom1){
                   int starCounter=0;
                   for(int j=0; j<4; j++){
                       if(word[j]=='*'){
                           starCounter++;
                       }
                   }
                   if(starCounter==4){
                       command.clearArray(word, size);
                       i=0; size=1;
                       commandInput=false;
                       cssInput=true;
                       blockCounter = command.findFirstEmptyBlock(&head);
                       if (blockCounter > 7) {
                           blockCounter = 0;
                           delete nodeDDL;
                           nodeDDL = new Node;
                           nodeDDL->addLast(&head, nodeDDL->blockArr);
                       }
                       delete[] word;
                       word = new char[16];
                   }
                   else
                       starCounter=0;
               }
               else if(letter == '\n'){
                   word[--i] = '\0';
                   isCom1=true;
                   isCom2=false;
                   isCom3=false;
               }
               else if(letter == ' ' && (isCom1 == true || isCom2 == true)){
                   delete[] word;
                   word = new char[16];
                   isCom1=true;
                   isCom2=false;
                   isCom3=false;
               }
               else if(letter == '\t'){
                   word[--i] = '\0';
               }
               if(isCom1==false && isCom2==false && isCom3==false){
                   commandFilter(com1, com2, com3, command, &head, sectionCounter);
                   isCom1=true; isCom2=false; isCom3=false;
               }
           }
       }while(letter!=EOF);


    attribute.clear();
    selector.clear();
    delete[] com2;
    delete[] com3;
    delete nodeDDL;
    return 0;
}

