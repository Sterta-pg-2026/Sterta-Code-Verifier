#pragma once

#include "csssection.h"
#include "string.h"
#include "css.h"

class CssParser {
private:
    enum class ParseStage {
        SELECTOR,
        ATTRIBUTE_NAME,
        ATTRIBUTE_VALUE,
        COMMAND
    };

    enum class CommandPart {
        FIRST,
        SECOND,
        THIRD
    };

    Css css;

    ParseStage parseStage;

    CssSection cssSectionBuffer;

    // for selectors stage parse
    String selectorNameBuffer;

    // for attribute name and value stage parse
    String attributeNameBuffer;
    String attributeValueBuffer;

    // for command stage parse
    CommandPart currentCommandPart;
    String commandPart1Buffer;
    String commandPart2Buffer;
    String commandPart3Buffer;

    /// @param newChar Char for parser.
    /// @details Parse selectors stage.
    void selectorsStageParse(char newChar);

    /// @param newChar Char for parser.
    /// @details Parse attribute name stage.
    void attributeNameStageParse(char newChar);

    /// @param newChar Char for parser.
    /// @details Parse attribute value stage.
    void attributeValueStageParse(char newChar);

    /// @param newChar Char for parser.
    /// @details Parse command stage.
    void commandStageParse(char newChar);

    /// @details Execute command from commands buffers.
    void executeCommand();

public:
    CssParser();

    /// @param newChar Char for css parser.
    /// @details Input new char to css parser.
    void pushChar(char newChar);
};
