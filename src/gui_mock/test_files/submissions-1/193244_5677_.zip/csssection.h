#pragma once

#include "string.h"

class CssSection {
private:
    struct Attribute {
        String name;
        String value;
    };

    template<typename T>
    class ListNode {
    public:
        T data;
        ListNode<T> *next;

        explicit ListNode(const T &data);

        ~ListNode();
    };

    ListNode<String> *selectors;
    ListNode<Attribute> *attributes;
    unsigned short int selectorsAmount;
    unsigned short int attributesAmount;

public:
    CssSection();

    /// @details Move css section data from css section indicated by the pointer. After move, clear the
    /// css section indicated by the pointer.
    /// @param cssSectionToMove Pointer to the css section from which the section is to be moved.
    void moveData(CssSection *cssSectionToMove);

    /// @param selectorName Name of selector to add.
    /// @details Add selector with the given name to css section.
    void addSelector(const String &selectorName);

    /// @param attributeName Name of attribute to add.
    /// @param attributeValue Value of attribute to add.
    /// @details Add attribute with the given name and value to css section. If there is already attribute with the
    /// given name in css section, overwrites its value.
    void addAttribute(const String &attributeName, const String &attributeValue);

    /// @return Amount of selectors in css section.
    int getSelectorsAmount() const;

    /// @return Amount of attributes in css section.
    int getAttributesAmount() const;

    /// @param index Index of selector (starting from 0).
    /// @return Selector name with the given index.
    /// @throw std::runtime_error If index out of bound.
    String getSelector(int index) const;

    /// @param attributeName Name of attribute.
    /// @return Value of attribute with the given name.
    /// @throw std::runtime_error If css section does not contain attribute with given name.
    String getAttributeValue(const String &attributeName) const;

    /// @param selectorName Name of searching selector.
    /// @return True if css section contains selector with the given name, false if not.
    bool containsSelector(const String &selectorName) const;

    /// @param attributeName Name of searching attribute.
    /// @return True if css section contains attribute with the given name, false if not.
    bool containsAttribute(const String &attributeName) const;

    /// @param attributeName Name of attribute to remove.
    /// @details Remove attribute with the given name from css section.
    /// @throw std::runtime_error If css section does not contain attribute with given name.
    void removeAttribute(const String &attributeName);

    /// @details Remove all selectors and attributes from css section.
    void clear();

    /// @details Print css section. For develop propose only.
    friend std::ostream &operator<<(std::ostream &os, const CssSection &cssSection);

    ~CssSection();
};
