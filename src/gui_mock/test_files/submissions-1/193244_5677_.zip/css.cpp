#include "css.h"

Css::ListNode::ListNode() {
    for (bool &i: this->occupiedSpace) {
        i = false;
    }
    this->sectionsAmount = 0;
    this->next = nullptr;
    this->previous = nullptr;
}

int Css::ListNode::getSectionsAmount() const {
    return this->sectionsAmount;
}

bool Css::ListNode::canAdd() const {
    return (this->next == nullptr && !this->occupiedSpace[TABLE_SIZE - 1]);
}

void Css::ListNode::addFromBuffer(CssSection *cssSectionToAdd) {
    if (!this->canAdd()) {
        throw std::runtime_error("Cannot add a section to this node's array.");
    }

    // search array index for section
    int lastFreeIndex = TABLE_SIZE - 1;
    for (int i = TABLE_SIZE - 2; i >= 0; i--) {
        if (this->occupiedSpace[i]) {
            break;
        } else {
            lastFreeIndex = i;
        }
    }

    this->data[lastFreeIndex].moveData(cssSectionToAdd);
    this->occupiedSpace[lastFreeIndex] = true;
    this->sectionsAmount++;
}

void Css::ListNode::remove(int index) {
    if (index < 0 || index >= this->sectionsAmount) {
        throw std::runtime_error("Index out of bound.");
    }

    for (int i = 0; i < TABLE_SIZE; i++) {
        if (this->occupiedSpace[i]) {
            index--;

            if (index == -1) {
                this->data[i].clear();
                this->occupiedSpace[i] = false;
                this->sectionsAmount--;
                return;
            }
        }
    }
}

CssSection *Css::ListNode::get(int index) {
    if (index < 0 || index >= this->sectionsAmount) {
        throw std::runtime_error("Index out of bound.");
    }

    for (int i = 0; i < TABLE_SIZE; i++) {
        if (this->occupiedSpace[i]) {
            index--;

            if (index == -1) {
                return &this->data[i];
            }
        }
    }

    // should never throw this
    throw std::runtime_error("Index out of bound.");
}

Css::ListNode::~ListNode() {
    delete this->next;
}

Css::Css() {
    this->firstNode = nullptr;
    this->lastNode = nullptr;
}

CssSection *Css::getSectionPointer(int sectionNumber) {
    int sectionsCounter = sectionNumber;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        sectionsCounter -= currentNode->getSectionsAmount();
        if (sectionsCounter <= 0) {
            return currentNode->get(sectionsCounter + currentNode->getSectionsAmount() - 1);
        }
        currentNode = currentNode->next;
    }

    throw std::runtime_error("Section not found.");
}

void Css::removeNode(ListNode *nodeToRemove) {
    if (this->firstNode == nodeToRemove && this->lastNode == nodeToRemove) {
        // only node in list
        delete this->firstNode;
        this->firstNode = nullptr;
        this->lastNode = nullptr;
    } else if (this->firstNode == nodeToRemove) {
        // first node in list
        ListNode *newFirstNode = nodeToRemove->next;
        nodeToRemove->next = nullptr;
        newFirstNode->previous = nullptr;
        delete nodeToRemove;
        this->firstNode = newFirstNode;
    } else if (this->lastNode == nodeToRemove) {
        // last node in list
        ListNode *newLastNode = nodeToRemove->previous;
        newLastNode->next = nullptr;
        delete nodeToRemove;
        this->lastNode = newLastNode;
    } else {
        // middle node in list
        ListNode *tmpPrevious = nodeToRemove->previous;
        ListNode *tmpNext = nodeToRemove->next;
        nodeToRemove->next = nullptr;
        delete nodeToRemove;
        tmpPrevious->next = tmpNext;
        tmpNext->previous = tmpPrevious;
    }
}

void Css::addSectionFromBuffer(CssSection *cssSection) {
    if (this->firstNode == nullptr) {
        // first css section
        this->firstNode = new ListNode();
        this->lastNode = this->firstNode;
        this->firstNode->addFromBuffer(cssSection);
        return;
    }

    if (this->lastNode->canAdd()) {
        // add to last node
        this->lastNode->addFromBuffer(cssSection);
    } else {
        // crate new last node and add
        ListNode *newNode = new ListNode();
        newNode->previous = this->lastNode;
        this->lastNode->next = newNode;
        this->lastNode = newNode;
        newNode->addFromBuffer(cssSection);
    }
}

void Css::printSectionsAmount() const {
    int sectionAmount = 0;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        sectionAmount += currentNode->getSectionsAmount();
        currentNode = currentNode->next;
    }

    std::cout << "? == " << sectionAmount << std::endl;
}

void Css::printSelectorsAmountInSection(int sectionNumber) {
    try {
        CssSection *cssSection = this->getSectionPointer(sectionNumber);
        std::cout << sectionNumber << ",S,? == " << cssSection->getSelectorsAmount() << std::endl;
    }
    catch (const std::runtime_error &) {
        // do noting on error
    }
}

void Css::printAttributesAmountInSection(int sectionNumber) {
    try {
        CssSection *cssSection = this->getSectionPointer(sectionNumber);
        std::cout << sectionNumber << ",A,? == " << cssSection->getAttributesAmount() << std::endl;
    }
    catch (const std::runtime_error &) {
        // do noting on error
    }
}

void Css::printSelector(int sectionNumber, int selectorNumber) {
    try {
        String selector = this->getSectionPointer(sectionNumber)->getSelector(selectorNumber - 1);
        std::cout << sectionNumber << ",S," << selectorNumber << " == " << selector << std::endl;
    } catch (const std::runtime_error &) {
        // do noting on error
    }
}

void Css::printAttributeValue(int sectionNumber, const String &attributeName) {
    try {
        String attributeValue = this->getSectionPointer(sectionNumber)->getAttributeValue(attributeName);
        std::cout << sectionNumber << ",A," << attributeName << " == " << attributeValue << std::endl;
    } catch (const std::runtime_error &) {
        // do noting on error
    }
}

void Css::printAttributeAmount(const String &attributeName) const {
    int attributeAmounts = 0;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        for (int i = 0; i < currentNode->getSectionsAmount(); i++) {
            if (currentNode->get(i)->containsAttribute(attributeName)) {
                attributeAmounts++;
            }
        }
        currentNode = currentNode->next;
    }

    std::cout << attributeName << ",A,? == " << attributeAmounts << std::endl;
}

void Css::printSelectorAmount(const String &selectorName) const {
    int selectorAmounts = 0;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        for (int i = 0; i < currentNode->getSectionsAmount(); i++) {
            if (currentNode->get(i)->containsSelector(selectorName)) {
                selectorAmounts++;
            }
        }
        currentNode = currentNode->next;
    }

    std::cout << selectorName << ",S,? == " << selectorAmounts << std::endl;
}

void Css::printAttributeValueForSelector(const String &selectorName, const String &attributeName) const {
    ListNode *currentNode = this->lastNode;

    while (currentNode != nullptr) {
        for (int i = currentNode->getSectionsAmount() - 1; i >= 0; i--) {
            CssSection *currentSection = currentNode->get(i);
            if (currentSection->containsSelector(selectorName) && currentSection->containsAttribute(attributeName)) {
                String attributeValue = currentSection->getAttributeValue(attributeName);
                std::cout << selectorName << ",E," << attributeName << " == " << attributeValue << std::endl;
                return;
            }
        }
        currentNode = currentNode->previous;
    }
}

void Css::deleteSection(int sectionNumber) {
    int sectionsCounter = sectionNumber;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        sectionsCounter -= currentNode->getSectionsAmount();
        if (sectionsCounter <= 0) {
            currentNode->remove(sectionsCounter + currentNode->getSectionsAmount() - 1);
            std::cout << sectionNumber << ",D,* == deleted" << std::endl;

            if (currentNode->getSectionsAmount() == 0) {
                // remove list node if is empty after css section remove
                this->removeNode(currentNode);
            }

            return;
        }
        currentNode = currentNode->next;
    }
}

void Css::deleteAttributeFromSection(int sectionNumber, const String &attributeName) {
    int sectionsCounter = sectionNumber;

    ListNode *currentNode = this->firstNode;
    while (currentNode != nullptr) {
        sectionsCounter -= currentNode->getSectionsAmount();
        if (sectionsCounter <= 0) {
            CssSection *currentSection = currentNode->get(sectionsCounter + currentNode->getSectionsAmount() - 1);

            try {
                currentSection->removeAttribute(attributeName);
                std::cout << sectionNumber << ",D," << attributeName << " == deleted" << std::endl;

                if (currentSection->getAttributesAmount() == 0) {
                    // remove css section if it contains no attributes after attribute remove
                    currentNode->remove(sectionsCounter + currentNode->getSectionsAmount() - 1);

                    if (currentNode->getSectionsAmount() == 0) {
                        // remove list node if is empty after css section remove
                        this->removeNode(currentNode);
                    }
                }
            } catch (const std::runtime_error &) {
                // do noting on error
            }

            return;
        }
        currentNode = currentNode->next;
    }
}

std::ostream &operator<<(std::ostream &os, const Css &css) {
    int sectionAmount = 0;
    Css::ListNode *currentNode = css.firstNode;
    while (currentNode != nullptr) {
        sectionAmount += currentNode->getSectionsAmount();
        currentNode = currentNode->next;
    }

    os << "Css(" << sectionAmount << "){" << std::endl;

    int nodeIndex = 0;
    currentNode = css.firstNode;
    while (currentNode != nullptr) {
        for (int i = 0; i < currentNode->getSectionsAmount(); i++) {
            os << "[n:" << nodeIndex << "|t:" << i << "] " << *currentNode->get(i) << std::endl;
        }
        nodeIndex++;
        currentNode = currentNode->next;
    }

    os << "}" << std::endl;

    return os;
}

Css::~Css() {
    delete this->firstNode;
}
