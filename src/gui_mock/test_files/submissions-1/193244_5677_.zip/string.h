# pragma once

#include <iostream>

class String {
private:
    static constexpr unsigned short int ARRAY_SEGMENT_SIZE = 16;

    char *chars;
    unsigned short int maxSize;
    unsigned short int size;

    /// @param charToPush Char to add.
    /// @details Add new char at the end of string.
    void push(char charToPush);

    /// @details Remove last char from string.
    void removeLastChar();

public:
    String();

    /// @details Copy constrictor.
    String(const String &stringToCopy);

    /// @details Check if string is empty.
    /// @return True if string is empty, false if not.
    bool isEmpty() const;

    /// @details Check if string is numeric.
    /// @return True if string is numeric, false if not (including empty string).
    bool isNumeric() const;

    /// @return Integer value of string or -1 if string is not numeric.
    int getIntVal() const;

    /// @details Remove all whitespace from end of string.
    void trim();

    /// @details Remove all chars from string.
    void clear();

    /// @details Print string.
    friend std::ostream &operator<<(std::ostream &os, const String &string);

    /// @details Copy assignment operator.
    String &operator=(const String &stringToCopy);

    /// @details Deep comparison between strings.
    /// @return True if both strings are the same.
    bool operator==(const String &stringToCompare) const;

    /// @details Comparison string and array of chars.
    /// @return True if array of char is the same as string.
    bool operator==(const char *charsToCompare) const;

    /// @details Add new char at the end of string.
    String &operator+=(char charToAdd);

    ~String();
};
