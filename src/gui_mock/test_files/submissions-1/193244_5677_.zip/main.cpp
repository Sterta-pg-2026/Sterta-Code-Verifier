#include <iostream>
#include "cssparser.h"

int main() {
    CssParser cssParser;

    while (true) {
        int charBuffer = getchar();

        if (charBuffer == EOF) {
            // force one more char after end of file
            cssParser.pushChar('\n');
            break;
        }

        cssParser.pushChar((char) charBuffer);
    }

    return 0;
}
