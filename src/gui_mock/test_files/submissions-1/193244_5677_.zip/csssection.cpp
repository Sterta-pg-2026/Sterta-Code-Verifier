#include "csssection.h"

template<typename T>
CssSection::ListNode<T>::ListNode(const T &data) {
    this->data = data;
    this->next = nullptr;
}

template<typename T>
CssSection::ListNode<T>::~ListNode() {
    delete this->next;
}

CssSection::CssSection() {
    this->attributes = nullptr;
    this->selectors = nullptr;
    this->selectorsAmount = 0;
    this->attributesAmount = 0;
}

void CssSection::moveData(CssSection *cssSectionToMove) {
    this->selectors = cssSectionToMove->selectors;
    cssSectionToMove->selectors = nullptr;

    this->attributes = cssSectionToMove->attributes;
    cssSectionToMove->attributes = nullptr;

    this->attributesAmount = cssSectionToMove->attributesAmount;
    cssSectionToMove->attributesAmount = 0;

    this->selectorsAmount = cssSectionToMove->selectorsAmount;
    cssSectionToMove->selectorsAmount = 0;
}

void CssSection::addSelector(const String &selectorName) {
    this->selectorsAmount++;

    if (this->selectors == nullptr) {
        // add first selector
        this->selectors = new ListNode<String>(selectorName);
        return;
    }

    ListNode<String> *currentSelector = this->selectors;
    while (currentSelector->next != nullptr) {
        currentSelector = currentSelector->next;
    }

    currentSelector->next = new ListNode<String>(selectorName);
}

void CssSection::addAttribute(const String &attributeName, const String &attributeValue) {
    Attribute newAttribute;
    newAttribute.name = attributeName;
    newAttribute.value = attributeValue;

    if (this->attributes == nullptr) {
        // add first attribute
        this->attributes = new ListNode<Attribute>(newAttribute);
        this->attributesAmount++;
        return;
    }

    ListNode<Attribute> *currentAttribute = this->attributes;
    while (currentAttribute->next != nullptr) {
        if (currentAttribute->data.name == attributeName) {
            // overwrite existing attribute
            currentAttribute->data.value = attributeValue;
            return;
        }
        currentAttribute = currentAttribute->next;
    }

    if (currentAttribute->data.name == attributeName) {
        // overwrite existing attribute which is at the end of list
        currentAttribute->data.value = attributeValue;
        return;
    }

    currentAttribute->next = new ListNode<Attribute>(newAttribute);
    this->attributesAmount++;
}

int CssSection::getSelectorsAmount() const {
    return this->selectorsAmount;
}

int CssSection::getAttributesAmount() const {
    return this->attributesAmount;
}

String CssSection::getSelector(int index) const {
    if (index < 0 || index >= this->selectorsAmount) {
        throw std::runtime_error("Index out of bound.");
    }

    ListNode<String> *currentSelector = this->selectors;
    for (int i = 0; i < index; i++) {
        currentSelector = currentSelector->next;
    }

    return currentSelector->data;
}

String CssSection::getAttributeValue(const String &attributeName) const {
    ListNode<Attribute> *currentAttribute = this->attributes;

    while (currentAttribute != nullptr) {
        if (currentAttribute->data.name == attributeName) {
            return currentAttribute->data.value;
        }
        currentAttribute = currentAttribute->next;
    }

    throw std::runtime_error("Attribute not found.");
}

bool CssSection::containsSelector(const String &selectorName) const {
    ListNode<String> *currentSelector = this->selectors;

    while (currentSelector != nullptr) {
        if (currentSelector->data == selectorName) {
            return true;
        }
        currentSelector = currentSelector->next;
    }

    return false;
}

bool CssSection::containsAttribute(const String &attributeName) const {
    ListNode<Attribute> *currentAttribute = this->attributes;

    while (currentAttribute != nullptr) {
        if (currentAttribute->data.name == attributeName) {
            return true;
        }
        currentAttribute = currentAttribute->next;
    }

    return false;
}

void CssSection::removeAttribute(const String &attributeName) {
    if (this->attributes == nullptr) {
        // nothing to remove
        throw std::runtime_error("Attribute not found.");
    }

    if (this->attributes->data.name == attributeName) {
        // remove first attribute from list
        ListNode<Attribute> *tmp = this->attributes->next;
        this->attributes->next = nullptr;
        delete this->attributes;
        this->attributes = tmp;
        this->attributesAmount--;
        return;
    }

    ListNode<Attribute> *currentAttribute = this->attributes;
    while (currentAttribute->next != nullptr) {
        if (currentAttribute->next->data.name == attributeName) {
            if (currentAttribute->next->next == nullptr) {
                // remove last attribute from list
                delete currentAttribute->next;
                currentAttribute->next = nullptr;
            } else {
                // remove middle attribute from list
                ListNode<Attribute> *tmp = currentAttribute->next->next;
                currentAttribute->next->next = nullptr;
                delete currentAttribute->next;
                currentAttribute->next = tmp;
            }
            this->attributesAmount--;
            return;
        }
        currentAttribute = currentAttribute->next;
    }

    throw std::runtime_error("Attribute not found.");
}

void CssSection::clear() {
    delete this->attributes;
    delete this->selectors;
    this->attributes = nullptr;
    this->selectors = nullptr;
    this->selectorsAmount = 0;
    this->attributesAmount = 0;
}

std::ostream &operator<<(std::ostream &os, const CssSection &cssSection) {
    os << "CssSection{selectors(" << cssSection.getSelectorsAmount() << "): [";

    CssSection::ListNode<String> *currentSelector = cssSection.selectors;
    while (currentSelector != nullptr) {
        os << currentSelector->data;
        currentSelector = currentSelector->next;
        if (currentSelector != nullptr) {
            os << ", ";
        }
    }

    os << "], attributes(" << cssSection.getAttributesAmount() << "): [";

    CssSection::ListNode<CssSection::Attribute> *currentAttribute = cssSection.attributes;
    while (currentAttribute != nullptr) {
        os << currentAttribute->data.name << ":|" << currentAttribute->data.value << "|";
        currentAttribute = currentAttribute->next;
        if (currentAttribute != nullptr) {
            os << ", ";
        }
    }

    os << "]}";

    return os;
}

CssSection::~CssSection() {
    delete this->attributes;
    delete this->selectors;
}
