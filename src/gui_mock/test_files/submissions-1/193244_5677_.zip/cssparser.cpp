#include "cssparser.h"

CssParser::CssParser() {
    this->parseStage = ParseStage::SELECTOR;
    this->currentCommandPart = CommandPart::FIRST;
}

void CssParser::pushChar(char newChar) {
    // ignore tab and carriage return char
    if (newChar == '\t' || newChar == '\r') {
        return;
    }

    switch (this->parseStage) {
        case ParseStage::SELECTOR:
            this->selectorsStageParse(newChar);
            break;
        case ParseStage::ATTRIBUTE_NAME:
            this->attributeNameStageParse(newChar);
            break;
        case ParseStage::ATTRIBUTE_VALUE:
            this->attributeValueStageParse(newChar);
            break;
        case ParseStage::COMMAND:
            this->commandStageParse(newChar);
            break;
    }
}

void CssParser::selectorsStageParse(char newChar) {
    if (newChar == '\n') {
        this->selectorNameBuffer.trim();
        if (this->selectorNameBuffer == "????") {
            this->selectorNameBuffer.clear();
            this->parseStage = ParseStage::COMMAND;
        }
    } else if (newChar == '{') {
        this->selectorNameBuffer.trim();
        if (!this->selectorNameBuffer.isEmpty()) {
            this->cssSectionBuffer.addSelector(this->selectorNameBuffer);
            this->selectorNameBuffer.clear();
        }
        this->parseStage = ParseStage::ATTRIBUTE_NAME;
    } else if (newChar == ',') {
        this->cssSectionBuffer.addSelector(this->selectorNameBuffer);
        this->selectorNameBuffer.clear();
    } else if (newChar != ' ' || !this->selectorNameBuffer.isEmpty()) {
        this->selectorNameBuffer += newChar;
    }
}

void CssParser::attributeNameStageParse(char newChar) {
    if (newChar == ':') {
        this->parseStage = ParseStage::ATTRIBUTE_VALUE;
    } else if (newChar == '}') {
        this->attributeNameBuffer.clear();
        this->attributeValueBuffer.clear();
        this->css.addSectionFromBuffer(&this->cssSectionBuffer);
        this->parseStage = ParseStage::SELECTOR;
    } else if (newChar != '\n' && (newChar != ' ' || !this->attributeNameBuffer.isEmpty())) {
        this->attributeNameBuffer += newChar;
    }
}

void CssParser::attributeValueStageParse(char newChar) {
    if (newChar == ';') {
        this->cssSectionBuffer.addAttribute(this->attributeNameBuffer, this->attributeValueBuffer);
        this->attributeNameBuffer.clear();
        this->attributeValueBuffer.clear();
        this->parseStage = ParseStage::ATTRIBUTE_NAME;
    } else if (newChar == '}') {
        this->cssSectionBuffer.addAttribute(this->attributeNameBuffer, this->attributeValueBuffer);
        this->attributeNameBuffer.clear();
        this->attributeValueBuffer.clear();
        this->css.addSectionFromBuffer(&this->cssSectionBuffer);
        this->parseStage = ParseStage::SELECTOR;
    } else if (newChar != '\n' && (newChar != ' ' || !this->attributeValueBuffer.isEmpty())) {
        this->attributeValueBuffer += newChar;
    }
}

void CssParser::commandStageParse(char newChar) {
    if (newChar == '\n') {
        if (this->commandPart1Buffer == "****") {
            this->commandPart1Buffer.clear();
            this->parseStage = ParseStage::SELECTOR;
        } else {
            this->executeCommand();
            this->commandPart1Buffer.clear();
            this->commandPart2Buffer.clear();
            this->commandPart3Buffer.clear();
        }
        this->currentCommandPart = CommandPart::FIRST;
    } else if (newChar == ',') {
        if (this->currentCommandPart == CommandPart::FIRST) {
            this->currentCommandPart = CommandPart::SECOND;
        } else if (this->currentCommandPart == CommandPart::SECOND) {
            this->currentCommandPart = CommandPart::THIRD;
        }
    } else {
        if (this->currentCommandPart == CommandPart::FIRST) {
            this->commandPart1Buffer += newChar;
        } else if (this->currentCommandPart == CommandPart::SECOND) {
            this->commandPart2Buffer += newChar;
        } else if (this->currentCommandPart == CommandPart::THIRD) {
            this->commandPart3Buffer += newChar;
        }
    }
}

void CssParser::executeCommand() {
    if (this->commandPart1Buffer == "?" && this->commandPart2Buffer.isEmpty() && this->commandPart3Buffer.isEmpty()) {
        this->css.printSectionsAmount();
    } else if (this->commandPart2Buffer == "E") {
        this->css.printAttributeValueForSelector(this->commandPart1Buffer, this->commandPart3Buffer);
    } else if (this->commandPart2Buffer == "D") {
        if (this->commandPart3Buffer == "*") {
            this->css.deleteSection(this->commandPart1Buffer.getIntVal());
        } else {
            this->css.deleteAttributeFromSection(this->commandPart1Buffer.getIntVal(), this->commandPart3Buffer);
        }
    } else if (this->commandPart2Buffer == "S") {
        if (this->commandPart3Buffer == "?") {
            if (this->commandPart1Buffer.isNumeric()) {
                this->css.printSelectorsAmountInSection(this->commandPart1Buffer.getIntVal());
            } else {
                this->css.printSelectorAmount(this->commandPart1Buffer);
            }
        } else {
            this->css.printSelector(this->commandPart1Buffer.getIntVal(), this->commandPart3Buffer.getIntVal());
        }
    } else if (this->commandPart2Buffer == "A") {
        if (this->commandPart3Buffer == "?") {
            if (this->commandPart1Buffer.isNumeric()) {
                this->css.printAttributesAmountInSection(this->commandPart1Buffer.getIntVal());
            } else {
                this->css.printAttributeAmount(this->commandPart1Buffer);
            }
        } else {
            this->css.printAttributeValue(this->commandPart1Buffer.getIntVal(), this->commandPart3Buffer);
        }
    }
}
