#pragma once

#include "csssection.h"

class Css {
private:
    class ListNode {
    private:
        static constexpr unsigned short int TABLE_SIZE = 8;

        CssSection data[TABLE_SIZE];
        unsigned short int sectionsAmount;
        bool occupiedSpace[TABLE_SIZE];

    public:
        ListNode *next;
        ListNode *previous;

        ListNode();

        /// @return Amount of css sections in node.
        int getSectionsAmount() const;

        /// @return True if there is free space in node's array to add css section, and this node is the
        /// last node of the sections list.
        bool canAdd() const;

        /// @details Add css section from buffer to node array. After adding, clear the buffer.
        /// @param cssSectionToAdd Pointer to the buffer from which the section is to be added.
        /// @throw std::runtime_error If there is no free space in node's array to add section, or this
        /// node is not the last node of the sections list.
        void addFromBuffer(CssSection *cssSectionToAdd);

        /// @details Remove css section with given index from node array.
        /// @param index Index of css section to remove (starting from 0).
        /// @throw std::runtime_error If index is out of bound.
        void remove(int index);

        /// @param index Index of css section (starting from 0).
        /// @return Pointer to css section.
        /// @throw std::runtime_error If index is out of bound.
        CssSection *get(int index);

        ~ListNode();
    };

    ListNode *firstNode;
    ListNode *lastNode;

    /// @param sectionNumber Number of css section (starting from 1).
    /// @return Pointer to css section.
    /// @throw std::runtime_error If section with given number was not found.
    CssSection *getSectionPointer(int sectionNumber);

    /// @param nodeToRemove Pointer of node to remove.
    /// @details Remove node from list.
    void removeNode(ListNode *nodeToRemove);

public:
    Css();

    /// @param cssSection Pointer to the buffer from which the section is to be added.
    /// @details Add section from buffer to list. After adding, clear the buffer.
    void addSectionFromBuffer(CssSection *cssSection);

    /// @details command: ?
    /// @details Print number of sections.
    void printSectionsAmount() const;

    /// @param sectionNumber Number of css section (starting from 1).
    /// @details command: i,S,?
    /// @details Print number of selectors for section i-th. Do nothing if there is no such section.
    void printSelectorsAmountInSection(int sectionNumber);

    /// @param sectionNumber Number of css section (starting from 1).
    /// @details command: i,A,?
    /// @details Print number of attributes for section i-th. Do nothing if there is no such section.
    void printAttributesAmountInSection(int sectionNumber);

    /// @param sectionNumber Number of css section (starting from 1).
    /// @param selectorNumber Number of css section's selector (starting from 1).
    /// @details command: i,S,j
    /// @details Print j-th selector of i-th section. Do nothing if there is no such section or selector.
    void printSelector(int sectionNumber, int selectorNumber);

    /// @param sectionNumber Number of css section (starting from 1).
    /// @param attributeName Name of searching attribute.
    /// @details command: i,A,n
    /// @details Print value of attribute named 'n' of i-th section. Do nothing if there is no such
    /// attribute or section.
    void printAttributeValue(int sectionNumber, const String &attributeName);

    /// @param attributeName Name of searching attribute.
    /// @details command: n,A,?
    /// @details Print total (for all section) number of occurrences of attribute named 'n'.
    void printAttributeAmount(const String &attributeName) const;

    /// @param selectorName Name of searching selector.
    /// @details command: z,S,?
    /// @details Print total (for all section) number of occurrences of selector named 'z'.
    void printSelectorAmount(const String &selectorName) const;

    /// @param selectorName Name of searching selector.
    /// @param attributeName Name of searching attribute.
    /// @details command: z,E,n
    /// @details Print value of attribute named 'n' for the selector named 'z'. If there are multiple occurrences
    /// of the selector print last.  Do nothing if there is no such selector or attribute.
    void printAttributeValueForSelector(const String &selectorName, const String &attributeName) const;

    /// @param sectionNumber Number of css section (starting from 1).
    /// @details command: i,D,*
    /// @details Remove entire i-th section. After success print 'deleted'.
    void deleteSection(int sectionNumber);

    /// @param sectionNumber Number of css section (starting from 1).
    /// @param attributeName Name of attribute to remove.
    /// @details command: i,D,n
    /// @details Remove attribute named 'n' from i-th section. If after remove section will be empty, remove whole
    /// section. After success print 'deleted'.
    void deleteAttributeFromSection(int sectionNumber, const String &attributeName);

    /// @details Print whole css. For develop propose only.
    friend std::ostream &operator<<(std::ostream &os, const Css &css);

    ~Css();
};
