#include "string.h"

String::String() {
    this->chars = (char *) malloc(sizeof(char) * String::ARRAY_SEGMENT_SIZE);
    this->size = 0;
    this->maxSize = String::ARRAY_SEGMENT_SIZE;
}

String::String(const String &stringToCopy) {
    // calculate needed amount of table segments
    unsigned short int arraySegmentsToAllocate = stringToCopy.size / String::ARRAY_SEGMENT_SIZE;
    if (stringToCopy.size % String::ARRAY_SEGMENT_SIZE != 0) {
        arraySegmentsToAllocate++;
    }

    this->chars = (char *) malloc(sizeof(char) * (arraySegmentsToAllocate * String::ARRAY_SEGMENT_SIZE));
    this->size = stringToCopy.size;
    this->maxSize = arraySegmentsToAllocate * String::ARRAY_SEGMENT_SIZE;

    for (int i = 0; i < this->size; i++) {
        this->chars[i] = stringToCopy.chars[i];
    }
}

void String::push(char charToPush) {
    if (this->size == this->maxSize) {
        // relocate chars array
        this->chars = (char *) realloc(this->chars, sizeof(char) * (this->maxSize + String::ARRAY_SEGMENT_SIZE));
        this->maxSize += String::ARRAY_SEGMENT_SIZE;
    }

    this->chars[this->size] = charToPush;
    this->size++;
}

void String::removeLastChar() {
    this->size--;
}

bool String::isEmpty() const {
    return this->size == 0;
}

bool String::isNumeric() const {
    if (this->size == 0) {
        // nothing to check
        return false;
    }

    for (int i = 0; i < this->size; i++) {
        if (this->chars[i] < '0' || this->chars[i] > '9') {
            // some char is not numeric
            return false;
        }
    }

    return true;
}

int String::getIntVal() const {
    if (this->size == 0) {
        // nothing to convert
        return -1;
    }

    int intValue = 0;

    for (int i = 0; i < this->size; i++) {
        if (this->chars[i] < '0' || this->chars[i] > '9') {
            // some char is not numeric
            return -1;
        }

        intValue *= 10;
        intValue += (this->chars[i] - 48);
    }

    return intValue;
}

void String::trim() {
    if (this->size == 0) {
        // nothing to trim
        return;
    }

    // trim end of string
    while (this->size != 0 && this->chars[this->size - 1] == ' ') {
        this->removeLastChar();
    }
}

void String::clear() {
    this->size = 0;
}

std::ostream &operator<<(std::ostream &os, const String &string) {
    for (int i = 0; i < string.size; i++) {
        os << string.chars[i];
    }

    return os;
}

String &String::operator=(const String &stringToCopy) {
    if (this == &stringToCopy) {
        // anti self-assigned
        return *this;
    }

    // calculate needed amount of table segments
    unsigned short int arraySegmentsToAllocate = stringToCopy.size / String::ARRAY_SEGMENT_SIZE;
    if (stringToCopy.size % String::ARRAY_SEGMENT_SIZE != 0) {
        arraySegmentsToAllocate++;
    }

    if (this->maxSize < arraySegmentsToAllocate * String::ARRAY_SEGMENT_SIZE) {
        // relocate chars array
        this->chars = (char *) realloc(
                this->chars,
                sizeof(char) * (arraySegmentsToAllocate * String::ARRAY_SEGMENT_SIZE)
        );
    }

    this->size = stringToCopy.size;
    this->maxSize = arraySegmentsToAllocate * String::ARRAY_SEGMENT_SIZE;

    for (int i = 0; i < this->size; i++) {
        this->chars[i] = stringToCopy.chars[i];
    }

    return *this;
}

bool String::operator==(const String &stringToCompare) const {
    if (this->size != stringToCompare.size) {
        // strings sizes are different
        return false;
    }

    for (int i = 0; i < this->size; i++) {
        if (this->chars[i] != stringToCompare.chars[i]) {
            // some char is different
            return false;
        }
    }

    return true;
}

bool String::operator==(const char *charsToCompare) const {
    for (int i = 0; i < this->size; i++) {
        if (*charsToCompare == '\0' || this->chars[i] != *charsToCompare) {
            // size of char's array is less then size of string or some char is different
            return false;
        }
        charsToCompare++;
    }

    if (*charsToCompare == '\0') {
        return true;
    } else {
        // size of char's array is greater then size of string
        return false;
    }
}

String &String::operator+=(char charToAdd) {
    this->push(charToAdd);
    return *this;
}

String::~String() {
    free(this->chars);
}
