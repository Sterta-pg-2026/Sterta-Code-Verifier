#include <iostream>
#include <limits>
#include <cstring>
#include <cassert>
#include <cctype>

template <typename T>
class myvector
{
	T* m_Ptr          = nullptr;
	size_t m_Size     = 0;
	size_t m_Capacity = 0;
public:
	myvector() = default;

	myvector(myvector&& right) { *this = static_cast<myvector&&>(right); }

	myvector(const myvector& right) { *this = right; }

	myvector& operator=(myvector&& right)
	{
		delete[] m_Ptr;

		m_Ptr            = right.m_Ptr;
		right.m_Ptr      = nullptr;
		m_Size           = right.m_Size;
		right.m_Size     = 0;
		m_Capacity       = right.m_Capacity;
		right.m_Capacity = 0;
		return *this;
	}

	myvector& operator=(const myvector& right)
	{
		delete[] m_Ptr;

		m_Size     = right.size();
		m_Capacity = m_Size;
		m_Ptr      = new T[m_Capacity];

		copy_from(right.begin(), right.size());
		return *this;
	}

	template <size_t N>
	explicit myvector(const T (&arr)[N])
	{
		resize(N);
		copy_from(arr, N);
	}

	myvector(size_t size, const T& value) { resize(size, value); }

	~myvector() { delete[] m_Ptr; }

	void clear() { m_Size = 0; }

	void resize(size_t size, const T& value = T())
	{
		assert(m_Size <= m_Capacity);
		if (size <= m_Size)
		{
			m_Size = size;
		}
		else if (m_Capacity >= size)
		{
			for (T* ptr = m_Ptr + m_Size; ptr != m_Ptr + size; ++ptr)
				*ptr = value;
			m_Size = size;
		}
		else
		{
			T* newPtr = new T[size];
			T* dst    = newPtr;
			T* src    = m_Ptr;
			while (src != m_Ptr + m_Size)
				*dst++ = *src++;
			while (dst != newPtr + size)
				*dst++ = value;
			delete[] m_Ptr;
			m_Ptr      = newPtr;
			m_Size     = size;
			m_Capacity = size;
		}
	}

	void reserve(size_t capacity)
	{
		assert(m_Size <= m_Capacity);
		if (capacity > m_Capacity)
		{
			T* newPtr = new T[capacity];
			T* dst    = newPtr;
			T* src    = m_Ptr;
			while (src != m_Ptr + m_Size)
				*dst++ = *src++;
			delete[] m_Ptr;
			m_Ptr      = newPtr;
			m_Capacity = capacity;
		}
	}

	void fill(const T& value)
	{
		assert(m_Size <= m_Capacity);
		for (T* ptr = m_Ptr; ptr != m_Ptr + m_Size; ++ptr)
			*ptr = value;
	}

	void copy_from(const T* src, size_t count)
	{
		T* dst             = begin();
		const T* const end = src + count;
		while (src != end)
			*dst++ = *src++;
	}

	void push_back(const T& value)
	{
		if (m_Size == m_Capacity)
			reserve(m_Size * 2);
		resize(m_Size + 1, value);
	}

	void pop_back()
	{
		assert(m_Size > 0);
		resize(m_Size - 1);
	}

	void shift_left(size_t count) { copy_from(begin() + count, size() - count); }

	void shift_right(size_t count)
	{
		if (count > 0)
		{
			T* dst = end();
			T* src = end() - count;
			while (dst != begin() + count)
				*--dst = *--src;
		}
	}

	void push_front(const T& value)
	{
		push_back(T());

		shift_right(1);

		*begin() = value;
	}

	void pop_front()
	{
		assert(m_Size > 0);

		shift_left(1);

		pop_back();
	}

	void erase(size_t index)
	{
		T* dst       = begin() + index;
		const T* src = begin() + index + 1;
		while (src != end())
			*dst++ = *src++;

		m_Size -= 1;
	}

	T& operator[](size_t index)
	{
		assert(index < m_Size);
		return m_Ptr[index];
	}
	const T& operator[](size_t index) const
	{
		assert(index < m_Size);
		return m_Ptr[index];
	}

	T* begin() { return m_Ptr; }
	T* end() { return m_Ptr + m_Size; }
	const T* begin() const { return m_Ptr; }
	const T* end() const { return m_Ptr + m_Size; }

	T& front()
	{
		assert(!empty());
		return m_Ptr[0];
	}

	const T& front() const
	{
		assert(!empty());
		return m_Ptr[0];
	}

	T& back()
	{
		assert(!empty());
		return m_Ptr[m_Size - 1];
	}

	const T& back() const
	{
		assert(!empty());
		return m_Ptr[m_Size - 1];
	}

	size_t size() const { return m_Size; }
	size_t capacity() const { return m_Capacity; }
	bool empty() const { return m_Size == 0; }

	bool operator==(const myvector& right) const
	{
		if (size() != right.size())
			return false;

		const T* leftIt  = begin();
		const T* rightIt = right.begin();

		while (leftIt != end())
			if (*leftIt++ != *rightIt++)
				return false;

		return true;
	}

	bool operator!=(const myvector& right) const { return !(*this == right); }

	template <typename F>
	T* find_if(F&& f)
	{
		T* it = begin();
		T* e  = end();
		for (; it != e; ++it)
		{
			if (f(*it))
				return it;
		}
		return e;
	}
};

class mystring
{
	myvector<char> m_Vector = { 1, '\0' };
public:
	mystring() = default;

	mystring(const char* str)
	{
		m_Vector.resize(strlen(str) + 1);
		memcpy(m_Vector.begin(), str, m_Vector.size());
	}

	void resize(size_t size)
	{
		m_Vector.resize(size + 1, '\0');
		m_Vector[m_Vector.size() - 1] = '\0';
	}

	void push_back(char c)
	{
		m_Vector[m_Vector.size() - 1] = c;
		m_Vector.push_back('\0');
	}

	void pop_back()
	{
		m_Vector.pop_back();
		m_Vector[m_Vector.size() - 1] = '\0';
	}

	void clear() { resize(0); }

	size_t size() const { return m_Vector.size() - 1; }
	bool empty() const { return size() == 0; }
	const char* c_str() const { return m_Vector.begin(); }
	char* data() { return m_Vector.begin(); }
	const char* data() const { return m_Vector.begin(); }

	char& front() { return m_Vector.front(); }
	const char& front() const { return m_Vector.front(); }
	char& back() { return m_Vector[size() - 1]; }
	const char& back() const { return m_Vector[size() - 1]; }

	void push_back_normalize(char c)
	{
		if (!isspace(c))
			push_back(c);
		else if (!empty() && !isspace(back()))
			push_back(' ');
	}

	void strip_trailing_whitespace()
	{
		if (!empty() && isspace(back()))
			pop_back();
	}

	bool operator==(const mystring& right) const { return m_Vector == right.m_Vector; }

	bool operator!=(const mystring& right) const { return !(*this == right); }

	friend std::ostream& operator<<(std::ostream& out, const mystring& str) { return out << str.c_str(); }
};

template <typename T, size_t NodeSize = 17>
class mylist
{
	struct node
	{
		node* next;
		node* prev;
		struct
		{
			T elem;
			bool exists = false;
		} elems[NodeSize];
		size_t count         = 0;
		size_t insertedCount = 0;
	};

	struct iterator
	{
		node* n      = nullptr;
		size_t index = 0;

		T& operator*() const
		{
			assert(valid());
			return n->elems[index].elem;
		}

		T* operator->() const
		{
			assert(valid());
			return &n->elems[index].elem;
		}

		bool valid() const { return n && n->elems[index].exists; }

		bool increment_helper()
		{
			assert(n);
			assert(index < NodeSize);
			++index;
			if (index == NodeSize)
			{
				if (n->next)
				{
					n     = n->next;
					index = 0;
				}
				else
					return false;
			}
			return true;
		}

		iterator& operator++()
		{
			while (increment_helper() && !valid())
				;
			return *this;
		}

		iterator operator++(int)
		{
			iterator temp = *this;
			++*this;
			return temp;
		}

		void decrement_helper()
		{
			assert(n);
			if (index == 0)
			{
				n     = n->prev;
				index = NodeSize;
			}
			--index;
		}

		iterator& operator--()
		{
			do
			{
				decrement_helper();
			} while (!valid());
			return *this;
		}

		iterator operator--(int)
		{
			iterator temp = *this;
			--*this;
			return temp;
		}

		bool operator==(const iterator& right) const { return n == right.n && index == right.index; }

		bool operator!=(const iterator& right) const { return !(*this == right); }
	};

	node* head = nullptr;
	node* tail = nullptr;
public:
	mylist() = default;

	mylist(mylist&& right) noexcept
		: head(right.head), tail(right.tail)
	{
		right.head = nullptr;
		right.tail = nullptr;
	}

	mylist(const mylist&) = delete;

	mylist& operator=(mylist&& right) noexcept
	{
		mylist temp = static_cast<mylist&&>(*this);
		head        = right.head;
		tail        = right.tail;
		right.head  = nullptr;
		right.tail  = nullptr;

		return *this;
	}

	mylist& operator=(const mylist&) = delete;

	~mylist()
	{
		while (head)
		{
			node* n = head;
			head    = head->next;
			delete n;
		}
	}

	iterator begin()
	{
		if (!head)
			return iterator{ nullptr, NodeSize };
		iterator it = iterator{ head, 0 };
		if (!it.valid())
			++it;
		return it;
	}

	iterator end() { return iterator{ tail, NodeSize }; }

	template <typename U>
	iterator insert(U&& elem)
	{
		if (!tail || tail->insertedCount >= NodeSize)
		{
			node* n = new node{ nullptr, tail };
			if (tail)
				tail->next = n;
			tail = n;

			if (!head)
				head = tail;
		}

		tail->elems[tail->insertedCount].elem   = static_cast<U&&>(elem);
		tail->elems[tail->insertedCount].exists = true;

		iterator result{ tail, tail->insertedCount };
		tail->insertedCount++;
		tail->count++;

		return result;
	}

	void erase(iterator it)
	{
		assert(it.n);
		assert(it.index < NodeSize);

		node* n = it.n;
		assert(n->elems[it.index].exists);
		assert(n->count > 0);
		assert(n->insertedCount > 0);

		n->elems[it.index].exists = false;
		if (it.index + 1 == n->insertedCount)
			n->insertedCount--;
		n->count--;

		if (n->count == 0)
		{
			if (n->prev)
				n->prev->next = n->next;
			else
				head = n->next;
			if (n->next)
				n->next->prev = n->prev;
			else
				tail = n->prev;
			delete n;
		}
	}

	template <typename F>
	iterator find_if(F&& f)
	{
		iterator it = begin();
		iterator e  = end();
		for (; it != e; ++it)
		{
			if (f(*it))
				return it;
		}
		return e;
	}

	iterator at(size_t index)
	{
		node* n = head;
		while (n)
		{
			if (n->count >= index)
				break;
			index -= n->count;
			n = n->next;
		}

		if (!n)
			return end();

		iterator result{ n, 0 };
		if (!result.valid())
			++result;

		while (index)
		{
			++result;
			--index;
		}

		return result;
	}

	size_t size()
	{
		size_t result = 0;
		node* n       = head;
		while (n)
		{
			result += n->count;
			n = n->next;
		}
		return result;
	}

	bool empty() { return head == nullptr; }
};

struct declaration
{
	mystring property;
	mystring value;
};

struct section
{
	mylist<mystring> selectors;
	mylist<declaration> declarations;

	void insertDeclaration(const declaration& decl)
	{
		auto it = declarations.find_if([&](declaration& declaration) { return declaration.property == decl.property; });
		if (it == declarations.end())
			declarations.insert(decl);
		else
			it->value = decl.value;
	}
};

class Parser
{
public:
	mylist<section> sections;

	mylist<mystring> parseSelectors()
	{
		mylist<mystring> selectors;
		mystring selector;
		char c;
		while (std::cin.get(c))
		{
			assert(c != '?');
			if (c == '{')
			{
				selector.strip_trailing_whitespace();
				if (!selector.empty())
					selectors.insert(selector);
				return selectors;
			}
			else if (c == ',')
			{
				selector.strip_trailing_whitespace();
				selectors.insert(selector);
				selector.clear();
			}
			else
			{
				selector.push_back_normalize(c);
			}
		}
		assert(false);
		return {};
	}

	void parseSection()
	{
		section& sect = *sections.insert(section{ parseSelectors() });

		declaration decl;

		enum class CurrentlyParsing
		{
			Property,
			Value,
		};
		CurrentlyParsing currentlyParsing = CurrentlyParsing::Property;

		char c;
		while (std::cin.get(c))
		{
			if (c == '}')
			{
				if (!decl.property.empty())
				{
					sect.insertDeclaration(decl);
				}
				return;
			}
			else if (c == ';')
			{
				if (!decl.property.empty())
				{
					assert(currentlyParsing == CurrentlyParsing::Value);
					sect.insertDeclaration(decl);
				}
				decl.property.clear();
				decl.value.clear();

				currentlyParsing = CurrentlyParsing::Property;
			}
			else if (c == ':')
			{
				assert(currentlyParsing == CurrentlyParsing::Property);
				decl.property.strip_trailing_whitespace();

				currentlyParsing = CurrentlyParsing::Value;
			}
			else if (currentlyParsing == CurrentlyParsing::Property)
				decl.property.push_back_normalize(c);
			else
				decl.value.push_back(c);
		}
		assert(false);
	}

	bool parseCommands()
	{
		for (int i = 0; i < 3; ++i)
		{
			auto c = std::cin.get();
			assert(c == '?');
		}

		char c;
		while (std::cin >> c)
		{
			if (c == '*')
			{
				for (int i = 0; i < 3; ++i)
				{
					c = (char)std::cin.get();
					assert(c == '*');
				}
				return true;
			}
			else if (c == '?')
			{
				std::cout << "? == " << sections.size() << std::endl;
			}
			else if (isdigit(c))
			{
				std::cin.unget();
				int i;
				std::cin >> i;
				assert(std::cin.good());

				assert(i > 0);
				auto sect = sections.at(i - 1);

				std::cin >> c;
				assert(std::cin.good());
				assert(c == ',');

				char command;
				std::cin >> command;
				assert(std::cin.good());

				std::cin >> c;
				assert(std::cin.good());
				assert(c == ',');

				if (command == 'S')
				{
					if (std::cin.peek() == '?')
					{
						std::cin.ignore();
						if (sect == sections.end())
							continue;
						std::cout << i << ",S,? == " << sect->selectors.size() << std::endl;
					}
					else
					{
						int j;
						std::cin >> j;
						assert(std::cin.good());
						assert(j > 0);
						if (sect == sections.end())
							continue;
						auto sel = sect->selectors.at(j - 1);
						if (sel != sect->selectors.end())
							std::cout << i << ",S," << j << " == " << *sel << std::endl;
					}
				}
				else if (command == 'A')
				{
					if (std::cin.peek() == '?')
					{
						std::cin.ignore();
						if (sect == sections.end())
							continue;
						std::cout << i << ",A,? == " << sect->declarations.size() << std::endl;
					}
					else
					{
						mystring n;
						while (std::cin.get(c))
						{
							if (c == '\n')
								break;
							n.push_back(c);
						}

						if (sect == sections.end())
							continue;

						auto d = sect->declarations.find_if([&](declaration& decl) { return decl.property == n; });

						if (d != sect->declarations.end())
							std::cout << i << ",A," << n << " ==" << d->value << std::endl;
					}
				}
				else if (command == 'D')
				{
					if (std::cin.peek() == '*')
					{
						std::cin.ignore();
						if (sect == sections.end())
							continue;
						sections.erase(sect);
						std::cout << i << ",D,* == deleted" << std::endl;
					}
					else
					{
						mystring n;
						while (std::cin.get(c))
						{
							if (c == '\n')
								break;
							n.push_back(c);
						}

						if (sect == sections.end())
							continue;

						auto d = sect->declarations.find_if([&](declaration& decl) { return decl.property == n; });

						if (d != sect->declarations.end())
						{
							sect->declarations.erase(d);
							if (sect->declarations.empty())
								sections.erase(sect);
							std::cout << i << ",D," << n << " == deleted" << std::endl;
						}
					}
				}
				else
				{
					// W testach na STOSie sa niepoprawne komendy
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					// assert(false);
				}
			}
			else
			{
				mystring s;
				s.push_back(c);
				while (std::cin.get(c))
				{
					if (c == ',')
						break;
					s.push_back(c);
				}

				char command;
				std::cin >> command;
				assert(std::cin.good());

				std::cin >> c;
				assert(std::cin.good());
				if (c != ',')
				{
					// Workaround broken STOS tests
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					continue;
				}
				assert(c == ',');

				if (command == 'S')
				{
					std::cin >> c;
					assert(std::cin.good());
					assert(c == '?');

					size_t result = 0;
					for (section& sect : sections)
					{
						for (mystring& sel : sect.selectors)
						{
							if (sel == s)
							{
								++result;
								break;
							}
						}
					}
					std::cout << s << ",S,? == " << result << std::endl;
				}
				else if (command == 'A')
				{
					std::cin >> c;
					assert(std::cin.good());
					assert(c == '?');

					size_t result = 0;
					for (section& sect : sections)
					{
						for (declaration& decl : sect.declarations)
						{
							if (decl.property == s)
								++result;
						}
					}
					std::cout << s << ",A,? == " << result << std::endl;
				}
				else if (command == 'E')
				{
					mystring n;
					while (std::cin.get(c))
					{
						if (c == '\n')
							break;
						n.push_back(c);
					}

					mystring* value = nullptr;
					for (section& sect : sections)
					{
						if (sect.selectors.find_if([&](mystring& sel) { return sel == s; }) == sect.selectors.end())
							continue;

						for (declaration& decl : sect.declarations)
						{
							if (decl.property == n)
								value = &decl.value;
						}
					}

					if (value)
						std::cout << s << ",E," << n << " == " << *value << std::endl;
				}
				else
				{
					// W testach na STOSie sa niepoprawne komendy
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					// assert(false);
				}
			}
		}
		return false;
	}

	void parse()
	{
		while (true)
		{
			char c;
			std::cin >> c;
			if (c == '?')
			{
				if (!parseCommands())
					break;
			}
			else
			{
				std::cin.unget();
				parseSection();
			}
		}
	}
};

int main()
{
	Parser parser;
	parser.parse();
}
