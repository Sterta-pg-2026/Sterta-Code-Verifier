#pragma once
#define T 31
#define SPACJA 32
#define ENTER 10