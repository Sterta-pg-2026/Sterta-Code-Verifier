#pragma once
#include "sekcja.h"



class Blok {
private:
	Blok* prev;
	Sekcja* sekcje;
	static int taken;
	static int deleted;
	int T;
	Blok* next;

public:
	Blok(Sekcja*& s);
	~Blok();
	void addSekcja(Blok*& firstNode, Sekcja*& s);
	void addFirst(Blok*& firstNode, Sekcja*& s);
	void addLast(Blok*& firstNode, Sekcja*& s);
	int getListLen(Blok* firstNode) const;
	int getTaken(Blok*& firstNode) const;
	int liczbaSekcji(Blok*& firstNode) const;
	Sekcja* getSekcjaByIndex(Blok* firstNode, int i);
	int selNameNum(Blok* firstNode, char* str) const;
	int attNameNum(Blok* firstNode, char* str) const;
	char* function(Blok* firstNode, char* z, char* n) const;
	void deleteSekcjaByIndex(Blok*& firstNode, int i);
};