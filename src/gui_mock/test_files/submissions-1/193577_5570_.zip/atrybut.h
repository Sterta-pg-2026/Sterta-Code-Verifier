#pragma once
#include <stdio.h>

class Atrybut {
private:
    Atrybut* prev;
    char* name;
    char* value;
    Atrybut* next;
public:
    Atrybut(char* name, char* value);
    Atrybut(Atrybut* other);
    ~Atrybut();
    char* getName() const;
    char* getValue() const;
    void addFirst(Atrybut*& firstNode, char* name, char* value);
    void addLast(Atrybut*& firstNode, char* name, char* value);
    void removeByName(Atrybut*& firstNode, char* str);
    void replaceValue(Atrybut*& firstNode, char* str, char* newValue);
    int getListLen(Atrybut* firstNode) const;
    Atrybut* GetByName(Atrybut* firstNode, char* str) const;
    Atrybut* getNext() const;
};



