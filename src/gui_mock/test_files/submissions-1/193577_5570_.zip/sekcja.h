#pragma once
#include <stdio.h>
#include <string.h>
#include "selektor.h"
#include "atrybut.h"

class Sekcja {
private:
    Selektor* selektory;
    Atrybut* atrybuty;
    static int cnt;
public:
    Sekcja();
    Sekcja(Selektor*& selektory, Atrybut*& atrybuty);
    Sekcja(Sekcja*& other);
    ~Sekcja();
    int getCnt() const;
    void deleteSekcja();
    Selektor* getSelektory() const;
    Atrybut* getAtrybuty() const;
    bool findSelName(char* str) const;
    bool findAttName(char* str) const;

};