#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NONSTDC_NO_DEPRECATE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "atrybut.h"
#include "selektor.h"
#include "sekcja.h"
#include "blok.h"

bool section_end = false;
bool command_section = false;

int actual_len(char* str) {
    if (str == NULL)return 0;
    while (isspace(*str)) {
        str++;
    }
    return strlen(str);
}

int count_char(char* str, char c) {
    int cnt = 0;
    while (*str != '\0') {
        if (*str == c) cnt++;
        str++;
    }
    return cnt;
}

bool equals(char* str, const char* command) {
    if (str == NULL)return false;
    if (strlen(str) != strlen(command)) return false;
    for (int i = 0; i < strlen(str); i++)
        if (str[i] != command[i])return false;
    return true;
}

bool is_number(char* str) {
    if (str[0] >= '0' && str[0] <= '9') return true;
    return false;
}

int to_number(char* str) {
    int n = 0;
    while (*str != '\0') {
        n = n * 10 + (*str - 48);
        str++;
    }
    return n;
}

void skip_char(int n) {
    for (int i = 0; i < n; i++) {
        char c = getchar();
    }
}

char* read_until(char stop_char) {
    char* str = new char[1];
    int c;
    int i = 0;

    while ((c = getchar()) && c != stop_char) {
        if (c == EOF) {
            exit(0);
        }
        if (c == '}') {
            section_end = true;
            break;
        }
        if (command_section == false && c == '?') {
            command_section = true;
            skip_char(4);
            break;
        }
        str[i++] = (char)c;
        char* temp = new char[i + 1];
        for (int j = 0; j < i; j++) {
            temp[j] = str[j];
        }
        str = temp;
    }

    str[i] = 0;

    return str;
}

char* read_until(char stop_char, Blok* head) {
    char* str = new char[1];
    int c;
    int i = 0;

    while ((c = getchar()) && c != stop_char) {
        if (c == '}') {
            section_end = true;
            break;
        }
        if (command_section == false && c == '?') {
            command_section = true;
            skip_char(4);
            break;
        }
        if (c == EOF) {
            str[i] = 0;
            if (equals(str, "?")) printf("? == %i", head->liczbaSekcji(head));
            exit(0);
        }

        str[i++] = (char)c;
        char* temp = new char[i + 1];
        for (int j = 0; j < i; j++) {
            temp[j] = str[j];
        }
        str = temp;
    }
    str[i] = 0;
    return str;
}

char* substr_until(char* str, int start, char stop_char) {
    while (isspace(*str)) {
        str++;
    }
    str += start;

    int len = 0;
    while (str[len] != stop_char && str[len] != 0) {
        len++;
    }

    char* substr = new char[len + 1];
    for (int i = 0; i < len; i++) {
        substr[i] = str[i];
    }
    substr[len] = 0;
    return substr;
}

char* substr_until(char* str, int start, char stop_char1, char stop_char2) {
    while (str != NULL && isspace(*str)) {
        str++;
    }
    str += start;

    int len = 0;
    while (str[len] != 0 && str[len] != stop_char2 && str[len] != stop_char1) {
        len++;
    }
    if (len <= 0)return NULL;
    while (isspace(str[len - 1])) len--;
    if (len <= 0)return NULL;

    char* substr = new char[len + 1];
    for (int i = 0; i < len; i++) {
        substr[i] = str[i];
    }
    substr[len] = 0;
    return substr;
}

char* substr_until(char* str, int start) {
    if (str == NULL) return NULL;
    while (isspace(*str)) {
        str++;
    }
    str += start;

    if (*str < 33)str++;

    int len = 0;
    while (str[len] != 0) {
        len++;
    }

    char* substr = new char[len + 1];
    for (int i = 0; i < len; i++) {
        substr[i] = str[i];
    }
    substr[len] = 0;

    return substr;
}

void sel(char* str, Selektor*& selektory) {
    char* selName = NULL;
    if (actual_len(str) <= 0) {
        selektory->addLast(selektory, selName);
    }
    int start = 0;
    while (start < actual_len(str)) {
        selName = substr_until(str, start, ',', '{');
        if (selName == NULL) printf("NULL\n");
        if (selektory->GetByName(selektory, selName) == NULL) selektory->addLast(selektory, selName);
        start += strlen(selName) + 2;
    }
}

void att(char* str, Atrybut*& atrybuty) {
    while (section_end == false) {
        str = read_until(';');
        char* attName = substr_until(str, 0, ':');
        char* attValue = substr_until(str, strlen(attName) + 1);
        if (section_end == false) {
            if (atrybuty->GetByName(atrybuty, attName) == NULL) atrybuty->addLast(atrybuty, attName, attValue);
            else atrybuty->replaceValue(atrybuty, attName, attValue);
        }
    }
    section_end = false;
}


void com1(Blok* head, char** com) {
    int i = to_number(com[0]);
    int temp = head->getSekcjaByIndex(head, i)->getSelektory()->getListLen(head->getSekcjaByIndex(head, i)->getSelektory());
    if(temp>0)printf("%i,S,? == %i\n", i, temp);
    if (temp == -1)printf("%i,S,? == 0\n", i);
}

void com2(Blok* head, char** com) {
    int i = to_number(com[0]);
    int temp = head->getSekcjaByIndex(head, i)->getAtrybuty()->getListLen(head->getSekcjaByIndex(head, i)->getAtrybuty());
    if (temp > 0)printf("%i,A,? == %i\n", i, temp);
}

void com3(Blok* head, char** com) {
    int i = to_number(com[0]);
    int j = to_number(com[2]);
    char* temp = head->getSekcjaByIndex(head, i)->getSelektory()->GetByIndex(head->getSekcjaByIndex(head, i)->getSelektory(), j - 1)->getName();
    if (temp != NULL) printf("%i,S,%i == %s\n", i, j, temp);
}

void com4(Blok* head, char** com) {
    int i = to_number(com[0]);
    char* n = com[2];
    char* temp = head->getSekcjaByIndex(head, i)->getAtrybuty()->GetByName(head->getSekcjaByIndex(head, i)->getAtrybuty(), n)->getValue();
    if (temp != NULL) printf("%i,A,%s == %s\n", i, n, temp);
}

void com5(Blok* head, char** com) {
    char* n = com[0];
    int i = head->attNameNum(head, n);
    printf("%s,A,? == %i\n", n, i);
}

void com6(Blok* head, char** com) {
    char* z = com[0];
    int i = head->selNameNum(head, z);
    printf("%s,S,? == %i\n", z, i);
}

void com7(Blok* head, char** com) {
    char* z = com[0];
    char* n = com[2];
    if(head->function(head, z, n)!=NULL)printf("%s,E,%s == %s\n", z, n, head->function(head, z, n));
}

void com8(Blok* head, char** com) {
    int i = to_number(com[0]);
    Atrybut* temp = head->getSekcjaByIndex(head, i)->getAtrybuty();
    if (temp->getListLen(temp) != 0) {
        head->deleteSekcjaByIndex(head, i);
        printf("%i,D,* == deleted\n", i);
    }
}

void com9(Blok* head, char** com) {
    int i = to_number(com[0]);
    char* n = com[2];
    Atrybut* temp = head->getSekcjaByIndex(head, i)->getAtrybuty();
    if (temp->getListLen(temp) != 0) {
        if (temp->GetByName(temp, n) != NULL) printf("%i,D,%s == deleted\n", i, n);
        temp->removeByName(temp, n);
        if (temp->getListLen(temp) == 0) head->deleteSekcjaByIndex(head, i);
    }
}

void commands(char* str, Blok* head) {
    if (equals(str, "?\n") || equals(str, "?")) printf("? == %i\n", head->liczbaSekcji(head));
    if (actual_len(str) > 2 && count_char(str, ',') == 2) {
        char** com = new char* [3];
        int start = 0;
        int k = 0;
        while (start < actual_len(str)) {
            char* tmp = substr_until(str, start, ',', '\n');
            com[k++] = tmp;
            start += strlen(tmp) + 1;
        }
        if (is_number(com[0]) && com[1][0] == 'S' && com[2][0] == '?') com1(head, com);
        else if (is_number(com[0]) && com[1][0] == 'A' && com[2][0] == '?') com2(head, com);
        else if (is_number(com[0]) && com[1][0] == 'S' && is_number(com[2])) com3(head, com);
        else if (is_number(com[0]) && com[1][0] == 'A' && !is_number(com[2])) com4(head, com);
        else if (!is_number(com[0]) && com[1][0] == 'A' && com[2][0] == '?') com5(head, com);
        else if (!is_number(com[0]) && com[1][0] == 'S' && com[2][0] == '?') com6(head, com);
        else if (!is_number(com[0]) && com[1][0] == 'E' && !is_number(com[2])) com7(head, com);
        else if (is_number(com[0]) && com[1][0] == 'D' && com[2][0] == '*') com8(head, com);
        else if (is_number(com[0]) && com[1][0] == 'D' && !is_number(com[2])) com9(head, com);
        delete[] com;
    }
}

int main() {
    Blok* head = NULL;
    char* str;
    while (true) {
        do {
            Selektor* selektory = NULL;
            Atrybut* atrybuty = NULL;
            str = read_until('{');
            if (!command_section) {
                sel(str, selektory);
                att(str, atrybuty);
                Sekcja* s = new Sekcja(selektory, atrybuty);
                head->addSekcja(head, s);
            }
        } while (!command_section);

        while (command_section) {
            str = read_until('\n',head);
            if (str != NULL) {
                if (equals(str, "****")) {
                    command_section = false;
                    break;
                }
                commands(str, head);
            }
        }
        delete[]str;
    }
    return 0;
}