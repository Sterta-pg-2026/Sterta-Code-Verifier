#pragma once
#include <stdio.h>
#include "atrybut.h"

class Selektor {
private:
    Selektor* prev;
    char* name;
    Selektor* next;

public:
    Selektor(char* str);
    Selektor(Selektor* other);
    ~Selektor();
    char* getName() const;
    void addFirst(Selektor*& firstNode, char* name);
    void addLast(Selektor*& firstNode, char* name);
    int getListLen(Selektor* firstNode) const;
    Selektor* GetByIndex(Selektor* firstNode, int i) const;
    Selektor* GetByName(Selektor* firstNode, char* str) const;
    Selektor* getNext() const;
};


