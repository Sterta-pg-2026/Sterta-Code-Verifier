//
// Created by Michał on 2023-04-02.
//

#ifndef AISD_CSSPROCESSOR_STRUCTURES_H
#define AISD_CSSPROCESSOR_STRUCTURES_H

#define SECTION_ARRAY_SIZE 8

#include "list.h"

typedef struct Attribute
{
    char *name;
    char *value;
} Attribute;

typedef struct Section
{
    // DO NOT CHANGE THE VARIABLES ORDER
    // THEIR ORDER IS CRUCIAL FOR A CORRECT DELETION OF SECTIONS

    List selectors;
    List attributes;
} Section;

typedef struct Master
{
    int slotsTaken;
    Section section_array[SECTION_ARRAY_SIZE];
} Master;

#endif //AISD_CSSPROCESSOR_STRUCTURES_H
