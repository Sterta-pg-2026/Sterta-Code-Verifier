#include <malloc.h>
#include "structures.h"
#include "controllers.h"
#include "string.h"

// create css_controller parsing all the css code,
// make main operations into mechanisms and implement passing parsed css into the structures
//
// check if includes repeat themselves and if executables are needed,
// make functions static,
// check STOS warnings
// replace the defined variables with enums
// read about the C buffer

int main() {
    // List of (arrays of) sections - initialized with NULL values
    List main_list = {NULL, NULL};
    char *test = ":";
    //css_controller(&main_list, test, strlen(test));
    main_controller(&main_list);


//
//    /* 1. */
//    insert_master_structure(&main_list);    // on start or if slotsTaken == T
//
//
//    /* ----------- */
//
//
//    /* 2a. */
//    // READING SELECTOR NAME AND NAME_SIZE
//    char text[32];
//    scanf("%s", text);
//    unsigned text_size = strlen(text)*sizeof(char) + 1;
//    // ASSIGNING THE SELECTOR
//    insert_last(&((Master *)main_list.head->data)->section_array[0].selectors, text, text_size);
//
//    /* 2b. */
//    // ALLOCATING AN ATTRIBUTE AND ITS VARIABLES
//    Attribute *attribute = (Attribute *) malloc(sizeof(Attribute));
//    attribute->name = malloc(13);   // should be based on input size
//    attribute->value = malloc(8);
//    // CREATING AN ATTRIBUTE
//    scanf("%s", text);
//    strcpy(attribute->name, text);
//    scanf("%s", text);
//    strcpy(attribute->value, text);
//    // ASSIGNING AN ATTRIBUTE
//    insert_last(&((Master *)main_list.head->data)->section_array[0].attributes, attribute, sizeof(Attribute));
//    // CLEARING MEMORY
//    free(attribute);
//
//    /* 2c. */
//    // INCREMENTING SLOTS_TAKEN DATA
//    ((Master *)main_list.head->data)->slotsTaken++;
//
//    /* additional. */
//    // REMOVING AN ATTRIBUTE
//    // remove_by_index(&((Master *)main_list.head->data)->section_array[0].attributes, 1);
//
//
//
//
//    // TESTING
//    printf("%d\n", ((Master *)main_list.head->data)->slotsTaken);
//    printf("%s\n", (char *)((Master *)main_list.head->data)->section_array[0].selectors.head->data);
//    printf("%s\n", (char *)((Attribute *)((Master *)main_list.head->data)->section_array[0].attributes.head->data)->name);
//    printf("%s\n", (char *)((Attribute *)((Master *)main_list.head->data)->section_array[0].attributes.head->data)->value);

    return 0;
}