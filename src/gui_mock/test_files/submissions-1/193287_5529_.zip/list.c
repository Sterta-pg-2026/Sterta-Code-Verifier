//
// Created by Michał on 2023-04-02.
//

#include "list.h"
#include <malloc.h>
#include <string.h>

void mallocError() {
    printf("Memory allocation error!");
    exit(1);
}

/* CREATES THE FIRST ELEMENT OF A LIST */
void list_init(List *list, void *data_src, size_t data_size) {
    list->head = (Node *) malloc(sizeof(Node));
    if (list->head != NULL) {
        list->head->next = NULL;
        list->head->prev = NULL;
        list->head->data = malloc(data_size);
        memcpy(list->head->data, data_src, data_size);
        // TAIL IS EQUAL HEAD (as there is only one element inside the list)
        list->tail = list->head;
    } else mallocError();
}

/* ADDS AN ELEMENT TO A LIST */
void insert_last(List *list, void *data_src, size_t data_size) {
    if(list->head == NULL) {
        list_init(list, data_src, data_size);
    } else {
        list->tail->next = (Node *) malloc(sizeof(Node));
        if (list->tail->next != NULL) {
            // CREATING A NEW NODE
            list->tail->next->next = NULL;
            list->tail->next->prev = list->tail;
            list->tail->next->data = malloc(data_size);
            memcpy(list->tail->next->data, data_src, data_size);
            // ASSIGNING THE NEW NODE TO THE TAIL
            list->tail = list->tail->next;
        } else mallocError();
    }
}

/* RESETS THE LIST - USE ONLY IF THERE IS ONE ELEMENT LEFT */
void list_reset(List *list) {
    free(list->head);
    list->head = NULL;
    list->tail = NULL;
}

void remove_first(List *list) {
    list->head = list->head->next;
    free(list->head->prev);
    list->head->prev = NULL;
}

void remove_last(List *list) {
    list->tail = list->tail->prev;
    free(list->tail->next);
    list->tail->next = NULL;
}

/* REMOVES AN ELEMENT FROM A LIST */
void remove_by_index(List *list, int index) {
    // NO ELEMENTS OR INPUT ERROR
    if (list->head == NULL || index < 1) return;
    // 1 ELEMENT
    if (list->head->next == NULL && index == 1) list_reset(list);
    // >1 ELEMENTS
    // FIRST ELEMENT
    else if (index == 1) remove_first(list);
    // (2 ; n) ELEMENT
    else {
        Node *current = list->head;
        for (int i = 1; i < index; ++i) {
            // ELEMENT NOT FOUND
            if (current->next == NULL) return;
            // ELEMENT EXISTS
            current = current->next;
        }
        if (current->next != NULL) {
            current->prev->next = current->next;
            current->next->prev = current->prev;
            free(current);
            // LAST ELEMENT
        } else remove_last(list);
    }
}

void remove_element(Node *node, List *list) {
    // NODE IS EMPTY
    if (node == NULL) return;
    // 1 ELEMENT
    if (node->prev == NULL && node->next == NULL) list_reset(list);
    // FIRST ELEMENT
    else if (node->prev == NULL) remove_first(list);
    else if (node->next == NULL) remove_last(list);
    else {
        node->prev->next = node->next;
        node->next->prev = node->prev;
        free(node);
    }
}

// fptr is a pointer to a function that takes a single argument of type void* and returns void
void printList(Node *node, void (*fptr)(void *))
{
    while (node != NULL)
    {
        (*fptr)(node->data);
        node = node->next;
    }
}

void printString(void *n)
{
    printf("%s\n", (char *)n);
}