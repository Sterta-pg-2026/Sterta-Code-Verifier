//
// Created by Michał on 2023-04-02.
//

#ifndef AISD_CSSPROCESSOR_LIST_H
#define AISD_CSSPROCESSOR_LIST_H

#include <stdio.h>

typedef struct Node
{
    void *data;
    struct Node *next;
    struct Node *prev;
} Node;

typedef struct List
{
    Node *head;
    Node *tail;
} List;

void list_init(List *list, void *data_src, size_t data_size);

void insert_last(List *list, void *data_src, size_t data_size);

void remove_by_index(List *list, int index);

void remove_element(Node *node, List *list);

void printList(Node *node, void (*fptr)(void *));

void printInt(void *n);

void printString(void *n);

#endif //AISD_CSSPROCESSOR_LIST_H