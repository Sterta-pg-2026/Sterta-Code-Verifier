//
// Created by Michał on 2023-04-03.
//

#define MAX_TEXT_SIZE 256
#define CSS_SECTION 1
#define COMMANDS_SECTION 2
#define SELECTOR 1
#define ATTRIBUTE_NAME 2
#define ATTRIBUTE_VALUE 3
#define RESET_TPC strcpy(textProcessingContainer, "\0"); classifier = SELECTOR; newSection = true

#include <malloc.h>
#include <stdbool.h>
#include "controllers.h"
#include "structures.h"
#include "string.h"

bool isDigit(char c) {
    if (48 < c && c < 58) return true;
    return false;
}

void insert_master_structure(List *main_list) {
    // ALLOCATING MASTER STRUCTURE WITH NULL VALUES (aka initializing slotsTaken, selectors and attributes to 0)
    Master *master_structure = (Master *) calloc(1, sizeof(Master));
    // ASSIGNING IT TO THE MAIN LIST
    insert_last(main_list, master_structure, sizeof(Master));
    // CLEARING MEMORY
    free(master_structure);
}

void css_controller(List *main_list, char *text) {
    // CLASSIFIER CONTROLS TYPES OF TEXT BEING PROCESSED
    // css files always begin with a selector
    static int classifier = SELECTOR;
    // newSection controls the creation of new sections
    static bool newSection = true;
    // sectionCounter holds the count of created sections
    static int sectionCounter = 0;

    // TPC holds text parts waiting for being processed.
    // If processing doesn't happen immediately, it is due to being seperated, because of white spaces
    static char textProcessingContainer[MAX_TEXT_SIZE];
    size_t tpc_size = strlen(textProcessingContainer);


    /* LOADING TEXT FOR PROCESSING */

    // COPYING TEXT INTO THE TPC
    // Adding a white space if it's supposed to be a part of a name/value
    if (tpc_size > 0 && textProcessingContainer[tpc_size - 1] != ':') strcat(textProcessingContainer, " ");
    strcat(textProcessingContainer, text);
    // UPDATING THE TPC SIZE
    tpc_size = strlen(textProcessingContainer);

    // CONSIDERING POSSIBILITIES OF TPC RESET
    // 1. '}' is the only sign in the TPC
    if (textProcessingContainer[0] == '}') {
        RESET_TPC;
        return;
    }

    // CONSIDERING POSSIBILITIES OF IMMEDIATE RETURN
    // 1. TPC does not end with a functional sign
    switch (textProcessingContainer[tpc_size - 1]) {
        case '{':
        case ';':
        case '}':
            break;  // continue
        case ',':
            // 2. Comma is a part of attribute's value
            // To assign an attribute, function needs both its name and value.
            // Here value isn't yet fully loaded, therefore classifier == ATTRIBUTE_NAME
            if (classifier != ATTRIBUTE_NAME) break;
        default:
            return;
    }

    // ALLOCATING AN ATTRIBUTE STRUCTURE - FOR PROCESSING A TEXT OF AN ATTRIBUTE TYPE LATER
    Attribute *attribute = (Attribute *) malloc(sizeof(Attribute));


    /* TEXT PROCESSING */

    for (int i = 1; i < tpc_size; ++i) {
        /* TEXT CONVERTING */

        // SEARCHING FOR FUNCTIONAL SIGNS
        // If not found the loop is skipped
        // If found text processing takes places
        switch (textProcessingContainer[i]) {
            case ',':
                // Checking if comma is a part of attribute's value
                if (classifier == ATTRIBUTE_VALUE) continue;
            case ';':
            case '{':
            case '}':
                break;
            case ':':
                // Checking if colon is a part of selector's name
                if (classifier == SELECTOR) continue;
                break;
            default:
                continue;
        }

        char processedText[MAX_TEXT_SIZE];
        // CONVERTING THE FIRST NAME/VALUE IN TPC
        strncpy(processedText, textProcessingContainer, i);
        processedText[i] = '\0';


        /* DATA MANAGEMENT */

        // Process of assigning processed text to the correct structure
        switch (classifier) {
            case SELECTOR:
                // ADDING A SELECTOR
                if (newSection) {
                    // CREATING A NEW SECTION
                    if (sectionCounter % SECTION_ARRAY_SIZE == 0) {
                        // CREATING A NEW MASTER STRUCTURE
                        insert_master_structure(main_list);
                    }
                    sectionCounter++;
//                    printf("SECTION NR %d\n", sectionCounter);
                    ((Master *) main_list->tail->data)->slotsTaken++;
                    newSection = false;
                }
                insert_last(&((Master *) main_list->tail->data)->section_array[(sectionCounter - 1) %
                                                                               SECTION_ARRAY_SIZE].selectors,
                            processedText, strlen(processedText) + 1);
//                printf("Selector: %s\n", processedText);
                break;
                // CREATING AN ATTRIBUTE STRUCTURE
            case ATTRIBUTE_NAME:
                attribute->name = (char *) malloc(strlen(processedText) + 1);
                strcpy(attribute->name, processedText);
//                printf("Attribute_name: %s\n", processedText);
                break;
            case ATTRIBUTE_VALUE:
                attribute->value = (char *) malloc(strlen(processedText) + 1);
                strcpy(attribute->value, processedText);
                // ADDING AN ATTRIBUTE STRUCTURE
                insert_last(&((Master *) main_list->tail->data)->section_array[(sectionCounter - 1) %
                                                                               SECTION_ARRAY_SIZE].attributes,
                            attribute, sizeof(Attribute));
//                printf("Attribute_value: %s\n", processedText);
                break;
            default:
                break;  // do nothing
        }


        /* PREPARING FOR THE PROCESSING OF THE NEXT TEXT PART */

        // CLASSIFYING THE NEXT TEXT PART
        switch (textProcessingContainer[i]) {
            case '}':
            RESET_TPC;
                break;
            case ';':
            case '{':
                classifier = ATTRIBUTE_NAME;
                break;
            case ':':
                classifier = ATTRIBUTE_VALUE;
                break;
            default:
                break;  // do nothing
        }
        // UPDATING THE TPC
        strcpy(textProcessingContainer, textProcessingContainer + i + 1);
        // CONSIDERING "}" BEING LEFT AS THE ONLY SIGN IN THE TPC
        if (textProcessingContainer[0] == '}') {
            RESET_TPC;
        }
        // UPDATING THE TPC SIZE
        tpc_size = strlen(textProcessingContainer);
        // RESETTING THE LOOP TO PROCESS THE NEXT NAME/VALUE WAITING IN THE TPC, IF THERE IS ONE
        i = 0;
    }
    free(attribute);
}


static void command_controller(List *main_list, char *text) {
    size_t text_size = strlen(text);
    Node *node = main_list->head;
    char elementName[MAX_TEXT_SIZE];
    // Comparator is used to check if some sections are equal to 0 (were deleted)
    char comparator[sizeof(Section)] = {0};
    int result = 0;

    // COMMANDS BEGINNING WITH A NUMBER
    if (isDigit(text[0])) {
        // Assigning section number
        int commandNumber = strtol(text, NULL, 10);
        // Assigning node to the correct master_structure
        while (commandNumber > ((Master *) node->data)->slotsTaken) {
            commandNumber -= ((Master *) node->data)->slotsTaken;
            node = node->next;
            // Considering that structure doesn't exist
            if (node == NULL) return;
        }

        // Searching for ',' sign
        for (int i = 0; i < text_size; ++i) {
            if (text[i] != ',') continue;

            // COMMANDS OF TYPE "i,S,."
            if (text[i + 1] == 'S') {
                // Assigning the node to the correct section
                for (int j = 0; j < SECTION_ARRAY_SIZE; ++j) {
                    if (memcmp(&((Master *) node->data)->section_array[j], comparator, sizeof(Section)) == 0) continue;

                    commandNumber--;
                    if (commandNumber == 0) {
                        node = ((Master *) node->data)->section_array[j].selectors.head;
                        break;
                    }
                }

                // "i,S,?" COMMAND
                if (text[i + 3] == '?') {
                    // COUNTING ELEMENTS
                    while (node != NULL) {
                        node = node->next;
                        result++;
                    }
                    printf("%s == %d\n", text, result);
                    return;
                }

                    // "i,S,j" COMMAND
                else if (text[i + 2] == ',' && isDigit(text[i + 3])) {
                    // Assigning selector number
                    commandNumber = strtol(text + i + 3, NULL, 10);
                    while (commandNumber > 1) {
                        node = node->next;
                        // Considering that structure doesn't exist
                        if (node == NULL) return;
                        commandNumber--;
                    }
                    printf("%s == %s\n", text, (char *) node->data);
                    return;
                }
            }
                // COMMANDS OF TYPE "i,A,."
            else if (text[i + 1] == 'A') {
                // Assigning the node to the correct section
                for (int j = 0; j < SECTION_ARRAY_SIZE; ++j) {
                    if (memcmp(&((Master *) node->data)->section_array[j], comparator, sizeof(Section)) == 0) continue;

                    commandNumber--;
                    if (commandNumber == 0) {
                        node = ((Master *) node->data)->section_array[j].attributes.head;
                        break;
                    }
                }

                // "i,A,?" COMMAND
                if (text[i + 3] == '?') {
                    // COUNTING ELEMENTS
                    while (node != NULL) {
                        node = node->next;
                        result++;
                    }
                    printf("%s == %d\n", text, result);
                    return;
                }

                    // "i,A,n" COMMAND
                else if (text[i + 2] == ',') {
                    // Assigning attribute's name
                    strcpy(elementName, text + i + 3);
                    // Searching for the attribute
                    while (strcmp(elementName, ((Attribute *) node->data)->name) != 0) {
                        node = node->next;
                        // Considering that structure doesn't exist
                        if (node == NULL) return;
                    }
                    printf("%s == %s\n", text, ((Attribute *) node->data)->value);
                    return;
                }
            }
                // COMMANDS OF TYPE "i,D,."
            else if (text[i + 1] == 'D') {
                Node *masterNode = node;
                // Assigning the node to the correct section
                for (int j = 0; j < SECTION_ARRAY_SIZE; ++j) {
                    if (memcmp(&((Master *) node->data)->section_array[j], comparator, sizeof(Section)) == 0) continue;

                    commandNumber--;
                    if (commandNumber == 0) {
                        node = (Node *) &((Master *) node->data)->section_array[j];
                        break;
                    }
                }

                // "i,D,*" COMMAND
                if (text[i + 3] == '*') {
                    // Updating info about taken slots in a master_structure (assuming that command will execute)
                    ((Master *) masterNode->data)->slotsTaken--;
                    // DELETING THE SECTION
                    memset(node, 0, sizeof(Section));
                    printf("%s == deleted\n", text);
                }

                    // "i,D,n" COMMAND
                else if (text[i + 2] == ',') {
                    List parent_list = ((Section *) node)->attributes;
                    Node *sectionNode = node;
                    // Assigning attribute's name
                    strcpy(elementName, text + i + 3);
                    // Searching for the attribute
                    node = ((Section *) node)->attributes.head;
                    while (strcmp(elementName, ((Attribute *) node->data)->name) != 0) {
                        node = node->next;
                        // Considering that structure doesn't exist
                        if (node == NULL) return;
                    }
                    remove_element(node, &parent_list);
                    if (parent_list.head == NULL) {
                        ((Master *) masterNode->data)->slotsTaken--;
                        // DELETING THE SECTION
                        memset(sectionNode, 0, sizeof(Section));
                    }
                    printf("%s == deleted\n", text);
                }

                // CHECKING IF SECTION_ARRAY (IN THE CURRENT MASTER_STRUCTURE) IS EMPTY
                if (((Master *) masterNode->data)->slotsTaken == 0) {
                    // DELETING THE STRUCTURE
                    remove_element(masterNode, main_list);
                    return;
                }
            }
        }
    }
        // "?" COMMAND
    else if (text[0] == '?') {
        int aliveSectionsCounter = 0;
        while (node != NULL) {
            aliveSectionsCounter += ((Master *) node->data)->slotsTaken;
            node = node->next;
        }
        printf("? == %d\n", aliveSectionsCounter);
        return;
    }
        // COMMANDS OF TYPE "n/z,.,?"
    else if (text[text_size - 1] == '?') {
        // Assigning attribute's name
        strncpy(elementName, text, text_size - 4);
        elementName[text_size - 4] = '\0';

        Node *elementNode;
        // Iterating through master_structures
        while (node != NULL) {
            for (int i = 0; i < SECTION_ARRAY_SIZE; ++i) {
                if (memcmp(&((Master *) node->data)->section_array[i], comparator, sizeof(Section)) == 0) continue;

                // "z,S,?" COMMAND
                if (text[text_size - 3] == 'S') {
                    elementNode = ((Master *) node->data)->section_array[i].selectors.head;
                    while (elementNode != NULL) {
                        if (strcmp(elementNode->data, elementName) == 0) result++;
                        elementNode = elementNode->next;
                    }
                }
                    // "n,A,?" COMMAND
                else if (text[text_size - 3] == 'A') {
                    elementNode = ((Master *) node->data)->section_array[i].attributes.head;
                    while (elementNode != NULL) {
                        if (strcmp(((Attribute *)elementNode->data)->name, elementName) == 0) result++;
                        elementNode = elementNode->next;
                    }
                }
            }

            node = node->next;
        }
        printf("%s == %d\n", text, result);
        return;
    } else {
        for (int i = 0; i < text_size - 2; ++i) {
            // "z,E,n" COMMAND
            if (text[i] == ',' && text[i + 1] == 'E') {
                char selectorName[MAX_TEXT_SIZE];
                strncpy(selectorName, text, i);
                selectorName[i] = '\0';
                strcpy(elementName, text + i + 3);

                Node *elementNode;
                node = main_list->tail;
                // Iterating through master_structures
                while (node != NULL) {
                    for (int j = SECTION_ARRAY_SIZE - 1; j > -1; --j) {
                        if (memcmp(&((Master *) node->data)->section_array[j], comparator, sizeof(Section)) == 0) continue;

                            elementNode = ((Master *) node->data)->section_array[j].selectors.tail;
                            while (elementNode != NULL) {
                                if (strcmp(elementNode->data, selectorName) == 0) {
                                    elementNode = ((Master *) node->data)->section_array[j].attributes.head;
                                    while (elementNode != NULL) {
                                        if (strcmp(((Attribute *) elementNode->data)->name, elementName) == 0) {
                                            printf("%s == %s\n", text, ((Attribute *) elementNode->data)->value);
                                            return;
                                        }
                                        elementNode = elementNode->next;
                                    }
                                }
                                elementNode = elementNode->prev;
                            }



                    }
                    node = node->prev;
                }
            }
        }
    }
}

void main_controller(List *main_list) {
    char text[MAX_TEXT_SIZE];
    int navigator = CSS_SECTION;
    // READING THE TEXT UNTIL THE END OF FILE
    while (scanf("%s", text) != EOF) {
        // CSS SECTION START
        if (strcmp(text, "****") == 0) navigator = CSS_SECTION;
            // COMMANDS SECTION START
        else if (strcmp(text, "????") == 0) navigator = COMMANDS_SECTION;
            // CSS SECTION
        else if (navigator == CSS_SECTION) css_controller(main_list, text);
            // COMMANDS SECTION
        else command_controller(main_list, text);
    }
}