//
// Created by Michał on 2023-04-03.
//

#ifndef AISD_CSSPROCESSOR_CONTROLLERS_H
#define AISD_CSSPROCESSOR_CONTROLLERS_H

#include "list.h"

static void insert_selector();

static void insert_attribute();

void insert_master_structure(List *main_list);

void css_controller(List *main_list, char *text);

static void command_controller(List *main_list, char *text);

void main_controller(List *main_list);

#endif //AISD_CSSPROCESSOR_CONTROLLERS_H
