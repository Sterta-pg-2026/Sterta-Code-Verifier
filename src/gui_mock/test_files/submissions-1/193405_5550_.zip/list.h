#pragma once
#include "node.h"

template<typename T>
class List {
public:
	List() : firstNode(new Node<T>), size(0) {
		this->lastNode = firstNode;
	}

	List(const List& other) : firstNode(new Node<T>) {
		this->lastNode = firstNode;
		this->size = 0;
		int length = other.getSize();
		for (int i = 0; i < length; i++) {
			this->pushBack(other[i]);
		}
	}

	List<T>& operator=(const List<T>& other) {
		this->clear();
		int length = other.getSize();
		for (int i = 0; i < length; i++) {
			this->pushBack(other[i]);
		}
		return *this;
	}

	T& pushBack(const T& value) {
		Node<T>* last = this->lastNode;
		T* added = last->addItem(value);
		if (added == nullptr) {
			Node<T>* newNode = new Node<T>(last);
			this->lastNode = newNode;
			last->setNext(newNode);
			added = newNode->addItem(value);			
		}
		this->size++;
		return *added;
	}

	int remove(const T& value) {
		int counter = 0;
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			int removed = testNode->removeMatches(value);
			this->size -= removed;
			counter += removed;
			Node<T>* checkThisNode = testNode;			
			testNode = testNode->getNext();
			emptyCheck(checkThisNode);
		}
		return counter;
	}

	void removePtr(T* ptr) {
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			if (testNode->removeItem(ptr)) {
				emptyCheck(testNode);
				return;
			}
			testNode = testNode->getNext();
		}
	}

	void removeAt(int index) {
		int i = 0;
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			for (int slot = 0; slot < NODE_SIZE; slot++) {
				T* item = testNode->getItem(slot);
				if (item != nullptr) {
					if (i == index) {
						testNode->removeItem(slot);
						emptyCheck(testNode);
						this->size--;
						return;
					}
					i++;
				}
			}
			testNode = testNode->getNext();
		}
	}

	void clear() {
		deleteAll();
		this->firstNode = new Node<T>;
		this->lastNode = this->firstNode;
	}

	int getSize() const {
		return this->size;
	}

	T& getLast() {
		return *(this->lastNode->getLast());
	}

	T& operator[](const int index) {
		int i = 0;
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			for (int slot = 0; slot < NODE_SIZE; slot++) {
				T* item = testNode->getItem(slot);
				if (item != nullptr) {
					if (i == index) return *item;
					i++;					
				}
			}
			testNode = testNode->getNext();
		}
		return *firstNode->getItem(NODE_SIZE - 1);
	}

	const T& operator[](const int index) const {
		int i = 0;
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			for (int slot = 0; slot < NODE_SIZE; slot++) {
				T* item = testNode->getItem(slot);
				if (item != nullptr) {
					if (i == index) return *item;
					i++;
				}
			}
			testNode = testNode->getNext();
		}
		return *firstNode->getItem(NODE_SIZE - 1);
	}

	void print(std::ostream& out, bool prettyPrint = true) {
		if(prettyPrint){
			out << "(" << size << "){\n";
			for (int i = 0; i < size; i++) {
				out << (*this)[i] << ",\n";
			}
			out << "\n}";
		}
		else{
			for (int i = 0; i < size; i++) {
				out << (*this)[i];
			}
		}
	}

	template<typename Fun>
	void forEach(Fun&& fun, bool reverse = false) {
		if (reverse) {
			Node<T>* testNode = this->lastNode;
			while (testNode != nullptr) {
				Node<T>* next = testNode->getPrev();
				for (int slot = NODE_SIZE - 1; slot > 0; slot--) {
					T* item = testNode->getItem(slot);
					if (item != nullptr) {
						if (fun(*item) == false) return;
					}
				}				
				testNode = next;
			}
		}
		else {
			Node<T>* testNode = this->firstNode;
			while (testNode != nullptr) {
				Node<T>* next = testNode->getNext();
				for (int slot = 0; slot < NODE_SIZE; slot++) {
					T* item = testNode->getItem(slot);
					if (item != nullptr) {
						if (fun(*item) == false) return;
					}
				}
				testNode = next;
			}
		}
	}

	template<typename Fun>
	int countIf(Fun&& fun) {
		int occurrences = 0;
		this->forEach([&](const T& selector) {
			if (fun(selector)) occurrences++;
			return true;
		});
		return occurrences;
	}

	template<typename Fun>
	T* findIf(Fun&& fun) {
		T* found = nullptr;
		this->forEach([&](T& selector) {
			if (fun(selector)) {
				found = &selector;
				return false;
			}
			return true;
		});
		return found;
	}

	~List() {
		deleteAll();
	}

private:
	Node<T>* firstNode;
	Node<T>* lastNode;
	int size = 0;

	void deleteAll() {
		Node<T>* testNode = this->firstNode;
		while (testNode != nullptr) {
			Node<T>* nextNode = testNode->getNext();
			delete testNode;
			testNode = nextNode;
		}
		this->size = 0;
	}

	void emptyCheck(Node<T>* testNode) {
		//check if node is empty
		if (testNode->getCount() <= 0) {
			auto next = testNode->getNext();
			auto prev = testNode->getPrev();

			if (testNode == this->firstNode && testNode == this->lastNode) {
				delete testNode;
				testNode = new Node<T>;
				this->firstNode = testNode;
				this->lastNode = testNode;
			}
			else {
				if (testNode == this->firstNode) {
					this->firstNode = next;
					if (this->firstNode == nullptr)
						this->firstNode = this->lastNode;
					else
						this->firstNode->setPrev(nullptr);
				}
				else if (testNode == this->lastNode) {
					this->lastNode = prev;
					if (this->lastNode == nullptr)
						this->lastNode = this->firstNode;
					else
						this->lastNode->setNext(nullptr);
				}
				else {
					prev->setNext(next);
					next->setPrev(prev);
				}

				delete testNode;
			}
		}
	}
};

template<typename T>
std::ostream& operator<< (std::ostream& stream, List<T>& list) {
	list.print(stream);
	return stream;
}
