#pragma once
#include "list.h"
#include "inputscanner.h"
#include "my_string.h"
#include <iostream>

struct Selector {
	String name;
};

struct Attribute {
	String name;
	String values;

	bool operator==(const Attribute& other) {
		return this->name == other.name;
	}
};

struct Block {
	List<Selector> selectors;
	List<Attribute> attributes;
};

std::ostream& operator<< (std::ostream& stream, Attribute& attribute) {
	stream << attribute.name << " == " << attribute.values;
	return stream;
}

std::ostream& operator<< (std::ostream& stream, Selector& selector) {
	stream << "[Selector] { Name: '" << selector.name << "' }";
	return stream;
}

std::ostream& operator<< (std::ostream& stream, Block& block) {
	stream << "[Block]{\n(Selectors)";
	stream << " " << block.selectors << "\n";
	stream << "(Attributes)";
	stream << " " << block.attributes << "\n";
	return stream;
}

class Parser {
private:
	List<Block> blocks;

public:
	void parse() {
		Selector tmpSel;
		Attribute tmpAttr;

		while (true) {
			Block* block = nullptr;
			
			{
				bool selectEnd = false;				
				while (!selectEnd) {
					//read next word
					char stopChar = InputScanner::readUntil(tmpSel.name, ",{\n");
					tmpSel.name.trimSpaces();

					//stop the parser
					if (tmpSel.name == "????") return;

					switch (stopChar) {
						case '\n':
						case ',':
							if (tmpSel.name.getSize() > 0) {
								//if selector found initialize new block and add it's first selector
								if (block == nullptr) 
									block = &blocks.pushBack({});

								// do not add the same selector twice
								if (block->selectors.findIf([&](const Selector& sel) { return sel.name == tmpSel.name; }) == nullptr)
									block->selectors.pushBack(tmpSel);
							}
							break;
						case '{':						
							if (block == nullptr) 
								block = &blocks.pushBack({});

							if (tmpSel.name.getSize() > 0) {
								if (block->selectors.findIf([&](const Selector& sel) { return sel.name == tmpSel.name; }) == nullptr)
									block->selectors.pushBack(tmpSel);
							}
							selectEnd = true;
							break;
						case 0:
							return;

						default:
							break;
					}
				}
			}

			if(block != nullptr) {
				bool atribEnd = false;
				while (!atribEnd) {
					char stopChar = InputScanner::readUntil(tmpAttr.name, ",}\n:;");
					tmpAttr.name.trimSpaces();
					switch (stopChar) {
						case '}':
						{
							atribEnd = true;
							break;
						}

						case ':':
						{
							if (InputScanner::readUntil(tmpAttr.values, "}\n;") == '}') {
								atribEnd = true;
							}
							tmpAttr.values.trimSpaces();

							// check if attribute with the same name already exists
							Attribute* existingAttr = block->attributes.findIf([&](Attribute& atr) -> bool { return tmpAttr.name == atr.name; });
							if (existingAttr == nullptr) {
								block->attributes.pushBack(tmpAttr);
							}
							else {
								existingAttr->values = tmpAttr.values;
							}
							break;
						}

						case 0:
							return;

						default:
							break;
					}
				}
			}
		}
	}

	void interrogate() {
		String firstCommandString, secondCommandString, thirdCommandString;
		while (true) {

			char stopSign = InputScanner::readUntil(firstCommandString, ",\n");	
			firstCommandString.trimSpaces();

			// "?" number of sections
			if (firstCommandString == "?") {
				const int sections = blocks.getSize();
				std::cout << "? == " << sections << '\n';
				if (stopSign != 0) continue;
			}

			if (stopSign == 0) return;

			// skip empty lines
			if (firstCommandString.getSize() <= 0 && stopSign == '\n') continue;

			// "****" stop the interrogation
			if (firstCommandString == "****") return;

			InputScanner::readUntil(secondCommandString, ",\n");
			if (secondCommandString.getSize() <= 0) continue;
			secondCommandString.trimSpaces();
			char thirdStopS = InputScanner::readUntil(thirdCommandString, ",\n");
			if (thirdCommandString.getSize() <= 0) continue;
			thirdCommandString.trimSpaces();

			bool IisNumber = true;
			int iParameter = firstCommandString.toInt(&IisNumber);
			bool JisNumber = true;
			int jParameter = thirdCommandString.toInt(&JisNumber);

			switch (secondCommandString[0]) {					
				case 'S':
					if (IisNumber) {
						if (iParameter - 1 < blocks.getSize()) {
							// "i,S,?" number of selectors in i section
							if (thirdCommandString == "?") {
								std::cout << iParameter << ",S,? == ";
								std::cout << blocks[iParameter - 1].selectors.getSize() << '\n';
							}
							// "i,S,j" print j selector from i block
							else if (JisNumber) {
								Block& block = blocks[iParameter - 1];
								if (jParameter - 1 < block.selectors.getSize()) {
									std::cout << iParameter << ",S," << jParameter << " == ";
									std::cout << block.selectors[jParameter - 1].name << '\n';
								}
							}
						}
					}
					else if (thirdCommandString == "?") {
						// "z,S,?"
						int occurrences = 0;
						blocks.forEach([&](Block& block) {
							occurrences += block.selectors.countIf([&](const Selector& sel) -> bool { return sel.name == firstCommandString; });
							return true;
						});
						std::cout << firstCommandString << ",S,? == " << occurrences << '\n';
					}
					break;

				case 'A':
					if (IisNumber) {
						if (iParameter - 1 < blocks.getSize()) {
							// "i,A,?" number of attributes in i section
							if (thirdCommandString == "?") {
								std::cout << iParameter << ",A,? == ";
								std::cout << blocks[iParameter - 1].attributes.getSize() << '\n';
							}
							// "i,A,j" print j attribute from i block
							else if (JisNumber) {
								if (jParameter - 1 < blocks[iParameter - 1].attributes.getSize()) {
									Attribute& foundAttr = blocks[iParameter - 1].attributes[jParameter - 1];
									std::cout << iParameter << ",A," << foundAttr << '\n';
								}
							}
							// "i,A,n" print attribute with name n from i block
							else {
								Attribute* foundAttr = blocks[iParameter - 1].attributes.findIf([&](Attribute& atr) -> bool { return thirdCommandString == atr.name; });
								if (foundAttr != nullptr)
									std::cout << iParameter << ",A," << *foundAttr << '\n';
							}
						}
					}
					else if (thirdCommandString == "?") {
						// "n,A,?"
						int occurrences = 0;
						blocks.forEach([&](Block& block) {
							occurrences += block.attributes.countIf([&](const Attribute& att) -> bool { return att.name == firstCommandString; });
							return true;
						});
						std::cout << firstCommandString << ",A,? == " << occurrences << '\n';
					}
					break;

				case 'D':
					if (iParameter - 1 < blocks.getSize()) {
						// "i,D,*"
						if (thirdCommandString == "*") {
							blocks.removeAt(iParameter - 1);
							std::cout << iParameter << ",D,* == deleted\n";
						}
						// "i,D,n" remove attribute with name n from i section
						else {
							int removed = blocks[iParameter - 1].attributes.remove({thirdCommandString});
							if (removed > 0) {
								if (blocks[iParameter - 1].attributes.getSize() <= 0) {
									// if section is empty
									blocks.removeAt(iParameter - 1);
								}
								std::cout << iParameter << ",D," << thirdCommandString << " == deleted\n";
							}
						}
					}
					break;

				case 'E':
					blocks.forEach([&](Block& block) -> bool {
						if (block.selectors.findIf([&](const Selector& sel) -> bool { return sel.name == firstCommandString; }) != nullptr) {
							Attribute* foundAttr = block.attributes.findIf([&](const Attribute& attr) -> bool { return attr.name == thirdCommandString; });
							if (foundAttr != nullptr) {
								std::cout << firstCommandString << ",E,";
								std::cout << *foundAttr << '\n';
							}
							return false;
						}
						return true;
					}, true);
					break;

				default:
					break;
			}
			// discard garbage
			if (stopSign != '\n' && thirdStopS != '\n')
				if(InputScanner::readUntil(firstCommandString, "\n") == 0) return;
		}
	}

	friend std::ostream& operator<< (std::ostream& stream, Parser& parser);
};



std::ostream& operator<< (std::ostream& stream, Parser& parser) {
	int blocksSize = parser.blocks.getSize();
	stream << "[Blocks](" << blocksSize << "){\n";
	
	for (int i = 0; i < blocksSize; i++) {
		stream << parser.blocks[i] << '\n';
	}

	stream << "}\n";

	return stream;
}
