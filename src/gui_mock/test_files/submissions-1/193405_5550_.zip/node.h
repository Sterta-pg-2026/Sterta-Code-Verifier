#pragma once

#define NODE_SIZE 17

template<typename T>
class Node {
public:
	Node(Node* _prev = nullptr, Node* _next = nullptr) : next(_next), prev(_prev), data(new T* [NODE_SIZE]), dataSize(0), itemCount(0) {
		for (size_t i = 0; i < NODE_SIZE; i++) {
			this->data[i] = nullptr;
		}
	}

	Node(const Node& other) : next(nullptr), prev(nullptr), data(new T* [NODE_SIZE]), dataSize(0), itemCount(0) {
		for (size_t i = 0; i < NODE_SIZE; i++) {
			this->data[i] = nullptr;
		}
	}

	Node* getNext() const { return this->next; }
	Node* getPrev() const { return this->prev; }
	void setNext(Node* next) { this->next = next; }
	void setPrev(Node* prev) { this->prev = prev; }
	int getCount() const { return this->itemCount; }

	T* getLast() {
		return this->data[this->dataSize - 1];
	}

	T* getItem(const int index) const {
		return this->data[index];
	}

	T* addItem(const T& item) {
		if (this->dataSize < NODE_SIZE) {
			T* newItem = new T(item);
			this->data[this->dataSize] = newItem;
			this->itemCount++;
			recalculateSize();
			return newItem;
		}
		return nullptr;
	}

	void removeItem(const int index) {
		if (this->data[index] != nullptr) {
			delete this->data[index];
			this->data[index] = nullptr;
			recalculateSize();
			this->itemCount--;
		}
		return;
	}

	bool removeItem(const T* item) {
		for (int i = 0; i < NODE_SIZE; i++) {
			if (this->data[i] == item) {
				removeItem(i);
				return true;
			}
		}
		return false;
	}

	int removeMatches(const T& item) {
		int deleted = 0;
		for (int i = 0; i < NODE_SIZE; i++) {
			if (this->data[i] != nullptr && *(this->data[i]) == item) {
				removeItem(i);
				deleted++;
				return deleted;
			}
		}
		return 0;
	}

	~Node() {
		for (size_t i = 0; i < NODE_SIZE; i++) {
			if (this->data[i] != nullptr) delete this->data[i];
		}
		delete[] this->data;
	}

private:
	Node* next, * prev;
	T** data;
	int dataSize, itemCount;

	void recalculateSize() {
		this->dataSize = 0;
		for (int i = 0; i < NODE_SIZE; i++) {
			if (this->data[i] != nullptr) {
				this->dataSize = i + 1;
			}
		}
	}
};
