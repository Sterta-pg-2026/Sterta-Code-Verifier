#pragma once
#include <iostream>
#include "my_string.h"

class InputScanner {
private:
	static String buffer;
	static bool eof;
public:
	static char readUntil(String& output, const char* stopCharacters);
	static bool isEOF();
};
