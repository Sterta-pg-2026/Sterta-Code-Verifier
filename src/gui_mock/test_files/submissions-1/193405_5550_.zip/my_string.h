#pragma once
#include <iostream>

template <typename T>
inline T clamp(T v, T minv, T maxv) {
	return ((v > maxv) ? maxv : ((v < minv) ? minv : v));
}

template <typename T>
inline T max(T a, T b) {
	return ((a > b) ? a : b);
}

class String {
public:
	String(int size) {
		this->data = new char[size];
		this->end = size;
		this->realSize = size;
	}

	String() {
		this->data = new char[1];
		this->data[0] = 0;
		this->end = 0;
		this->realSize = 1;
	}

	String(const String& other) {
		this->operator=(other);
	}

	int getSize() const {
		return max(0, this->end - this->start);
	}

	bool empty() const {
		return (getSize() > 0 && (*this)[0] != 0);
	}

	// remove surrounding spaces
	void trimSpaces() {
		//check for unwanted spaces in front
		for (int i = this->start; i < this->end; i++) {
			if (this->data[i] <= ' ') {
				start++;
			}
			else break;
		}
		//check for unwanted spaces it the back
		for (int i = this->end - 1; i > this->start; i--) {
			if (this->data[i] <= ' ') {
				end--;
				this->data[end] = 0;
			}
			else break;
		}
	}

	unsigned int toInt(bool* isPure = nullptr) const {
		unsigned int num = 0;
		for (int i = start; i < end; i++) {
			int digit = data[i] - '0';
			if (digit >= 0 && digit <= 9) {
				num *= 10;
				num += digit;
			}
			else {
				if (isPure != nullptr) *isPure = false;
				return num;
			}
		}
		if (isPure != nullptr) *isPure = (getSize() > 0);
		return num;
	}

	char operator[](const int id) const  {
		return this->data[id + start];
	}

	char& operator[](const int id) {
		return this->data[id + start];
	}

	String& operator=(const String& other) {
		if (&other == this) return *this;

		if (other.realSize > 0) {
			if (this->realSize <= other.getSize()) {
				delete[] this->data;
				this->data = new char[other.getSize() + 1];
				this->realSize = other.getSize() + 1;
			}
			this->start = 0;
			this->end = other.getSize();
			for (int i = 0; i < this->end + 1; i++) {
				this->data[i] = other[i];
				if (other[i] == 0) {
					this->end = i;
					break;
				}
			}
		}
		else {
			this->data = new char[1];
			this->end = 0;
			this->start = 0;
			this->realSize = 1;
		}
		this->data[this->end] = 0;
		return *this;
	}

	bool operator==(const char* cstr) const {
		int size = getSize();
		int i = 0;
		while (cstr[i] != 0) {
			if (size < i || cstr[i] != (*this)[i]) return false;
			i++;
		}
		return (size == i);
	}

	bool operator==(const String& second) const {
		int fsize = getSize();
		int ssize = second.getSize();
		if (fsize != ssize) return false;
		for (int i = 0; i < fsize; i++) {
			if ((*this)[i] != second[i]) return false;
		}
		return true;
	}

	void setEnd(int newEnd) {
		this->end = clamp(newEnd, 0, this->realSize - 1);
	}

	void setStart(int newStart) {
		this->start = clamp(newStart, 0, this->realSize - 1);
	}

	int getStart() {
		return this->start;
	}

	void resetTrim() {
		this->start = 0;
		this->end = this->realSize;
	}

	char* getData() const {
		return this->data;
	}

	~String() {
		if(data != nullptr)
			delete[] data;
	}

	friend std::ostream& operator<< (std::ostream& stream, const String& string);

private:
	int start = 0;
	int end = 0;
	int realSize = 0;
	char* data = nullptr;
};


