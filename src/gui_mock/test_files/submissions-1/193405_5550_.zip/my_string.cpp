#include "my_string.h"

std::ostream& operator<< (std::ostream& stream, const String& string) {
	stream << (string.data + string.start);
	return stream;
}
