#include "inputscanner.h"

String InputScanner::buffer(1000);
bool InputScanner::eof = false;

// returns character which caused the stop
char InputScanner::readUntil(String& output, const char* stopCharacters) {
	int i = 0;
	char c;
	buffer[0] = 0;
	while (std::cin >> std::noskipws >> c) {
		int scId = 0;
		//check if read character matches any stopCharacter
		while (true) {
			if (stopCharacters[scId] == 0) break;
			if (stopCharacters[scId] == c) {
				buffer[i] = 0;
				buffer.setEnd(i);
				output = buffer;
				buffer.resetTrim();
				return c;
			}
			scId++;
		}
		buffer[i++] = c;
	}
	output = buffer;
	eof = true;
	return 0;
}

bool InputScanner::isEOF() {
	return eof;
}

