#include <iostream>
#include "list.h"
#include "inputscanner.h"
#include "my_string.h"
#include "parser.h"

int main() {

	Parser parser;

	while (true) {
		parser.parse();
		if (InputScanner::isEOF()) return 0;

		parser.interrogate();
		if (InputScanner::isEOF()) return 0;
	}

	return 0;
}
