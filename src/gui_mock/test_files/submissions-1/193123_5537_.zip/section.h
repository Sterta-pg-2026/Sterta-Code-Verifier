#pragma once

#include "attr.h"
#include "sele.h"

class Section
{
private:
    Selector *selectors = nullptr;
    Attribute *attributes = nullptr;
    int numberOfSele = 0;
    int numberOfAttr = 0;

public:
    Section();
    ~Section();

    void addAttr(Attribute *attr);
    void addSele(Selector *sele);
    bool removeAttrByName(char *name);

    int getNumOfSele();
    int getNumOfAttr();

    Attribute *getAttrByName(char *name);
    Selector *getSeleByName(char *name);
    Selector *getNthSele(int n);
    int getNumOfMatchingattr(char *name);
    int getNumOfMatchingSele(char *name);
};