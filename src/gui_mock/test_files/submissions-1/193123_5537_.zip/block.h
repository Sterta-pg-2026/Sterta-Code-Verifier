#pragma once

#include "section.h"

#define SEC_PER_BLOCK 17

// A two way list containing all blocks
class Block
{
private:
    Block *nextBlock = nullptr;
    Block *prevBlock = nullptr;
    Section *sections[SEC_PER_BLOCK];
    int currentIndex = 0;
    int numOfSections = 0;

public:
    bool toRemoveHead = false;
    Block();
    Block(Section *section, Block *prev, Block *next = nullptr);
    ~Block();

    Block *next();
    Block *prev();
    Section *getSection(int i);
    int deleteSection(int i);
    int getNumOfSections();

    void add(Section *section);
    // returns true if successfully deleted
    bool removeNth(int n);
    bool removeFromNthSecAttrByName(int n, char *attrName);

    int getNumOfAllBlocksSections();
    Section *getNthSec(int n);
    int getNumOfAllSeleByName(char *name);
    int getNumOfAllAttrByName(char *name);
    const char *getValueOfLastAttrOfGivenSele(char *seleName, char *attrName);
};