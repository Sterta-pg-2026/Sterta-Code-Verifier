#include <iostream>
#include "block.h"
#include "cssloader.h"

using namespace std;

int main()
{
    Block *block = new Block();
    Loader loader(block);
    loader.load();

    return 0;
}