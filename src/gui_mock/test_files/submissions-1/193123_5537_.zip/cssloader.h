#pragma once

#include <cstdio>
#include <string.h>
#include "block.h"
#include "simplestr.h"

using namespace std;

class Loader
{
	// Loads
	Block *block;

public:
	Loader(Block *block);
	void load();

private:
	void getSection(char firstChar);
	void getSelectors(char firstChar, Section *sec);
	void getAttributes(Section *sec);
	void handleCommands(char firstChar);
	void executeCommand(SimpleSTR &arg1, SimpleSTR &arg2, SimpleSTR &command);

	// commands
	void questionMarkCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2);
	void SCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2);
	void ACommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2);
	void ECommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2);
	void DCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2);
};