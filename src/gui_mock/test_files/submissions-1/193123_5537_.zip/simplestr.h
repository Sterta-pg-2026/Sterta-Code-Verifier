#pragma once

#include <iostream>

using namespace std;

class SimpleSTR
{
	char *str;
	int totalLength = 1;

public:
	SimpleSTR(const char *str);
	~SimpleSTR();

	char operator[](int index);
	const char operator[](int index) const;

	void operator+=(const SimpleSTR &addition);
	void operator+=(char addition);

	bool operator==(const SimpleSTR &str2);
	SimpleSTR &operator=(const SimpleSTR &other);

	friend ostream &operator<<(ostream &os, const SimpleSTR &str);

	int len();
	int toInt();
	char *getStr();

	void rmWhitespacesOnEdges();
};

ostream &operator<<(ostream &os, const SimpleSTR &str);