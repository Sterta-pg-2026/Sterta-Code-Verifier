#include "block.h"
#include <iostream>

Block::Block()
{
    for (int i = 0; i < SEC_PER_BLOCK; i++)
    {
        this->sections[i] = nullptr;
    }
}

Block::Block(Section *section, Block *prev, Block *next)
{
    this->sections[0] = section;
    for (int i = 1; i < SEC_PER_BLOCK; i++)
    {
        this->sections[i] = nullptr;
    }
    this->currentIndex++;
    this->numOfSections++;
    this->prevBlock = prev;
    this->nextBlock = next;
}

Block::~Block()
{
    if (nextBlock != nullptr && prevBlock != nullptr)
    {
        prevBlock->nextBlock = nextBlock;
        nextBlock->prevBlock = prevBlock;
    }
    else if (nextBlock != nullptr)
    {
        nextBlock->prevBlock = nullptr;
    }
    else if (prevBlock != nullptr)
    {
        prevBlock->nextBlock = nullptr;
    }
    delete sections[0];
}

Block *Block::next()
{
    return nextBlock;
}

Block *Block::prev()
{
    return prevBlock;
}

Section *Block::getSection(int i)
{
    for (int k = 0; k < SEC_PER_BLOCK; k++)
    {
        if (i == 0 && sections[k] != nullptr)
        {
            return sections[k];
        }
        if (sections[k] != nullptr)
        {
            i--;
        }
    }
    return nullptr;
}

// returns index of removed
// if negative remove failed
int Block::deleteSection(int i)
{
    for (int k = 0; k < SEC_PER_BLOCK; k++)
    {
        if (i == 0 && sections[k] != nullptr)
        {
            delete sections[k];
            return k;
        }
        if (sections[k] != nullptr)
        {
            i--;
        }
    }
    return -1;
}

int Block::getNumOfSections()
{
    return numOfSections;
}

void Block::add(Section *section)
{
    Block *cur = this;
    while (cur->currentIndex >= SEC_PER_BLOCK)
    {
        // If there is no available space create another block
        if (cur->nextBlock == nullptr)
        {
            cur->nextBlock = new Block(section, cur);
            return;
        }
        cur = cur->nextBlock;
    }
    cur->sections[cur->currentIndex] = section;
    cur->currentIndex++;
    cur->numOfSections++;
}

bool Block::removeNth(int n)
{
    Block *cur = this;
    int skippedSec = 0;
    while (skippedSec < n)
    {
        if (cur->next() == nullptr)
        {
            break;
        }
        skippedSec += cur->getNumOfSections();
        cur = cur->next();
    }
    if (cur->getNumOfSections() < n - skippedSec)
    {
        return false;
    }
    if (n - skippedSec <= 0)
    {
        cur = cur->prev();
        skippedSec -= cur->getNumOfSections();
    }
    if (cur->sections[n - skippedSec - 1] == nullptr)
    {
        return false;
    }
    int index = cur->deleteSection(n - skippedSec);
    // delete cur->sections[n - skippedSec - 1];
    cur->sections[index] = nullptr;
    if (index == cur->currentIndex - 1)
    {
        cur->currentIndex--;
    }
    cur->numOfSections--;
    if (numOfSections == 0)
    {
        if (cur == this)
        {
            toRemoveHead = true;
            return false;
        }
        delete cur;
    }
    return true;
}

bool Block::removeFromNthSecAttrByName(int n, char *attrName)
{
    Block *cur = this;
    int skippedSec = 0;
    while (skippedSec < n)
    {
        if (cur->next() == nullptr)
        {
            break;
        }
        skippedSec += cur->getNumOfSections();
        cur = cur->next();
    }
    if (cur->getNumOfSections() < n - skippedSec)
    {
        return false;
    }
    if (n - skippedSec <= 0)
    {
        cur = cur->prev();
        skippedSec -= cur->getNumOfSections();
    }

    Section *sec;
    for (int i = 0; i < SEC_PER_BLOCK; i++)
    {
        sec = cur->sections[i];
        if (sec == nullptr)
        {
            continue;
        }
        if (skippedSec == n - 1)
        {
            break;
        }
        skippedSec++;
    }
    if (sec == nullptr)
    {
        return false;
    }

    if (sec->removeAttrByName(attrName))
    {
        if (sec->getNumOfAttr() == 0)
        {
            delete sec;
            cur->sections[n - skippedSec] = nullptr;
            numOfSections--;
        }
        return true;
    }
    return false;
}

int Block::getNumOfAllBlocksSections()
{
    int numOfSec = 0;
    Block *cur = this;
    while (cur->next() != nullptr)
    {
        numOfSec += cur->getNumOfSections();
        cur = cur->next();
    }
    numOfSec += cur->getNumOfSections();
    return numOfSec;
}

// n == 0 means that we want first section
Section *Block::getNthSec(int n)
{
    int skippedSele = 0;
    Block *cur = this;
    while (skippedSele < n)
    {
        if (cur->next() == nullptr)
        {
            break;
        }
        skippedSele += cur->getNumOfSections();
        cur = cur->next();
    }
    if (skippedSele >= n)
    {
        cur = cur->prevBlock;
        skippedSele -= cur->getNumOfSections();
    }
    return cur->getSection(n - skippedSele - 1);
}

int Block::getNumOfAllSeleByName(char *name)
{
    Block *cur = this;
    int matches = 0;
    while (cur != nullptr)
    {
        for (int i = 0; i < SEC_PER_BLOCK; i++)
        {
            Section *sec = cur->getSection(i);
            if (sec == nullptr)
                continue;

            matches += sec->getNumOfMatchingSele(name);
        }
        cur = cur->next();
    }
    return matches;
}

int Block::getNumOfAllAttrByName(char *name)
{
    Block *cur = this;
    int matches = 0;
    while (cur != nullptr)
    {
        for (int i = 0; i < SEC_PER_BLOCK; i++)
        {
            Section *sec = cur->getSection(i);
            if (sec == nullptr)
                continue;

            matches += sec->getNumOfMatchingattr(name);
        }
        cur = cur->next();
    }
    return matches;
}

const char *Block::getValueOfLastAttrOfGivenSele(char *seleName, char *attrName)
{
    // getting the last block
    Block *cur = this;
    while (true)
    {
        if (cur->next() == nullptr)
        {
            break;
        }
        cur = cur->next();
    }
    while (cur != nullptr)
    {
        for (int i = SEC_PER_BLOCK - 1; i >= 0; i--)
        {
            Section *sec = cur->getSection(i);
            if (sec == nullptr)
                continue;
            if (sec->getSeleByName(seleName) == nullptr)
                continue;
            Attribute *attr = sec->getAttrByName(attrName);
            if (attr == nullptr)
            {
                continue;
            }
            return attr->getValue();
        }
        cur = cur->prev();
    }
    return nullptr;
}
