#pragma once

class Attribute
{
private:
    char *name = nullptr;
    char *value = nullptr;
    Attribute *nextAttr = nullptr;

    // if the attributes' name are the same returns true
    bool isAttrSame(Attribute *newAttr, Attribute *checkedAttr);

public:
    Attribute(const char *name, const char *value);
    ~Attribute();

    bool addNext(Attribute *next);

    void setValue(const char *value);

    void setNext(Attribute *next);

    const char *getValue();

    const char *getName();

    Attribute *next();
};