#include <cstdio>
#include <string.h>
#include "block.h"
#include "simplestr.h"
#include "cssloader.h"

using namespace std;

#define COMMAND_SECTION_CHAR '?'
#define NUMBER_OF_COMMAND_SECTION_CHAR 4
#define CSS_SECTION_CHAR '*'
#define EMPTY_COMMAND_ARG '?'

Loader::Loader(Block *block) : block{block}
{
}

// Loads the CSS and commands and executes them
void Loader::load()
{
	char character = NULL;
	while (true)
	{
		character = getchar();
		if (character < ' ')
		{
			continue;
		}
		switch (character)
		{
		// a command section
		// delegates it to handle commands
		case COMMAND_SECTION_CHAR:
			handleCommands(character);
			break;

		// ignoring the enter
		case '\n':
			continue;

		case EOF:
			return;

		// Assume that it is start of a section so either a normal character or "*"
		default:
			getSection(character);
			break;
		}
	}
}

// Loads the section from the input and adds it to the block
void Loader::getSection(char firstChar)
{
	// skips the "*" as this character indicates only start of css section
	while (firstChar == CSS_SECTION_CHAR)
	{
		firstChar = getchar();
	}
	Section *sec = new Section();
	getSelectors(firstChar, sec);
	getAttributes(sec);
	block->add(sec);
}

void Loader::getSelectors(char character, Section *sec)
{
	while (character != '{')
	{
		SimpleSTR str("");
		str += character;
		while (character != ',' && character != '{')
		{
			character = getchar();
			if (character == ',')
			{
				// gets the next char to check if it will be "{"
				character = getchar();
				break;
			}
			// skipping the enter
			else if (character == '\n')
			{
				continue;
			}
			else if (character == '{')
			{
				break;
			}

			str += character;
		}
		str.rmWhitespacesOnEdges();
		sec->addSele(new Selector(str.getStr()));
	}
}

void Loader::getAttributes(Section *sec)
{
	char character = NULL;
	while (character != '}')
	{
		SimpleSTR attrName("");
		SimpleSTR attrValue("");
		// attribute name
		while (character != '}')
		{
			character = getchar();
			// end of attr name
			if (character == ':')
			{
				break;
			}
			// section arguments end
			else if (character == '}')
			{
				return;
			}
			// skipping the enter
			else if (character == '\n')
			{
				continue;
			}
			attrName += character;
		}
		// attr value
		while (true)
		{
			character = getchar();
			// end of attr value
			if (character == '}' || character == ';')
			{
				break;
			}
			// skipping the enter
			else if (character == '\n')
			{
				continue;
			}
			attrValue += character;
		}
		attrName.rmWhitespacesOnEdges();
		attrValue.rmWhitespacesOnEdges();
		sec->addAttr(new Attribute(attrName.getStr(), attrValue.getStr()));
	}
}

// gets and executes commands
void Loader::handleCommands(char character)
{
	// As commands section starts skips over the "????"
	// which indicates start of a command section
	// we start at 1 because we have already taken in first COMMAND SECTION CHAR
	for (int i = 1; i < NUMBER_OF_COMMAND_SECTION_CHAR; i++)
	{
		character = getchar();
	}

	while (true)
	{
		SimpleSTR arg1("");
		SimpleSTR command("");
		SimpleSTR arg2("");
		// getting first argument
		while (true)
		{
			character = getchar();
			if (character == ',')
			{
				break;
			}
			else if (character == CSS_SECTION_CHAR)
			{
				return;
			}
			// the special case comand - ?
			else if (character == '?')
			{
				command += character;
				break;
			}
			else if (character == '\n')
			{
				continue;
			}
			else if (character == EOF)
			{
				exit(0);
			}
			arg1 += character;
		}
		// getting command
		while (character != '?')
		{
			character = getchar();
			if (character == ',')
			{
				break;
			}
			command += character;
		}
		// getting second argument
		while (character != '?')
		{
			character = getchar();
			if (character == '\n')
			{
				break;
			}
			arg2 += character;
		}
		arg1.rmWhitespacesOnEdges();
		arg2.rmWhitespacesOnEdges();
		command.rmWhitespacesOnEdges();
		executeCommand(arg1, command, arg2);
	}
}

void Loader::executeCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	switch (command[0])
	{
	case '?':
		questionMarkCommand(arg1, command, arg2);
		break;

	case 'S':
		SCommand(arg1, command, arg2);
		break;

	case 'A':
		ACommand(arg1, command, arg2);
		break;

	case 'E':
		ECommand(arg1, command, arg2);
		break;
	case 'D':
		DCommand(arg1, command, arg2);
		break;

	default:
		return;
	}
}

void Loader::questionMarkCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	if (block == nullptr)
	{
		cout << "? == 0" << endl;
		return;
	}
	cout << "? == " << block->getNumOfAllBlocksSections() << endl;
}

void Loader::SCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	// arg2 was given
	if (arg2[0] != '?')
	{
		int a1, a2;
		a1 = arg1.toInt();
		a2 = arg2.toInt();
		if (a1 < 0 || a2 < 0)
		{
			return;
		}

		Section *sec = block->getNthSec(a1);
		if (sec == nullptr)
		{
			return;
		}
		Selector *sele = sec->getNthSele(a2);
		if (sele == nullptr)
		{
			return;
		}
		cout << arg1 << ',' << command << ',' << arg2 << " == " << sele->getName() << endl;
		return;
	}
	// checking if arg1 is a number
	int a1 = arg1.toInt();
	if (a1 < 0)
	{
		cout << arg1 << ',' << command << ',' << arg2 << " == " << block->getNumOfAllSeleByName(arg1.getStr()) << endl;
		return;
	}
	Section *sec = block->getNthSec(a1);
	if (sec == nullptr)
	{
		return;
	}
	cout << arg1 << ',' << command << ',' << arg2 << " == " << sec->getNumOfSele() << endl;
}

void Loader::ACommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	// arg2 was given
	if (arg2[0] != '?')
	{
		int a1;
		a1 = arg1.toInt();
		if (a1 < 0)
		{
			return;
		}
		Section *sec = block->getNthSec(a1);
		if (sec == nullptr)
		{
			return;
		}
		Attribute *attr = sec->getAttrByName(arg2.getStr());
		if (attr == nullptr)
		{
			return;
		}
		cout << arg1 << ',' << command << ',' << arg2 << " == " << attr->getValue() << endl;
		return;
	}
	// checking if arg1 is a number
	int a1 = arg1.toInt();
	if (a1 < 0)
	{
		cout << arg1 << ',' << command << ',' << arg2 << " == " << block->getNumOfAllAttrByName(arg1.getStr()) << endl;
		return;
	}
	Section *sec = block->getNthSec(a1);
	if (sec == nullptr)
	{
		return;
	}
	cout << arg1 << ',' << command << ',' << arg2 << " == " << sec->getNumOfAttr() << endl;
}

void Loader::ECommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	const char *value = block->getValueOfLastAttrOfGivenSele(arg1.getStr(), arg2.getStr());
	if (value == nullptr)
	{
		return;
	}
	cout << arg1 << ',' << command << ',' << arg2 << " == " << value << endl;
}

void Loader::DCommand(SimpleSTR &arg1, SimpleSTR &command, SimpleSTR &arg2)
{
	if (arg2[0] == '*')
	{
		int a1;

		a1 = arg1.toInt();
		if (a1 < 0)
		{
			return;
		}
		if (block->removeNth(a1))
		{
			cout << arg1 << ',' << command << ',' << arg2 << " == deleted" << endl;
		}
		else if (block->toRemoveHead)
		{
			Block *oldHead = block;
			block = block->next();
			delete oldHead;
			cout << arg1 << ',' << command << ',' << arg2 << " == deleted" << endl;
		}
	}
	else
	{
		int a1;
		a1 = arg1.toInt();
		if (a1 < 0)
		{
			return;
		}
		if (block->removeFromNthSecAttrByName(a1, arg2.getStr()))
		{
			cout << arg1 << ',' << command << ',' << arg2 << " == deleted" << endl;
		}
	}
}
