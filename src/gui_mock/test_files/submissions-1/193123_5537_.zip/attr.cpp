#define _CRT_SECURE_NO_WARNINGS
#include "attr.h"
#include <string.h>

Attribute::Attribute(const char *name, const char *value)
{
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
    this->value = new char[strlen(value) + 1];
    strcpy(this->value, value);
}

Attribute::~Attribute()
{
    if (name != nullptr)
    {
        delete[] name;
    }
    if (value != nullptr)
    {
        delete[] value;
    }
    if (nextAttr != nullptr)
    {
        delete nextAttr;
    }
    nextAttr = nullptr;
}

bool Attribute::isAttrSame(Attribute *newAttr, Attribute *checkedAttr)
{
    if (!strcmp(newAttr->getName(), checkedAttr->getName()))
    {
        return true;
    }
    return false;
}

// Loops over the attr list and adds the given attr at the end
// If another attr with the same name is found its value is replaced by given value
// Returns true if the attribute was added
bool Attribute::addNext(Attribute *nextAttr)
{
    Attribute *cur = this;
    if (isAttrSame(nextAttr, cur))
    {
        cur->setValue(nextAttr->getValue());
        return false;
    }
    while (cur->next() != nullptr)
    {
        cur = cur->next();
        if (isAttrSame(nextAttr, cur))
        {
            cur->setValue(nextAttr->getValue());
            return false;
        }
    }
    cur->nextAttr = nextAttr;
    return true;
}

void Attribute::setNext(Attribute *next)
{
    nextAttr = next;
}

Attribute *Attribute::next()
{
    return this->nextAttr;
}

const char *Attribute::getName()
{
    return this->name;
}

const char *Attribute::getValue()
{
    return this->value;
}

void Attribute::setValue(const char *value)
{
    if (this->value != nullptr)
    {
        delete[] this->value;
    }
    this->value = new char[strlen(value) + 1];
    strcpy(this->value, value);
}
