#include <string.h>
#include "section.h"
#include "attr.h"
#include "sele.h"

Section::Section() {}

Section::~Section()
{
    if (selectors != nullptr)
    {
        delete selectors;
    }
    if (attributes != nullptr)
    {
        delete attributes;
    }
    this->selectors = nullptr;
    this->attributes = nullptr;
}

void Section::addAttr(Attribute *attr)
{
    if (attributes == nullptr)
    {
        attributes = attr;
        numberOfAttr++;
        return;
    }
    if (attributes->addNext(attr))
    {
        numberOfAttr++;
    }
    else
    {
        delete attr;
    }
}

void Section::addSele(Selector *sele)
{
    if (selectors == nullptr)
    {
        selectors = sele;
        numberOfSele++;
        return;
    }
    if (selectors->addNext(sele))
    {
        numberOfSele++;
    }
    else
    {
        delete sele;
    }
}

bool Section::removeAttrByName(char *name)
{
    Attribute *cur = attributes;
    Attribute *bef = nullptr;
    while (cur != nullptr)
    {
        if (!strcmp(cur->getName(), name))
        {
            if (bef != nullptr)
            {
                bef->setNext(cur->next());
            }
            else
            {
                attributes = cur->next();
            }
            cur->setNext(nullptr);
            delete cur;
            numberOfAttr--;
            return true;
        }
        bef = cur;
        cur = cur->next();
    }
    return false;
}

int Section::getNumOfSele()
{
    return numberOfSele;
}

int Section::getNumOfAttr()
{
    return numberOfAttr;
}

Attribute *Section::getAttrByName(char *name)
{
    Attribute *cur = attributes;
    while (cur != nullptr)
    {
        if (!strcmp(cur->getName(), name))
        {
            return cur;
        }
        cur = cur->next();
    }
    return nullptr;
}

Selector *Section::getSeleByName(char *name)
{
    Selector *cur = selectors;
    while (cur != nullptr)
    {
        if (!strcmp(cur->getName(), name))
        {
            return cur;
        }
        cur = cur->next();
    }
    return nullptr;
}

Selector *Section::getNthSele(int n)
{
    // subtracting 1 because n starts from 1 not 0
    n -= 1;
    Selector *cur = selectors;
    for (int i = 0; i < n; i++)
    {
        if (cur == nullptr)
        {
            return nullptr;
        }
        cur = cur->next();
    }
    return cur;
}

int Section::getNumOfMatchingattr(char *name)
{
    int matches = 0;
    Attribute *cur = attributes;
    while (cur != nullptr)
    {
        if (!strcmp(cur->getName(), name))
        {
            matches++;
        }
        cur = cur->next();
    }
    return matches;
}
int Section::getNumOfMatchingSele(char *name)
{
    int matches = 0;
    Selector *cur = selectors;
    while (cur != nullptr)
    {
        if (!strcmp(cur->getName(), name))
        {
            matches++;
        }
        cur = cur->next();
    }
    return matches;
}