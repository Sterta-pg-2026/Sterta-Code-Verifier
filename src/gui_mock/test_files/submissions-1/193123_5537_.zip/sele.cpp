#include "sele.h"
#include <string.h>

Selector::Selector(const char* name)
{
    this->name = new char[strlen(name)+1];
    strcpy(this->name, name);
}

Selector::~Selector()
{
    if (name != nullptr)
    {
        delete[] name;
    }
    if (nextSele != nullptr)
    {
        delete nextSele;
    }
    nextSele = nullptr;
}

bool Selector::isSeleSame(Selector* newSele, Selector* checkedSele) {
    if (!strcmp(newSele->getName(), checkedSele->getName()))
    {
        return true;
    }
    return false;
}

// Loops over the selector list and adds the given selector at the end
// If another selector with the same name is found it just returns false
// Returns true if the new selector was added
bool Selector::addNext(Selector* nextSele)
{
    Selector* cur = this;
    if (isSeleSame(nextSele, cur)) {
        return false;
    }
    while (cur->next() != nullptr)
    {
        cur = cur->next();
        if (isSeleSame(nextSele, cur)) {
            return false;
        }
    }
    cur->nextSele = nextSele;
    return true;
}

Selector* Selector::next()
{
    return this->nextSele;
}

char* Selector::getName()
{
    return this->name;
}