#define _CRT_SECURE_NO_WARNINGS
#pragma once

class Selector
{
private:
    char* name = nullptr;
    Selector* nextSele = nullptr;

    bool isSeleSame(Selector* newSele, Selector* checkedSele);

public:
    Selector(const char* name);
    ~Selector();

    bool addNext(Selector* nextSele);

    char* getName();

    Selector* next();
};