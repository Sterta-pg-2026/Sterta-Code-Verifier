#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#include "simplestr.h"
#include <iostream>

using namespace std;

SimpleSTR::SimpleSTR(const char *str)
{
	int length = strlen(str) + 1;
	while (totalLength <= length)
	{
		totalLength *= 2;
	}
	this->str = new char[totalLength];
	strcpy(this->str, str);
}

SimpleSTR::~SimpleSTR()
{
	if (str != nullptr)
	{
		delete[] str;
	}
}

char SimpleSTR::operator[](int index)
{
	return str[index];
}

const char SimpleSTR::operator[](int index) const
{
	return str[index];
}

void SimpleSTR::operator+=(const SimpleSTR &addition)
{
	int neededLength = len() + strlen(addition.str) + 1;
	if (neededLength > totalLength)
	{
		while (totalLength <= neededLength)
		{
			totalLength *= 2;
		}
		char *buffer = new char[totalLength];
		strcpy(buffer, str);
		strcat(buffer, addition.str);
		delete[] str;
		str = buffer;
	}
	else
	{
		strcat(str, addition.str);
	}
}

void SimpleSTR::operator+=(const char addition)
{
	int neededLength = len() + 2;
	if (neededLength > totalLength)
	{
		totalLength *= 2;

		char *buffer = new char[totalLength];
		strcpy(buffer, str);
		buffer[neededLength - 2] = addition;
		buffer[neededLength - 1] = '\0';
		delete[] str;

		str = buffer;
	}
	else
	{
		str[neededLength - 2] = addition;
		str[neededLength - 1] = '\0';
	}
}

bool SimpleSTR::operator==(const SimpleSTR &str2)
{
	return !(strcmp(str, str2.str));
}

SimpleSTR &SimpleSTR::operator=(const SimpleSTR &other)
{
	this->str = new char[other.totalLength];
	strcpy(this->str, other.str);
	this->totalLength = other.totalLength;
	return *this;
}

int SimpleSTR::toInt()
{
	int start = 0;
	if (str[0] == '-')
	{
		start = 1;
	}
	for (int i = start; i < len(); i++)
	{
		if (!isdigit(str[i]))
		{
			return -1;
		}
	}
	return atoi(str);
}

int SimpleSTR::len()
{
	return strlen(str);
}

char *SimpleSTR::getStr()
{
	return str;
}

void SimpleSTR::rmWhitespacesOnEdges()
{
	int start = 0, end = 0;
	int length = len();
	for (int i = 0; i < length; i++)
	{
		if (!isspace(str[i]))
		{
			start = i;
			break;
		}
	}
	for (int i = length - 1; i >= 0; i--)
	{
		if (!isspace(str[i]))
		{
			end = i;
			break;
		}
	}
	for (int i = 0; i <= end - start; i++)
	{
		str[i] = str[i + start];
	}
	str[end - start + 1] = '\0';
}

ostream &operator<<(ostream &os, const SimpleSTR &str)
{
	os << str.str;
	return os;
}