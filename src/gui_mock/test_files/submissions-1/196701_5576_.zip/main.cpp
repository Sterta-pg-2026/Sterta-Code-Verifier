#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct attributes {
	char property[100], value[100];
	struct attributes* next;
}attributes;
typedef struct selectors {
	char selector[100];
	struct selectors* next;
}selectors;
typedef struct sections {
	int count_s, count_a;
	struct selectors* s_head;
	struct attributes* a_head;
	struct sections* next, * prev;
}sections;
typedef struct MyList {
	int count;
	struct sections* head;
	struct sections* tail;
}MyList;
void Read(MyList** list);
MyList* Create_my_list();
void Add_selector(selectors** list, char* dana, bool& same);
void Add_to_selectors(selectors** list, selectors* new_item);
void Add_attribute(attributes** list, char* dana1, char* dana2, bool& same);
void Add_to_attributes(attributes** list, attributes* new_item);
void Add_to_sections(MyList** list, sections* new_item);
void Delete_f(char* str);
void Delete_b(char* str);
void Free_the_memory(MyList** list);
void Listen_commends(MyList** list);
bool Check_if_int(char* str);
sections* Get_section(MyList* list, int ind);
int Count_selectors(MyList* list, char* str);
selectors* Get_selector(sections* list, int ind);
int Count_attributes(MyList* list, char* str);
char* Get_value(sections* list, char* str);
char* Get_value1(MyList* list, char* selector, char* attribute);
void Delete_section(MyList** list, int ind, bool& verify);
void Delete_attribute(MyList** list, int ind, char* str, bool& verify);
int main()
{
	MyList* List = Create_my_list();
	Read(&List);
	Listen_commends(&List);
	Free_the_memory(&List);
	return 0;
}
MyList* Create_my_list()
{
	MyList* h = (MyList*)malloc(sizeof(MyList));
	h->count = 0;
	h->head = NULL;
	h->tail = NULL;
	return h;
}
void Read(MyList** list)
{
	char input[1000] = {}, tmp[1000] = {};
		while (input != "????")
		{
			fgets(input, sizeof(input), stdin);
			while(input[0] == '\n'|| input[0] == '\0' || input[0] == ' ' || input[0] == '\t')fgets(input, sizeof(input), stdin);
			while (input[strlen(input) - 1] == ' ' || input[strlen(input) - 1] == '\n') Delete_b(input);
			if (!strcmp(input, "????")) break;
			sections* new_section = (sections*)malloc(sizeof(sections));
			new_section->next = NULL;
			new_section->prev = (*list)->tail;
			new_section->count_a = 0;
			new_section->count_s = 0;
			new_section->a_head = NULL;
			new_section->s_head = NULL;
				int size = strlen(input);
			if (input[size - 1] != '}')
			{
				while (true)
				{
					char delim[] = ",";
					strcpy(tmp, input);
					char* dana = strtok(tmp, delim);
					if (dana[0]=='{');
					else while (dana != NULL)
					{
						new_section->count_s++;
						while(dana[0]==' ' || dana[0] == '\t') Delete_f(dana);
						while (dana[strlen(dana) - 1] == ' '|| dana[strlen(dana) - 1] == '{'|| dana[strlen(dana) - 1] == '\n') Delete_b(dana);
						bool same = false;
						Add_selector(&(new_section->s_head), dana, same);
						if(same)new_section->count_s--;
						dana = strtok(NULL, delim);
					}
					if (input[strlen(input) - 1] == ',')
					{
						fgets(input, sizeof(input), stdin);
						while (input[strlen(input) - 1] == ' ' || input[strlen(input) - 1] == '\n') Delete_b(input);
					}
					else break;
				}
				char delim[] = ":";
				fgets(input, sizeof(input), stdin);
				if(input[0]=='{')fgets(input, sizeof(input), stdin);
				while (input != "}")
				{
					if (input[0] == '}')break;
					new_section->count_a++;
					char* dana = strtok(input, delim);
					char* dana1 = dana;
					dana = strtok(NULL, delim);
					char* dana2 = dana;
					bool same = false;
					while (dana1[0] == ' ' || dana1[0] == '\t') Delete_f(dana1);
					while (dana2[0] == ' ' || dana1[0] == '\t') Delete_f(dana2);
					while (dana1[strlen(dana1) - 1] == ' '|| dana1[strlen(dana1) - 1] == '\n') Delete_b(dana1);
					while (dana2[strlen(dana2) - 1] == ' '|| dana2[strlen(dana2) - 1] == '\n'|| dana2[strlen(dana2) - 1] == ';') Delete_b(dana2);
					Add_attribute(&(new_section->a_head), dana1, dana2, same);
					if(same)new_section->count_a--;
					fgets(input, sizeof(input), stdin);
					while (input[0] == ' ' || input[0] == '\t') Delete_f(input);
				}
			}
			else
			{
				char delim[] = "{";
				char* str1 = strtok(input, delim);
				char* str2 = strtok(NULL, delim);
				strcpy(delim, ",");
				char* dana = strtok(str1, delim);
				while (dana != NULL)
				{
					new_section->count_s++;
					while (dana[0] == ' ' || dana[0] == '\t') Delete_f(dana);
					while (dana[strlen(dana) - 1] == ' ' || dana[strlen(dana) - 1] == '{' || dana[strlen(dana) - 1] == '\n') Delete_b(dana);
					bool same = false;
					Add_selector(&(new_section->s_head), dana, same);
					dana = strtok(NULL, delim);
				}
				new_section->count_a++;
				strcpy(delim, ":");
				dana = strtok(str2, delim);
				char* dana1 = dana;
				dana = strtok(NULL, delim);
				char* dana2 = dana;
				bool same;
				while (dana1[0] == ' ' || dana1[0] == '\t') Delete_f(dana1);
				while (dana2[0] == ' ' || dana1[0] == '\t') Delete_f(dana2);
				while (dana1[strlen(dana1) - 1] == ' ' || dana1[strlen(dana1) - 1] == '\n') Delete_b(dana1);
				while (dana2[strlen(dana2) - 1] == ' ' || dana2[strlen(dana2) - 1] == '\n' || dana2[strlen(dana2) - 1] == ';' || dana2[strlen(dana2) - 1] == '}') Delete_b(dana2);
				Add_attribute(&(new_section->a_head), dana1, dana2, same);
			}
			Add_to_sections(list, new_section);
			(*list)->count++;
		}
}
void Add_selector(selectors * *list, char* dana, bool& same)
{
	for (selectors* i = *list; i != NULL; i = i->next)
	{
		if (!strcmp(i->selector, dana)) {
			same = true;
			return;
		}
	}
	selectors* new_selector = (selectors*)malloc(sizeof(selectors));
	strcpy(new_selector->selector, dana);
	new_selector->next = NULL;
	Add_to_selectors(list, new_selector);
}
void Add_to_selectors(selectors** list, selectors* new_item)
{
	if (*list == NULL)
	{
		*list = new_item;
	}
	else
	{
		for (selectors* i = *list; i!=NULL ; i=i->next)
		{
			if (i->next == NULL) {
				i->next = new_item;
				break;
			}
		}
	}
}
void Add_attribute(attributes** list, char* dana1, char* dana2, bool& same)
{
	for (attributes* i = *list; i != NULL; i = i->next)
	{
		if (!strcmp(i->property, dana1)) {
			strcpy(i->value , dana2);
			same = true;
			return;
		}
	}
		attributes* new_attribute = (attributes*)malloc(sizeof(attributes));
		strcpy(new_attribute->property, dana1);
		strcpy(new_attribute->value, dana2);
		new_attribute->next = NULL;
		Add_to_attributes(list, new_attribute);
}
void Add_to_attributes(attributes** list, attributes* new_item)
{
	if (*list == NULL)
	{
		*list = new_item;
	}
	else
	{
		for (attributes* i = *list; i != NULL; i = i->next)
		{
			if (i->next == NULL) {
				i->next = new_item;
				break;
			}
		}
	}
}
void Add_to_sections(MyList** list, sections* new_item)
{
	if (((*list)->tail != NULL))
	{
		(*list)->tail->next = new_item;
	}
	(*list)->tail = new_item;
	if ((*list)->head == NULL)
	{
		(*list)->head = new_item;
	}
}
void Delete_f(char* str)
{
	for (int i = 0; i < strlen(str); i++)
		str[i] = str[i + 1];
}
void Delete_b(char* str)
{
	str[strlen(str) - 1] = '\0';
}
void Free_the_memory(MyList** list)
{
	sections* tmp = (*list)->head;
	sections* next = NULL;
	while (tmp) {
		next = tmp->next;
		free(tmp);
		tmp = next;
	}
	free(*list);
	(*list) = NULL;
}
void Listen_commends(MyList** list)
{
	char input[100] = {};
	while (fgets(input, sizeof(input), stdin)) {
		if (input[0] == '\n' || input[0] == '\0' || input[0] == ' ' || input[0] == '\t')if(!fgets(input, sizeof(input), stdin))break;
		while (input[strlen(input) - 1] == ' ' || input[strlen(input) - 1] == '\n') Delete_b(input);
		char delim[] = ",";
		char tmp[100];
		strcpy(tmp, input);
		char* dana1 = strtok(tmp, delim);
		char* dana2 = strtok(NULL, delim);
		char* dana3 = strtok(NULL, delim);
		if (!strcmp(input, "****")) Read(list);
		else if (!strcmp(input, "?")) printf("? == %d\n", (*list)->count);
		else if (!strcmp(dana2, "S"))
		{
			if (!strcmp(dana3, "?"))
			{
				if (Check_if_int(dana1))
				{
					int index = atoi(dana1);
					sections* output = Get_section((*list), index);
					if (output != NULL) 
					{
						printf("%s == %d\n", input, output->count_s);
					}
				}
				else
				{
					printf("%s == %d\n", input, Count_selectors(*list, dana1));
				}
			}
			else
			{
				int i = atoi(dana1);
				int j = atoi(dana3);
				if (i <= (*list)->count)
				{
					selectors* output = Get_selector(Get_section(*list, i), j);
					if (output != NULL) printf("%s == %s\n", input, output->selector);
				}
			}
		}
		else if (!strcmp(dana2, "A"))
		{
			if (!strcmp(dana3, "?"))
			{
				if (Check_if_int(dana1))
				{
					int index = atoi(dana1);
					sections* output = Get_section((*list), index);
					if (output != NULL)
					{
						printf("%s == %d\n", input, output->count_a);
					}
				}
				else
				{
					printf("%s == %d\n", input, Count_attributes(*list, dana1));
				}
			}
			else if (Check_if_int(dana1))
			{
				int i = atoi(dana1);
				char* output = Get_value(Get_section((*list), i), dana3);
				if (output != NULL) 
				{
					printf("%s == %s\n", input, output);
				}
			}
		}
		else if (!strcmp(dana2, "E") && !Check_if_int(dana1) && !Check_if_int(dana3))
		{
			char* output = Get_value1(*list, dana1, dana3);
			if (output != NULL) printf("%s == %s\n", input, output);
		}
		else if (!strcmp(dana2, "D"))
		{
			if (!strcmp(dana3, "*")&& Check_if_int(dana1))
			{
				int index = atoi(dana1);
				bool verify = false;
				Delete_section(list, index, verify);
				if (verify) printf("%s == deleted\n", input);
			}
			else
			{
				int index = atoi(dana1);
				bool verify = false;
				Delete_attribute(list, index, dana3, verify);
				
				if(verify)printf("%s == deleted\n", input);
			}
		}
	}
}
bool Check_if_int(char* str)
{
	for (int i = 0; i < strlen(str); i++)
	{
		if (!isdigit(str[i])) return false;
	}
	return true;
}
sections* Get_section(MyList* list, int ind)
{
	if (list->count < ind) return NULL;
	int j;
	if (ind <= list->count / 2)
	{
		j = 1;
		for (sections* i = list->head; i != NULL; i = i->next)
		{
			if (j == ind) return i;
			j++;
		}
	}
	else
	{
		j = list->count;
		for (sections* i = list->tail; i != NULL; i = i->prev)
		{
			if (j == ind) return i;
			j--;
		}
	}
	return NULL;
}
int Count_selectors(MyList* list, char* str)
{
	int s = 0;
	for (sections* i = list->head; i != NULL; i = i->next)
	{
		for (selectors* j = i->s_head; j != NULL; j = j->next)
		{
			if (!strcmp(str, j->selector)) s++;
		}
	}
	return s;
}
selectors* Get_selector(sections* list, int ind)
{
	if (ind > list->count_s) return NULL;
	int j = 1;
	for (selectors* i = list->s_head; i != NULL; i = i->next)
	{
		if (j == ind) return i;
		j++;
	}
	return NULL;
}
int Count_attributes(MyList* list, char* str)
{
	int s = 0;
	for (sections* i = list->head; i != NULL; i = i->next)
	{
		for (attributes* j = i->a_head; j != NULL; j = j->next)
		{
			if (!strcmp(str, j->property)) s++;
		}
	}
	return s;
}
char* Get_value(sections* list, char* str)
{
	for (attributes* i = list->a_head; i != NULL; i = i->next)
	{
		if (!strcmp(str, i->property))
		{
			return i->value;
		}
	}
	return NULL;
}
char* Get_value1(MyList* list, char* selector, char* attribute)
{
	for (sections* i = list->tail; i != NULL; i = i->prev)
	{
		for (selectors* j = i->s_head; j != NULL; j = j->next)
		{
			if (!strcmp(selector, j->selector))
			{
				for (attributes* k = i->a_head; k != NULL; k = k->next)
				{
					if (!strcmp(attribute, k->property)) return k->value;
				}
			}
		}
	}
	return NULL;
}
void Delete_section(MyList** list, int ind, bool& verify)
{
	if ((*list)->count < ind) return;
	sections* section_d = Get_section(*list, ind);
	if (section_d != NULL) verify = true;
	if (section_d->prev != NULL)
	{
		section_d->prev->next = section_d->next;
	}
	if (section_d->next != NULL)
	{
		section_d->next->prev = section_d->prev;
	}
	if (section_d->prev == NULL)
	{
		(*list)->head = section_d->next;
	}
	if (section_d->next == NULL)
	{
		(*list)->tail = section_d->prev;
	}
	free(section_d);
	(*list)->count--;
}
void Delete_attribute(MyList** list, int ind, char* str, bool& verify)
{
	if ((*list)->count < ind) return;
	sections* section = Get_section(*list, ind);
	if (section == NULL) return;
	if (!strcmp(str, section->a_head->property))
	{
		attributes* attribute_d = section->a_head;
		section->a_head = section->a_head->next;
		free(attribute_d);
		section->count_a--;
		verify = true;
	}
	else for (attributes* i = section->a_head; i->next != NULL; i = i->next)
	{
			if (!strcmp(str, i->next->property))
			{
				attributes* prev = i;
				attributes* attribute_d = i->next;
				prev->next = attribute_d->next;
				free(attribute_d);
				section->count_a--;
				verify = true;
				break;
			}
	}
	if (section->count_a == 0)Delete_section(list, ind, verify);
}