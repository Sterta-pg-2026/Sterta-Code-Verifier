#include <iostream>
#include <string.h>
#include <cctype>
using namespace std;

int const T = 37;

void Put(char s1[], char* s2) {
	for (int i = 0; i < 512; i++)
		s1[i] = s2[i];
	int k = 0;
}

void Purify(char* s) {
	int l = strlen(s);
	if (l == 0)
		return;
	l--;
	while (s[l] <= ' ') {
		s[l] = '\0';
		l--;
	}
	int i = 0;
	while (s[i] <= ' ') {
		i++;
	}
	int j = 0;
	while (s[i] != '\0') {
		s[j] = s[i];
		i++;
		j++;
	}
	s[j] = '\0';
}

int Extract0(char s[]) {
	
	Purify(s);
	
	int n = strlen(s);

	if (n == 0)
		return 0;

	if (s[n - 1] == '{') {
		if (n == 1)
			return 21;
		return 1;
	}

	if (s[n - 1] == '}') {
		if (n == 1)
			return 22;
		return 2;
	}
	if (s[n - 1] == ';')
		return 3;
	return 99;
}

int Compare(char* s1, char* s2) {
	if (strlen(s1) != strlen(s2))
		return 0;
	for (int i = 0; i < strlen(s1); i++) {
		if (s1[i] != s2[i])
			return 0;
	}
	return 1;
}

void Parse(char s[], char* s1) {
	int i = 0;
	while (s1[i] != ',' && s1[i] != '\0') {
		s[i] = s1[i];
		i++;
	}
	s[i] = '\0';

	if (Compare(s, s1) == 1) {
		s1[0] = '\0';
	}
	else {
		int j = 0;
		i++;
		while (s1[i] != '\0') {
			s1[j] = s1[i];
			i++;
			j++;
		}
		s1[j] = '\0';
	}
}

void ExtractAttr(char s[], char s1[], char s2[]) {
	int n = 0;
	int m = 0;
	for (int i = 0; i < strlen(s); i++) {
		if (s[i] == ':') {
			n = i;
		}
		if (s[i] == ';')
			m = i;
	}

	for (int i = 0; i < n; i++) {
		s1[i] = s[i];
	}
	s1[n] = '\0';

	for (int i = n + 1; i < m; i++) {
		s2[i - n - 1] = s[i];
	}
	s2[m - n - 1] = '\0';

	Purify(s1);
	Purify(s2);

}

int ParseInput(char* line, char* selector, char* attribute) {
	int n = -1;
	int m = -1;

	for (int i = 0; i < strlen(line); i++) {
		if (line[i] == '{')
			n = i;
	}

	if (n == -1)
		return 0;

	if (n == 0) {
		for (int i = 1; i <= strlen(line); i++) {
			attribute[i - 1] = line[i];
		}
		return 1;
	}
	else {
		for (int i = 0; i < n; i++) {
			selector[i] = line[i];
		}
		selector[n] = '\0';
		for (int i = n + 1; i <= strlen(line); i++) {
			attribute[i - n - 1] = line[i];
		}
		return 2;
	}

}

int Decide(char s[512]) {
	Purify(s);
	char sections[512] = "****";
	char commands[512] = "????";
	if (Compare(sections, s) == 1 || Compare(commands, s) == 1)
		return 1;
	return 0;
}

void Write(char* s) {
	for (int i = 0; i < strlen(s); i++)
		cout << s[i];
	cout << endl;
}

void Write2(char* s) {
	for (int i = 0; i < strlen(s); i++)
		cout << s[i];
}

int isNumber(char* s) {
	for (int i = 0; i < strlen(s); i++) {
		if (!isdigit(s[i]))
			return 0;
	}
	return 1;
}

struct Attribute {
	char name[512];
	char value[512];
	Attribute* next = nullptr;
	Attribute* previous = nullptr;
};

struct Selector {
	char name[512];
	Selector* next = nullptr;
	Selector* previous = nullptr;
};

class Section {

public:
	int attrNum = 0;
	int selNum = 0;
	int n = 0;
	Attribute* headA = nullptr;
	Attribute* tailA = nullptr;
	Attribute* currA = nullptr;
	Selector* headS = nullptr;
	Selector* tailS = nullptr;
	Selector* currS = nullptr;

	Section() {
	}

	int CountS(char* s) {
		Selector* sel = headS;
		for (int i = 0; i < selNum; i++) {
			if (Compare(s, sel->name) == 1)
				return 1;
			sel = sel->next;
		}
		return 0;
	}

	int CountA(char* s) {
		Attribute* attr = headA;
		for (int i = 0; i < attrNum; i++) {
			if (Compare(s, attr->name) == 1)
				return 1;
			attr = attr->next;
		}
		return 0;
	}

	char* FindNS(int n) {
		if (n > selNum)
			return nullptr;
		Selector* sel = headS;
		for (int i = 1; i < n; i++) {
			sel = sel->next;
		}
		return sel->name;
	}

	char* FindNA(char* s) {
		Attribute* attr = headA;
		for (int i = 0; i < attrNum; i++) {
			if (Compare(s, attr->name) == 1) {
				return attr->value;
			}
			attr = attr->next;
		}
		return nullptr;
	}

	Attribute* FindNA2(char* s) {
		Attribute* attr = headA;
		for (int i = 0; i < attrNum; i++) {
			if (Compare(s, attr->name) == 1) {
				return attr;
			}
			attr = attr->next;
		}
		return nullptr;
	}

	void DAttr(Attribute* attr) {
		attr->name[0] = '\0';
		attr->value[0] = '\0';
		if (attr->previous == nullptr && attr->next == nullptr) {
			delete headA;
		}
		else if (attr->previous == nullptr) {
			headA = *&attr->next;
			headA->previous = nullptr;
			delete attr;
		}
		else if (attr->next == nullptr) {
			tailA = *&attr->previous;
			tailA->next = nullptr;
			delete attr;
		}
		else {
			attr->previous->next = *&attr->next;
			attr->next->previous = *&attr->previous;
			delete attr;
		}
		attrNum--;

	}

	void DSel(Selector* sel) {
		sel->name[0] = '\0';
		if (sel->previous == nullptr && sel->next == nullptr) {
			delete headS;
		}
		else if (sel->previous == nullptr) {
			headS = *&sel->next;
			headS->previous = nullptr;
			delete sel;
		}
		else if (sel->next == nullptr) {
			tailS = *&sel->previous;
			tailS->next = nullptr;
			delete sel;
		}
		else {
			sel->previous->next = *&sel->next;
			sel->next->previous = *&sel->previous;
			delete sel;
		}
		selNum--;

	}

	int FindS(Selector* sel) {
		Selector* selF = *&headS;
		for (int i = 0; i < selNum; i++) {
			if (Compare(selF->name, sel->name) == 1)
				return 1;
			else
				selF = *&selF->next;
		}
		return 0;
	}

	int FindA(Attribute* attr) {
		Attribute* attrF = *&headA;
		for (int i = 0; i < attrNum; i++) {
			if (Compare(attrF->name, attr->name) == 1)
			{
				Put(attrF->value, attr->value);
				return 1;
			}
			else
				attrF = *&attrF->next;
		}
		return 0;
	}

	void addSel(Selector*& sel) {
		if (FindS(sel) == 0) {
			if (headS == nullptr) {
				headS = sel;
				tailS = sel;
				currS = sel;
			}
			else {
				(*currS).next = sel;
				(*sel).previous = currS;
				currS = sel;
				tailS = sel;
			}
			selNum++;
		}
	}

	void addAttr(Attribute*& attr) {
		if (FindA(attr) == 0) {
			if (headA == nullptr) {
				headA = attr;
				tailA = attr;
				currA = attr;
			}
			else {
				(*currA).next = attr;
				(*attr).previous = currA;
				currA = attr;
				tailA = attr;
			}
			attrNum++;
		}
	}

	int getAttrNum() {
		return attrNum;
	}

	int getSelNum() {
		return selNum;
	}

	~Section() {
		n = -1;
		for (int i = 0; i < attrNum; i++) {
			DAttr(headA);
			attrNum++;
		}
		for (int i = 0; i < selNum; i++) {
			DSel(headS);
			selNum++;
		}
		selNum = 0;
		attrNum = 0;
		
	}
};


struct Node {
	int t = 0;
	Section* secList[T];
	Node* previous = nullptr;
	Node* next = nullptr;

	void AddNext(Node*& next) {
		(this)->next = next;
	}
};

void CreateAttr(char line[512], Section* sec) {
	char name[512];
	char value[512];
	ExtractAttr(line, name, value);
	Attribute* attr = new Attribute();
	Put((*attr).name, name);
	Put((*attr).value, value);
	sec->addAttr(attr);
}

void CreateSel(char* line, Section* sec) {
	char token[512];
	while (strlen(line) > 0) {
		Parse(token, line);
		Purify(token);
		Selector* sel = new Selector();
		Put((*sel).name, token);
		sec->addSel(sel);
	}
}

void SplitCommand(char* s, char* s1, char* s2, char* s3) {
	int n = 0;
	int m = 0;

	while (s[n] != ',') {
		s1[n] = s[n];
		n++;
	}
	s1[n] = '\0';

	m = n + 1;
	while (s[m] != ',') {
		s2[m-n-1] = s[m];
		m++;
	}
	s2[m - n - 1] = '\0';

	int i = m + 1;
	while (s[i] != '\0') {
		s3[i - m - 1] = s[i];
		i++;
	}
	s3[i - m - 1] = '\0';
	Purify(s1);
	Purify(s2);
	Purify(s3);

}

int ChooseCommand(char* first, char* second, char* third) {
	if (isNumber(first) == 1) {
		if (isNumber(third) == 1 && second[0] == 'S') {
			return 3;
		}
		if (second[0] == 'S')
			return 1;
		if (second[0] == 'A') {
			if (third[0] == '?')
				return 2;
			return 4;
		}
		if (second[0] == 'D') {
			if (third[0] == '*')
				return 8;
			return 9;
		}

	}
	else {
		if (second[0] == 'A')
			return 5;
		if (second[0] == 'S')
			return 6;
		if (second[0] == 'E')
			return 7;
	}
	
	return 0;
}

void Command1(char* first, char* second, char* third, Node* node, Node* tail, int secNum, int nodeNum) {
	int i = atoi(first);
	int s = -1;
	if (i > secNum)
		return;

	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	if (s != -1)
		cout << i << ",S,? == " << node->secList[s]->selNum << endl;
	

}

void Command2(char* first, char* second, char* third, Node* node, Node* tail, int secNum, int nodeNum) {
	int i = atoi(first);
	int s = -1;
	if (i > secNum)
		return;
	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	if (s != -1)
		cout << i << ",A,? == " << node->secList[s]->attrNum << endl;
	

}

void Command3(char* first, char* second, char* third, Node* node, int secNum, int nodeNum) {
	int i = atoi(first);
	int j = atoi(third);
	int s = -1;
	if (i > secNum)
		return;
	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	if (s != -1 && node->secList[s]->FindNS(j) != nullptr) {
		cout << i << ",S," << j << " == ";
		Write2(node->secList[s]->FindNS(j));
		cout << endl;
	}
}

void Command4(char* first, char* second, char* third, Node* node, int secNum, int nodeNum) {
	int i = atoi(first);
	int s = -1;
	if (i > secNum)
		return;
	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	if (s != -1 && node->secList[s]->FindNA(third) != nullptr) {
		cout << i << ",A,";
		Write2(third);
		cout << " == ";
		Write2(node->secList[s]->FindNA(third));
		cout << endl;
	}
}

void Command5(char* first, char* second, char* third, Node* node, int totalnodes) {
	int c = 0;
	for (int i = 0; i < totalnodes; i++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n != -1)
				c+=node->secList[j]->CountA(first);
		}
		node = node->next;
	}
	Write2(first);
	cout << ",A,? == " << c << endl;
}

void Command6(char* first, char* second, char* third, Node* node, int totalnodes) {
	int c = 0;
	for (int i = 0; i < totalnodes; i++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n != -1)
				c += node->secList[j]->CountS(first);
		}
		node = node->next;
	}
	Write2(first);
	cout << ",S,? == " << c << endl;
}

void Command7(char* first, char* second, char* third, Node* node, int totalnodes) {
	for (int i = totalnodes; i > 0; i--) {
		for (int j = node->t - 1; j >= 0; j--) {
			if ((node->secList[j]->n != -1) && node->secList[j]->CountS(first) == 1) {
				if (node->secList[j]->FindNA(third) != nullptr) {
					Write2(first);
					cout << ",E,";
					Write2(third);
					cout << " == ";
					Write2(node->secList[j]->FindNA(third));
					cout << endl;
					return;
				}
				
			}
		}
		if (node->previous != NULL)
			node = node->previous;
	}

}

void Command8(char* first, char* second, char* third, Node* node, int nodeNum, int& secNum) {
	int i = atoi(first);
	int s = -1;
	if (i > secNum)
		return;
	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	if (s != -1) {

		node->secList[s]->~Section();

		secNum--;
		cout << i << ",D,* == deleted" << endl;
	}
	
	
}

int Command9(char* first, char* second, char* third, Node* node, int nodeNum, int &secNum) {
	int i = atoi(first);
	int s = -1;
	if (i > secNum)
		return 0;
	
	for (int c = 0; c < nodeNum; c++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n == i) {
				s = j;
				break;
			}
		}
		if (s != -1)
			break;
		if (node->next != nullptr)
			node = node->next;
	}
	
	if (s != -1) {
		if (node->secList[s]->FindNA2(third) == nullptr)
			return 0;
		if (node->secList[s]->attrNum == 1) {
			node->secList[s]->~Section();
			
			secNum--;
			cout << i << ",D,";
			Write2(third);
			cout << " == deleted" << endl;
			return 1;
		}
		else {
			node->secList[s]->DAttr(node->secList[s]->FindNA2(third));
			cout << i << ",D,";
			Write2(third);
			cout << " == deleted" << endl;
			return 0;
		}
	}
	return 0;
}

void MoveN(int n, Node* node, int nodeNum) {
	for (int i = 0; i < nodeNum; i++) {
		for (int j = 0; j < node->t; j++) {
			if (node->secList[j]->n > n)
				node->secList[j]->n--;
		}
		node = node->next;
	}
}

int main() {
	char line[512];
	int aControl = 0;
	int sControl = 0;
	int attrControl = 0;
	Node* current = new Node();
	Node* head = *&current;
	Node* tail = *&current;
	int nodeNum = 1;
	int secCount = 0;
	int secNum = 0;
	int commands = -1;
	int skip = 0;
	Section* sec = new Section();
	int z = 0;

	while (cin.getline(line, 512, '\n')) {

		int d = Decide(line);

		if (d == 1) {
			commands = commands * -1;
			skip = 1;
		}

		if (commands == 1 && skip == 0) {
			Purify(line);
			if (line[0] != '\0') {
				if (line[0] == '?') {
					cout << "? == " << secNum << endl;
				}
				else {
					char first[128];
					char second[128];
					char third[128];
					SplitCommand(line, first, second, third);
					int c = ChooseCommand(first, second, third);
					switch (c) {
					case  1:
						Command1(first, second, third, head, tail, secNum, nodeNum);
						break;
					case  2:
						Command2(first, second, third, head, tail, secNum, nodeNum);
						break;
					case  3:
						Command3(first, second, third, head, secNum, nodeNum);
						break;
					case  4:
						Command4(first, second, third, head, secNum, nodeNum);
						break;
					case  5:
						Command5(first, second, third, head, nodeNum);
						break;
					case  6:
						Command6(first, second, third, head, nodeNum);
						break;
					case  7:
						Command7(first, second, third, tail, nodeNum);
						break;
					case  8:
						Command8(first, second, third, head, nodeNum, secNum);
						MoveN(atoi(first), head, nodeNum);
						break;
					case  9:
						z = Command9(first, second, third, head, nodeNum, secNum);
						if (z == 1) {
							MoveN(atoi(first), head, nodeNum);
						}
						break;
					default:
						break;
					}
				}
			}
			
		}
		
		if (commands == -1 && skip == 0) {
			Purify(line);
			int k = Extract0(line);

			if (k == 22) {
				aControl = 0;
				current->secList[secCount] = sec;
				secCount++;
				secNum++;
				sec->n = secNum;
				current->t++;
				sec = new Section();
			}

			if (secCount != 0 && secCount % T == 0) {
				Node* node = new Node();
				current->AddNext(node);
				node->previous = *&current;
				current = *&node;
				tail = *&current;
				secCount = 0;
				nodeNum++;
			}

			if (k == 2) {
				char attribute[512];
				char selector[512];
				line[strlen(line) - 1] = '\0';
				int g = ParseInput(line, selector, attribute);
				if (g == 0) {
					CreateAttr(line, sec);
				}
				if (g == 1) {
					CreateAttr(attribute, sec);
				}
				if (g == 2) {
					CreateSel(selector, sec);
					CreateAttr(attribute, sec);
				}

				aControl = 0;
				current->secList[secCount] = sec;
				secCount++;
				secNum++;
				sec->n = secNum;
				current->t++;
				sec = new Section();
			}

			if (aControl == 1) {
				CreateAttr(line, sec);
			}

			if (k == 99) {
				Purify(line);
				if (strlen(line) != 0)
					sControl = 1;
			}

			if (k == 1 || sControl == 1) {



				if (line[strlen(line) - 1] == '{') {
					line[strlen(line) - 1] = '\0';
					aControl = 1;
				}

				CreateSel(line, sec);

				sControl = 0;
			}

			if (k == 21) {
				aControl = 1;
			}
		}
		skip = 0;

	}
}