#pragma once
#include "customstring.h"

struct SplitCommands
{
    int count;
    CustomString *elements;
};