#include "commandprocessor.h"
#include "doublylinkedattribute.h"
#include "doublylinkedselector.h"
#include "customstring.h"
#include "selectornode.h"
#include "attributenode.h"
#include "attribute.h"

CommandProcessor::CommandProcessor(DoublyLinkedSection *initializer)
{
    this->dll = initializer;
}

void CommandProcessor::PrintSelectorsCountForSectionI(int i)
{
    Section *node = dll->GetSectionAtPos(i);

    if (node != NULL)
    {
        std::cout << i << ",S,? == " << node->GetSelectorsCount() << std::endl;
    }
}

void CommandProcessor::PrintSelectorJForSectionI(int iNum, int jNum)
{
    Section *node = dll->GetSectionAtPos(iNum);
    int index = 0;

    if (node != NULL)
    {
        DoublyLinkedSelector *sels = node->GetSelectors();
        SelectorNode *selNode = sels->GetAtPos(jNum);

        if (selNode != NULL)
        {
            std::cout << iNum << ",S," << jNum << " == " << selNode->GetSelector()->GetString() << std::endl;
        }
    }
}

void CommandProcessor::PrintAttributesCountForSectionI(int iNum)
{
    Section *node = dll->GetSectionAtPos(iNum);

    if (node != NULL)
    {
        std::cout << iNum << ",A,? == " << node->GetAttributesCount() << std::endl;
    }
}

void CommandProcessor::PrintAttributeNForSectionI(CustomString &n, int iNum)
{
    Section *section = dll->GetSectionAtPos(iNum);
    int index = 0;

    if (section != NULL)
    {
        DoublyLinkedAttribute *atts = section->GetAttributes();
        AttributeNode *attNode = atts->GetHead();

        if (attNode != NULL)
        {
            while (attNode != NULL)
            {
                CustomString *name = attNode->GetAttribute()->GetName();
                if (name->Compare(n.GetString()))
                {
                    std::cout << iNum << ",A," << n.GetString() << " == " << attNode->GetAttribute()->GetValue()->GetString() << std::endl;
                }

                attNode = attNode->GetNext();
            }
        }
    }
}

void CommandProcessor::DeleteSectionI(int i)
{
    Section *section = dll->GetSectionAtPos(i);

    if (section != NULL)
    {
        section->SetDeleted();
        std::cout << i << ",D,* == deleted" << std::endl;
    }
}

void CommandProcessor::DeleteAttributeNFromSectionI(CustomString &n, int i)
{
    Section *section = dll->GetSectionAtPos(i);

    if (section != NULL)
    {
        DoublyLinkedAttribute *attributes = section->GetAttributes();
        AttributeNode *tmp = attributes->GetHead();

        while (tmp != NULL)
        {
            if (tmp->GetAttribute()->GetName()->Compare(n.GetString()))
            {
                tmp->GetAttribute()->SetDeleted();

                // Delete the whole section if no attributes are left
                if (!attributes->GetListLen())
                {
                    section->SetDeleted();
                }

                std::cout << i << ",D," << n.GetString() << " == deleted" << std::endl;
                return;
            }

            tmp = tmp->GetNext();
        }
    }
}

void CommandProcessor::PrintAttributeTotalCount(CustomString &n)
{
    int counter = 0;
    if (dll->GetHead() != NULL)
    {
        SectionNode *tmp = dll->GetHead();

        while (tmp != NULL)
        {
            Section *sections = tmp->GetSections();

            for (int i = 0; i < T; i++)
            {
                if (sections[i].Counts())
                {
                    DoublyLinkedAttribute *attributes = sections[i].GetAttributes();
                    AttributeNode *attNode = attributes->GetHead();

                    while (attNode != NULL)
                    {
                        Attribute *attribute = attNode->GetAttribute();

                        if (!attribute->GetDeleted() && attribute->GetName()->Compare(n.GetString()))
                        {
                            counter++;
                        }

                        attNode = attNode->GetNext();
                    }
                }
            }

            tmp = tmp->GetNext();
        }
    }

    std::cout << n.GetString() << ",A,? == " << counter << std::endl;
}

void CommandProcessor::PrintSelectorTotalCount(CustomString &n)
{
    int counter = 0;
    if (dll->GetHead() != NULL)
    {
        SectionNode *tmp = dll->GetHead();

        while (tmp != NULL)
        {
            Section *sections = tmp->GetSections();

            for (int i = 0; i < T; i++)
            {
                if (sections[i].Counts())
                {
                    DoublyLinkedSelector *selectors = sections[i].GetSelectors();
                    SelectorNode *selNode = selectors->GetHead();

                    while (selNode != NULL)
                    {
                        CustomString *selector = selNode->GetSelector();

                        if (selector->Compare(n.GetString()))
                        {
                            counter++;
                            break;
                        }

                        selNode = selNode->GetNext();
                    }
                }
            }

            tmp = tmp->GetNext();
        }
    }

    std::cout << n.GetString() << ",S,? == " << counter << std::endl;
}

void CommandProcessor::PrintAttributeNForSelectorZ(CustomString &z, CustomString &n)
{
    if (dll->GetHead() != NULL && dll->GetHead() != nullptr)
    {
        char value[100] = "";
        SectionNode *tmp = dll->GetHead();

        while (tmp != nullptr && tmp != NULL)
        {
            Section *sections = tmp->GetSections();

            for (int i = 0; i < T; i++)
            {
                DoublyLinkedSelector *selectors = sections[i].GetSelectors();
                SelectorNode *selNode = selectors->GetHead();

                while (selNode != NULL && selNode != nullptr)
                {
                    if (!strcmp(selNode->GetSelector()->GetString(), z.GetString()))
                    {
                        DoublyLinkedAttribute *attributes = sections[i].GetAttributes();
                        AttributeNode *attNode = attributes->GetHead();

                        while (attNode != NULL && attNode != nullptr)
                        {
                            if (!strcmp(attNode->GetAttribute()->GetName()->GetString(), n.GetString()) && !sections[i].GetDeleted())
                            {
                                strcpy(value, attNode->GetAttribute()->GetValue()->GetString());
                            }

                            attNode = attNode->GetNext();
                        }
                    }

                    selNode = selNode->GetNext();
                }
            }
            tmp = tmp->GetNext();
        }

        if (value[0] != '\0')
        {
            std::cout << z.GetString() << ",E," << n.GetString() << " == " << value << std::endl;
        }
    }
}

CommandProcessor::~CommandProcessor()
{
}