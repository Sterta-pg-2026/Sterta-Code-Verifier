#pragma once
#define T 17
#define MAX_NAME_SIZE 64
#define SELECTOR_ATTRIBUTE_BUFFOR_SIZE 32