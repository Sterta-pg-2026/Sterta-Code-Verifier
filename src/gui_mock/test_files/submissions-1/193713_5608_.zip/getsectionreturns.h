#pragma once
#include "customstring.h"

struct GetSectionReturns
{
    CustomString *selectors;
    CustomString *attributes;
};