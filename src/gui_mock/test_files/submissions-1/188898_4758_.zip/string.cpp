#pragma once
#include "string.h"


inline string::string() : data(new char[1]), _size(0) {
	data[0] = '\0';
}

inline string::string(const char* str) : _size(strlen(str)) {
	data = new char[_size + 1];
	data[0] = '\0';
	strcpy_s(data, _size + 1, str);
}

inline string::string(const string& str) : _size(str._size) {
	data = new char[_size + 1];
	data[0] = '\0';
	strcpy_s(data, _size + 1, str.data);
}

inline string::string(string&& str) noexcept : data(prj::move(str.data)), _size(prj::move(str._size)) {
	str.data = new char[1];
	str.data[0] = '\0';
	str._size = 0;
}



inline string& string::operator=(const char* str) {
	string tmp = str;
	prj::swap(data, tmp.data);
	prj::swap(_size, tmp._size);
	return *this;
}

inline string& string::operator=(const string& str) {
	string tmp = str;
	prj::swap(data, tmp.data);
	prj::swap(_size, tmp._size);
	return *this;
}

inline string& string::operator=(string&& str) noexcept {
	string tmp = str;
	prj::swap(data, tmp.data);
	prj::swap(_size, tmp._size);
	return *this;
}



inline char& string::operator[](const std::size_t& index) {
	return data[index];
}

inline const char& string::operator[](const std::size_t& index) const {
	return data[index];
}



inline bool string::operator==(const char* str) const {
	return strcmp(data, str) == 0;
}

inline bool string::operator==(const string& str) const {
	return strcmp(data, str.data) == 0;
}



inline std::size_t string::size() const {
	return _size;
}

inline std::size_t string::length() const {
	return _size;
}

inline const char* string::c_str() const {
	return data;
}



inline string::~string() {
	delete[] data;
}