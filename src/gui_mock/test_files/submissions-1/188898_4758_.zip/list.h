#pragma once
#include "node.h"
#include "utility.h"

template <typename T>
class list {
private:
	std::size_t _size;
	Node<T>* firstNode, * lastNode;
public:
	class iterator;
	class const_iterator;
	class reverse_iterator;
	class const_reverse_iterator;

	list();
	list(const list<T>& lst);
	list(list<T>&& lst) noexcept;

	list& operator=(const list<T>& lst);
	list& operator=(list<T>&& lst) noexcept;

	void push_back(const T& value);
	void push_back(T&& value);

	void erase(const iterator& it);
	//void erase(const const_iterator& it);
	void erase(const reverse_iterator& it);
	//void erase(const const_reverse_iterator& it);

	iterator begin();
	iterator end();

	const_iterator cbegin() const;
	const_iterator cend() const;

	reverse_iterator rbegin();
	reverse_iterator rend();

	const_reverse_iterator crbegin() const;
	const_reverse_iterator crend() const;

	std::size_t size() const;

	~list();

};

template <typename T>
inline list<T>::list() : _size(0), firstNode(nullptr), lastNode(nullptr) {};

template <typename T>
inline list<T>::list(const list<T>& lst) : list() {
	for (auto it = lst.cbegin(); it != lst.cend(); ++it) {
		this->push_back(*it);
	}
}

template <typename T>
inline list<T>::list(list<T>&& lst) noexcept : _size(prj::move(lst._size)), firstNode(prj::move(lst.firstNode)), lastNode(prj::move(lst.lastNode)) {
	lst._size = 0;
	lst.firstNode = nullptr;
	lst.lastNode = nullptr;
}


template <typename T>
list<T>& list<T>::operator=(const list<T>& lst) {
	list<T> tmp = lst;
	prj::swap(this->_size, tmp._size);
	prj::swap(this->firstNode, tmp.firstNode);
	prj::swap(this->lastNode, tmp.lastNode);
	return *this;
}

template <typename T>
list<T>& list<T>::operator=(list<T>&& lst) noexcept {
	list<T> tmp = prj::move(lst);
	prj::swap(this->_size, tmp._size);
	prj::swap(this->firstNode, tmp.firstNode);
	prj::swap(this->lastNode, tmp.lastNode);
	return *this;
}


template <typename T>
inline void list<T>::push_back(const T& value) {
	if (firstNode == nullptr) {
		Node<T>* tmp = new Node<T>(value);
		firstNode = tmp;
		lastNode = tmp;
	}
	else if (lastNode->capacity() == lastNode->_size) {
		Node<T>* tmp = new Node<T>(value);
		if (firstNode == lastNode) {
			lastNode = tmp;
			lastNode->prevNode = firstNode;
			firstNode->nextNode = lastNode;
		}
		else {
			lastNode->nextNode = tmp;
			tmp->prevNode = lastNode;
			lastNode = tmp;
		}
	}
	else {
		lastNode->push_back(value);
	}
	_size++;
}



template <typename T>
inline void list<T>::push_back(T&& value) {
	if (firstNode == nullptr) {
		Node<T>* tmp = new Node<T>(prj::move(value));
		firstNode = tmp;
		lastNode = tmp;
	}
	else if (lastNode->capacity() == lastNode->_size) {
		Node<T>* tmp = new Node<T>(prj::move(value));
		if (firstNode == lastNode) {
			lastNode = tmp;
			lastNode->prevNode = firstNode;
			firstNode->nextNode = lastNode;
		}
		else {
			lastNode->nextNode = tmp;
			tmp->prevNode = lastNode;
			lastNode = tmp;
		}
	}
	else {
		lastNode->push_back(prj::move(value));
	}
	_size++;
}



template <typename T>
inline void list<T>::erase(const typename list<T>::iterator& it) {
	Node<T>* tmp = it.data;
	tmp->deleteAt(it.index);
	if (tmp->empty()) {
		if (firstNode == lastNode) {
			firstNode = nullptr;
			lastNode = nullptr;
		}
		else if (tmp == firstNode) {
			firstNode = firstNode->nextNode;
		}
		else if (tmp == lastNode) {
			lastNode = lastNode->prevNode;
		}
		tmp->~Node();
	}
	_size--;
}



template <typename T>
inline void list<T>::erase(const typename list<T>::reverse_iterator& it) {
	Node<T>* tmp = it.data;
	tmp->deleteAt(it.index);
	if (tmp->empty()) {
		if (firstNode == lastNode) {
			firstNode = nullptr;
			lastNode = nullptr;
		}
		else if (tmp == firstNode) {
			firstNode = firstNode->nextNode;
		}
		else if (tmp == lastNode) {
			lastNode = lastNode->prevNode;
		}
		tmp->~Node();
	}
	_size--;
}






#include "iterator.h"
#include "const_iterator.h"
#include "reverse_iterator.h"
#include "const_reverse_iterator.h"

template <typename T>
inline typename list<T>::iterator list<T>::begin() {
	return iterator(firstNode);
}

template <typename T>
inline typename list<T>::iterator list<T>::end() {
	return iterator(nullptr);
}



template <typename T>
inline typename list<T>::const_iterator list<T>::cbegin() const {
	return const_iterator(firstNode);
}

template <typename T>
inline typename list<T>::const_iterator list<T>::cend() const {
	return const_iterator(nullptr);
}



template <typename T>
inline typename list<T>::reverse_iterator list<T>::rbegin() {
	return reverse_iterator(lastNode);
}

template <typename T>
inline typename list<T>::reverse_iterator list<T>::rend() {
	return reverse_iterator(nullptr);
}



template <typename T>
inline typename list<T>::const_reverse_iterator list<T>::crbegin() const {
	return const_reverse_iterator(lastNode);
}

template <typename T>
inline typename list<T>::const_reverse_iterator list<T>::crend() const {
	return const_reverse_iterator(nullptr);
}



template <typename T>
inline std::size_t list<T>::size() const {
	return _size;
}



template <typename T>
inline list<T>::~list() {
	if (firstNode != nullptr) {
		while (firstNode != lastNode) {
			firstNode = firstNode->nextNode;
			firstNode->prevNode->~Node();
		}
		firstNode->~Node();
		firstNode = nullptr;
		lastNode = nullptr;
	}
}