#pragma once

template <typename T, typename func>
T find_if(T begin, T end, func function) {
	for (auto it = begin; it != end; ++it) {
		if (function(*it)) return it;
	}
	return end;
}