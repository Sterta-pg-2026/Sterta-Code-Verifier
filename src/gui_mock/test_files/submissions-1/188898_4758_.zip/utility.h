#pragma once
#include <type_traits>

namespace prj {
	template <typename T>
	typename std::remove_reference<T>::type&&
		move(T&& data) noexcept
	{
		return static_cast<typename std::remove_reference<T>::type&&>(data);
	}

	template <typename T>
	void swap(T& dataA, T& dataB) noexcept {
		T tmp = move(dataA);
		dataA = move(dataB);
		dataB = move(tmp);
	}	
}