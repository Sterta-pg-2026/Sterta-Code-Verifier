#pragma once
#include "utility.h"

constexpr std::size_t _ARRAY_CAPACITY = 17;

template <typename T>
class Node {
private:
	T data[_ARRAY_CAPACITY];
	std::size_t _size;
	Node *nextNode, *prevNode;
public:
	template <typename T>
	friend class list;

	Node();
	Node(const T& value);
	Node(T&& value) noexcept;
	Node(const Node& node);
	Node(Node&& node) noexcept;

	Node& operator=(const Node& node);
	Node& operator=(Node&& node) noexcept;

	T& operator[](const std::size_t& index);
	const T& operator[](const std::size_t& index) const;

	void push_back(const T& value);
	void push_back(T&& value);
	void deleteAt(const std::size_t& index);

	std::size_t size() const;
	bool empty() const;
	std::size_t capacity() const;

	~Node();
};

template <typename T>
inline Node<T>::Node() : _size(0), nextNode(nullptr), prevNode(nullptr) {};

template <typename T>
inline Node<T>::Node(const T& value) : Node() {
	this->push_back(value);
}

template <typename T>
inline Node<T>::Node(T&& value) noexcept : Node() {
	this->push_back(prj::move(value));
}

template <typename T>
inline Node<T>::Node(const Node<T>& node) : Node() {
	_size = node._size;
	for (std::size_t i = 0; _size > i; i++) {
		this->data[i] = node.data[i];
	}
}

template <typename T>
inline Node<T>::Node(Node<T>&& node) noexcept : Node() {
	_size = prj::move(node._size);
	node._size = 0;
	for (std::size_t i = 0; _size > i; i++) {
		this->data[i] = prj::move(node.data[i]);
	}
}



template <typename T>
inline Node<T>& Node<T>::operator=(const Node<T>& node) {
	Node<T> tmp = node;
	prj::swap(this->_size, tmp._size);
	for (std::size_t i = 0; _ARRAY_CAPACITY > i; i++) {
		prj::swap(data[i], tmp.data[i]);
	}
	return *this;
}

template <typename T>
inline Node<T>& Node<T>::operator=(Node<T>&& node) noexcept {
	Node<T> tmp = prj::move(node);
	prj::swap(this->_size, tmp._size);
	for (std::size_t i = 0; _ARRAY_CAPACITY > i; i++) {
		prj::swap(data[i], tmp.data[i]);
	}
	return *this;
}



template <typename T>
inline T& Node<T>::operator[](const std::size_t& index) {
	return data[index];
}

template <typename T>
inline const T& Node<T>::operator[](const std::size_t& index) const {
	return data[index];
}



template <typename T>
inline void Node<T>::push_back(const T& value) {
	data[_size] = value;
	_size++;
}

template <typename T>
inline void Node<T>::push_back(T&& value) {
	data[_size] = prj::move(value);
	_size++;
}



template <typename T>
inline void Node<T>::deleteAt(const std::size_t& index) {
	for (std::size_t i = index; _size > i + 1; i++) {
		data[i] = prj::move(data[i + 1]);
		//std::swap(data[i], data[i + 1]);
	}
	_size--;
	//data[_size] = T();
}



template <typename T>
inline std::size_t Node<T>::size() const {
	return _size;
}

template <typename T>
inline std::size_t Node<T>::capacity() const {
	return _ARRAY_CAPACITY;
}

template <typename T>
inline bool Node<T>::empty() const {
	return _size == 0;
}



template <typename T>
inline Node<T>::~Node() {
	if (nextNode != nullptr && prevNode != nullptr) {
		nextNode->prevNode = prevNode;
		prevNode->nextNode = nextNode;
		nextNode = nullptr;
		prevNode = nullptr;
	}
	else if (nextNode != nullptr) {
		nextNode->prevNode = nullptr;
		nextNode = nullptr;
	}
	else if (prevNode != nullptr) {
		prevNode->nextNode = nullptr;
		prevNode = nullptr;
	}
}
