#pragma once
#include "list.h"
#include <iterator>
#include <cstddef>

template <typename T>
class list<T>::iterator {
private:
	Node<T>* data;
	std::size_t index;
public:
	template <typename T>
	friend class list;

	using iterator_category = std::forward_iterator_tag;
	using difference_type = std::ptrdiff_t;
	using value_type = T;
	using pointer = T*;
	using reference = T&;

	iterator(Node<T>* node) {
		data = node;
		index = 0;
	}

	iterator(const iterator& it) {
		data = it.data;
		index = it.index;
	}

	iterator& operator=(const iterator& it) {
		iterator tmp = it;
		prj::swap(data, it.data);
		prj::swap(index, it.index);
	}

	iterator& operator++() {
		index++;
		if (data->_size == index) {
			data = data->nextNode;
			index = 0;
		}
		return *this;
	}

	bool operator==(const iterator& it) const {
		return data == it.data && index == it.index;
	}

	bool operator!=(const iterator& it) const {
		return data != it.data || index != it.index;
	}

	reference operator*() {
		return data->operator[](index);
	}

	pointer operator->() {
		return &(operator*());
	}

};