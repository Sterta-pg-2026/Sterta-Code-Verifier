#pragma once
#include "list.h"
#include <iterator>
#include <cstddef>

template <typename T>
class list<T>::const_iterator {
private:
	Node<T>* data;
	std::size_t index;
public:
	template <typename T>
	friend class list;

	using iterator_category = std::input_iterator_tag;
	using difference_type = std::ptrdiff_t;
	using value_type = const T;
	using pointer = const T*;
	using reference = const T&;

	const_iterator(Node<T>* node) {
		data = node;
		index = 0;
	}

	const_iterator(const const_iterator& it) {
		data = it.data;
		index = it.index;
	}

	const_iterator& operator=(const const_iterator& it) {
		iterator tmp = it;
		prj::swap(data, it.data);
		prj::swap(index, it.index);
	}

	const_iterator& operator++() {
		index++;
		if (data->_size == index) {
			data = data->nextNode;
			index = 0;
		}
		return *this;
	}

	bool operator==(const const_iterator& it) const {
		return data == it.data && index == it.index;
	}

	bool operator!=(const const_iterator& it) const {
		return data != it.data || index != it.index;
	}

	reference operator*() const {
		return data->operator[](index);
	}

	pointer operator->() const {
		return &(operator*());
	}

};