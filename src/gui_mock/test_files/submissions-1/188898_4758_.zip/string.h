#pragma once
#include "utility.h"
#include <cstring>
#include <ostream>

class string {
private:
	char* data;
	std::size_t _size;
public:
	string();
	string(const char* str);
	string(const string& str);
	string(string&& str) noexcept;

	string& operator=(const char* str);
	string& operator=(const string& str);
	string& operator=(string&& str) noexcept;

	char& operator[](const std::size_t& index);
	const char& operator[](const std::size_t& index) const;

	bool operator==(const char* str) const;
	bool operator==(const string& str) const;
	friend bool operator==(const char* strA, const string& strB) {
		return strcmp(strA, strB.data) == 0;
	}

	friend std::ostream& operator<<(std::ostream& out, const string& str) {
		out << str.data;
		return out;
	}

	std::size_t size() const;
	std::size_t length() const;
	const char* c_str() const;

	~string();
};