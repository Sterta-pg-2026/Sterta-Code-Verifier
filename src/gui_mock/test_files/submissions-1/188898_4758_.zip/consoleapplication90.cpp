#include "list.h"
#include <iostream>
#include "algorithms.h"
#include "string.h"
#include "string.cpp"

struct Attribute {
	string name;
	string value;
};

struct Section {
public:
	list<string> selectors;
	list<Attribute> attributes;
};

#pragma region Read Sections

void ClearSpace(char& c) {
	while (isspace(c)) {
		c = getchar();
	}
}

void ClearEnd(int& i, char buffer[]) {
	while (i > 0 && isspace(buffer[i - 1])) {
		i--;
	}
}

string ReadSelector(char& c, char buffer[], int& i) {
	if (i == 0) {
		ClearSpace(c);
	}
	while (c != ',' && c != '{') {
		buffer[i++] = c;
		c = getchar();
	}
	ClearEnd(i, buffer);
	buffer[i] = '\0';
	if (c == ',') {
		c = getchar();
	}
	i = 0;
	return string(buffer);
}

string ReadAttributeName(char& c, char buffer[]) {
	int i = 0;
	ClearSpace(c);
	while (c != ':') {
		buffer[i++] = c;
		c = getchar();
	}
	ClearEnd(i, buffer);
	buffer[i] = '\0';
	c = getchar();
	return string(buffer);
}

string ReadAttributeValue(char& c, char buffer[]) {
	int i = 0;
	ClearSpace(c);
	while (c != ';' && c != '}') {
		buffer[i++] = c;
		c = getchar();
	}
	ClearEnd(i, buffer);
	buffer[i] = '\0';
	return string(buffer);
}

Attribute ReadAttribute(char& c, char buffer[]) {
	return { ReadAttributeName(c, buffer), ReadAttributeValue(c, buffer) };
}

Section ReadSection(char& c, char buffer[], int& i) {
	Section tmp;
	while (c != '{') {
		tmp.selectors.push_back(prj::move(ReadSelector(c, buffer, i)));
	}
	c = getchar();
	while (c != '}') {
		Attribute tmpAttr = prj::move(ReadAttribute(c, buffer));
		auto it = find_if(tmp.attributes.begin(), tmp.attributes.end(), [&tmpAttr](const Attribute& attr) {
			return tmpAttr.name == attr.name;
			});
		if (it == tmp.attributes.end()) {
			tmp.attributes.push_back(prj::move(tmpAttr));
		}
		else {
			it->value = prj::move(tmpAttr.value);
		}
		if (c != '}') {
			c = getchar();
			ClearSpace(c);
		}
	}
	return tmp;
}

void ReadCSS(char& c, char buffer[], list<Section>& sections) {
	int i = 0;
	while (i != 4) {
		if (i == 0) {
			ClearSpace(c);
		}
		if (c == '?') {
			buffer[i] = c;
			i++;
		}
		else {
			sections.push_back(prj::move(ReadSection(c, buffer, i)));
			i = 0;
		}
		c = getchar();
	}
}

#pragma endregion

#pragma region Commands

void SplitCommand(char command[], char** commands) {
	int i, j = 0, k = 0;
	for (i = 0; k < 3 && strlen(command) > i; i++) {
		if (command[i] == ',') {
			commands[k][j] = '\0';
			k++;
			j = 0;
		}
		else {
			commands[k][j] = command[i];
			j++;
		}
	}
	k = k < 3 ? k : k--;
	commands[k][j] = '\0';
}

bool isNumber(char str[]) {
	for (std::size_t i = 0; strlen(str) > i; i++) {
		if (!isdigit(str[i])) return false;
	}
	return true;
}

namespace lol {
	int stoi(char str[]) {
		int number = 0;
		for (int i = 0; strlen(str) > i; i++) {
			number *= 10;
			number += str[i] - '0';
		}
		return number;
	}
}

void PrintSectionsCount(char command[], list<Section>& sections) {
	std::cout << command << " == " << sections.size() << '\n';
}

void PrintSelectorCountForI(char command[], list<Section>& sections, const int& index) {
	if (sections.size() > index) {
		auto& selectors = (std::next(sections.begin(), index))->selectors;
		std::cout << command << " == " << selectors.size() << '\n';
	}
}

void PrintSelectorZCount(char command[], list<Section>& sections, char selectorName[]) {
	std::size_t count = 0;
	for (auto section : sections) {
		if (find_if(section.selectors.begin(), section.selectors.end(), [&selectorName](const string& selector) {
			return selectorName == selector;
			}) != section.selectors.end()) count++;
	}
	std::cout << command << " == " << count << '\n';
}

void PrintJSelectorForI(char command[], list<Section>& sections, const int& indexSection, const int& indexSelector) {
	if (sections.size() > indexSection) {
		auto& selectors = (std::next(sections.begin(), indexSection))->selectors;
		if (selectors.size() > indexSelector) {
			std::cout << command << " == " << *(std::next(selectors.begin(), indexSelector)) << '\n';
		}
	}
}

void PrintAttributesCountForI(char command[], list<Section>& sections, const int& index) {
	if (sections.size() > index) {
		auto& attrs = (std::next(sections.begin(), index))->attributes;
		std::cout << command << " == " << attrs.size() << '\n';
	}
}

void PrintNAttributeCount(char command[], list<Section>& sections, char attributeName[]) {
	std::size_t count = 0;
	for (auto section : sections) {
		if (find_if(section.attributes.begin(), section.attributes.end(), [&attributeName](const Attribute& attr) {
			return attributeName == attr.name;
			}) != section.attributes.end()) count++;
	}
	std::cout << command << " == " << count << '\n';
}

void PrintNAttributeForI(char command[], list<Section>& sections, const int& index, char attributeName[]) {
	if (sections.size() > index) {
		auto& attrs = (std::next(sections.begin(), index))->attributes;
		auto it_2 = find_if(attrs.begin(), attrs.end(), [&attributeName](const Attribute& attr) {
			return attributeName == attr.name;
			});
		if (it_2 != attrs.end()) {
			std::cout << command << " == " << it_2->value << '\n';
		}
	}
}

void DeleteWholeISection(char command[], list<Section>& sections, const int& index) {
	if (sections.size() > index) {
		sections.erase(std::next(sections.begin(), index));
		std::cout << command << " == " << "deleted" << '\n';
	}
}

void DeleteNAttributeFromISelector(char command[], list<Section>& sections, const int& index, char attributeName[]) {
	if (sections.size() > index) {
		auto it = std::next(sections.begin(), index);
		auto& attr = it->attributes;
		auto it_2 = find_if(attr.begin(), attr.end(), [&attributeName](const Attribute& attr) {
			return attributeName == attr.name;
			});
		if (it_2 != attr.end()) {
			attr.erase(it_2);
			std::cout << command << " == " << "deleted" << '\n';
		}
		if (attr.size() == 0) {
			sections.erase(it);
		}
	}
}

void PrintNAttributeForSelectorZ(char command[], list<Section>& sections, char selectorName[], char attributeName[]) {
	for (auto it = sections.rbegin(); it != sections.rend(); ++it) {
		auto& selectors = it->selectors;
		if (selectors.size() == 0 || find_if(selectors.begin(), selectors.end(), [selectorName](const string& str) {
			return selectorName == str;
			}) != selectors.end()) {
			auto it_2 = find_if(it->attributes.begin(), it->attributes.end(), [attributeName](const Attribute& attr) {
				return attributeName == attr.name;
				});
			if (it_2 != it->attributes.end()) {
				std::cout << command << " == " << it_2->value << '\n';
				break;
			}
		}
	}
}




void CommandHandler(list<Section>& sections, char command[], char** commands) {

	SplitCommand(command, commands);

	if (strcmp(commands[0], "?") == 0) {
		PrintSectionsCount(command, sections);
	}
	else if (strcmp(commands[1], "S") == 0 && strcmp(commands[2], "?") == 0 && isNumber(commands[0])) {
		PrintSelectorCountForI(command, sections, lol::stoi(commands[0]) - 1);
	}
	else if (strcmp(commands[1], "S") == 0 && strcmp(commands[2], "?") == 0) {
		PrintSelectorZCount(command, sections, commands[0]);
	}
	else if (strcmp(commands[1], "S") == 0) {
		PrintJSelectorForI(command, sections, lol::stoi(commands[0]) - 1, lol::stoi(commands[2]) - 1);
	}
	else if (strcmp(commands[1], "A") == 0 && strcmp(commands[2], "?") == 0 && isNumber(commands[0])) {
		PrintAttributesCountForI(command, sections, lol::stoi(commands[0]) - 1);
	}
	else if (strcmp(commands[1], "A") == 0 && strcmp(commands[2], "?") == 0) {
		PrintNAttributeCount(command, sections, commands[0]);
	}
	else if (strcmp(commands[1], "A") == 0) {
		PrintNAttributeForI(command, sections, lol::stoi(commands[0]) - 1, commands[2]);
	}
	else if (strcmp(commands[1], "D") == 0 && strcmp(commands[2], "*") == 0) {
		DeleteWholeISection(command, sections, lol::stoi(commands[0]) - 1);
	}
	else if (strcmp(commands[1], "D") == 0) {
		DeleteNAttributeFromISelector(command, sections, lol::stoi(commands[0]) - 1, commands[2]);
	}
	else if (strcmp(commands[1], "E") == 0) {
		PrintNAttributeForSelectorZ(command, sections, commands[0], commands[2]);
	}
}

bool isEmpty(char str[]) {
	for (int i = 0; str[i] != '\0'; i++) {
		if (!isspace(str[i])) return false;
	}
	return true;
}

void ReadCommand(char& c, char buffer[], list<Section>& sections) {
	ClearSpace(c);
	int i = 0;
	char** commands = new char* [4];
	for (int i = 0; 4 > i; i++) {
		commands[i] = new char[1024];
	}
	while (buffer[3] != '*') {
		if (c == EOF || c == '\n') {
			buffer[i] = '\0';
			if (!isEmpty(buffer)) {
				CommandHandler(sections, buffer, commands);
				i = 0;
			}
		}
		else {
			buffer[i++] = c;
		}
		if (c == EOF) break;
		c = getchar();
	}
	for (int i = 0; 4 > i; i++) {
		delete[] commands[i];
	}
	delete[] commands;
}

#pragma endregion

void ReadInput(list<Section>& sections) {
	char buffer[1024], c = getchar();
	do {
		ReadCSS(c, buffer, sections);
		ReadCommand(c, buffer, sections);
	} while (c != EOF && std::cin.get(c));
}

int main()
{
	list<Section> sections;
	ReadInput(sections);
	return 0;
}
