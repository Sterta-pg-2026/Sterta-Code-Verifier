#pragma once
#include "list.h"
#include <iterator>
#include <cstddef>

template <typename T>
class list<T>::reverse_iterator {
private:
	Node<T>* data;
	std::size_t index;
public:
	template <typename T>
	friend class list;

	using iterator_category = std::forward_iterator_tag;
	using difference_type = std::ptrdiff_t;
	using value_type = T;
	using pointer = T*;
	using reference = T&;

	reverse_iterator(Node<T>* node) {
		data = node;
		if (node != nullptr) {
			index = data->_size - 1;
		}
		else {
			index = 0;
		}
	}

	reverse_iterator(const reverse_iterator& it) {
		data = it.data;
		index = it.index;
	}

	reverse_iterator& operator=(const reverse_iterator& it) {
		iterator tmp = it;
		prj::swap(data, it.data);
		prj::swap(index, it.index);
	}

	reverse_iterator& operator++() {
		if (index == 0) {
			data = data->prevNode;
			if (data != nullptr) {
				index = data->_size;
			}
			else {
				index = 1;
			}
		}
		index--;
		return *this;
	}

	bool operator==(const reverse_iterator& it) const {
		return data == it.data && index == it.index;
	}

	bool operator!=(const reverse_iterator& it) const {
		return data != it.data || index != it.index;
	}

	reference operator*() {
		return data->operator[](index);
	}

	pointer operator->() {
		return &(operator*());
	}

};