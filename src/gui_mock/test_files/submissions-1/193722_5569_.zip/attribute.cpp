//
// Created by kamil on 23.03.23.
//

#include "attribute.h"
#include "string.h"

int Attribute::initialize()
{
    int i = property.read_input(2, ":}");
    if (i > 0) return 2;
    return value.read_input(2, ";}");
}

bool Attribute::operator==(Attribute &other)
{
    if (strcmp(property.arr, other.property.arr) == 0)
        return true;
    return false;
}
