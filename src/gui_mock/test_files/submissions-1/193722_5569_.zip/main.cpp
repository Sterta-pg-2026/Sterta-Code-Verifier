#include <iostream>
#include "list.h"
#include "my_string.h"
#include "block.h"
#include <string.h>
#include "commands.h"

using namespace std;

void handle_commands(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    switch (c)
    {
        case 'D':
        {
            if (strcmp(string2->arr, "*") == 0)
            {
                deleteBlock(blocks, string1, c, string2);
            } else
            {
                deleteAttribute(blocks, string1, c, string2);
            }
            break;
        }
        case 'S':
        {
            int i = atoi(string1->arr);
            if (i > 0)
            {
                if (strcmp(string2->arr, "?") == 0)
                {
                    selectorNum(blocks, i, c, string2);
                }
                else
                {
                    findSelector(blocks, i, c, string2);
                }
            }
            else
            {
                if (strcmp(string2->arr, "?") == 0)
                {
                    selectorCount(blocks, string1, c, string2);
                }
                else
                {
                    cout << "ERROR WRONG COMMAND";
                }

            }
            break;
        }
        case 'A':
        {
            int i = atoi(string1->arr);
            if (i > 0)
            {
                if (strcmp(string2->arr, "?") == 0)
                {
                    attributesInSection(blocks, i, c, string2);
                }
                else
                {
                    valueOfAttribute(blocks, i, c, string2);
                }
            }
            else
            {
                if (strcmp(string2->arr, "?") == 0)
                {
                    attributeCount(blocks, string1, c, string2);
                }
                else
                {
                    cout << "WRONG A COMMAND";
                }
            }
            break;
        }
        case 'E':
        {
            valueOfLastAtt(blocks, string1, c, string2);
        }
    }

}

int read_commands(List<Block*> *blocks)
{
    int result;
    my_string str;
    char c;
    char trash;
    my_string str2;

    result = str.read_command(1, ",");
    if (!result)
    {
        cin.get(c);
        cin.get(trash);
        str2.read_command(0, "");
        handle_commands(blocks, &str, c, &str2);
    }
    else if (result != 100)
    {
        if (str.arr[0] == '?')
            cout << "? == " << blocks->num << endl;
        else if (str.arr[0] == '*')
        {
            return 0;
        }
    }
    else
    {
        if (str.arr[0] == '?')
            cout << "? == " << blocks->num << endl;
        return 100;
    }
    return 1;
}

int parseCSS(List<Block*> *blocks)
{
    Block *block = new Block();
    int result = block->initialize();
    if (result == 1)
    {
        delete block;
        my_string str;
        str.read_command(0, "");
        return 1;
    }
    else
    {
        blocks->add(block);
    }
    return 0;
}

int main()
{
    List<Block*> blocks;
    int result = 0;

    while (result != 100)
    {
        if (result == 0)
        {
            result = parseCSS(&blocks);
        }
        else if (result == 1)
        {
            result = read_commands(&blocks);
        }
    }
    return 0;
}
