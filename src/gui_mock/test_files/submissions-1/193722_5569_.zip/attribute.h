//
// Created by kamil on 23.03.23.
//

#ifndef PROJEKT1_ATTRIBUTE_H
#define PROJEKT1_ATTRIBUTE_H

#include "my_string.h"

struct Attribute
{
public:
    Attribute() =default;
    int initialize();
    my_string property;
    my_string value;

    bool operator == (Attribute & other);

};


#endif //PROJEKT1_ATTRIBUTE_H
