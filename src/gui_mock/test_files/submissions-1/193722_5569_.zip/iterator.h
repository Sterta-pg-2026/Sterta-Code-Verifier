//
// Created by kamil on 27.03.23.
//

#ifndef PROJEKT1_ITERATOR_H
#define PROJEKT1_ITERATOR_H

#include "list_el.h"

template<typename T>
class Iterator
{
    List_el<T> *el;
public:
    Iterator(List_el<T> *el);
    Iterator(List_el<T> *el, bool backward);
    Iterator<T>& operator++();
    Iterator<T>& operator--();
    T operator*();
    bool operator!=(Iterator<T> other);
    List_el<T>* get_el();
    int index;
};

template<typename T>
Iterator<T>::Iterator(List_el<T> *el)
{
    this->el = el;
    index = 0;
    if (el != nullptr)
    {
        while (el->value[index] == nullptr)
            index++;
    }
}

template<typename T>
Iterator<T>::Iterator(List_el<T> *el, bool backward)
{
    this->el = el;
    index = List_el<T>::unit_size-1;
    if (el != nullptr)
    {
        while (el->value[index] == nullptr)
            index--;
    }
}

template<typename T>
Iterator<T> &Iterator<T>::operator++()
{
    if (el)
    {
        while (true)
        {
            index++;
            if (index >= List_el<T>::unit_size)
            {
                el = el->next;
                index = 0;
                if (el != nullptr)
                {
                    if (el->value[index] != nullptr)
                        return *this;
                } else
                {
                    return *this;
                }
            }
            if (el->value[index] != nullptr)
                return *this;
        }
    }
    return *this;
}

template<typename T>
T Iterator<T>::operator*()
{
    return this->el->value[index];
}

template<typename T>
bool Iterator<T>::operator!=(Iterator<T> other)
{
    if (other.el != this->el) return true;
    return false;
}

template<typename T>
List_el<T> *Iterator<T>::get_el()
{
    return el;
}

template<typename T>
Iterator<T> &Iterator<T>::operator--()
{
    while (true)
    {
        index--;
        if (index < 0)
        {
            el = el->prev;
            index = List_el<T>::unit_size-1;
            if (el != nullptr)
            {
                if (el->value[index] != nullptr)
                    return *this;
            }
            else
            {
                return *this;
            }
        }
        if (el->value[index] != nullptr)
            return *this;
    }
}

#endif //PROJEKT1_ITERATOR_H
