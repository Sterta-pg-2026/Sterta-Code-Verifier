//
// Created by kamil on 27.03.23.
//

#ifndef PROJEKT1_LIST_EL_H
#define PROJEKT1_LIST_EL_H

template<typename T>
class List_el
{
public:
    const static int unit_size = 29;
    int num;
    int used;
    List_el();

    List_el(T value);

    bool add(T value);
    void remove(int i);

    T value[unit_size];
    List_el<T> *next;
    List_el<T> *prev;
};

template<typename T>
List_el<T>::List_el()
{
    for (int i = 0; i < unit_size; ++i)
    {
        value[i] = nullptr;
    }
    num = 0;
    used = 0;
    prev = next = nullptr;
}

template<typename T>
List_el<T>::List_el(T value)
{
    for (int i = 0; i < unit_size; ++i)
    {
        this->value[i] = nullptr;
    }
    num = 0;
    used = 0;
    this->value[0] = value;
    num++;
    used++;
    prev = next = nullptr;
}

template<typename T>
bool List_el<T>::add(T value)
{
    if (used < unit_size)
    {
        this->value[used] = value;
        used++;
        num++;
        return true;
    }
    return false;
}

template<typename T>
void List_el<T>::remove(int i)
{
    delete value[i];
    value[i] = nullptr;
    num--;

}

#endif //PROJEKT1_LIST_EL_H
