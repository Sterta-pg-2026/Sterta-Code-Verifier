//
// Created by kamil on 29.03.23.
//

#ifndef PROJEKT1_COMMANDS_H
#define PROJEKT1_COMMANDS_H

#include "list.h"
#include "block.h"
#include "my_string.h"
#include <string.h>

void deleteBlock(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    int i = atoi(string1->arr);
    if (blocks->remove(i))
        cout << *string1 << "," << c << "," << *string2 << " == deleted" << endl;
}

void deleteAttribute(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    int i = atoi(string1->arr);
    Iterator<Block *> bl_it = blocks->begin();
    for (int j = 0; j < i - 1; ++j)
    {
        ++bl_it;
    }
    if (bl_it.get_el() != nullptr)
    {
        for (Iterator<Attribute *> it = (*bl_it)->attributes.begin(); it != (*bl_it)->attributes.end(); ++it)
        {
            if ((*it)->property == *string2)
            {
                (*bl_it)->attributes.remove(it);
                if ((*bl_it)->attributes.num == 0)
                {
                    blocks->remove(bl_it);
                }
                cout << *string1 << "," << c << "," << *string2 << " == deleted" << endl;
                return;
            }
        }
    }
}

void selectorNum(List<Block*> *blocks, int i, char c, my_string* string2)
{
    Iterator<Block*> it = blocks->begin();
    for (int j = 0; j < i - 1; ++j)
    {
        ++it;
    }
    if (it.get_el() != nullptr)
        cout << i << "," << c << "," << *string2 << " == " << (*it)->selectors.num << endl;
}

void findSelector(List<Block*> *blocks, int i, char c, my_string* string2)
{
    int j = atoi(string2->arr);
    Iterator<Block*> it = blocks->begin();
    for (int x = 0; x < i - 1; ++x)
    {
        ++it;
    }
    if (it.get_el() != nullptr)
    {
        Iterator<my_string *> str_it = (*it)->selectors.begin();
        for (int x = 0; x < j - 1; ++x)
        {
            ++str_it;
        }
        if (str_it.get_el() != nullptr)
            cout << i << "," << c << "," << *string2 << " == " << **str_it << endl;
    }
}

void selectorCount(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    int num = 0;
    for (auto block: *blocks)
    {
        for (auto sel: block->selectors)
        {
            if (strcmp(sel->arr, string1->arr) == 0) num++;
        }
    }
    cout << *string1 << "," << c << "," << *string2 << " == " << num << endl;
}

void attributesInSection(List<Block*> *blocks, int i, char c, my_string *string2)
{
    Iterator<Block*> it = blocks->begin();
    for (int j = 0; j < i - 1; ++j)
    {
        ++it;
    }
    if (it.get_el() != nullptr)
        cout << i << "," << c << "," << *string2 << " == " << (*it)->attributes.num << endl;
}

void valueOfAttribute(List<Block*> *blocks, int i, char c, my_string *string2)
{
    Iterator<Block*> it = blocks->begin();
    for (int j = 0; j < i - 1; ++j)
    {
        ++it;
    }
    if (it.get_el() != nullptr)
    {
        for (auto att: (*it)->attributes)
        {
            if (strcmp(att->property.arr, string2->arr) == 0)
                cout << i << "," << c << "," << *string2 << " == " << att->value << endl;
        }
    }
}

void attributeCount(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    int num = 0;
    for (auto block: *blocks)
    {
        for (auto att: block->attributes)
        {
            if (strcmp(att->property.arr, string1->arr) == 0) num++;
        }
    }
    cout << *string1 << "," << c << "," << *string2 << " == " << num << endl;
}

void valueOfLastAtt(List<Block*> *blocks, my_string* string1, char c, my_string* string2)
{
    Iterator<Block*> it = blocks->last();
    while (it.get_el() != nullptr)
    {
        for (auto sel : (*it)->selectors)
        {
            if (strcmp(sel->arr, string1->arr) == 0)
            {
                for (auto att : (*it)->attributes)
                {
                    if (strcmp(att->property.arr, string2->arr) == 0)
                    {
                        cout << *string1 << "," << c << "," << *string2 << " == " << att->value << endl;
                        return;
                    }
                }
                return;
            }
        }
        --it;
    }
}

#endif //PROJEKT1_COMMANDS_H
