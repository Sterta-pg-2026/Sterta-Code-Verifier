//
// Created by kamil on 23.03.23.
//

#include "block.h"
#include <string.h>

int Block::initialize()
{
    int last_char = 0;
    while (last_char == 0)
    {
        my_string *str = new my_string();
        last_char = str->read_input(3, ",{?");
        if (last_char != 2)
        {
            if (strcmp(str->arr, "") != 0)
                selectors.add_unique(str);
        }
        else
            return 1;
    }
    last_char = 0;
    while (last_char == 0)
    {
        Attribute *att = new Attribute();
        last_char = att->initialize();
        if (last_char == 2)
        {
            delete att;
            return 0;
        }
        else if (last_char == 1)
        {
            attributes.add_unique(att);
            return 0;
        }
        else
        {
            attributes.add_unique(att);
        }
    }
return 123;
}
