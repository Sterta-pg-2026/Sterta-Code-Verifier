//
// Created by kamil on 27.03.23.
//

#ifndef PROJEKT1_MY_STRING_H
#define PROJEKT1_MY_STRING_H

#include <iostream>

using namespace std;

class my_string
{
public:
    int length;
    char* arr;
    my_string();
    ~my_string();

    void realloc();

    int read_input(int size, const char* end);
    int read_command(int size, const char* end);
    bool operator == (my_string& other);

    friend ostream & operator << (ostream& out, const my_string &str);
};


#endif //PROJEKT1_MY_STRING_H
