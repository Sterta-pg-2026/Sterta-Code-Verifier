//
// Created by kamil on 23.03.23.
//

#ifndef PROJEKT1_BLOCK_H
#define PROJEKT1_BLOCK_H

#include "list.h"
#include "attribute.h"
#include "my_string.h"

struct Block
{
public:
    Block() =default;
    int initialize();
    List<my_string*> selectors;
    List<Attribute*>  attributes;

    bool remove_attribute(my_string* name);
};


#endif //PROJEKT1_BLOCK_H
