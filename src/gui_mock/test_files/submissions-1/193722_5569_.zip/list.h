//
// Created by kamil on 26.11.22.
//

#ifndef GO_LIST_H
#define GO_LIST_H

#include <cassert>
#include "list_el.h"
#include "iterator.h"

template<typename T>
class List
{
    List_el<T> *head;
    List_el<T> *tail;
public:
    int num;
    List();
    ~List();
    void add(T thing);
    bool add_unique(T thing);
    bool remove(int i);
    void remove(Iterator<T> it);
    Iterator<T> begin();
    Iterator<T> end();
    Iterator<T> last();
};

template<typename T>
List<T>::List()
{
    head = tail = nullptr;
    num = 0;
}

template<typename T>
void List<T>::add(T thing)
{
    if(head != nullptr)
    {
        if (!tail->add(thing))
        {
            List_el<T> *new_el = new List_el<T>(thing);
            tail->next = new_el;
            new_el->prev = tail;
            tail = new_el;
        }
    }
    else
    {
        head = new List_el<T>(thing);
        tail = head;
    }
    num++;
}

template<typename T>
bool List<T>::add_unique(T thing)
{
    if(head != nullptr)
    {
        Iterator<T> it = begin();
        while (it != end())
        {
            if (**it == *thing)
            {
                delete it.get_el()->value[it.index];
                it.get_el()->value[it.index] = thing;
                return true;
            }
            ++it;
        }
        if (!tail->add(thing))
        {
            List_el<T> *new_el = new List_el<T>(thing);
            tail->next = new_el;
            new_el->prev = tail;
            tail = new_el;
        }
    }
    else
    {
        head = new List_el<T>(thing);
        tail = head;
    }
    num++;
    return true;
}

template<typename T>
List<T>::~List()
{
    List_el<T> *el = head;
    bool finish = false;
    while (!finish)
    {
        List_el<T> *tmp = el;
        if (el == tail)
        {
            finish = true;
        }
        else
        {
            el = el->next;
        }
        delete tmp;
    }
}

template<typename T>
Iterator<T> List<T>::begin()
{
    return Iterator<T>(this->head);
}

template<typename T>
Iterator<T> List<T>::end()
{
    return Iterator<T>(nullptr);
}

template<typename T>
Iterator<T> List<T>::last()
{
    return Iterator<T>(this->tail, true);
}

template<typename T>
bool List<T>::remove(int i)
{
    if (num >= i)
    {
        Iterator<T> it = begin();
        for (int j = 0; j < i - 1; ++j)
        {
            ++it;
        }
        List_el<T> *el = it.get_el();
        el->remove(it.index);
        if (el->num == 0)
        {
            if (el == head)
            {
                List_el<T> *tmp = head;
                if (head->next)
                {
                    head = head->next;
                    head->prev = nullptr;
                } else
                {
                    head = nullptr;
                    tail = nullptr;
                }
                delete tmp;
            } else if (el == tail)
            {
                tail = el->prev;
                tail->next = nullptr;
                delete el;
            } else
            {
                el->prev->next = el->next;
                el->next->prev = el->prev;
                delete el;
            }
        }
        num--;
        return true;
    }
    return false;
    //List_el<T> *el = head;
/*    while (i > el->num)
    {
        i -= el->num;
        el = el->next;
    }
    for (int j = 0; j < el->unit_size; ++j)
    {
        if (i == 0)
        {
            delete el->value[j];
            el->value[j] = nullptr;
            el->num--;
            return;
        }
        if (el->value[j] != nullptr)
        {
            i--;
        }
    }*/

}

template<typename T>
void List<T>::remove(Iterator<T> it)
{
    List_el<T> *el = it.get_el();
    el->remove(it.index);
    if (el->num == 0)
    {
        if (el == head)
        {
            List_el<T> *tmp = head;
            if (head->next)
            {
                head = head->next;
                head->prev = nullptr;
            }
            else
            {
                head = nullptr;
                tail = nullptr;
            }
            delete tmp;
        }
        else if (el == tail)
        {
            tail = el->prev;
            tail->next = nullptr;
            delete el;
        }
        else
        {
            el->prev->next = el->next;
            el->next->prev = el->prev;
            delete el;
        }
    }
    num--;

}


#endif //GO_LIST_H
