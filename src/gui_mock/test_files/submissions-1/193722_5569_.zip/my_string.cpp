//
// Created by kamil on 27.03.23.
//

#include "my_string.h"
#include <string.h>

my_string::my_string()
{
    arr = new char[8];
    length = 8;
}

my_string::~my_string()
{
    delete[] arr;

}

void my_string::realloc()
{
    char* tmp = arr;
    arr = new char[length*2];
    for (int i = 0; i < length; ++i)
    {
        arr[i] = tmp[i];
    }
    delete[] tmp;
    arr[length] = 0;
    length *= 2;
}

ostream &operator<<(ostream &out, const my_string &str)
{
    out << str.arr;
    return out;
}

int my_string::read_input(int size, const char *end)
{
    char buf;
    cin >> buf;
    while (buf == ' ')
    {
        cin >> buf;
    }
    for (int i = 0; i < size; ++i)
    {
        if (end[i] == buf)
        {
            arr[0] = 0;
            return i;
        }
    }
    arr[0] = buf;
    int index = 1;
    while (cin.get(buf))
    {
        if (buf == '\n') continue;
        for (int i = 0; i < size; ++i)
        {
            if (end[i] == buf)
            {
                arr[index] = 0;
                for (int j = index-1; j >=0; ++j)
                {
                    if (arr[j] == ' ')
                    {
                        arr[j] = 0;
                    }
                    else
                        break;
                }
                return i;
            }
        }
        if (index >= length)
            realloc();
        arr[index] = buf;
        index++;
    }
    return 100;
}

int my_string::read_command(int size, const char* end)
{
    char buf = 0;
    cin >> buf;
    while (buf == ' ' || buf == '\n')
    {
        cin >> buf;
    }
    for (int i = 0; i < size; ++i)
    {
        if (end[i] == buf)
        {
            arr[0] = 0;
            return i;
        }
    }
    arr[0] = buf;
    int index = 1;
    while (cin.get(buf))
    {
        if (buf == '\n')
        {
            arr[index] = 0;
            return 1;
        }
        for (int i = 0; i < size; ++i)
        {
            if (end[i] == buf)
            {
                arr[index] = 0;
                return i;
            }
        }
        if (index >= length)
            realloc();
        arr[index] = buf;
        index++;
    }
    return 100;
}

bool my_string::operator==(my_string &other)
{
    return (strcmp(arr, other.arr) == 0);
}
