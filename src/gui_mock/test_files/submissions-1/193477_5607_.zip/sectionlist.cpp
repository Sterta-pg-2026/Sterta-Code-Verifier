///#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
#pragma once
#include <iostream>
#include "d_l_list.cpp"
#include "mystring2.cpp"

#define L 29

using namespace std;

struct attributes {
	MyString name;
	LinkedList<MyString> ValuesList;
};

class ADLNode {
private:
	ADLNode* prev;
	ADLNode* next;
	struct attributes data;
	friend class AttibutesLinkedList;
public:
	ADLNode() :prev(nullptr), next(nullptr), data{} {}
	//SDLNode(struct section data) :prev(nullptr), next(nullptr), data(data) {}
	attributes getData() {
		return data;
	}
	ADLNode* getNext() {
		return next;
	}
	ADLNode* getPrev() {
		return prev;
	}
	~ADLNode() {
		next = nullptr;
	}
};

class AttibutesLinkedList {
private:
	ADLNode* Head;
	//int count;
public:
	void CreateNode() {
		ADLNode* node = new ADLNode();
		if (Head == NULL) {
			Head = node;
			//cout << "new node";
			return;
		}
		ADLNode* temp = Head;
		ADLNode* prev = nullptr;
		while (temp->next != NULL) {
			prev = temp;
			temp = temp->next;
		}
		temp->next = node;
		temp->prev = prev;
		//this->count++;
	}

	void AttributesLinkedList() {
		//this->count = -1;
		CreateNode();
	}

	void SetAttributeName(MyString str) {
		if (Head == NULL) {
			CreateNode();
			Head->data.name.add(str);
			return;
		}
		ADLNode* node = new ADLNode();
		node->data.name.add(str);
		ADLNode* temp = Head;
		ADLNode* prev = nullptr;
		while (temp->next != NULL) {
			prev = temp;
			temp = temp->next;
		}
		temp->next = node;
		temp->prev = prev;
	}

	void addAttributeValue(MyString str) {
		ADLNode* temp = Head;
		while (temp->next != NULL) {
			temp = temp->next;
		}
		temp->data.ValuesList.addLast(str);
	}
	void getAttributeName(int index) {
		ADLNode* temp = Head;
		int i = 0;
		while (i != index) {
			temp = temp->next;
			i++;
		}
		cout << temp->data.name;
	}
	void getAttributeValue(int index) {
		ADLNode* temp = Head;
		int i = 0;
		while (i != index) {
			temp = temp->next;
			i++;
		}
		temp->data.ValuesList.display();
	}
	int length() {
		int len = 0;
		ADLNode* temp = Head;
		while (temp != NULL) {
			len++;
			temp = temp->next;
		}
		return len;
	}
	int findAttributeByName(MyString str) {
		int index = 0;
		ADLNode* temp = Head;
		while (temp != NULL) {
			if (temp->data.name == str) {
				//cout << temp->data.name;
				return index;
			}
			index++;
			temp = temp->next;
		}
		return index;
	}
	void removeAttribute(int index) {
		int len = 0;
		ADLNode* temp = Head;
		ADLNode* prev = NULL;
		ADLNode* next = Head->next;
		for (int i = 0; i < index; i++) {
			prev = temp;
			temp = temp->next;
			next = temp->next;
		}
		if (temp == Head) {
			Head = temp->next;
			prev = NULL;
			delete temp;
		}
		else {
			prev->next = next;
			delete temp;
		}
	}
	void removeAll() {
		this->Head = NULL;
	}
	void changeAttributeValue(MyString str, int index) {
		ADLNode* temp = Head;
		int i = 0;
		while (i != index) {
			temp = temp->next;
			i++;
		}
		temp->data.ValuesList.addLast(str);
		temp->data.ValuesList.remove(str);
	}
};

struct section {
	LinkedList<MyString> selectors;
	AttibutesLinkedList attributes;
};

class SDLNode {
private:
	SDLNode* prev;
	SDLNode* next;
	struct section data[L];
	friend class SectionLinkedList;
public:
	SDLNode() :prev(nullptr), next(nullptr), data{} {}
	//SDLNode(struct section data) :prev(nullptr), next(nullptr), data(data) {}
	section* getData() {
		return data;
	}
	SDLNode* getNext() {
		return next;
	}
	SDLNode* getPrev() {
		return prev;
	}
};

class SectionLinkedList {
private:
	SDLNode* Head;
	int lastIndex;
	int count;
public:
	void createNode() {
		SDLNode* node = new SDLNode();
		if (Head == NULL) {
			Head = node;
			//cout << "new node";
			return;
		}
		SDLNode* temp = Head;
		SDLNode* prev = nullptr;
		while (temp->next != NULL) {
			prev = temp;
			temp = temp->next;
		}
		temp->next = node;
		temp->prev = prev;

		//this->lastIndex++;
		//this->count++;
	}
	SectionLinkedList() :Head(NULL), lastIndex(0), count(0) {
		this->createNode();
	}

	void addLast(struct section data) {
		int count = 0;
		if (this->lastIndex % L == 0) {
			this->createNode();
		}
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L >= this->lastIndex) {
				temp->data[this->lastIndex - count] = data;
				break;
			}
			count += L;
			temp = temp->next;
		}
		this->lastIndex++;
	}
	void addSelectorName(MyString str, int *newnode) {
		//cout << str << endl;
		int count = 0;
		if (this->lastIndex % L == 0 && *newnode == 1) {
			*newnode = 0;
			this->createNode();
		}
		int add = 1;
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L > this->lastIndex) {
				for (int i = 0; i < temp->data[this->lastIndex - count].selectors.length(); i++) {
					if (temp->data[this->lastIndex - count].selectors.get(i) == str) { add = 0; }
				}
				if (!(str == "")) {
					if (add == 1) { temp->data[this->lastIndex - count].selectors.addLast(str); }
					break;
				}
			}
			count += L;
			temp = temp->next;
		}
	}
	void addAtribute(attributes attr, int* newnode) {
		//	Head->data[lastIndex].attributes.addLast(attr);
	}
	void addAttributeName(MyString str, int* newnode) {
		int count = 0;
		if (this->lastIndex % L == 0 && *newnode == 1) {
			*newnode = 0;
			this->createNode();
		}
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L > this->lastIndex) {
				if (temp->data[this->lastIndex - count].attributes.length() == 0 || temp->data[this->lastIndex - count].attributes.findAttributeByName(str) >= temp->data[this->lastIndex - count].attributes.length()) {
					temp->data[this->lastIndex - count].attributes.SetAttributeName(str);
				}
				break;
			}
			count += L;
			temp = temp->next;
		}
	}
	void addAttributeValue(MyString val, MyString attr, int change, int* newnode) {
		int count = 0;
		if (this->lastIndex % L == 0 && *newnode == 1) {
			*newnode = 0;
			this->createNode();
		}
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L > this->lastIndex) {
				int j = temp->data[this->lastIndex - count].attributes.findAttributeByName(attr);
				if (change == 1 && j < temp->data[this->lastIndex - count].attributes.length()) { temp->data[this->lastIndex - count].attributes.changeAttributeValue(val, j); }
				else { temp->data[this->lastIndex - count].attributes.addAttributeValue(val); }
				break;
			}
			count += L;
			temp = temp->next;
		}
	}
	void getSelectorName(int index) {
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L >= index) {
				output = temp->data[index - count];
				break;
			}
			count += L;
			temp = temp->next;
		}
		output.selectors.display();
	}
	void getSelectorName(int index, int j) {
		index--;
		j--;
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}

			output = temp->data[i];
			//MyString n = output.selectors.get(j);
			if (output.selectors.length() > j && !(output.selectors.get(j) == "") && !(output.selectors.get(j) == "\n")) {
				cout << index + 1 << ",S," << j + 1 << " == " << output.selectors.get(j) << endl;
			}
		}
		//output.selectors.displayindex(j);
	}
	void getAttributeName(int index, int index2) {
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L >= index) {
				output = temp->data[index - count];
				break;
			}
			count += L;
			temp = temp->next;
		}
		output.attributes.getAttributeName(index2);
	}
	void getAttributevalue(int index, int index2) {
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		while (temp != NULL) {
			if (count + L >= index) {
				output = temp->data[index - count];
				break;
			}
			count += L;
			temp = temp->next;
		}
		output.attributes.getAttributeValue(index2);
	}
	int getLastIndex() {
		return this->lastIndex;
	}
	int getSelectorNumber(int index) {
		index--;
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}
		}
		else { return -1; }
		output = temp->data[i];
		if (output.selectors.get(0) == "\n") { return 0; }
		return output.selectors.length();
	}
	int getAttributeNumber(int index) {
		index--;
		int count = 0;
		struct section output;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}
		}
		else { return 0; }
		output = temp->data[i];
		return output.attributes.length();
	}
	void findAttributeValue(int index, MyString str) {
		index--;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}
			int m = temp->data[i].attributes.findAttributeByName(str);
			if (m < temp->data[i].attributes.length()) {
				cout << index + 1 << ",A," << str << " == ";
				temp->data[i].attributes.getAttributeValue(m);
			}
		}
	}

	int countAttribute(MyString str) {
		int count = 0;
		SDLNode* temp = Head;
		while (temp != NULL) {
			for (int i = 0; i < L; i++) {
				if (temp->data[i].attributes.findAttributeByName(str) < temp->data[i].attributes.length()) {
					count++;
				}
			}
			temp = temp->next;
		}
		return count;
	}

	int countSelectors(MyString str) {
		int count = 0;
		SDLNode* temp = Head;
		while (temp != NULL) {
			for (int i = 0; i < L; i++) {
				if (temp->data[i].attributes.length() != 0) {
					for (int j = 0; j < temp->data[i].selectors.length(); j++) {
						if (temp->data[i].selectors.get(j) == str) {
							count++;
						}
					}
				}
			}
			temp = temp->next;
		}
		return count;
	}
	void findAttributeForSelector(MyString attr, MyString sel) {
		int index = -1;
		SDLNode* temp = Head;
		SDLNode* temp2 = Head;
		while (temp != NULL) {
			for (int i = 0; i < L; i++) {
				for (int j = 0; j < temp->data[i].selectors.length(); j++) {
					//cout<<(temp->data[i].selectors.get(j));
					if (temp->data[i].selectors.get(j) == sel) {
						if (temp->data[i].attributes.findAttributeByName(attr) < temp->data[i].attributes.length()) {
							index = i;
							temp2 = temp;
						}
					}
				}
			}
			temp = temp->next;
		}
		if (index > -1) {
			int i = temp2->data[index].attributes.findAttributeByName(attr);
			if (i < temp2->data[index].attributes.length()) {
				cout << sel << ",E," << attr << " == ";
				temp2->data[index].attributes.getAttributeValue(i);
			}
		}
	}
	void remove(int index) {
		index--;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}
			temp->data[i].attributes.removeAll();
			cout << index + 1 << ",D,* == deleted" << endl;
			//usunac sekcje
			this->count--;
		}
	}
	int countSections() {
		return this->count;
	}
	void setLastIndex() {
		this->lastIndex++;
		this->count++;
	}
	void removeAttribute(int index, MyString str) {
		index--;
		SDLNode* temp = Head;
		int c = -1, i = 0;
		if (index + 1 <= this->count) {
			while (c <= index) {
				if (temp->data[i].attributes.length() != 0) {
					c++;
					if (c >= index) { break; }
				}
				i++;
				if (i % L == 0) {
					i = 0;
					temp = temp->next;
				}
			}

			int n = temp->data[i].attributes.findAttributeByName(str);
			if (n < temp->data[i].attributes.length()) {
				temp->data[i].attributes.removeAttribute(n);
				cout << index + 1 << ",D," << str << " == deleted" << endl;
			}
			int m = temp->data[i].attributes.length();
			if (temp->data[i].attributes.length() == 0) {
				this->count--;
			}
		}
	}
	void clear() {
		int len = 0;
		SDLNode* temp = Head;
		while (temp != nullptr) {
			SDLNode* next = temp->next;
			delete temp;
			temp = next;
			next = nullptr;
		}
	}
	~SectionLinkedList() {
		this->clear();
	}
};


