//#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996) //<-- crtsecurenowatnings
#include <iostream>
#include "d_l_list.cpp"
#include "mystring2.cpp"
#include "sectionlist.cpp"

#define T 8

using namespace std;



void wczytaj(MyString* s) {
	char c = getchar();
	while (c != ',' && c != '{') {
		s->addchar(c);
		c = getchar();
	}
}
int main() {
	char c = getchar();
	int selectors = 1;
	int attributeName = 1;
	int commends = 0;
	int attrValueChange = 1;
	int newnode = 1;
	SectionLinkedList list;
	MyString lastAttr = "";
	while (c != EOF) {
		MyString s = "";
		MyString lastAttr2 = lastAttr;
		//MyString lastAttr = "";
		if (c == '?') {
			int i = 1;
			c = getchar();
			while (c == '?') {
				i++;
				c = getchar();
			}
			if (i == 4) {
				commends = 1;
			}
		}
		if (commends == 1) {
			if (c != EOF) { c = getchar(); }
			while (c == '\n') { c = getchar(); }
			if (c == '*') {
				int i = 0;
				while (c == '*') {
					i++;
					c = getchar();
				}
				if (i == 4) {
					commends = 0;
				}
			}
			else if (c == '?') {
				cout << "? == " << list.countSections() << endl;
			}
			else if (isdigit(c)) {
				MyString a = "";
				while (isdigit(c)) {
					a.addchar(c);
					c = getchar();
				}
				int i = a.stoi();
				c = getchar();
				if (c == 'S') {
					c = getchar();
					c = getchar();
					if (c == '?') {
						if (list.getSelectorNumber(i) >= 0) { cout << i << ",S,? == " << list.getSelectorNumber(i) << endl; }
					}
					else if (isdigit(c)) {
						MyString b = "";
						while (isdigit(c)) {
							b.addchar(c);
							c = getchar();
						}
						int j = b.stoi();
						list.getSelectorName(i, j);
					}
				}
				else if (c == 'A') {
					c = getchar();
					c = getchar();
					if (c == '?') {
						if (list.getAttributeNumber(i) > 0) { cout << i << ",A,? == " << list.getAttributeNumber(i) << endl; }
					}
					else {
						MyString b = "";
						while (c != '\n' and c != EOF) {
							b.addchar(c);
							c = getchar();
						}
						list.findAttributeValue(i, b);
					}
				}
				else if (c == 'D') {
					c = getchar();
					c = getchar();
					if (c == '*') {
						list.remove(i);
					}
					else {
						MyString n = "";
						n.addchar(c);
						c = getchar();
						while (c != ' ' && c != '\n' && c != EOF) {
							n.addchar(c);
							c = getchar();
						}
						list.removeAttribute(i, n);
					}
				}
				while (c != '\n' && c != '\r' && c != EOF) { c = getchar(); }
			}
			else if (c != EOF) {
				MyString a = "";
				while (c != ',' && c != EOF) {
					a.addchar(c);
					c = getchar();
				}
				MyString b = "";
				b.addchar(getchar());
				b.addchar(getchar());
				if (b == "A,") {
					b.addchar(getchar());
					int countattr = list.countAttribute(a);
					if (countattr >= 0) { cout << a << "," << b << " == " << countattr << endl; }

				}
				else if (b == "S,") {
					b.addchar(getchar());
					int countsel = list.countSelectors(a);
					if (countsel >= 0) { cout << a << "," << b << " == " << countsel << endl; }
				}
				else if (b == "E,") {
					MyString n = "";
					c = getchar();
					while (c != '\n' && c != ' ') {
						n.addchar(c);
						c = getchar();
					}
					list.findAttributeForSelector(n, a);
				}
				else {
					while (c != '\n' && c != EOF) {
						c = getchar();
					}
				}
			}
		}
		else {
			while (c != ',' && c != '{' && c != '}' && c != ':' && c != ';') {
				s.addchar(c);
				c = getchar();
				while (c == '\n') { c = getchar(); }
			}
			if (c == ',') {
				if (selectors == 1) {
					list.addSelectorName(s, &newnode);
					newnode = 0;
				}
				else if (attributeName == 1) {
					list.addAttributeName(s, &newnode);
					newnode = 0;
				}
				else {
					list.addAttributeValue(s, lastAttr, attrValueChange, &newnode);
					attrValueChange = 0;
					newnode = 0;
				}
			}
			else if (c == '{') {
				if (s[s.getSize() - 1] == ' ') {
					s.removeLast();
				}
				if (s.getTabsize() > 0) {
					list.addSelectorName(s, &newnode);
					selectors = 0;
					newnode = 0;
				}
			}
			else if (c == ':') {
				if (selectors == 1) {
					while (c != ',' && c != '{' && c != '\n' && c != '\t') {
						s.addchar(c);
						c = getchar();
					}
					if (s[s.getSize() - 1] == ' ') {
						s.removeLast();
					}
					list.addSelectorName(s, &newnode);
					newnode = 0;
					while (c == '\n' || c == '\t' || c <= ' ') { c = getchar(); }
					if (c == '{') { selectors = 0; }
				}
				else {
					list.addAttributeName(s, &newnode);
					attributeName = 0;
					lastAttr.clear();
					lastAttr.add(s);
					newnode = 0;
				}
			}
			else if (c == ';') {
				list.addAttributeValue(s, lastAttr2, attrValueChange, &newnode);
				attributeName = 1;
				lastAttr.clear();
				attrValueChange = 1;
				newnode = 0;
			}
			else if (c == '}') {
				selectors = 1;
				if (list.getLastIndex() % L == 0) {
					list.createNode();
					list.setLastIndex();
				}
				else {
					list.setLastIndex();
				}
				newnode = 1;
			}
			if (c != EOF) {
				c = getchar();
				while (c == '\n' || c == '\t' || c <= ' ') { c = getchar(); }
			}
		}

	}

}