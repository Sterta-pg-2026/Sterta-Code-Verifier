//#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
#pragma once
#include <iostream>

using namespace std;

template <typename T> class DLNode {
private:
	DLNode<T>* prev;
	DLNode<T>* next;
	T data;
	template <typename F> friend class LinkedList;
public:
	DLNode(T data) :data(data) {
		this->next = NULL;
		this->prev = NULL;
	}
	T& getData() {
		return data;
	}
	DLNode* getNext() {
		return next;
	}
	DLNode* getPrev() {
		return prev;
	}
};

template <typename T> class LinkedList {
private:
	DLNode<T>* Head;
public:
	LinkedList() :Head(NULL) {}
	void addLast(T data) {
		DLNode<T>* node = new DLNode<T>(data);
		if (Head == NULL) {
			Head = node;
			return;
		}
		DLNode<T>* temp = Head;
		DLNode<T>* prev = nullptr;
		while (temp->next != NULL) {
			prev = temp;
			temp = temp->next;
		}
		temp->next = node;
		temp->prev = prev;
		//cout << "new node back";
	}
	int length() {
		int len = 0;
		DLNode<T>* temp = Head;
		while (temp != NULL) {
			len++;
			temp = temp->next;
		}
		return len;
	}
	void display() {
		/*if (Head == NULL) {
			cout << "linked list is empty" << Head <<endl;
			return;
		}*/
		//cout << "items" << endl;
		DLNode<T>* temp = Head;
		while (temp != NULL) {
			cout << temp->data;
			if (temp->next != NULL) {
				cout << ", ";
			}
			temp = temp->next;
		}
		cout << '\n';
	}
	void remove(T data) {
		DLNode<T>* temp = Head->next;
		while (temp != NULL) {
			DLNode<T>* next = temp->next;
			temp->next = nullptr;
			delete temp;
			temp = next;
			next = nullptr;
		}
		Head = new DLNode<T>(data);
	}
	T& get(int index) {
		/*if (Head == NULL) {
			cout << "list is empty"<<endl;
			T output = NULL;
			return output;
		}
		if (index >= length() || index < 0) {
			cout << "wrong index" << endl;
			T output = NULL;
			return output;
		}*/
		int count = 0;
		T output;
		DLNode<T>* temp = Head;
		while (temp != NULL) {
			if (count == index) {
				break;
			}
			count++;
			temp = temp->next;
		}
		return temp->getData();
	}
	void displayindex(int index) {
		int count = 0;
		T output;
		DLNode<T>* temp = Head;
		while (temp != NULL) {
			if (count == index) {
				output = temp->data;
				break;
			}
			count++;
			temp = temp->next;
		}
		cout << output;
	}
	/*void setValue(T data) {

	}*/
};
