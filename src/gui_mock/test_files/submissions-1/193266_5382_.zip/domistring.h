#pragma once
#include <string.h>

class DomiString {

private:
	char* domi_wsk;
public:
	DomiString();
	DomiString(const char* s_chr);
	DomiString(const DomiString& s);//kopiowanie
	void Wypisz();
	int Dlugosc();
	~DomiString();
	DomiString& operator=(const DomiString& test);//przyrownanie
	bool operator==(const DomiString& s);//porownanie
	bool operator!=(const DomiString& s);



};