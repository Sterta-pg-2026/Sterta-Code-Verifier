#pragma once
#include "domisel.h"
#include "funkcje.h"

DomiSel::DomiSel() {
	this->sel_start = NULL;
}
DomiSel::DomiSel(const DomiSel& s) {
//	this->domi_wsk = new char[strlen(s.domi_wsk) + 1];//+ 1 bo mamy na ostatnim miejscu zero
//	strcpy(this->domi_wsk, s.domi_wsk);
	struct Sel* tym2;

	this->sel_start = NULL;
	tym2 = s.sel_start;
	while (tym2 != NULL) {
		this->Dodaj(tym2->nazwa);
		tym2 = tym2->nastepny;
	}
}
DomiSel:: ~DomiSel() {
	struct Sel* tym2;

	while (this->sel_start != NULL) {
		tym2 = this->sel_start->nastepny;
		delete this->sel_start;
		this->sel_start = tym2;
	}
}
void DomiSel::Kasuj() {
	struct Sel* tym2;

	while (this->sel_start != NULL) {
		tym2 = this->sel_start->nastepny;
		delete this->sel_start;
		this->sel_start = tym2;
	}
}
void DomiSel::Dodaj(DomiString nazwa) {
	struct Sel* tym;
	if (this->sel_start == NULL) {
		this->sel_start = new Sel();
		this->sel_start->nastepny = NULL;
		this->sel_start->nazwa = nazwa;
	}
	else {
		tym = this->sel_start;
		while (tym->nastepny != NULL) {
			tym = tym->nastepny;
		}
		tym->nastepny = new Sel();
		tym->nastepny->nastepny = NULL;
		tym->nastepny->nazwa = nazwa;
//		while (tym->nastepny != NULL) {
//			tym = tym->nastepny;
//		}
//		tym->nastepny = new Sel();
//		tym->nastepny->nastepny = NULL;
//		tym->nastepny->nazwa = nazwa;
	}
}

int DomiSel::Policz() {
	struct Sel* tym = this->sel_start;
	int ilosc = 0;
	while (tym != NULL) {
		ilosc++;
		tym = tym->nastepny;
	}
	return ilosc;
}

void DomiSel::Usun(DomiString nazwa) {
	struct Sel* tym;
	struct Sel* tym2;
	if (this->sel_start != NULL) {
		if (this->sel_start->nazwa == nazwa) {
			tym2 = this->sel_start->nastepny;
			delete this->sel_start;
			this->sel_start = tym2;
		}
		else {
			tym = this->sel_start;
			while (tym->nastepny != NULL) {
				if (tym->nastepny->nazwa == nazwa) {
					tym2 = tym->nastepny->nastepny;
					delete tym->nastepny;
					tym->nastepny = tym2;
					break;
				}
				tym = tym->nastepny;
			}
		}
	}
}
struct Sel* DomiSel::ZnajdzSel(DomiString nazwa) {
	struct Sel* tym = this->sel_start;
	while (tym != NULL) {
		if (tym->nazwa == nazwa)
			return tym;
		tym = tym->nastepny;
	}
	return NULL;
}
struct Sel* DomiSel::ZnajdzJoty(int jot) {
	struct Sel* tym = this->sel_start;
	int qwerty = 1;
	while (tym != NULL) {
		if (qwerty == jot)
			return tym;
		qwerty++;
		tym = tym->nastepny;
	}
	return NULL;
}
DomiSel& DomiSel::operator=(const DomiSel& s) {
	struct Sel* tym2;

	tym2 = s.sel_start;
	if (this != &s) {
//		delete[](this->domi_wsk);
//		this->domi_wsk = new char[strlen(s.domi_wsk) + 1];
//		strcpy(this->domi_wsk, s.domi_wsk);
		while (tym2 != NULL) {
			this->Dodaj(tym2->nazwa);
			tym2 = tym2->nastepny;
		}
	}
	return *this;
}