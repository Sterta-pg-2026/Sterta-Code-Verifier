#pragma once
#include "domistring.h"
class DomiList {
private:
	struct SekList* sl_start;
	struct SekList* sl_stop;
	int SekLiczba;
public:
	DomiList();
	~DomiList();
	void Dodaj(DomiAtr datr, DomiSel dsel);
	int PodajLiczbaSekcji();
	void BlokLiczbaSel(const int sekcja, int& i);
	void BlokLiczbaAtr(const int sekcja, int& i);
	DomiString  BlokSelelektor(const int sekcja, const int selektor, int& liczba);
	DomiString  BlokAtrybutWartosc(const int sekcja, DomiString s, int& liczba);
	DomiString  WartoscAtrybutSelektora(DomiString buf1, DomiString buf3, int& liczba);
	void UsunAtrybut(const int liczba1, DomiString buf3, int& liczba);
	void UsunSekcje(const int liczba1, int& liczba);
	void LiczbaSelNazwa(DomiString s, int& liczba);
	void LiczbaAtrNazwa(DomiString s, int& liczba);
};
