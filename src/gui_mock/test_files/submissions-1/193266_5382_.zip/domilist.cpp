#include "funkcje.h"
#include "domilist.h"
DomiList::DomiList() {
	//wlasciwosci klasy
	this->sl_start = new SekList();
	this->sl_stop = this->sl_start;
	this->SekLiczba = 0;
	//pierwszy element listy
	this->sl_start->sek_liczba = 0;
	this->sl_start->nastepny = NULL;
	this->sl_start->poprzedni = NULL;
}
DomiList::~DomiList() {

}

int DomiList::PodajLiczbaSekcji(){
	return this->SekLiczba;
}
void DomiList::BlokLiczbaSel(const int sekcja, int& liczba) {
	struct SekList* tym;
	int i;
	int k = 0;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++) {
			k++;
//			if (tym->sektab[i].numer == sekcja)
			if (k == sekcja)
				liczba = tym->sektab[i].selektrory.Policz();
		}
		tym = tym->nastepny;
	}
}
void DomiList::BlokLiczbaAtr(const int sekcja, int& liczba) {
	struct SekList* tym;
	int i;
	int k = 0;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++) {
			k++;
			if (k == sekcja)
			//			if (tym->sektab[i].numer == sekcja)
				liczba = tym->sektab[i].atrybuty.Policz();
		}
		tym = tym->nastepny;
	}
}
DomiString DomiList::BlokSelelektor(const int sekcja, const int selektor, int& liczba) {
	struct SekList* tym;
	struct Sel* tymsel;
	int i;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++)
			if (tym->sektab[i].numer == sekcja) {
				tymsel = tym->sektab[i].selektrory.ZnajdzJoty(selektor);
				if (tymsel != NULL) {
					liczba = tym->sektab[i].selektrory.Policz();
					return tymsel->nazwa;
				}
			}
		tym = tym->nastepny;
	}
	return DomiString("");
}
void DomiList::UsunSekcje(const int sekcja, int& liczba) {
	struct SekList* tym;
	int i, j;
	int k = 0;
	tym = this->sl_start;
	this->SekLiczba--;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++) {
				k++;
				if (k == sekcja) {
					//			if (tym->sektab[i].numer == sekcja) {
				//znaleziono sekcje do skasowania
				for (j = i;j < tym->sek_liczba - 1;j++) {
					//					tym->sektab[j].numer = tym->sektab[j + 1].numer-1;
					tym->sektab[j].atrybuty.Kasuj();
					tym->sektab[j].atrybuty = tym->sektab[j + 1].atrybuty;
					tym->sektab[j].selektrory.Kasuj();
					tym->sektab[j].selektrory = tym->sektab[j + 1].selektrory;
				}
				while (tym->nastepny != NULL) {
					//					tym->sektab[tym->sek_liczba].numer = tym->nastepny->sektab[0].numer - 1;
					tym->sektab[tym->sek_liczba-1].atrybuty.Kasuj();
					tym->sektab[tym->sek_liczba-1].atrybuty = tym->nastepny->sektab[0].atrybuty;
					tym->sektab[tym->sek_liczba-1].selektrory.Kasuj();
					tym->sektab[tym->sek_liczba-1].selektrory = tym->nastepny->sektab[0].selektrory;
					for (j = 0;j < tym->sek_liczba - 1;j++) {
						//						tym->nastepny->sektab[j].numer = tym->nastepny->sektab[j + 1].numer - 1;
						tym->nastepny->sektab[j].atrybuty.Kasuj();
						tym->nastepny->sektab[j].atrybuty = tym->nastepny->sektab[j + 1].atrybuty;
						tym->nastepny->sektab[j].selektrory.Kasuj();
						tym->nastepny->sektab[j].selektrory = tym->nastepny->sektab[j + 1].selektrory;
					}
					tym = tym->nastepny;
				}
				tym->sek_liczba--;
			}
		}
		tym = tym->nastepny;
	}
	liczba = 0;
}
void DomiList::UsunAtrybut(const int sekcja, DomiString buf3, int& liczba) {
	struct SekList* tym;
	int i;
	int k = 0;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++) {
			//			if (tym->sektab[i].numer == sekcja) {
			k++;
			if (k == sekcja) {
				if (tym->sektab[i].atrybuty.ZnajdzAtr(buf3) != NULL) {
					tym->sektab[i].atrybuty.Usun(buf3);
					if (tym->sektab[i].atrybuty.Policz() <= 0) {
						this->UsunSekcje(sekcja, liczba);
					}
				}
			}
		}
		tym = tym->nastepny;
	}
}
DomiString  DomiList::WartoscAtrybutSelektora(DomiString buf1, DomiString buf3, int& liczba) {
	struct SekList* tym;
	struct Atr* tymatr;
	int i;
	tym = this->sl_stop;
	while (tym != NULL) {
		for (i = tym->sek_liczba-1;i>=0; i--)//22:04
			if (tym->sektab[i].selektrory.ZnajdzSel(buf1) != NULL) {
				tymatr = tym->sektab[i].atrybuty.ZnajdzAtr(buf3);
				if (tymatr != NULL) {
					liczba = tym->sektab[i].atrybuty.Policz();
					return tymatr->wartosc;
				}
			}
		tym = tym->poprzedni;
	}
	return DomiString("");

}
DomiString DomiList::BlokAtrybutWartosc(const int sekcja, DomiString s, int& liczba) {
	struct SekList* tym;
	struct Atr* tymatr;
	int i;
	int k = 0;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++) {
			//			if (tym->sektab[i].numer == sekcja) {
			k++;
			if (k == sekcja) {
				tymatr = tym->sektab[i].atrybuty.ZnajdzAtr(s);
				if (tymatr != NULL) {
					liczba = tym->sektab[i].atrybuty.Policz();
					return tymatr->wartosc;
				}
			}
		}
		tym = tym->nastepny;
	}
	return DomiString("");
}
void DomiList::LiczbaSelNazwa(DomiString s, int& liczba) {
	struct SekList* tym;
//	struct Sel* tymsel;
	int i;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++)
			if (tym->sektab[i].selektrory.ZnajdzSel(s) != NULL) {
				liczba++;
				}
		tym = tym->nastepny;
	}
}
void DomiList::LiczbaAtrNazwa(DomiString s, int& liczba) {
	struct SekList* tym;
//	struct Atr* tymatr;
	int i;
	tym = this->sl_start;
	while (tym != NULL) {
		for (i = 0;i < tym->sek_liczba;i++)
			if (tym->sektab[i].atrybuty.ZnajdzAtr(s) != NULL) {
				liczba++;
			}
		tym = tym->nastepny;
	}
}
void DomiList::Dodaj(DomiAtr datr, DomiSel dsel) {
	struct SekList* tym;
	tym = this->sl_stop;
	if(tym->sek_liczba >= T) {
		tym->nastepny = new SekList();
		tym->nastepny->nastepny = NULL;
		tym->nastepny->poprzedni = tym;
		tym->nastepny->sek_liczba = 0;
		this->sl_stop = tym->nastepny;
	}
	this->SekLiczba++;
	this->sl_stop->sek_liczba++;
	this->sl_stop->sektab[this->sl_stop->sek_liczba - 1].numer = this->sl_stop->sek_liczba;
	this->sl_stop->sektab[this->sl_stop->sek_liczba - 1].atrybuty = datr;
	this->sl_stop->sektab[this->sl_stop->sek_liczba - 1].selektrory = dsel;
}