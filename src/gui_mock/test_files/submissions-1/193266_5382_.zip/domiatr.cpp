#pragma once
#include "domiatr.h"
#include "funkcje.h"

DomiAtr::DomiAtr() {
	this->atr_start = NULL;
}
DomiAtr::DomiAtr(const DomiAtr& s) {
	struct Atr* tym2;

	this->atr_start = NULL;
	tym2 = s.atr_start;
	while (tym2 != NULL) {
		this->Dodaj(tym2->nazwa, tym2->wartosc);
		tym2 = tym2->nastepny;
	}
}
DomiAtr:: ~DomiAtr() {
	struct Atr* tym2;

	while(this->atr_start != NULL) {
		tym2 = this->atr_start->nastepny;
		delete this->atr_start;
		this->atr_start = tym2;
	}
}
void DomiAtr:: Kasuj() {
	struct Atr* tym2;

	while (this->atr_start != NULL) {
		tym2 = this->atr_start->nastepny;
		delete this->atr_start;
		this->atr_start = tym2;
	}
}
void DomiAtr::Dodaj(DomiString nazwa, DomiString wartosc) {
	struct Atr* tym; 
	if (this->atr_start == NULL) {
		this->atr_start = new Atr();
		this->atr_start->nastepny = NULL;
		this->atr_start->nazwa = nazwa;
		this->atr_start->wartosc = wartosc;
	}
	else {
//sprawdzamy czy juz nie ma
		tym = this->ZnajdzAtr(nazwa);
		if (tym != NULL) {
			tym->wartosc = wartosc;
		}
//dodajemy na koncu jak nie ma
		else {
			tym = this->atr_start;
			while (tym->nastepny != NULL) {
				tym = tym->nastepny;
			}
			tym->nastepny = new Atr();
			tym->nastepny->nastepny = NULL;
			tym->nastepny->nazwa = nazwa;
			tym->nastepny->wartosc = wartosc;
		}
	}
}

int DomiAtr::Policz() {
	struct Atr* tym = this->atr_start;
	int ilosc = 0;
	while (tym != NULL) {
		ilosc++;
		tym = tym->nastepny;
	}
	return ilosc;
}

void DomiAtr::Usun(DomiString nazwa) {
	struct Atr* tym;
	struct Atr* tym2;
	if (this->atr_start != NULL) {
		if ( this->atr_start->nazwa == nazwa)  {
			tym2 = this->atr_start->nastepny;
			delete this->atr_start;
			this->atr_start = tym2;
		}
		else {
			tym = this->atr_start;
			while (tym->nastepny != NULL) {
				if (tym->nastepny->nazwa == nazwa) {
					tym2 = tym->nastepny->nastepny;
					delete tym->nastepny;
					tym->nastepny = tym2;
					break;
				}
				tym = tym->nastepny;
			}
		}
	}
}
struct Atr* DomiAtr::ZnajdzAtr(DomiString nazwa) {
	struct Atr* tym = this->atr_start;
	while (tym != NULL) {
		if (tym->nazwa == nazwa)
			return tym;
		tym = tym->nastepny;
	}
	return NULL;
}
DomiAtr& DomiAtr::operator=(const DomiAtr& s) {
	struct Atr* tym2;

	tym2 = s.atr_start;
	if (this != &s) {
		//		delete[](this->domi_wsk);
		//		this->domi_wsk = new char[strlen(s.domi_wsk) + 1];
		//		strcpy(this->domi_wsk, s.domi_wsk);
		while (tym2 != NULL) {
			this->Dodaj(tym2->nazwa, tym2->wartosc);
			tym2 = tym2->nastepny;
		}
	}
	return *this;
}