#pragma once
#include "domistring.h"
class DomiSel {
private:
	struct Sel* sel_start;
public:
	DomiSel();
	DomiSel(const DomiSel& s);
	~DomiSel();
	void Dodaj(DomiString nazwa);
	struct Sel* ZnajdzSel(DomiString nazwa);
	struct Sel* ZnajdzJoty(int jot);
	int Policz();
	void Usun(DomiString nazwa);
	void Kasuj();
	DomiSel& operator=(const DomiSel& test);//przyrownanie
};