#pragma once
#include "domistring.h"
class DomiAtr {
private:
	struct Atr* atr_start;
public:
	DomiAtr();
	DomiAtr(const DomiAtr& s);
	~DomiAtr();
	void Dodaj(DomiString nazwa, DomiString wartosc);
	struct Atr* ZnajdzAtr(DomiString nazwa);
	int Policz();
	void Usun(DomiString nazwa);
	void Kasuj();
	DomiAtr& operator=(const DomiAtr& test);//przyrownanie
};
