#pragma once
//#include <iostream>
//#define ROZMIAR_TAB 255
#include "domistring.h"
#include "domiatr.h"
#include "domisel.h"

#define		T		17 

typedef struct Atr {
	DomiString nazwa;
	DomiString wartosc;
	struct Atr* nastepny;
}Atr_typ;

typedef struct Sel {
	DomiString nazwa;
	struct Sel* nastepny;
}Sel_typ;

typedef struct Sek {
	int numer;
	DomiSel selektrory;
	DomiAtr atrybuty;
}Sek_typ;
typedef struct SekList {
	int sek_liczba;
	Sek sektab[T];
	struct SekList* nastepny;
	struct SekList* poprzedni;
}SekList_typ;
//typedef struct atrybuty {
//	char nazwa[ROZMIAR_TAB];
//	char wartosc[ROZMIAR_TAB];
//	struct atrybuty* nastepny;
//}Atrybuty_type;

//struct atrybuty* ZnajdzAtrybutNazwa(struct atrybuty* lista, char* nazwa);
//char* ZnajdzWartoscAtrybutPoNazwa(struct atrybuty* lista, char* nazwa);
//struct atrybuty* ZnajdzAtrybutWartosc(struct atrybuty* lista, char* wartosc);
//void WstawAtrybut(struct atrybuty** lista, char* nazwa, char*wartosc);
//void UsunNazwa(struct atrybuty** lista, char* nazwa);
//int PoliczAtrybuty(struct atrybuty* lista);