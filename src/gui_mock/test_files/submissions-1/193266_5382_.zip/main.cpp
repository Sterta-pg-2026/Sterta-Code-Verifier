#define _CRTDBG_MAP_ALLOC
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <iostream>
#include <crtdbg.h>
#include "funkcje.h"
#include "domistring.h"
#include "domiatr.h"
#include "domilist.h"

using namespace std;
DomiList dlist;
bool czytanieKomend, czytanieAtrybutow, czytanieAwartosc;
bool jestLiczba(char* s_chr) {
	int i;
	bool q = true;
	for (i = 0; i < strlen(s_chr); i++)
		if ((s_chr[i] < '0') || (s_chr[i] > '9'))
			q = false;
	return q;
}
void WyczyscSpacje(char* s_chr) {
	int cnt = strlen(s_chr);

	if(cnt >= 1)
		while ((cnt >0)&&((s_chr[cnt-1] == ' ') || (s_chr[cnt - 1] == '\r') || (s_chr[cnt - 1] == '\n') || (s_chr[cnt - 1] == '\t'))) {
			s_chr[cnt-1] = '\0';
			cnt--;
		}
	while ((cnt >0)&&((s_chr[0] == ' ') || (s_chr[0] == '\r') || (s_chr[0] == '\n') || (s_chr[0] == '\t'))) {
		cnt--;
		for (int i = 0; i < cnt; i++)
			s_chr[i] = s_chr[i + 1];
	}
}
void PrzetworzKomende(char* s_chr, int cnt) {
	char buf1[255], buf2[255],buf3[255];
	int m, k1, k2, k3, i, tempi, liczba1, liczba3;
	bool buf1liczba;
	DomiString dstring;

	k1 = 0;
	k2 = 0;
	k3 = 0;
	m = 0;

	for (i = 0; i < cnt; i++)
		if (s_chr[i] == ',') 
			m++;
		else if (m == 0) 
			buf1[k1++] = s_chr[i];
		else if (m == 1)
			buf2[k2++] = s_chr[i];
		else if (m == 2)
			buf3[k3++] = s_chr[i];
	buf1[k1++] = '\0';
	buf2[k2++] = '\0';
	buf3[k3++] = '\0';
	WyczyscSpacje(buf1);
	WyczyscSpacje(buf2);
	WyczyscSpacje(buf3);
	buf1liczba = jestLiczba(buf1);

	if ((buf1[0] == '*') && (buf1[1] == '*') && (buf1[2] == '*') && (buf1[3] == '*')) {
		czytanieKomend = false;//wznow czytanie css
		return;
	}
	else if (buf1[0] == '?') {
		cout << "? == " << dlist.PodajLiczbaSekcji() << endl;//wypisz liczbe sekcji css
	}
	else if ((buf2[0] == 'D') && (buf3[0] == '*')){//i,D,*
		tempi = -1;;//usuñ ca³y blok nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted;
		sscanf(buf1, "%d", &liczba1);
		dlist.UsunSekcje(liczba1, tempi);
//		if (tempi != -1)
			cout << liczba1 << ",D," << buf3 << " == " << "deleted" << endl;
	}
	else if (buf2[0] == 'D'){//i,D,n
		tempi = -1;//suñ z i-tego bloku atrybut o nazwie n, jeli w wyniku operacji pozostaje pusty blok powinien zostaæ równie¿ usuniêty (wraz z ew. selektorami), po poprawnym wykonaniu wypisz deleted.
		sscanf(buf1, "%d", &liczba1);
		dlist.UsunAtrybut(liczba1, buf3, tempi);
//		if (tempi != -1)
			cout << liczba1 << ",D," << buf3 << " == " << "deleted" << endl;
	}
	else if (buf2[0] == 'E') {//z,E,n
		tempi = -1;//wypisz wartoæ atrybutu o nazwie n dla selektora z, w przypadku wielu wyst¹pieñ selektora z bierzemy ostatnie. W przypadku braku pomiñ;
		dstring = dlist.WartoscAtrybutSelektora(buf1, buf3, tempi);
		if (tempi != -1) {
			cout << buf1 << ",E," << buf3 << " == ";
			dstring.Wypisz();
			cout << endl;
		}
	}
	else if (buf1liczba && (buf2[0] == 'S') && (buf3[0] == '?')) {//i,S,?
		tempi = -1;//wypisz liczbê selektorów dla bloku nr i (numery zaczynaj¹ siê od 1), jeli nie ma takiego bloku pomiñ;
		sscanf(buf1, "%d", &liczba1);
		dlist.BlokLiczbaSel(liczba1,tempi);
		if(tempi != -1)
			cout << liczba1 << ",S,? == " << tempi << endl;
	}
	else if (!buf1liczba && (buf2[0] == 'S') && (buf3[0] == '?')) {//z,S,?
		tempi = 0;//wypisz liczbê selektorów dla bloku nr i (numery zaczynaj¹ siê od 1), jeli nie ma takiego bloku pomiñ;
		dlist.LiczbaSelNazwa(buf1, tempi);
		if (tempi != -1)
			cout << buf1 << ",S,? == " << tempi << endl;
	}
	else if (buf1liczba && (buf2[0] == 'S') && (buf3[0] != '?')) {//i,S,j 
		tempi = -1;
		sscanf(buf1, "%d", &liczba1);
		sscanf(buf3, "%d", &liczba3);
		dstring = dlist.BlokSelelektor(liczba1, liczba3, tempi);
		if (tempi != -1) {
			cout << liczba1 << ",S," << liczba3 << " == ";
			dstring.Wypisz();
			cout << endl;//wypisz j-ty selector dla i-tego bloku (numery bloków oraz atrybutów zaczynaj¹ siê od 1) jeli nie ma bloku lub selektora pomiñ;
		}
	}
	else if (buf1liczba && (buf2[0] == 'A') && (buf3[0] == '?')) {//i,A,? 
		tempi = -1;//wypisz liczbê selektorów dla bloku nr i (numery zaczynaj¹ siê od 1), jeli nie ma takiego bloku pomiñ;
		sscanf(buf1, "%d", &liczba1);
		dlist.BlokLiczbaAtr(liczba1, tempi);
		if (tempi != -1)
			cout << liczba1 << ",A,? == " << tempi << endl;
	}
	else if (!buf1liczba && (buf2[0] == 'A') && (buf3[0] == '?')) {//n,A,?
		tempi = 0;//wypisz liczbê selektorów dla bloku nr i (numery zaczynaj¹ siê od 1), jeli nie ma takiego bloku pomiñ;
		dlist.LiczbaAtrNazwa(buf1, tempi);
		if (tempi != -1)
			cout << buf1 << ",A,? == " << tempi << endl;
	}
	else if (buf1liczba && (buf2[0] == 'A') && (buf3[0] != '?')) {//i,A,n  
		tempi = -1;//wypisz j-ty selector dla i-tego bloku (numery bloków oraz atrybutów zaczynaj¹ siê od 1) jeli nie ma bloku lub selektora pomiñ;
		sscanf(buf1, "%d", &liczba1);
		dstring = dlist.BlokAtrybutWartosc(liczba1, buf3, tempi);
		if (tempi != -1) {
			cout << liczba1 << ",A," << buf3 << " == ";
			dstring.Wypisz();
			cout << endl;//wypisz j-ty selector dla i-tego bloku (numery bloków oraz atrybutów zaczynaj¹ siê od 1) jeli nie ma bloku lub selektora pomiñ;
		}
	}
	else {

	}
}
char CSS_buf[255];
char CSS_a_nazwa[255], CSS_a_wartosc[255];
int CSS_i, CSS_k;
DomiAtr CSS_datr;
DomiSel CSS_dsel;
void PrzetworzCSS(char* s_chr, int cnt) {


	for (CSS_i = 0;CSS_i < cnt; CSS_i++)
		if (((s_chr[CSS_i] == ' ')|| (s_chr[CSS_i] == '\t')|| (s_chr[CSS_i] == '\0')|| (s_chr[CSS_i] == '\r')|| (s_chr[CSS_i] == '\n'))&& (CSS_k == 0)) {
			//ignorujemy poczatkowe spacje
		}
		else if ((!czytanieAtrybutow)&&(s_chr[CSS_i] == ',')) {
			if (!czytanieAtrybutow) {
				CSS_buf[CSS_k++] = '\0';
				WyczyscSpacje(CSS_buf);
				CSS_dsel.Dodaj(CSS_buf);//dodaj selektor
				CSS_k = 0;
			}
		}
		else if ((!czytanieAtrybutow)&&(s_chr[CSS_i] == '{')) {
			if (!czytanieAtrybutow) {
				CSS_buf[CSS_k++] = '\0';
				WyczyscSpacje(CSS_buf);
				CSS_dsel.Dodaj(CSS_buf);//dodaj selektor
				CSS_k = 0;
				czytanieAtrybutow = true;//zaczynamy czytanie atrybutów
				czytanieAwartosc = false;
			}
		}
		else if ((czytanieAtrybutow)&&(s_chr[CSS_i] == '}')) {
			if (czytanieAtrybutow) {
				if (CSS_k > 0) {
					CSS_a_wartosc[CSS_k++] = '\0';
					WyczyscSpacje(CSS_a_wartosc);
					CSS_datr.Dodaj(CSS_a_nazwa, CSS_a_wartosc);//dodaj atrybut
				}
				CSS_k = 0;
				czytanieAtrybutow = false;//konczymy czytanie atrybutów
				czytanieAwartosc = false;
				dlist.Dodaj(CSS_datr, CSS_dsel);//dodaj SEKCJE
				CSS_datr.Kasuj();
				CSS_dsel.Kasuj();
			}
		}
		else if ((czytanieAtrybutow)&&(s_chr[CSS_i] == ':')) {
			CSS_a_nazwa[CSS_k++] = '\0';
			WyczyscSpacje(CSS_a_nazwa);
			czytanieAwartosc = true;
			CSS_k = 0;
		}
		else if ((czytanieAtrybutow)&&(s_chr[CSS_i] == ';')) {
			czytanieAwartosc = false;
			CSS_a_wartosc[CSS_k++] = '\0';
			WyczyscSpacje(CSS_a_wartosc);
			CSS_datr.Dodaj(CSS_a_nazwa, CSS_a_wartosc);//dodaj atrybut
			CSS_k = 0;
		}
		else {
			if(!czytanieAtrybutow)
				CSS_buf[CSS_k++] = s_chr[CSS_i];
			else if(!czytanieAwartosc)
				CSS_a_nazwa[CSS_k++] = s_chr[CSS_i];
			else
				CSS_a_wartosc[CSS_k++] = s_chr[CSS_i];
			if ((CSS_k > 3) && (CSS_buf[CSS_k - 1] == '?') && (CSS_buf[CSS_k - 2] == '?') && (CSS_buf[CSS_k - 3] == '?') && (CSS_buf[CSS_k - 4] == '?')) {
				czytanieKomend = true;
				CSS_k = 0;
				return;
			}
		}
}
void PrzetworzLinie(char* s_chr, int cnt) {
	if (czytanieKomend)
		PrzetworzKomende(s_chr, cnt);
	else
		PrzetworzCSS(s_chr, cnt);
}
int main() {

	char buf[255]; // deklaracja tablicy 255 znaków
	czytanieKomend = false;
	czytanieAtrybutow = false;
	CSS_k = 0;
	while (!cin.eof()) {
		cin.getline(buf, sizeof(buf));
		PrzetworzLinie(buf, cin.gcount());
	}
/*

	char buf1[] = "#breadcrumb {	width: 80%;font-family: Verdana;font-size: 9pt;}";
	char buf2[] = "body {min-width: 780px;margin: 20;padding: 0;border: 10;text-align: center;font-family: \"Trebuchet MS\", \"Lucida Grande\", Arial, Helvetica, sans-serif;font-size: 85%;color: #666666;background-color: #B2CFE6;}";
	char buf3[] = "h1, h2, h3, h4, h5, h6 {color: #0066CB;}";
	char buf4[] = "h1 {font-size: 2.0em;font-weight: normal;}";
	char buf5[] = "body, #mainwrapper {margin: 10 auto;width: 80%;min-width: 780px;text-align: left;}";
	char buf6[] = "#header {margin-left: 0px;margin-bottom: 0px;color: #FFFFFF;background-color: #8CA7BB;border:solid 1px #005AC5;font-size: 2.0em;font-weight: normal;padding:10px;border-bottom:solid 4px Black;}";
	char buf61[] = "#header-bottom{width:100%;font-size: 14px;font-style: italic;}";
	char buf62[] = "#content {width: 100%;border:solid 1px #005AC5;background-color:White;border-top:solid 1px Black;}";
	char buf63[] = "#content-left {width:180px;padding-top:10px;}";
	char buf64[] = "#content-right{width:auto;border-left:1px solid #A7A7A7;padding:15px;vertical-align:top;}";
	char buf65[] = "#breadcrumb{width: 100%;font-family: Verdana;font-size: 9pt;}";
	char buf66[] = "#breadcrumb a{color: #0066CB;text-decoration: none;}";
	char buf67[] = "#breadcrumb a:hover{text-decoration: underline;}";
	char buf68[] = "#footer{width:100%;font-size: 0.8em;font-style: italic;text-align: left;}";
	char buf69[] = "h1.menu_nodeStyle{color:Black;font-family:\"Verdana\";font-size:8pt;padding: 5px 5px 5px 5px;width:100%;border:solid 1px White;}";
	char buf7[] = "	h1 div, .menu_hoverNodestyle{background-color:#CCCCCC;border:solid 1px #888888;cursor:pointer;}";
	char buf8[] = "	.menu_selectedNodestyle{padding: 5px 5px 5px 5px;font-weight:bold;color:#0066CB;}";
	char buf9[] = "h1.menu_nodeStyle{color:Black;font-family:\"Verdana\";font-size:8pt;padding: 5px 5px 5px 5px;width:100%;border:solid 1px White;}";
	char buf10[] = "????";
	char buf11[] = "?";
	char buf12[] = "1,S,?";
	char buf13[] = "1,A,?";
	char buf14[] = "2,S,?";
	char buf15[] = "2,A,?";
	char buf16[] = "3,S,?";
	char buf17[] = "3,A,?";
	char buf18[] = "1,S,1";
	char buf19[] = "1,S,2";
	char buf20[] = "1,A,padding";
	char buf21[] = "1,A,width";
	char buf22[] = "1,A,font-family";
	char buf23[] = "1,A,font-size";
	char buf24[] = "2,S,1";
	char buf25[] = "2,S,2";
	char buf26[] = "3,S,1";
	char buf27[] = "3,S,2";
	char buf28[] = "font-size,A,?";
	char buf29[] = "color,A,?";
	char buf30[] = "font-weight,A,?";
	char buf31[] = "font,A,?";
	char buf32[] = "2,A,margin";
	char buf33[] = "body,E,margin";
	char buf34[] = "margin,A,?";
	char buf35[] = "margin-left,A,?";
	char buf36[] = "h1,S,?";
	char buf37[] = "#breadcrumb,E,width";
	char buf38[] = "#bes,A,?";
	char buf39[] = "#bes,S,?";
	char buf40[] = "#bes,E,width";
	char buf41[] = "#breadcrumb,E,test";
	char buf42[] = " ";
	char buf43[] = " ";
	char buf44[] = " ";
	char buf45[] = " ";
	char buf46[] = " ";

	PrzetworzLinie(buf1, sizeof(buf1));
	PrzetworzLinie(buf2, sizeof(buf2));
	PrzetworzLinie(buf3, sizeof(buf3));
	PrzetworzLinie(buf4, sizeof(buf4));
	PrzetworzLinie(buf5, sizeof(buf5));
	PrzetworzLinie(buf6, sizeof(buf6));
	PrzetworzLinie(buf61, sizeof(buf61));
	PrzetworzLinie(buf62, sizeof(buf62));
	PrzetworzLinie(buf63, sizeof(buf63));
	PrzetworzLinie(buf64, sizeof(buf64));
	PrzetworzLinie(buf65, sizeof(buf65));
	PrzetworzLinie(buf66, sizeof(buf66));
	PrzetworzLinie(buf67, sizeof(buf67));
	PrzetworzLinie(buf68, sizeof(buf68));
	PrzetworzLinie(buf69, sizeof(buf69));
	PrzetworzLinie(buf7, sizeof(buf7));
	PrzetworzLinie(buf8, sizeof(buf8));
	PrzetworzLinie(buf9, sizeof(buf9));
	PrzetworzLinie(buf10, sizeof(buf10));
	PrzetworzLinie(buf11, sizeof(buf11));
	PrzetworzLinie(buf12, sizeof(buf12));
	PrzetworzLinie(buf13, sizeof(buf13));
	PrzetworzLinie(buf14, sizeof(buf14));
	PrzetworzLinie(buf15, sizeof(buf15));
	PrzetworzLinie(buf16, sizeof(buf16));
	PrzetworzLinie(buf17, sizeof(buf17));
	PrzetworzLinie(buf18, sizeof(buf18));
	PrzetworzLinie(buf19, sizeof(buf19));
	PrzetworzLinie(buf20, sizeof(buf20));
	PrzetworzLinie(buf21, sizeof(buf21));
	PrzetworzLinie(buf22, sizeof(buf22));
	PrzetworzLinie(buf23, sizeof(buf23));
	PrzetworzLinie(buf24, sizeof(buf24));
	PrzetworzLinie(buf25, sizeof(buf25));
	PrzetworzLinie(buf26, sizeof(buf26));
	PrzetworzLinie(buf27, sizeof(buf27));
	PrzetworzLinie(buf28, sizeof(buf28));
	PrzetworzLinie(buf29, sizeof(buf29));
	PrzetworzLinie(buf30, sizeof(buf30));
	PrzetworzLinie(buf31, sizeof(buf31));
	PrzetworzLinie(buf32, sizeof(buf32));
	PrzetworzLinie(buf33, sizeof(buf33));
	PrzetworzLinie(buf34, sizeof(buf34));
	PrzetworzLinie(buf35, sizeof(buf35));
	PrzetworzLinie(buf36, sizeof(buf36));
	PrzetworzLinie(buf37, sizeof(buf37));
	PrzetworzLinie(buf38, sizeof(buf38));
	PrzetworzLinie(buf39, sizeof(buf39));
	PrzetworzLinie(buf40, sizeof(buf40));
	PrzetworzLinie(buf41, sizeof(buf41));
	PrzetworzLinie(buf42, sizeof(buf42));
	PrzetworzLinie(buf43, sizeof(buf43));
	PrzetworzLinie(buf44, sizeof(buf44));
	PrzetworzLinie(buf45, sizeof(buf45));
	PrzetworzLinie(buf46, sizeof(buf46));
*/

//	cin.get();

//	char test1[] = "test1111111111";
//	DomiString text1("test1111111111");
//	DomiString text2;
//	text1.Wypisz();
//	printf("Dlkugos %d",text1.Dlugosc());
//	text2.Wypisz();
//	printf("Dlkugos %d", text2.Dlugosc());
//	text2 = text1;
//	text2.Wypisz();
//	printf("Dlkugos %d", text2.Dlugosc());
//	if (text1 == text2)
//		printf(" Identyczne ");

//	text1.~DomiString();
/*
	
	DomiAtr q;
	cout << q.Policz();
	q.Dodaj("qqq", "wwww");
	cout << q.Policz();
	q.Dodaj("n2", "wwww222");
	cout << q.Policz();
	q.Dodaj("n3", "wwww3");
	cout << q.Policz();

	q.ZnajdzAtr("qqq")->wartosc.Wypisz();
	q.Usun("n3");
	cout << q.Policz();
//	q.Usun("qqq");
	cout << q.Policz();
	q.Kasuj();
	_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG);
	_CrtDumpMemoryLeaks();
*/
	return 0;
}

