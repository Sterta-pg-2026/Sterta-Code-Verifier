#define _CRT_SECURE_NO_WARNINGS

#include <string.h>
#include <iostream>
#include "domistring.h"

using namespace std;

DomiString::DomiString() {
	this->domi_wsk = new char[1];
	this->domi_wsk[0] = '\0';
}

DomiString :: DomiString(const char* s_chr) {
	this->domi_wsk = new char[strlen(s_chr) + 1];//+ 1 bo mamy na ostatnim miejscu zero
	strcpy(this->domi_wsk, s_chr);
}

DomiString::DomiString(const DomiString& s) {
	this->domi_wsk = new char[strlen(s.domi_wsk) + 1];//+ 1 bo mamy na ostatnim miejscu zero
	strcpy(this->domi_wsk, s.domi_wsk);
}

void DomiString::Wypisz() {
	if ((this != NULL) && (this->domi_wsk != NULL))
		cout << domi_wsk;
}
int DomiString::Dlugosc() {
	if ((this != NULL) && (this->domi_wsk != NULL))
		return strlen(this->domi_wsk);
	else
		return 0;
}

DomiString :: ~DomiString() {
//		if (this->domi_wsk != NULL)
	delete[] (this->domi_wsk);
//		this->domi_wsk = NULL;
}
DomiString& DomiString::operator=(const DomiString& s) {
	if (this != &s) {
		delete[] (this->domi_wsk);
		this->domi_wsk = new char[strlen(s.domi_wsk) + 1];
		strcpy(this->domi_wsk, s.domi_wsk);
//		this->domi_wsk = s.domi_wsk;
	}
	return *this;
}
bool DomiString::operator==(const DomiString& s) {
	if ((this->domi_wsk != NULL) && (s.domi_wsk != NULL))
		return  (strcmp(this->domi_wsk, s.domi_wsk) == 0);
	else
		return false;
}
bool DomiString::operator!=(const DomiString& s) {
	if ((this->domi_wsk != NULL) && (s.domi_wsk != NULL))
		return  (strcmp(this->domi_wsk, s.domi_wsk) != 0);
	else
		return true;
}



