#include <iostream>
#include "lists.h"
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int main() {
	int currentSection = 0, sectionCounter = 0, j, last, commas = 0;
	DoubleList* doubleList = new DoubleList;
	DoubleList* doubleHead = doubleList;
	for (int i = 0; i < T; i++)	doubleList->sections[i].isActive = false;
	doubleList->sections[currentSection].selectors = NULL;
	doubleList->sections[currentSection].attributes = NULL;
	bool isCode = true, isSelector = true, isInput = true, newSection = false, sectionCreation = false, commandDone = false;
	char* buffer = (char*)malloc(BUFFER * sizeof(char));
	char* tmp = new char[BUFFER];
	int i, tmpPosition;
	while (isInput) {
		for (int i = 0; i < BUFFER; i++) buffer[i] = '\0';

		if (gets_s(buffer, BUFFER) == NULL) return 0;
		i = 0;		

		for (int j = 0; j < BUFFER; j++) {
			if (buffer[j] == 10 || buffer[j] == 13) continue;
			if (buffer[j] == 9) buffer[j] = 32;
			if (buffer[j] < 26 || buffer[j] > 126 )	buffer[j] = '\0';
		}

		if (sectionCreation && currentSection < T ) {
			doubleList->sections[currentSection].attributes = NULL;
			doubleList->sections[currentSection].selectors = NULL;
			sectionCreation = false;
		}
		if (sectionCreation && currentSection == T ) {
			currentSection = 0;
			Sections* section = new Sections[T];
			push_back_double(&doubleList, section);
			doubleList = doubleList->next;
			sectionCreation = false;
			doubleList->sectionsUsed = 0;
			for (int k = 0; k < T; k++) {
				doubleList->sections[k].selectorCounter = 0;
				doubleList->sections[k].isActive = false;
				doubleList->sections[k].attributes = NULL;
				doubleList->sections[k].selectors = NULL;
			}
		}
		if (isCode) {

			if (isSelector) {
				if (buffer[i] == '?' && buffer[i + 1] == '?' && buffer[i + 2] == '?' && buffer[i + 3] == '?') {
					isCode = false;
					last = currentSection;
					continue;
				}
				
				for (int h = 0; h < BUFFER; h++) {
					if (buffer[h] == ',')
						commas++;
				}
				for (int h = 0; h < BUFFER; h++) {
					if (buffer[h] > 32 && buffer[h] < 123) {
						doubleList->sections[currentSection].selectorCounter++;
						break;
					}
				}
				
				while (i < BUFFER && buffer[i] != '{' && buffer[i] != '?') {
					i++;
				}
				if (buffer[i] == '{') {
					isSelector = false;
					doubleList->sections[currentSection].isActive = true;
					tmpPosition = 0;
					int pos = i;
					while (pos < BUFFER && (buffer[pos - 1] != '}')) {
						if (buffer[pos] == ':') doubleList->sections[currentSection].attributeCounter++;
						if (buffer[pos] == '}') {
							sectionCounter++;
							doubleList->sectionsUsed++;
							isSelector = true;
							sectionCreation = true;
						}
						tmp[tmpPosition] = buffer[pos];
						tmpPosition++;
						pos++;
						buffer[i] = '\0';
					}
					newSection = true;
				}
				if (commas > 0)doubleList->sections[currentSection].selectorCounter = commas + 1;
				if (buffer[i] == '=') {
					if (buffer[i + 1] == '=')	isInput = false;
				}
				push_back(&doubleList->sections[currentSection].selectors, buffer);
			}	
			if (newSection) {
				commas = 0;
				push_back(&doubleList->sections[currentSection].attributes, tmp);
				j = 0;
				while (tmp[j] != '\0') {
					tmp[j] = '\0';
					j++;
				}
				newSection = false;
				if (sectionCreation && isSelector) currentSection++;
				continue;
			}
			if (!isSelector) {
				commas = 0;
				bool pushed = false;
				for (int z=0; z<BUFFER; z++){	
					if (buffer[z] == ':')	doubleList->sections[currentSection].attributeCounter++;
					if (buffer[z] == ';') {
						z++;
						for (z; z < BUFFER; z++) buffer[z] = '\0';
						break;
					}
					if (buffer[z] == '}') {
						push_back(&doubleList->sections[currentSection].attributes, buffer);
						isSelector = true;
						sectionCreation = true;
						doubleList->sectionsUsed++;
						currentSection++;
						sectionCounter++;
						pushed = true;
						break;
					}
					if (buffer[z] == '?') {
						if (buffer[z + 1] == '?' && buffer[z + 2] == '?' && buffer[z + 3] == '?') {
							last = currentSection;
							isCode = false;
							continue;
						}
					}
				}
				if (buffer[i] == '=') {
					if (buffer[i + 1] == '=')	return 0;
				}
				int ac = 0;
				while (ac < BUFFER && buffer[ac] != ':') ac++;
				if (buffer[ac] == ':') {
					char* attributeComparison = new char[BUFFER];
					for (int g = 0; g < ac; g++) {
						attributeComparison[g] = buffer[g];
					}
					bool isDeleted = false;
					SingleList* current = doubleList->sections[currentSection].attributes;
					SingleList* previous = doubleList->sections[currentSection].attributes;
					int match = 0;
					while (current != NULL) {
						for (int d = 0; d < BUFFER; d++) {
							match = 0;
							if (current->arr[d] == attributeComparison[0]) {
								for (int j = 0; j < ac; j++) {
									if (current->arr[d + j] != attributeComparison[j]) {
										break;
									}
									match++;
								}
								if (match == ac) {
									if (current->next != NULL) {
										doubleList->sections[currentSection].attributeCounter--;
										deleteSingle(&previous, &current);
										isDeleted = true;
									}
									if (current->next == NULL) {
										for (int y = 0; y < BUFFER; y++)
										current->arr[y] = buffer[y];
										doubleList->sections[currentSection].attributeCounter--;
										isDeleted = true;
										pushed = true;
									}
								}
							}
						}
						if (isDeleted) 
							break;
						previous = current;
						current = current->next;
					}
				}

			    if (!pushed) push_back(&doubleList->sections[currentSection].attributes, buffer);
				continue;
			}
		}
		if (!isCode) {
			if (buffer[i] == '*') {
				if (buffer[i + 1] == '*' && buffer[i + 2] == '*' && buffer[i + 3] == '*')	isCode = true;
			}
			if (buffer[i] == '=') {
				if (buffer[i + 1] == '=')	return 0;
			}

			commandDone = false;
			while (i < BUFFER && buffer[i] != ',' && buffer[i] != '?' && buffer[i] != '*'&& buffer[i] != '=')	i++;
			if (buffer[i] == '?' && (i < 2 || buffer[i - 1] != ',')) {
				cout << "? == " << sectionCounter << endl;
				i++;
				continue;
			}
			if (buffer[i] == ',' && !commandDone) {
				char* l = new char[COMMANDBUFF];
				char* command = new char[MIDDLEBUFF];
				char* r = new char[COMMANDBUFF];
				int k = 0;
				int leftL = 0, rightL = 0;
				
				while (buffer[k] != ',') {
					l[leftL] = buffer[k];
					k++;
					leftL++;
				}
				for (int b = 0; b < MIDDLEBUFF; b++) {
					command[b] = buffer[k];
					k++;
				}
				while (buffer[k] > 26 && buffer[k] < 126) {
					r[rightL] = buffer[k];
					k++;
					rightL++;
				}

				commandDone = true;
				if (command[1] == 'S') {
					if (r[0] == '?' && isdigit(l[0])) {
						int n = atoi(l);
						if (n > sectionCounter) continue;
						Sections* section = movingToSection(&doubleHead, n);
						int k = 0;
						while (buffer[k] > 26 && buffer[k] < 126) {
							cout << buffer[k];
							k++;
						}

						cout << " == " << section->selectorCounter << endl;
						continue;
					}
					if (r[0] == '?' && !isdigit(l[0])) {
						
						int selectorApperances = 0;
						DoubleList* doubleCheck = doubleHead;

						while (doubleCheck != NULL) {
							for (int z = 0; z < T; z++) {
								if (doubleCheck->sections[z].selectors == NULL) break;
								if (!doubleCheck->sections[z].isActive) continue;
								selectorApperances += searchingForEquals(&doubleCheck->sections[z].selectors, buffer, l, leftL, false, false);
							}
							doubleCheck = doubleCheck->next;
						}

						int z = 0;
						while (buffer[z] > 26 && buffer[z] < 126) {
							cout << buffer[z];
							z++;
						}
						cout << " == " << selectorApperances << endl;
						continue;
					}
					if (isdigit(r[0]) && isdigit(l[0])) {
						int x = atoi(l);
						int n = atoi(r);
						if (x > sectionCounter) continue;
						Sections* section = movingToSection(&doubleHead, x);
						if (n > section->selectorCounter) continue;
						if (!section->isActive) continue;
						SingleList* list = section->selectors;
						
						int selectorNr = 1;
						int z = 0, a, c = 0;
						int done = 1, text = 0;
						if (list == NULL) done = 0;
						while (text == 0 ) {
							c = 0;
							for (c; c < BUFFER; c++) {
								if (list->arr[c] > 32 && list->arr[c] < 123) text = 1;
								break;
							}
							if (text == 0 ) list = list->next;
							if (list == NULL) done = 0;
						}
						while (done == 1){
							for (a = z; a < BUFFER; a++) {
								if (n == selectorNr) {
									z = a;
									done = 2;
									int p = 0;
									while (buffer[p] != '\0') {
										cout << buffer[p];
										p++;
									}
									cout << " == ";
									while (list->arr[z] <33 || list->arr[z] >122) z++;
									while (list->arr[z] >31 && list->arr[z] <123 && list->arr[z]!=',') {
										cout << list->arr[z];
										z++;
									}
									cout << endl;
									break;
								}
								if (list->arr[a] == ',') selectorNr++;
							}
							if (list->next != NULL) list = list->next;
							if (list->next == NULL) done = 0;
						}
						continue;
					}
				}

				if (command[1] == 'A') {
					if (r[0] == '?' && isdigit(l[0])) {
						int n = atoi(l);
						if (n > sectionCounter) continue;
						Sections* section = movingToSection(&doubleHead, n);
						int k = 0;
						while (buffer[k] > 23 && buffer[k] < 123) {
							cout << buffer[k];
							k++;
						}
						cout << " == " << section->attributeCounter << endl;

						continue;
					}
					if (isdigit(l[0])) {
						int n = atoi(l);
						Sections* section = movingToSection(&doubleHead, n);
						if (n > sectionCounter) continue;
						SingleList* list = section->attributes;
						searchingForEquals(&list, buffer, r, rightL, true, false);
						continue;
					}
					if (r[0] == '?' && !isdigit(l[0])) {
						int attributeAppearance = 0;
						DoubleList* doubleCheck = doubleHead;

						while (doubleCheck != NULL) {
							for (int z = 0; z < T; z++) {
								if (doubleCheck->sections[z].selectors == NULL) break;
								if (!doubleCheck->sections[z].isActive) continue;
								attributeAppearance += searchingForEquals(&doubleCheck->sections[z].attributes, buffer, l, leftL, false, false);
							}
							doubleCheck = doubleCheck->next;
						}

						int z = 0;
						while (buffer[z] > 26 && buffer[z] < 126) {
							cout << buffer[z];
							z++;
						}
						cout << " == " << attributeAppearance << endl;
						continue;
					}
				}
				if (command[1] == 'D') {
					if (r[0] == '*') {
						int value = atoi(l);
						if (value > sectionCounter) continue;
						movingToSection(&doubleHead, value)->isActive = false;
						movingToDoubleNode(&doubleHead, value)->sectionsUsed--;
						int k = 0;
						while (buffer[k] > 26 && buffer[k] < 126) {
							cout << buffer[k];
							k++;
						}
						sectionCounter--;
						cout << " == deleted" << endl;
						continue;
					}
					if (isdigit(l[0])) {
						int value = atoi(l);
						if (value > sectionCounter) continue;
						Sections* section = movingToSection(&doubleHead, value);
						DoubleList* rootOfSection = movingToRootOfSection(&doubleHead, value);
						int deleted = searchingForEquals(&section->attributes, buffer, r, rightL, false, true);
						section->attributeCounter -= deleted;
						int amm = section->attributeCounter;
						if (amm <= 0) {
							sectionCounter--;
							section->isActive = false;
							rootOfSection->sectionsUsed--;
						}
						int z = 0;

						if (deleted > 0) {
							while (buffer[z] > 26 && buffer[z] < 126) {
								cout << buffer[z];
								z++;
							}
							cout << " == deleted" << endl;
						}
						continue;
					}
				}
				if (command[1] == 'E') {
					DoubleList* current = doubleHead;
					bool done = false;
					while (current->next != NULL) current = current->next;
					while (!done) {
							if (last < 0) {
								last = T - 1;
								if (current->previous == NULL) done = true;
								if (current->previous != NULL) current = current->previous;
							continue;
						}
						if (attributeAndSelector(&current->sections[last].attributes, &current->sections[last].selectors, buffer, r, l, rightL, leftL)) {
							done = true;
						}
						last--;
					}
					continue;
				}
			}
		}
	}
	return 0;
}
