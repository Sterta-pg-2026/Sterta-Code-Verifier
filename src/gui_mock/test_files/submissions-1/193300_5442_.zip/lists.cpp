#include <iostream>
#include "lists.h"
using namespace std;

DoubleList* movingToRootOfSection(DoubleList** head, int n) {
    int currentSection = 0;
    DoubleList* current = *head;
    while (n > currentSection) {
        currentSection += current->sectionsUsed;
        if (currentSection >= n) {
            currentSection -= current->sectionsUsed;
            break;
        }
        current = current->next;
    }
    return current;
}

Sections* movingToSection(DoubleList** head, int n){

    int currentSection = 0;
    DoubleList* current = *head;

    while (n > currentSection) {
        currentSection += current->sectionsUsed;
        if (currentSection >= n) {
            currentSection -= current->sectionsUsed;
            break;
        }
        current = current->next;
    }
    int i = 0;

    while (n > currentSection) {
        if (current->sections[i].isActive) currentSection++;
        if (currentSection == n) {
            if (i == T) return &current->sections[T - 1];
            else return &current->sections[i];
        }
        i++;
    }
    return NULL;
}

DoubleList* movingToDoubleNode(DoubleList** head, int n) {
    int currentNode = 0;
    DoubleList* current = *head;
    while (current != NULL && n > currentNode) {
        currentNode += current->sectionsUsed;
        if (n > currentNode)   current = current->next;
        else break;
    }
    return current;
}

int attributeAndSelector(SingleList**headAttribute, SingleList**headSelector, char buffer[], char attribute[], char selector[], int lengthA, int lengthS) {
    SingleList* currentA = *headAttribute;
    SingleList* currentS = *headSelector;
    int matchS = 0, matchA =0;
    while (currentS != NULL) {
        for (int i = 0; i < BUFFER; i++) {
            if (currentS->arr[i] == selector[0]) {
                matchS = 0;
                for (int j = 1; j < lengthS; j++) {
                    if (currentS->arr[i + j] != selector[j]) {
                        i++;
                        break;
                    }
                    matchS++;
                }
                if (matchS == lengthS - 1) {
                    while (currentA != NULL) {
                        for (int k = 0; k < BUFFER; k++) {
                            if (currentA->arr[k] == attribute[0]) {
                                matchA = 0;
                                for (int j = 1; j < lengthA; j++) {
                                    if (currentA->arr[k + j] != attribute[j]) {
                                        
                                        k++;
                                        break;
                                    }
                                    matchA++;
                                }
                                    if (matchA == lengthA - 1) {
                                        int start = k;
                                        while (currentA->arr[k] != ':') k++;
                                        int z = 0;
                                        while (buffer[z] != '\0') {
                                            cout << buffer[z];
                                            z++;
                                        }
                                        cout << " == ";
                                        while (currentA->arr[k] != ':') k++;
                                        k++;
                                        while (currentA->arr[k] < 34) k++;
                                        while (currentA->arr[k] != ';' && currentA->arr[k] != '}') {
                                            cout << currentA->arr[k];
                                            k++;
                                        }
                                        cout << endl;
                                        return 1;
                                    }
                                
                            }
                            continue;
                        }
                        currentA = currentA->next;
                    }
                }
            }
        }
        if (currentS->next == NULL) return 0;
        currentS = currentS->next;
    }
    return 0;
}

int searchingForEquals(SingleList** head, char buffer[], char arr[], int arrLength, bool print, bool toDelete) {
    SingleList* current = *head;
    int occurences = 0;
    int lettersMatched = 0;
    int deleted = 0;

    while (current != NULL) {
        for (int i = 0; i < BUFFER; i++) {
            if (current->arr[i] == arr[0]) {
                lettersMatched = 0;
                for (int j = 0; j < arrLength; j++) {
                    if (current->arr[i + j] != arr[j]) {
                        break;
                    }
                    lettersMatched++;
                }
                if (current->arr[i+arrLength] != ' ' && current->arr[i + arrLength] != ';' && current->arr[i + arrLength] != ':' && current->arr[i + arrLength] != '\n' && current->arr[i + arrLength] != ',') {
                   lettersMatched = 0;       
                }
                if (current->arr[i - 1] > 32 && current->arr[i - 1] < 126 && current->arr[i-1] != '{') {
                    lettersMatched = 0;
                }
                if (current->arr[i + arrLength] == ' ') {
                    if (current->arr[i + arrLength + 1] > 45 && current->arr[i + 1 + arrLength] < 123)
                        lettersMatched = 0;
                }
                if (lettersMatched == 0) continue;
                if (lettersMatched == arrLength)
                {
                    occurences++;
                }
                if (toDelete && lettersMatched == arrLength ) {
                    while (current->arr[i] != ';' && current->arr[i] != '}') {
                        if (current->arr[i] == ':') deleted++;
                        current->arr[i] = '\0';
                        i++;
                    }
                    if (current->arr[i] == ';')  current->arr[i] = '\0';
                }
                if (print && lettersMatched == arrLength ) {
                    while (current->arr[i] != ':') i++;
                    int start = i + 1;
                    while (current->arr[i] > 26 && current->arr[i] < 126) {
                        i++;
                    }
                    int z = 0;
                    while (buffer[z] > 26 && buffer[z] < 126) {
                        cout << buffer[z];
                        z++;
                    }
                    cout << " ==";
                    while (current->arr[start] != ';') {
                        cout << current->arr[start];
                        start++;
                    }
                    cout << endl;
                    
                    return 1;
                }
            }
        }
        current = current->next;
    }
    if (toDelete) return deleted;
    else return occurences;
}

void printSingle(SingleList** head) {
    if (head == NULL)   cout << "list is empty";
    else {
        SingleList *current = *head;
        for (int i = 0; i < BUFFER; i++) {
            cout << current->arr[i];
        }
    }
}

//single list

void deleteSingle(SingleList** tail, SingleList** head) {
    SingleList *previous = *tail;
    SingleList *current = *head;
    if(current->next!=NULL)     previous->next = current->next;
    delete current;
}

void push_front(SingleList** head, char new_arr[BUFFER]) {
    SingleList* current;
    current = (SingleList*)malloc(sizeof(SingleList));

    for (int i = 0; i < BUFFER; i++) {
        (*head)->arr[i] = new_arr[i];
    }
    current->next = (*head);
    *head = current;
}

void push_back(SingleList** head, char new_arr[BUFFER]) /*dodawanie na koncu*/ {
    if (*head == NULL) {
        *head = new SingleList;
        for (int i = 0; i < BUFFER; i++) {
            (*head)->arr[i] = new_arr[i];
        }
        (*head)->next = NULL;
    }
    else {
        SingleList* current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new SingleList;
        // clean-up char buffers.
        for (int i = 0; i < BUFFER; i++) current->next->arr[i] = '\0';
        int  i = 0;
        while (i < BUFFER && new_arr[i] != '\0') {
            current->next->arr[i] = new_arr[i];
            if (new_arr[i] == ';') break;
            i++;
        }

        current->next->next = NULL;
    }
}

void push_by_back(SingleList** head, char new_arr[BUFFER], int position) {
    if (position == 0) push_front(head, new_arr);
    else {
        if (position == list_size(*head)) push_back(head, new_arr);
        else {
            SingleList* current = *head;
            SingleList* tmp;

            int i = 0;
            for (int i = 0; i < position; i++) {
                current = current->next;
                if (current->next == NULL) {
                    break;
                }
            }

            tmp = current->next;
            current->next = (SingleList*)malloc(sizeof(SingleList));
            for (int i = 0; i < BUFFER; i++) {
                (*head)->arr[i] = new_arr[i];
            }
            current->next->next = tmp;
        }
    }
}

void pop_front(SingleList** head) {
    SingleList* tmp = NULL;

    if (*head != NULL) {
        tmp = (*head)->next;
        free(*head);
        *head = tmp;
    }
}

void pop_back(SingleList** head) {
    if ((*head)->next == NULL) {
        *head = NULL;
    }
    else {
        SingleList* current = *head;
        while (current->next->next != NULL) {
            current = current->next;
        }
        free(current->next);
        current->next = NULL;
    }
}

void pop_by_index(SingleList** head, int position) {
    if (position == 0) pop_front(head);
    else
    {
        SingleList* current = *head;
        SingleList* tmp;
        int i = 0;
        for (int i = 0; i < position; i++) {
            current = current->next;
            if (current->next == NULL) {
                break;
            }
        }
        tmp = (SingleList*)malloc(sizeof(SingleList));
        tmp->next = current->next;
        current->next = tmp;
        free(tmp);
    }

}

int list_size(SingleList* head) {
    int counter = 0;
    if (head == NULL) return counter;
    else
    {
        SingleList* current = head;
        do {
            counter++;
            current = current->next;
        } while (current != NULL);
    }
    return counter;
}

//double list

void push_front(DoubleList** head, struct Sections new_sections[T]) {
    if (*head == NULL) {
        *head = (DoubleList*)malloc(sizeof(DoubleList));
        for (int i = 0; i < T; i++) {
            (*head)->sections[i] = new_sections[i];
        }
        (*head)->previous = NULL;
        (*head)->next = NULL;
    }
    else {
        DoubleList* current;
        current = (DoubleList*)malloc(sizeof(DoubleList));
        for (int i = 0; i < T; i++) {
            (*head)->sections[i] = new_sections[i];
        }
        current->previous = NULL;
        current->next = (*head);
        (*head)->previous = current;
        *head = current;//
    }
}

void push_back_double(DoubleList** head, struct Sections new_sections[T]) {
    if (*head == NULL) {
        *head = (DoubleList*)malloc(sizeof(DoubleList));
        for (int i = 0; i < T; i++) {
            (*head)->sections[i] = new_sections[i];
        }
        (*head)->previous = NULL;
        (*head)->next = NULL;
    }
    else {
        DoubleList* current = *head;
        DoubleList* new_element;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = (DoubleList*)malloc(sizeof(DoubleList));
        for (int i = 0; i < T; i++) {
            current->next->sections[i] = new_sections[i];
        }
        current->next->previous = current;
        current->next->next = NULL;
    }
}

void push_by_index(DoubleList** head, struct Sections new_sections[T], int position) {
    if (position == 0) push_front(head, new_sections);
    else {
        if (position == list_size(*head)) push_back_double(head, new_sections);
        else {
            DoubleList* current = *head;
            DoubleList* tmp;

            int i = 0;
            while (current->next != NULL && i < position - 1) {
                current = current->next;
                i++;
            }

            tmp = current->next;
            current->next = (DoubleList*)malloc(sizeof(DoubleList));
            for (int i = 0; i < T; i++) {
                current->next->sections[i] = new_sections[i];
            }
            current->next = tmp;
            tmp->next = current->next;
            current->next->previous = tmp;
            tmp->previous = current;
        }
    }
}

void pop_front(DoubleList** head) {
    if (*head != NULL) {
        if ((*head)->next == NULL) {
            *head = NULL;
        }
        else {
            DoubleList* tmp;
            tmp = (*head)->next;
            free(*head);
            *head = tmp;
            (*head)->previous = NULL;
        }
    }
}

void pop_back(DoubleList** head) {
    if ((*head)->next == NULL) {
        *head = NULL;
    }
    else {
        DoubleList* current = *head;
        while (current->next->next != NULL) {
            current = current->next;
        }
        free(current->next);
        current->next = NULL;
    }
}

void pop_by_index(DoubleList** head, int position) {
    if (position == 0) pop_front(head);
    else {
        DoubleList* current = *head;
        DoubleList* tmp;
        int i = 0;
        while (current->next != NULL && i < position - 1) {
            current = current->next;
            i++;
        }
        tmp = current->next;
        current->next = tmp->next;
        current->next->previous = current;
        free(tmp);
    }
} 

int list_size(DoubleList* head) {
    int counter = 0;
    if (head == NULL) return counter;
    else {
        DoubleList* current = head;
        do {
            counter++;
            current = current->next;
        } while (current != NULL);
    }
    return counter;
}

/*
void debug(char* info) {
    if (ENABLED) {
        cout << info << endl;
    }
};
*/