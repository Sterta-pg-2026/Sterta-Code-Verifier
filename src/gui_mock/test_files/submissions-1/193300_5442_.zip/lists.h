#pragma once
#define BUFFER 150
#define T 8
#define MIDDLEBUFF 3
#define COMMANDBUFF 20
//#define DEBUG 1

typedef struct SingleNode {
    char arr[BUFFER];
    struct SingleNode* next;
} SingleList;

struct Sections {
    bool isActive = false;
    int attributeCounter = 0;
    int selectorCounter = 0;
    struct SingleNode* attributes;
    struct SingleNode* selectors;
};

typedef struct Node {
    int sectionsUsed = 0;
    struct Sections sections[T];
    struct Node* previous = NULL;
    struct Node* next = NULL;
} DoubleList;

void push_front(DoubleList** head, struct Sections sections[T]);
void push_back_double(DoubleList** head, struct Sections sections[T]);
void push_by_index(DoubleList** head, struct Sections sections[T], int position);
void pop_front(DoubleList** head);
void pop_back(DoubleList** head);
void pop_by_index(DoubleList** head, int position);
int list_size(DoubleList* head);


void push_front(SingleList** head, char new_arr[BUFFER]);
void push_back(SingleList** head, char new_arr[BUFFER]);
void push_by_back(SingleList** head, char new_arr[BUFFER], int position);
void pop_front(SingleList** head);
void pop_back(SingleList** head);
void pop_by_index(SingleList** head, int position);
int list_size(SingleList* head);

Sections* movingToSection(DoubleList** head, int n);
DoubleList* movingToDoubleNode(DoubleList** head, int n);
int searchingForEquals(SingleList** head, char buffer[], char arr[], int arrLength, bool print, bool toDelete);
int attributeAndSelector(SingleList** headAttribute, SingleList** headSelector, char buffer[], char attribute[], char selector[], int lengthA, int lengthS);
void deleteSingle(SingleList** tail, SingleList** head);
DoubleList* movingToRootOfSection(DoubleList** head, int n);