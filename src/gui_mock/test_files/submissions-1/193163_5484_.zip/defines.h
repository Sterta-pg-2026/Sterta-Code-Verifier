﻿#pragma once

#define STRING_LENGTH_BUFFER 1000
#define MY_STRING_LENGTH_BUFFER 16
#define BLOCK_SIZE_BUFFER 8

// types of data saving on list
#define SAVE_PROP 1
#define SAVE_VAL 2
#define SAVE_SEL 3

// current read mode
#define READ_SELECTORS 1
#define READ_PROPERTIES 2
#define READ_COMMANDS 3

// returning count of selectors or properties
#define RETURN_COUNT_OF_SELECTORS 1
#define RETURN_COUNT_OF_PROPERTIES 2

#define PRINT_PROP_VALUE 1
#define PRINT_SEL_NR 2

// no selectors
#define NO_SECECTOR_SPECIFIED "NO_SECECTOR_SPECIFIED"
