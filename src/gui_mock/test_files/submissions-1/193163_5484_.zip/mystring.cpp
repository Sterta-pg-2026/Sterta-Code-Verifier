#include "mystring.h"
#include "string.h"
#include "stdio.h"
#include <iostream>


int CharArrayLength(const char* charArray) {
    int i = 0;
    while (charArray[i] != '\0')
    {
        i++;
    }
    return i;
}

MyString::MyString() {
    length = 1;
    charArray = new char[MY_STRING_LENGTH_BUFFER];
    charArray[0] = '\0';
}

MyString::MyString(const char stringText[]) {
    length = CharArrayLength(stringText)+1;
    buffer = (length / MY_STRING_LENGTH_BUFFER)*MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
    charArray = new char[buffer];

    int i = 0;
    while (stringText[i] != '\0')
    {
        charArray[i] = stringText[i];
        i++;
    }
    charArray[i] = '\0';
}

void MyString::Write() {
    std::cout << charArray;
}

char& MyString::operator[](int index) {
    return charArray[index];
}

char& MyString::operator[](int index) const {
    return charArray[index];
}

int MyString::GetLenght() const {
    return length;
}

void MyString::SetLenght(int len) {
    length = len;
}

void MyString::Replace(const char stringText[]) {
    length = CharArrayLength(stringText)+1;

    if (length >= buffer) {
        delete[] charArray;
        buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        charArray = new char[buffer];
    }

    int i = 0;
    while (stringText[i] != '\0')
    {
        charArray[i] = stringText[i];
        i++;
    }
    charArray[i] = '\0';
}

void MyString::ReplaceBySlicedString(const char stringText[], int startIndex, int endIndex) {

    length = endIndex - startIndex + 2;

    if (length >= buffer) {
        buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        delete[] charArray;
        charArray = new char[buffer];
    }

    for (int i = 0; i < length; i++) {
        if (i == length - 1) {
            charArray[i] = '\0';
        }
        else {
            charArray[i] = stringText[i + startIndex];
        }
    }
}

void MyString::AddAtEndPartOfString(const char table[], int startIndex, int endIndex) {
    int lengthToAdd = endIndex - startIndex + 3;
    char* tempArray = new char[lengthToAdd];

    for (int i = 0; i < lengthToAdd; i++) {
        if (i == lengthToAdd - 1) {
            tempArray[i] = '\0';
        }
        else {
            tempArray[i] = table[i + startIndex];
        }
    }

    AddAtEnd(tempArray);
}

void MyString::Copy(MyString& desc) {
    if (desc.buffer <= length) {
        delete[] desc.charArray;
        desc.buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        desc.charArray = new char[desc.buffer];
    }

    desc.length = length;

    for (int i = 0; i < length; i++) {
        desc.charArray[i] = charArray[i];
    }
}

char* MyString::GetCharArray() {
    return charArray;
}

bool operator==(const MyString& myStringL, const MyString& myStringR)
{
    if (myStringL.length != myStringR.length) {
        return false;
    }

    for (int i = 0; i < myStringL.length; i++) {
        if (myStringL[i] != myStringR[i]) {
            return false;
        }
    }
    return true;
}

bool operator==(const char*& charArrayL, const MyString& myStringR)
{
    int charArrayLLength = CharArrayLength(charArrayL);
    if (charArrayLLength != myStringR.length) {
        return false;
    }

    for (int i = 0; i < charArrayLLength; i++) {
        if (charArrayL[i] != myStringR[i]) {
            return false;
        }
    }
    return true;
}

bool MyString::IsEqualTo(const char* charArrayL) {
    int charArrayLLength = CharArrayLength(charArrayL);
    if (charArrayLLength != length - 1) {
        return false;
    }

    for (int i = 0; i < charArrayLLength; i++) {
        if (charArrayL[i] != charArray[i]) {
            return false;
        }
    }
    return true;
}

char MyString::GetIndexValue(int index) {
    return charArray[index];
}

void MyString::InsertOnIndex(const MyString& myString, int index) {
    if ((index < 0) || (index >= length)) {
        return;
    }

    char* newCharArray = new char[length + myString.GetLenght()];

    length = length + myString.GetLenght();

    int oldCouter = 0;
    int insetertedCouter = 0;
    for (int i = 0; i < length; i++) {
        if (i < index) {
            newCharArray[i] = charArray[oldCouter];
            oldCouter++;
        }
        else if (i < index + myString.GetLenght()) {
            newCharArray[i] = charArray[insetertedCouter];
            insetertedCouter++;
        }
        else {
            newCharArray[i] = charArray[oldCouter];
            oldCouter++;
        }
    }
    delete[] charArray;
    charArray = newCharArray;
}

void MyString::EmptyMyString() {
    charArray[0] = '\0';
    length = 1;
}

void MyString::ClearStr() {
    bool clearOnFront = false;
    bool clearOnEnd = false;

    if (length == 1) {
        return;
    }

    if ((charArray[0] == '{') || (charArray[0] == '}') || (charArray[0] == ';') || (charArray[0] == ',') ||  isspace(charArray[0]) || (charArray[0] == ':')) {
        clearOnFront = true;
    }

    if ((charArray[length - 2] == '{') || (charArray[length - 2] == '}') || (charArray[length - 2] == ':') || (charArray[length - 2] == ';') || isspace(charArray[length - 2])) {
        clearOnEnd = true;
    }
    // maksymalna minimalizacja (dugo 2 oznacza, e zosta jeden znak (znak + '\0'))
    if (length <= 2) {
        return;
    }
    if (clearOnFront) {
        for (int i = 0; i < length; i++) {
            charArray[i] = charArray[i + 1];
        }
        length--;
    }
    if (clearOnEnd) {
        charArray[length - 2] = '\0';
        length--;
    }

    if ((charArray[0] == '{') || (charArray[0] == '}') || (charArray[0] == ';') || (charArray[0] == ',') || isspace(charArray[0]) || (charArray[0] == ':') ) {
        ClearStr();
    }

    if ((charArray[length - 2] == '{') || (charArray[length - 2] == '}') || (charArray[length - 2] == ':') || (charArray[length - 2] == ';') || isspace(charArray[length - 2])) {
        ClearStr();
    }
}

void MyString::ReplaceOnIndex(const char sign, int index) {
    if ((index < 0) || (index >= length)) {
        return;
    }
    charArray[index] = sign;
}

void MyString::RemoveToIndex(int index) {
    charArray[index] = '\0';
}

void MyString::RemoveOnIndex(int index) {
    if ((index < 0) || (index >= length)) {
        return;
    }
    for (int i = index; i < length - 1; i++) {
        charArray[i] = charArray[i + 1];
    }
    length--;
}

void MyString::AddAtEnd(const char sign) {
    length += 1;

    char* tempArr = NULL;

    if (length >= buffer) {
        tempArr = charArray;
        buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        charArray = new char[buffer];
    }

    if (tempArr != NULL) {
        for (int i = 0; i < length; i++) {
            if (i < length - 2) {
                charArray[i] = tempArr[i];
            }
            else if (i == length - 2) {
                charArray[i] = sign;
            }
            else {
                charArray[i] = '\0';
            }
        }
    }
    else {
        charArray[length - 2] = sign;
        charArray[length - 1] = '\0';
    }
    if (tempArr!=NULL) {
        delete[] tempArr;
    }
}

void MyString::AddAtEnd(const char table[]) {
    int additionLength = 0;
    while (table[additionLength] != '\0')
    {
        additionLength++;
    }

    int oldLength = length;

    length += additionLength;

    char* tempArr = NULL;

    if (length >= buffer) {
        buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        charArray = new char[buffer];
    }

    if (tempArr != NULL) {

        for (int i = 0; i < length; i++) {
            if (i < oldLength - 1) {
                charArray[i] = tempArr[i];
            }
            else {
                charArray[i] = table[i - oldLength + 1];
            }
        }
    }
    else {
        for (int i = oldLength - 1; i < length; i++) {
               charArray[i] = table[i - oldLength + 1];
        }
    }
    if (tempArr != NULL) {
        delete[] tempArr;
    }
}

void MyString::AddAtEnd(const MyString& myString) {

    int additionLength = myString.GetLenght() - 1;
    int oldLength = length;
    char* tempArr = NULL;

    length += additionLength;

    if (length >= buffer) {
        tempArr = charArray;
        buffer = (length / MY_STRING_LENGTH_BUFFER) * MY_STRING_LENGTH_BUFFER + MY_STRING_LENGTH_BUFFER;
        charArray = new char[buffer];
    }

    if (tempArr != NULL) {
        for (int i = 0; i < length; i++) {
            if (i < oldLength - 1) {
                char cp;
                cp = tempArr[i];
                charArray[i] = cp;
            }
            else {
                char cp = myString[i - oldLength + 1];
                charArray[i] = cp;
            }
        }
    }
    else {
        for (int i = oldLength - 1; i < length; i++) {
            char cp = myString[i - oldLength + 1];
            charArray[i] = cp;
        }
    }
    if (tempArr != NULL) {
        delete[] tempArr;
    }
}


int MyString::FindChar(const char sign) {
    for (int i = 0; i < length; i++) {
        if (charArray[i] == sign) {
            return i;
        }
    }
    return -1;
}

MyString::~MyString() {
    delete[] charArray;
}

int ConvertStringToInt(const char* stringArr, int startIndex, int length) {
    int counter = 0;
    int multiplier = 1;
    for (int i = startIndex + length - 2; i >= startIndex; i--) {
        counter += (stringArr[i] - int('0')) * multiplier;
        multiplier *= 10;
    }
    return counter;
}
