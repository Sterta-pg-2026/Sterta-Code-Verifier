﻿#pragma once
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "mystring.h"
#include "defines.h"
#include "structures.h"
// -------------- commend sections -------------

int CountAllSections(ProgramState* programState);

// return -1 whe section dont't exist
int CountNumbersOfSelOrPropForSectionNr(DoublyLinkedList* sectionsList, ProgramState* programState, int sectionNumber, int mode);

void SearchForSelOrPropForSectionNrOfNr(DoublyLinkedList* sectionsList, ProgramState* programState, int sectionNumber, int itemNumber, int mode, MyString* result, MyString* propName = NULL);

int CountOfChosenSelector(DoublyLinkedList* sectionsList,  MyString* selectorName);

int CountOfChosenAtributes(DoublyLinkedList* sectionsList,  MyString* attrName);

// return true if attr was finded, in other case return false
bool FindAndPrintValueOfProperty(AttributesList* attrCursor, MyString* attrName, MyString* result);

// return true if selector was finded, in other case return false
bool FindSelector(SelectorsList* selCursor, MyString* selName);

void FindLastAttrValue(DoublyLinkedList* sectionsList, MyString* attrName, MyString* selectorName, MyString* result);

void DeleteLastFromSelList(SelectorsList* cursor, int* counter);

void DeleteAllSelectorsInList(SelectorsList* cursor, Section* sectionCursor);

void DeleteLastFromAttrList(AttributesList* cursor, int* counter);

void DeleteAllArgsAndSelFromBlock(DoublyLinkedList* cursor, int index);

void DeleteAllArgsAndSelFromNode(DoublyLinkedList* cursor);

bool DeleteSelectedFromAttrList(AttributesList* cursor, ProgramState* programState, Section* sectionCursor, int* counter, MyString* attrt);

bool DeleteChosenSection(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int sectionNumber);

bool DeleteChosenAttrFromChosenSection(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int sectionNumber, MyString* attrName);
// --------------^commend sections^----
