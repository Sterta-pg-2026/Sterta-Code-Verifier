﻿#pragma once
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "mystring.h"
#include "defines.h"
#include "structures.h"
// ----------------saving section----------
bool AddToAttributesList(AttributesList* list, const char* prop, const char* val) {
    AttributesList* cursor = list;
    while (cursor->next != NULL)
    {
        cursor = cursor->next;
        // checking if there are any duplicates
        if (cursor->attributeValue->property->IsEqualTo(prop)) {
            cursor->attributeValue->value->Replace(val);
            return false;
        }
    }
    cursor->next = new AttributesList;
    cursor->next->attributeValue = new AttributeValue(prop, val);
    return true;
}

bool AddToSelectorsList(SelectorsList* list, const char selector[]) {
    SelectorsList* cursor = list;

    while (cursor->next != NULL)
    {
        cursor = cursor->next;
        // searching for duplicates
        if (cursor->selector->IsEqualTo(selector)) {
            return false;
        }
    }
    cursor->next = new SelectorsList;
    cursor->next->selector = new MyString(selector);
    return true;
}

void AddToCSSSectionsList(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int dataType, const char data[], const char secondData[] = NULL, bool goToNext = false) {

    // initializating the new doubly linked list with blocks (on program start on after deleting all sections)
    if (sectionsListHead->head == NULL) {
        sectionsListHead->head = new DoublyLinkedList;
        sectionsListHead->tail = sectionsListHead->head;
        sectionsListHead->nodesCount = 1;
        programState->allSectionsCreatedCount = 1;
        programState->allSectionsCount = 1;
        goToNext = false;
    }

    DoublyLinkedList* cursor = sectionsListHead->tail;

    int sectionCountInBlock = programState->allSectionsCreatedCount - (sectionsListHead->nodesCount-1) * BLOCK_SIZE_BUFFER;
    int sectionIndex = -1;

    if (goToNext) {
        if (sectionCountInBlock >= BLOCK_SIZE_BUFFER) {
            cursor->next = new DoublyLinkedList;
            cursor->next->prev = cursor;
            cursor->next->next = NULL;
            cursor = cursor->next;
            sectionsListHead->tail = cursor;
            sectionsListHead->nodesCount++;
            sectionIndex = 0;
        }
        else {
            cursor->counter++;
            sectionIndex = sectionCountInBlock;
        }
        programState->allSectionsCount++;
        programState->allSectionsCreatedCount++;
    }
    else {
        sectionIndex = sectionCountInBlock-1;
    }

    if (dataType == SAVE_PROP) {
        if (cursor->block[sectionIndex].attributes == NULL) {
            cursor->block[sectionIndex].attributes = new AttributesList;
        }
        // saving the full attrs (prop + value)
        if (AddToAttributesList(cursor->block[sectionIndex].attributes, data, secondData)) {
            cursor->block[sectionIndex].propertiesCounter++;
        }
    }
    else if (dataType == SAVE_SEL)
    {
        // checking if this saction have global attrs
        if (strcmp(data, "NO_SECECTOR_SPECIFIED") != 0) {
            if (cursor->block[sectionIndex].selectors == NULL) {
                cursor->block[sectionIndex].selectors = new SelectorsList;
            }
            if (AddToSelectorsList(cursor->block[sectionIndex].selectors, data)) {
                cursor->block[sectionIndex].selectorCounter++;
            }
        }
        else {
            if (cursor->block[sectionIndex].selectors == NULL) {
                cursor->block[sectionIndex].selectors = new SelectorsList;
            }
        }
    }
}

// ----------------^saving section^----------