﻿#pragma once
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "mystring.h"
#include "defines.h"
#include "structures.h"
// ----------------saving section----------

// return true when there are no attrs duplicates and false in other cases
bool AddToAttributesList(AttributesList* list, const char* prop, const char* val);

// return true when there are no selectors duplicates and false in other cases
bool AddToSelectorsList(SelectorsList* list, const char selector[]);

void AddToCSSSectionsList(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int dataType, const char data[], const char secondData[] = NULL, bool goToNext = false);

// ----------------^saving section^----------
