﻿#pragma once

// Data structures

struct AttributeValue
{
    MyString* property;
    MyString* value;
    AttributeValue(const char attr[], const  char val[]) {
        property = new MyString(attr);
        value = new MyString(val);
    }
};

struct AttributesList {
    AttributeValue* attributeValue = NULL;
    AttributesList* next = NULL;
};

struct SelectorsList {
    MyString* selector = NULL;
    SelectorsList* next = NULL;
};

struct Section
{
    int selectorCounter = 0;
    int propertiesCounter = 0;
    SelectorsList* selectors = NULL;
    AttributesList* attributes = NULL;
};

struct DoublyLinkedList {
    int counter = 1;
    Section block[BLOCK_SIZE_BUFFER];
    DoublyLinkedList* prev = NULL;
    DoublyLinkedList* next = NULL;
};

struct DoublyLinkedListHead {
    DoublyLinkedList* head = NULL;
    DoublyLinkedList* tail = NULL;
    int nodesCount = 0;
};

struct ProgramState
{
    int readMode = READ_SELECTORS;
    char lastChar = 'T';
    bool goToNextSection = false;
    int allSectionsCount = 1;
    int allSectionsCreatedCount = 1;
};
