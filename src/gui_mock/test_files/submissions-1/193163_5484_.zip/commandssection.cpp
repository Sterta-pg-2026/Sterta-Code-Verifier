﻿#include <stdio.h>
#include <iostream>
#include <string.h>
#include "mystring.h"
#include "defines.h"
#include "structures.h"
// --------------commands section-------------

int CountAllSections(ProgramState* programState) {
    return programState->allSectionsCount;
}

// return -1 if section doesn't exist
int CountNumbersOfSelOrPropForSectionNr(DoublyLinkedList* sectionsList, ProgramState* programState, int sectionNumber, int mode) {
    DoublyLinkedList* cursor = sectionsList;

    if (sectionNumber > programState->allSectionsCount) {
        return -1;
    }

    do {
        if (sectionNumber <= cursor->counter) {
            // to which section we must enter
            int innerCounter = sectionNumber - 1;
            int i = 0;
            for (i; i < BLOCK_SIZE_BUFFER; i++) {
                if (cursor->block[i].propertiesCounter != 0) {
                    if (innerCounter == 0) {
                        break;
                    }
                    innerCounter--;
                }
            }
            if (mode == RETURN_COUNT_OF_SELECTORS) {
                return cursor->block[i].selectorCounter;
            }
            else if (mode == RETURN_COUNT_OF_PROPERTIES) {
                return cursor->block[i].propertiesCounter;
            }
            else {
                return NULL;
            }
        }
        sectionNumber -= cursor->counter;
        if (cursor->next != NULL) {
            cursor = cursor->next;
        }
        else {
            break;
        }
    } while (true);

    return NULL; // this should never be executed
}

void SearchForSelOrPropForSectionNrOfNr(DoublyLinkedList* sectionsList, ProgramState* programState, int sectionNumber, int itemNumber, int mode, MyString* result, MyString* propName = NULL) {
    DoublyLinkedList* cursor = sectionsList;

    if (sectionNumber > programState->allSectionsCount) {
        return; // there is nothing to return because that section douesn't exist
    }

    do {
        if (sectionNumber <= cursor->counter) {
            // to which section we must enter
            int i = 0;
            for (i = 0; i < BLOCK_SIZE_BUFFER; i++) {
                if (cursor->block[i].propertiesCounter != 0) {
                    sectionNumber--;
                    if (sectionNumber == 0) {
                        break;
                    }
                }
            }

            if (i == BLOCK_SIZE_BUFFER) {
                return;
            }
            // basing on passed parameter it decide to seach for sel or prop
            if (mode == PRINT_SEL_NR) {
                if (cursor->block[i].selectorCounter < itemNumber) {
                    return;
                }
                else {
                    SelectorsList* selCursor = cursor->block[i].selectors;
                    for (int j = 0; j < itemNumber; j++) {
                        selCursor = selCursor->next;
                    }
                    if (selCursor != NULL) {
                        result->Replace(selCursor->selector->GetCharArray());
                    }
                }
                return;
            }
            else if (mode == PRINT_PROP_VALUE) {
                AttributesList* attrCursor = cursor->block[i].attributes;
                while (attrCursor->next != NULL)
                {
                    attrCursor = attrCursor->next;
                    if (attrCursor->attributeValue->property->IsEqualTo(propName->GetCharArray())) {
                        result->Replace(attrCursor->attributeValue->value->GetCharArray());
                        return;
                    }
                }
                return;
            }
            else {
                return;
            }
        }
        if (cursor->next != NULL) {
            sectionNumber -= cursor->counter;
            cursor = cursor->next;
        }
        else
        {
            break;
        }
    } while (true);

    return; // this should be never executed
}

int CountOfChosenSelector(DoublyLinkedList* sectionsList, MyString* selectorName) {
    if (sectionsList == NULL) {
        return 0;
    }
    int selectorCounter = 0;

    DoublyLinkedList* sectionsCoursor = sectionsList;

    do {
        for (int i = 0; i < BLOCK_SIZE_BUFFER; i++) {
            if (sectionsCoursor->block[i].propertiesCounter != 0) {
                SelectorsList* selCursor = sectionsCoursor->block[i].selectors;

                while (selCursor->next != NULL)
                {
                    selCursor = selCursor->next;
                    if (selCursor->selector->IsEqualTo(selectorName->GetCharArray())) {
                        selectorCounter++;
                        break;
                    }
                }
            }
        }
        if (sectionsCoursor->next != NULL) {
            sectionsCoursor = sectionsCoursor->next;
        }
        else
        {
            break;
        }
    } while (true);

    return selectorCounter;
}

int CountOfChosenAtributes(DoublyLinkedList* sectionsList, MyString* attrName) {
    if (sectionsList == NULL) {
        return 0;
    }
    int attrCounter = 0;

    DoublyLinkedList* sectionsCoursor = sectionsList;

    do {
        for (int i = 0; i < BLOCK_SIZE_BUFFER; i++) {
            if (sectionsCoursor->block[i].propertiesCounter != 0) {
                AttributesList* attrCursor = sectionsCoursor->block[i].attributes;

                if (attrCursor != NULL) {
                    while (attrCursor->next != NULL)
                    {
                        attrCursor = attrCursor->next;
                        if (attrCursor->attributeValue->property->IsEqualTo(attrName->GetCharArray())) {
                            attrCounter++;
                            break;
                        }
                    }
                }
            }
        }
        if (sectionsCoursor->next != NULL) {
            sectionsCoursor = sectionsCoursor->next;
        }
        else
        {
            break;
        }
    } while (true);

    return attrCounter;
}

// return true if selected attr was founded. In another case return false 
bool FindAndPrintValueOfProperty(AttributesList* attrCursor, MyString* attrName, MyString* result) {
    while (attrCursor->next != NULL)
    {
        attrCursor = attrCursor->next;
        if (attrCursor->attributeValue->property->IsEqualTo(attrName->GetCharArray())) {
            result->Replace(attrCursor->attributeValue->value->GetCharArray());
            return true;
        }
    }
    return false;
}

// return true if selected selector was founded. In another case return false 
bool FindSelector(SelectorsList* selCursor, MyString* selName) {
    if (selCursor == NULL) {
        // global attrs section == no selectors
        return false;
    }
    while (selCursor->next != NULL)
    {
        selCursor = selCursor->next;
        if (selCursor->selector->IsEqualTo(selName->GetCharArray())) {
            return true;
        }
    }
    return false;
}

void FindLastAttrValue(DoublyLinkedList* sectionsList, MyString* attrName, MyString* selectorName, MyString* result) {
    if (sectionsList == NULL) {
        return;
    }
    
    DoublyLinkedList* sectionsCursor = sectionsList;

    // we are iterating through the list from tail to head
    do {
        for (int i = BLOCK_SIZE_BUFFER - 1; i >= 0; i--) {
            if ((sectionsCursor->block[i].propertiesCounter > 0) && (FindSelector(sectionsCursor->block[i].selectors, selectorName))) {
                if (FindAndPrintValueOfProperty(sectionsCursor->block[i].attributes, attrName, result)) {
                    return;
                }
            }
        }
        if (sectionsCursor->prev != NULL) {
            sectionsCursor = sectionsCursor->prev;
        }
        else {
            // attr was not found
            return;
        }
    } while (true);
}

void DeleteLastFromSelList(SelectorsList* cursor, int* counter) {
    if (cursor->next == NULL) {
        return;
    }
    while (cursor->next->next != NULL)
    {
        cursor = cursor->next;
    }
    // we are deleting last element from selectors list
    delete cursor->next->selector;
    delete cursor->next;
    cursor->next = NULL;
    (*counter)--;
}

void DeleteAllSelectorsInList(SelectorsList* cursor, Section* sectionCursor) {
    for (int i = sectionCursor->selectorCounter; i > 0; i--) {
        DeleteLastFromSelList(cursor, &sectionCursor->selectorCounter);
    }
}

void DeleteLastFromAttrList(AttributesList* cursor, int* counter) {

    if (cursor->next == NULL) {
        return;
    }
    while (cursor->next->next != NULL)
    {
        cursor = cursor->next;
    }
    // we are deleting last element of attrs list
    delete cursor->next->attributeValue->property;
    delete cursor->next->attributeValue->value;
    delete cursor->next->attributeValue;
    delete cursor->next;
    cursor->next = NULL;
    (*counter)--;
}

// return true if selected attribute was deleted and false if didn't
bool DeleteSelectedFromAttrList(AttributesList* cursor, ProgramState* programState, Section* sectionCursor, int* counter, MyString* attrt) {
    if ((cursor == NULL)|| (cursor->next == NULL)) {
        return false;
    }

    // flag to return
    bool REMOVE_ANYTHING_FLAG = false;

    while (cursor->next != NULL)
    {
        if (cursor->next->attributeValue->property->IsEqualTo(attrt->GetCharArray())) {
            if (cursor->next->next == NULL) {
                // we are deleting last element in list
                delete cursor->next->attributeValue->property;
                delete cursor->next->attributeValue->value;
                delete cursor->next->attributeValue;
                delete cursor->next;
                cursor->next = NULL;
                (sectionCursor->propertiesCounter)--;
                REMOVE_ANYTHING_FLAG = true;
                break;
            }
            else {
                // we are deleting not last element in list
                AttributesList* cursorCopy = cursor->next->next;
                delete cursor->next->attributeValue->property;
                delete cursor->next->attributeValue->value;
                delete cursor->next->attributeValue;
                delete cursor->next;
                cursor->next = cursorCopy;
                (sectionCursor->propertiesCounter)--;
                REMOVE_ANYTHING_FLAG = true;
                break;
            }
        }
        cursor = cursor->next;
    }

    // check if section is empty and clean it if it is
    if (sectionCursor->propertiesCounter == 0) {
        DeleteAllSelectorsInList(sectionCursor->selectors, sectionCursor);
        delete sectionCursor->selectors;
        delete sectionCursor->attributes;
        sectionCursor->selectors = NULL;
        sectionCursor->attributes = NULL;
        (*counter)--;
        (programState->allSectionsCount)--;
    }
    return REMOVE_ANYTHING_FLAG;
}

bool DeleteNode(DoublyLinkedListHead* sectionsListHead, DoublyLinkedList* cursor) {
    if ((cursor->next != NULL) && (cursor->prev != NULL)) {
        DoublyLinkedList* nextCursorCopy = cursor->next;
        cursor = cursor->prev;
        delete[] cursor->next;
        cursor->next = nextCursorCopy;
        cursor->next->prev = cursor;
        return true;
    }
    else if ((cursor->next == NULL) && (cursor->prev != NULL)) {
        cursor = cursor->prev;
        sectionsListHead->tail = cursor;
        delete[] cursor->next;
        cursor->next = NULL;
        return true;
    }
    else if ((cursor->next != NULL) && (cursor->prev == NULL)) {
        cursor = cursor->next;
        sectionsListHead->head = cursor;
        delete[] cursor->prev;
        cursor->prev = NULL;
        return true;
    }
    else {
        delete cursor;
        sectionsListHead->head = NULL;
        sectionsListHead->tail = NULL;
        return true;
    }
}

void DeleteAllArgsAndSelFromBlock(DoublyLinkedList* cursor,int index) {
    if (index >= BLOCK_SIZE_BUFFER) {
        return;
    }
    while (cursor->block[index].selectorCounter != 0)
    {
        if (cursor->block[index].selectors == NULL) {
            break;
        }
        DeleteLastFromSelList(cursor->block[index].selectors, &cursor->block[index].selectorCounter);
    }
    delete cursor->block[index].selectors;
    cursor->block[index].selectors = NULL;

    while (cursor->block[index].propertiesCounter != 0)
    {
        if (cursor->block[index].attributes == NULL) {
            break;
        }
        DeleteLastFromAttrList(cursor->block[index].attributes, &cursor->block[index].propertiesCounter);
    }
    delete cursor->block[index].attributes;
    cursor->block[index].attributes = NULL;
}

void DeleteAllArgsAndSelFromNode(DoublyLinkedList* cursor) {
    for (int i = 0; i < BLOCK_SIZE_BUFFER; i++) {
        if (cursor->block[i].attributes != NULL) {
            DeleteAllArgsAndSelFromBlock(cursor, i);
        }
    }
}

// if section was deleted return true. In other case false
bool DeleteChosenSection(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int sectionNumber) {
    if ((sectionsListHead->head == NULL)||(sectionNumber <= 0)||(sectionNumber > programState->allSectionsCount)) {
        return false;
    }
    DoublyLinkedList* cursor = sectionsListHead->head;

    do {
        if (sectionNumber <= cursor->counter) {
            // count which section of node we should delete
            int i = 0;
            for (i = 0; i < BLOCK_SIZE_BUFFER; i++) {
                if (cursor->block[i].propertiesCounter != 0) {
                    sectionNumber--;
                    if (sectionNumber == 0) {
                        break;
                    }
                }
            }
            
            DeleteAllArgsAndSelFromBlock(cursor, i);
            (cursor->counter)--;
            (programState->allSectionsCount)--;
            
            if (cursor->counter == 0) {
                if (DeleteNode(sectionsListHead, cursor)) {
                    // node was deleted
                    sectionsListHead->nodesCount--;
                    if (sectionsListHead->nodesCount == 0) {
                        programState->allSectionsCreatedCount = 0;
                    }
                    else {
                        programState->allSectionsCreatedCount -= BLOCK_SIZE_BUFFER;
                    }
                }
            }
            return true;
        }

        if (cursor->next != NULL) {
            sectionNumber -= cursor->counter;
            cursor = cursor->next;
        }
        else {
            return false;
        }
    } while (true);
}

bool DeleteChosenAttrFromChosenSection(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, int sectionNumber, MyString* attrName) {
    if ((sectionsListHead->head == NULL)|| (sectionNumber <= 0)|| (sectionNumber > programState->allSectionsCount)) {
        return false;
    }

    DoublyLinkedList* cursor = sectionsListHead->head;

    do {
        if (sectionNumber <= cursor->counter) {
            // count to which section we schould enter
            int i = 0;
            for (i = 0; i < BLOCK_SIZE_BUFFER; i++) {
                if (cursor->block[i].propertiesCounter != 0) {
                    sectionNumber--;
                    if (sectionNumber == 0) {
                        break;
                    }
                }
            }
            if (i >= BLOCK_SIZE_BUFFER) {
                return false;
            }

            bool result = DeleteSelectedFromAttrList(cursor->block[i].attributes, programState, &cursor->block[i], &cursor->counter, attrName);
            
            // place to delete
            if (result) {
                if ((cursor->counter==0)&&(DeleteNode(sectionsListHead, cursor))) {
                    // node was deleted
                    sectionsListHead->nodesCount--;
                    programState->allSectionsCreatedCount -= BLOCK_SIZE_BUFFER;
                }
            }
            return result;
        }

        if (cursor->next != NULL) {
            sectionNumber -= cursor->counter;
            cursor = cursor->next;
        }
        else {
            return false;
        }
    } while (true);
}
// --------------^commands section^---------------------------