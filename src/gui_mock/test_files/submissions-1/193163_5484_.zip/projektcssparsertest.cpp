﻿#include <stdio.h>
#include <iostream>
#include <string.h>
#include "mystring.h"
#include "defines.h"
#include "structures.h"
#include "commandssection.h"
#include "addingtolist.h"
using namespace std;


// ----------------reading section-------------------------
void ReadSelectors(char firstChar, ProgramState* programState,  DoublyLinkedListHead* sectionsListHead);

void ReadNumFirstCommands(DoublyLinkedListHead* sectionsListHead, ProgramState* programState, MyString* firstArg, MyString* secondArg, MyString* thirdArg);

void ReadStringFirstCommands(DoublyLinkedListHead* sectionsListHead,  MyString* firstArg, MyString* secondArg, MyString* thirdArg);

void ReadAttrs(ProgramState* programState, DoublyLinkedListHead* sectionsListHead) {
    programState->readMode = READ_PROPERTIES;
    char sign = getchar();
    MyString* currentAttrName = new MyString();
    MyString* currentAttrValue = new MyString();

    while (sign != '}')
    {
        // building attribute name
        while (sign != ':') {
            currentAttrName->AddAtEnd(sign);
            sign = getchar();
        }
        // bulding value name
        while (sign != ';') {
            currentAttrValue->AddAtEnd(sign);
            sign = getchar();

            if (sign == '}') {
                // exit the attributes section
                break;
            }
        }

        // cleaning strings from control signs and white signs
        currentAttrName->ClearStr();
        currentAttrValue->ClearStr();

        // adding data (property and value) to appropriate list
        AddToCSSSectionsList(sectionsListHead, programState, SAVE_PROP, currentAttrName->GetCharArray(), currentAttrValue->GetCharArray(), programState->goToNextSection);

        currentAttrName->EmptyMyString();
        currentAttrValue->EmptyMyString();

        if (sign != '}') {
            sign = getchar();
        }
        while ((sign == ' ') || (sign == '\n') || (sign == '\t'))
        {
            sign = getchar();
        }
    }
    programState->goToNextSection = true;
    delete currentAttrName;
    delete currentAttrValue;
}

void ReadSelectors(char firstChar, ProgramState* programState,  DoublyLinkedListHead* sectionsListHead) {
    char sign = firstChar;
    MyString* currentSelectorName = new MyString();

    if (sign == '{') {
        // no selectors == global attributes
        AddToCSSSectionsList(sectionsListHead, programState, SAVE_SEL, NO_SECECTOR_SPECIFIED, NULL, programState->goToNextSection);
        programState->readMode = READ_PROPERTIES;
        programState->goToNextSection = false;
    }

    while (sign != '{')
    {
        while (sign != ',') {
            currentSelectorName->AddAtEnd(sign);
            sign = getchar();
            if (sign == '{') {
                break;
            }
        }
        if (sign != '{') {
            sign = getchar();
        }
        currentSelectorName->ClearStr();

        // place in which we gave selector name to save
        AddToCSSSectionsList(sectionsListHead, programState, SAVE_SEL, currentSelectorName->GetCharArray(), NULL, programState->goToNextSection);

        programState->goToNextSection = false;
        currentSelectorName->EmptyMyString();
    }

    // change program mode to reading attrs
    programState->readMode = READ_PROPERTIES;
    delete currentSelectorName;
    ReadAttrs(programState, sectionsListHead);
}

// it fill the array with the part of command (to first comma or specified whitespace or EOF)
char ReadToCommaOrEnd(MyString* arrToFill) {
    char sign = getchar();
    while ((sign != ',') && (sign != '\n') && (sign != EOF) && (sign != '\t'))
    {
        arrToFill->AddAtEnd(sign);
        sign = getchar();
    }
    arrToFill->ClearStr();
    return sign;
}

void DeleteCommandsHolders(MyString* firstArg, MyString* secondArg, MyString* thirdArg) {
    delete firstArg;
    delete secondArg;
    delete thirdArg;
}

void ReadCommands(ProgramState* programState, DoublyLinkedListHead* sectionsListHead) {
    MyString* firstArg = new MyString();
    MyString* secondArg = new MyString();
    MyString* thirdArg = new MyString();

    while (true)
    {
        char sign;
        if ((sign = getchar()) == EOF) {
            DeleteCommandsHolders(firstArg, secondArg, thirdArg);
            // end of the file -> preparing to finish program
            return; 
        }

        while (isspace(sign))
        {
            if ((sign = getchar()) == EOF) {
                DeleteCommandsHolders(firstArg, secondArg, thirdArg);
                return;
            }
        }

        if (sign == '?') {  
            cout << "?" << " == " << CountAllSections(programState) << endl;
            continue;
        }

        firstArg->AddAtEnd(sign);
        ReadToCommaOrEnd(firstArg);

        if (firstArg->IsEqualTo("****")) {
            // end of commands section
            break;
        }
        ReadToCommaOrEnd(secondArg);

        // shifting out errors
        char testSign = ReadToCommaOrEnd(thirdArg);
        if (testSign == ',') {
            MyString* trash = new MyString();
            ReadToCommaOrEnd(trash);
            delete trash;
        }

        // place in which commands are executed
        if ((firstArg->GetCharArray()[0] >= '0') && (firstArg->GetCharArray()[0] <= '9')) {
            ReadNumFirstCommands(sectionsListHead, programState, firstArg, secondArg, thirdArg);
        }
        else {
            ReadStringFirstCommands(sectionsListHead,  firstArg, secondArg, thirdArg);
        }
        
        firstArg->EmptyMyString();
        secondArg->EmptyMyString();
        thirdArg->EmptyMyString();
    }
    DeleteCommandsHolders(firstArg, secondArg, thirdArg);

    // go to reading selectors mode
    programState->readMode = READ_SELECTORS;
    programState->goToNextSection = true;
}

// first comman arg is number
void ReadNumFirstCommands(DoublyLinkedListHead* sectionsListHead,ProgramState* programState,MyString* firstArg, MyString* secondArg, MyString* thirdArg) {
    int firstArgNum = ConvertStringToInt(firstArg->GetCharArray(), 0, firstArg->GetLenght());

    switch (secondArg->GetCharArray()[0])
    {
    case 'S': {
        if (thirdArg->GetCharArray()[0] == '?') {
            // i,S,? ï¿½ wypisz liczbï¿½ selektorï¿½w dla sekcji nr i (numery zaczynajï¿½ siï¿½ od 1), jeï¿½li nie ma takiego bloku pomiï¿½
            int count = CountNumbersOfSelOrPropForSectionNr(sectionsListHead->head, programState, firstArgNum, RETURN_COUNT_OF_SELECTORS);
            if (count == -1) {
                break;
            }
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << count << endl;
        }
        else {
            //i,S,j ï¿½ wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutï¿½w zaczynajï¿½ siï¿½ od 1) jeï¿½li nie ma sekcji lub selektora pomiï¿½;
            int j = ConvertStringToInt(thirdArg->GetCharArray(), 0, thirdArg->GetLenght());

            MyString* result = new MyString();
            SearchForSelOrPropForSectionNrOfNr(sectionsListHead->head, programState, firstArgNum, j, PRINT_SEL_NR, result);

            if (result->GetLenght() <= 1) {
                delete result;
                break;
            }
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << result->GetCharArray() << endl;
            delete result;
        }
        break;
    }
    case 'A': {
        if (thirdArg->GetCharArray()[0] == '?') {
            // i,A,? - wypisz liczbï¿½ atrybutï¿½w dla sekcji nr i, jeï¿½li nie ma takiego bloku lub sekcji pomiï¿½;
            int count = CountNumbersOfSelOrPropForSectionNr(sectionsListHead->head, programState, firstArgNum, RETURN_COUNT_OF_PROPERTIES);
            if (count == -1) {
                break;
            }
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << count << endl;
        }
        else {
            // i,A,n ï¿½ wypisz dla i-tej sekcji wartoï¿½ï¿½ atrybutu o nazwie n, jeï¿½li nie ma takiego pomiï¿½
            MyString* propToFind = new MyString();
            propToFind->Replace(thirdArg->GetCharArray());
            MyString* result = new MyString();
            SearchForSelOrPropForSectionNrOfNr(sectionsListHead->head, programState, firstArgNum, NULL, PRINT_PROP_VALUE, result, propToFind);

            if (result->GetLenght() <= 1) {
                delete propToFind;
                delete result;
                break;
            }
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << result->GetCharArray() << endl;
            delete propToFind;
            delete result;
        }
        break;
    }
    case 'D': {
        if (thirdArg->GetCharArray()[0] == '*') {
            // i,D,* - usuï¿½ caï¿½ï¿½ sekcjï¿½ nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted
            bool deletedSuccesfully = DeleteChosenSection(sectionsListHead, programState, firstArgNum);
            if (deletedSuccesfully) {
                cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << "deleted" << endl;
            }
        }
        else {
            // i,D,n ï¿½ usuï¿½ z i-tej sekcji atrybut o nazwie n, jeï¿½li w wyniku operacji pozostaje pusta sekcja powinna zostaï¿½ rï¿½wnieï¿½ usuniï¿½ta(wraz z ew.selektorami), po poprawnym wykonaniu wypisz deleted
            MyString* propToFind = new MyString();
            propToFind->Replace(thirdArg->GetCharArray());
            bool deletedSuccesfully = DeleteChosenAttrFromChosenSection(sectionsListHead, programState, firstArgNum, propToFind);
            if (deletedSuccesfully) {
                cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << "deleted" << endl;
            }
            delete propToFind;
        }
        break;
    }
    default:
        break;
    }
}

// first argument of command is not a number
void ReadStringFirstCommands(DoublyLinkedListHead* sectionsListHead, MyString* firstArg, MyString* secondArg, MyString* thirdArg){

    switch (secondArg->GetCharArray()[0]) {
        case 'A': {
            // n,A,? ï¿½ wypisz ï¿½ï¿½cznï¿½ (dla wszystkich blokï¿½w) liczbï¿½ wystï¿½pieï¿½ atrybutu nazwie n. (W ramach pojedynczego bloku duplikaty powinny zostaï¿½ usuniï¿½te na etapie wczytywania).Moï¿½liwe jest 0;
            int count = CountOfChosenAtributes(sectionsListHead->head, firstArg);
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << count << endl;
            break;
        }
        case 'S': {
            // z,S,? ï¿½ wypisz ï¿½ï¿½cznï¿½ (dla wszystkich blokï¿½w) liczbï¿½ wystï¿½pieï¿½ selektora z. Moï¿½liwe jest 0;
            int count = CountOfChosenSelector(sectionsListHead->head, firstArg);
            cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == " << count << endl;
            break;
        }
        case 'E': {
            //z,E,n ï¿½ wypisz wartoï¿½ï¿½ atrybutu o nazwie n dla selektora z, w przypadku wielu wystï¿½pieï¿½ selektora z bierzemy ostatnie.W przypadku braku pomiï¿½;
            MyString* result = new MyString();
            FindLastAttrValue(sectionsListHead->tail, thirdArg, firstArg, result);

            if (result->GetLenght() > 1) {
                cout << firstArg->GetCharArray() << ',' << secondArg->GetCharArray() << ',' << thirdArg->GetCharArray() << " == ";
                result->Write();
                cout << endl;
            }
            delete result;
            break;
        }
        default: {
            break;
        }
    }
 }
// ----------------^reading section^-------------------------

// Main program loop
void MainLoopTest(ProgramState* programState, DoublyLinkedListHead* sectionsListHead) {
    char sign;
    while ((sign = getchar()) != EOF)
    {
        while (isspace(sign))
        {
            if ((sign = getchar()) == EOF) {
                // preparing to finish the program
                break;
            }
        }
        if (sign == '?') {
            for (int i = 0; i < 3; i++) {
                sign = getchar();
            }
            ReadCommands(programState, sectionsListHead);
        }
        else {
            ReadSelectors(sign, programState, sectionsListHead);
        }
    }
}

// Relasing memory to avoid memory leaks
void FreeSpace(DoublyLinkedListHead* sectionsListHead) {
    if (sectionsListHead->nodesCount == 0){
        return;
    }
    else {
        DoublyLinkedList* cursor = sectionsListHead->head;
        do {
            DeleteAllArgsAndSelFromNode(cursor);
            if (cursor->next != NULL) {
                cursor = cursor->next;
                delete[] cursor->prev;
            }
            else {
                // list tail to free
                delete[] sectionsListHead->tail;
                sectionsListHead->head = NULL;
                sectionsListHead->tail = NULL;
                sectionsListHead->nodesCount = 0;
                break;
            }
        } while (true);
    }
}

int main()
{
    DoublyLinkedListHead* sectionsListHead = new DoublyLinkedListHead;

    ProgramState* programState = new ProgramState;

    MainLoopTest(programState,sectionsListHead);

    FreeSpace(sectionsListHead);
    delete sectionsListHead;
    delete programState;

    return 0;
}

