#pragma once
#include "defines.h"

class MyString
{
    char* charArray;
    int length = 1;
    int buffer = MY_STRING_LENGTH_BUFFER;

protected:
    void SetLenght(int len);

public:
    MyString();

    MyString(const char stringText[]);

    void Write();

    char& operator[](int index);

    char& operator[](int index)const;

    friend bool operator==(const MyString& myStringL, const MyString& myStringR);

    friend bool operator==(const char*& charArrayL, const MyString& myStringR);

    int GetLenght() const;

    char* GetCharArray();

    void Replace(const char stringText[]);

    // startIndex powinien by mniejszy od endIndex
    void ReplaceBySlicedString(const char stringText[], int startIndex, int endIndex);

    void InsertOnIndex(const MyString& myString, int index);

    void ReplaceOnIndex(const char sign, int index);

    void RemoveOnIndex(int index);

    void RemoveToIndex(int index);

    void AddAtEnd(const char sign);

    void AddAtEnd(const char table[]);

    void AddAtEnd(const MyString& myString);

    void AddAtEndPartOfString(const char table[], int startIndex, int endIndex);

    bool IsEqualTo(const char* charArrayL);

    char GetIndexValue(int index);

    void ClearStr();

    void EmptyMyString();

    // return -1 when sign was't finded 
    int FindChar(const char sign);

    void Copy(MyString& desc);

    ~MyString();
private:

};

int ConvertStringToInt(const char* stringArr, int startIndex, int length);