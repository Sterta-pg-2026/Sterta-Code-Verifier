#include <iostream>
#include <string.h>

#include "my_string.h"
#include "lists.h"

// ignores characters in std::cin until it reaches one not present in 'chars' or EOF
void IgnoreChars(const char* chars) 
{
    char c;
    if (std::cin.eof()) 
        return;

    c = std::cin.peek();
    while (CstrContains(c, chars)) 
    {
        std::cin.ignore(1);
        if (std::cin.eof()) 
            return;
        c = std::cin.peek();
    }
}

bool isNumber(string& str)
{
    for (int i = 0; i < str.getLength() - 1; i++)
    {
        if (str[i] < '0' || str[i] > '9')
            return false;
    }
    return true;
}

void ExecuteCommand(string& command, CssContainerNode* chain_start) 
{
    // special case: "?"
    if (command == "?")
    {
        std::cout << "? == ";
        auto node = chain_start;
        // check if the chain exists
        if (node == nullptr) {
            std::cout << "0\n";
            return;
        }


        int count = 0;
        while (true) 
        {
            count += node->count_occupied;
            if (node->next == chain_start)
                break;
            node = node->next;
        }
        std::cout << count << "\n";
        return;
    }
    
    // separate args
    string args[3];

    int start = 0;
    int end = 0;
    
    // this makes the loop below work for i == 2, thus requiring less code
    command += ",";
    for (int i = 0; i < 3; i++)
    {
        while (!CstrContains(command[end], ","))
            end++;
        args[i] = command.Substr(start, end - start);
        // skip ','
        end++;
        start = end;
    }
    // remove the ','
    command.PopBack();

    // i,S,?
    if (isNumber(args[0]) && args[1] == "S" && args[2] == "?")
    {
        char* temp = args[0].cstr();
        int index = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        // reference to i-th block's selectors list
        auto block = GetNthSection(index, chain_start);

        if (block == nullptr)
            return;
        auto selectors = block->selectors;

        if (selectors == nullptr)
        {
            std::cout << command << " == " << "0\n";
            return;
        }
        int count = 1;
        while (selectors->next != nullptr)
        {
            selectors = selectors->next;
            count++;
        }
        std::cout << command << " == " << count << "\n";
    }
    // z,S,?
    else if (args[1] == "S" && args[2] == "?")
    {
        int count = 0;
        auto node = chain_start;
        do
        {
            for (int i = 0; i < T; i++)
            {
                if (node->occupied[i] == false)
                    break;
                auto selectors = node->sections[i].selectors;
                while (selectors != nullptr)
                {
                    if (selectors->data == args[0])
                    {
                        count++;
                        break;
                    }
                    selectors = selectors->next;
                }
            }

        } while (node->next != chain_start);

        std::cout << command << " == " << count << "\n";
    }
    // z,E,n
    else if (args[1] == "E")
    {
        string final_value = "";
        auto node = chain_start;
        do
        {
            for (int i = 0; i < T; i++)
            {
                if (node->occupied[i] == false)
                    break;
                auto selectors = node->sections[i].selectors;

                while (selectors != nullptr)
                {
                    // find the correct selector
                    if (selectors->data == args[0])
                    {
                        // find the correct attribute
                        auto attributes = node->sections[i].attributes;
                        while (attributes != nullptr && !(attributes->data.name == args[2]))
                        {
                            attributes = attributes->next;
                        }
                        if (attributes != nullptr)
                            final_value = attributes->data.value;
                        break;
                    }
                    selectors = selectors->next;
                }
            }

        } while (node->next != chain_start);

        // skip the command if the attribute wasn't found
        if (final_value.getLength() == 1)
            return;
        std::cout << command << " == " << final_value << "\n";
    }
    // i,S,j
    else if (isNumber(args[0]) && args[1] == "S" && isNumber(args[2]))
    {
        char* temp = args[0].cstr();
        int i = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        temp = args[2].cstr();
        int j = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        // reference to i-th block's selectors list
        auto block = GetNthSection(i, chain_start);

        if (block == nullptr)
            return;
        auto selectors = block->selectors;

        if (selectors == nullptr)
        { return; }

        int count = 1;
        while (count < j)
        {
            selectors = selectors->next;
            // if j-th selector doesn't exist, skip the command
            if (selectors == nullptr)
                return;
            count++;
        }
        std::cout << command << " == " << selectors->data << "\n";
    }
    // i,A,?
    else if (isNumber(args[0]) && args[1] == "A" && args[2] == "?")
    {
        char* temp = args[0].cstr();
        int index = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        // reference to i-th block's selectors list
        auto block = GetNthSection(index, chain_start);

        if (block == nullptr)
            return;
        auto attributes = block->attributes;

        if (attributes == nullptr)
        {
            std::cout << command << " == " << "0\n";
            return;
        }
        int count = 1;
        while (attributes->next != nullptr)
        {
            attributes = attributes->next;
            count++;
        }
        std::cout << command << " == " << count << "\n";
    }
    // n,A,?
    else if (args[1] == "A" && args[2] == "?")
    {
        int count = 0;
        auto node = chain_start;
        do
        {
            for (int i = 0; i < T; i++)
            {
                if (node->occupied[i] == false)
                    break;
                auto attributes = node->sections[i].attributes;
                while (attributes != nullptr)
                {
                    if (attributes->data.name == args[0])
                    {
                        count++;
                        break;
                    }
                    attributes = attributes->next;
                }
            }

        } while (node->next != chain_start);

        std::cout << command << " == " << count << "\n";
    }
    // i,A,n
    else if (isNumber(args[0]) && args[1] == "A")
    {
        char* temp = args[0].cstr();
        int index = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        // reference to i-th block's selectors list
        auto block = GetNthSection(index, chain_start);

        if (block == nullptr)
            return;
        auto attributes = block->attributes;

        if (attributes == nullptr)
        { return; }
        
        while (!(attributes->data.name == args[2]))
        {
            attributes = attributes->next;
            if (attributes == nullptr)
                return;
        }
        std::cout << command << " == " << attributes->data.value << "\n";
    }
    // i,D,*
    else if (args[1] == "D" && args[2] == "*")
    {
        char* temp = args[0].cstr();
        int index = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        auto node = chain_start;
        while (index > node->count_occupied)
        {
            // if i-th section doesn't exist, skip the command
            if (node->next == chain_start)
                return;
            index -= node->count_occupied;
            node = node->next;
        }

        node->Delete(index-1);
        std::cout << command << " == deleted\n";
    }
    // i,D,n
    else if (args[1] == "D")
    {
        char* temp = args[0].cstr();
        int index = std::atoi(temp);
        // cstr returns a dynamically allocated char array
        delete[] temp;

        auto node = chain_start;
        while (index > node->count_occupied)
        {
            // if i-th section doesn't exist, skip the command
            if (node->next == chain_start)
                return;
            index -= node->count_occupied;
            node = node->next;
        }

        auto attributes = node->sections[index - 1].attributes;
        // check first attribute
        if (attributes->data.name == args[2])
        {
            // if this is the only attribute, delete the entire section
            if (attributes->next == nullptr) {
                node->Delete(index - 1);
            }
            else
            { 
                // change the pointer in the section to next in the list before deleting the attribute
                node->sections[index - 1].attributes = attributes->next;
                delete attributes;
            }
            std::cout << command << " == deleted\n";
        }
        else
        {
            int att_index = 1;
            while (attributes->next != nullptr && !(attributes->next->data.name == args[2]))
            {
                attributes = attributes->next;
                att_index++;
            }
            if (attributes->next == nullptr)
                return;
            DeleteSllNode(node->sections[index - 1].attributes, att_index);
            std::cout << command << " == deleted\n";
        }
    }
}

/*
TODO:

    - ExecuteCommand()

    - string::operator+ creates many temporary copies which may slow down the program significantly
*/

int main()
{
/*
    while end of file not reached
        get sections until '?'
        get commands until '*'
*/
    CssContainerNode* chain_start = CssContainerNode::getStart();
    // FIXME there may be redundant checks for EOF
    while (!std::cin.eof()) 
    {
        string block;
        while (std::cin.peek() != '?')
        {
            // get the whole block
            block.getline(std::cin, "}");
            block += "}";

            // push back the block into the chain
            chain_start->prev->Add(block);

            // ignore '}'
            std::cin.ignore(1);
            IgnoreChars(" \n\t");
        }
        
        if (!std::cin.eof()) {
            // ignore "????"
            std::cin.ignore(4);
            IgnoreChars(" \n\t");
        }
        else break;

        while (!std::cin.eof() && std::cin.peek() != '*')
        {
            string command;
            // get the command
            command.getline(std::cin, " \n\t");
            IgnoreChars(" \n\t");

            ExecuteCommand(command, chain_start);
        }
        if (!std::cin.eof()) {
            // ignore "****"
            std::cin.ignore(4);
            IgnoreChars(" \n\t");
        }
        else break;
    }
}
