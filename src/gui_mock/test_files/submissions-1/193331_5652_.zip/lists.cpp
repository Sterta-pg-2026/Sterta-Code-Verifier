#include "lists.h"

template <typename _T>
void SllNode<_T>::PushBack(_T& new_data)
{
    if (!data_initialized) {
        data = new_data;
        tail = this;
        data_initialized = true;
        return;
    }

    tail->next = new SllNode<_T>(new_data);
    tail = tail->next;
}

template <typename _T>
SllNode<_T>::~SllNode() {
    // FIXME this requires a rework

}

template <typename _T>
void DeleteSllNode(SllNode<_T>*& head, int index) {
    auto temp = head;
    if (index == 0) {
        head = head->next;
        delete temp;
    }

    for (int i = 0; i < index-1; i++)
    {
        temp = temp->next;
    }

    SllNode<_T>* temp_next_after_delete = temp->next->next;
    delete temp->next;
    temp->next = temp_next_after_delete;
}

CssSection::CssSection(string& block)
{
    selectors = new SllNode<string>();
    attributes = new SllNode<Attribute>();

    string temp;
    Attribute att;
    int start = 0;
    int end = 0;

    // extract the selectors and push them into the 'selectors' list
    while (block[start] != '{')
    {
        // find the end of the selector
        while (!CstrContains(block[end], "\t\n{,"))
        {
            end++;
        }

        // extract the selector
        temp = block.Substr(start, end - start);

        // check if the selector contains ' ' at the end
        if (temp.Last() == ' ')
            temp.PopBack();

        // push the selector into the list
        selectors->PushBack(temp);

        start = end;

        // skip to the first good character or '{'
        while (CstrContains(block[start], "\t\n, "))
        {
            start++;
        }
        end = start;
    }

    // skip to the first attribute
    while (CstrContains(block[start], " {\t\n")) {
        start++;
    }
    end = start;

    // extract the attributes and push them into the 'attributes' list
    while (block[start] != '}')
    {
        // find the end of the attribute's name
        while (block[end] != ':')
        {
            end++;
        }

        // extract the attribute's name
        att.name = block.Substr(start, end - start);

        start = end;

        // skip to the first good character
        while (CstrContains(block[start], ":\t\n "))
        {
            start++;
        }
        end = start;

        // find the end of the attribute's value
        while (block[end] != ';')
        {
            end++;
        }

        // extract the attribute's value
        att.value = block.Substr(start, end - start);
        attributes->PushBack(att);

        start = end;

        // skip to the first good character
        while (CstrContains(block[start], ";\t\n "))
        {
            start++;
        }
        end = start;
    }
    
    // remove duplicates
    if (selectors != nullptr)
    {
        // iterate over the entire list, for every node check all the nodes down the list for the first duplicate and delete the original node
        int i = 0;
        bool duplicate_found;
        bool complete = false;
        while (true)
        {
            duplicate_found = false;

            // pointer to the first instance of the attribute name
            auto first_instance = selectors;
            for (int it = 0; it < i; it++)
            {
                // if the end of the list is reached before the loop finishes, exit the outer loop
                if (first_instance->next == nullptr)
                {
                    complete = true;
                    break;
                }
                first_instance = first_instance->next;
            }
            if (complete)
                break;


            auto list_iter = first_instance->next;
            const string& name = first_instance->data;

            // iterate over the list in search of a duplicate
            while (list_iter != nullptr)
            {
                if (list_iter->data == name)
                {
                    // delete the first instance
                    DeleteSllNode<string>(selectors, i);
                    duplicate_found = true;
                    break;
                }
                list_iter = list_iter->next;
            }

            if (!duplicate_found)
            {
                i++;
            }
        }
    }

    if (attributes != nullptr)
    {
        // iterate over the entire list, for every node check all the nodes down the list for the first duplicate and delete the original node
        int i = 0;
        bool duplicate_found;
        bool complete = false;
        while (true)
        {
            duplicate_found = false;

            // pointer to the first instance of the attribute name
            auto first_instance = attributes;
            for (int it = 0; it < i; it++)
            {
                // if the end of the list is reached before the loop finishes, exit the outer loop
                if (first_instance->next == nullptr)
                {
                    complete = true;
                    break;
                }
                first_instance = first_instance->next;
            }
            if (complete)
                break;


            auto list_iter = first_instance->next;
            const string& name = first_instance->data.name;

            // iterate over the list in search of a duplicate
            while (list_iter != nullptr)
            {
                if (list_iter->data.name == name)
                {
                    // delete the first instance
                    DeleteSllNode<Attribute>(attributes, i);
                    duplicate_found = true;
                    break;
                }
                list_iter = list_iter->next;
            }

            if (!duplicate_found)
            {
                i++;
            }
        }
    }
}

void CssSection::MoveFrom(CssSection& other)
{
    selectors = other.selectors;
    other.selectors = nullptr;

    attributes = other.attributes;
    other.attributes = nullptr;
}

CssContainerNode::CssContainerNode(CssContainerNode* chain) {
    if (chain == nullptr) {
        prev = this;
        next = this;

        return;
    }

    this->next = chain->next;
    this->prev = chain;

    chain->next = this;
    this->next->prev = this;
}

void CssContainerNode::Add(string& block)
{
    // check if there's space available in this node
    if (count_occupied >= T) {
        // check the next node
        // FIXME this condition shouldn't ever be met in the current design of the parser, for now I leave it here just in case
        if (next != chain_start) {
            next->Add(block);
        }
        // or create a new node
        else {
            CssContainerNode new_node(this);
            new_node.Add(block);
        }
        return;
    }
    if (count_occupied == 0) {
        sections[0] = CssSection(block);
        count_occupied++;
        occupied[0] = true;
        return;
    }

    for (int i = 0; i < T; i++) {
        if (occupied[i] == false) {
            sections[i] = CssSection(block);
            count_occupied++;
            occupied[i] = true;
            break;
        }
    }
}

void CssContainerNode::Delete(int n)
{
    delete sections[n].selectors;
    delete sections[n].attributes;

    // move the CSS blocks one index back
    for (int i = n; i < T - 1; i++)
    {
        if (occupied[i + 1] == false)
        {
            occupied[i] = false;
            count_occupied--;
            break;
        }
        sections[i].MoveFrom(sections[i + 1]);
    }
    if (occupied[T - 1] == true) {
        occupied[T - 1] = false;
        count_occupied--;
    }

    // delete this node if it's empty
    if (count_occupied == 0) {
        if (this == chain_start) {
            chain_start = next;
        }
        prev->next = this->next;
        next->prev = this->prev;
        delete this;
    }
}

CssSection* GetNthSection(int n, CssContainerNode* chain_start)
{
    // find the node containing n-th CSS block
    auto node = chain_start;
    while (node->count_occupied < n)
    {
        n -= node->count_occupied;
        // if n-th block doesn't exist, return nullptr
        if (node->next == chain_start)
            return nullptr;
        node = node->next;
    }

    // find the CSS block
    int count = 0;
    int i = 0;
    for (; i < T; i++)
    {
        if (node->occupied[i] == false)
            continue;

        count++;
        if (count == n)
            break;
    }

    return &(node->sections[i]);
}


CssContainerNode* CssContainerNode::chain_start = new CssContainerNode(nullptr);
CssContainerNode*& CssContainerNode::getStart() { return chain_start; }
