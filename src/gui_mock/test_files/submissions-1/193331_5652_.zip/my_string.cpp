#include "my_string.h"

bool CstrContains(char c, const char* str)
{
    for (int i = 0; str[i] != '\0'; i++)
    {
        if (c == str[i])
            return true;
    }
    return false;
}

void string::CalculateMaxLength()
{
    while (max_length < length) {
        max_length *= 2;
    }
    while (max_length >= 2 * length) {
        max_length /= 2;
    }
}

void string::ReallocateBuffer()
{
    char* temp = new char[max_length];
    strcpy_s(temp, length * sizeof(char), buffer);
    delete[] buffer;
    buffer = temp;
}

void string::CalculateAndReallocate()
{
    int before = max_length;
    CalculateMaxLength();
    if (before != max_length)
        ReallocateBuffer();
}

string::string()
    : length(1), max_length(1)
{
    buffer = new char[max_length];
    buffer[0] = '\0';
}
string::string(const char* str)
{
    length = strlen(str) + 1; // +1 for null termination char

    max_length = 1;

    CalculateMaxLength();

    buffer = new char[max_length];

    strcpy_s(buffer, length * sizeof(char), str);
}
string::string(const string& str)
{
    length = str.length;
    max_length = str.max_length;
    buffer = new char[max_length];
    strcpy_s(buffer, length * sizeof(char), str.buffer);
}

int string::getLength() { return length; }

string string::Substr(int offset, int length)
{
    string temp;
    temp.length = length + 1;
    temp.CalculateAndReallocate();
    strncpy_s(temp.buffer, temp.length, this->buffer + offset, length);
    temp[length] = '\0';
    return temp;
}

void string::PopBack()
{
    length--;
    buffer[length - 1] = '\0';
    CalculateAndReallocate();
}

char string::Last()
{
    return buffer[length - 2];
}

void string::getline(std::istream& in, const char* delims)
{
    int i = 0;
    length = 1;
    buffer[length - 1] = '\0';
    CalculateAndReallocate();

    while (!std::cin.eof() && !CstrContains(in.peek(), delims))
    {
        length++;
        // resize the buffer if needed to fit the next character
        CalculateAndReallocate();
        buffer[i] = in.get();
        i++;
        buffer[length - 1] = '\0';
    }
}

string string::operator+(string& other)
{
    string copy(*this);
    *this += other;
    string result(*this);
    *this = copy;

    return result;
}

string& string::operator+=(string other)
{
    int original_length = length;
    length += other.length - 1; // -1 to prevent counting this' null termination char

    CalculateAndReallocate();

    // -1 in the destination is used to overwrite the previous null termination char
    // null termination char is copied from 'other' and doesn't need to be assigned again to 'this->buffer'
    strncpy_s(this->buffer + original_length - 1, other.length, other.buffer, other.length);

    return *this;
}

void string::operator=(string other)
{
    delete[] buffer;
    this->length = other.length;
    this->max_length = other.max_length;
    buffer = new char[max_length];
    strcpy_s(buffer, length * sizeof(char), other.buffer);
}

bool string::operator==(string other)
{
    if (length != other.length)
        return false;
    for (int i = 0; i < length - 1; i++) {
        if (buffer[i] != other[i])
            return false;
    }
    return true;
}

char* string::cstr()
{
    char* temp = new char[length];
    strcpy_s(temp, length, buffer);
    return temp;
}

char& string::operator[](int i) { return buffer[i]; }

string::~string() {
    delete[] buffer;
    buffer = nullptr;
}

std::ostream& operator<<(std::ostream& out, const string& str)
{
    for (int i = 0; i < str.length - 1; i++) {
        out << str.buffer[i];
    }
    return out;
}
