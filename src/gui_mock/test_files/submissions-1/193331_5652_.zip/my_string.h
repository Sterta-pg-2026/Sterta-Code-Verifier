#pragma once
#include <iostream>
#include <string.h>

// checks if 'str' contains 'c'
bool CstrContains(char c, const char* str);

struct string
{
private:
    char* buffer;
    int length; // length takes into account the null termination character
    int max_length;

    void CalculateMaxLength();

    void ReallocateBuffer();

    void CalculateAndReallocate();

public:
    string();
    string(const char* str);
    string(const string& str);

    int getLength();

    string Substr(int offset, int length);

    void PopBack();
    char Last();

    friend std::ostream& operator<<(std::ostream& out, const string& str);

    void getline(std::istream& in, const char* delims);

    string operator+(string& other);
    string& operator+=(string other);
    void operator=(string other);
    bool operator==(string other);

    char* cstr();

    char& operator[](int i);

    ~string();
};

std::ostream& operator<<(std::ostream& out, const string& str);