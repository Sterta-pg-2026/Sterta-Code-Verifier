#pragma once
#include "my_string.h"

constexpr int T = 8;

struct Attribute {
    string name;
    string value;

    Attribute() {}
    Attribute(const Attribute& other)
        : name(other.name), value(other.value) {}
};

// single-linked list node
template <typename _T>
struct SllNode {
    _T data;
    SllNode* next = nullptr;

    bool data_initialized;
    SllNode* tail;

    SllNode() : data_initialized(false), tail(nullptr) {}
    SllNode(_T& data) : data(data), data_initialized(true), tail(this) {}

    void PushBack(_T& new_data);

    ~SllNode();
};

template <typename _T>
void DeleteSllNode(SllNode<_T>*& head, int index);

struct CssSection {
    SllNode<string>* selectors = nullptr;
    SllNode<Attribute>* attributes = nullptr;

    CssSection() {}
    CssSection(string& block);

    void MoveFrom(CssSection& other);
};

class CssContainerNode {
public:
    CssSection sections[T];
    CssContainerNode* prev;
    CssContainerNode* next;
    bool occupied[T] = { false };
    // counts currently occupied sections
    int count_occupied = 0;

private:
    static CssContainerNode* chain_start; // this variable is necessary to determine the order of the sections

public:
    // returns a reference to a pointer to the node containing the first CSS section
    static CssContainerNode*& getStart();

    // ctor appends a new node between 'chain' and 'chain->next'
    // if there is no chain, pass a nullptr
    //
    // ... - [chain->prev] - [chain] -    - [chain->next] - ...
    //                                 /\
    //                                 ||
    //                               [this]
    //
    CssContainerNode(CssContainerNode* chain);

    void Add(string& block);

    void Delete(int n);
};

CssSection* GetNthSection(int n, CssContainerNode* chain_start);
