#pragma once
#include <iostream>
#include "defines.h"
#include "section.h"
using namespace std;


class Node {
public:
    int spaces;

    Node* next; 
    Node* previous;
    section sectionarr[T];
    Node() {
        spaces = 0;
        next = nullptr;
        previous = nullptr;
    }
};


class Mainlist {
    Node* head;
public:
    // Constructor
    Mainlist() {
        head = nullptr;
    }

    // Destructor
    ~Mainlist() {
        Node* current = head;
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
    }
    

    void addingselectortotheblock(char*newerselector) {
       
        Node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->sectionarr[current->spaces - 1].selectorlist.add(newerselector);


    }
   

    
    void addingblock(section& block) {
        if (head == nullptr) {
            head = new Node;
            head->sectionarr[head->spaces] = block;
            head->spaces++;
            return;
        }

        Node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }

        if (current->spaces == T) {
            Node* newNode = new Node;
            newNode->previous = current;
            current->next = newNode;
            newNode->sectionarr[newNode->spaces] = block;
            newNode->spaces++;
        }
        else {
           
            current->sectionarr[current->spaces] = block;
            current->spaces++;
        }
    }
    
    int chooseblockforsel(int intValue) {
        Node* temp = head;
        int onwhichblock=0;
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head!=nullptr) {
                    onwhichblock++;
                }
                if (onwhichblock == intValue) {
                    return temp->sectionarr[k].selectorlist.getCount();
                }
               
            }
            temp = temp->next;
        }
        return 0;
    }


    int chooseblockforatt(int intValue) {
        Node* temp = head;
        int onwhichblock = 0;
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    onwhichblock++;
                }
                if (onwhichblock == intValue) {
                    return temp->sectionarr[k].attributelist.getCountofAtt();
                }

            }
            temp = temp->next;
        }
        return 0;
    }

    char* nameofthesel(int i, int j) {
        char* error = new char[5];
        strcpy(error, "SKIP");
        Node* temp = head;
        int onwhichblock = 0;
        if (temp == nullptr) {
            return error;
        }
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    onwhichblock++;
                }
                if (onwhichblock == i) {
                    delete[] error;
                    return temp->sectionarr[k].selectorlist.theJthsel(j);
                }

            }
            temp = temp->next;
        }
        return error;
    }

    char* searchingattr(int i, char* name) {
        char* error = new char[5];
        strcpy(error, "SKIP");
        Node* temp = head;
        int onwhichblock = 0;
        if (temp == nullptr) {
            return error;
        }
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    onwhichblock++;
                }
                if (onwhichblock == i) {
                    delete[] error;
                    return temp->sectionarr[k].attributelist.thevaluesearched(name);
                }

            }
            temp = temp->next;
        }
        return error;
    }

    int numofoccurattinallsecs(char* name) {
        Node* temp = head;
        int counter=0;
        if (temp == nullptr) {
            return 0;
        }
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    if (temp->sectionarr[k].attributelist.foundattr(name) == true) {
                        counter++;
                    }
                }
            }
            temp = temp->next;

        }return counter;
    }

    int numofoccurselinallsecs(char* name) {
        Node* temp = head;
        int counter = 0;
        if (temp == nullptr) {
            return 0;
        }
        while (temp != nullptr) {
            for (int k = 0; k < T; k++) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    if (temp->sectionarr[k].selectorlist.foundsel(name) == true) {
                        counter++;
                    }
                }
            }
            temp = temp->next;

        }return counter;
    }

    char* valueforattrforsel(char* attribute_name,char*selector ) {
        char* error = new char[5];
        strcpy(error, "SKIP");
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        while (temp != nullptr) {
            for (int k = T - 1; k >= 0; k--) {
                if (temp->sectionarr[k].attributelist.head != nullptr) {
                    if (temp->sectionarr[k].selectorlist.foundsel(selector) == true) {
                        delete[] error;
                        return temp->sectionarr[k].attributelist.thevaluesearched(attribute_name);
                    }
                }
            }
            temp = temp->previous;
        }

        return error;
    }
};