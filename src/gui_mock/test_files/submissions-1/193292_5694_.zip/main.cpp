#include <iostream>
#include <string.h>
#include "selectors.h"
#include "attributes.h"
#include "defines.h"
#include "section.h"
#include "mainlist.h"
using namespace std;

void deletespaces(char* input_text) {
	int g = 0;
	int j = 0;
	for (int i = 0; isspace(input_text[i]); i++) {
			g++;

	}
	if (g != 0) {
		for (j; input_text[j+g] != '\0'; j++) {
			input_text[j] = input_text[j+g];
		}
		input_text[j] = '\0';
	}
	for (int i = strlen(input_text)-1; isspace(input_text[i]); i--) {
		input_text[i] = '\0';
	}
}

char* leftattribute(char* fullattr) {
	
	char* attr1=new char[308];
	int i = 0;
	for (i; fullattr[i] != ':'; i++) {
		attr1[i] = fullattr[i];
	}
	attr1[i] = '\0';
	return attr1;
	
}
char* rightattribute(char* fullattr) {

	int size = strlen(fullattr);
	char* attr2=new char[308];
	char helpattr;
	int i = size-1;
	int j = 0;
	for (i; fullattr[i] != ':'; i--) {
			attr2[j] = fullattr[i];
			j++;
	}
	attr2[j] = '\0';
	j--;
	size = strlen(attr2);
	for (i = 0; i<size/2; i++) {
		helpattr = attr2[i];
		attr2[i] = attr2[j];
		attr2[j] = helpattr;
		j--;
	}
	
	return attr2;

}

int charArrayToInt(char* charArray) {
	int intValue = 0;
	for (int i = 0; charArray[i] != '\0'; i++) {
		if (charArray[i] < '0' || charArray[i] > '9') {
			// Handle non-digit character
			return 0;
		}
		int digitValue = charArray[i] - '0';
		intValue = intValue * 10 + digitValue;
	}
	return intValue;
}

int countLettersleft(char arr[]) {
	int count = 0;
	for (int i = 0; arr[i] != ','; i++) {
		count++;
		if (count > 30) {
			return 0;
		}
	}
	if (count > 0 && count <= 30) {
		return count;
	}
	else return 0;
	
}


char* breakapartleft(char* input_text) {
	
	int count = countLettersleft(input_text);
	char* leftside = new char[count + 1];
	for (int i = 0; i < count; i++) {
		leftside[i] = input_text[i];
	}
	leftside[count] = '\0';
	return leftside;
	

}

char breakapartmiddle(char* input_text) {
	int i = 0;
	while (input_text[i]!=',') {
		i++;

	}
	return input_text[i + 1];

}

char* breakapartright(char* input_text) {

	int count = 0;
	int fullength = strlen(input_text);

	for (int i = fullength - 1; input_text[i] != ','; i--) {
		count++;
	}
	char* rightside = new char[count + 1];
	int j = 0;
	for (int i = fullength-count; i<fullength; i++) {
		rightside[j] = input_text[i];
		j++;
	}
	rightside[j] = '\0';
	return rightside;
}

char isanumber(char* examinedpart) {
	int i = 0;
	int lettercounter = 0;
	int numbercounter = 0;
	while (examinedpart[i] != '\0') {
		if ((examinedpart[i] >= '0' && examinedpart[i] <= '9')) {
			numbercounter++;
		}
		else {
			lettercounter++;
		}
		i++;
	}
	if (numbercounter > 0 && lettercounter == 0) {
		return 'n'; // if there are only numbers, return 'n'
	}
	else {
		return 'l'; // if there are only letters, return 'l'
	}
	
}
void resetthej(int& j) {
	j = 0;
}

void commandone(char*leftside,Mainlist&mainlist,int&j) {
	int intValue = charArrayToInt(leftside);
	if (mainlist.chooseblockforsel(intValue) > 0) {
		cout << intValue << ",S,? == " << mainlist.chooseblockforsel(intValue) << endl;
	}
	resetthej(j);
	
}
void commandtwo(char* leftside, Mainlist& mainlist,int&j) {
	int intValue = charArrayToInt(leftside);
	if (mainlist.chooseblockforatt(intValue) > 0) {
		cout << intValue << ",A,? == " << mainlist.chooseblockforatt(intValue) << endl;
	}
	resetthej(j);
}
void commandthree(char*leftside,char*rightside,Mainlist&mainlist,int&j) {
	int leftint = charArrayToInt(leftside);
	int rightint = charArrayToInt(rightside);
	if (strcmp(mainlist.nameofthesel(leftint, rightint), "SKIP") != 0) {
		cout << leftint << ",S," << rightint << " == " << mainlist.nameofthesel(leftint, rightint) << endl;
	}
	resetthej(j);
}
void commandfour(char* leftside, Mainlist& mainlist, char* rightside,int&j ) {
	int leftint = charArrayToInt(leftside);
	if (strcmp(mainlist.searchingattr(leftint, rightside), "SKIP") != 0) {
		cout << leftint << ",A," << rightside << " == " << mainlist.searchingattr(leftint, rightside) << endl;
	}
	resetthej(j);
}
void commandfive(char* leftside, Mainlist& mainlist, int& j) {
	cout << leftside << ",A,? == " << mainlist.numofoccurattinallsecs(leftside) << endl;
	resetthej(j);
}
void commandsix(char* leftside, Mainlist& mainlist, int& j) {
	cout << leftside << ",S,? == " << mainlist.numofoccurselinallsecs(leftside) << endl;
	resetthej(j);
}
void commandseven(Mainlist& mainlist, char* leftside, char* rightside, int& j) {
	if (strcmp(mainlist.valueforattrforsel(rightside, leftside), "SKIP") != 0) {
		cout << leftside << ",E," << rightside << " == " << mainlist.valueforattrforsel(rightside, leftside) << endl;
	}
	resetthej(j);
}

int main() {

	char input_text[200];
	int j = 0;
	int gearshift = 0;
	Mainlist mainlist;
	int commandgearshift = 0;
	int howmanysections = 0;

	section* Block = new section;

	while (1) {
		
		if ((input_text[j] = getchar()) == EOF) {
			break;
		}
			
		if ((isspace(input_text[j])&&input_text[j]!=' ') && commandgearshift == 0 && input_text[j - 1] != '?') {
			j--;
		}
		else if (commandgearshift == 1 && (isspace(input_text[j]) && input_text[j] != ' ' && input_text[j] != '\n')) {
			j--;

		}
		j++;
		input_text[j] = '\0';
		

		for (int i = 0; input_text[i] != '\0'; i++) {

			if (commandgearshift == 0) {

					if (gearshift == 0) {
							if (input_text[i] == ',') {

								input_text[i] = '\0';
								deletespaces(input_text);
								Block->selectorlist.add(input_text);
								resetthej(j);
							}
							else if (input_text[i] == '{') {
							input_text[i] = '\0';
							if (input_text[0] != '\0') {
								deletespaces(input_text);
								if (input_text[0] != '\0') {
									Block->selectorlist.add(input_text);
								}
							}
							
							resetthej(j);

							gearshift = 1;
							howmanysections++;
							}
					}
					else if (input_text[i] == ';') {
					char* attrname;
					char* attrvalue;
					input_text[i] = '\0';

					attrname = leftattribute(input_text);
					deletespaces(attrname);
					attrvalue = rightattribute(input_text);
					deletespaces(attrvalue);
					Block->attributelist.add(attrname, attrvalue);
					delete[] attrname;
					delete[] attrvalue;
					resetthej(j);
					}
					
					else if (input_text[i] == '}') {
						char* attrname;
						char* attrvalue;
						input_text[i] = '\0';
						if (input_text[0] != '\0') {
							deletespaces(input_text); 
							if (input_text[0] != '\0') {
								
								attrname = leftattribute(input_text);
								deletespaces(attrname);
								attrvalue = rightattribute(input_text);
								deletespaces(attrvalue);
								Block->attributelist.add(attrname, attrvalue);
							}
						}
					gearshift = 0;
					mainlist.addingblock(*Block);
					Block = new section;
					resetthej(j);

					}


				if (input_text[i] == '\n') {
					input_text[i] = '\0';
						if (strcmp(input_text,"????")==0) {
							input_text[0] = '\0';
							commandgearshift = 1;
							resetthej(j);
					
							continue;
						}
				}
			}
			if (commandgearshift == 1) {

				if (input_text[i] == '\n') {
					input_text[i] = '\0';
					
					if (strcmp(input_text, "?")==0) {
						cout << "? == " << howmanysections << endl;
						resetthej(j);
						break;
					}
					if (strcmp(input_text, "****")==0) {
						commandgearshift = 0;
						input_text[i + 1] = '\0';
						resetthej(j);
						break;
					}

					if (countLettersleft(input_text) != 0) {

						char leftside[64];
						strcpy(leftside, breakapartleft(input_text));
						char rightside[64];
						strcpy(rightside, breakapartright(input_text));
						char middleletter;
						middleletter = breakapartmiddle(input_text);

						//command 1
						if (isanumber(leftside) == 'n' && middleletter == 'S' && strcmp(rightside, "?") == 0) {

							commandone(leftside,mainlist,j);
						}
						
						//command 2
						else if (isanumber(leftside) == 'n' && middleletter == 'A' && strcmp(rightside, "?") == 0) {

							commandtwo(leftside,mainlist,j);
						}
						//comand 3
						else if (isanumber(leftside) == 'n' && middleletter == 'S' && isanumber(rightside) == 'n') {

							commandthree(leftside,rightside,mainlist,j);
						}

						//command 4
						else if (isanumber(leftside) == 'n' && middleletter == 'A' && isanumber(rightside) == 'l') {

							commandfour(leftside,mainlist,rightside,j);
						}
						//command 5
						else if (isanumber(leftside) == 'l' && middleletter == 'A' && strcmp(rightside, "?") == 0) {
							
							commandfive(leftside,mainlist,j);
						}
						//command 6
						else if (isanumber(leftside) == 'l' && middleletter == 'S' && strcmp(rightside, "?") == 0) {
							
							commandsix(leftside,mainlist,j);	
						}
						//command 7
						else if (isanumber(leftside) == 'l' && middleletter == 'E' && isanumber(rightside) == 'l') {
							
							commandseven(mainlist,leftside,rightside,j);
							
						}
						//command 8
						else if (isanumber(leftside) == 'n' && middleletter == 'D' && isanumber(rightside) != 'l') {
							resetthej(j);
							
						}
						//command 9
						else if (isanumber(leftside) == 'n' && middleletter == 'D' && isanumber(rightside) == 'l') {
							resetthej(j);
							
						}
						resetthej(j);
					}
				}
			}
		}
	}	
	return 0;
}