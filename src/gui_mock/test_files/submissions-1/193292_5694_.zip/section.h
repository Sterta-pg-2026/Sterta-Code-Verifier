#pragma once
#include "attributes.h"
#include "selectors.h"
class section
{
public:
	Attributes attributelist;
	Selectors selectorlist;

};

