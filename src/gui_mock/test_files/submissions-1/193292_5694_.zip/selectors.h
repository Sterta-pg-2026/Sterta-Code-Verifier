#pragma once
#include <string.h>
class Selectors {

public:
    Selectors() : head(nullptr), count(0) {}
    ~Selectors();
    void add(char* data);
    void print();
    int getCount();
    char* theJthsel(int j);
    bool foundsel(char* name);
    struct Node {
        char* selname;
        Node* next;
        Node(char* data) : next(nullptr) {
            int length = 0;
            while (data[length] != '\0') {
                ++length;
            }
            this->selname = new char[length + 1];
            for (int i = 0; i < length; ++i) {
                this->selname[i] = data[i];
            }
            this->selname[length] = '\0';
        }
        ~Node() { delete[] selname; }
    };
    Node* head;
    int count;

};