#include "selectors.h"
#include <iostream>
using namespace std;

Selectors::~Selectors() {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
        count--;
    }
}

void Selectors::add(char* selname) {
    Node* new_node = new Node(selname);
    if (head == nullptr) {
        head = new_node;
    }
    else {
        Node* curr_node = head;
        while (curr_node->next != nullptr) {
            curr_node = curr_node->next;
        }
        curr_node->next = new_node;
    }
    count++;
}

void Selectors::print() {
    Node* curr_node = head;
    while (curr_node != nullptr) {
        cout << curr_node->selname << endl;
        curr_node = curr_node->next;
    }
    cout << endl;
}

int Selectors::getCount() {
    int count_i = 0;
    Node* curr_node = head;
    while (curr_node != nullptr) {
        count_i++;
        curr_node = curr_node->next;
    }
    return count_i;
}
char* Selectors::theJthsel(int j) {
    int count = 0;
    char* error = new char[5];
    strcpy(error, "SKIP");
    Node* curr_node = head;
    while (curr_node != nullptr) {
        count++;
        if (count == j) {
            break;
        }
        curr_node = curr_node->next;
    }
    if (curr_node == nullptr) {
        return error;
    }
    delete[] error;
    return curr_node->selname;
}

bool Selectors::foundsel(char* name) {
    Node* curr_node = head;
    while (curr_node != nullptr) {
        if (strcmp(curr_node->selname, name) == 0) {
            return true;
        }
        curr_node = curr_node->next;
    }
    return false;
}

