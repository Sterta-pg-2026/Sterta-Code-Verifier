#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS
class Attributes {
public:

    struct Node {
        char* name;
        char* value;
        Node* next;
        Node(char* left, char* right) : next(nullptr) {
            int size;
            size = strlen(left);
            name = new char[size + 1];
            strcpy(name, left);

            size = strlen(right);
            value = new char[size + 1];
            strcpy(value, right);

        }
        ~Node() { 
         delete[] name;
        delete[] value; 
        }
    };
    Node* head;
    Attributes() : head(nullptr) {}
    ~Attributes();
    void add(char* name,char*value);
   /* void print();*/
    int getCountofAtt();
    char* thevaluesearched(char* name);
    bool foundattr(char* name);
   
};