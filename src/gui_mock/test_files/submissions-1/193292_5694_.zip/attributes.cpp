#include "attributes.h"

#include <iostream>

Attributes::~Attributes() {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void Attributes::add(char* name,char*value) {
    Node* new_node = new Node(name,value);
    if (head == nullptr) {
        head = new_node;
    }
    else {
        Node* curr_node = head;
        while (curr_node->next != nullptr) {
            if (strcmp(curr_node->name, name) == 0) {
               
                strcpy(curr_node->value, value);
                return;
            }
            curr_node = curr_node->next;
        }
        if (strcmp(curr_node->name, name) == 0) {

            strcpy(curr_node->value, value);
            return;
        }
        curr_node->next = new_node;
    }
}

int Attributes::getCountofAtt() {
    int count_i = 0;
    Node* curr_node = head;
    while (curr_node != nullptr) {
        count_i++;
        curr_node = curr_node->next;
    }
    return count_i;
}

char* Attributes::thevaluesearched(char* name) {
    char* error = new char[5];
    strcpy(error, "SKIP");
    Node* curr_node = head;
    while (curr_node != nullptr) {
        if (strcmp(curr_node->name, name) == 0) {
            break;
        }
        curr_node = curr_node->next;
    }
    if (curr_node == nullptr) {
        return error;
    }
    delete[] error;
    return curr_node->value;
}

bool Attributes::foundattr(char*name) {
    Node* curr_node = head;
    while (curr_node != nullptr) {
        if (strcmp(curr_node->name, name) == 0) {
            return true;
        }
        curr_node = curr_node->next;
    }
    return false;
}

