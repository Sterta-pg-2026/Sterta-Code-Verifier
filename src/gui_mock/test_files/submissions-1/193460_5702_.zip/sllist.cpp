#include "sllist.h"

SLlist::SLlist() :head(nullptr), tail(nullptr) {};

SLlist::~SLlist()
{
	//delete hole list;
	if (head != nullptr) {
		SLnode* now = this->head;
		SLnode* next = this->head->getNext();
		while (now != nullptr ) {
			delete now;
			now = next;
			if (now != nullptr)
			next = now->getNext();
		}
	}

}

void SLlist::addNode() {
	if (this->head == nullptr) {
		this->head = new SLnode;
		this->tail = this->head;
	}
	else if (this->head == this->tail) {
		this->tail = new SLnode;
		this->head->setNext(this->tail);
		
	}
	else {
		SLnode* tmp = new SLnode;
		this->tail->setNext(tmp);
		this->tail = tmp;
		tmp = nullptr;
	}
}

void SLlist::saveName(MyString& other) {
	other.clearWhiteSpace();
	if (other.compare("") != 1) {
		if (other.getString() != nullptr) {
			checkForDuplication(other);
			if (this->tail == nullptr) {
				this->addNode();
				this->tail->setName(other);
			}
			else if (this->tail->getName().compare("")) {
				this->tail->setName(other);
			}
			else {
				addNode();
				this->tail->setName(other);
			}
		}
	}
};


void SLlist::saveValue(MyString& other) {
	other.clearWhiteSpace();
	if (this->tail == nullptr) {
		this->addNode();
		this->tail->setValue(other);
	}
	else if (this->tail->getValue().compare("")) {
		this->tail->setValue(other);
	}
	else {
		addNode();
		this->tail->setValue(other);
	}
};

int SLlist::lengthOfList() {
	int count = 0;
	SLnode* now = this->getHead();
	while (now != nullptr) {
		count++;
		now = now->getNext();
	}
	return count;
};

void SLlist::checkForDuplication(const MyString& other) {
	SLnode* now = this->getHead();
	while (now != nullptr) {
		if (now->getName().compare(other)) {
			this->removeNode(now);
			break;
		}
		now = now->getNext();
	}
};


//moga byc problemy;
void SLlist::removeNode(SLnode* other) {
	if (other != nullptr) {
		if (this->head == nullptr) {

		}
		else if (this->head == this->tail) {
			delete this->head;
			this->head = nullptr;
			this->tail = nullptr;
		}
		else {
			SLnode* last = nullptr, * now = this->head, * next = this->head->getNext();
			while (now != other) {
				last = now;
				now = next;
				next = next->getNext();
			}
			if (other == this->getHead()) {
				this->head = next;

			}
			else if (other == this->tail)
			{
				this->tail = last;
				this->tail->setNext(nullptr);
			}
			else {
				last->setNext(now->getNext());
			}
			delete now;
		}
	}
};

	SLnode* SLlist::findNthNode(int& n) {
		if (this->getHead() != nullptr) {
			int count = 0;
			SLnode* now = this->head;
			count++;
			while (count != n) {

				now = now->getNext();
				if (now == nullptr)
					return nullptr;
				count++;
			}
			return now;
		}
		return nullptr;
	
};

SLnode* SLlist::searchForName( MyString& other) {
	if (this->head != nullptr) {
		SLnode* now = this->head;
		while (other.compare(now->getName()) != 1) {
			now = now->getNext();
			if (now == nullptr)
				return nullptr;
		}
		return now;
	}
	return nullptr;
};

void SLlist::clearList() {
	SLnode* now = this->head, * next = nullptr;
	while (now != nullptr) {
		next = now->getNext();
		delete now;
		now = next;
	}
	this->head = nullptr;
	this->tail = nullptr;
};