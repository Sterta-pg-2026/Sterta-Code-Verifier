#include "dlnode.h"
DLnode::DLnode() :amountOfValidSections(0),last(nullptr), next(nullptr) {};


void DLnode::setCssSection(Section& other, int counter) {
	
	amountOfValidSections++;
	this->getCssSection(counter)->setIndex(counter);
	this->getCssSection(counter)->setAttributes(other);
	this->getCssSection(counter)->setSelectors(other);
};
