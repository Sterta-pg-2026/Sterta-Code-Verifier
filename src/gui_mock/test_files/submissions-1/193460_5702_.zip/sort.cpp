#include "sort.h"

void Sort::changeToSelectors() {
	this->selectors = true;
	this->attributes = false;
	this->commands = false;
};
void Sort::changeToAttributes() {
	this->selectors = false;
	this->attributes = true;
	this->commands = false;
};
void Sort::changeToCommands() {
	this->selectors = false;
	this->attributes = false;
	this->commands = true;
};

int Sort::check_letter(const char& letter) {
	static int command_count = 0;
	static int count_cycles = 0;
	switch (letter) {
	case '{':
		tmp.getSelectors().saveName(this->word);
		changeToAttributes();
		break;
	case '}':
		this->general.saveCssSection(this->tmp);
		changeToSelectors();
		break;
	case '?':
		if (this->commands == false) {
			command_count++;
			if (command_count == 4) {
				changeToCommands();
				command_count = 0;
				count_cycles = 0;
				return 0;
			}
			else {
				count_cycles++;
				if (count_cycles > command_count) {
					count_cycles = 0;
					command_count = 0;
				}
				return 0;
			}
		}
		break;
	}
	
	useProperInterpretation(letter);
	return 1;
}

void Sort::useProperInterpretation(const char &letter) {
	if (this->selectors)
		sortAsSelector(letter);
	else if (this->attributes)
		sortAsAttribute(letter);
	else if (this->commands)
		interpretAsCommand(letter);
		
}

void Sort::sortAsSelector(const char& letter) {
	if (letter == ',') {
		tmp.getSelectors().saveName(this->word);
	}
	else if (letter != '\n' && letter !='}' )
		word += letter;
};
void Sort::sortAsAttribute(const char &letter) {
	if (letter == ':') {
		tmp.getAttributes().saveName(this->word);
	}
	else if (letter == ';') {
		tmp.getAttributes().saveValue(this->word);
	} else if( letter != '\n' && letter != '{')
		word += letter;
};

void Sort::takeInput() {
	char letter = 'a';
	while (scanf_s("%c", &letter, 1) == 1) {

		
		if(letter == EOF || letter == '\n' || letter == '\t')
			check_letter(letter);
		 else if(letter - ' ' >=0)
			check_letter(letter);
	}
	check_letter(EOF);
};

void Sort::interpretAsCommand(const char &letter) {
	static bool save_as_command = false;
	static int commandCount = 0;
	if (letter == '\n' || letter == EOF) {
		runCommand();
		delete this->word.getString();
		this->word.setStringToNull();
		this->word.getLength() = 0;
		delete this->command.getString();
		this->command.setStringToNull();
 		this->command.getLength() = 0;
		save_as_command = false;
	}		
	else if (letter == '*') {
		if (save_as_command)
			this->command += letter;
		else
			this->word += letter;
	}
	else if (letter == ',') {
		if (save_as_command)
			command += letter;
		else
			save_as_command = true;
	}
	else {
		if (save_as_command)
			this->command += letter;
		else
			this->word += letter;
	}
};

void Sort::runCommand() {
	if (this->word.getString() != nullptr) {
		if (this->command.checkIfStartsWithLetter('A')) {
			if (this->command.compare("A,?") && this->word.isItNumber()) {
				A_amountOfAttributesInSection_Command(); 
			}
			else if (this->command.compare("A,?")) {
				A_occuranceOfAttributes_Command();
			}

			else if (this->command.checkIfStartsWithLetter('A')) {
				A_printValueOfAttribute_Command();
			}
		}
		else if (this->command.checkIfStartsWithLetter('S')) {
			if (this->command.checkIfStartsWithLetter('S') && this->command.checkIfLastElementIsNumber()) {
				S_searchForSelectorinSection_Command();
			}
			else if (this->command.compare("S,?") && this->word.isItNumber()) {
				S_amountOfSelectorsInSection_Command();
			}
			else if (this->command.compare("S,?")) {
				S_occuranceOfSelector_Command();
			}
		}
		else if (this->command.checkIfStartsWithLetter('E')) {
			E_findValueOfAttributeForLastSelector_Command();
		}
		else if (this->command.checkIfStartsWithLetter('D')) {
			if (this->command.compare("D,*")) {
				D_deleteSection_Command();
			}
			else if (this->command.checkIfStartsWithLetter('D')) {
				D_deleteAttribute_Command();
			}
		}
		else {
			if (this->word.compare("?"))
				std::cout << word << " == " << this->general.countValidSections() << std::endl;

			else if (this->word.compare("****")) {
				changeToSelectors();
			}
		}
	}
}








	
void Sort::S_searchForSelectorinSection_Command() {
	int num = this->word.swapToInt();
	int end_num = this->command.extractLastElement().swapToInt();
	if (general.countValidSections() >= num) {
		SLnode* tmp = general.findNthSection(num)->getSelectors().findNthNode(end_num);
		if (tmp != nullptr)
			std::cout << word << "," << command << " == " << tmp->getName() << std::endl;
	}
};

void Sort::S_amountOfSelectorsInSection_Command() {
	int num = this->word.swapToInt();
	if (general.countValidSections() >= num)
		std::cout << word << "," << command << " == " << general.findNthSection(num)->getSelectors().lengthOfList() << std::endl;

};

void Sort::S_occuranceOfSelector_Command() {
	std::cout << word << "," << command << " == " << this->general.countOccurrenceSelector(word) << std::endl;
};

void Sort::A_amountOfAttributesInSection_Command() {
	int num = this->word.swapToInt();
	if (general.countValidSections() >= num)
		std::cout << word << "," << command << " == " << general.findNthSection(num)->getAttributes().lengthOfList() << std::endl;
};

void Sort::A_occuranceOfAttributes_Command() {
	std::cout << word << "," << command << " == " << this->general.countOccurrenceAttributse(word) << std::endl;
};

void Sort::A_printValueOfAttribute_Command() {
	int num = word.swapToInt();
	MyString end = command.extractLastElement();
	SLnode* tmp = general.findNthSection(num)->getAttributes().searchForName(end);
	if (tmp != nullptr)
		std::cout << word << "," << command << " == " << tmp->getValue() << std::endl;
};

void Sort::E_findValueOfAttributeForLastSelector_Command() {
	Section* section = general.findLastSelector(&this->word);
	if (section != nullptr) {
		MyString tmp = std::move(this->command.extractLastElement());
		SLnode* condition = nullptr;
		if (section->getIndex() != -1) {
			condition = section->getAttributes().searchForName(tmp);
			while (condition == nullptr) {
				section = general.findLastSelector();
				if (section == nullptr)
					break;
				if (section->getIndex() == -1)
					break;
				condition = section->getAttributes().searchForName(tmp);
			}
			if (section != nullptr && section->getIndex() != -1)
				std::cout << word << "," << command << " == " << condition->getValue() << std::endl;
		}
	}
};
void Sort::D_deleteSection_Command() {
	int num = this->word.swapToInt();
	if (general.countValidSections() >= num) {
		general.removeNthSection(num);
		std::cout << this->word << "," << this->command << " == " << "deleted" << std::endl;
	}
};
void Sort::D_deleteAttribute_Command() {
	int num = this->word.swapToInt();
	MyString tmp = this->command.extractLastElement();
	Section* section = general.findNthSection(num);
	if (section != nullptr) {
		SLnode* remove = section->getAttributes().searchForName(tmp);
		if (remove != nullptr) {
			section->getAttributes().removeNode(remove);
			if (section->ifEmpty())
				general.removeNthSection(num);
			std::cout << this->word << "," << this->command << " == " << "deleted" << std::endl;
		}
	}
};