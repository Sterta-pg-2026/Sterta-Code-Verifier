#pragma once
#include <iostream>
#include "section.h"

class DLnode
{
private:
	int amountOfValidSections;
	Section CssSection[8];
	DLnode* last, * next;
	
public:
	DLnode() ;

	~DLnode() {};


	void setNext(DLnode* next) { this->next = next; };
	void setLast(DLnode* last) { this->last = last; };
	void setCssSection(Section& other, int counter);
	void removeValidSecion() { amountOfValidSections--; };
	DLnode* getNext() { return next; }
	DLnode* getLast() { return last; }
	Section* getCssSection(int index) { return &CssSection[index]; }
	int getAmountOfValidSections() { return amountOfValidSections; };

};

