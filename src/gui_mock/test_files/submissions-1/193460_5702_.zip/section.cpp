#include "section.h"

void Section::setIndex(int& couter) {
	this->index = couter;
};

void Section::setSelectors(Section& other) {
	this->selectors.setHead(other.selectors.getHead());
	this->selectors.setTail(other.selectors.getTail());
	other.getSelectors().setHead(nullptr);
	other.getSelectors().setTail(nullptr);
};

void Section::setAttributes(Section& other) {
	this->attributes.setHead(other.attributes.getHead());
	this->attributes.setTail(other.attributes.getTail());
	other.attributes.setHead(nullptr);
	other.attributes.setTail(nullptr);
};

void Section::removeSection() {
	this->index = -1;
	this->selectors.clearList();
	this->attributes.clearList();
};

int Section::ifEmpty() {
	if (this->attributes.getHead() == nullptr) {
		return 1;
	}
	return 0;
};