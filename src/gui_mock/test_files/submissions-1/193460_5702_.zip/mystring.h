#pragma once
#include <iostream>

class MyString
{
private:
	char* string;
	int length;

public:
	MyString();

	MyString(const char array[]);

	inline ~MyString() { delete string; };

	MyString(const MyString& other);

	MyString(MyString&& other);

	inline int& getLength() { return length; };
	inline char* getString() { return string; };
	void setStringToNull();
	friend std::ostream& operator<<(std::ostream& out, const MyString& other);
	friend std::istream& operator>>(std::istream& in, MyString& other);

	MyString operator+(MyString& other);
	MyString operator+(const char array[]);

	MyString& operator=(const MyString& other);
	MyString& operator=( MyString&& other);

	int compare(const MyString& other);
	int compare(const char array[]);

	MyString& operator+=(const MyString& other);
	MyString& operator+=(const char array[]);
	MyString& operator+=(const char &letter);
	
	
	int swapToInt();

	void clearWhiteSpace();

	int checkIfLastElementIsNumber();

	int checkIfStartsWithLetter(const char &letter);

	MyString extractLastElement();

	int isItNumber();
	
};

