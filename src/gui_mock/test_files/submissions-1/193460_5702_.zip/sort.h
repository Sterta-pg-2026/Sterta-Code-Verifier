#pragma once
#include <iostream>
#include "dllist.h"
#include "sllist.h"
#include "section.h"
#include "mystring.h"
#include "sort.h"
class Sort
{
private:
	 DLlist general;
	 Section tmp;
	 MyString word, command;
	bool selectors, attributes , commands;
public:
	Sort() :selectors(true), attributes(false), commands(false) {};

	void changeToSelectors();
	void changeToAttributes();
	void changeToCommands();

	int check_letter(const char& letter);
	
	void takeInput();

	void useProperInterpretation(const char &letter);
	void sortAsSelector(const char &letter);
	void sortAsAttribute(const char &letter);

	void interpretAsCommand(const char &letter);

	void runCommand();

	void S_searchForSelectorinSection_Command();
	void S_amountOfSelectorsInSection_Command();
	void S_occuranceOfSelector_Command();
	void A_amountOfAttributesInSection_Command();
	void A_occuranceOfAttributes_Command();
	void A_printValueOfAttribute_Command();
	void E_findValueOfAttributeForLastSelector_Command();
	void D_deleteSection_Command();
	void D_deleteAttribute_Command();
};

