#pragma once
#include <iostream>
#include "sllist.h"

class Section {
private:
	int index;
	SLlist selectors, attributes;

public:
	Section():index(-1) {};

	int& getIndex() { return index; };
	SLlist& getSelectors() { return selectors; };
	SLlist& getAttributes() { return attributes; };

	void setIndex(int& couter);
	void setSelectors(Section& other);
	void setAttributes(Section& other);

	void removeSection();

	int ifEmpty();
	
};