#include "mystring.h"


int count_Array_Length(const char array[]) {
	char letter = 'a';
	int lengthArray = -1;
	while (letter != '\0') {
		lengthArray++;
		letter = array[lengthArray];

	}
	return lengthArray;
};


MyString::MyString() :string(nullptr), length(0) {};

MyString::MyString(const char array[]) {
	int arrayLength = count_Array_Length(array);

	this->string = new char[arrayLength + 1];
	this->length = arrayLength;
	for (int i = 0; i < this->length; i++) {
		this->string[i] = array[i];
	}
	this->string[this->length] = '\0';
};

MyString::MyString(const MyString& other) {
	this->length = other.length;
	this->string = new char[length + 1];
	for (int i = 0; i < this->length; i++) {
		this->string[i] = other.string[i];
	}
	this->string[this->length] = '\0';
};

MyString::MyString(MyString&& other) {
	string = other.string;
	other.string = nullptr;
	this->length = other.length;
};

std::ostream& operator<<(std::ostream& out, const MyString& other) {
	for (int i = 0; i < other.length; i++) {
		out << other.string[i];
	}
	return out;
};

std::istream& operator>>(std::istream& in, MyString& other) {
	char buffer[256] = "\0";
	in >> buffer;
	int length = 0;
	char letter = 'a';
	while (letter != '\0') {
		letter = buffer[length];
		length++;
	}
	other.length = length;
	delete other.string;
	other.string = new char[length + 1];
	for (int i = 0; i < length; i++) {
		other.string[i] = buffer[i];
	}
	other.string[length] = '\0';

	return in;
};

MyString MyString::operator+(MyString& other) {
	MyString tmp;
	tmp.length = this->length + other.length;
	tmp.string = new char[tmp.length + 1];
	int j = 0;
	for (int i = 0; i < this->length; i++) {
		tmp.string[j] = this->string[i];
		j++;
	}
	for (int i = 0; i < other.length; i++) {
		tmp.string[j] = other.string[i];
		j++;
	}
	tmp.string[tmp.length] = '\0';

	return tmp;
};

MyString MyString::operator+(const char array[]) {
	MyString tmp;
	int lengthArray = count_Array_Length(array);

	tmp.length = lengthArray + this->length;
	tmp.string = new char[tmp.length + 1];
	int j = 0;
	for (int i = 0; i < this->length; i++) {
		tmp.string[j] = this->string[i];
		j++;
	}
	for (int i = 0; i < lengthArray; i++) {
		tmp.string[j] = array[i];
		j++;
	}
	tmp.string[tmp.length] = '\0';

	return tmp;
};



MyString& MyString::operator=(const MyString& other) {
	this->length = other.length;
	delete this->string;
	this->string = new char[this->length + 1];
	for (int i = 0; i < this->length; i++) {
		this->string[i] = other.string[i];
	}
	this->string[this->length] = '\0';

	return *this;
};

MyString& MyString::operator=( MyString&& other) {
	this->length = other.length;
	delete this->string;
	this->string = other.string;
	other.string = nullptr;
	other.length = 0;
	return*this;
};



int MyString::compare(const MyString& other) {
	if (this->length == other.length) {
		for (int i = 0; i < other.length; i++) {
			if (this->string[i] != other.string[i])
				return 0;

		}
		return 1;
	}
	else
		return 0;
};


int MyString::compare(const char array[]) {
	int arrayLength = count_Array_Length(array);

	if (this->length == arrayLength) {
		for (int i = 0; i < arrayLength; i++) {
			if (this->string[i] != array[i])
				return 0;
		}
		return 1;
	}
	else
		return 0;
};

MyString& MyString::operator+=(const MyString& other) {
	MyString tmp;
	tmp.length = this->length + other.length;
	tmp.string = new char[tmp.length + 1];
	int j = 0;
	for (int i = 0; i < this->length; i++) {
		tmp.string[j] = this->string[i];
		j++;
	}
	for (int i = 0; i < other.length; i++) {
		tmp.string[j] = other.string[i];
		j++;
	}
	tmp.string[tmp.length] = '\0';
	delete this->string;
	this->length = tmp.length;
	this->string = tmp.string;
	tmp.string = nullptr;
	return*this;
};
MyString& MyString::operator+=(const char array[]) {
	int arrayLength = count_Array_Length(array);
	MyString tmp;
	tmp.length = this->length + arrayLength;
	tmp.string = new char[tmp.length + 1];
	int j = 0;
	for (int i = 0; i < this->length; i++) {
		tmp.string[j] = this->string[i];
		j++;
	}
	for (int i = 0; i < arrayLength; i++) {
		tmp.string[j] = array[i];
		j++;
	}
	tmp.string[tmp.length] = '\0';
	delete this->string;
	this->length = tmp.length;
	this->string = tmp.string;
	tmp.string = nullptr;
	return*this;

};


MyString& MyString::operator+=(const char& letter) {
	if (this->string != nullptr && (this->length % 8) != 0) {
		this->string[this->length] = letter;
		this->length++;
		this->string[this->length] = '\0';
	}
	else if (this->string != nullptr && (this->length % 8) == 0) {
		MyString tmp;
		tmp.length = this->length + 1;
		tmp.string = new char[this->length + 9];
		for (int i = 0; i < this->length; i++) {
			tmp.string[i] = this->string[i];
		}
		tmp.string[this->length] = letter;
		tmp.string[tmp.length] = '\0';
		this->length = tmp.length;
		delete this->string;
		this->string = tmp.string;
		tmp.string = nullptr;
	}
	else if (this->string == nullptr) {
		this->string = new char[9];
		this->length = 0;
		this->string[this->length] = letter;
		this->length++;
		this->string[this->length] = '\0';
	}
	return *this;
};
	

int MyString::swapToInt() {
	int number = 0;
	if (this->string != nullptr) {
		if (this->length > 0) {
			for (int i = 0 ; i < this->length; i++) {
				number = number * 10 + (this->string[i] - '0');
			}
		}
	}
	return number;
};

void MyString::clearWhiteSpace() {
	bool front = false, back = false;
	int frontAmount = 0, backAmount = 0;
	if (this->string != nullptr) {
		for (int i = 0; i < this->length; i++) {
			if (this->string[i] == ' ' || this->string[i] == '\t') {
				front = true;
				frontAmount++;
			}
			else
				break;
		}
		for (int i = this->length-1; i >= 0; i--) {
			if (this->string[i] == ' ' || this->string[i] == '\t') {
				back = true;
				backAmount++;
			}
			else
				break;
		}


		if (front && back) {
			MyString tmp;
			tmp.length = this->length - backAmount - frontAmount;
			tmp.string = new char[tmp.length + 1];
			for (int i = 0; i < tmp.length; i++) {
				tmp.string[i] = this->string[i + frontAmount];
			}
			tmp.string[tmp.length] = '\0';
			delete this->string;
			this->string = tmp.string;
			this->length = tmp.length;
			tmp.string = nullptr;
		}
		else if (front) {
			MyString tmp;
			tmp.length = this->length - frontAmount;
			tmp.string = new char[tmp.length + 1];
			for (int i = 0; i < tmp.length; i++) {
				tmp.string[i] = this->string[i + frontAmount];
			}
			tmp.string[tmp.length] = '\0';
			delete this->string;
			this->string = tmp.string;
			this->length = tmp.length;
			tmp.string = nullptr;
		}
		else if (back) {
			MyString tmp;
			tmp.length = this->length - backAmount;
			tmp.string = new char[tmp.length + 1];
			for (int i = 0; i < tmp.length; i++) {
				tmp.string[i] = this->string[i];
			}
			tmp.string[tmp.length] = '\0';
			delete this->string;
			this->string = tmp.string;
			this->length = tmp.length;
			tmp.string = nullptr;
		}
	}
};

int MyString::checkIfLastElementIsNumber() {
	char letter = 'a';
	int i = 0;
	letter = this->string[this->length - 1 - i];
	while (letter != ',') {
		switch (letter) {
		case '1':
			break;
		case '2':
			break;
		case '3':
			break;
		case '4':
			break;
		case '5':
			break;
		case '6':
			break;
		case '7':
			break;
		case '8':
			break;
		case '9':
			break;
		case '0':
			break;
		default:
			return 0;

		}
		
		i++;
		letter = this->string[this->length - 1 - i];
	}
	return 1;

};

int MyString::checkIfStartsWithLetter(const char& letter) {
	if (this->string != nullptr) {
		if (this->string[0] == letter)
			return 1;
	}
	return 0;
}

MyString MyString::extractLastElement() {
	char letter = 'a';
	int i = 0;
	int cut = 0;
	MyString word;
	letter = this->string[i];
	while (letter != '\0') {
		if (letter == ',')
			cut = i;
		i++;
		letter = this->string[i];
	}

	for (int j = cut+1; j < this->length; j++) {
		word += this->string[j];
	}
	word.length = this->length - cut-1;

	return word;
}

int MyString::isItNumber() {
	int value = 0;
	for (int i = 0; i < this->length; i++) {
		value = this->string[i] - '0';
		if (value < 0 || value > 9)
			return 0;
	}
	return 1;
}
void MyString::setStringToNull() {
	this->string = nullptr;
	this->length = 0;
}