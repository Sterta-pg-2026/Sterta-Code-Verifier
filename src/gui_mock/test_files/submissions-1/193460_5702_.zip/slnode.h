#pragma once

#include <iostream>
#include "mystring.h"

class SLnode
{
	
private:
	MyString name;
	MyString value;
	SLnode* next;
public:
	SLnode() {  next = nullptr; };
	
	SLnode* getNext() { return next; };
	MyString& getName() { return name; };
	MyString& getValue() { return value; };
	
	void setNext(SLnode* next) { this->next = next; };
	void setName(MyString& name) { this->name = std::move(name); };
	void setValue(MyString& value) { this->value = std::move(value); };
	


};

