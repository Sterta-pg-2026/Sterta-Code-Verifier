#pragma once
#include <iostream>
#include "dlnode.h"
#include "section.h"

class DLlist
{
private:
	//amount of CssSections in DLnode array;
	int counter;
	DLnode* head, * tail;
public:
	DLlist() :counter(0), head(nullptr), tail(head) {};
	~DLlist();
	void addNode();

	void removeNode(DLnode* remove);

	void saveCssSection(Section& other);
	DLnode* getHead() { return head; }
	DLnode* getTail() { return tail; }

	size_t countValidSections();
	Section* findNthSection(int& n);
	void removeNthSection(int n);

	int countOccurrenceAttributse(MyString& other);
	int countOccurrenceSelector(MyString& other);

	Section* findLastSelector(MyString* name = nullptr);



};