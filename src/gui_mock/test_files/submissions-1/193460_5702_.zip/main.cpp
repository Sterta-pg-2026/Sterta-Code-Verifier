#pragma
#include <iostream>
#include "dllist.h"
#include "sllist.h"
#include "section.h"
#include "mystring.h"
#include "sort.h"


int main()
{
	
	Section tmp;
	Sort sort;
	
	sort.takeInput();
}

