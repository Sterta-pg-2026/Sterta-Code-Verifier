#pragma once

#pragma once
#include "slnode.h"
#include "mystring.h"
#include <iostream>

class SLlist
{
private:
	SLnode* head, * tail;
public:
	SLlist();
	~SLlist();

	inline void setHead(SLnode* head) { this->head = head; };
	inline void setTail(SLnode* tail) { this->tail = tail; };
	inline SLnode* getHead() { return head; };
	inline SLnode* getTail() { return tail; };

	void addNode();

	void removeNode(SLnode* other);

	void saveName(MyString& other);
	void saveValue(MyString& other);

	int lengthOfList();
	
	void checkForDuplication(const MyString& other);

	SLnode* findNthNode(int &n);

	SLnode* searchForName( MyString& other);

	void clearList();
};

