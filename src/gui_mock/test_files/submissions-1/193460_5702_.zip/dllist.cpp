#include "dllist.h"


void DLlist::addNode() {
		if (this->head == nullptr) {
			this->head = new DLnode;
			this->tail = this->head;
		}
		else if (this->head == this->tail) {
			this->tail = new DLnode;
			this->head->setNext(this->tail);
			this->tail->setLast(this->head);
		}
		else {
			DLnode* tmp = new DLnode;
			this->tail->setNext(tmp);
			tmp->setLast(this->tail);
			this->tail = tmp;
			tmp = nullptr;
		}
	};

	void DLlist::removeNode(DLnode* remove) {
		if (this->tail == this->head) {
			if (remove == this->head)
				delete this->head;
			this->head = nullptr;
			this->tail = nullptr;
		}
		else if (remove == this->head) {
			this->head = this->head->getNext();
			delete remove;
		}
		else if (remove == this->tail) {
			this->tail = this->tail->getLast();
			this->tail->setNext(nullptr);
			delete remove;
		}
		else {
			remove->getLast()->setNext(remove->getNext());
			delete remove;
		}

}

	DLlist::~DLlist()
	{
		//delete hole list;
		if (head != nullptr) {
			DLnode* now = this->head;
			DLnode* next = this->head->getNext();
			while (now != nullptr) {
				delete now;
				now = next;
				if (now != nullptr)
					next = now->getNext();
			}
		}
	};

	void DLlist::saveCssSection(Section& other) {
		if (this->head == nullptr)
			this->addNode();
		DLnode* saveIn = this->tail;
		if (saveIn->getCssSection(7)->getIndex() != -1) {
			this->addNode();
			saveIn = this->tail;
		}
		int i = 7;
		for (; i >= 0; i--) {
			if (saveIn->getCssSection(i)->getIndex() != -1) {
				i++;
				break;
			}
			else if (i == 0)
				break;
		}
		
		saveIn->setCssSection(other, i);
		counter++;
		
	};

	size_t DLlist::countValidSections() {
		size_t sum = 0;
		DLnode* now = this->getHead();
		while (now != nullptr) {
			sum += now->getAmountOfValidSections();
			now = now->getNext();
		}
		return sum;
	}

	Section* DLlist::findNthSection(int& n) {
		Section* tmp = nullptr;
		DLnode* now = this->getHead();
		int i = 0;
		while (now != nullptr) {
			for (int j = 0; j < 8; j++) {
				tmp = now->getCssSection(j);
				if (tmp->getIndex() != -1) {
					if (i == n - 1)
						return tmp;
					i++;
				}
			}
			now = now->getNext();
		}
		return nullptr;
	};

	void DLlist::removeNthSection(int n) {
		Section* tmp = nullptr;
		DLnode* now = this->getHead();
		for (int i = 0; i < n; ) {
			for (int j = 0; j < 8; j++) {
				tmp = now->getCssSection(j);
				if (tmp->getIndex() != -1) {
					if (i == n - 1) {
						tmp->removeSection();
						now->removeValidSecion();
						goto next;
					}
					i++;
				}
			}
			now = now->getNext();
		}
		next:
		for (int i = 0; i < 8; i++){
			if (now->getCssSection(i)->getIndex() != -1)
				break;
			else if  (i == 7)
				this->removeNode(now);
		}
	};

	int DLlist::countOccurrenceAttributse(MyString& other) {
		int sum = 0;
		DLnode* now = this->head;
		Section* tmp = nullptr;
		while (now != nullptr) {
			for (int i = 0; i < 8; i++) {
				tmp = now->getCssSection(i);
				if (tmp->getIndex() != -1) {
					if (tmp->getAttributes().searchForName(other) != nullptr)
						sum++;
				}
			}
			now = now->getNext();
		}
		return sum;
	};
	int DLlist::countOccurrenceSelector(MyString& other) {
		int sum = 0;
		DLnode* now = this->head;
		Section* tmp = nullptr;
		while (now != nullptr) {
			for (int i = 0; i < 8; i++) {
				tmp = now->getCssSection(i);
				if (tmp->getIndex() != -1) {
					if (tmp->getSelectors().searchForName(other) != nullptr)
						sum++;
				}
			}
			now = now->getNext();
		}
		return sum;
	};

	Section* DLlist::findLastSelector( MyString* name) {
		static MyString name_copy = "";
		static DLnode* now = this->tail;
		static int i = 7;
		if (name != nullptr) {
			name_copy = *name;
			i = 7;
			now = this->tail;
		}
		else
			i--;
		while (now != nullptr) {
			Section* tmp;
			for (; i >= 0; i--) {
				tmp = now->getCssSection(i);
				if(tmp->getIndex() != -1) {
					if (tmp->getSelectors().searchForName(name_copy) != nullptr)
						return tmp;
				}
			}
			i = 7;
			now = now->getLast();
		}
		return nullptr;
	};