#pragma once
#define T 8
#include "string.h"
#include "singlelinkedlist.h"

struct CSSsection {
	SingleLinkedList* headSelector = nullptr;
	SingleLinkedList* headAttribute = nullptr;
	int SelectorCounter = 0;
	int AttributeCounter = 0;
	bool isWritten = false;
};


class DoubleLinkedList 
{
	CSSsection SectionsArray[T];
	int index = 1;
	int FreeBlocks = T;
public:
	DoubleLinkedList* next = nullptr;
	DoubleLinkedList* prev = nullptr;
	DoubleLinkedList();
	DoubleLinkedList* DllAddLastNode(DoubleLinkedList ** currNode, int *tab, int* index);
	//void RemoveNode(DoubleLinkedList** headNode,int index);
	void AddSelectorNode(DoubleLinkedList** currNode, String* name);
	void AddAttributeNode(DoubleLinkedList** currNode, String* name, String* value);
	void IsWritten(DoubleLinkedList** currNode,int index);
	void PrintNumberOfSectionsCSS(DoubleLinkedList** currNode);
	void PrintNumberOfSelectorsForIthSection(DoubleLinkedList** currNode,int i);
	void PrintNumberOfAttributesForIthSection(DoubleLinkedList** currNode, int i);
	void PrintJthSelectorforIthSection(DoubleLinkedList** currNode, int i, int j);
	void PrintValueOfAttributeForIthSection(DoubleLinkedList** currNode, int i, char s[]);
	void AllBlocksAttributeNCounter(DoubleLinkedList** currNode, char s[]);
	void AllBlockSelectorNCounter(DoubleLinkedList** currNode, char s[]);
	void ValueOfAttributeNForSelectorZ(DoubleLinkedList** currNode, char s1[], char s2[]);
	void DeleteEntireSection(DoubleLinkedList** currNode, int i);
	void CommandParser(char* input, DoubleLinkedList** currNode);
};
