#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "string.h"

using namespace std;



String::String() {
	str = new char[1];
	str[0] = '\0';
}

String::String(char* name) {
	if (name == nullptr) {
		str = new char[1];
		str[0] = '\0';
	}
	else {
		str = new char[strlen (name)+1];
		strcpy(str,name);
		str[strlen(name)] = '\0';
	}
}

char* String:: getString() {
	return str;
}

char* String:: removeLastElement(char* string) {
	string[strlen(string) - 1] = '\0';
	return string;
}

char* String:: addTwoStrings(char* s1, char* s2) {
	int size = strlen(s1) + strlen(s2) + 1;
	str = new char[size];
	for (int i = 0; i < strlen(s1); i++) {
		str[i] = s1[i];
		}
	for(int j=0; j<strlen(s2)+1;j++){
		str[j + strlen(s1) + 1] = s2[j];
	}
	return str;
}
char* String::newString(char* str, int &currBufforSize, char c) {
	int len = strlen(str);
	char* newString;

	if (len + 2 > currBufforSize)
	{
		currBufforSize += BUFFORLENADD;
		newString = new char[currBufforSize];
		for (int i = 0; i < len; i++)
		{
			newString[i] = str[i];
		}
	}
	else {
		newString = str;
	}
	if (newString != nullptr) {
		newString[len] = c;
		newString[len + 1] = '\0';
	}
	return newString;
}

void String::StripWhitespace(char* str) {
	char* end = str + strlen(str) - 1;
	while (isspace(*str)) {
		str++;
	}
	while (isspace(*end) && end > str) {
		*end-- = '\0';
	}
}

void String::printString(char *str){
	int len = strlen(str)+1;
	for (int i = 0; i < len; i++) {
		cout << str[i];
	}
	return;
}

const char String:: operator[](int i) {
	return str[i];
}
bool String::operator==(String& s) {
	int i = 0;
	while (str[i] == s[i]) {
		if (str[i] == '\0' && s[i] == '\0') {
			return true;
		}
		i++;
	}
	return false;
}

bool String::operator==(char s) {
	if (str[0] == s) {
		return true;
	}
	return false;
}

bool String::operator==(char s[]) {
	int i = 0;
	int len = strlen(s);
	for (int j = 0; j < (strlen(s) + 1); j++) {
		if (str[i] == s[i]) {
			if (i == len) {
				return true;
			}
			else {
				i++;
			}
		}
		else {
			return false;
		}
	}
	return false;
}

bool String::operator != (char s[]) {
	int i = 0;
	int len = strlen(s);
	for (int j = 0; j < (strlen(s) + 1); j++) {
		if (str[i] == s[i]) {
			if (i == len) {
				return false;
			}
			else {
				i++;
			}
		}
		else {
			return true;
		}
	}
	return true;
}

bool String::operator!=(String& s) {
	int i = 0;
	while (str[i] == s[i]) {
		if (str[i] == '\0' && s[i] == '\0') {
			return false;
		}
		i++;
	}
	return true;
}

String::~String() {
}
