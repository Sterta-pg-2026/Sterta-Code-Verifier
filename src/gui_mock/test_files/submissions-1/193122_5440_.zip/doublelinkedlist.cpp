#define _CRT_SECURE_NO_WARNINGS
#include "doublelinkedlist.h"
#include "singlelinkedlist.h"
#include <iostream>

using namespace std;

DoubleLinkedList::DoubleLinkedList() {
	next = nullptr;
}

DoubleLinkedList* DoubleLinkedList::DllAddLastNode(DoubleLinkedList** currNode, int *tab, int* index) {
	if ((*currNode)->FreeBlocks > 0) {
		return (*currNode);
	}
	DoubleLinkedList* newNode = new DoubleLinkedList;
	DoubleLinkedList* tmp = (*currNode);
	while (tmp->next != nullptr) {
		tmp= tmp->next;
		(*index)++;
	}
	(*index)++;
	tmp->next = newNode;
	newNode->prev = tmp;
	newNode->index = (*index);
	(*tab) = 0;
	return newNode;
}

/*void DoubleLinkedList::RemoveNode(DoubleLinkedList** headNode, int index) {
	if (headNode == nullptr) {
		return;
	}
	DllNode* tmp = head;
	if (tmp != nullptr && tmp->index == index) {
		head = tmp->next;
		delete tmp;
		return;
	}
	else {
		DllNode* CurrentNode = head;
		while (tmp != nullptr && tmp->index != index) {
			CurrentNode = tmp;
			tmp = tmp->next;
		}
		if (tmp == nullptr) {
			cout << "No such node in the list" << endl;
			return;
		}
		if (tmp->next != nullptr) {
			DllNode* nextNode = tmp->next;
			nextNode->prev = CurrentNode;
		}
		CurrentNode->next = tmp->next;
		delete tmp;
	}
}
*/

void DoubleLinkedList::AddSelectorNode(DoubleLinkedList** currNode, String* name) {
	if ((*name) == '\0') {
		return;
	}
	SingleLinkedList* newNode = new SingleLinkedList;
	name->StripWhitespace(name->getString());
	newNode->name = (*name);
	int index = 1;
	int arrayIndex = 0;

	while ((*currNode)->SectionsArray[arrayIndex].isWritten == true) {
		arrayIndex++;
	}

	if ((*currNode)->SectionsArray[arrayIndex].headSelector == nullptr) {
		(*currNode)->SectionsArray[arrayIndex].headSelector = newNode;
		(*currNode)->SectionsArray[arrayIndex].SelectorCounter++;
		return;
	}
	SingleLinkedList* tmp = (*currNode)->SectionsArray[arrayIndex].headSelector;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
		index++;
	}
	if (tmp != newNode) {
		index++;
	}
	tmp->next = newNode;
	newNode->index = index;
	(*currNode)->SectionsArray[arrayIndex].SelectorCounter++;
}

void DoubleLinkedList::AddAttributeNode(DoubleLinkedList** currNode, String* name, String* value) {
	if ((*name) == '\0') {
		return;
	}
	SingleLinkedList* newNode = new SingleLinkedList;
	name->StripWhitespace(name->getString());
	value->StripWhitespace(value->getString());
	newNode->name = (*name);
	newNode->value = (*value);
	int index = 1;
	int arrayIndex = 0;
	
	while ((*currNode)->SectionsArray[arrayIndex].isWritten == true) {
		arrayIndex++;
	}
	
	if ((*currNode)->SectionsArray[arrayIndex].headAttribute != nullptr) {
		if ((*currNode)->SectionsArray[arrayIndex].headAttribute->name == (*name)) {
			(*currNode)->SectionsArray[arrayIndex].headAttribute->value = (*value);
			return;
		}
		else if ((*currNode)->SectionsArray[arrayIndex].headAttribute->next != nullptr) {
			SingleLinkedList* tmp = (*currNode)->SectionsArray[arrayIndex].headAttribute;
			while (tmp != nullptr) {
				if (tmp->name ==(*name)) {
					tmp->value = (*value);
					return;
				}
				tmp = tmp->next;
			}

		}
	}
	


	if ((*currNode)->SectionsArray[arrayIndex].headAttribute == nullptr) {
		(*currNode)->SectionsArray[arrayIndex].headAttribute = newNode;
		(*currNode)->SectionsArray[arrayIndex].AttributeCounter++;
		return;
	}
	SingleLinkedList* tmp = (*currNode)->SectionsArray[arrayIndex].headAttribute;
	while (tmp->next != nullptr) {
		tmp= tmp->next;
		index++;
	}
	if (tmp != newNode) {
		index++;
	}
	tmp->next = newNode;
	newNode->index = index;
	(*currNode)->SectionsArray[arrayIndex].AttributeCounter++;
}

void DoubleLinkedList::IsWritten(DoubleLinkedList** currNode, int index) {
	(*currNode)->SectionsArray[index].isWritten = true;
	(*currNode)->FreeBlocks--;
}

void DoubleLinkedList::PrintNumberOfSectionsCSS(DoubleLinkedList** currNode) {
	int counter = 0;
	DoubleLinkedList* tmp = (*currNode);
	while (tmp->prev!= nullptr) {
		counter = counter + (T - tmp->FreeBlocks);
		tmp = tmp->prev;
	}
	if (tmp->prev == nullptr) {
		counter = counter + (T - tmp->FreeBlocks);
	}
	cout << "? == " << counter<< endl;
}

void DoubleLinkedList::PrintNumberOfSelectorsForIthSection(DoubleLinkedList** currNode, int i) {
	int jump = i % T;
	jump--;
	DoubleLinkedList* tmp = (*currNode);//because arrays are indexed from 0
	while (((i+T -1)/ T) != tmp->index) {
		if (((i + T - 1) / T) < tmp->index) {
			tmp = tmp->prev;
		}
		else if (((i + T - 1) / T) > tmp->index) {
			tmp = tmp->next;
		}
	}
	if (tmp->SectionsArray[jump].SelectorCounter == 0) {
		return;
	}
	cout << i <<",S,? == "<< tmp->SectionsArray[jump].SelectorCounter<< endl;
}

void DoubleLinkedList::PrintNumberOfAttributesForIthSection(DoubleLinkedList** currNode, int i) {
	DoubleLinkedList* tmp = (*currNode);
	int jump = i % T;
	jump--; //because arrays are indexed from 0
	while (((i + T - 1) / T) != tmp->index) {
		if (((i + T - 1) / T) < tmp->index) {
			tmp = tmp->prev;
		}
		else if (((i + T - 1) / T) > tmp->index) {
			tmp = tmp->next;
		}
	}
	if (tmp->SectionsArray[jump].AttributeCounter == 0) {
		return;
	}
	cout << i << ",A,? == " << tmp->SectionsArray[jump].AttributeCounter<< endl;
}

void DoubleLinkedList::PrintJthSelectorforIthSection(DoubleLinkedList** currNode, int i, int j){
	DoubleLinkedList* tmp = (*currNode);
	int jump = i % T;
	jump--; //because arrays are indexed from 0
	while (((i + T - 1) / T) != tmp->index) {
		if (((i + T - 1) / T) < tmp->index) {
			tmp = tmp->prev;
		}
		else if (((i + T - 1) / T) > tmp->index) {
			tmp = tmp->next;
		}
	}
	SingleLinkedList* tmpSelector = tmp->SectionsArray[jump].headSelector;
	if (tmpSelector == nullptr) {
		return;
	}
	while (tmpSelector->index != j) {
		tmpSelector = tmpSelector->next;
		if (tmpSelector == nullptr) {
			return;
		}
	}
	char* nameSelector = tmpSelector->name.getString();
	cout << i << ",S," << j << " == ";// << tmpSelector->name << endl;
	for (int i = 0; i < strlen(nameSelector); i++) {
		cout << nameSelector[i];
	}
	cout << endl;
}

void DoubleLinkedList::PrintValueOfAttributeForIthSection(DoubleLinkedList** currNode, int i, char s[]) {
	DoubleLinkedList* tmp = (*currNode);
	int jump = i % T;
	jump--;
	while (((i + T - 1) / T) != tmp->index) {
		if (((i + T - 1) / T) < tmp->index) {
			tmp = tmp->prev;
		}
		else if (((i + T - 1) / T) > tmp->index) {
			tmp = tmp->next;
		}
	}

	SingleLinkedList* tmpAttribute = tmp->SectionsArray[jump].headAttribute;
	if (tmpAttribute == nullptr) {
		return;
	}
	char* nameAttribute = tmpAttribute->name.getString();
	if (nameAttribute != nullptr) {
		while (strcmp(nameAttribute, s) != 0) { // blad na STOSIE VIOLATION ACCESS

			tmpAttribute = tmpAttribute->next;
			if (tmpAttribute == nullptr) {
				return;
			}
			nameAttribute = tmpAttribute->name.getString();
			if (nameAttribute == nullptr) {//do poprawienia
				return;
			}
		}
	}
	char* valueAttribute = tmpAttribute->value.getString();
	cout << i << ",A,"; //tmpAttribute->name << " == " << tmpAttribute->value<<endl;
	for (int n = 0; n < strlen(s); n++) {
		cout << s[n];
	}
	cout << " == ";
	cout << valueAttribute;
	cout << endl;

}

void DoubleLinkedList::AllBlocksAttributeNCounter(DoubleLinkedList** currNode, char s[]) {
	int counter = 0;
	DoubleLinkedList* tmp = (*currNode);
	while (tmp != nullptr) {
		for (int i = 0; i < (T - tmp->FreeBlocks); i++) {
			SingleLinkedList* tmpAttribute = tmp->SectionsArray[i].headAttribute;
			while (tmpAttribute != nullptr) {
				char* nameAttribute = tmpAttribute->name.getString();
				if (strcmp(nameAttribute,s)==0) {
					counter++;
				}
				tmpAttribute = tmpAttribute->next;
			}
		}
		tmp = tmp->prev;
	}
	for (int j = 0; j < strlen(s); j++) {
		cout << s[j];
	}
	cout << ",A,? == " << counter << endl;
}

void DoubleLinkedList::AllBlockSelectorNCounter(DoubleLinkedList** currNode, char s[]) {
	int counter = 0;
	DoubleLinkedList* tmp = (*currNode);
	while (tmp != nullptr) {
		for (int i = 0; i < (T - tmp->FreeBlocks); i++) {
			SingleLinkedList* tmpSelector = tmp->SectionsArray[i].headSelector;
			while (tmpSelector != nullptr) {
				char* nameSelector = tmpSelector->name.getString();
				if (strcmp(nameSelector, s) == 0) {
					counter++;
				}
				tmpSelector = tmpSelector->next;
			}
		}
		tmp = tmp->prev;
	}
	for (int j = 0; j < strlen(s); j++) {
		cout << s[j];
	}
	cout << ",S,? == " << counter << endl;
}

void DoubleLinkedList::ValueOfAttributeNForSelectorZ(DoubleLinkedList** currNode, char s1[], char s2[]) {
	DoubleLinkedList* tmp = (*currNode);
	DoubleLinkedList* findNode = nullptr;
	int index = 0;
	while (tmp != nullptr) {
		for (int i = 0; i < (T - tmp->FreeBlocks);i++) {
			SingleLinkedList* tmpSelector = tmp->SectionsArray[i].headSelector;
			while (tmpSelector != nullptr) {
				char* nameSelector = tmpSelector->name.getString();
				if (strcmp(nameSelector, s1) == 0) {
					index = i;
					findNode = tmp;
				}
				tmpSelector = tmpSelector->next;
			}
		}
		tmp = tmp->prev;
	}
	if (findNode == nullptr) {
		return;
	}
	else {
		SingleLinkedList* tmpAttribute = findNode->SectionsArray[index].headAttribute;
		char *print = nullptr;
		while (tmpAttribute != nullptr) {
			char* nameAttribute = tmpAttribute->name.getString();
			if (strcmp(nameAttribute, s2) == 0) {
				print = tmpAttribute->value.getString();
			}
			tmpAttribute = tmpAttribute->next;
		}
		if (print != nullptr) {
			for (int z = 0; z < strlen(s1); z++) {
				cout << s1[z];
			}
			cout << ",E,";
			for (int n = 0; n < strlen(s2); n++) {
				cout << s2[n];
			}
			cout << "  ==  " << print << endl;

		}
	}
}

void DoubleLinkedList::DeleteEntireSection(DoubleLinkedList** currNode, int i) {
	DoubleLinkedList* tmp = (*currNode);
	if (tmp == nullptr) {
		return;
	}
	int jump = i % T;
	jump--;
	while (((i + T - 1) / T) != tmp->index) {
		if (((i + T - 1) / T) < tmp->index) {
			tmp = tmp->prev;
		}
		else if (((i + T - 1) / T) > tmp->index) {
			tmp = tmp->next;
		}
	}
	if (tmp->SectionsArray[jump].isWritten==true) {
		tmp->SectionsArray[jump].headAttribute = nullptr;
		tmp->SectionsArray[jump].headSelector = nullptr;
		tmp->SectionsArray[jump].AttributeCounter = 0;
		tmp->SectionsArray[jump].SelectorCounter = 0;
		tmp->FreeBlocks++;
		cout << i << ",D,* == deleted";
	}
	else {
		return;
	}
}

void DoubleLinkedList:: CommandParser(char* input, DoubleLinkedList** currNode) {
	char* token = strtok(input, ",");
	char* values[3];
	int count = 0;
	if (input[0] == '?') {
		(*currNode)->PrintNumberOfSectionsCSS(currNode);  // ?
		return;
	}
	else {
		while (token != NULL) {
			values[count] = token;
			count++;
			token = strtok(NULL, ",");
		}

		if (count == 3) {
			if ((!(isdigit(values[0][0]))) && (strlen(values[0]) > 1)) {
				if (strlen(values[2]) > 1) {
					(*currNode)->ValueOfAttributeNForSelectorZ(currNode, values[0], values[2]); //z,E,n
					return;
				}
				else {
					if (values[1][0] == 'A') {  //n,A,?    z,S,? 
						(*currNode)->AllBlocksAttributeNCounter(currNode, values[0]);
						return;
					}
					else {
						(*currNode)->AllBlockSelectorNCounter(currNode, values[0]);
						return;
					}
				}
			}
			else {
				int num1 = atoi(values[0]);
				char ch = values[1][0];
				if (isdigit(values[2][0])) {
					int num2 = atoi(values[2]);
					(*currNode)->PrintJthSelectorforIthSection(currNode, num1, num2); //i,S,j   
					return;
				}
				else {
					if (strlen(values[2]) > 1) {
						if (values[1][0] == 'A') {
							(*currNode)->PrintValueOfAttributeForIthSection(currNode, num1, values[2]);
							return;  //i,A,n
						}
						else {  // i,D,n
							return;
						}
					}
					else {
						if (values[1][0] == 'S') {
							(*currNode)->PrintNumberOfSelectorsForIthSection(currNode, num1); //i,S,?
							return;
						}
						else if(values[1][0] =='A'){
							(*currNode)->PrintNumberOfAttributesForIthSection(currNode, num1); //i,A,?
							return;
						}
						else {
							(*currNode)->DeleteEntireSection(currNode, num1);
							return;
						}
						
					}
				}
			}
		}
		else {
			return;
		}
	}
}