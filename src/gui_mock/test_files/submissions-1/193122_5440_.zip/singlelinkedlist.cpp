#include "singlelinkedlist.h"
#include "string.h"
#include <iostream>

using namespace std;
SingleLinkedList::SingleLinkedList() {
	next = nullptr;
}



int SingleLinkedList::GetListLen(SingleLinkedList* firstNode) {
	int counter = 1;
	SingleLinkedList* tmp = firstNode;
	while (tmp->next != nullptr) {
		counter++;
		tmp = tmp->next;
	}
	return counter;
}

/*void SingleLinkedList::AddSelectorNodeSll(String* name) {
	SllNode* newNode = new SllNode;
	newNode->name = (*name);
	int index = 1;

	if (head == nullptr) {
		head = newNode;
		return;
	}
	SllNode* tmp = head;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
		index++;
	}
	if (head != newNode) {
		index++;
	}
	tmp->next = newNode;
	newNode->index = index;
}
*/

/*
void SingleLinkedList::RemoveSelectorNode(SingleLinkedList** headSelector, String* name) {
	SllNode* tmp = head;
	if (tmp == nullptr) {
		cout << "Empty list." << endl;
		return;
	}
	if (tmp != nullptr && tmp->name == (*name)) {
		head = tmp->next;
		delete tmp;
		return;
	}
	else {
		SllNode* CurrentNode = head;
		while (tmp->name != (*name) && tmp != nullptr) {
			CurrentNode = tmp;
			tmp = tmp->next;
		}
		if (tmp == nullptr) {
			cout << "No such selector in list" << endl;
			return;
		}
		CurrentNode->next = tmp->next;
		delete tmp;
	}

}
*/

/*
void SingleLinkedList::AddAttributeNodeSll(SingleLinkedList** headAttribute,String* name, String* value) {
	SllNode* newNode = new SllNode;
	newNode->name = (*name);
	newNode->value = (*value);
	int index = 1;

	if (head == nullptr) {
		head = newNode;
		return;
	}
	SllNode* tmp = head;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
		index++;
	}
	if (head != newNode) {
		index++;
	}
	tmp->next = newNode;
	tmp->index = index;
}
*/

/*
void SingleLinkedList::RemoveAttributeNode(SingleLinkedList** headSelector, String *name) {
	SllNode* tmp = head;
	if (tmp == nullptr) {
		cout << "Empty list." << endl;
		return;
	}
	if (tmp != nullptr && tmp->name == (*name) ) {
		head = tmp->next;
		delete tmp;
		return;
	}
	else {
		SllNode* CurrentNode = head;
		while (tmp->name != (*name) && tmp != nullptr) {
			CurrentNode = tmp;
			tmp = tmp->next;
		}
		if (tmp == nullptr) {
			cout << "No such attribute in list" << endl;
			return;
		}
		CurrentNode->next = tmp->next;
		delete tmp;
	}

}
*/
