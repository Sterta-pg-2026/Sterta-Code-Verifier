#pragma once
#include "string.h"




class SingleLinkedList
{
private:
public:
	SingleLinkedList* next = nullptr;
	int index = 1;
	String name;
	String value;
	SingleLinkedList();
	int GetListLen(SingleLinkedList* firstNode);
	/*void AddSelectorNodeSll(String* name);
	void RemoveSelectorNode(SingleLinkedList** headSelector, String* name);
	void AddAttributeNodeSll(SingleLinkedList** headAttribute, String *name, String* value);
	void RemoveAttributeNode(SingleLinkedList** headAttribute, String* name);
	*/
};