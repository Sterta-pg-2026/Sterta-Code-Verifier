#pragma once
#define BUFFORLENADD 100
#include <iostream>
using namespace std;

class String {
	char* str;
public:
	String();
	String(char* name);
	char* getString();
	char* removeLastElement(char* string);
	char* addTwoStrings(char* s1, char* s2);
	char* newString(char* str, int &bufforSize, char c);
	void StripWhitespace(char* str);
	void printString(char* str);
	const char operator[](int i);
	bool operator == (String& s);
	bool operator == (char s);
	bool operator == (char s[]);
	bool operator != (char s[]);
	bool operator != (String& s);
	~String();

};
