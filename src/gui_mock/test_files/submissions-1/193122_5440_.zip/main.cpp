#define _CRT_SECURE_NO_WARNINGS
#include "string.h"
#include "singlelinkedlist.h"
#include "doublelinkedlist.h"
#include <iostream>


using namespace std;

int main() {
	DoubleLinkedList* Dll= new DoubleLinkedList;
	int currBufforSize = 0;
	String command;
	char c;
	String str1;
	String str2;
	int tab = 0;
	int CurrentMode = 0;//0 - Selectors, 1- attributes, 2- commands
	int CurrentString = 1; // for attributes
	int QuestionMarksCounter = 0;
	int AsterixMarkCounter = 0;
	int DllNodeIndex = 1;

	while ((c=getchar()) != EOF) {
		if (CurrentMode == 0) {
			if (c == ',') {
				Dll->AddSelectorNode(&Dll, &str1);
				str1 = String();
				currBufforSize = 0;
				continue;
			}
			if (c == '{') {
				Dll->AddSelectorNode(&Dll, &str1);
				str1 = String();
				currBufforSize = 0;
				CurrentMode = 1;
				continue;
			}
			if (c == ' '|| c=='\n'||c== '\t'||c== '\r') {
				continue;
			}
			if (c == '?') {
				QuestionMarksCounter++;
				if (QuestionMarksCounter == 4) {
					CurrentMode = 2;
					str1 = String();
					currBufforSize = 0;
					QuestionMarksCounter = 0;
					continue;
				}
		
			}
			str1 = str1.newString(str1.getString(), currBufforSize, c);
		}
		else if (CurrentMode == 1) {
			if (c == ':') {
				CurrentString = 2;
				continue;
			}
			if (c == ';') {
				Dll->AddAttributeNode(&Dll, &str1, &str2);
				str1 = String();
				str2 = String();
				currBufforSize = 0;
				CurrentString = 1;
				continue;
			}
			if (c == ' ') {
				if (CurrentString == 2) {
					if (strlen(str2.getString()) > 1) {
						str2 = str2.newString(str2.getString(), currBufforSize, c);
						continue;
					}
					else {
						continue;
					}
				}
				else {
					continue;
				}
			}
			if (c == '\n' || c == '\r' || c == '\t') {
				continue;
			}
			if (c == '}') {
				Dll->AddAttributeNode(&Dll, &str1, &str2);
				str1 = String();
				str2 = String();
				currBufforSize = 0;
				CurrentMode = 0;
				Dll->IsWritten(&Dll, tab);
				tab++;
				Dll=Dll->DllAddLastNode(&Dll, &tab, &DllNodeIndex);
				continue;
			}
			if (c == '?') {
				QuestionMarksCounter++;
				if (QuestionMarksCounter == 4) {
					CurrentMode = 2;
					str1 = String();
					str2 = String();
					currBufforSize = 0;
					QuestionMarksCounter = 0;
					continue;
				}
			}
			if (CurrentString == 1) {
				str1 = str1.newString(str1.getString(), currBufforSize, c);
			}
			if (CurrentString == 2) {
				str2 = str2.newString(str2.getString(), currBufforSize, c);
			}
		}
		else if (CurrentMode == 2) {
			if (c == '*') {
				AsterixMarkCounter++;
				if (AsterixMarkCounter == 4) {
					CurrentMode = 0;
					str1 = String();
					currBufforSize = 0;
					AsterixMarkCounter = 0;
					continue;
				}
			}
			else {
				if (c != '\n' && c!= '\r' && c!= '\t') {
					command = command.newString(command.getString(), currBufforSize, c);
					continue;
				}
				
				Dll->CommandParser(command.getString(), &Dll);
				command = String();
			}
		}
	}
	return 0;
}
