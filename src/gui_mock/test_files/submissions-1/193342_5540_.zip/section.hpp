#pragma once

#include "attribute.hpp"

struct Section {

	List<String> selectors;
	List<Attribute> attributes;

	Section(List<String>& selectors, List<Attribute> attributes)
	: selectors(selectors) {
		attributes.iterate([&] (Attribute& attr) {
			this->attributes.removeIf([&] (Attribute& item) {
				return item.key == attr.key;
			});
		
			this->attributes.pushBack(attr);
		});
	}

	int getSelectorCount() {
		return selectors.length();
	}
	
	int getAttributeCount() {
		return attributes.length();
	}
	
	String* getSelector(int index) {
		return selectors.get(index);
	}
	
	
	Attribute* getAttribute(String& name) {
		auto* tmp = attributes.head;

		while (tmp != nullptr) {
			if (tmp->value.key == name) {
				return &tmp->value;
			}
			
			tmp = tmp->next;
		}
		
		return nullptr;
	}
	
	bool removeAttribute(String& name) {
		auto* tmp = attributes.head;
		int i = 0;

		while (tmp != nullptr) {
			if (tmp->value.key == name) {
				attributes.remove(i);
				return attributes.empty();
			}
			
			tmp = tmp->next;
			i ++;
		}
		
		return false;
	}
	
	String* getSelector(String& name) {
		auto* tmp = selectors.head;

		while (tmp != nullptr) {
			if (tmp->value == name) {
				return &tmp->value;
			}
			
			tmp = tmp->next;
		}
		
		return nullptr;
	}
	
	void print() {

		std::cout << " HEAD: ";
		selectors.iterate([] (auto& item) {
			const char* cstr = item.c_str();
			std::cout << cstr << " ";
			delete[] cstr;
		});

		std::cout << " ATTR: ";
		attributes.iterate([] (auto& item) {
			item.print();

//			const char* cstr = item.c_str();
//			std::cout << cstr << " ";
//			delete[] cstr;
		});
	}

};
