#pragma once

#include "external.hpp"
#include "section.hpp"
#include "util.hpp"

enum struct Phase {
	HEAD, // css selectors
	BODY, // css attributes
	TEST  // testing mode
};

template<class T>
List<T> splitAndTrim(String& string, char separator) {
	List<T> strings;
	String buffer;

	for (int i = 0; i < string.size(); i ++) {
		char chr = string[i];

		if (separator == chr) {
			String trimmed = trim(buffer);
			strings.pushBack(trimmed);
			buffer.clear();
			continue;
		}

		buffer.push(chr);
	}

	if (buffer.size() > 0) {
		String trimmed = trim(buffer);
		strings.pushBack(trimmed);
	}

	return strings;
}

Vector<String> split(String& string, char separator) {
	Vector<String> strings;
	String buffer;

	for (int i = 0; i < string.size(); i ++) {
		char chr = string[i];

		if (separator == chr) {
			strings.push(buffer);
			buffer.clear();
			continue;
		}

		buffer.push(chr);
	}
	
	if (buffer.size() > 0) {
		strings.push(buffer);
	}
	
	return strings;
}

Section* createSection(String& head, String& body) {

	String thead = trim(head);
	String tbody = trim(body);

	auto selectors = splitAndTrim<String>(thead, ',');
	auto attributes = splitAndTrim<Attribute>(tbody, ';');

	return new Section {
		selectors,
		attributes
	};

}

void execute(Phase& phase, String& command, BlockList<8, Section>& list) {
	command = trim(command);
	Vector<String> parts = split(command, ',');
	
	if (parts[0] == "****") {
		phase = Phase::HEAD;
		return;
	}
	
	if (parts[0] == "?") {
		std::cout << "? == " << list.entries() << "\n";
		return;
	}
	
	if (parts.size() < 3) {
		//std::cout << "Expected 3 args got: '" << command << "'\n";
		return;
	}
	
	if (parts[1] == "S") {
	
		if (parts[0].isNumber()) {
			int a = parts[0].toInt();
			Section* section = list.get(a - 1);
			
			if (section == nullptr) {
				return;
			}
			
			if (parts[2] == "?") {
				std::cout << a << ",S,? == " << section->getSelectorCount() << "\n";
				return;
			}
			
			if (parts[2].isNumber()) {
				int b = parts[2].toInt();
				String* selector = section->getSelector(b - 1);
				
				if (selector != nullptr) {
					std::cout << a << ",S," << b << " == " << *selector << "\n";
				}
				return;
			}
			
			return;
		}
		
		size_t counter = 0;
		
		list.iterate([&] (Section* value) {
			if (value->getSelector(parts[0]) != nullptr) {
				counter ++;
			}
			
		});
		
		std::cout << parts[0] << ",S,? == " << counter << "\n";	
		return;
	}
	
	if (parts[1] == "A") {
	
		if (parts[0].isNumber()) {
			int a = parts[0].toInt();
			Section* section = list.get(a - 1);
			
			if (section == nullptr) {
				return;
			}
			
			if (parts[2] == "?") {
				std::cout << a << ",A,? == " << section->getAttributeCount() << "\n";
				return;
			}
			
			Attribute* attr = section->getAttribute(parts[2]);
			
			if (attr != nullptr) {
				std::cout << a << ",A," << attr->key << " == " << attr->value << "\n";
				return;
			}
			
			return;
		}
		
		size_t counter = 0;
		
		list.iterate([&] (Section* value) {
			if (value->getAttribute(parts[0]) != nullptr) {
				counter ++;
			}
			
		});
		
		std::cout << parts[0] << ",A,? == " << counter << "\n";	
		return;
	}
	
	if (parts[1] == "E") {
		String* value = nullptr;
		
		list.iterate([&] (Section* section) {
			if (section->getSelector(parts[0]) != nullptr) {
				Attribute* attr = section->getAttribute(parts[2]);
				
				if (attr != nullptr) {
					value = &attr->value;
				}
			}
		});
		
		if (value != nullptr) {
			std::cout << parts[0] << ",E," << parts[2] << " == " << *value << "\n";
		}
		return;
	}
	
	if (parts[1] == "D") {
	
		if (parts[0].isNumber()) {
			int a = parts[0].toInt();
			
			if (parts[2] == "*") {
				if (list.remove(a - 1)) {
					std::cout << parts[0] << ",D,* == deleted\n";
				}
				return;
			}
			
			Section* section = list.get(a - 1);
			
			if (section == nullptr) {
				return;
			}
			
			if (section->removeAttribute(parts[2])) {
				list.remove(a - 1);
			}
			
			std::cout << parts[0] << ",D," << parts[2] << " == deleted\n";
		}
		
		return;
	}
	
}

void parse(Pool<Section>& pool, BlockList<8, Section>& list) {

	Phase phase = Phase::HEAD;
	char chr = 0;
	String head {};
	String body {};

	while (std::cin.get(chr)) {
		//std::cout << "Loaded char in mode " << (int) phase << ": " << (int) chr << "\n";
	
		if (chr < ' ' && chr != '\n') {
			continue;
		}
	
		switch (phase) {

			case Phase::HEAD:
				if (chr != '{') {
					head.push(chr);
					
					if (trim(head) == "????") {
						head.clear();
						phase = Phase::TEST;
					}
				} else {
					body.clear();
					phase = Phase::BODY;
				}
				break;

			case Phase::BODY:
				if (chr != '}') {
					body.push(chr);
				} else {
					Section* section = createSection(head, body);
					pool.add(section);
					list.append(section);
					//section->print();

					head.clear();
					phase = Phase::HEAD;
				}
				break;
				
			case Phase::TEST:
				if (chr == '\n' && head.size() > 0) {
					execute(phase, head, list);
					head.clear();
				} else {
					//if (chr < ' ') {
						head.push(chr);
					//}
				}
				break;

		}
	}

}
