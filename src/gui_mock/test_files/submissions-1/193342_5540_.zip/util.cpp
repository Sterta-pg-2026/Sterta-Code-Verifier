#include "util.hpp"

String trim(String& string) {
	int start = 0, end = string.size() - 1;

	for (int i = 0; i < string.size(); i ++) {
		if (!isspace(string[i])) {
			start = i;
			break;
		}
	}

	for (int i = string.size() - 1; i >= 0; i --) {
		if (!isspace(string[i])) {
			end = i;
			break;
		}
	}

	String copy;

	for (int i = start; i <= end; i ++) {
		copy.push(string[i]);
	}

	return copy;
}
