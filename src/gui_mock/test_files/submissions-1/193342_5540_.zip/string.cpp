
#include "string.hpp"

std::ostream& operator <<(std::ostream& stream, String& string) {
	std::copy(string.dataPtr, string.dataPtr + string.dataSize, std::ostream_iterator<char>(stream, ""));
	return stream;
}

