
#pragma once

#include "vector.hpp"

class String : public Vector<char> {

	public:
	
		friend std::ostream& operator <<(std::ostream& stream, String& string);

		/// pop last char from the string
		void pop() {
			if (this->dataSize > 0) {
				this->dataSize --;
			}
		}

		/// append the given c-string to thie string
		void append(const char* cstr) {
			size_t i = 0;

			while (cstr[i] != 0) {
				push(cstr[i ++]);
			}
		}

		/// c_str() for the poor, remember to delete[]
		char* c_str() const {
			char* str = new char[this->dataSize + 1];

			for (size_t i = 0; i < this->dataSize; i ++) {
				str[i] = this->dataPtr[i];
			}

			str[this->dataSize] = 0;

			return str;
		}
		
		int toInt() {
			char* cstr = c_str();
			int value = atoi(cstr);
			delete[] cstr;
			return value;
		}
		
		bool isNumber() {
			for (int i = 0; i < size(); i ++) {
				if (!isdigit((*this)[i])) return false;
			}
			
			return true;
		}
		
		bool operator== (const char* cstr) {
			int i = 0;
			
			while (cstr[i]) {
				if (i >= size() || (*this)[i] != cstr[i]) {
					return false;
				}
				
				i ++;
			}
			
			return i == size();
		}
		
		bool operator== (String& str) {
			if (str.size() != size()) {
				return false;
			}
			
			for (int i = 0; i < size(); i ++) {
				if (str[i] != (*this)[i]) {
					return false;
				}
			}
			
			return true;
		}

};


