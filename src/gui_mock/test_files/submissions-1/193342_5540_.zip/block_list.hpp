
#pragma once

#include "list.hpp"

template<size_t count, typename T>
struct Block {

	private:

		T* data[count];
		size_t size = 0;
		size_t last = 0;

	public:

		//using Iterator = void (*) (T* value);

		Block() {
			memset(data, 0, count * sizeof(T*));
		}

		size_t length() const {
			return size;
		}

		bool append(T* value) {
			if (last < count) {
				data[last ++] = value;
				size ++;
				return true;
			}

			return false;
		}

		// index starts at 1
		T* getNth(size_t index) {
			size_t counter = 0;

			for (size_t i = 0; i < count; i ++) {
				if (data[i] != nullptr) {
					if (index == counter) return data[i];
					counter ++;
				}
			}

			return nullptr;
		}

		// index starts at 1
		void removeNth(size_t index) {
			size_t counter = 0;

			for (size_t i = 0; i < count; i ++) {
				if (data[i] != nullptr) {
					if (index == counter) {
						size --;
						if (i + 1 == last) last --;
						data[i] = nullptr;
						return;
					}

					counter ++;
				}
			}
		}

//		T* get(size_t index) const {
//			if (index >= count) throw std::out_of_range("Given index falls outside of the block!");
//			return data[index];
//		}
//
//		void set(size_t index, T* value) {
//			T* ptr = get(index);
//			if (value == nullptr && ptr != nullptr) size --;
//			if (value != nullptr && ptr == nullptr) size ++;
//			data[index] = value;
//		}
//
		template<class Iterator>
		void iterate(Iterator iterator) const {
			for (size_t i = 0; i < count; i ++) {
				if (data[i] != nullptr) iterator(data[i]);
			}
		}

};

template<size_t BS, typename T>
class BlockList : public List<Block<BS, T>> {

	size_t _entries = 0;

	public:
 
		T* get(size_t index) const {
			auto* tmp = this->head;

			while (tmp != nullptr) {
				size_t blen = tmp->value.length();

				if (index < blen) {
					return tmp->value.getNth(index);
				} else {
					index -= blen;
				}

				tmp = tmp->next;
			}

			return nullptr;
		}

		bool remove(size_t index) {
			auto* tmp = this->head;

			while (tmp != nullptr) {
				size_t blen = tmp->value.length();
				auto* next = tmp->next;

				if (index < blen) {
					tmp->value.removeNth(index);
					_entries --;
					
					if (tmp->value.length() == 0) {
						this->removeNode(tmp);
					}
					
					return true;
				} else {
					index -= blen;
				}

				tmp = next;
			}
			
			return false;
		}

		void append(T* value) {
			auto* tmp = this->head;

			while (tmp != nullptr) {
				if (tmp->value.append(value)) {
					_entries ++;
					return;
				}

				tmp = tmp->next;
			}

			Block<BS, T> blc {};
			blc.append(value);
			_entries ++;

			this->pushBack(blc);
		}

		template<class Iterator>
		void iterate(Iterator iterator) const {
			auto* tmp = this->head;

			while (tmp != nullptr) {
				tmp->value.iterate(iterator);
				tmp = tmp->next;
			}
		}
		
		size_t entries() {
			return _entries;
		}

};
