#pragma once

template<typename T>
class Pool {

	private:

		Vector<T*> pointers;

	public:

		~Pool() {
			free();
		}

		void free() {
			foreach(pointers, pointer, {
				delete pointer;
			});

			pointers.clear();
		}

		T* add(T* pointer) {
			pointers.push(pointer);
			return pointer;
		}

};
