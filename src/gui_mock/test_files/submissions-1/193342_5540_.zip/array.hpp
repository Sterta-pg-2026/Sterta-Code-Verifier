
#pragma once

#include "external.hpp"

template<typename T>
class Array {

	public:

		T* data;
		size_t size;

	public:

		explicit Array(size_t size) {
			this->data = new T[size];
			this->size = size;
		}

		~Array() {
			delete[] this->data;
			this->size = 0;
		}

		/// resize this array, previous data is deleted
		void replace(size_t size) {
			delete[] this->data;
			this->data = new T[size];
			this->size = size;
		}

		Array(Array&& array) {
			this->data = array.data;
			this->size = array.size;

			array.data = nullptr;
			array.size = 0;
		}

		/// fill the whole array with one value
		void fill(const T& element) {
			for (int i = 0; i < this->size; i ++) {
				this->data[i] = element;
			}
		}

		T& operator[](size_t index) {
			return this->data[index];
		}

};
