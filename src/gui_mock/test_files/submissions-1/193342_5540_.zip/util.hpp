#pragma once

#include "string.hpp"

String trim(String& string);

