
#pragma once

#include "external.hpp"
#define foreach(vector, elem, ...) for (long _i = 0; _i < (vector).size(); _i ++) for(const auto& elem = (vector)[_i]; true;) { __VA_ARGS__; break; }

template<typename T>
class Vector {

	protected:

		T* dataPtr = nullptr;
		size_t dataSize = 0;
		size_t capacity = 0;

		/// resize this buffer to fit length, can be used to shrink the buffer
		void resize(size_t length) {
			T* tmp = new T [length];
			std::copy(dataPtr, dataPtr + dataSize, tmp);
			this->dataPtr = tmp;
			this->capacity = length;
		}

	public:

		using Iterator = void (*) (const T&);

		Vector(size_t initial = 4) {
			this->dataPtr = new T[initial];
			this->dataSize = 0;
			this->capacity = initial;
		}

		Vector(const Vector& vec) : Vector(vec.size()) {
			addAll(vec);
		}
		
		Vector(Vector&& vec) : dataPtr(vec.dataPtr), dataSize(vec.dataSize), capacity(vec.capacity) {
			vec.dataPtr = 0;
			vec.dataSize = 0;
			vec.capacity = 0;
		}

		~Vector() {
			if (dataPtr != nullptr) {
				delete[] (this->dataPtr);
			}
		}

		Vector& operator =(const Vector& src) {
			Vector tmp {src};

			std::swap(tmp.dataPtr, dataPtr);
			std::swap(tmp.dataSize, dataSize);
			std::swap(tmp.capacity, capacity);
			return *this;
		}

		/// add an element to this vector
		void push(const T& element) {
			this->dataPtr[dataSize ++] = element;

			if (this->dataSize == this->capacity) {
				resize(this->capacity * 2);
			}
		}

		/// get data pointer
		T* data() const {
			return this->dataPtr;
		}

		/// get vector size
		size_t size() const {
			return this->dataSize;
		}

		/// shrink to not waste memory
		void shrink() {
			resize(this->dataSize + 1);
		}

		void clear() {
			this->dataSize = 0;
		}

		T& operator[](long index) {
			if (index >= dataSize) {
				throw std::out_of_range("Vector index out of bounds!");
			}
		
			return this->dataPtr[index];
		}

		const T& operator[](long index) const {
			if (index >= dataSize) {
				throw std::out_of_range("Vector index out of bounds!");
			}
		
			return this->dataPtr[index];
		}

		void addAll(const Vector<T>& other) {
			foreach (other, item, {
				push(item);
			});
		}

		void iterate(Iterator iterator) {
			foreach (*this, item, {
				iterator(item);
			});
		}

};
