#pragma once

#include "util.hpp"

struct Attribute {

	String key, value;

	Attribute(String& entry) : key(), value() {
		bool first = true;

		for (int i = 0; i < entry.size(); i ++) {
			char chr = entry[i];

			if (chr == ':') {
				first = false;
				continue;
			}

			if (first) {
				key.push(chr);
			} else {
				value.push(chr);
			}
		}

		key = trim(key);
		value = trim(value);
	}

	void print() {
		const char* a = key.c_str();
		const char* b = value.c_str();

		std::cout << "Attr a=" << a << " b=" << b << "\n";
		delete[] a;
		delete[] b;
	}

};
