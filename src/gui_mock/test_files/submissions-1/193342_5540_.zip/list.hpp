
#pragma once

#include "external.hpp"

template<typename T>
class List {

	public:

		struct Node {
			Node* next;
			Node* prev;
			T value;

			Node(const T& value)
			: value(value), next(nullptr), prev(nullptr) {}
		};

	public:

		Node* head;
		Node* tail;
		size_t size;

		void setInitial(Node* node) {
			this->head = node;
			this->tail = node;
		}

	public:

		List()
		: head(nullptr), tail(nullptr), size(0) {}

		List(const List& vec) : List() {
			Node* tmp = vec.head;

			while (tmp != nullptr) {
				pushBack(tmp->value);
				tmp = tmp->next;
			}
		}

		~List() {
			clear();
		}

		List& operator =(const List& src) {
			List tmp {src};

			std::swap(tmp.head, head);
			std::swap(tmp.tail, tail);
			std::swap(tmp.size, size);
			return *this;
		}

		void clear() {
			while (head != nullptr) {
				Node* tmp = head;
				head = tmp->next;
				delete tmp; // has to use tmp as head->prev may be nullptr
			}
		}
			
		T* get(int index) {
			Node* tmp = head;
			int i = 0;

			while (tmp != nullptr) {
				if (i ++ == index) {
					return &tmp->value;
				}
				
				tmp = tmp->next;
			}
			
			return nullptr;
		}
		
		bool remove(int index) {
			Node* tmp = head;
			int i = 0;
			
			if (index == 0) {
				popFront();
				return true;
			}
			
			if (index == size - 1) {
				popBack();
				return true;
			}

			while (tmp != nullptr) {
				if (i ++ == index) {
					Node* prev = tmp->prev;
					Node* next = tmp->next;
					
					prev->next = next;
					next->prev = prev;
					return true;
				}
				
				tmp = tmp->next;
			}
			
			return false;
		}

		size_t length() {
		    return size;
		}

		size_t empty() {
			return size == 0;
		}

		void pushFront(const T& value) {
			Node* created = new Node(value);
			size ++;

			if (head == nullptr) {
				setInitial(created);
				return;
			}

			// add to list from the front
			created->next = head;
			head->prev = created;
			head = created;
		}

		void pushBack(const T& value) {
			Node* created = new Node(value);
			size ++;

			if (head == nullptr) {
				setInitial(created);
				return;
			}

			// add to list from the back
			created->prev = tail;
			tail->next = created;
			tail = created;
		}

		void popFront() {
			if (head == nullptr) return;
			size--;

			if (head == tail) {
				setInitial(nullptr);
				return;
			}

			Node* tmp = head;
			head = head->next;
			head->prev = nullptr;

			//T value = tmp->value;
			delete tmp;
			//return value;
		}

		void popBack() {
			if (tail == nullptr) return;
			size--;

			if (head == tail) {
				setInitial(nullptr);
				return;
			}

			Node* tmp = tail;
			tail = tail->prev;
			tail->next = nullptr;

			//T value = tmp->value;
			delete tmp;
			//return value;
		}

		template<class Iterator>
		void iterate(Iterator iterator) {
			Node* tmp = head;

			while (tmp != nullptr) {
				iterator(tmp->value);
				tmp = tmp->next;
			}
		}
		
		void removeNode(Node* tmp) {
			if (tmp == head) {
				tmp = tmp->next;
				popFront();
				return;
			}
					
			if (tmp == tail) {
				tmp = tmp->next;
				popBack();
				return;
			}
		
			Node* prev = tmp->prev;
			Node* next = tmp->next;
			
			prev->next = next;
			next->prev = prev;
		}
		
		template<class Iterator>
		void removeIf(Iterator iterator) {
			Node* tmp = head;

			while (tmp != nullptr) {
				Node* next = tmp->next;
			
				if (iterator(tmp->value)) {
					removeNode(tmp);
				}
				
				tmp = next;
			}
			
			
		}
};
