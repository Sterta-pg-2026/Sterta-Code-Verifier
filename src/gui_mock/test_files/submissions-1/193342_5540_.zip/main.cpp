
#include "array.hpp"
#include "list.hpp"
#include "string.hpp"
#include "vector.hpp"
#include "block_list.hpp"
#include "pool.hpp"
#include "section.hpp"
#include "attribute.hpp"
#include "parser.hpp"

int main() {

	Pool<Section> pool;
	BlockList<8, Section> sections;

	parse(pool, sections);

	pool.free();

}
