#pragma once
#include <iostream>
#include "mystring.cpp"
#include "listofattribute.cpp"
#include "listofselector.cpp"
#include "mlist.cpp"

using namespace std;


void selectors(MyString *x,char *b,ListofBlock *mainList,bool *s) {
    MyString tmp;
    MyString p;
    *x = (*x).substring_after('}');
    *x = (*x).removeSpaces(*x);
    *x = (*x).deletesEnter();
    tmp = *x;
    p = *x;
    while (!(tmp == tmp.substring_until(','))) {
        tmp = p.substring_until(',');
        tmp = tmp.removeSpaces(tmp);
        (* mainList).addSelector(tmp);
        tmp = p.substring_after(',');
        p = p.substring_after(',');
        *b = '{';
    }
    tmp = tmp.removeSpaces(tmp);
    (* mainList).addSelector(tmp);
    *s = true;
}

void atribute(MyString* x, char* b, ListofBlock* mainList,bool* h,MyString* atr) {
    MyString tmp;
    MyString p;
    *h = false;
    *x = (* x).substring_after(*b);
    *x =  (* x).substring_after('{');
    tmp = *x;
    p = *x;
    tmp = p.substring_until(':');
    tmp = tmp.substring_after('{');
    *atr = tmp.deletesEnter();
    *atr = (* atr).deleteLeadingSpaces();
    *b = ':';
}
void value1(MyString* x, char* b, ListofBlock* mainList, bool* h, MyString* atr) {
    MyString tmp;
    MyString p;
    MyString val;
    *x = (* x).substring_after(*b);
    tmp = *x;
    p = *x;
    tmp = p.substring_until(';');
    val = tmp.deletesEnter();
    val = val.deleteLeadingSpaces();
    (* mainList).addAttributeAndValue(*atr, val);
    *b = ';';
    *h = true;
    *x = " ";
}

void value2(MyString* x, char* b, ListofBlock* mainList, bool* h, MyString* atr,bool *s) {
    MyString tmp;
    MyString p;
    MyString val;
    *x = (* x).substring_after(*b);
    tmp = *x;
    p = *x;
    tmp = p.substring_until('}');
    val = tmp.deletesEnter();
    val = val.deleteLeadingSpaces();
    *s = false;
    (* mainList).addAttributeAndValue(*atr, val);
    *b = ';';
    *x = " ";
    (*mainList).addSection();
}
void selectorAmount(ListofBlock* mainList, MyString* x) {
    int i;
    *x = (*x).substring_until(',');
    i = (*x).to_int(*x);
    if ((*mainList).numberOfSection() >= i) {
        cout << i << ",S,? == " << (*mainList).sectionInIndex(i).selector->numberOfElements() << endl;
    }
}
void attributeAmount(ListofBlock* mainList, MyString* x) {
    int i;
    *x = (* x).substring_until(',');
    i = (* x).to_int(*x);
    if ((*mainList).numberOfSection() >= i) {
        cout << i << ",A,? == " << (*mainList).sectionInIndex(i).attribute->numberOfElements() << endl;
    }     
}
void AllSectionsSelectorAmount(ListofBlock* mainList, MyString* x) {
    *x = (* x).substring_until(',');
    *x = (*x).deleteLeadingSpaces();

    int i = (* mainList).numberOfSelector(*x);
    cout << *x << ",S,? == " << i << endl;
}
void  AllSectionsAttributeAmount(ListofBlock* mainList, MyString* x) {
    *x = (* x).substring_until(',');
    int i = (* mainList).numberOfAttribute(*x);
    cout << *x << ",A,? == " << i << endl;
}
void selectorOnIndex(ListofBlock* mainList, MyString* x) {
    MyString tmp = *x;
    int i;
    int j;
    *x = (* x).substring_until(',');
    i = (* x).to_int(*x);
    tmp = tmp.substring_after(',');
    tmp = tmp.substring_after(',');
    j = tmp.to_int(tmp);
    if (((*mainList).numberOfSection() >= i) && ((* mainList).sectionInIndex(i).selector->numberOfElements() >= j)) {
        cout << i << ",S," << j << " == " << (* mainList).sectionInIndex(i).selector->nameInThisIndex(j) << endl;
    }
}
void nameOfAttribute(ListofBlock* mainList, MyString* x) {
    MyString tmp = *x;
    int i;
    *x = (* x).substring_until(',');
    i = (* x).to_int(*x);
    tmp = tmp.substring_after(',');
    tmp = tmp.substring_after(',');
    if (((*mainList).numberOfSection() >= i) && ((*mainList).sectionInIndex(i).attribute->ifNameExist(tmp))) {
        cout << i << ",A," << tmp << " == " << (*mainList).sectionInIndex(i).attribute->valueOfName(tmp) << endl;
    }
}
void deleteSectionOnIndex(ListofBlock* mainList, MyString* x) {
    int i;
    *x = (* x).substring_until(',');
    i = (* x).to_int(*x);
    int s = (* mainList).numberOfSection();
    if (s == 1) {
        (* mainList).deleteAll();
        cout << i << ",D,* == deleted" << endl;
        (* mainList).addBack();
    }
    else if (s >= i) {
        (* mainList).delSection(i);
        cout << i << ",D,* == deleted" << endl;
    }

}

void deleteAttribute(ListofBlock* mainList, MyString* x) {
    MyString tmp = *x;
    int i;
    *x = (* x).substring_until(',');
    i = (* x).to_int(*x);
    tmp = tmp.substring_after(',');
    tmp = tmp.substring_after(',');
    if (((* mainList).numberOfSection() >= i) && ((* mainList).sectionInIndex(i).attribute->ifNameExist(tmp))) {
        (* mainList).delAtributeInSection(i, tmp);
        cout << i << ",D," << tmp << " == " << "deleted" << endl;
    }
}

void valueOfAttribute(ListofBlock* mainList, MyString* x) {
    MyString tmp = *x;
    *x = (* x).substring_until(',');
    tmp = tmp.substring_after(',');
    tmp = tmp.substring_after(',');
    MyString v = (* mainList).valueOfAttributeForSelector1(tmp, *x);
    if (!(v == "brak")) {
        cout << *x << ",E," << tmp << " == " << v << endl;
    }
}

int main()
{    ListofBlock mainList;
    mainList.addFront();
    MyString x="\n";
    char sign;
    char b = '{';
    MyString atr;
    bool h = false;
    bool s = false;
    bool cssparse = true;
    int change = 0;
    while (cin.get(sign)) {
          if (cssparse) {    
            if (sign == '{') {
                if (x.deletesSpace().deletesEnter().size()> 1) {
                    selectors(&x, &b, &mainList, &s);
                }
            }
            else if ((sign == ':')&&(s==true)) { 
                atribute(&x, &b, &mainList, &h, &atr);
            }
            else if (sign == ';') {
                value1(&x, &b, &mainList, &h, &atr);
            }
            else if ((sign == '}') && (h == false)) {
                value2(&x, &b, &mainList, &h, &atr, &s);
            }
            else if ((sign == '}') && (h == true)) {
                x = " ";
                mainList.addSection();
                s = false;
            }
            if (sign == '?') {
                change++;
                if (change == 4) {
                    cssparse = false;
                    x = " ";
                }
            }
            else {
                change = 0;
            }
            if (cssparse) {
                x.append(sign);
            }
        }
        else {
            if (sign != '\n') {
                x.append(sign);
            }
            if ((sign == '\n') && (x.size() > 1)) {
                x = x.removeSpaces(x);
                x = x.deletesEnter();
                if (x == "?") {
                    cout << "? == " << mainList.numberOfSection() << endl;
                }
                else if (x == "****") {
                    cssparse = true;
                    x = " ";
                    x.append(sign);
                }
                else if ((x.substring_after(',') == "S,?") && ((isdigit(x[0])))) {
                    selectorAmount(&mainList,&x);
                }
                else if ((x.substring_after(',') == "A,?") && ((isdigit(x[0])))) {
                    attributeAmount(&mainList, &x);
                }
                else if ((x.substring_after(',') == "S,?") && (!(isdigit(x[0])))) {
                    AllSectionsSelectorAmount(&mainList, &x);
                }
                else if ((x.substring_after(',') == "A,?") && (!(isdigit(x[0])))) {
                    AllSectionsAttributeAmount(&mainList, &x);
                }
                else if (x.substring_after(',').substring_until(',') == "S") {
                    selectorOnIndex(&mainList, &x);
                }
                else if (x.substring_after(',').substring_until(',') == "A") {
                    nameOfAttribute(&mainList, &x);
                }
                else if (x.substring_after(',') == "D,*") {
                    deleteSectionOnIndex(&mainList, &x);
                }
                else if (x.substring_after(',').substring_until(',') == "D") {
                    deleteAttribute(&mainList, &x);
                }
                else if (x.substring_after(',').substring_until(',') == "E") {
                    valueOfAttribute(&mainList, &x);
                }
                x = " ";
            }
        }
    }
    mainList.deleteAll();
    return 0;
}


