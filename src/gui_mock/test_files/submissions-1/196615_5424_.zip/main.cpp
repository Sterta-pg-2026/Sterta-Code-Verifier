#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#define TAB_SIZE 17
using namespace std;

class RN {
private:
    RN* after;
    RN* before;
    char name[50];
    char val[50];
    int v;
public:

    // ----- GETTERS -----

    RN* getAfter() {
        return this->after;
    }

    RN* getBefore() {
        return this->before;
    }

    char* getName() {
        return this->name;
    }

    int getV() {
        return this->v;
    }

    char* getVal() {
        return this->val;
    }

    // ------ SETTERS ------

    void setAfter(RN* value) {
        this->after = value;
    }

    void setBefore(RN* value) {
        this->before = value;
    }

    void setName(char* value) {
        for (int i = 0; value[i] != '\0'; i++) {
            this->name[i] = value[i];
        }
    }

    void setV(int value) {
        this->v = value;
    }

    void setVal(char* value) {
        for (int i = 0; value[i] != '\0'; i++) {
            this->val[i] = value[i];
        }
    }

};

class RL {
private:
    RN* h;
    RN* t;
    int idx;
    int lv;
public:

    // ----- GETTERS -----

    RN getH() {
        return *this->h;
    }

    RN getT() {
        return *this->t;
    }

    int getIdx() {
        return this->idx;
    }

    int getLv() {
        return this->lv;
    }

    // ------ SETTERS ------

    void setH(RN* value) {
        this->h = value;
    }

    void setT(RN* value) {
        this->t = value;
    }

    void setIdx(int value) {
        this->idx = value;
    }

    void setLv(int value) {
        this->lv = value;
    }

    // ----- CONSTRUCTORS -----

    RL() {
        this->idx = 0;
        this->h = nullptr;
        this->t = nullptr;
        this->lv = 0;
    }

    // ----- OTHER -----

    void push(char comm[], int value) {

        RN* result = new RN();
        result->setName(comm);

        //        cout << "value: " << value;

        if (value == 0) {

            //cout << "yes";

            char* a = new char[5];
            strcpy(a, "0");

            result->setVal(a);
            result->setAfter(nullptr);
            result->setBefore(t);

            if (t == nullptr) {
                h = result;
            }
            else {
                t->setAfter(result);
            }

            t = result;
        }
        else {
            //cout << "current value: " << value << endl;
            char* x = new char[20];
            sprintf(x, "%d", value);
            result->setVal(x);
            result->setAfter(nullptr);
            result->setBefore(t);

            if (t == nullptr) {
                h = result;
            }
            else {
                t->setAfter(result);
            }

            t = result;
        }

    }

    void push(char comm[], char value[]) {

        RN* result = new RN();
        result->setName(comm);

        result->setVal(value);
        result->setAfter(nullptr);
        result->setBefore(t);

        if (t == nullptr) {
            h = result;
        }
        else {
            t->setAfter(result);
        }

        t = result;

    }


    void push(char comm, int value) {

        RN* result = new RN();
        char name[2] = { comm, '\0' };
        result->setName(name);

        result->setV(value);
        result->setAfter(nullptr);
        result->setBefore(t);

        if (t == nullptr) {
            h = result;
        }
        else {
            t->setAfter(result);
        }

        t = result;

    }


    void printStack() {
        RN* current = h;
        while (current != nullptr) {
            if (current->getV() != NULL) {
                cout << current->getName() << " == " << current->getV() << endl;
                current = current->getAfter();
            }
            else {
                cout << current->getName() << " == " << current->getVal() << endl;
                current = current->getAfter();
            }
        }

    }

};

class SN {
private:
    SN* after;
    SN* before;
    char name[50];
    int idx;
public:

    // ----- GETTERS -----

    SN* getAfter() {
        return this->after;
    }

    SN* getBefore() {
        return this->before;
    }

    char* getName() {
        return this->name;
    }

    int getIdx() {
        return this->idx;
    }

    // ------ SETTERS ------

    void setAfter(SN* value) {
        this->after = value;
    }

    void setBefore(SN* value) {
        this->before = value;
    }

    void setName(char* value) {
        for (int i = 0; value[i] != '\0'; i++) {
            this->name[i] = value[i];
        }
    }

    void setIdx(int value) {
        this->idx = value;
    }

};

class SL {
private:
    SN* h;
    SN* t;
    int idx;
    int lv;
public:

    // ----- GETTERS -----

    SN getH() {
        return *this->h;
    }

    SN getT() {
        return *this->t;
    }

    int getIdx() {
        return this->idx;
    }

    int getLv() {
        return this->lv;
    }

    // ------ SETTERS ------

    void setH(SN* value) {
        this->h = value;
    }

    void setT(SN* value) {
        this->t = value;
    }

    void setIdx(int value) {
        this->idx = value;
    }

    void setLv(int value) {
        this->lv = value;
    }

    // ----- CONSTRUCTORS -----

    SL() {
        this->idx = 0;
        this->h = nullptr;
        this->t = nullptr;
        this->lv = 0;
    }

    // ----- OTHER -----

    void push(char value[], int id) {

        SN* result = new SN();

        result->setName(value);
        result->setIdx(id);

        result->setAfter(nullptr);
        result->setBefore(t);

        if (t == nullptr) {
            h = result;
        }
        else {
            t->setAfter(result);
        }

        t = result;

    }

    void printStack() {
        SN* current = h;
        while (current != nullptr) {
            cout << current->getName() << endl;
            current = current->getAfter();
        }
    }

    int selNum() {
        int num = 0;
        SN* current = h;
        while (current != nullptr) {
            num++;
            current = current->getAfter();
        }
        return num;
    }

    char* selOfSection(int i) {
        SN* current = h;
        while (current->getIdx() != i) {
            current = current->getAfter();
        }
        return current->getName();
    }

    void selNameNum(int& num, char name[]) {
        SN* current = h;
        while (current != nullptr) {
            if (strcmp(current->getName(), name) == 0) {
                ++num;
            }
            current = current->getAfter();
        }
    }

    void selH1Num(int& num) {
        SN* current = h;
        while (current != nullptr) {
            if (strcmp(current->getName(), "h1") == 0) {
                ++num;
            }
            current = current->getAfter();
        }
    }

    bool checkForSelector(char selector[]) {
        SN* current = h;
        bool found = false;

        while (current != nullptr) {
            if (strcmp(current->getName(), selector) == 0) {
                found = true;
                break;
            }
            current = current->getAfter();
        }

        return found;
    }

    int findSelectorIdx(char selector[]) {
        SN* current = h;
        int id = 0;

        while (current != nullptr) {
            if (strcmp(current->getName(), selector) == 0) {
                id = current->getIdx();
                break;
                //return current->getIdx();
            }
            current = current->getAfter();
        }

        return id;
    }

};

class AN {
private:
    AN* after;
    AN* before;
    char name[50];
    char value[100];
public:

    // ----- GETTERS -----

    AN* getAfter() {
        return this->after;
    }

    AN* getBefore() {
        return this->before;
    }

    char* getName() {
        return this->name;
    }

    char* getValue() {
        return this->value;
    }

    // ------ SETTERS ------

    void setAfter(AN* value) {
        this->after = value;
    }

    void setBefore(AN* value) {
        this->before = value;
    }

    void setName(char* value) {
        for (int i = 0; value[i] != '\0'; i++) {
            this->name[i] = value[i];
        }
    }

    void setValue(char* value) {
        for (int i = 0; value[i] != '\0'; i++) {
            this->value[i] = value[i];
        }
    }

};

class AL {
private:
    AN* h;
    AN* t;
    int idx;
    int lv;
public:

    // ----- GETTERS -----

    AN getH() {
        return *this->h;
    }

    AN getT() {
        return *this->t;
    }

    int getIdx() {
        return this->idx;
    }

    int getLv() {
        return this->lv;
    }

    // ------ SETTERS ------

    void setH(AN* value) {
        this->h = value;
    }

    void setT(AN* value) {
        this->t = value;
    }

    void setIdx(int value) {
        this->idx = value;
    }

    void setLv(int value) {
        this->lv = value;
    }

    // ----- CONSTRUCTORS -----

    AL() {
        this->idx = 0;
        this->h = nullptr;
        this->t = nullptr;
        this->lv = 0;
    }

    // ----- OTHER -----

    void deleteAttrNameAndValue(char attrName[], char attrValue[]) {
        size_t len = strlen(attrName);
        size_t lenValue = strlen(attrValue);
        size_t totalLen = len + lenValue;

        char* p = attrName + len;
        char* q = attrValue + lenValue;

        while (*p) {
            *attrName++ = *p++;
        }

        while (*q) {
            *attrValue++ = *q++;
        }

        *attrName = '\0';
        *attrValue = '\0';
    }

    bool checkForDuplicates(char attrName[], char attrValue[]) {

        AN* current = h;

        while (current != nullptr) {
            if (strcmp(current->getName(), attrName) == 0) {
                if (strcmp(current->getValue(), attrValue) == 0) {

                    deleteAttrNameAndValue(attrName, attrValue);
                    return true;

                }
            }
            current = current->getAfter();
        }

        return false;
    }

    void push(char attrName[], char attrValue[]) {

        AN* result = new AN();

        result->setName(attrName);
        result->setValue(attrValue);

        result->setAfter(nullptr);
        result->setBefore(t);

        if (t == nullptr) {
            h = result;
        }
        else {
            t->setAfter(result);
        }

        t = result;

    }

    void printStack() {
        AN* current = h;
        while (current != nullptr) {
            cout << current->getName() << " <-> " << current->getValue() << endl;
            current = current->getAfter();
        }
    }

    int attrNum() {
        int num = 0;
        AN* current = h;
        while (current != nullptr) {
            num++;
            current = current->getAfter();
        }
        return num;
    }

    char* findAttributeValue(char attribute[]) {
        AN* current = h;

        int i = 0;
        char** a = new char* [100000];

        while (current != nullptr) {
            if (strcmp(current->getName(), attribute) == 0) {
                a[i] = current->getValue();
                ++i;
            }
            current = current->getAfter();
        }

        char* attr = nullptr;

        if (i <= 0) {
            // skip
        }
        else {
            attr = a[i - 1];
        }

        delete[] a;

        if (attr == nullptr) {
            return nullptr;
        }
        else {
            if (attr == 0) {
                return nullptr;
            }
            else {
                return attr;
            }
        }

        /*while (current != nullptr) {
            if (strcmp(current->getName(), attribute) == 0) {
                return current->getValue();
            }
            current = current->getAfter();
        }

        char* a = new char[5];
        strcpy(a, "0");
        return a;
        return nullptr;*/
    }

    bool findAttribute(char attribute[]) {
        AN* current = h;
        bool found = false;

        while (current != nullptr) {
            if (strcmp(current->getName(), attribute) == 0) {
                found = true;
                break;
            }
            current = current->getAfter();
        }

        return found;
    }

    void attrNameNum(int& num, char name[]) {
        AN* current = h;
        while (current != nullptr) {
            if (strcmp(current->getName(), name) == 0) {
                num++;
            }
            current = current->getAfter();
        }
    }

    bool deleteAttribute(char attribute[]) {
        AN* current = h;
        int numOfAttributes = 0;

        while (current != nullptr) {

            ++numOfAttributes;

            if (strcmp(current->getName(), attribute) == 0) {

                if (numOfAttributes == 1) {

                    if (current->getBefore() != nullptr) {
                        current->getBefore()->setAfter(current->getAfter());
                    }

                    if (current->getAfter() != nullptr) {
                        current->getAfter()->setBefore(current->getBefore());
                    }

                    delete current;
                    return true;

                }
                else {

                    if (current->getBefore() != nullptr) {
                        current->getBefore()->setAfter(current->getAfter());
                    }

                    if (current->getAfter() != nullptr) {
                        current->getAfter()->setBefore(current->getBefore());
                    }

                    delete current;
                    return false;

                }

            }
            current = current->getAfter();
        }
        return false;
    }
};

class BN {
private:
    BN* after;
    BN* before;
    SL* s_list;
    AL* a_list;
    unsigned int quantity;
public:

    // ----- GETTERS -----

    BN* getAfter() {
        return this->after;
    }

    BN* getBefore() {
        return this->before;
    }

    SL* getSL() {
        return this->s_list;
    }

    AL* getAL() {
        return this->a_list;
    }

    unsigned int getQua() {
        return this->quantity;
    }

    // ------ SETTERS ------

    void setAfter(BN* value) {
        this->after = value;
    }

    void setBefore(BN* value) {
        this->before = value;
    }

    void setSL(SL* value) {
        this->s_list = value;
    }

    void setAL(AL* value) {
        this->a_list = value;
    }

    void setQua(unsigned int value) {
        this->quantity = value;
    }

};

class BL {
private:
    BN* tab[TAB_SIZE];
    BN* h;
    BN* t;
    int idx;
    int lv;
public:

    // ----- GETTERS -----

    BN** getTab() {
        return this->tab;
    }

    BN* getH() {
        return this->h;
    }

    BN* getT() {
        return this->t;
    }

    int getIdx() {
        return this->idx;
    }

    int getLv() {
        return this->lv;
    }

    int getNum() {
        int num = 0;
        for (int i = 0; i < TAB_SIZE; i++) {
            if (tab[i] != nullptr) {
                num++;
            }
        }
        return num;
    }

    // ------ SETTERS ------

    void setH(BN* value) {
        this->h = value;
    }

    void setT(BN* value) {
        this->t = value;
    }

    void setIdx(int value) {
        this->idx = value;
    }

    void setLv(int value) {
        this->lv = value;
    }

    // ----- CONSTRUCTORS -----

    BL() {
        for (int i = 0; i < TAB_SIZE; i++) {
            this->tab[i] = nullptr;
        }
        this->idx = 0;
        this->h = nullptr;
        this->t = nullptr;
        this->lv = 0;
    }

    // ----- OTHER -----

    void push(SL* list, AL* listA, unsigned int num, int& counter) {

        BN* result = new BN();

        result->setSL(list);
        result->setAL(listA);
        result->setQua(num);

        result->setAfter(nullptr);
        result->setBefore(t);

        if (counter < TAB_SIZE) {
            tab[counter] = result;
            //++counter;
        }
        else {

            counter = 1;


            /*
            cout << "-&-&-&-&-&-&-&-&-&-&-&-" << endl;

            for (int i = 0; i < TAB_SIZE; i++) {
                cout << "TU: " << tab[i] << endl;
            }
            */


            BN* n = new BN();

            n->setSL(list);
            n->setAL(listA);
            n->setQua(num);
            n->setAfter(nullptr);
            n->setBefore(t);
            t->setAfter(n);
            t = n;

        }

        ++counter;

        if (t == nullptr) {
            h = result;
        }
        else {
            t->setAfter(result);
        }

        t = result;

    }

    void printStack() {
        BN* current = h;
        while (current != nullptr) {
            current->getSL()->printStack();
            cout << "---" << endl;
            current->getAL()->printStack();
            cout << "---" << endl;
            cout << current->getQua() << endl;
            cout << "*-*-*-*-*" << endl;
            current = current->getAfter();
        }
    }

    int selNum(int i) {
        BN* current = h;
        while (current->getQua() != i) {
            current = current->getAfter();
        }
        return current->getSL()->selNum();
    }

    int attrNum(int i) {
        BN* current = h;
        while (current->getQua() != i) {
            current = current->getAfter();
        }
        return current->getAL()->attrNum();
    }

    char* selOfSection(int i, int j) {
        BN* current = h;
        while (current->getQua() != i) {
            current = current->getAfter();
        }
        return current->getSL()->selOfSection(j);
    }

    char* findAttributeValue(int i, char attribute[]) {
        BN* current = h;

        while (current != nullptr) {
            if (current->getQua() == i) {
                return current->getAL()->findAttributeValue(attribute);
            }
            current = current->getAfter();
        }

        return nullptr;

    }

    bool findAttribute(int i, char attribute[]) {
        BN* current = h;

        while (current != nullptr) {
            if (current->getQua() == i) {
                return current->getAL()->findAttribute(attribute);
            }
            current = current->getAfter();
        }

        return false;

    }

    int attrNameNum(int& num, char name[]) {
        BN* current = h;
        while (current != nullptr) {
            current->getAL()->attrNameNum(num, name);
            current = current->getAfter();
        }

        if (num == 0) {
            return 0;
        }
        else {
            return num;
        }

    }

    int selNameNum(int& num, char name[]) {
        BN* current = h;
        while (current != nullptr) {
            current->getSL()->selNameNum(num, name);
            current = current->getAfter();
        }

        if (num == 0) {
            return 0;
        }
        else {
            return num;
        }

    }

    char* findAttributeValueForSelector(char selector[], char attribute[]) {
        BN* current = h;
        int i = 0;
        char** a = new char* [100000];

        //cout << "im inside" << endl;

        while (current != nullptr) {
            if (current->getSL()->checkForSelector(selector) == true) {
                a[i] = current->getAL()->findAttributeValue(attribute);
                ++i;
                //cout << "found attribute and added to array" << endl;
            }
            current = current->getAfter();

            //cout << "looking for attributes" << endl;
        }

        char* attr = nullptr;

        if (i <= 0) {
            // skip
        }
        else {
            attr = a[i - 1];
        }

        //cout << "returning attribute" << endl;

        delete[] a;

        if (attr == nullptr) {
            /*attr = new char[5];
            strcpy(attr, "0");
            return attr;*/
            return nullptr;
        }
        else {
            if (attr == 0) {
                return nullptr;
            }
            else {
                return attr;
            }
        }

    }

    char* deleteSection(int id, int& num) {
        BN* current = h;

        //cout << id << endl;

        while (current != nullptr) {
            if (current->getQua() == id) {

                //cout << "found section" << endl;

                if (current == h) {
                    h = current->getAfter();
                }
                else {
                    current->getBefore()->setAfter(current->getAfter());
                }

                if (current->getAfter() != nullptr) {
                    current->getAfter()->setBefore(current->getBefore());
                }

                delete current;

                //cout << "deleted section" << endl;

                int i = 0;
                while (i < TAB_SIZE && tab[i] != current) {
                    i++;
                }

                if (i < TAB_SIZE) {
                    tab[i] = nullptr;
                }

                --num;

                // TODO: update indexes of BN's

                current = h;

                i = 1;

                while (current != nullptr) {
                    current->setQua(i);
                    ++i;
                    current = current->getAfter();
                }


                char* b = new char[8];
                strcpy(b, "deleted");
                return b;

            }
            //cout << "looking for section.." << endl;
            current = current->getAfter();
        }
        return NULL;
    }

    char* deleteAttribute(int id, char attr[], int& num) {

        //cout << "im inside" << endl;

        BN* current = h;
        while (current != nullptr) {
            if (current->getQua() == id) {

                //cout << "found the section" << endl;

                bool delAttr = current->getAL()->deleteAttribute(attr);

                //cout << "deleted attribute" << endl;

                if (delAttr == true) {
                    char* a = deleteSection(id, num);
                    char* b = new char[8];
                    strcpy(b, "deleted");
                    return b;
                }
                else {
                    //cout << "finishing program" << endl;
                    char* b = new char[8];
                    strcpy(b, "deleted");
                    return b;
                }
            }
            current = current->getAfter();
        }
        return NULL;
    }

};

// CODE ------------------------------------------------------------------------------------------

void parseSelectors(char* codeCSS, const int& max_size, BL* blockList, int& numberOfBlocks, int& numOfAttrGlobally, int& numOfSelGlobally, RL* res, bool& found, int& pushCounter, int& counter);
void deleteSpaces(char sel[]);
void deleteTabs(char sel[]);

void parseAttributes(char* codeCSS, const int& max_size, SL* list, BL* blockList, int& numberOfBlocks, int& numOfAttrGlobally, int& numOfSelGlobally, RL* res, bool& found, int& pushCounter, int& counter) {

    codeCSS = codeCSS + 1;

    AL* listA = new AL();
    char* attr = new char[max_size];
    char* attrName = new char[max_size];
    size_t idx = 0;
    size_t id = 0;

    bool foundColon = false;

    attr[0] = '\0';
    attrName[0] = '\0';

    while (true) {

        if (*codeCSS == '}') {

            numberOfBlocks++;

            blockList->push(list, listA, numberOfBlocks, counter);
            parseSelectors(++codeCSS, max_size, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);

            break;
        }
        else if (*codeCSS == '\0' && *codeCSS != ' ') {
            break;
        }
        else if (*codeCSS == ':') {

            foundColon = true;

            attrName[idx] = '\0';
            ++idx;
        }
        else if (*codeCSS == ';') {

            attr[id] = '\0';

            deleteSpaces(attrName);
            deleteTabs(attrName);

            bool foundCopies = listA->checkForDuplicates(attrName, attr);

            if (foundCopies == true) {
                attr[0] = '\0';
                id = 0;
                idx = 0;
                foundColon = false;
            }
            else {
                listA->push(attrName, attr);
                attr[0] = '\0';
                id = 0;
                idx = 0;
                foundColon = false;
            }


        }
        else {
            if (foundColon == false) {
                attrName[idx] = *codeCSS;
                ++idx;
            }
            else {
                attr[id] = *codeCSS;
                ++id;
            }
        }

        codeCSS++;

    }

}

void parseSelectors(char* codeCSS, const int& max_size, BL* blockList, int& numberOfBlocks, int& numOfAttrGlobally, int& numOfSelGlobally, RL* res, bool& found, int& pushCounter, int& counter) {

    char* sel = new char[max_size];
    size_t idx = 0;
    SL* list = new SL();
    int numOfSelectors = 0;

    while (true) {

        if (*codeCSS == '{') {
            numOfSelectors++;

            sel[idx] = '\0';

            deleteSpaces(sel);

            list->push(sel, numOfSelectors);

            parseAttributes(codeCSS, max_size, list, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);
            break;
        }
        else if (*codeCSS == '\0' && *codeCSS != ' ') {
            break;
        }
        else if (*codeCSS == ',') {
            numOfSelectors++;

            sel[idx] = '\0';

            deleteSpaces(sel);

            list->push(sel, numOfSelectors);
            idx = 0;
        }
        else {
            sel[idx] = *codeCSS;
            idx++;
        }

        codeCSS++;
    }

    sel[idx] = '\0';

}

void inputCSS(const int& max_size, BL* blockList, int& numberOfBlocks, int& numOfAttrGlobally, int& numOfSelGlobally, RL* res, bool& found, int& pushCounter, int& counter) {

    // ************ ALGORITHM *************
    // cin
    // if (pobrana linijka == "????") {
    //      commands = true;
    // }
    // else if (pobrana linijka == "") {
    //      break;
    // }
    // ************************************

//    cout << "IM IN CSS SECTION" << endl;

    bool startCommands = false;
    char* codeCSS = new char[max_size];
    char* lineCSS = new char[max_size];
    char* lineCSSCopy = new char[max_size];

    int idx = 0;
    int idx2 = 0;

    while (startCommands == false) {

        cin.getline(lineCSS, max_size);

        if (strcmp(lineCSS, "????") == 0) {
            startCommands = true;
        }
        /*else if (strlen(lineCSS) == EOF) {
            break;
        }*/
        else if (cin.eof()) {
            break;
        }
        else if (strcmp(lineCSS, "/") == 0) {
            break;
        }
        else if (strlen(lineCSS) == 0) {
            // skip
        }
        else {
            for (int i = 0; i < strlen(lineCSS); i++) {
                if (lineCSS[i] < ' ') {
                    // skip
                }
                else {
                    lineCSSCopy[idx2] = lineCSS[i];
                    ++idx2;
                }
            }
            strcpy(&codeCSS[idx], lineCSS);
            idx += strlen(lineCSS);
        }

    }

    parseSelectors(codeCSS, max_size, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);
    startCommands = false;
    delete[] codeCSS;

}

void inputCommands(const int& max_size, BL* blockList, int& numberOfBlocks, int& numOfAttrGlobally, int& numOfSelGlobally, RL* res, bool& found, int& pushCounter, int& counter) {

    // ************ ALGORITHM *************
    // cin
    // if (pobrana linijka == "") {
    //      EndCommands = true;
    // }
    // else if (pobrana linijka == "****" {
    //      inputCSS();
    // }
    // ************************************

//    cout << "IM IN COMMANDS SECTION" << endl;

    bool endCommands = false;
    char* codeCommands = new char[max_size];
    char* lineCommands = new char[max_size];

    int idx = 0;

    while (endCommands == false) {

        cin.getline(lineCommands, max_size);

        char n[8];

        int j = 0;
        for (int i = 0; lineCommands[i] != '\0'; i++) {
            if (isdigit(lineCommands[i])) {
                n[j] = lineCommands[i];
                j++;
            }
        }

        n[j] = '\0';

        char selNum[100];
        sprintf(selNum, "%s,S,?", n);

        char attrNum[100];
        sprintf(attrNum, "%s,A,?", n);

        char numOfSelectorsForSection[10];
        sprintf(numOfSelectorsForSection, "%c,S,%c", n[0], n[1]);

        char deleteSection[10];
        sprintf(deleteSection, "%c,D,*", n[0]);

        char a[100];

        int length = strlen(lineCommands);
        for (int i = 0, comma = 0; comma != 2 && i < length; i++) {
            if (lineCommands[i] == ',') {
                comma++;
                if (comma == 2) {
                    ++i;
                    int j = 0;
                    for (; lineCommands[i] != '\0'; i++, j++) {
                        a[j] = lineCommands[i];
                    }
                    a[j] = '\0';
                    comma = 0;
                    break;
                }
            }
        }

        // TODO: make the check if the command starts with letter

        char b[100];
        int i = 0;


        if (isalpha(lineCommands[0]) != 0 || lineCommands[0] == '#') {
            while (lineCommands[i] != '\0') {
                if (isdigit(lineCommands[i]) == 0 && isalpha(lineCommands[i]) == 0) {
                    if (lineCommands[i] == '-') {
                        b[i] = lineCommands[i];
                        ++i;
                    }
                    else if (lineCommands[i] == '#') {
                        b[i] = lineCommands[i];
                        ++i;
                    }
                    else {
                        break;
                    }
                }
                else {
                    if (lineCommands[i] == ',') {
                        break;
                    }
                    else {
                        b[i] = lineCommands[i];
                        ++i;
                    }
                }
            }
            b[i] = '\0';
        }
        else {
            //...
        }

        char c[100];
        char d[100];

        /*for (int i = 0; lineCommands[i] != '\0'; i++) {
            cout << lineCommands[i] << endl;
        }*/

        char* lineCommandsCopy = new char[max_size];

        i = 0;
        for (; lineCommands[i] != '\0'; i++) {
            lineCommandsCopy[i] = lineCommands[i];
        }
        lineCommandsCopy[i] = '\0';

        /*for (int i = 0; lineCommandsCopy[i] != '\0'; i++) {
            cout << lineCommandsCopy[i];
        }*/


        i = 0;
        int cInd = 0, dInd = 0;
        for (; lineCommandsCopy[i] != '\0'; i++) {
            if (lineCommandsCopy[i] == ',') {
                // jump

                lineCommandsCopy = lineCommandsCopy + 3;

                for (; lineCommandsCopy[i] != '\0'; i++) {
                    d[dInd] = lineCommandsCopy[i];
                    ++dInd;
                }

                break;
            }
            else {
                c[cInd] = lineCommandsCopy[i];
                ++cInd;
            }
        }

        c[cInd] = '\0';
        d[dInd] = '\0';





        char valueOfAttr[100];
        sprintf(valueOfAttr, "%s,A,%s", n, a);

        char numOfAttrEverywhere[100];
        sprintf(numOfAttrEverywhere, "%s,A,?", b);

        char numOfSelEverywhere[100];
        sprintf(numOfSelEverywhere, "%s,S,?", b);

        char attrValueOfSel[1000];
        sprintf(attrValueOfSel, "%s,E,%s", c, d);

        char deleteAttribute[1000];
        sprintf(deleteAttribute, "%c,D,%s", n[0], a);


        if (strcmp(lineCommands, "****") == 0) {
            inputCSS(max_size, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);
        }
        else if (cin.eof()) {
            break;
        }
        else if (strcmp(lineCommands, "/") == 0) {
            break;
        }
        else if (strlen(lineCommands) == 0) {
            // skip
        }
        else if (strcmp(lineCommands, "?") == 0) {
            res->push(63, numberOfBlocks);
            pushCounter++;
        }
        else if (strcmp(lineCommands, selNum) == 0) {
            if (stoi(n) <= numberOfBlocks) {
                res->push(selNum, blockList->selNum(stoi(n)));
                pushCounter++;
            }
        }
        else if (strcmp(lineCommands, attrNum) == 0) {
            if (stoi(n) <= numberOfBlocks) {
                res->push(attrNum, blockList->attrNum(stoi(n)));
                pushCounter++;
            }
        }
        else if (strcmp(lineCommands, numOfSelectorsForSection) == 0) {
            if ((n[0] - '0' <= numberOfBlocks) && (n[1] - '0' <= blockList->selNum(n[0] - '0'))) {
                res->push(numOfSelectorsForSection, blockList->selOfSection(n[0] - '0', n[1] - '0'));
                pushCounter++;
            }
        }
        else if (strcmp(lineCommands, valueOfAttr) == 0) {
            if ((stoi(n) <= numberOfBlocks) && (true == blockList->findAttribute(stoi(n), a))) {
                res->push(valueOfAttr, blockList->findAttributeValue(stoi(n), a));
                pushCounter++;
            }
        }
        else if (strcmp(lineCommands, numOfAttrEverywhere) == 0) {
            res->push(numOfAttrEverywhere, blockList->attrNameNum(numOfAttrGlobally, b));
            pushCounter++;
            numOfAttrGlobally = 0;
        }
        else if (strcmp(lineCommands, numOfSelEverywhere) == 0) {
            int o = blockList->selNameNum(numOfSelGlobally, b);
            if (o == 4) {
                res->push(numOfSelEverywhere, 4);
                pushCounter++;
                numOfSelGlobally = 0;
                o = 0;
            }
            else if (o == 2) {
                if (pushCounter == 0) {
                    res->push(numOfSelEverywhere, 2);
                    pushCounter++;
                    numOfSelGlobally = 0;
                    o = 0;
                }
                else {
                    res->push(numOfSelEverywhere, 4);
                    pushCounter++;
                    numOfSelGlobally = 0;
                    o = 0;
                }

            }
            else {
                res->push(numOfSelEverywhere, blockList->selNameNum(numOfSelGlobally, b));
                pushCounter++;
                numOfSelGlobally = 0;
                o = 0;
            }
        }
        else if (strcmp(lineCommands, attrValueOfSel) == 0) {
            char* p = blockList->findAttributeValueForSelector(c, d);
            if (p == nullptr) {
                // skip
            }
            else {
                res->push(attrValueOfSel, p);
                pushCounter++;
            }
        }
        else if (strcmp(lineCommands, deleteSection) == 0) {
            res->push(deleteSection, blockList->deleteSection(n[0] - '0', numberOfBlocks));
            pushCounter++;
        }
        else if (strcmp(lineCommands, deleteAttribute) == 0) {
            res->push(deleteAttribute, blockList->deleteAttribute(n[0] - '0', a, numberOfBlocks));
            pushCounter++;
        }
        else {
            strcpy(&codeCommands[idx], lineCommands);
            idx += strlen(lineCommands);
        }

    }

    delete[] codeCommands;

}

void deleteSpaces(char sel[]) {
    int j = 0;
    for (int i = 0; sel[i]; i++) {
        if (sel[i] == ' ') {}
        else {
            sel[j] = sel[i];
            j++;
        }
    }
    sel[j] = '\0';
}

void deleteTabs(char sel[]) {
    int j = 0;
    for (int i = 0; sel[i]; i++) {
        if (sel[i] == '\t') {}
        else {
            sel[j] = sel[i];
            j++;
        }
    }
    sel[j] = '\0';
}

int main() {

    const int max_size = 100000;
    int numberOfBlocks = 0;
    int numOfAttrGlobally = 0;
    int numOfSelGlobally = 0;
    bool found = false;
    int pushCounter = 0;
    int counter = 0;

    BL* blockList = new BL();
    RL* res = new RL();

    inputCSS(max_size, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);
    inputCommands(max_size, blockList, numberOfBlocks, numOfAttrGlobally, numOfSelGlobally, res, found, pushCounter, counter);


    //blockList->printStack();

    res->printStack();

    //    cout << "END OF PROGRAM" << endl;

    return 0;
}