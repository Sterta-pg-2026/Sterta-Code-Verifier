#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include<stdio.h>
#include <stdlib.h>
#define MAX 99

typedef struct section section;
typedef struct list list;

struct section {
    char name[MAX];
    list* down;
    section* next;
    section* prev;
};

struct list {
    char name[MAX];
    char value[MAX];
    list* down;
};

void findlastvalue(section* , char [], char []);
section* updateEND(section* );
bool deleteattribute(section* , int , char []);
int countallselectors(section* , char []);
int countsectionswithattribute(section*, char[]);
section** deletesection(section*, int, int*,bool);
void printvalue(section*, int, char[]);
int chartoint(char[]);
int countattributes(section*, int);
int countselectors(section*, int);
void printselector(section*, int, int);
void readcommands(section**, section**, bool*, int*);
section* addsection(section*, char[]);
section* addattribute(section*, char[], char[]);
void cleartable(char*);

int main()
{
    bool isCSSuploaded = 1, isSection = 1, isNewAttributeadded = 0, isEND = 1;
    char nametable[MAX], valuetable[MAX];
    section* cssBEG = NULL;
    section* cssEND = NULL;
    int numberofsections = 0;
    while (isEND) {
        if (feof(stdin))
        {
            isEND = 0;
        }
        cleartable(nametable);
        if (isCSSuploaded == 1) {
            if (isSection) {
                for (int i = 0; i < MAX; i++) {
                    if (i > 3) {
                        if (nametable[i - 1] == '?' && nametable[i - 2] == '?' && nametable[i - 3] == '?' && nametable[i - 4] == '?') {
                            isCSSuploaded = 0;
                            break;
                        }
                    }
                    scanf("%c", &nametable[i]);
                    
                    if (nametable[i] == '{') {
                        cssBEG = addsection(cssBEG, nametable);
                        cssEND = updateEND(cssBEG);
                        isSection = 0;
                        numberofsections++;
                        break;
                    }
                }
            }
            else {
                cleartable(valuetable);
                for (int i = 0; i < MAX; i++) {
                    isNewAttributeadded = 0;
                    scanf_s("%c", &nametable[i], MAX);
                    if (nametable[i] == ':') {
                        for (int j = 0; j < MAX; j++) {
                            scanf_s("%c", &valuetable[j], MAX);
                            if (valuetable[j] == ';') {
                                cssBEG = addattribute(cssBEG, nametable, valuetable);
                                isNewAttributeadded = 1;
                                break;
                            }
                        }
                        if (isNewAttributeadded) {
                            break;
                        }
                    }
                    else if (nametable[i] == '}') {
                        isSection = 1;
                        break;
                    }
                }
            }
        }
        else {
            readcommands(&cssBEG,&cssEND, &isCSSuploaded, &numberofsections);
        }
    }
}

void readcommands(section** BEG, section** END, bool* isCSSuploaded, int* numberofsections) {
    char comm1[MAX], comm2 = NULL, comm3[MAX];
    bool deletesec = 0;
    int j = 0, n = 0;
    cleartable(comm1);
    cleartable(comm3);
    for (int i = 0; i < MAX; i++) {
        if (comm3[j] == '\n') {
            break;
        }
        j = 0;
        scanf("%c", &comm1[i]);
        if (comm1[i] == '?') {
            printf("? == %i\n", *numberofsections);
            break;
        }
        if (comm1[i] == ',') {
            scanf_s("%c,", &comm2, MAX);
            for (j; j < MAX; j++) {
                scanf_s("%c", &comm3[j], MAX);
                if (comm3[j] == '\n') {
                    break;
                }
            }
        }
        if (i > 3) {
            if (comm1[i - 1] == '*' && comm1[i - 2] == '*' && comm1[i - 3] == '*' && comm1[i - 4] == '*') {
                *isCSSuploaded = 1;
                break;
            }
        }
    }
    if (comm2 == 'S') {
        n = chartoint(comm1);
        if (comm3[0] == '?') {
            if (n > 0) {
                if (countselectors(*BEG, n) != 0) {
                    printf("%i,S,? == %i\n", n, countselectors(*BEG, n));
                }
            }
            else {
                for (int i = 0; i < MAX; i++) {
                    if (comm1[i] == ',') {
                        break;
                    }
                    else if (comm1[i] == '\n') {

                    }
                    else {
                        printf("%c", comm1[i]);
                    }
                }
                printf(",S,? == %i\n", countallselectors(*BEG, comm1));
            }
        }
        else {
            int s = chartoint(comm3);
            printselector(*BEG, n, s);
        }
    }
    if (comm2 == 'A') {
        if (comm3[0] == '?') {
            n = chartoint(comm1);
            if (n > 0) {
                int count = countattributes(*BEG, n);
                if (count >= 0) {
                    printf("%i,A,? == %i\n", n, count);
                }
            }
            else {
                for (int i = 0; i < MAX; i++) {
                    if (comm1[i] == ',') {
                        break;
                    }
                    else {
                        printf("%c", comm1[i]);
                    }
                }
                printf(",A,? == %i\n", countsectionswithattribute(*BEG, comm1));
            }
        }
        else {
            n = chartoint(comm1);
            printvalue(*BEG, n, comm3);
        }
    }
    if (comm2 == 'D') {
        if (comm3[0] == '*') {
            n = chartoint(comm1);
            *BEG = *deletesection(*BEG, n, numberofsections, 1);
            *END = updateEND(*BEG);
        }
        else {
            n = chartoint(comm1);
            deletesec = deleteattribute(*BEG, n, comm3);
            if (deletesec) {
                *BEG = *deletesection(*BEG, n, numberofsections, 0);
            }
            *END = updateEND(*BEG);
        }
    }
    if (comm2 == 'E') {
        findlastvalue(*END,comm1,comm3 );
    }
}

void findlastvalue(section* END, char selname[],char attname[] ) {
    section* secptr = END;
    list* listptr = NULL;
    bool secisfound = 0, attisfound = 0;
    char altname[MAX], altwithtwo[MAX], temp[MAX];
    cleartable(temp);
    cleartable(altname);
    cleartable(altwithtwo);
    altwithtwo[0] = '\n';
    altwithtwo[1] = '\n';
    for (int i = 0; i < MAX; i++) {
        if (selname[i] == ',') {
            selname[i] = NULL;
            break;
        }
    }
    if (selname[0] == '\n') {
        for (int i = 0; i < MAX - 1; i++) {
            altname[i] = selname[i + 1];
        }
        for (int i = 0; i < MAX - 2; i++) {
            altwithtwo[i + 2] = altname[i];
        }
    }
    else {
        altname[0] = '\n';
        for (int i = 0; i < MAX - 1; i++) {
            altname[i + 1] = selname[i];
        }
        for (int i = 0; i < MAX - 2; i++) {
            altwithtwo[i + 2] = selname[i];
        }
    }
    while (secptr != NULL) {
        cleartable(temp);
        int i = 0, j = 0, k = 0;
        secisfound = 0;
        while (secptr->name[i] != NULL) {
            if (secptr->name[i] == ',' || secptr->name[i] == '{') {
                j = 0;
                for (j; j < MAX; j++) {
                    k = 0;
                    if (temp[k + j] != NULL) {
                        if ((temp[k + j] != selname[j]) && (temp[k + j] != altname[j]) && (temp[k + j] != altwithtwo[j])) {
                            secisfound = 0;
                            break;
                        }
                        else {
                            secisfound = 1;
                        }
                    }
                    else {
                        break;
                    }
                }
                cleartable(temp);
            }
            else if (secptr->name[i] != ' ') {
                temp[k] = secptr->name[i];
                k++;
            }
            if (secisfound) {
                if (secptr->down != NULL) listptr = secptr->down;
                while (listptr!= NULL) {
                    cleartable(temp);
                    i = 0, j = 0;
                    while (listptr->name[i] != ':') {
                        if (listptr->name[i] != '\n' && listptr->name[i] != '\t') {
                            temp[j] = listptr->name[i];
                            j++;
                        }
                        if (j > 0&&attname[j-1]!='\n') {
                            if (temp[j-1] != attname[j-1]) {
                                attisfound = 0;
                                break;
                            }
                        }
                        attisfound = 1;
                        i++;
                    }
                    if (attisfound) {
                        break;
                    }
                    listptr = listptr->down;
                }
            }
            if (attisfound) {
                break;
            }
            i++;
        }
        if (attisfound) {
            i = 0;
            for (i = 0; i < MAX; i++) {
                if (selname[i] == ','||selname[i]==NULL) {
                    break;
                }
                if (selname[i] != '\n') {
                    printf("%c", selname[i]);
                }
            }
            printf(",E,");
            i = 0;
            for (i = 0; i < MAX; i++) {
                if (attname[i] == ':' || attname[i]=='\n') {
                    break;
                }
                if (attname[i] != '\n' && attname[i] != '\t') {
                    printf("%c", attname[i]);
                }
            }
            printf(" == ");
            i = 0;
            for (i = 0; i < MAX; i++) {
                if (listptr->value[i] == ';'||listptr->value[i]==NULL) {
                    break;
                }
                if (i==0&&listptr->value[i]==' ') {
                    
                }
                else {
                    printf("%c", listptr->value[i]);
                }
            }
            printf("\n");
            break;
        }
        if (attisfound) {
            break;
        }
        secptr = secptr->prev;
    }
}

int countsectionswithattribute(section* BEG, char name[]) {
    for (int i = 0; i < MAX; i++) {
        if (name[i] == ',') {
            name[i] = ':';
            break;
        }
    }
    int count = 0;
    bool isfound = 0;
    section* secptr = BEG;
    list* listptr = NULL;
    char altname[MAX], temp[MAX], altnamewithtab[MAX];
    cleartable(altname);
    cleartable(altnamewithtab);
    cleartable(temp);
    altnamewithtab[0] = '\n';
    altnamewithtab[1] = '\t';
    if (name[0] == '\n') {
        for (int i = 0; i < MAX - 1; i++) {
            if (name[i] == NULL || name[i] == ':') {
                break;
            }
            altname[i] = name[i+1];
        }
        for (int i = 0; i < MAX - 2; i++) {
            if (name[i] == NULL || name[i] == ':') {
                break;
            }
            altnamewithtab[i + 2] = altname[i];
        }
    }
    else {
        altname[0] = '\n';
        for (int i = 0; i < MAX - 1; i++) {
            if (name[i] == NULL || name[i] == ':') {
                break;
            }
            altname[i+1] = name[i];
        }
        for (int i = 0; i < MAX - 2; i++) {
            if (name[i] == NULL || name[i] == ':') {
                break;
            }
            altnamewithtab[i + 2] = name[i];
        }
    }
    if (secptr == NULL) {
        return 0;
    }
    else {
        while (secptr != NULL) {
            if (secptr->down != NULL) {
                listptr = secptr->down;
            }
            while (listptr != NULL) {
                cleartable(temp);
                if (listptr->name[0] == '\n' || listptr->name[0] == '\t') {
                    for (int i = 0; i < MAX; i++) {
                        temp[i] = listptr->name[i];
                        if (altnamewithtab[i] != NULL) {
                            if (temp[i] != name[i] && temp[i] != altname[i] && temp[i] != altnamewithtab[i]) {
                                isfound = 0;
                                break;
                            }
                        }
                        if (altnamewithtab[i] != NULL && temp[i] == NULL) {
                            isfound = 0;
                            break;
                        }
                        else {
                            isfound = 1;
                        }
                    }
                }
                else {
                    for (int i = 0; i < MAX; i++) {
                        temp[i] = listptr->name[i];
                        if (name[i] != NULL) {
                            if (temp[i] != name[i] && temp[i] != altname[i] && temp[i] != altnamewithtab[i]) {
                                isfound = 0;
                                break;
                            }
                        }
                       
                        else {
                            isfound = 1;
                        }
                    }
                }
                if (isfound == 1) {
                    count++;
                    break;
                }
                else {
                    listptr = listptr->down;
                }
            }
            secptr = secptr->next;
        }
        return count;
    }
}

int countallselectors(section* BEG, char name[]) {
    section* secptr = BEG;
    bool isfound = 0;
    int count = 0;
    char altname[MAX], altwithtwo[MAX], temp[MAX];
    cleartable(temp);
    cleartable(altname);
    cleartable(altwithtwo);
    altwithtwo[0] = '\n';
    altwithtwo[1] = '\n';
    for (int i = 0; i < MAX; i++) {
        if (name[i] == ',') {
            name[i] = NULL;
            break;
        }
    }
    if (name[0] == '\n') {
        for (int i = 0; i < MAX - 1; i++) {
            altname[i] = name[i + 1];
        }
        for (int i = 0; i < MAX - 2; i++) {
            altwithtwo[i + 2] = altname[i];
        }
    }
    else {
        altname[0] = '\n';
        for (int i = 0; i < MAX - 1; i++) {
            altname[i+1] = name[i];
        }
        for (int i = 0; i < MAX-2; i++) {
            altwithtwo[i + 2] = name[i];
        }
    }
    while (secptr != NULL) {
        cleartable(temp);
        int i = 0, j = 0, k = 0;
        isfound = 0;
        while (secptr->name[i] != NULL) {
            if (secptr->name[i] == ','|| secptr->name[i] == '{') {
                j = 0;
                for (j; j < MAX; j++) {
                    k = 0;
                    if (temp[k + j] != NULL) {
                        if ((temp[k + j] != name[j]) && (temp[k + j] != altname[j]) && (temp[k + j] != altwithtwo[j])) {
                            isfound = 0;
                            break;
                        }
                        else {
                            isfound = 1;
                        }
                    }
                }
                cleartable(temp);
            }
            else if (secptr->name[i]!=' ') {
                temp[k] = secptr->name[i];
                k++;
            }
            if (isfound) {
                count++;
                break;
            }
            i++;
        }
        secptr = secptr->next;
    }
    return count;
}

bool deleteattribute(section* BEG, int n,char name[]) {
    for (int i = 0; i < MAX; i++) {
        if (name[i] == '\n') {
            name[i] = ':';
            break;
        }
    }
    int j = 0;
    bool isfound = 0, isEMPTY = 0;
    section* secptr = BEG;
    list* listptr = NULL;
    list* ltemp = NULL;
    char altname[MAX], temp[MAX], altnamewithtab[MAX];
    cleartable(altname);
    cleartable(altnamewithtab);
    cleartable(temp);
    altname[0] = '\n';
    altnamewithtab[0] = '\n';
    altnamewithtab[1] = '\t';
    for (int i = 0; i < MAX - 1; i++) {
        if (name[i] == NULL || name[i] == '\n') {
            break;
        }
        altname[i + 1] = name[i];
    }
    for (int i = 0; i < MAX - 2; i++) {
        if (name[i] == NULL || name[i] == '\n') {
            break;
        }
        altnamewithtab[i + 2] = name[i];
    }
    if (secptr == NULL) {
        return 0;
    }
    else {
        if (n == 1) {
            listptr = secptr->down;
        }
        else {
            for (int i = 1; i < n; i++) {
                if (secptr->next != NULL) {
                    secptr = secptr->next;
                }
                else {
                    return 0;
                }
            }
            listptr = secptr->down;
            if (secptr->down->down == NULL) {
                secptr->down = NULL;
                isEMPTY = 1;
            }
        }
        for (int i = 0; i < MAX; i++) {
            temp[i] = listptr->name[i];
            if (name[i] != NULL) {
                if (temp[i] != name[i] && temp[i] != altname[i] && temp[i] != altnamewithtab[i]) {
                    isfound = 0;
                    break;
                }
                else {
                    isfound = 1;
                }
            }
            else {
                break;
            }
        }
        if (!isfound) {
            while (listptr->down != NULL) {
                cleartable(temp);
                for (int i = 0; i < MAX; i++) {
                    temp[i] = listptr->down->name[i];
                    if (name[i] != NULL) {
                        if (temp[i] != name[i] && temp[i] != altname[i] && temp[i] != altnamewithtab[i]) {
                            isfound = 0;
                            break;
                        }
                    }
                    else {
                        isfound = 1;
                    }
                }
                if (isfound == 1) {
                    break;
                }
            }
        }
        if (isfound) {
            ltemp = listptr->down;
            if (secptr->down != NULL) {
                if (listptr->down->down != NULL) {
                    listptr->down = listptr->down->down;
                }
                else {
                    listptr->down = NULL;
                }
            }
            free(ltemp);
            printf("%i,D,", n);
            for (int i = 0; i < MAX; i++) {
                if (name[i] == '\n'||name[i]==':') {
                    break;
                }
                else {
                    printf("%c", name[i]);
                }
            }
            printf(" == deleted");
            printf("\n");
        }
    }
    return isEMPTY;
}

section** deletesection(section* BEG, int n,int *count,bool ifprint) {
    section* ptr = BEG;
    list* lptr;
    if (BEG == NULL) {
        *count = 0;
        return &BEG;
    }
    else {
        if (n == 1) {
            if (ptr->next != NULL) {
                BEG = BEG->next;
                BEG->prev=NULL;
            }
            if (ptr->down != NULL) {
                lptr = ptr->down;
                while (lptr->down != NULL) {
                    lptr = lptr->down;
                }
                free(lptr);
            }
            free(ptr);
            printf("%i,D,* == deleted\n", n);
            *count=*count-1;
            return &BEG;
        }
        else {
            for (int i = 1; i < n; i++) {
                if (ptr->next != NULL) {
                    ptr = ptr->next;
                }
                else {
                    return &BEG;
                }
            }
            if (ptr->next != NULL) {
                ptr->next->prev = ptr->prev;
                ptr->prev->next = ptr->next;
            }
            else {
                ptr->prev->next = NULL;
            }
            while (ptr->down != NULL) {
                lptr = ptr->down;
                while (lptr->down != NULL) {
                    lptr = lptr->down;
                }
                free(lptr);
            }
            free(ptr);
            if (ifprint) {
                printf("%i,D,* == deleted\n", n);
            }
            *count=*count-1;
            return &BEG;
        }
    }
}



void printvalue(section* BEG, int n, char name[]) {
    for (int i = 0; i < MAX; i++) {
        if (name[i] == '\n') {
            name[i] = ':';
            break;
        }
    }
    int j = 0;
    bool isfound = 0;
    section* secptr = BEG;
    list* listptr = NULL;
    char altname[MAX], temp[MAX], altnamewithtab[MAX];
    cleartable(altname);
    cleartable(altnamewithtab);
    cleartable(temp);
    altname[0] = '\n';
    altnamewithtab[0] = '\n';
    altnamewithtab[1] = '\t';
    for (int i = 0; i < MAX - 1; i++) {
        if (name[i] == NULL || name[i] == '\n') {
            break;
        }
        altname[i + 1] = name[i];
    }
    for (int i = 0; i < MAX - 2; i++) {
        if (name[i] == NULL || name[i] == '\n') {
            break;
        }
        altnamewithtab[i + 2] = name[i];
    }
    if (secptr == NULL) {

    }
    else {
        if (n == 1) {
            if (secptr->down != NULL) {
                listptr = secptr->down;
                while (listptr != NULL) {
                    cleartable(temp);
                    for (int i = 0; i < MAX; i++) {
                        if (listptr->name[i] == NULL) {
                            break;
                        }
                        else {
                            temp[i] = listptr->name[i];
                        }
                    }
                    j = 0;
                    for (j; j < MAX; j++) {
                        isfound = 0;
                        if (temp[j] != name[j] && temp[j] != altname[j]&&temp[j]!=altnamewithtab[j]) {
                            listptr = listptr->down;
                            isfound = 0;
                            j = 0;
                            break;
                        }
                    }
                    if (j == MAX) {
                        isfound = 1;
                        break;
                    }
                }
            }
        }
        else {
            for (int i = 1; i < n; i++) {
                if (secptr != NULL) {
                    secptr = secptr->next;
                }
            }
            if (secptr) {
                if (secptr->down != NULL) {
                    listptr = secptr->down;
                    while (listptr != NULL) {
                        for (int i = 0; i < MAX; i++) {
                            if (listptr->name[i] == NULL) {
                                break;
                            }
                            else {
                                temp[i] = listptr->name[i];
                            }
                        }
                        j = 0;
                        for (j; j < MAX; j++) {
                            isfound = 0;
                            if (temp[j] != name[j] && temp[j] != altname[j] && temp[j] != altnamewithtab[j]) {
                                listptr = listptr->down;
                                isfound = 0;
                                j = 0;
                                break;
                            }
                        }
                        if (j == MAX) {
                            isfound = 1;
                            break;
                        }
                    }
                }
            }
        }
        if (isfound) {
            printf("%i,A,", n);
            for (int i = 0; i < MAX; i++) {
                if (listptr->name[i] == ':') {
                    break;
                }
                if (listptr->name[i] != '\n'&&listptr->name[i]!='\t') {
                    printf("%c", listptr->name[i]);
                }
            }
            printf(" == ");
            for (int i = 0; i < MAX; i++) {
                if (listptr->value[i] == ';') {
                    break;
                }
                printf("%c", listptr->value[i]);
            }
            printf("\n");
        }

    }
}

int chartoint(char tab[]) {
    int count = 0;
    for (int i = 0; i < MAX; i++) {
        if (tab[i] == NULL || tab[i] == ',') {
            break;
        }else if (tab[i] == '\n') {

        }
        else if (tab[i] > 47 && tab[i] < 58) {
            count = count + (tab[i] - '0');
        }
        else {
            count = 0;
            break;
        }
    }
    return count;
}

int countattributes(section* BEG, int n) {
    int counter = 0;
    section* secptr = BEG;
    list* listptr;
    if (BEG == NULL) {
        return -1;
    }
    else if (n == 1) {
        if (BEG->down == NULL) {
            return 0;
        }
        else {
            listptr = BEG->down;
            while (listptr->down != NULL) {
                listptr = listptr->down;
                counter++;
            }
            return counter + 1;
        }
    }
    else {
        for (int i = 1; i < n; i++) {
            if (secptr->next== NULL) {
                return -1;
                break;
            }
            secptr = secptr->next;
        }
        if (secptr->down == NULL) {
            return 0;
        }
        else {
            listptr = secptr->down;
            while (listptr->down != NULL) {
                listptr = listptr->down;
                counter++;
            }
            return counter + 1;
        }
    }
}

void printselector(section* BEG, int n, int j) {
    section* ptr = BEG;
    if (BEG == NULL) {

    }
    else {
        if (n == 1) {
            int iterator = 1, ninttemp = 0;
            char temp[MAX];
            cleartable(temp);
            for (int i = 0; i < MAX; i++) {
                if (ptr->name[i] == '{') {
                    break;
                }
                if (iterator == j) {
                    temp[ninttemp] = ptr->name[i];
                    if (temp[ninttemp] == ',') {
                        iterator++;
                        break;
                    }
                    ninttemp++;
                }
                else {
                    if (ptr->name[i] == ',') {
                        iterator++;
                    }
                }
            }
            if (temp[0] != NULL) {
                printf("%i,S,%i == ", n, j);
                for (int i = 0; i < ninttemp; i++) {
                    if (temp[i] != '\n' && temp[i] != ' ') {
                        printf("%c", temp[i]);
                    }
                }
                printf("\n");
            }
        }
        else {
            for (int i = 1; i < n; i++) {
                if (ptr->next!= NULL) {
                    ptr = ptr->next;
                }
                else {
                    return;
                }
            }
            int iterator = 1, ninttemp = 0;
            char temp[MAX];
            cleartable(temp);
            for (int i = 0; i < MAX; i++) {
                if (ptr->name[i] == '{') {
                    break;
                }
                if (iterator == j) {
                    temp[ninttemp] = ptr->name[i];
                    if (temp[ninttemp] == ',') {
                        iterator++;
                        break;
                    }
                    ninttemp++;
                }
                else {
                    if (ptr->name[i] == ',') {
                        iterator++;
                    }
                }
            }
            if (temp[0] != NULL) {
                printf("%i,S,%i == ", n, j);
                for (int i = 0; i < ninttemp; i++) {
                    if (temp[i] != '\n' && temp[i] != ' ') {
                        printf("%c", temp[i]);
                    }
                }
                printf("\n");
            }
        }
    }
}

int countselectors(section* BEG, int n) {
    section* ptr = BEG;
    int count = 1;
    bool isfound = 1;
    if (BEG == NULL) {
        return 0;
    }
    if (n == 1) {
        for (int i = 0; i < MAX; i++) {
            if (BEG->name[i] == ',') {
                count++;
            }
            else if (BEG->name[i] == '{') {
                return count;
                break;
            }
        }
    }
    else {
        for (int i = 1; i < n; i++) {
            if (ptr->next!= NULL) {
                ptr = ptr->next;
            }
            else {
                isfound = 0;
                break;
            }
        }
        if (isfound) {
            for (int j = 0; j < MAX; j++) {
                if (ptr->name[j] == ',') {
                    count++;
                }
                else if (ptr->name[j] == '{') {
                    return count;
                    break;
                }
            }
            return count;
        }
        else {
            return 0;
        }
    }
    return 0;
}

section* addattribute(section* BEG, char nametable[], char valuetable[]) {
    section* secptr = BEG;
    list* ptr;
    if (secptr->next == NULL) {
        if (secptr->down == NULL) {
            list* newattribute;
            newattribute = (list*)malloc(sizeof(struct list));
            if (newattribute) {
                newattribute->down = NULL;
                BEG->down = newattribute;
                strcpy(newattribute->name, nametable);
                strcpy(newattribute->value, valuetable);

            }
            return BEG;
        }
        else {
            ptr = secptr->down;
            while (ptr->down != NULL) {
                ptr = ptr->down;
            }
            list* newattribute;
            newattribute = (list*)malloc(sizeof(struct list));
            if (newattribute) {
                newattribute->down = NULL;
                ptr->down = newattribute;
                strcpy(newattribute->name, nametable);
                strcpy(newattribute->value, valuetable);

            }
            return BEG;
        }
    }
    else {
        while (secptr->next != NULL) {
            secptr = secptr->next;
        }
        if (secptr->down == NULL) {
            list* newattribute;
            newattribute = (list*)malloc(sizeof(struct list));
            if (newattribute) {
                newattribute->down = NULL;
                secptr->down = newattribute;
                strcpy(newattribute->name, nametable);
                strcpy(newattribute->value, valuetable);

            }
            return BEG;
        }
        else {
            ptr = secptr->down;
            while (ptr->down != NULL) {
                ptr = ptr->down;
            }
            list* newattribute;
            newattribute = (list*)malloc(sizeof(struct list));
            if (newattribute) {
                newattribute->down = NULL;
                ptr->down = newattribute;
                strcpy(newattribute->name, nametable);
                strcpy(newattribute->value, valuetable);

            }
            return BEG;
        }
    }
}

section* updateEND(section* BEG) {
    section* ptr = BEG;
    section* END;
    if (BEG == NULL) {
        END = NULL;
    }else if (ptr->next == NULL)
    {
        END = ptr;
    }
    else {
        while (ptr->next != NULL) {
            ptr = ptr->next;
        }
        END = ptr;
    }
    return END;
}

section* addsection(section* BEG, char nametable[]) {
    section* secptr = BEG;
    if (secptr == NULL) {
        section* newsection = NULL;
        newsection = (section*)malloc(sizeof(struct section));
        if (newsection) {
            newsection->prev = NULL;
            newsection->next = NULL;
            newsection->down = NULL;
            strcpy(newsection->name, nametable);
            BEG = newsection;

        }
        return BEG;
    }
    else {
        if (secptr->next == NULL) {
            section* newsection = NULL;
            newsection = (section*)malloc(sizeof(struct section));
            if (newsection) {
                newsection->prev = BEG;
                newsection->next = NULL;
                BEG->next = newsection;
                newsection->down = NULL;
                strcpy(newsection->name, nametable);

            }
            return BEG;
        }
        else {
            while (secptr->next != NULL) {
                secptr = secptr->next;
            }
            section* newsection = NULL;
            newsection = (section*)malloc(sizeof(struct section));
            if (newsection) {
                newsection->prev = secptr;
                newsection->next = NULL;
                secptr->next = newsection;
                newsection->down = NULL;
                strcpy(newsection->name, nametable);
            }
            return BEG;
        }
    }
}

void cleartable(char* table) {
    for (int i = 0; i < MAX; i++) {
        table[i] = NULL;
    }
}