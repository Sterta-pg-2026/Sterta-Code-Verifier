#include "attributenode.h"
AttributeNode::AttributeNode() {
	this->next = nullptr;
}

AttributeNode::AttributeNode(MyString n, MyString v) {
	this->name = n;
	this->value = v;
	this->next = nullptr;
}