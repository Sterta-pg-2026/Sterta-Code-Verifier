#define BUFFOR_SIZE 1000
#define SMALL_BUFFOR_SIZE 256
#define SMALL_BUFFOR 32
#define ZERO '0'
#define NINE '9'
#include "mystring.h"
#include "selectorlinkedlist.h"
#include "selectornode.h"
#include "attributenode.h"
#include "attributelinkedlist.h"
#include "section.h"
#include "doublylinkedlist.h"

using std::cout;
using std::cin;
using std::endl;

//selectors
void setSelectors(char* buffor, DoublyLinkedList& mainList);
void prepareSelectorsToDivide(char* t);
void setAttributes(char* buffor, DoublyLinkedList& mainList);

int mainForCommands(char* buffor, DoublyLinkedList& mainList);
void interpreteCommand(char* buffor, DoublyLinkedList& mainList);
void processSpecificCommand(int firstNum, char* firstKW, char operation, char* secondKW, int secondNum, DoublyLinkedList& l, MyString command);

//tabs changers
void clearTemporaryArray(char* t);
void cleanFromAllWhiteJunkBelowSpaceCharacter(char* t);
void cleanFromTabs(char* t);
int convertCharToInt(char* buffor);
void cleanFromEnters(char* t);
void prepareAttributesToDivide(char* t);

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
int main() {
    char buffor[BUFFOR_SIZE] = { '\0' };
    char ch;
    int iter = 0;
    bool startAddingAttributes = false;
    bool startReadingCommands = false;
    int activatorCounter = 0;

    DoublyLinkedList mainList;
    mainList.addNode();

    while (ch = getchar()) {
        if (ch == '\n') {
            continue;
        }
        if (ch == '\r') {
            continue;
        }
        if (ch == '\xff') {
            break;
        }
        buffor[iter] = ch;
        if (ch == '?') {
            startReadingCommands = true;
            activatorCounter++;

        }
        if (activatorCounter == 4) {
            int test = mainForCommands(buffor, mainList);
            if (!test) {
                break;
            }
            clearTemporaryArray(buffor);
            iter = 0;
            startReadingCommands = false;
            activatorCounter = 0;
            continue;
        }
        if (!startReadingCommands) {
            if (!startAddingAttributes) {
                if (ch == '{') {
                    mainList.addSection();
                    prepareSelectorsToDivide(buffor);
                    setSelectors(buffor, mainList);
                    clearTemporaryArray(buffor);
                    startAddingAttributes = true;
                    iter = 0;
                    continue;
                }
            }
            if (startAddingAttributes) {
                if (ch == '}') {
                    setAttributes(buffor, mainList);
                    clearTemporaryArray(buffor);
                    startAddingAttributes = false;
                    iter = 0;
                    continue;
                }
            }
        }
        
        iter++;
    }
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

int mainForCommands(char* buffor, DoublyLinkedList& mainList) {
    int iter = 0;
    char c;
    bool quit = false;

    clearTemporaryArray(buffor);
    getchar();

    while (c = getchar()) {
        buffor[iter] = c;
        if (quit) {
            return 0;
        }
        if (buffor[iter] == '\n' || buffor[iter] == '\xff') {
            if (buffor[iter] == '\xff') {
                buffor[iter] = '\n';
                quit = true;
            }
            cleanFromEnters(buffor);
            if (buffor[0] == '*') {
                return 1;
            }
            interpreteCommand(buffor, mainList);
            clearTemporaryArray(buffor);
            iter = 0;
            continue;
        }
        iter++;
    }
    return 1;
}


void interpreteCommand(char* buffor, DoublyLinkedList& mainList) {
    MyString command = buffor;
    int stoppedAtIndex = 0;
    //1st place of command
    int firstNumber = -1;
    char firstKeyword[BUFFOR_SIZE] = { '\0' };
    //2nd place of command
    char operation = ' ';
    //3rd place of command
    int secondNumber = 0;
    char secondKeyword[BUFFOR_SIZE] = { '\0' };
    if (buffor[0] == '?') {
        cout << command << " == " << mainList.countSections() << endl;
    } else {
        if (buffor[0] >= ZERO && buffor[0] <= NINE) { // thats int, not char
            firstNumber = convertCharToInt(buffor);
            for (int i = 0; i < BUFFOR_SIZE; i++) {
                if (buffor[i] == ',') {
                    stoppedAtIndex = i;
                    operation = buffor[stoppedAtIndex + 1];
                    break;
                }
            }
        } else {
            for (int i = 0; i < BUFFOR_SIZE; i++) {
                if (buffor[i] == '\0') {
                    break;
                }
                if (buffor[i] == ',') {
                    stoppedAtIndex = i;
                    operation = buffor[stoppedAtIndex + 1];
                    break;
                }
                firstKeyword[i] = buffor[i];
            }
        }
           
        int k = 0;
        for (int i = stoppedAtIndex + 3; i < BUFFOR_SIZE - stoppedAtIndex - 3; i++) {
            secondKeyword[k] = buffor[i];
            k++;
            if (buffor[i] == '\0') {
                break;
            }
        }
        if (secondKeyword[0] >= ZERO && secondKeyword[0] <= NINE) {
            secondNumber = convertCharToInt(secondKeyword);
        }
        processSpecificCommand(firstNumber, firstKeyword, operation, secondKeyword, secondNumber, mainList, command);
    } 
    clearTemporaryArray(firstKeyword);
    clearTemporaryArray(secondKeyword);
    clearTemporaryArray(buffor);
}
/*
______________________________________________________________________________________________________________________________________________
i,S,? – wypisz liczbę selektorów dla sekcji nr i (numery zaczynają się od 1), jeśli nie ma takiego bloku pomiń;

i,S,j – wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutów zaczynają się od 1) jeśli nie ma sekcji lub selektora pomiń;

z,S,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień selektora z. Możliwe jest 0;
----------------------------------------------------------------------------------------------------------------------------------------------

______________________________________________________________________________________________________________________________________________
i,A,? - wypisz liczbę atrybutów dla sekcji nr i, jeśli nie ma takiego bloku lub sekcji pomiń;

i,A,n – wypisz dla i-tej sekcji wartość atrybutu o nazwie n, jeśli nie ma takiego pomiń;

n,A,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n. 
(W ramach pojedynczego bloku duplikaty powinny zostać usunięte na etapie wczytywania). Możliwe jest 0;
----------------------------------------------------------------------------------------------------------------------------------------------

______________________________________________________________________________________________________________________________________________
z,E,n – wypisz wartość atrybutu o nazwie n dla selektora z, w przypadku wielu wystąpień selektora z bierzemy ostatnie. W przypadku braku pomiń;
----------------------------------------------------------------------------------------------------------------------------------------------

______________________________________________________________________________________________________________________________________________
i,D,* - usuń całą sekcję nr i (tj. selektory+atrybuty), po poprawnym wykonaniu wypisz deleted;

i,D,n – usuń z i-tej sekcji atrybut o nazwie n, jeśli w wyniku operacji pozostaje pusta sekcja powinna 
zostać również usunięta (wraz z ew. selektorami), po poprawnym wykonaniu wypisz deleted.
----------------------------------------------------------------------------------------------------------------------------------------------*/

void processSpecificCommand(int firstNum, char* firstKW, char operation, char* secondKW, int secondNum, DoublyLinkedList& l, MyString command) {
    MyString empty;
    MyString result = l.findLastNameNode(firstKW, secondKW);
    MyString error;
    switch (operation) {
        case 'S':
        if (firstNum > 0) {
            int index = 0;
            int nodeNum = -1;
            int h = 0;
            LinkedNode* temp = l.head;

            bool flag = false;
            while (temp != nullptr && !flag) {
                for (int i = 0; i < TAB_SIZE; i++) {
                    if (temp->tab[i] != nullptr) {
                        h++;
                    }
                    if (h == firstNum) {
                        index = i;
                        flag = true;
                        break;
                    }
                }
                temp = temp->next;
                nodeNum++;
            }
            if (secondKW[0] == '?') { //i,S,?
                if (firstNum <= l.countSections()) {
                    cout << command << " == " << l.countSelectorsOrAttributesInOneNode(nodeNum, index, 0) << endl;
                } 
            }
            else if (secondNum > 0) { //i,S,k
                if (firstNum <= l.countSections() && l.checkIfThingExists(nodeNum, index, secondNum)) {
                    MyString temp = l.getNameFromOneNode(nodeNum, index, secondNum);
                    if (!(temp == empty)) {
                        cout << command << " == " << temp << endl;
                    }
                }
            }
        } else { //z,S,?
            cout << command << " == " << l.countByName(firstKW, 0) << endl;
        }
        break;

        case 'A':
        if (firstNum > 0) {
            int index = 0;
            int nodeNum = -1;
            int h = 0;
            bool flag = false;
            LinkedNode* temp = l.head;

            while (temp != nullptr && !flag) {
                for (int i = 0; i < TAB_SIZE; i++) {
                    if (temp->tab[i] != nullptr) {
                        h++;
                    }
                    if (h == firstNum) {
                        index = i;
                        flag = true;
                        break;
                    }
                }
                temp = temp->next;
                nodeNum++;
            }

            if (secondKW[0] == '?') { //i,A,?
                if (firstNum <= l.countSections()) {
                    cout << command << " == " << l.countSelectorsOrAttributesInOneNode(nodeNum, index, 1) << endl;
                }
            } else { //i,A,n
                if (firstNum <= l.countSections() && l.checkIfThingExists(nodeNum, index, secondNum)) {
                    if (!(l.getValueFromOneNode(nodeNum, index, secondKW) == error)) {
                        cout << command << " == " << l.getValueFromOneNode(nodeNum, index, secondKW) << endl;
                    }
                }
            } 
        } else { //n,A,?
            cout << command << " == " << l.countByName(firstKW, 1) << endl;
        }
        break;

        case 'E': //z,E,n
            if (!(result == empty)) {
                cout << command << " == " << result << endl;
            }
        break;

        case 'D':
            if (secondKW[0] == '*') { //i,D,*
                if (l.deleteSection(firstNum)) {
                    cout << command << " == deleted" << endl;
                }
            } else { //i,D,n
                if (l.deleteAttribute(firstNum, secondKW)) {
                    cout << command << " == deleted" << endl;
                }
            }
        break;
    }
}

int convertCharToInt(char* buffor) {
    char temp[SMALL_BUFFOR_SIZE] = { '\0' };
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (buffor[i] == ',' || buffor[i] == '\0') {
            break;
        }
        temp[i] = buffor[i];
    }
    return atoi(temp);
}

void setAttributes(char* buffor, DoublyLinkedList& mainList) {
    char temp[SMALL_BUFFOR_SIZE] = { '\0' };
    MyString name;
    MyString value;
    int currentIndex = 0;
    bool settingName = true;
    bool settingValue = false;
    bool checkSpacesBefore = true;
    cleanFromAllWhiteJunkBelowSpaceCharacter(buffor);
    prepareAttributesToDivide(buffor);

    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if(checkSpacesBefore) {
            for (int x = i; x < BUFFOR_SIZE; x++) {
                if (buffor[x] > ' ') {
                    i = x;
                    checkSpacesBefore = false;
                    break;
                }
            }
        }
        if (buffor[i] == '\0') {
            break;
        }
        if (settingName) {
            if (buffor[i] != ':') {
                temp[currentIndex] = buffor[i];
                currentIndex++;
            } else {
                settingName = false;
                settingValue = true;
                name = temp;
                currentIndex = 0;
                clearTemporaryArray(temp);
                continue;
            }
        }
        if (settingValue) {
            if (buffor[i] == '}') {
                value = temp;
                mainList.tail->tab[mainList.tail->currentIndex - 1]->atrlist.addNode(name, value);
                clearTemporaryArray(temp);
                break;
            }
            if (buffor[i] != ';') {
                temp[currentIndex] = buffor[i];
                currentIndex++;
            } else {
                settingName = true;
                settingValue = false;
                checkSpacesBefore = true;
                value = temp;
                currentIndex = 0;
                mainList.tail->tab[mainList.tail->currentIndex - 1]->atrlist.addNode(name, value);
                clearTemporaryArray(temp);
                continue;
            }
        }
    }
}

void setSelectors(char* buffor, DoublyLinkedList& mainList) {
    char temp[SMALL_BUFFOR_SIZE] = { '\0' };
    MyString readyToPass;

    int k = 0;
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (buffor[i] != ',' && buffor[i] != '{') {
            temp[k] = buffor[i];
            k++;
        } else {
            readyToPass = temp;
            mainList.tail->tab[mainList.tail->currentIndex - 1]->sellist.addNode(temp);
            clearTemporaryArray(temp);
            k = 0;
            if (buffor[i] == '{') {
                break;
            }
        }
    }
}

void prepareAttributesToDivide(char* t) {
    int j = 0;
    bool startSkipping = false;
    
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] != ':') {
            if (t[i] == '}') {
                t[j-1] = t[i];
                t[j] = '\0';
                break;
            }
            t[j] = t[i];
            j++;
        } else { //if there was whitespaces after
            t[j] = t[i];
            j++;
            startSkipping = true;
            while (startSkipping) {
                if (t[i+1] == ' ') {
                    i++;
                } else {
                    startSkipping = false;
                }
            }
        }  
    }
}

void clearTemporaryArray(char* t) {
    int i = 0;
    for (;;) {
        if (t[i] == '\0') {
            break;
        }
        t[i] = '\0';
        i++;
    }
}

void prepareSelectorsToDivide(char* t) { 
    char temp[BUFFOR_SIZE] = { '\0' };
    int k = 0;
    int whereToStart = 0;

    cleanFromEnters(t);
    cleanFromTabs(t);

    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] != ' ') {
            whereToStart = i;
            break;
        }
    }

    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] == '{') {
            if (t[i - 1] == ' ' || t[i-1] == '\n') {
                t[i - 1] = '{';
                t[i] = '\n';
                break;
            }
        }
    }

    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] == '\t') {
            continue;
        }
        if (t[i] != ' ') {
            temp[k] = t[i];
            k++;
        }
        else {
            if (t[i - 1] != ',') {
                temp[k] = t[i];
                k++;
            }
        }
    }
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        t[i] = temp[i];
        if (temp[i] == '\0') {
            break;
        }
    }
}

void cleanFromEnters(char* t) {
    int j = 0;
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] != '\n') {
            t[j] = t[i];
            j++;
        }
        if (t[i] == '\0') {
            break;
        }
    }
}

void cleanFromAllWhiteJunkBelowSpaceCharacter(char* t) {  //everything below space (32) need to be deleted
    int j = 0;
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] == '\0') {
            t[j] = t[i];
            break;
        }
        if (t[i] >= ' ') {
            t[j] = t[i];
            j++;
        } 
    }
}

void cleanFromTabs(char* t) {
    int j = 0;
    for (int i = 0; i < BUFFOR_SIZE; i++) {
        if (t[i] != '\t') {
            t[j] = t[i];
            j++;
        }
        if (t[i] == '\0') {
            break;
        }
    }
}