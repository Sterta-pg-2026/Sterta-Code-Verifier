#include "linkednode.h"

LinkedNode::LinkedNode() {
	this->next = nullptr;
	this->prev = nullptr;
	for (int i = 0; i < TAB_SIZE; i++) {
		tab[i] = nullptr;
	}
	currentIndex = 0;
	numOfElements = 0;
}
