#include "selectornode.h"

SelectorNode::SelectorNode() {
	this->next = nullptr;
}