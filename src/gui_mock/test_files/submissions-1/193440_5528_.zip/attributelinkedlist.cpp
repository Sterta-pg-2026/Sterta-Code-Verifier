#include "attributelinkedlist.h"

AttributeLinkedList::AttributeLinkedList() {
	this->first = nullptr;
    this->size = 0;
}

void AttributeLinkedList::addNode(MyString name, MyString value) {
    AttributeNode* fresh = new AttributeNode(name, value);
    if (first == nullptr) {
        first = fresh;
        size++;
        return;
    }

    AttributeNode* search = searchForExistingNode(name);
    if (search != nullptr) {
        search->value = value;
        delete fresh;
        return;
    }

    AttributeNode* temp = first;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = fresh;
    size++;
}


AttributeNode* AttributeLinkedList::searchForExistingNode(MyString name) {
    AttributeNode* temp = first;
    while (temp != nullptr) {
        if (name == temp->name) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
}

int AttributeLinkedList::countElements() {
    int i = 0;
    AttributeNode* temp = first;
    while (temp != nullptr) {
        i++;
        temp = temp->next;
    }
    return i;
}

MyString AttributeLinkedList::getValueByName(MyString searchFor) {
    AttributeNode* temp = first;
    while (temp != nullptr) {
        if (temp->name == searchFor) {
            return temp->value;
        }
        temp = temp->next;
    }
    MyString error;
    return error;
}

int AttributeLinkedList::countAttributesByName(MyString name) {
    AttributeNode* temp = first;
    while (temp != nullptr) {
        if (temp->name == name) {
            return 1;
        }
        temp = temp->next;
    }
    return 0;
}

bool AttributeLinkedList::deleteNode(MyString name) {
    AttributeNode* temp = first;
    AttributeNode* previous = nullptr;

    while (temp != nullptr) {
        if (temp->name == name) {
            if (previous != nullptr) {
                previous->next = temp->next;
            } else {
                first = temp->next;
            }
            delete temp;
            size--;
            return true;
        }
        previous = temp;
        temp = temp->next;
    }
    return false;
}

