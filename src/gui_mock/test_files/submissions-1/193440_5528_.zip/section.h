#pragma once
#include "attributelinkedlist.h"
#include "selectorlinkedlist.h"

class Section {
public:
	AttributeLinkedList atrlist;
	SelectorLinkedList sellist;
	Section();
};
