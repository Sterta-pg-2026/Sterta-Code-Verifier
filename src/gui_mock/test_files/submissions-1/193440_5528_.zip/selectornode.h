#pragma once
#include "mystring.h"

class SelectorNode {
public:
	SelectorNode* next;
	MyString name;
	SelectorNode();
};
