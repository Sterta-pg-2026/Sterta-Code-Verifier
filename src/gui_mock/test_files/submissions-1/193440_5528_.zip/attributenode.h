#pragma once
#include "mystring.h"

class AttributeNode {
public:
	AttributeNode* next;
	MyString name;
	MyString value;
	AttributeNode();
	AttributeNode(MyString n, MyString v);
};