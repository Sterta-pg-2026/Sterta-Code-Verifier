#include "selectorlinkedlist.h"

SelectorLinkedList::SelectorLinkedList() {
    this->first = nullptr;
    this->size = 0;
}

void SelectorLinkedList::addNode(MyString name) {
    if (findSelector(name)) {
        return;
    }
    SelectorNode* fresh = new SelectorNode();
    fresh->name = name;
    if (first == nullptr) {
        first = fresh;
        size++;
        return;
    }

    SelectorNode* temp = first;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = fresh;
    size++;
}

void SelectorLinkedList::printList() {
    SelectorNode* temp = first;
    while (temp != nullptr) {
        cout << temp->name << endl;
        temp = temp->next;
    }
}

int SelectorLinkedList::countElements() {
    int i = 0;
    SelectorNode* temp = first;
    MyString empty;
    while (temp != nullptr) {
        if (temp->name == empty) {
            return 0;
        }
        i++;
        temp = temp->next;
    }
    return i;
}

MyString SelectorLinkedList::getNameByNumber(int whichOne) {
    SelectorNode* temp = first;
    while (whichOne-- > 1) {
        temp = temp -> next;
    }
    return temp->name;
}

int SelectorLinkedList::countSelectorsByName(MyString name) {
    SelectorNode* temp = first;
    int counter = 0;
    while (temp != nullptr) {
        if (temp->name == name) {
            counter++;
        }
        temp = temp->next;
    }
    return counter;
}

bool SelectorLinkedList::findSelector(MyString name) {
    SelectorNode* temp = first;
    while (temp != nullptr) {
        if (temp->name == name) {
            return true;
        }
        temp = temp->next;
    }
    return false;
}


