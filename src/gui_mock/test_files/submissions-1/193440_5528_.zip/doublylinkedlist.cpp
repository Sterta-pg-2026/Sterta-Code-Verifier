#include "doublylinkedlist.h"

DoublyLinkedList::DoublyLinkedList() {
	this->head = nullptr;
	this->tail = nullptr;
	this->size = 0;
}

void DoublyLinkedList::addNode() {
	LinkedNode* temp = tail;
	tail = new LinkedNode();
	if (temp == nullptr) {
		tail->prev = nullptr;
		head = tail;
	} else {
		tail->prev = temp;
		temp->next = tail;
	}
	size++;
}

void DoublyLinkedList::addSection() {
	if (tail == nullptr) {
		addNode();
	}
	if (tail->currentIndex == TAB_SIZE) {
		addNode();
	}
	tail->tab[tail->currentIndex] = new Section();
	tail->currentIndex++;
	tail->numOfElements++;
}

int DoublyLinkedList::countSections() {
	LinkedNode* temp = head;
	int counter = 0;
	while (temp != nullptr) {
		counter += temp->numOfElements;
		temp = temp->next;
	}
	return counter;
}

int DoublyLinkedList::countSelectorsOrAttributesInOneNode(int nodeNum, int index, bool SoA) {
	LinkedNode* temp = head;
	while (nodeNum-- > 0) {
		temp = temp->next;
	}
	
	if (!SoA) { //selectors
		return temp->tab[index]->sellist.countElements();
	}
	return temp->tab[index]->atrlist.countElements();//attributes	
}

MyString DoublyLinkedList::getNameFromOneNode(int nodeNum, int index, int whichOne) {
	LinkedNode* temp = head;
	while (nodeNum-- > 0) {
		temp = temp->next;
	}
	return temp->tab[index]->sellist.getNameByNumber(whichOne);
}

bool DoublyLinkedList::checkIfThingExists(int nodeNum, int index, int whichOne) {
	LinkedNode* temp = head;
	while (nodeNum-- > 0) {
		temp = temp->next;
	}
	if (temp->tab[index]->sellist.size < whichOne) {
		return false;
	}
	return true;
}

int DoublyLinkedList::countByName(MyString name, bool SoA) {
	int counter = 0;
	int howManySections = countSections();
	while (howManySections > 0) {
		howManySections = howManySections - TAB_SIZE;
	}
	LinkedNode* temp = head;
	while (temp != nullptr) {
		for (int i = 0; i < TAB_SIZE; i++) {
			if (temp->tab[i] != nullptr) {
				if (!SoA) {
					counter += temp->tab[i]->sellist.countSelectorsByName(name);
				} else {
					counter += temp->tab[i]->atrlist.countAttributesByName(name);
				}
			}
		}
		temp = temp->next;
	}
	return counter;
}

MyString DoublyLinkedList::getValueFromOneNode(int nodeNum, int index, MyString name) {
	LinkedNode* temp = head;
	while (nodeNum-- > 0) {
		temp = temp->next;
	}
	return temp->tab[index]->atrlist.getValueByName(name);
}

MyString DoublyLinkedList::findLastNameNode(MyString selName, MyString atrName) {
	LinkedNode* temp = tail; //!!!TAIL
	MyString empty;
	while (temp != nullptr) {
		for (int i = TAB_SIZE - 1; i >= 0; i--) {
			if (temp->tab[i] == nullptr) {
				continue;
			}
			if (temp->tab[i]->sellist.findSelector(selName)) {
				MyString search = temp->tab[i]->atrlist.getValueByName(atrName);
				if (!(search == empty)) {
					return search;
				} 
			}
		}
		temp = temp->prev;
	}
	return empty;
}

bool DoublyLinkedList::deleteSection(int which) {
	LinkedNode* temp = head;
	int counter = 0;
	while (temp != nullptr) {
		for (int i = 0; i < TAB_SIZE; i++) {
			if (temp->tab[i] != nullptr) {
				counter++;
			}
			if (counter == which) {
				delete temp->tab[i];
				temp->tab[i] = nullptr;
				temp->numOfElements--;
				
				if (temp->numOfElements == 0) {
					deleteNode(temp);
				}
				return true;
			}
		}
		temp = temp->next;
	}
	return false;
}

bool DoublyLinkedList::deleteAttribute(int which, MyString name) {
	LinkedNode* temp = head;
	int counter = 0;
	while (temp != nullptr) {
		for (int i = 0; i < TAB_SIZE; i++) {
			if (temp->tab[i] != nullptr) {
				counter++;
			}
			if (counter == which) {
				if (temp->tab[i]->atrlist.deleteNode(name)) {
					if (temp->tab[i]->atrlist.size == 0) {
						deleteSection(which);
					}
					return true;
				} else {
					return false;
				}
			}
		}
		temp = temp->next;
	}
	return false;
}

void DoublyLinkedList::deleteNode(LinkedNode* which) {
	if (this->size == 1) {
		head = nullptr;
		tail = nullptr;
	}
	else if (which == head) {
		head = which->next;
		head->prev = nullptr;
	}
	else if (which == tail) {
		tail = which->prev;
		tail->next = nullptr;
	} else {
		which->prev->next = which->next;
		which->next->prev = which->prev;
	}
	delete which;
	size--;
}