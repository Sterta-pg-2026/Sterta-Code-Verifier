#pragma once
#include "selectornode.h"
#include <iostream>

class SelectorLinkedList {
public:
	SelectorNode* first;
	int size;
	SelectorLinkedList();
	void addNode(MyString name);
	void printList();
	int countElements();
	MyString getNameByNumber(int whichOne);
	int countSelectorsByName(MyString name);
	bool findSelector(MyString name);
};
