#pragma once
#define TAB_SIZE 17
#include "section.h"

class LinkedNode {
public:
	Section* tab[TAB_SIZE];
	LinkedNode* next;
	LinkedNode* prev;
	int numOfElements;
	int currentIndex;
	LinkedNode();
};
