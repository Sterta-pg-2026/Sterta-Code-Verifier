#pragma once
#include "linkednode.h"
#include "section.h"
class DoublyLinkedList {
public:
	LinkedNode* head;
	LinkedNode* tail;
	int size;
	
	DoublyLinkedList();
	void addNode();
	void addSection();
	int countSections();
	int countSelectorsOrAttributesInOneNode(int nodeNum, int index, bool SoA); //S - selectors = 0 //A - attributes = 1
	MyString getNameFromOneNode(int nodeNum, int index, int whichOne);
	bool checkIfThingExists(int nodeNum, int index, int whichOne);
	int countByName(MyString name, bool SoA);
	MyString getValueFromOneNode(int nodeNum, int index, MyString name);
	MyString findLastNameNode(MyString selName, MyString atrName);
	bool deleteSection(int which);
	bool deleteAttribute(int which, MyString name);
	void deleteNode(LinkedNode* which);
};

