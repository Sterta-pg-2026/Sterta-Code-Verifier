#pragma once
#include <iostream>
#include "attributenode.h"

class AttributeLinkedList {
public:
	AttributeNode* first;
	int size;
	AttributeLinkedList();
	void addNode(MyString name, MyString value);
	AttributeNode* searchForExistingNode(MyString name);
	int countElements();
	MyString getValueByName(MyString searchFor);
	int countAttributesByName(MyString name);
	bool deleteNode(MyString name);
};