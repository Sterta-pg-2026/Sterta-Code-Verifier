#pragma once
#include "node.h"
class MainNode {
public:
	Node* start;
	Node* end;
	int size;

	MainNode();
	void append(Block* block);
	static int read_characters(char* buffer);
	void load_CSS();
	Node* find(int index, int* node_id);
	int count(bool use_selectors, char* argument);
	char* last_att_value(char* selector, char* attribute);
	int remove(Node* toDel);
	int remove(int index, char* name = nullptr);
	~MainNode();
	Block* operator[](int index);
};

