#pragma once
#include "block.h"
#define T 8
class Node {
public:
	Block* array[T];
	Node* next;
	Node* prev;
	int size;
	static int total_size;

	Node();
	void add(Block* block);
	int remove(int index);
	int remove(int index, char* name);
	void del();
	~Node();
};