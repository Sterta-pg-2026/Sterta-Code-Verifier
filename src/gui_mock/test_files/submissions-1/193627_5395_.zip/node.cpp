#include "node.h"
Node::Node()
	: next(nullptr), prev(nullptr), size(0)
{
	for (int i = 0; i < T; i++) {
		array[i] = nullptr;
	}
}

int Node::total_size = 0;

void Node::add(Block* block) {
	for (int i = 0; i < T; i++) {
		if (array[i] == nullptr) {
			array[i] = block;
			size++;
			total_size++;
			break;
		}
	}
}

int Node::remove(int index) {
	if (array[index] != nullptr) delete array[index];
	else return 0;
	size--;
	total_size--;

	for (int i = index; i < size; i++) {
		array[i] = array[i + 1];
	}

	array[size] = nullptr;
	return 1;
}

int Node::remove(int index, char* name) {
	if (array[index]->remove_att(name)) {

		if (array[index]->att_n == 0) {

			if (remove(index)) return 1;
			else return 0;
		}
		return 1;
	}
	return 0;
}

void Node::del() {
	prev->next = next;
	next->prev = prev;
	delete this;
}

Node::~Node() {
	for (int i = 0; i < T; i++) {
		if (array[i] != nullptr) {
			delete array[i];
		}
	}
}