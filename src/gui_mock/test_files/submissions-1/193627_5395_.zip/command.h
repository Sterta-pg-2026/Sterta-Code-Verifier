#pragma once
#include "mainnode.h"
class Command
{
public:
	char lArgument[MAX_STR_LENGTH], type, rArgument[MAX_STR_LENGTH];
	Command();
	void set(char* fullcmd);
	void execute(MainNode& node);
	void result(char* result) const;
	void result(int result) const;
};