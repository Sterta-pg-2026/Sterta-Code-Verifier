#include <iostream>
#include "command.h"

int main() {
	MainNode node;
	Command cmd;
	char buffer[MAX_STR_LENGTH];
	node.load_CSS();
	while (cin) {
		cin.getline(buffer, MAX_STR_LENGTH);

		if (!strcmp(buffer, "****")) {
			node.load_CSS();
		}
		else if (!strcmp(buffer, "?")) {
			cout << buffer << " == " << node.start->total_size << endl;
		}
		else if (strchr(buffer, ',')) {
			cmd.set(buffer);
			cmd.execute(node);
		}
	}
	return 0;
}