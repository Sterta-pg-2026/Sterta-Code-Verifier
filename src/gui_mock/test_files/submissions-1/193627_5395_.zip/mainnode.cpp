#include "mainnode.h"

MainNode::MainNode()
	:start(nullptr), end(nullptr), size(0) {}

void MainNode::append(Block* block) {
	if (size == 0) {
		Node* node = new Node;

		node->next = nullptr;
		node->prev = nullptr;
		start = node;
		end = node;
		
		node->add(block);
		size++;
	}
	else if(size > 0) {
		if (end->size < T) {
			end->add(block);
		}
		else {
			Node* node = new Node;

			end->next = node;
			node->prev = end;
			node->next = nullptr;
			end = node;

			node->add(block);
			size++;
		}
	}
}

int MainNode::read_characters(char* buffer) {
	char c;
	int i = 0, counter = 0;

	do {
		c = getchar();

		if (c == '?') counter++;
		else counter = 0;

		if (c != NULL) buffer[i] = c;
		i++;
	} while (c != '{' && counter < 4);

	buffer[i] = '\0';
	return counter;
}

void MainNode::load_CSS() {
	char buffer[MAX_LENGTH];
	int qm_counter;

	qm_counter = read_characters(buffer);

	while (qm_counter != 4) {
		Block* block = new Block;

		block->load_selectors(buffer);
		block->load_attributes(buffer);
		append(block);

		qm_counter = read_characters(buffer);
	}
}

Node* MainNode::find(int index, int* node_id) {
	Node* temp1 = start, *temp2 = start;
	int counter = 0;

	while (counter < index + 1) {
		counter += temp1->size;
		temp2 = temp1;
		temp1 = temp1->next;
	}

	*node_id = index - (counter - temp2->size);
	return temp2;
}

int MainNode::count(bool use_selectors, char* argument) {
	int counter = 0;

	for (Node* temp = start; temp != nullptr; temp = temp->next) {
		for (int i = 0; i < temp->size; i++) {

			if (use_selectors && temp->array[i]->sel_find(argument) != nullptr) {
				counter++;
			}
			else if (!use_selectors && temp->array[i]->att_find(argument) != nullptr) {
				counter++;
			}
		}
	}
	return counter;
}

char* MainNode::last_att_value(char* selector, char* attribute) {
	Block* block;
	for (Node* temp = end; temp != nullptr; temp = temp->prev) {

		for (int i = temp->size - 1; i >= 0; i--) {
			block = temp->array[i];

			if (block->sel_find(selector)) {
				Attribute* att = block->att_find(attribute);

				if (att != nullptr) {
					return att->value;
				}
			}
		}
	}
	return nullptr;
}

int MainNode::remove(Node* toDel) {
	if (toDel != nullptr) {
		if (toDel == start) {
			start = toDel->next;

			if (start != nullptr) {
				start->prev = nullptr;
			}
			else {
				end = nullptr;
			}
			delete toDel;
		}
		else if (toDel == end) {
			end = toDel->prev;
			end->next = nullptr;
			delete toDel;
		}
		else {
			toDel->del();
		}
		size--;
		return 1;
	}
	return 0;
}

int MainNode::remove(int index, char* name) {
	int node_id;

	Node* ref = find(index, &node_id);

	if (name == nullptr){
		if (!ref->remove(node_id)) return 0;
	}
	else {
		if (!ref->remove(node_id, name)) return 0;
	}

	if (ref->size == 0) {
		if (!remove(ref)) return 0;
	}
	return 1;
}

MainNode::~MainNode() {
	Node* temp = nullptr;

	for (Node* toDel = start; toDel != nullptr; toDel = temp) {
		temp = toDel->next;
		delete toDel;
	}
}

Block* MainNode::operator[](int index) {
	int node_id;
	Node* node = find(index, &node_id);

	return node->array[node_id];
}
