#include "selector.h"
Selector::Selector()
	:next(nullptr), prev(nullptr) {
	strcpy_s(name, "-");
}

Selector::Selector(char* Name)
	:next(nullptr), prev(nullptr) {
	strcpy_s(name, Name);
}
void Selector::set(char* Name) {
	strcpy_s(name, Name);
}
