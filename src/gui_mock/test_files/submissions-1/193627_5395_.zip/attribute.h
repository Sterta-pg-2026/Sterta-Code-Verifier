#pragma once
#include <iostream>
#include "string.h"
#define MAX_STR_LENGTH 500
#define MAX_LENGTH 5000
using namespace std;

class Attribute {
public:
	char name[MAX_STR_LENGTH], value[MAX_STR_LENGTH];
	Attribute* next;
	Attribute* prev;
	Attribute();
	Attribute(char* Name, char* Value);
	void set(char* Name, char* Value);
	void del();
	friend ostream& operator<<(ostream& ostr, const Attribute& att);
};