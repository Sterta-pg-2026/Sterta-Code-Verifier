#pragma once
#include "attribute.h"
#include "selector.h"
class Block {
public:
	Attribute* att_start;
	Attribute* att_end;
	Selector* sel_start;
	Selector* sel_end;
	int sel_n;
	int att_n;

	Block();
	void append(char* name, char* value);
	void append(char* name);
	static void swap_white_char(char* buffer);
	static char* remove_spaces(char* buffer);
	void load_selectors(char* buffer);
	void load_attributes(char* buffer);
	Attribute* att_find(int index);
	Attribute* att_find(char* name);
	char* sel_find(int index);
	Selector* sel_find(char* name);
	int remove_att(char* name);
	~Block();
	friend ostream& operator<<(ostream& ostr, Block& block);
};