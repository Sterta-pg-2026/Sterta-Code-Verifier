#include "command.h"

Command::Command() {
	strcpy_s(lArgument, "-");
	type = '-';
	strcpy_s(rArgument, "-");
}

void Command::set(char* fullcmd) {
	char* nextToken, * token, * cmd[3];
	cmd[0] = lArgument; cmd[1] = &type; cmd[2] = rArgument;

	nextToken = nullptr;
	token = strtok_s(fullcmd, ",", &nextToken);

	for (int i = 0; token != nullptr; i++) {

		if (strcmp(token, "") && i <= 2) {
			strcpy_s(cmd[i], MAX_STR_LENGTH, token);
		}
		token = strtok_s(nullptr, ",", &nextToken);
	}
}

void Command::execute(MainNode& node) {
	switch (type) {
	case 'S':
		if (atoi(lArgument)) {//sprawdzanie czy lArgument jest intem
			int n_lArg = atoi(lArgument);

			if (n_lArg <= node.start->total_size) {
				int n_rArg = atoi(rArgument);

				if (!strcmp(rArgument, "?")) {
					result(node[n_lArg - 1]->sel_n);
				}
				else if (n_rArg <= node[n_lArg - 1]->sel_n) {
					result(node[n_lArg - 1]->sel_find(n_rArg - 1));
				}
			}
		}
		else if (!strcmp(rArgument, "?")) {
			int sel_counter = 0;

			sel_counter = node.count(true, lArgument);
			result(sel_counter);
		}
		break;
	case 'A':
		if (atoi(lArgument)) {
			int n_lArg = atoi(lArgument);

			if (n_lArg <= node.start->total_size) {

				if (!strcmp(rArgument, "?")) {
					result(node[n_lArg - 1]->att_n);
				}
				else {
					Attribute* att = node[n_lArg - 1]->att_find(rArgument);

					if (att != nullptr) result(att->value);
				}
			}
		}
		else if (!strcmp(rArgument, "?")) {
			int att_counter = 0;
			att_counter = node.count(false, lArgument);
			result(att_counter);
		}
		break;
	case 'E':
		if (!atoi(lArgument) && !atoi(rArgument)) {

			char* temp = node.last_att_value(lArgument, rArgument);
			if(temp != nullptr) result(temp);
		}
		break;
	case 'D':
		if (atoi(lArgument)) {
			int n_lArg = atoi(lArgument);
			char success[MAX_STR_LENGTH];
			strcpy_s(success, "deleted");

			if (n_lArg <= node.start->total_size){
				if (!strcmp(rArgument, "*")) {
					if (node.remove(n_lArg - 1)) {
						result(success);
					}
				}
				else if(node.remove(n_lArg - 1, rArgument)) {
					result(success);
				}
			}
		}
		break;
	}
}

void Command::result(char* result) const {
	cout << lArgument << "," << type << "," << rArgument << " == " << result << endl;
}

void Command::result(int result) const {
	cout << lArgument << "," << type << "," << rArgument << " == " << result << endl;
}