#include "attribute.h"
Attribute::Attribute() 
	:next(nullptr), prev(nullptr) {
	strcpy_s(name, "-");
	strcpy_s(value, "-");
}

Attribute::Attribute(char* Name, char* Value) 
	:next(nullptr), prev(nullptr) {
	strcpy_s(name, Name);
	strcpy_s(value, Value);
}

void Attribute::set(char* Name, char* Value) {
	strcpy_s(name, Name);
	strcpy_s(value, Value);
}

void Attribute::del() {
	prev->next = next;
	next->prev = prev;
	delete this;
}