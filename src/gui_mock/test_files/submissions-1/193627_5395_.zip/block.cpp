#include "block.h"

Block::Block()
	: att_start(nullptr), att_end(nullptr),
	sel_start(nullptr), sel_end(nullptr), sel_n(0), att_n(0) {
}

void Block::append(char* name, char* value) {
	Attribute* toAppend = new Attribute(name, value);

	if (att_start == nullptr) {
		att_start = toAppend;
		att_end = toAppend;
		att_start->next = nullptr;
		att_start->prev = nullptr;
	}
	else {
		att_end->next = toAppend;
		toAppend->prev = att_end;
		toAppend->next = nullptr;
		att_end = toAppend;
	}
	att_n++;
}

void Block::append(char* name) {
	Selector* toAppend = new Selector(name);

	if (sel_start == nullptr) {
		sel_start = toAppend;
		sel_end = toAppend;
		sel_start->next = nullptr;
		sel_start->prev = nullptr;
	}
	else {
		sel_end->next = toAppend;
		toAppend->prev = sel_end;
		toAppend->next = nullptr;
		sel_end = toAppend;
	}
	sel_n++;
}

void Block::swap_white_char(char* buffer) {
	while (strchr(buffer, '\n')) {//pomijanie \n
		*strchr(buffer, '\n') = ' ';
	}
	while (strchr(buffer, '\t')) {//pomijanie \t
		*strchr(buffer, '\t') = ' ';
	}
}

char* Block::remove_spaces(char* buffer) {
	char* last_char;
	while (buffer[0] == ' ') {
		buffer += 1;
	}

	last_char = strchr(buffer, '\0') - 1;
	while (*last_char == ' ') {
		*last_char = '\0';
		last_char--;
	}
	return buffer;
}

void Block::load_selectors(char* buffer) {
	char* nextToken, *token, *last_char;
	nextToken = nullptr;

	swap_white_char(buffer);
	last_char = strchr(buffer, '\0') - 1;
	if (*last_char == '{') *last_char = '\0';

	token = strtok_s(buffer, ",", &nextToken);

	while (token != nullptr) {
		for (int i = 0; i < strlen(token); i++) {
			if (token[i] < ' ') {//wykrywanie niepoprawnych znakow
				token[i] = ' ';
			}
		}
		token = remove_spaces(token);
		if (strcmp(token, "")) {//jesli token nie jest pusty
			append(token);
		}
		token = strtok_s(nullptr, ",", &nextToken);
	}
}

void Block::load_attributes(char* buffer) {
	Attribute* check_duplicates;
	char* nextToken, *token;
	char name[MAX_STR_LENGTH];
	nextToken = nullptr;

	scanf_s("%[^}]s", buffer, MAX_LENGTH);
	swap_white_char(buffer);

	token = strtok_s(buffer, ":;", &nextToken);
	if (token[0] == '{') token += 1;

	for (int i = 0; token != nullptr; i++) {
		token = remove_spaces(token);

		if (strcmp(token, "")) {
			if (i % 2) {
				check_duplicates = att_find(name);

				if (check_duplicates == nullptr) {
					append(name, token);
				}
				else {
					strcpy_s(check_duplicates->name, name);
					strcpy_s(check_duplicates->value, token);
				}
			}
			else if (token != NULL) {
				strcpy_s(name, token);
			}
		}
		token = strtok_s(nullptr, ":;", &nextToken);
	}
	getchar();//pomin '}'
}

Attribute* Block::att_find(int index) {
	Attribute* temp = nullptr;

	if (index <= att_n / 2) {
		temp = att_start;
		for (int i = 0; i != index; i++) {
			temp = temp->next;
		}
	}
	else {
		temp = att_end;
		for (int i = att_n - 1; i != index; i--) {
			temp = temp->prev;
		}
	}
	return temp;
}

Attribute* Block::att_find(char* name) {
	for (Attribute* temp = att_start; temp != nullptr; temp = temp->next) {
		if (!strcmp(name, temp->name)) {
			return temp;
		}
	}
	return nullptr;
}

char* Block::sel_find(int index) {
	Selector* temp = nullptr;

	if (index <= sel_n / 2) {
		temp = sel_start;
		for (int i = 0; i != index; i++) {
			temp = temp->next;
		}
	}
	else {
		temp = sel_end;
		for (int i = sel_n - 1; i != index; i--) {
			temp = temp->prev;
		}
	}
	return temp->name;
}

Selector* Block::sel_find(char* name) {
	for (Selector* temp = sel_start; temp != nullptr; temp = temp->next) {
		if (!strcmp(name, temp->name)) {
			return temp;
		}
	}
	return nullptr;
}

int Block::remove_att(char* name) {
	Attribute* toDel = att_find(name);

	if (toDel != nullptr) {
		if (toDel == att_start) {
			att_start = toDel->next;
			if (att_start != nullptr) {
				att_start->prev = nullptr;
			}
			else {
				att_end = nullptr;
			}
			delete toDel;
		}
		else if (toDel == att_end) {
			att_end = toDel->prev;
			att_end->next = nullptr;
			delete toDel;
		}
		else {
			toDel->del();
		}
		att_n--;
		return 1;
	}
	else {
		return 0;
	}
}

Block::~Block() {
	Attribute* temp1 = nullptr;

	for (Attribute* AttrtoDel = att_start; AttrtoDel != nullptr; AttrtoDel = temp1) {
		temp1 = AttrtoDel->next;
		delete AttrtoDel;
	}

	Selector* temp2 = nullptr;
	for (Selector* SeltoDel = sel_start; SeltoDel != nullptr; SeltoDel = temp2) {
		temp2 = SeltoDel->next;
		delete SeltoDel;
	}
}