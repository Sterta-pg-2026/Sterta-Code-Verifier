#pragma once
#include <iostream>
#include "string.h"
#include "attribute.h"
using namespace std;

class Selector
{
public:
	char name[MAX_STR_LENGTH];
	Selector* next;
	Selector* prev;
	Selector();
	Selector(char* Name);
	void set(char* Name);
	friend ostream& operator<<(ostream& ostr, const Selector& att);
};

