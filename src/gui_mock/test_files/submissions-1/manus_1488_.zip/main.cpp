#include <iostream>
#include <string>
#include <vector>
#include <deque>
#include <sstream>
#include <fstream>
//#include <algorithm>


#include <algorithm> 
#include <cctype>
#include <locale>

using namespace std;

// trim from start (in place)
static inline void ltrim(std::string& s) {
	s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
		return !std::isspace(ch);
		}));
}

// trim from end (in place)
static inline void rtrim(std::string& s) {
	s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
		return !std::isspace(ch);
		}).base(), s.end());
}

// trim from both ends (in place)
static inline void trim(std::string& s) {
	rtrim(s);
	ltrim(s);
}

// trim from start (copying)
static inline std::string ltrim_copy(std::string s) {
	ltrim(s);
	return s;
}

// trim from end (copying)
static inline std::string rtrim_copy(std::string s) {
	rtrim(s);
	return s;
}

// trim from both ends (copying)
static inline std::string trim_copy(std::string s) {
	trim(s);
	return s;
}

//////////////////////////////////


typedef string::iterator STR_ITER;
typedef string::const_iterator STR_CITER;

typedef deque<string> LINES;
typedef deque<string>::iterator LINES_ITER;
typedef deque<string>::const_iterator LINES_CITER;

typedef vector<string> SELECTORS;

struct BODY {
	LINES keys;
	LINES vals;
	void addAttrib(const string & key, const string & val) { 
		LINES_ITER keyPos = find(keys.begin(), keys.end(), key);
		if (keyPos == keys.end())
		{
			keys.push_back(key); vals.push_back(val);
		}
		else
		{
			vals[keyPos - keys.begin()] = val;
		}
	}

	bool removeAttrib(const string & key) {
		LINES_CITER keyPos = find(keys.begin(), keys.end(), key);
		if (keyPos == keys.end())
		{
			return false;
		}
		else
		{
			int pos = keyPos - keys.begin();
			keys.erase(keyPos);
			vals.erase(vals.begin() + pos);
			return true;
		}
	}

	string getAttrib(const string& key) const {
		LINES_CITER keyPos = find(keys.begin(), keys.end(), key);
		if (keyPos == keys.end())
		{
			return "";
		}
		else
		{
			return vals[keyPos - keys.begin()];
		}
	}
} ;

struct CSS_ATOM {
public:
	SELECTORS selectors;
	BODY body;
	CSS_ATOM(const SELECTORS & nSelectors, const BODY & nBody) : selectors(nSelectors), body(nBody) { }
};

typedef vector <CSS_ATOM> CSS_DEF;
typedef vector <CSS_ATOM>::iterator CSS_ITER;
typedef vector <CSS_ATOM>::const_iterator CSS_CITER;
typedef vector <CSS_ATOM>::reverse_iterator CSS_RITER;
typedef vector <CSS_ATOM>::const_reverse_iterator CSS_CRITER;



SELECTORS Tokenize(const string & s, const string & del = " ", bool trimLR = true)
{
	SELECTORS ret;
	int end = -1 * del.size();
	do {
		int start = end + del.size();
		end = s.find(del, start);
		string token = s.substr(start, end - start);
		if (trimLR)
			trim(token);
		if (! token.empty())
			ret.push_back(token);
	} while (end != -1);
	return ret;
}


SELECTORS ProcessSelectors(const LINES & lines) {
	stringstream buf;
	for (LINES_CITER i = lines.begin(); i != lines.end(); ++i)
		buf << *i << " ";
	
	return Tokenize(buf.str(), ",");
}

BODY ProcessBody(const LINES & lines) {
	stringstream buf;
	for (LINES_CITER i = lines.begin(); i != lines.end(); ++i)
		buf << *i << " ";
	BODY body;

	vector<string> attribs = Tokenize(buf.str(), ";");
	if (attribs.empty())
		throw "empty structure found";
	
	for (vector<string>::iterator cur = attribs.begin(); cur != attribs.end(); ++cur) {
		vector<string> parts = Tokenize(*cur, ":");
		if (parts.size() == 1)
			throw "Unknown structure (maybe missing :) for attribute";
		if (parts.size() > 2)
			throw "Error (multi:) during processing an attribute";
		body.addAttrib(parts[0], parts[1]);
	}

	return body;
}

LINES ReadUntilEndOfBody(LINES& cssLines) {
	LINES bodyLines;

	while (!cssLines.empty()) {
		string line = cssLines.front();
		cssLines.pop_front();

		STR_ITER endPos = find(line.begin(), line.end(), '}');
		//ITERS startPos = find(line.begin(), line.end(), '{');
		//if (startPos < endPos) {

		if (endPos != line.end()) {
			bodyLines.push_back(line.substr(0, endPos - line.begin()));
			if (endPos + 1 < line.end()) {
				cssLines.push_front(line.substr(endPos - line.begin() + 1));
			}
			return bodyLines;
		}
		else {
			bodyLines.push_back(line);
		}
	}
		
	throw "missing } in line :";
}

void ProcessCss(LINES &lines, CSS_DEF &ret) {
	//CSS_DEF ret;
	LINES selectorLines;
	
	while (lines.size() > 0) {
		string line = lines.front();
		lines.pop_front();
		size_t pos = line.find('{');
		if ( pos != string::npos)
		{
			if (pos > 0) {
				string selector = line.substr(0, pos);
				selectorLines.push_back(selector);
			}

			lines.push_front(line.substr(pos + 1));
			LINES bodyLines = ReadUntilEndOfBody(lines);
			SELECTORS selectors = ProcessSelectors(selectorLines);
			BODY body = ProcessBody(bodyLines);
			ret.push_back(CSS_ATOM(selectors, body));
			selectorLines.erase(selectorLines.begin(), selectorLines.end());
		}
		else
			selectorLines.push_back(line);

	}
	//return ret;
}

void QueryCSS(CSS_DEF & cssDef, const string & question) {
	if (question == "?")
		cout << question << " == " << cssDef.size() << endl;
	else {
		vector<string> tokens = Tokenize(question, ",");
		if (tokens.size() != 3)
			return;
		string sel = tokens[0];
		string group = tokens[1];
		string cmd = tokens[2];

		int pos = -1;
		try {
			pos = stoi(sel)-1;
		}
		catch (...) {
		}

		if ((pos >= int(cssDef.size())) && (group == "S" || group == "A" || group =="D"))
			return;

		if (cmd == "?") {
			int cnt = 0;

			if (pos >= 0) {
				if (group == "S")
					cnt = cssDef[pos].selectors.size();
				else if (group == "A")
					cnt = cssDef[pos].body.keys.size();
				else
					return;
			}
			else {
				if (group == "S")
					for (CSS_CITER atom = cssDef.begin(); atom != cssDef.end(); ++atom) {
						if (find(atom->selectors.begin(), atom->selectors.end(), sel) != atom->selectors.end())
							cnt++;
					}
				else if (group == "A")
					for (CSS_CITER atom = cssDef.begin(); atom != cssDef.end(); ++atom) {
						if (find(atom->body.keys.begin(), atom->body.keys.end(), sel) != atom->body.keys.end())
							cnt++;
					}
				else
					return;
			}
			cout << question << " == " << cnt << endl;
		}
		else {
			string res;
			if (group == "S") {
				int pos1;
				try {
					pos1 = stoi(cmd)-1;
				}
				catch (...) {
					return;
				}
				if (pos1 >= cssDef[pos].selectors.size())
					return;
				res = cssDef[pos].selectors[pos1];
			}
			else if (group == "A") {
				res = cssDef[pos].body.getAttrib(cmd);
				if (res == "") return;
			}
			else if (group == "E") {
				for (CSS_CRITER atom = cssDef.rbegin(); atom != cssDef.rend(); ++atom) {
					if (find(atom->selectors.begin(), atom->selectors.end(), sel) != atom->selectors.end()) {
						res = atom->body.getAttrib(cmd);
						if (res != "") break;
					}
				}
			}
			else if (group == "D" ) {
				if (cmd == "*") {
					cssDef.erase(cssDef.begin() + pos);
					res = "deleted" ;
				}
				else {
					if (cssDef[pos].body.removeAttrib(cmd))
					{
						if (cssDef[pos].body.keys.size() == 0)
							cssDef.erase(cssDef.begin() + pos);
						res = "deleted";
					}
				}
			}
			if (res != "")
				cout << question << " == " << res << endl;

		}
	}
}


int main() {
	/*
	ifstream input;
	input.open("c:\\work\\projektAiSD\\cpp_tests\\css_proc\\x64\\Debug\\5.in");
	if (!input) {
		cerr << "Error code: " << strerror(errno); // Get some info as to why
		return 0;
	}
	*/
	istream &input = cin;


	LINES lines;
	bool queryMode = false;
	vector<CSS_ATOM> css;
	
	while (!input.eof()) {
		string line;
		getline(input, line);
		if (line == "????") {
			queryMode = true;
			ProcessCss(lines, css);
			continue;
		}
		if (line == "****") {
			queryMode = false;
			continue;
		}
		if (queryMode) {
			QueryCSS(css, line);
			cout.flush();
		}
		else
			lines.push_back(line);
	}
}