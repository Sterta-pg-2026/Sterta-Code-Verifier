#include <iostream>
class String {
private:
    char* m_data;
    size_t m_size;
    
public:
    static const size_t npos = static_cast<size_t>(-1);
    // Konstruktor
    String();
    friend std::istream& operator>>(std::istream& in, String& str);
    friend std::ostream& operator<<(std::ostream& out, const String& str);

    // Konstruktor z jednym argumentem
    String(const char* str);

    // Konstruktor kopiujcy
    String(const String& other);

    // Destruktor
    ~String();

        // Funkcja zwracajca rozmiar stringa
        size_t size() const;

    // Funkcja zwracajca wskanik do danych stringa
        const char* c_str() const;

    // Operator przypisania
        String& operator=(const String& other);

    // Operator dodawania stringw
        String operator+(const String& other) const;

    // Operator porwnania stringw
        bool operator==(const String& other) const;

    // Operator nierwnoci stringw
        bool operator!=(const String& other) const;

    // Operator mniejszoci stringw
        bool operator<(const String& other) const;

    // Operator wikszoci stringw
        bool operator>(const String& other) const;

    // Operator mniejszoci lub rwnoci stringw
        bool operator<=(const String& other) const;

    // Operator wikszoci lub rwnoci stringw
        bool operator>=(const String& other) const;

    // Operator indeksowania
        char& operator[](size_t index);

    // Funkcja zwracajca znak na podanej pozycji
        char& at(size_t index);

    // Funkcja przeksztacajca string na liczbe calkowita
    int to_int() const ;
    

    void erase(size_t pos, size_t count);

    String substr(size_t pos, size_t count) const;

    size_t find(const String& substr) const;

    bool empty() const;

    size_t find_first_of(const char* chars) const;

    size_t find_first_not_of(const char* charsToSkip) const;

    size_t find_last_not_of(const char* chars) const;

    size_t find_first_of(const char* chars, size_t pos) const;

    size_t find_last_of(const char c) const;
    
};
