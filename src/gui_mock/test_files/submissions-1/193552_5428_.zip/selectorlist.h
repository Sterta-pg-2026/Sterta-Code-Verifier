#pragma once
#include <iostream>
using namespace std;


//STRUKTURA WZA SELEKTORW

struct SelectorNode {
    char* selector;
    SelectorNode* next;
};

//LISTA SELEKTORW
class SelectorList {


public:
    SelectorNode* start = nullptr;
    SelectorNode* end = nullptr;
    int elements = 0;


    SelectorList() {

    }

    void AddLast(char* selector);

    int GetSize() const;

    void FindSelector(int which_one, int which_selector) const;

    int CountAll(char* selector) const;


    void FreeMemo();

    ~SelectorList();
};

void SelectorList::AddLast(char* selector) {
    if (elements > 0) {
        SelectorNode* helper = start;
        while (helper != nullptr) {
            if (!strcmp(helper->selector, selector)) {
                return;
            }
            helper = helper->next;
        }
    }
    if (selector != nullptr) {

        SelectorNode* newnode = new SelectorNode;
        newnode->selector = (char*)malloc(strlen(selector) * sizeof(char));
        newnode->next = nullptr;
        strcpy(newnode->selector, selector);

        if (!elements) start = newnode;
        else end->next = newnode;

        end = newnode;
        this->elements++;
    }
}

void SelectorList::FindSelector(int which_one, int which_selector) const {
    if (which_selector >= elements) {
        return;
    }
    SelectorNode* currnode = start;
    for (int i = 1; i <= which_selector; i++) {
        currnode = currnode->next;
    }
    printf("%d,S,%d == %s\n", which_one + 1, which_selector + 1, currnode->selector);
}

int SelectorList::CountAll(char* selector) const {
    /*  if (selector[0] == 'h' && selector[1] == '1')
          bool a = true;*/
    if (start == nullptr) return 0;
    SelectorNode* node = start;
    for (int i = 0; i < elements; i++) {
        if (node == nullptr) return 0;;
        if (!strcmp(node->selector, selector)) {
            return 1;
        }
        node = node->next;
    }
    return 0;
}

int SelectorList::GetSize() const {
    return this->elements;
}

void SelectorList::FreeMemo() {
    SelectorNode* obecny = start;
    while (obecny != nullptr) {
        SelectorNode* nastepny = obecny->next;
        free(obecny->selector);
        delete obecny;
        obecny = nastepny;
    }
    start = nullptr;
    end = nullptr;
    elements = 0;

}
SelectorList::~SelectorList() {

}