#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <string.h>
#include "mystring.h"
#include "selectorlist.h"
#include "attributeslist.h"
#include "mainlist.h"

using namespace std;

#define T 8
#define COMMANDMODE 1
#define CSSMODE 0
#define SELECTORPARSE 0
#define ATTRIBUTEPARSE 1
#define NAME 0
#define VALUE 1


struct Init {
    int ongoing;
    int mode;
    int parsemode;
};


//FUNKCJA ROZDZIELA TEKST TMP NA NAZW I WARTO ATRYBUTU
void AttributeSplit(Section* section, char* tmp) {
    int split_mode = 0;
    Attribute attribute;
    for (int i = 0; i < (int)strlen(tmp); i++) {
        if (tmp[i] == ':') {
            split_mode = i;
            break;
        }
    }
    if (split_mode) {
        char* name = (char*)malloc((split_mode + 1) * sizeof(char));


        //wykluczanie spacji jako pocztku nazwy atrybutu
        if (tmp[0] != ' ') {
            strncpy(name, tmp, split_mode);
            name[split_mode] = '\0';
        }
        else {
            strncpy(name, tmp + 1, split_mode);
            name[split_mode - 1] = '\0';
        }
        attribute.attrname = new char[strlen(name) + 1];
        strcpy(attribute.attrname, name);
        char* value = (char*)malloc((strlen(tmp) - split_mode + 1) * sizeof(char));

        //wykluczanie spacji jako pocztku nazwy wartoci atrybutu
        if (tmp[split_mode + 1] != ' ') {
            strncpy(value, tmp + split_mode + 1, strlen(tmp) - split_mode - 1);
            value[strlen(tmp) - split_mode - 1] = '\0';
        }
        else {
            strncpy(value, tmp + split_mode + 2, strlen(tmp) - split_mode - 1);
            value[strlen(tmp) - split_mode - 2] = '\0';
        }
        attribute.attvalue = new char[strlen(value) + 1];
        strcpy(attribute.attvalue, value);
        //cout << name << " " << value << "\n";
        section->attributes.AddLast(attribute);
        free(name);
        free(value);
    }
}

void CopyChar(char*& tmp, char* input, int& iter, int i) {
    tmp[iter - 1] = input[i];
    iter++;
    tmp = (char*)realloc(tmp, iter);
    tmp[iter - 1] = '\0';
}

//FUNKCJA PARSUJCA  WPISANY INPUT JEELI JEST ON SEKCJ CSS
void Css_Parse(char* input, Init* init, MainList* mainlist) {
    if (input[0] != '{')
    {

        init->parsemode = SELECTORPARSE;
        char* tmp = (char*)malloc(BASICSIZE * sizeof(char));
        Section section;
        int iter = BASICSIZE;
        for (int i = 0; i < (int)strlen(input); i++) {
            if (init->parsemode == SELECTORPARSE) {

                if (input[i] == ',' || input[i] == '{') {
                    section.selectors.AddLast(tmp);
                    //cout << "SELEKTOR " << tmp << "\n";
                    free(tmp);
                    iter = 1;
                    tmp = (char*)malloc(iter * sizeof(char));
                    if (input[i] == '{') {
                        init->parsemode = ATTRIBUTEPARSE;
                    }
                }
                else {
                    CopyChar(tmp, input, iter, i);
                }
                tmp[iter - 1] = '\0';
            }
            else {
                if (input[i] == ';' || input[i] == '}') {
                    AttributeSplit(&section, tmp);
                    free(tmp);
                    iter = 1;
                    tmp = (char*)malloc(iter * sizeof(char));
                }
                else {
                    CopyChar(tmp, input, iter, i);
                }
                tmp[iter - 1] = '\0';
            }
        }
        mainlist->AddLast(section);
        free(tmp);
    }

}
void GetLast(char* input, char** thirdpart) {
    int commacounter = 0, i = 0, pos = 0;

    for (i = 0; commacounter < 2; i++) {
        if (input[i] == ',') {
            commacounter++;
        }
        if (commacounter == 2) pos = i;
    }
    *thirdpart = (char*)malloc(sizeof(char) * (strlen(input) - pos + 1));

    if (*thirdpart == NULL) {
        return;
    }

    strncpy(*thirdpart, input + pos + 1, strlen(input) - pos);
    (*thirdpart)[strlen(input) - pos] = '\0';
}
void GetFirst(char* input, char** firstpart) {
    int commacounter = 0, i = 0;
    for (i = 0; commacounter < 1; i++) {
        if (input[i] == ',') {
            commacounter++;
            break;
        }
    }
    *firstpart = (char*)malloc(i * sizeof(char) + 1);

    if (*firstpart == NULL) {
        return;
    }

    strncpy(*firstpart, input, i);
    (*firstpart)[i] = '\0';
}

void CommandParse(char* input, MainList* mainlist) {
    if (input[0] == NULL || mainlist == nullptr) {
        return;
    }
    int which = 0, second = 0;
    char a, helper;
    char* firstpart;
    char* thirdpart;
    int commas = 0;
    for (int i = 0; i < (int)strlen(input); i++) {
        if (input[i] == ',') {
            commas++;
        }
    }
    if (commas < 3) {
        if (sscanf(input, "%d,%c,A", &which, &a) == 2) {
            if (which < 0 || second < 0) return;
            if (a == 'D') {
                if (sscanf(input, "%d,%c,%c", &which, &a, &helper) == 3 && helper == '*') {
                    if (mainlist->DeleteSection(which - 1)) {
                        printf("%d,D,* == deleted\n", which);
                    }
                }
                else {
                    GetLast(input, &thirdpart);
                    if (sscanf(input, "%d,%c,%s", &which, &a, thirdpart) == 3) {
                        mainlist->DeleteAttribute(which - 1, thirdpart);
                    }
                    free(thirdpart);
                }
            }
            else if (a == 'S') {
                if (sscanf(input, "%d,%c,%c", &which, &a, &helper) == 3 && helper == '?') {
                    mainlist->CountSelectors(which - 1);
                }
                else if (sscanf(input, "%d,%c,%d", &which, &a, &second) == 3) {
                    mainlist->JSelectorForIBlock(which - 1, second - 1);
                }
            }
            else if (a == 'A') {
                if (sscanf(input, "%d,%c,%c", &which, &a, &helper) == 3 && helper == '?') {
                    mainlist->CountAttributes(which - 1);
                }
                else {
                    GetLast(input, &thirdpart);
                    if (sscanf(input, "%d,%c,%s", &which, &a, thirdpart) == 3) {
                        mainlist->FindAttribute(which - 1, thirdpart);
                    }
                    free(thirdpart);
                }
            }
        }
        else {

            GetFirst(input, &firstpart);
            if (input[strlen(input) - 3] == 'S') {
                mainlist->SelectorCounter(firstpart);
            }
            else if (input[strlen(input) - 3] == 'A') {
                mainlist->AttributeCounter(firstpart);
            }
            else {
                GetLast(input, &thirdpart);
                mainlist->FindLastAttribute(firstpart, thirdpart);
                free(thirdpart);
            }
            free(firstpart);




        }
    }
}

void InputParse(char* input, Init* init, MainList* mainlist) {
    if (!strcmp(input, "****")) {
        init->mode = CSSMODE;
    }
    else if (!strcmp(input, "????")) {
        init->mode = COMMANDMODE;
    }
    else if (!strcmp(input, "?")) {
        printf("? == %d\n", mainlist->GetSize());
    }
    else {
        switch (init->mode) {
        case CSSMODE:
            Css_Parse(input, init, mainlist);
            break;
        case COMMANDMODE:
            if (input != nullptr) {
                CommandParse(input, mainlist);
            }
            break;
        }
    }
}

int main() {
    MyString tmp;
    Init init;
    init.ongoing = 1, init.mode = CSSMODE, init.parsemode = SELECTORPARSE;
    MainList mainlist;
    while (init.ongoing) {
        if (init.mode == COMMANDMODE) {
            tmp.CommandString();
        }
        else {
            tmp.CreateString();
        }
        char* input = (char*)malloc((tmp.GetSize() + 1) * sizeof(char));
        strcpy(input, tmp.tmp);
        InputParse(input, &init, &mainlist);
        free(input);
        tmp.Destroy();

    }
    return 0;
}