#pragma once
#pragma once
#include<iostream>
#include <string.h>

#define BASICSIZE 1
#define BIGSIZE 2000
#define BASICCHARACTERVALUE ' '

class MyString {
private:
    int size;
public:
    char* tmp;
    MyString() {
        size = BASICSIZE;
        tmp = (char*)malloc(size * sizeof(char));
    }

    MyString(const MyString& copy) {
        size = copy.size;
        tmp = (char*)malloc(size * sizeof(char));
        strcpy(tmp, copy.tmp);
    }


    //funkcja usuwajaca niepotrzebne bia�e znaki
    static void DeleteWhite(char* input) {
        int j = 0;
        int input_len = strlen(input);
        bool space_remover = false;

        bool selector = true;

        char* output = (char*)malloc(strlen(input) * sizeof(char));
        for (int i = 0; i < input_len; i++) {
            if (input[i] == '{') {
                selector = false;
            }
            else if (input[i] == '}') {
                selector = true;
            }

            if (input[i] < ' ')
                continue;
            else if (input[i] == ' ')
            {

                if (selector)
                {
                    if (space_remover)
                        continue;
                    else if (i == 0 || j == 0)
                    {
                        space_remover = true;
                    }
                    else
                    {
                        if (input[i - 1] == ',' || input[i - 1] == '}')
                        {
                            space_remover = true;
                        }
                        else if (i < (input_len - 1))
                        {
                            int h = 0;
                            while (input[i] == ' ')
                            {
                                h++;
                                i++;
                            }
                            if (input[i] != '{')
                                i -= h;
                            else selector = false;

                        }
                    }
                }
                else
                {
                    if (space_remover)
                        continue;
                    else if (input[i - 1] == '{' || input[i - 1] == ';')
                    {
                        space_remover = true;
                    }
                    else space_remover = false;
                }
            }
            else space_remover = false;

            if (input[i] >= ' ' && !space_remover) {
                space_remover = false;
                output[j++] = input[i];
            }
        }
        output[j] = '\0';
        strcpy(input, output);
        free(output);
    }

    //tworzenie inputu do sekcji CSS
    void CreateString() {
        size = BASICSIZE;
        char* tmp2 = (char*)malloc(BIGSIZE * sizeof(char));

        char character = BASICCHARACTERVALUE;
        int help = BASICSIZE - 1;
        while (character != '}') {
            character = (char)getchar();
            if (character == EOF) {
                free(tmp2);
                exit(1);
            }
            if (character == '\n') {
                if (tmp2[help - 1] == '?') break;
                else tmp2[help] = ' ';
            }
            else tmp2[help] = character;
            help++;
            size++;
            //tmp = (char*)realloc(tmp, size);
        }
        tmp2[size - 1] = '\0';
        tmp = (char*)malloc(size * sizeof(char));
        strncpy(tmp, tmp2, size);
        DeleteWhite(tmp);
        free(tmp2);
    }

    //tworzenie inputu do komend
    void CommandString() {
        size = BASICSIZE;
        char* tmp2 = (char*)malloc(BIGSIZE * sizeof(char));

        char character = BASICCHARACTERVALUE;
        while (character != '\n') {
            character = (char)getchar();
            if (character == EOF) {
                free(tmp2);
                exit(1);
            }
            tmp2[size - 1] = character;
            if (tmp2[size - 1] == EOF) {
                exit(1);
            }
            size++;
            //tmp2 = (char*)realloc(tmp, size);
        }
        tmp2[size - 2] = '\0';
        tmp = (char*)malloc(size * sizeof(char));
        strncpy(tmp, tmp2, size);
        free(tmp2);
    }


    int GetSize() const {
        int tmp_size = 0;
        char* copy = tmp;
        while (*copy) {
            tmp_size++;
            copy++;
        }
        return tmp_size;
    }
    void Destroy() {
        free(tmp);
        size = BASICSIZE;
    }

    MyString& operator=(const MyString& second_str) {
        if (this != &second_str) {
            size = second_str.size;
            tmp = (char*)malloc(size * sizeof(char));
            strcpy(tmp, second_str.tmp);
        }
        return *this;
    }
    ~MyString()
    {

    }
};