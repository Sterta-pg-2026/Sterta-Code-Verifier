#pragma once
#include <string.h>

//STRUKTURA ATRYBUTW
struct Attribute {
    char* attrname;
    char* attvalue;
};



//STRUKTURA WZA ATRYBUTW
struct AttributesNode {
    AttributesNode* next;
    Attribute attribute;
};

//LISTA ATRYBUTW
class AttributesList {
public:

    AttributesNode* start = nullptr;
    AttributesNode* end = nullptr;
    int elements = 0;

    AttributesList() {
    }

    void AddLast(Attribute attribute);

    void DeleteAttribute(int which_one, char* attribute);

    void FindAttribute2(int which_one, char* attribute) const;

    int CountAll(char* attribute) const;

    void SearchFor(char* selector, char* attribute, int* found) const;

    int GetSize() const;

    void FreeMemo();

    ~AttributesList();
};

void AttributesList::AddLast(Attribute attribute) {
    if (elements > 0) {
        AttributesNode* currnode = start;
        while (currnode != NULL) {
            if (strcmp(currnode->attribute.attrname, attribute.attrname) == 0) {
                free(currnode->attribute.attvalue);
                currnode->attribute.attvalue = _strdup(attribute.attvalue);
                return;
            }
            currnode = currnode->next;
        }

    }
    AttributesNode* newnode = new AttributesNode;
    newnode->attribute = attribute;
    newnode->next = nullptr;

    if (!elements) start = newnode;
    else end->next = newnode;

    end = newnode;
    elements++;
}

void AttributesList::DeleteAttribute(int which_one, char* attribute) {
    AttributesNode* node = start;
    AttributesNode* previous = nullptr;
    for (int i = 0; i < elements; i++) {
        if (!strcmp(node->attribute.attrname, attribute)) {
            if (previous != nullptr) previous->next = node->next;
            else start = node->next;

            if (end == node) end = previous;

            delete[] node->attribute.attrname;
            delete[] node->attribute.attvalue;
            delete node;

            printf("%d,D,%s == deleted\n", which_one + 1, attribute);

            elements--;
            break;
        }
        previous = node;
        node = node->next;

    }
}

void AttributesList::FindAttribute2(int which_one, char* attribute) const {
    AttributesNode* node = start;
    for (int i = 0; i < elements; i++) {
        if (!strcmp(node->attribute.attrname, attribute)) {
            printf("%d,A,%s == %s\n", which_one + 1, attribute, node->attribute.attvalue);
            return;
        }


        node = node->next;
    }
}

int AttributesList::CountAll(char* attribute) const {

    AttributesNode* node = start;

    for (int i = 0; i < elements; i++) {

        if (!strcmp(node->attribute.attrname, attribute)) {
            return 1;
        }
        node = node->next;
    }
    return 0;
}

void AttributesList::SearchFor(char* selector, char* attribute, int* found) const {
    AttributesNode* node = start;
    for (int i = 0; i < elements; i++) {
        if (!strcmp(node->attribute.attrname, attribute)) {
            *found = 1;
            printf("%s,E,%s == %s\n", selector, attribute, node->attribute.attvalue);
        }
        node = node->next;
    }
}

int AttributesList::GetSize() const {
    return this->elements;
}

void AttributesList::FreeMemo() {
    AttributesNode* obecny = start;
    while (obecny != nullptr) {
        AttributesNode* nastepny = obecny->next;
        delete[] obecny->attribute.attrname;
        delete[] obecny->attribute.attvalue;
        delete obecny;
        obecny = nastepny;
    }
    start = nullptr;
    end = nullptr;
    elements = 0;
}

AttributesList::~AttributesList() {

}