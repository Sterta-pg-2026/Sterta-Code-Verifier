#pragma once
#include "attributeslist.h"
#include "selectorlist.h"

#define T 19


//STRUKTURA BLOK�W CSSA
struct Section {
    SelectorList selectors;
    AttributesList attributes;
};

//STRUKTURA W�Z��W LISTY G��WNEJ
struct CssNode {
    Section* sections = new Section[T];
    CssNode* previous;
    CssNode* next;
    int filled = 0;
    CssNode() {
        previous = nullptr;
        next = nullptr;
        filled = 0;
    }
};

class MainList {
private:
    CssNode* start;
    CssNode* end;
    int size;
public:
    MainList() {
        start = nullptr;
        end = nullptr;
        size = 0;
    }

    void AddLast(Section& section);

    int DeleteSection(int which_one);

    void CountSelectors(int which_one) const;

    void CountAttributes(int which_one) const;

    void JSelectorForIBlock(int which_one, int which_selector) const;

    void DeleteAttribute(int which_one, char* attribute);

    void FindAttribute(int which_one, char* attribute) const;

    void SelectorCounter(char* selector) const;

    void AttributeCounter(char* attribute) const;

    void FindLastAttribute(char* selector, char* attribute) const;

    int GetSize() const;

    ~MainList() {
        CssNode* currnode = start;
        while (currnode != nullptr) {
            CssNode* nextnode = currnode->next;
            for (int i = 0; i < currnode->filled; i++) {
                currnode->sections[i].attributes.FreeMemo();
                currnode->sections[i].selectors.FreeMemo();
            }
            delete currnode->sections;
            delete currnode;
            currnode = nextnode;
        }
    }
};

void MainList::AddLast(Section& section) {
    if (section.attributes.elements > 0) {
        if (end == nullptr) {
            start = new CssNode;
            end = start;
        }
        else if (size % T == 0) {
            end->next = new CssNode;

            end->next->previous = end;
            end = end->next;
        }
        end->sections[size % T] = section;
        size++;
        end->filled++;
    }
}


int MainList::DeleteSection(int which_one) {
    if (which_one >= size || which_one < 0) {
        return 0;
    }
    CssNode* node = start;
    int wanted_node = which_one / T;
    int wanted_section = which_one % T;
    for (int i = 0; i < wanted_node; i++) {
        node = node->next;
    }
    for (int i = wanted_section + 1; i < node->filled; i++) {
        node->sections[i - 1] = node->sections[i];
    }
    node->filled--;
    size--;
    if (node->filled == 0) {
        if (node == start) {
            start = node->next;
        }
        else if (node == end) {
            end = node->previous;
        }
        else {
            node->next->previous = node->previous;
            node->previous->next = node->next;
        }
        delete node;
    }
    return 1;
}
void MainList::CountSelectors(int which_one) const {
    if (which_one + 1 > size || which_one < 0) {
        return;
    }

    CssNode* node = start;


    int wanted_node = which_one / T;
    int wanted_section = which_one % T;

    for (int i = 0; i < wanted_node; i++) {
        if (node->next != nullptr) {
            node = node->next;
        }
    }

    if (node != nullptr) {
        printf("%d,S,? == %d\n", which_one + 1, node->sections[wanted_section].selectors.GetSize());
    }
}

void MainList::CountAttributes(int which_one) const {
    if (which_one + 1 > size || which_one < 0)  {
        return;
    }
    CssNode* node = start;
    int wanted_node = which_one / T;
    int wanted_section = which_one % T;
    for (int i = 0; i < wanted_node; i++) {
        if(node!=nullptr)node = node->next;
    }
    if (node != nullptr) {
        printf("%d,A,? == %d\n", which_one + 1, node->sections[wanted_section].attributes.GetSize());
    }
}

void MainList::JSelectorForIBlock(int which_one, int which_selector) const {
    if (which_one + 1 > size || which_one < 0) {
        return;
    }
    CssNode* node = start;
    int wanted_node = which_one / T;
    int wanted_section = which_one % T;

    for (int i = 0; i < wanted_node; i++) {
        node = node->next;
    }
    node->sections[wanted_section].selectors.FindSelector(which_one, which_selector);
}

void MainList::DeleteAttribute(int which_one, char* attribute) {
    if (which_one + 1 > size || which_one < 0) {
        return;
    }
    CssNode* node = start;
    int wanted_node = which_one / T;
    int wanted_section = which_one % T;

    for (int i = 0; i < wanted_node; i++) {
        node = node->next;
    }
    node->sections[wanted_section].attributes.DeleteAttribute(which_one, attribute);

    if (node->sections[wanted_section].attributes.GetSize() == 0) {
        if (DeleteSection(which_one) == 1) {
            for (int i = which_one; i < size; i++) {
                int current_node = i / T;
                int current_section = i % T;
                if (current_node != wanted_node || current_section != wanted_section) {
                    node->sections[current_section] = node->sections[current_section + 1];
                }
                return;
            }
        }
    }
}

void MainList::FindAttribute(int which_one, char* attribute)  const {
    if (which_one + 1 > size || which_one < 0) {
        return;
    }
    CssNode* node = start;
    int wanted_node = which_one / T;
    int wanted_section = which_one % T;

    for (int i = 0; i < wanted_node; i++) {
        if (node->next != nullptr) {
            node = node->next;
        }
    }
    if (node!=nullptr && node->filled > 0) {
        node->sections[wanted_section].attributes.FindAttribute2(which_one, attribute);
    }
            
}

void MainList::SelectorCounter(char* selector)  const {
    int how_many = 0;
    if (start == nullptr) return;
    CssNode* node = start;
    for (int j = 0; j < size / T + 1; j++) {
        for (int i = 0; i < node->filled; i++) {
            how_many += node->sections[i].selectors.CountAll(selector);
        }
        if (node != end) {
            node = node->next;
        }
    }
    printf("%s,S,? == %d\n", selector, how_many);
}

void MainList::AttributeCounter(char* attribute)  const {
    int how_many = 0;
    if (start == nullptr) return;
    CssNode* node = start;
    for (int j = 0; j < size / T + 1; j++) {
        for (int i = 0; i < node->filled; i++) {
            how_many += node->sections[i].attributes.CountAll(attribute);
        }
        node = node->next;
    }
    printf("%s,A,? == %d\n", attribute, how_many);
}

void MainList::FindLastAttribute(char* selector, char* attribute) const {
    if (start == nullptr || size==0 || selector==nullptr || attribute==nullptr) return;
    CssNode* node = end;
    int found = 0;
    for (int j = size / T; j >= 0; j--) {
        for (int i = node->filled - 1; i >= 0; i--) {
            if (node->sections[i].selectors.CountAll(selector)) {
                node->sections[i].attributes.SearchFor(selector, attribute, &found);
                if (found) return;
            }
        }
        node = node->previous;
    }
}

int MainList::GetSize()  const {
    return size;
}