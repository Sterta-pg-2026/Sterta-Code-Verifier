#pragma once
#include <iostream>
#include "selectorlist.h"
#include "attrlist.h"

using namespace std;

#define T 8

struct Section {
	SelectorList* selectors = new SelectorList;
	AttrList* atributes = new AttrList;
};

struct MainNode {
	Section sections[T] = {};
	MainNode* next;
	MainNode* previous;
};

class MainList {
private:
	MainNode* head;
	MainNode* tail;
public:
	MainList();
	int Length();
	MainNode* GetAtPos(int position);
	void InsertAtTail();
	void InsertAtHead();
	void RemoveFirst();
	void RemoveLast();
	void RemoveNode(MainNode* node);
};
