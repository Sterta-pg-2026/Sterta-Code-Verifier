#include <iostream>
#include "mainlist.h"

using namespace std;


MainList::MainList() : head(nullptr), tail(nullptr) {
	this->head = nullptr;
	this->tail = nullptr;
}


int MainList::Length() {
	int counter = 0;
	MainNode* tmp = head;
	while (tmp != NULL) {
		counter++;
		tmp = tmp->next;
	}
	return counter;
}

MainNode* MainList::GetAtPos(int position) {
	MainNode* tmp = head;
	while (tmp != NULL) {
		if (position == 0) return tmp;
		position--;
		tmp = tmp->next;
	}
	return NULL;
}

void MainList::InsertAtTail() {
	MainNode* newNode = new MainNode;
	newNode->previous = tail;
	newNode->next = NULL;
	if (tail != NULL) tail->next = newNode;
	if (head == NULL) head = newNode;
	tail = newNode;
}

void MainList::InsertAtHead() {
	MainNode* newNode = new MainNode();
	newNode->previous = nullptr;
	newNode->next = head;
	if (head != nullptr) head->previous = newNode;
	if (tail == nullptr) tail = newNode;
	head = newNode;
}

void MainList::RemoveFirst() {
	head = head->next;
	delete head->previous;
	head->previous = nullptr;
}

void MainList::RemoveLast() {
	tail = tail->previous;
	delete tail->next;
	tail->next = nullptr;
}

void MainList::RemoveNode(MainNode* node) {
	//TODO
}