#pragma once
#include <iostream>
#include <string>

using namespace std;

struct AttrNode {
	string attribute="";
	string value = "";
	AttrNode* next = nullptr;
	AttrNode* previous = nullptr;
};

class AttrList {
private:
	AttrNode* head;
	AttrNode* tail;
public:
	AttrList();
	void Print();
	int Length();
	AttrNode* GetAtPos(int position);
	void InsertAtTail(string attribute, string value);
	void InsertAtHead(string attribute, string value);
	void RemoveFirst();
	void RemoveLast();
	void RemoveNode(AttrNode* node);
};