#include <iostream>
#include <cstdlib>
#include <string>
#include "mainlist.h"
#include "attrlist.h"
#include "selectorlist.h"

#define COMMANDS 0
#define SELECTORS 1
#define ATTRIBUTES 2
#define ENTER '\n'
#define TABULATION '\t'


using namespace std;

int main() {
	MainList mainList;
	string line="";
	int quesMarks = 0, stars=0, blocks=0;
	short int mode = SELECTORS, inputLength = 0;
	char ch;
	/*
	mainList.InsertAtTail();
	cout << mainList.Length() << endl;
	MainNode* huuj = mainList.GetAtPos(0);
	Section t=huuj->sections[0];
	cout << "sections[0]" << endl;;
	AttrList ratatata;
	ratatata.InsertAtTail("chuj", "cycki");
	cout << "ratatata" << endl;
	cout << ratatata.Length() << endl;
	cout << t.atributes->Length();*/
	
	while ((ch = getchar()) != EOF) {
		
		if (mode != COMMANDS) {


			if (mode == SELECTORS && (ch == '{' || ch==',')) {
				//REMOVING SPACES FROM BEGINNING AND END
				if (inputLength > 0 && line[inputLength - 1] == ' ') line[inputLength - 1] = '\0';
				if (inputLength > 0 && line[0] == ' ')
					for (int i = 0; i < inputLength - 1; i++) line[i] = line[i + 1];

				//SAVING TO SELECTORS
				if (blocks % T == 0) mainList.InsertAtTail();
				mainList.GetAtPos(blocks / T)->sections[blocks % T].selectors->InsertAtTail(line);
				line = "";
				inputLength = 0;
			}

			if (mode == ATTRIBUTES) {
				if (ch == ':') {
					mainList.GetAtPos(blocks / T)->sections[blocks % T].atributes->InsertAtTail(line, "");
					line = "";
					inputLength = 0;
				}
				if (ch == ';') {
					for (int i = 0; i < inputLength - 1; i++) line[i] = line[i + 1];
					mainList.GetAtPos(blocks / T)->sections[blocks % T].atributes->GetAtPos(mainList.GetAtPos(blocks / T)->sections[blocks % T].atributes->Length() - 1)->value = line;
					line = "";
					inputLength = 0;
				}
			}

			if (ch == '{') {
				mode = ATTRIBUTES;
				line = "";
				inputLength = 0;
			}

			else if (ch == '}') {
				mode = SELECTORS;
				blocks++;
				line = "";
				inputLength = 0;
			}
			else if (ch == ENTER || ch == TABULATION) cout << "line: " << line << endl;
			else {
				line = line + ch;
				inputLength++;

				if (ch == '?') quesMarks++;
				else quesMarks = 0;
				if (quesMarks == 4) {
					mode = COMMANDS;
					line = "";
					inputLength = 0;
					continue;
				}
			}

			
		}
























		//COMMANDS
		else {
			//CHECKING FOR COMMAND EXIT
			if (ch == '*') stars++;
			else stars = 0;
			if (stars == 4) {
				mode = SELECTORS;
				continue;
			}

			if (ch!=ENTER) line = line + ch;
			else if (line!="") {
				//COMMAND ?
				if (line == "?") {
					cout << "? == " << blocks << endl;
					continue;
				}
				char commArg1[64] = {};
				int charCounter = 0;
				while (line[charCounter] != ',') {
					commArg1[charCounter] = line[charCounter];
					charCounter++;
				}
				charCounter++; //SKIPPING THE FIRST ','
				char commArg2 = line[charCounter];
				charCounter += 2; //GOING PAST THE SECOND ','
				char commArg3[64] = {};
				while (line[charCounter] != '\0') {
					int i = 0;
					charCounter++;
					commArg3[i] = line[charCounter];
				}
				
				//FIRST ARGUMENT IS A NUMBER
				if (commArg1[0] >= '0' && commArg1[0] <= '9') {
					int commArg1Int = atoi(commArg1);
					
					//COMMAND WITH S IN THE MIDDLE
					if (commArg2 == 'S') {
						//COMMAND i,S,?
						if (commArg3[0] == '?') {
							if (commArg1Int <= blocks) {
								int selNo = mainList.GetAtPos(blocks / T)->sections[T % 8].selectors->Length();
								cout << "i,S,? == " << selNo << endl;
							}
						}
						//COMMAND i,S,j
						else {
							int selNo = atoi(commArg3);
							if (commArg1Int <= blocks) {
								if (selNo <= mainList.GetAtPos(blocks / T)->sections[T % 8].selectors->Length()) {
									cout << "i,S,j == " << mainList.GetAtPos(blocks / T)->sections[T % 8].selectors->GetAtPos(selNo - 1);
								}
							}
						}
					}

					//COMMAND WITH A IN THE MIDDLE
					if (commArg2 == 'A') {
						//COMMAND i,A,?
						if (commArg3[0] == '?') {
							if (commArg1Int <= blocks) {
								int argNo = mainList.GetAtPos(blocks / T)->sections[T % 8].atributes->Length();
								cout << "i,A,? == " << argNo << endl;
							}
						}
						//COMMAND i,A,n
						else {

						}
					}

					//COMMAND WITH D IN THE MIDDLE
					if (commArg2 == 'D') {
						//COMMAND i,D,*
						if (commArg3[0] == '*') {

						}
						//COMMAND i,D,n
						else {

						}
					}
				}

				//FIRST ARGUMENT IS NOT A NUMBER
				else {
					//COMMAND z,S,?
					if (commArg2 == 'S') {

					}
					//COMMAND n,A,?
					else if (commArg2 == 'A') {

					}
					//COMMAND z,E,n
					else if (commArg2 == 'E') {

					}
				}
				line = "";
				inputLength = 0;
			}
		}
	}
	
	return 0;
}