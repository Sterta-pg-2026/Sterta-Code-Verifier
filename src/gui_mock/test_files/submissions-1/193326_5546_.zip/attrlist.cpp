#include <iostream>
#include <string>
#include "attrlist.h"

using namespace std;

AttrList::AttrList() : head(nullptr), tail(nullptr) {
	this->head = nullptr;
	this->tail = nullptr;
}

void AttrList::Print() {
	AttrNode* tmp = head;
	while (tmp != NULL) {
		cout << tmp->attribute << " ";
		tmp = tmp->next;
	}
}

int AttrList::Length() {
	int counter = 0;
	AttrNode* tmp = head;
	while (tmp != NULL) {
		counter++;
		tmp = tmp->next;
	}
	return counter;
}

AttrNode* AttrList::GetAtPos(int position) {
	AttrNode* tmp = head;
	while (tmp != NULL) {
		if (position == 0) return tmp;
		position--;
		tmp = tmp->next;
	}
	return NULL;
}

void AttrList::InsertAtTail(string attribute, string value) {
	AttrNode* newNode = new AttrNode();
	newNode->attribute = attribute;
	newNode->value = value;
	newNode->previous = tail;
	newNode->next = NULL;
	if (tail != NULL) tail->next = newNode;
	if (head == NULL) head = newNode;
	tail = newNode;
}

void AttrList::InsertAtHead(string attribute, string value) {
	AttrNode* newNode = new AttrNode();
	newNode->attribute = attribute;
	newNode->value = value;
	newNode->previous = nullptr;
	newNode->next = head;
	if (head != nullptr) head->previous = newNode;
	if (tail == nullptr) tail = newNode;
	head = newNode;
}

void AttrList::RemoveFirst() {
	head = head->next;
	delete head->previous;
	head->previous = nullptr;
}

void AttrList::RemoveLast() {
	tail = tail->previous;
	delete tail->next;
	tail->next = nullptr;
}

void AttrList::RemoveNode(AttrNode* node) {
	//TODO
}