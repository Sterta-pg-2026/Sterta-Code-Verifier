#include <iostream>
#include <string>
#include "selectorlist.h"

using namespace std;

SelectorList::SelectorList() : head(nullptr), tail(nullptr) {
	this->head = nullptr;
	this->tail = nullptr;
}

void SelectorList::Print() {
	SelectorNode* tmp = head;
	while (tmp != NULL) {
		cout << tmp->selector << " ";
		tmp = tmp->next;
	}
}

int SelectorList::Length() {
	int counter = 0;
	SelectorNode* tmp = head;
	while (tmp != NULL) {
		counter++;
		tmp = tmp->next;
	}
	return counter;
}

SelectorNode* SelectorList::GetAtPos(int position) {
	SelectorNode* tmp = head;
	while (tmp != NULL) {
		if (position == 0) return tmp;
		position--;
		tmp = tmp->next;
	}
	return NULL;
}

void SelectorList::InsertAtTail(string selector) {
	SelectorNode* newNode = new SelectorNode();
	newNode->selector = selector;
	newNode->previous = tail;
	newNode->next = NULL;
	if (tail != NULL) tail->next = newNode;
	if (head == NULL) head = newNode;
	tail = newNode;
}

void SelectorList::InsertAtHead(string selector) {
	SelectorNode* newNode = new SelectorNode();
	newNode->selector = selector;
	newNode->previous = nullptr;
	newNode->next = head;
	if (head != nullptr) head->previous = newNode;
	if (tail == nullptr) tail = newNode;
	head = newNode;
}

void SelectorList::RemoveFirst() {
	head = head->next;
	delete head->previous;
	head->previous = nullptr;
}

void SelectorList::RemoveLast() {
	tail = tail->previous;
	delete tail->next;
	tail->next = nullptr;
}

void SelectorList::RemoveNode(SelectorNode* node) {
	//TODO
}