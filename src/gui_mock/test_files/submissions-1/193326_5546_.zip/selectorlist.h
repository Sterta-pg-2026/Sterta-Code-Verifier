#pragma once
#include <iostream>
#include <string>

using namespace std;

struct SelectorNode {
	string selector = "";
	SelectorNode* next = nullptr;
	SelectorNode* previous = nullptr;
};

class SelectorList {
private:
	SelectorNode* head;
	SelectorNode* tail;
public:
	SelectorList();
	void Print();
	int Length();
	SelectorNode* GetAtPos(int position);
	void InsertAtTail(string selector);
	void InsertAtHead(string selector);
	void RemoveFirst();
	void RemoveLast();
	void RemoveNode(SelectorNode* node);
};
