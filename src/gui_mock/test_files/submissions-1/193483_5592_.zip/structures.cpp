#include "structures.h"

void createNode(Locations& usedLocations)
{
	Node* newNode = new Node;
	newNode->prev = usedLocations.lastNode;
	newNode->next = nullptr;
	newNode->takenCounter = 0;

	for (int i = 0; i < NODE_ARRAY_SIZE; i++) {
		newNode->blocks[i] = { nullptr, nullptr };
	}

	if (usedLocations.lastNode != nullptr) usedLocations.lastNode->next = newNode;

	usedLocations.lastNode = newNode;

	if (usedLocations.firstNode == nullptr) usedLocations.firstNode = newNode;
}

void deleteNode(Node* currentNode, Locations& usedLocations)
{
	for (int i = 0; i < NODE_ARRAY_SIZE; i++) {
		deleteBlock(&(currentNode->blocks[i]), usedLocations);
	}

	if (currentNode == usedLocations.firstNode) usedLocations.firstNode = currentNode->next;
	else currentNode->prev->next = currentNode->next;

	if (currentNode == usedLocations.lastNode) usedLocations.lastNode = currentNode->prev;
	else currentNode->next->prev = currentNode->prev;

	delete currentNode;
}

void deleteAllNodes(Locations& usedLocations)
{
	Node* currentNode = usedLocations.firstNode;

	while (currentNode != nullptr) {
		deleteNode(currentNode, usedLocations);
		currentNode = usedLocations.firstNode;
	}
}

bool isNodeEmpty(Node* currentNode)
{
	if (currentNode->takenCounter == 0) return true;
	return false;
}
//----------------------------------------------------------------------------------
void beginNewBlock(Locations& usedLocations)
{
	if (usedLocations.firstNode == nullptr) createNode(usedLocations);

	if (usedLocations.lastNode->takenCounter == NODE_ARRAY_SIZE) createNode(usedLocations);

	usedLocations.lastUsedBlock = &(usedLocations.lastNode->blocks[usedLocations.lastNode->takenCounter]);
	usedLocations.lastUsedSelector = nullptr;
	usedLocations.lastUsedAttribute = nullptr;
}

void closeBlock(Locations& usedLocations)
{
	if (!hasAttributes(usedLocations.lastUsedBlock)) deleteSelectorList(usedLocations.lastUsedBlock, usedLocations);

	if (isBlockEmpty(usedLocations.lastUsedBlock)) {
		deleteNode(usedLocations.lastNode, usedLocations);
		return;
	}

	usedLocations.lastNode->takenCounter += 1;
}

bool hasSelectors(Block* currentBlock)
{
	if (currentBlock->firstSelector == nullptr) return false;
	return true;
}

bool hasAttributes(Block* currentBlock)
{
	if (currentBlock->firstAttribute == nullptr) return false;
	return true;
}

bool isBlockEmpty(Block* currentBlock)
{
	if (hasAttributes(currentBlock) || hasSelectors(currentBlock)) return false;
	return true;
}

int countTakenBlocks(Locations& usedLocations)
{
	int result = 0;

	Node* currentNode = usedLocations.firstNode;

	while (currentNode != nullptr) {
		result += currentNode->takenCounter;
		currentNode = currentNode->next;
	}

	return result;
}

void deleteBlock(Block* currentBlock, Locations& usedLocations)
{
	if (currentBlock == usedLocations.lastUsedBlock) usedLocations.lastUsedBlock = nullptr;
	deleteSelectorList(currentBlock, usedLocations);
	deleteAttributeList(currentBlock, usedLocations);
}

bool deleteBlockNr(int nr, Locations& usedLocations)
{
	Node* currentNode = findNodeWithBlockNr(nr, usedLocations);
	Block* currentBLock = findBlockNr(nr, usedLocations);

	if (currentBLock == nullptr) return false;

	deleteBlock(currentBLock, usedLocations);
	currentNode->takenCounter -= 1;
	if (isNodeEmpty(currentNode)) deleteNode(currentNode, usedLocations);
	else shiftBlocks(currentNode);
	return true;
}

Node* findNodeWithBlockNr(int nr, Locations& usedLocations)
{
	if (nr > countTakenBlocks(usedLocations)) return nullptr;

	Node* currentNode = usedLocations.firstNode;

	while (currentNode != nullptr) {
		if (nr <= currentNode->takenCounter) return currentNode;
		nr -= currentNode->takenCounter;
		currentNode = currentNode->next;
	}

	return nullptr;
}

Block* findBlockNr(int nr, Locations& usedLocations)
{
	if (nr > countTakenBlocks(usedLocations)) return nullptr;

	Node* currentNode = usedLocations.firstNode;

	while (currentNode != nullptr) {
		if (nr <= currentNode->takenCounter) return &(currentNode->blocks[nr - 1]);
		nr -= currentNode->takenCounter;
		currentNode = currentNode->next;
	}

	return nullptr;
}

void shiftBlocks(Node* currentNode)
{
	for (int i = 0; i < NODE_ARRAY_SIZE - 1; i++) {
		if (isBlockEmpty(&(currentNode->blocks[i]))) {
			currentNode->blocks[i].firstAttribute = currentNode->blocks[i + 1].firstAttribute;
			currentNode->blocks[i].firstSelector = currentNode->blocks[i + 1].firstSelector;

			currentNode->blocks[i + 1].firstAttribute = nullptr;
			currentNode->blocks[i + 1].firstSelector = nullptr;
		}
	}
}
//----------------------------------------------------------------------------------
void createSelector(SimpleString name, Locations& usedLocations)
{
	deleteSelectorInGivenBlock(usedLocations.lastUsedBlock, name, usedLocations);

	Selector* newSelector = new Selector;
	newSelector->name = name;
	newSelector->next = nullptr;

	if (!hasSelectors(usedLocations.lastUsedBlock)) usedLocations.lastUsedBlock->firstSelector = newSelector;
	if (usedLocations.lastUsedSelector != nullptr) usedLocations.lastUsedSelector->next = newSelector;

	usedLocations.lastUsedSelector = newSelector;
}

bool deleteSelectorInGivenBlock(Block* currentBlock, const SimpleString& name, Locations& usedLocations)
{
	if (currentBlock == nullptr) return false;

	Selector* currentSelector = currentBlock->firstSelector;
	Selector* precedingSelector = nullptr;

	while (currentSelector != nullptr) {
		if (currentSelector->name == name) {
			if (precedingSelector == nullptr) currentBlock->firstSelector = currentSelector->next;
			else precedingSelector->next = currentSelector->next;

			if (usedLocations.lastUsedSelector == currentSelector) usedLocations.lastUsedSelector = precedingSelector;

			delete currentSelector;
			return true;
		}
		precedingSelector = currentSelector;
		currentSelector = currentSelector->next;
	}
	return false;
}

void deleteSelectorList(Block* currentBlock, Locations& usedLocations)
{
	if (currentBlock == usedLocations.lastUsedBlock) usedLocations.lastUsedSelector = nullptr; 

	Selector* currentSelector = currentBlock->firstSelector;

	while (currentSelector != nullptr) {
		currentBlock->firstSelector = currentSelector->next;
		delete currentSelector;
		currentSelector = currentBlock->firstSelector;
	}
}
//----------------------------------------------------------------------------------
void createAttributeName(SimpleString name, Locations& usedLocations)
{
	deleteAttrInGivenBlock(usedLocations.lastUsedBlock, name, usedLocations);

	Attribute* newAttribute = new Attribute;
	newAttribute->name = name;
	newAttribute->next = nullptr;

	if (!hasAttributes(usedLocations.lastUsedBlock)) usedLocations.lastUsedBlock->firstAttribute = newAttribute;
	if (usedLocations.lastUsedAttribute != nullptr) usedLocations.lastUsedAttribute->next = newAttribute;

	usedLocations.lastUsedAttribute = newAttribute;
}

void createAttributeValue(SimpleString name, Locations& usedLocations)
{
	usedLocations.lastUsedAttribute->value = name;
}

bool deleteAttrInGivenBlock(Block* currentBlock, const SimpleString& name, Locations& usedLocations)
{
	if (currentBlock == nullptr) return false;
	
	Attribute* currentAttribute = currentBlock->firstAttribute;
	Attribute* precedingAttribute = nullptr;

	while (currentAttribute != nullptr) {
		if (currentAttribute->name == name) {
			if (precedingAttribute == nullptr) currentBlock->firstAttribute = currentAttribute->next;
			else precedingAttribute->next = currentAttribute->next;
			
			if (usedLocations.lastUsedAttribute == currentAttribute) usedLocations.lastUsedAttribute = precedingAttribute;

			delete currentAttribute;
			return true;
		}
		precedingAttribute = currentAttribute;
		currentAttribute = currentAttribute->next;
	}
	return false;
}

void deleteAttributeList(Block* currentBlock, Locations& usedLocations) {
	if (currentBlock == usedLocations.lastUsedBlock) usedLocations.lastUsedAttribute = nullptr;

	Attribute* currentAttribute = currentBlock->firstAttribute;

	while (currentAttribute != nullptr) {
		currentBlock->firstAttribute = currentAttribute->next;
		delete currentAttribute;
		currentAttribute = currentBlock->firstAttribute;
	}
}

bool deleteAttrInBlockNr(int nr, const SimpleString& name, Locations& usedLocations)
{
	Block* currentBlock = findBlockNr(nr, usedLocations);

	if (currentBlock == nullptr) return false;

	if (!deleteAttrInGivenBlock(currentBlock, name, usedLocations)) return false;

	if (!hasAttributes(currentBlock)) deleteBlockNr(nr, usedLocations);

	return true;
}
//----------------------------------------------------------------------------------
int countAttrInBlockNr(int nr, Locations& usedLocations) {
	Block* currentBlock = findBlockNr(nr, usedLocations);

	if (currentBlock == nullptr) return 0;

	return countAttrInGivenBlock(currentBlock);
}

int countAttrInGivenBlock(Block* currentBlock) {
	int counter = 0;
	Attribute* currentAttribute = currentBlock->firstAttribute;

	while (currentAttribute != nullptr) {
		counter++;
		currentAttribute = currentAttribute->next;
	}

	return counter;
}

int countSelectorsInBlockNr(int nr, Locations& usedLocations) {
	Block* currentBlock = findBlockNr(nr, usedLocations);

	if (currentBlock == nullptr) return 0;

	return countSelectorsInGivenBlock(currentBlock);
}

int countSelectorsInGivenBlock(Block* currentBlock) {
	int counter = 0;
	Selector* currentSelector = currentBlock->firstSelector;

	while (currentSelector != nullptr) {
		counter++;
		currentSelector = currentSelector->next;
	}

	return counter;
}
//----------------------------------------------------------------------------------
SimpleString selectorNrInBlockNr(int selectorNr, int blockNr, Locations& usedLocations) {
	Block* currentBlock = findBlockNr(blockNr, usedLocations);

	if (currentBlock == nullptr) return SimpleString();

	return selectorNrInGivenBlock(currentBlock, selectorNr);
}

SimpleString selectorNrInGivenBlock(Block* currentBlock, int selectorNr) {
	Selector* currentSelector = currentBlock->firstSelector;

	while (currentSelector != nullptr) {
		if (selectorNr == 1) return currentSelector->name;
		selectorNr--;
		currentSelector = currentSelector->next;
	}

	return SimpleString();
}

SimpleString attrValueInBlockNr(int nr, const SimpleString& name, Locations& usedLocations) {
	Block* currentBlock = findBlockNr(nr, usedLocations);

	if (currentBlock == nullptr) return SimpleString();

	return attrValueInGivenBlock(currentBlock, name);
}

SimpleString attrValueInGivenBlock(Block* currentBlock, const SimpleString& name) {
	Attribute* currentAttribute = currentBlock->firstAttribute;

	while (currentAttribute != nullptr) {
		if (currentAttribute->name == name) return currentAttribute->value;
		currentAttribute = currentAttribute->next;
	}

	return SimpleString();
}
//----------------------------------------------------------------------------------
bool containsAttributeOfName(Block* currentBlock, const SimpleString& name) {
	if (currentBlock == nullptr) return false;

	Attribute* currentAttribute = currentBlock->firstAttribute;

	while (currentAttribute != nullptr) {
		if (currentAttribute->name == name) return true;
		currentAttribute = currentAttribute->next;
	}

	return false;
}

int attributeOccurrences(const SimpleString& name, Locations& usedLocations) {
	Node* currentNode = usedLocations.lastNode;
	int counter = 0;

	while (currentNode != nullptr) {
		for (int i = 0; i < NODE_ARRAY_SIZE; i++) {
			if (containsAttributeOfName(&(currentNode->blocks[i]), name)) counter++;
		}

		currentNode = currentNode->prev;
	}

	return counter;
}

bool selectorApplies(Block* currentBlock, const SimpleString& name) {
	if (containsSelectorOfName(currentBlock, name) || !(hasSelectors(currentBlock))) return true;
	return false;
}

bool containsSelectorOfName(Block* currentBlock, const SimpleString& name) {
	if (currentBlock == nullptr) return false;

	if (!hasSelectors(currentBlock)) return false;

	Selector* currentSelector = currentBlock->firstSelector;

	while (currentSelector != nullptr) {
		if (currentSelector->name == name) return true;
		currentSelector = currentSelector->next;
	}

	return false;
}

int selectorOccurrences(const SimpleString& name, Locations& usedLocations) {
	Node* currentNode = usedLocations.firstNode;
	int counter = 0;

	while (currentNode != nullptr) {
		for (int i = 0; i < currentNode->takenCounter; i++) {
			if (containsSelectorOfName(&(currentNode->blocks[i]), name)) counter++;
		}
		currentNode = currentNode->next;
	}

	return counter;
}

SimpleString attrValueForSelector(const SimpleString& attrName, const SimpleString& selectorName, Locations& usedLocations) {
	Node* currentNode = usedLocations.lastNode;

	while (currentNode != nullptr) {
		for (int i = currentNode->takenCounter - 1; i >= 0; i--) {
			if (selectorApplies(&(currentNode->blocks[i]), selectorName)) {
				SimpleString foundValue = attrValueInGivenBlock(&(currentNode->blocks[i]), attrName);

				if (foundValue.isEmpty()) continue;

				return foundValue;
			}
		}

		currentNode = currentNode->prev;
	}

	return SimpleString();
}

