#include <iostream>
#include "simplestring.h"
#include "structures.h"
#include "reading.h"

int main() {
	Locations usedLocations = { nullptr, nullptr, nullptr, nullptr, nullptr };
	Reading usedReading = {NULL, SimpleString(), waitingForFirstSelector};

	while (std::cin.get(usedReading.character)) {
		parse(usedReading, usedLocations);
	}

	if (usedReading.state == commandMode && usedReading.word.isEmpty() == false) {
		usedReading.character = NEWLINE;		// na wypadek gdyby na koncu pliku znajdowala sie komenda,
		parse(usedReading, usedLocations);		// po ktorej nie zostal wcisniety enter
	}

	deleteAllNodes(usedLocations);

	return 0;
}