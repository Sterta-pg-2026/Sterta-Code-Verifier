#include "reading.h"

void parse(Reading& usedReading, Locations& usedLocations)
{
	switch (usedReading.state) {
	case waitingForFirstSelector: {
		waitForFirstSelector(usedReading, usedLocations);
		break;	}
	case waitingForNewSelector: {
		waitForNewSelector(usedReading);
		break;	}
	case readingSelector: {
		readSelector(usedReading, usedLocations);
		break;	}
	case waitingForAttrName: {
		waitForAttrName(usedReading, usedLocations);
		break;	}
	case readingAttrName: {
		readAttrName(usedReading, usedLocations);
		break;	}
	case waitingForAttrValue: {
		waitForAttrValue(usedReading);
		break;	}
	case readingAttrValue: {
		readAttrValue(usedReading, usedLocations);
		break;	}
	case commandMode: {
		doCommands(usedReading, usedLocations);
		break;	}
	}
}

void waitForFirstSelector(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character <= SPACE) return;

	beginNewBlock(usedLocations);

	if (usedReading.character == '{') {
		usedReading.state = waitingForAttrName;
		return;
	}

	usedReading.state = readingSelector;
	usedReading.word += usedReading.character;
}

void waitForNewSelector(Reading& usedReading)
{
	if (usedReading.character <= SPACE) return;

	usedReading.word += usedReading.character;
	usedReading.state = readingSelector;
}

void readSelector(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character == NEWLINE) {
		if (usedReading.word == "????") {
			usedReading.word.clear();
			usedReading.state = commandMode;
		}
		return;
	}

	if (usedReading.character < SPACE) return;

	if (usedReading.character == ',' || usedReading.character == '{') {
		if (usedReading.character == ',') usedReading.state = waitingForNewSelector;
		if (usedReading.character == '{') usedReading.state = waitingForAttrName;

		usedReading.word.removeTrailingSpaces();
		createSelector(usedReading.word, usedLocations);
		usedReading.word.clear();
		return;
	}

	usedReading.word += usedReading.character;
}

void waitForAttrName(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character <= SPACE) return;

	if (usedReading.character == '}') {
		usedReading.state = waitingForFirstSelector;
		closeBlock(usedLocations);
		usedReading.word.clear();
		return;
	}

	usedReading.word += usedReading.character;
	usedReading.state = readingAttrName;
}

void readAttrName(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character < SPACE) return;

	if (usedReading.character == ':') {
		usedReading.state = waitingForAttrValue;
		usedReading.word.removeTrailingSpaces();
		createAttributeName(usedReading.word, usedLocations);
		usedReading.word.clear();
		return;
	}

	usedReading.word += usedReading.character;
}

void waitForAttrValue(Reading& usedReading)
{
	if (usedReading.character <= SPACE) return;

	usedReading.state = readingAttrValue;
	usedReading.word += usedReading.character;
}

void readAttrValue(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character == ';' || usedReading.character == '}') {
		usedReading.word.removeTrailingSpaces();
		createAttributeValue(usedReading.word, usedLocations);
		usedReading.word.clear();

		if (usedReading.character == ';') usedReading.state = waitingForAttrName;
		if (usedReading.character == '}') {
			closeBlock(usedLocations);
			usedReading.state = waitingForFirstSelector;
		}

		return;
	}

	usedReading.word += usedReading.character;
}

void doCommands(Reading& usedReading, Locations& usedLocations)
{
	if (usedReading.character == NEWLINE) {
		if (usedReading.word == "****") {
			usedReading.state = waitingForFirstSelector;
			usedReading.word.clear();
			return;
		}
		parseCommand(usedReading.word, usedLocations);
		usedReading.word.clear();
		return;
	}

	if (usedReading.character < SPACE) return;

	usedReading.word += usedReading.character;
}

void parseCommand(SimpleString command, Locations& usedLocations)
{
	if (command == "?") {
		std::cout << "? == " << countTakenBlocks(usedLocations) << std::endl;
		return;
	}

	if (command.isEmpty()) return;

	SimpleString segment1, segment2, segment3;
	int i = 0;

	while (command[i] != ',') {
		if (command[i] == '\0') return;
		segment1 += command[i];
		i++;
	}
	i++; // omijamy przecinek
	while (command[i] != ',') {
		if (command[i] == '\0') return;
		segment2 += command[i];
		i++;
	}
	i++;
	while (command[i] != '\0') {
		segment3 += command[i];
		i++;
	}

	chooseCommand(segment1, segment2, segment3, usedLocations);
}

void chooseCommand(const SimpleString& s1, const SimpleString& s2, const SimpleString& s3, Locations& usedLocations)
{
	if (s2 == "S") selectorCommands(s1, s3, usedLocations);
	if (s2 == "A") attributeCommands(s1, s3, usedLocations);
	if (s2 == "E") valueCommands(s1, s3, usedLocations);
	if (s2 == "D") deletionCommands(s1, s3, usedLocations);
}

void selectorCommands(SimpleString arg1, SimpleString arg2, Locations& usedLocations)
{
	if (arg2 == "?") {
		if (arg1.isNumber()) {
			if (findBlockNr(arg1.toNumber(), usedLocations) == nullptr) return;
			int result = countSelectorsInBlockNr(arg1.toNumber(), usedLocations);
			std::cout << arg1 << ",S,? == " << result << std::endl;
		}
		else {
			int result = selectorOccurrences(arg1, usedLocations);
			std::cout << arg1 << ",S,? == " << result << std::endl;
		}
	}
	else {
		if (!arg1.isNumber() || !arg2.isNumber()) return;
		SimpleString result = selectorNrInBlockNr(arg2.toNumber(), arg1.toNumber(), usedLocations);
		if (result.isEmpty()) return;
		std::cout << arg1 << ",S," << arg2 << " == " << result << std::endl;
	}
}

void attributeCommands(SimpleString arg1, const SimpleString& arg2, Locations& usedLocations)
{
	if (arg2 == "?") {
		if (arg1.isNumber()) {
			int result = countAttrInBlockNr(arg1.toNumber(), usedLocations);
			if (result == 0) return;
			std::cout << arg1 << ",A,? == " << result << std::endl;
		}
		else {
			if (arg1 == "") return;
			int result = attributeOccurrences(arg1, usedLocations);
			std::cout << arg1 << ",A,? == " << result << std::endl;
		}
	}
	else {
		if (!arg1.isNumber()) return;
		SimpleString result = attrValueInBlockNr(arg1.toNumber(), arg2, usedLocations);
		if (result.isEmpty()) return;
		std::cout << arg1 << ",A," << arg2 << " == " << result << std::endl;
	}
}

void valueCommands(const SimpleString& arg1, const SimpleString& arg2, Locations& usedLocations)
{
	SimpleString result = attrValueForSelector(arg2, arg1, usedLocations);
	if (result.isEmpty()) return;
	std::cout << arg1 << ",E," << arg2 << " == " << result << std::endl;
}

void deletionCommands(SimpleString arg1, const SimpleString& arg2, Locations& usedLocations)
{
	if (!arg1.isNumber()) return;
	if (arg2 == "*") {
		if (deleteBlockNr(arg1.toNumber(), usedLocations)) std::cout << arg1 << ",D,* == deleted" << std::endl;
	}
	else {
		if (deleteAttrInBlockNr(arg1.toNumber(), arg2, usedLocations)) std::cout << arg1 << ",D," << arg2 << " == deleted" << std::endl;
	}
}
