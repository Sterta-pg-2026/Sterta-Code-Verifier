#include "simplestring.h"

SimpleString::SimpleString()
	: size(1), maxSize(1), characters(new char[1])
{
	characters[0] = '\0';
}

SimpleString::SimpleString(const char word[])
{
	for (size = 1; word[size - 1] != '\0'; size++);
	for (maxSize = 1; maxSize < size; maxSize *= 2);

	characters = new char[maxSize];
	for (int i = 0; i < size; i++) characters[i] = word[i];
}

SimpleString::SimpleString(const SimpleString& word)
	: size(word.size), maxSize(word.maxSize), characters(new char[word.maxSize])
{
	for (int i = 0; i < size; i++) characters[i] = word.characters[i];
}

SimpleString::SimpleString(SimpleString&& word)
	: size(word.size), maxSize(word.maxSize), characters(word.characters)
{
	word.size = word.maxSize = 0;
	word.characters = nullptr;
}

SimpleString::~SimpleString()
{
	delete[] characters;
}

SimpleString& SimpleString::operator=(const SimpleString& word)
{
	if (this == &word) return *this;

	delete[] characters;

	SimpleString temp = word;
	size = temp.size;
	maxSize = temp.maxSize;
	characters = temp.characters;

	temp.size = temp.maxSize = 0;
	temp.characters = nullptr;

	return *this;
}

SimpleString& SimpleString::operator=(SimpleString&& word)
{
	if (this == &word) return *this;
	
	delete[] characters;

	size = word.size;
	maxSize = word.maxSize;
	characters = word.characters;

	word.size = word.maxSize = 0;
	word.characters = nullptr;

	return *this;
}

SimpleString& SimpleString::operator+=(const char ch)
{
	if (size == maxSize) {
		maxSize *= 2;
		char* newCharacters = new char[maxSize];
		for (int i = 0; i < size; i++) {
			newCharacters[i] = characters[i];
		}
		newCharacters[size - 1] = ch;
		newCharacters[size] = '\0';

		delete[] characters;
		characters = newCharacters;
	}
	else {
		characters[size - 1] = ch;
		characters[size] = '\0';
	}
	size++;

	return *this;
}

char& SimpleString::operator[](int i)
{
	return characters[i];
}

const char& SimpleString::operator[](int i) const
{
	return characters[i];
}

bool SimpleString::isEmpty() const
{
	if (size == 1) return true;
	return false;
}

bool SimpleString::isNumber() const
{
	for (int i = 0; i < size - 1; i++) {
		if (characters[i] > '9' || characters[i] < '0') return false;
	}
	return true;
}

int SimpleString::toNumber()
{
	if (!(this->isNumber())) return 0;

	int result = 0;

	for (int i = 0; i < size - 1; i++) {
		result *= 10;

		result += (characters[i] - '0');
	}

	return result;
}

void SimpleString::removeTrailingSpaces()
{
	int newSize = size;
	while (newSize > 0 && characters[newSize - 2] == ' ') newSize--;
	if (size == newSize) return;

	int newMaxSize = 1;
	while (newMaxSize < newSize) newMaxSize *= 2;

	if (newMaxSize != maxSize) {
		char* newCharacters = new char[newMaxSize];
		for (int i = 0; i < newSize - 1; i++) newCharacters[i] = characters[i];
		delete[] characters;
		characters = newCharacters;
	}

	characters[newSize - 1] = '\0';
	size = newSize;
	maxSize = newMaxSize;
}

void SimpleString::clear()
{
	delete[] characters;
	characters = new char[1];
	characters[0] = '\0';
	size = maxSize = 1;
}

bool operator==(const SimpleString& left, const SimpleString& right)
{
	if (left.size != right.size) return false;

	for (int i = 0; i < left.size; i++) {
		if (left.characters[i] != right.characters[i]) return false;
	}

	return true;
}

bool operator==(const SimpleString& left, const char right[])
{
	for (int i = 0; i < left.size; i++) {
		if (left.characters[i] != right[i]) return false;
	}

	return true;
}

std::ostream& operator<<(std::ostream& os, const SimpleString& word)
{
	os << word.characters;

	return os;
}
