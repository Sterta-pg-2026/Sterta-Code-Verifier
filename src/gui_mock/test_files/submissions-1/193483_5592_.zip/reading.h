#pragma once

#include "simplestring.h"
#include "structures.h"

#define SPACE ' '
#define NEWLINE '\n'

enum readingState {
	waitingForFirstSelector,
	waitingForNewSelector,
	readingSelector,
	waitingForAttrName,
	readingAttrName,
	waitingForAttrValue,
	readingAttrValue,
	commandMode
};

struct Reading {
	char character;
	SimpleString word;
	readingState state;
};

void parse(Reading& usedReading, Locations& usedLocations);

void waitForFirstSelector(Reading& usedReading, Locations& usedLocations);
void waitForNewSelector(Reading& usedReading);
void readSelector(Reading& usedReading, Locations& usedLocations);
void waitForAttrName(Reading& usedReading, Locations& usedLocations);
void readAttrName(Reading& usedReading, Locations& usedLocations);
void waitForAttrValue(Reading& usedReading);
void readAttrValue(Reading& usedReading, Locations& usedLocations);

void doCommands(Reading& usedReading, Locations& usedLocations);
void parseCommand(SimpleString command, Locations& usedLocations);
void chooseCommand(const SimpleString& s1, const SimpleString& s2, const SimpleString& s3, Locations& usedLocations);
void selectorCommands(SimpleString arg1, SimpleString arg2, Locations& usedLocations);
void attributeCommands(SimpleString arg1, const SimpleString& arg2, Locations& usedLocations);
void valueCommands(const SimpleString& arg1, const SimpleString& arg2, Locations& usedLocations);
void deletionCommands(SimpleString arg1, const SimpleString& arg2, Locations& usedLocations);