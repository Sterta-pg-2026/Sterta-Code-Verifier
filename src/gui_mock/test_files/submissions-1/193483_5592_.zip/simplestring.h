#pragma once

#include <iostream>

class SimpleString {
private:
	int size{}, maxSize{};
	char* characters;

public:
	SimpleString();
	SimpleString(const char word[]);
	SimpleString(const SimpleString& word);
	SimpleString(SimpleString&& word);
	~SimpleString();

	SimpleString& operator=(const SimpleString& word);
	SimpleString& operator=(SimpleString&& word);

	SimpleString& operator+=(const char ch);

	friend bool operator==(const SimpleString& left, const SimpleString& right);
	friend bool operator==(const SimpleString& left, const char right[]);

	char& operator[](int i);
	const char& operator[](int i) const;

	bool isEmpty() const;

	bool isNumber() const;
	int toNumber();

	void removeTrailingSpaces();
	void clear();

	friend std::ostream& operator<<(std::ostream& os, const SimpleString& word);
};