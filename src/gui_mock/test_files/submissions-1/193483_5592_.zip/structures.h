#pragma once

#include "simplestring.h"

#define NODE_ARRAY_SIZE 29

struct Selector {
	SimpleString name;
	Selector* next;
};

struct Attribute {
	SimpleString name;
	SimpleString value;
	Attribute* next;
};

struct Block {
	Selector* firstSelector;
	Attribute* firstAttribute;
};

struct Node {
	int takenCounter;
	Block blocks[NODE_ARRAY_SIZE];
	Node* prev;
	Node* next;
};

struct Locations {
	Node* firstNode;
	Node* lastNode;
	Block* lastUsedBlock;
	Selector* lastUsedSelector;
	Attribute* lastUsedAttribute;
};

void createNode(Locations& usedLocations);
void deleteNode(Node* currentNode, Locations& usedLocations);
void deleteAllNodes(Locations& usedLocations);
bool isNodeEmpty(Node* currentNode);
//----------------------------------------------------------------------------------
void beginNewBlock(Locations& usedLocations);
void closeBlock(Locations& usedLocations);

bool hasSelectors(Block* currentBlock);
bool hasAttributes(Block* currentBlock);
bool isBlockEmpty(Block* currentBlock);

int countTakenBlocks(Locations& usedLocations);

void deleteBlock(Block* currentBlock, Locations& usedLocations);
bool deleteBlockNr(int nr, Locations& usedLocations);
Node* findNodeWithBlockNr(int nr, Locations& usedLocations);
Block* findBlockNr(int nr, Locations& usedLocations);
void shiftBlocks(Node* currentNode);
//----------------------------------------------------------------------------------
void createSelector(SimpleString name, Locations& usedLocations);
bool deleteSelectorInGivenBlock(Block* currentBlock, const SimpleString& name, Locations& usedLocations);
void deleteSelectorList(Block* currentBlock, Locations& usedLocations);
//----------------------------------------------------------------------------------
void createAttributeName(SimpleString name, Locations& usedLocations);
void createAttributeValue(SimpleString name, Locations& usedLocations);
bool deleteAttrInGivenBlock(Block* currentBlock, const SimpleString& name, Locations& usedLocations);		// bool na potrzeby komend (wypisywanie == deleted tylko gdy trzeba)
void deleteAttributeList(Block* currentBlock, Locations& usedLocations);
bool deleteAttrInBlockNr(int nr, const SimpleString& name, Locations& usedLocations);
//----------------------------------------------------------------------------------
int countAttrInBlockNr(int nr, Locations& usedLocations);
int countAttrInGivenBlock(Block* currentBlock);

int countSelectorsInBlockNr(int nr, Locations& usedLocations);
int countSelectorsInGivenBlock(Block* currentBlock);
//----------------------------------------------------------------------------------
SimpleString selectorNrInBlockNr(int selectorNr, int blockNr, Locations& usedLocations);
SimpleString selectorNrInGivenBlock(Block* currentBlock, int selectorNr);

SimpleString attrValueInBlockNr(int nr, const SimpleString& name, Locations& usedLocations);
SimpleString attrValueInGivenBlock(Block* currentBlock, const SimpleString& name);
//----------------------------------------------------------------------------------
bool containsAttributeOfName(Block* currentBlock, const SimpleString& name);
int attributeOccurrences(const SimpleString& name, Locations& usedLocations);

bool selectorApplies(Block* currentBlock, const SimpleString& name);
bool containsSelectorOfName(Block* currentBlock, const SimpleString& name);
int selectorOccurrences(const SimpleString& name, Locations& usedLocations);

SimpleString attrValueForSelector(const SimpleString& attrName, const SimpleString& selectorName, Locations& usedLocations);
