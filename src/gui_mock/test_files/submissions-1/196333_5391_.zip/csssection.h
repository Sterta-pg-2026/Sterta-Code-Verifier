#pragma once
#include "list.h"
#include "string.h"

struct Attribute
{
	String name;
	String value;
};

struct CssSection
{
	List<String> selectors;
	List<Attribute> attributes;
};
