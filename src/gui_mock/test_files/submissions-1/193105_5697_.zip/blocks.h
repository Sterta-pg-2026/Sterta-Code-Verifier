#pragma once
#include "section.h"

const int ARR_SIZE = 8;

struct BlocksIndex {
    std::size_t index;
    std::size_t node_number;
};

class Blocks {
public:
    Blocks();

    Section& operator[](std::size_t index);
    const Section& operator[](std::size_t index) const;

    // marks the indexed place (in counter) as occupied
    void occupy(const int index);

    // returns number of occupied sections
    int getOccupiedSections() const;
    // converts "normal" index to actual (real) index in the counter
    int getOccupiedIndex(const int index) const;
    // returns number of sections that contain given selector
    int getNumOfSelectors(const String &sel) const;
    // calculates the total number of occurences of att_name in all sections of the node
    int sumOfAttributes(const String &att_name) const;
    // get index of the last selector which has attribute given
    int getLastSelectorWithAttribute(const String &sel, const String &att) const;
    // removes entire section
    void removeSection(const int index);
    // return index of the last occupied space
    int getLastOccupied() const;
private:
    Section _arr[ARR_SIZE];
    bool _counter[ARR_SIZE];
    int _size;
};

std::ostream& operator<<(std::ostream& ostr, const Blocks &blocks);
bool operator==(const Blocks& left, const Blocks& right);
