#include <iostream>
#include "string.h"
#include "dllist.h"
#include "parser.h"

int main() {
    int c;
    Parser parser;

    while (true) {
        c = getchar();

        if (c < ' ' && c != EOF && c != '\n' && c != '\t')
            continue;

        if (!parser.parse(c))
            break;
    }

    return 0;
}

