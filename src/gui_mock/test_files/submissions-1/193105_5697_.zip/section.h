#pragma once
#include "dllist.h"
#include "string.h"

struct Attribute {
    String name;
    String value;
    Attribute(const String& namee) : name(namee), value(nullptr) {};
    Attribute(String&& namee, String&& valuee) : name(std::move(namee)), value(std::move(valuee)) {};
};

class Section {
public:
    void addSelector(String&& sel);
    void addAttribute(Attribute&& att);
    void print() const;
    void removeEverything();
    bool removeAttribute(String&& att);

    std::size_t getNumOfSelectors() const;
    std::size_t getNumOfAttributes() const;
    // could be optimized, I think (to references?)
    const String& getSelector(std::size_t index) const;
    int getSelector(const String& str) const;
    Attribute getAttribute(std::size_t index) const;
    int getAttributeNameIndex(const String& str) const;
private:
    DLList<String> _selectors;
    DLList<Attribute> _attributes;
};

std::ostream& operator<<(std::ostream& ostr, const Section& section);
std::ostream& operator<<(std::ostream& ostr, const Attribute& att);
bool operator==(const Attribute& left, const Attribute& right);
bool operator==(const String& left, const Attribute& right);

