#include "blocks.h"

Blocks::Blocks() {
    _size = 0;
    for (int i = 0; i < ARR_SIZE; ++i)
        _counter[i] = false;
}

void Blocks::occupy(const int index) {
    if (_counter[index]) {
        throw std::invalid_argument("Tried to occupy already occupied space.");
    }
    _counter[index] = true;
    ++_size;
}

int Blocks::getOccupiedSections() const {
    return _size;
}

int Blocks::getOccupiedIndex(const int index) const {
    if (index > ARR_SIZE)
        throw std::invalid_argument("Index is bigger than the counter itself.");

    int j = 0;
    for (int i = 0; i < ARR_SIZE; ++i) {
        if (_counter[i]) {
            ++j;
            if (j == index)
                return i;
        }
    }
    return -1;
}

int Blocks::getNumOfSelectors(const String &sel) const {
    int sum = 0;
    for (int i = 0; i < ARR_SIZE; ++i) {
        if (_counter[i] && _arr[i].getSelector(sel) >= 0)
            ++sum;
    }
    return sum;
}

int Blocks::sumOfAttributes(const String &att_name) const {
    int sum = 0;
    for (int i = 0; i < ARR_SIZE; ++i) {
        if (_counter[i] && _arr[i].getAttributeNameIndex(att_name) >= 0)
            ++sum;
    }
    return sum;
}

int Blocks::getLastSelectorWithAttribute(const String &sel, const String &att) const {
    int index;
    for (int i = ARR_SIZE - 1; i >= 0; --i) {
        if (_counter[i]) {
            index = _arr[i].getSelector(sel);
            if (index >= 0) {
                if (_arr[i].getAttributeNameIndex(att) >= 0)
                    return i;
            }
        }
    }
    return -1;
}

void Blocks::removeSection(const int index) {
    if (!_counter[index])
        throw std::invalid_argument("Tried to remove empty section.");
    _counter[index] = false;
    _arr[index].removeEverything();
    --_size;
}

int Blocks::getLastOccupied() const {
    for (int i = ARR_SIZE - 1; i >= 0; --i) {
        if (_counter[i])
            return i;
    }
    return -1;
}

Section& Blocks::operator[] (std::size_t index) {
    if (index >= ARR_SIZE)
        throw std::out_of_range("Tried to access Blocks outside of range");
    return _arr[index];
}

const Section& Blocks::operator[](std::size_t index) const {
    if (index >= ARR_SIZE)
        throw std::out_of_range("Tried to access Blocks outside of range");
    return _arr[index];
}

std::ostream& operator<<(std::ostream& ostr, const Blocks &blocks) {
    for (int i = 0; i < ARR_SIZE; ++i)
        ostr << blocks[i] << std::endl;
    return ostr;
}

// this should never be called
// it exists because we compare data in list template
bool operator==(const Blocks& left, const Blocks& right) {
    std::cout << "comparing blocks" << std::endl;
    if (left.getOccupiedSections() != right.getOccupiedSections())
        return false;
    return false;
}
