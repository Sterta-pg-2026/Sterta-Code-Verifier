#include "section.h"

void Section::addSelector(String&& sel) {
    _selectors.push_back(std::move(sel));
}

void Section::addAttribute(Attribute&& att) {
    for (auto it = _attributes.begin(); it != _attributes.end(); ++it) {
        if ( (*it).name == att.name ) {
            (*it).value = std::move(att.value);
            return;
        }
    }
    _attributes.push_back(std::move(att));
}

void Section::removeEverything() {
    _attributes.free();
    _selectors.free();
}

bool Section::removeAttribute(String&& att) {
    Attribute attribute(std::move(att));
    return _attributes.remove_node(attribute);
}

std::size_t Section::getNumOfSelectors() const {
    return _selectors.size();
}

std::size_t Section::getNumOfAttributes() const {
    return _attributes.size();
}

const String& Section::getSelector(std::size_t index) const {
    return _selectors[index];
}

int Section::getSelector(const String &str) const {
    return _selectors.find(str);
}

Attribute Section::getAttribute(std::size_t index) const {
    return _attributes[index - 1];
}

int Section::getAttributeNameIndex(const String& str) const {
    return _attributes.find(str);
}


void Section::print() const {
    std::cout << std::endl << "Selectors (" << _selectors.size() << ")" << std::endl;
    _selectors.print();
    std::cout << std::endl << "Attributes (" << _attributes.size() << ")" << std::endl;
    _attributes.print();
    std::cout << std::endl;
}

std::ostream& operator<<(std::ostream& ostr, const Section &section) {
    ostr << "Start of the Block:" << std::endl;
    section.print();
    ostr << "End of the Block" << std::endl;
    return ostr;
}

std::ostream& operator<<(std::ostream& ostr, const Attribute &att) {
    ostr << att.name << ": " << att.value << " ||";
    return ostr;
}

bool operator==(const Attribute& left, const Attribute& right) {
    return left.name == right.name;
}
bool operator==(const String& left, const Attribute& right) {
    return left == right.name;
}
