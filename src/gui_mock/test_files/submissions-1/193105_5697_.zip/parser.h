#pragma once
#include "blocks.h"

const int COMMAND_PARTS = 3;

enum inType {SELECTORS, ATTRIBUTES, ATT_VALUES, COMMANDS};

class Parser {
public:
    Parser();
    ~Parser();

    bool parse(int ch);
private:
    // _mode stores what we are currenty reading
    inType _mode;
    DLList<Blocks> _list;
    // _buffer2 is for attribute values and _buffer for everything else
    String _buffer, _buffer2;
    // _curr_block stores actual index of current section; it can be temporarily -1
    int _curr_block;
    // commands consist of 3 buffers (separated by commas)
    String *_command_buffers;
    // _curr_buff remembers which command buffer we are currently reading
    std::size_t _curr_buff;
    // _size stores total number of blocks
    std::size_t _size;
    // _indexes is a helper structure which helps access actual section
    BlocksIndex _indexes;

    // helper methods
    void _updateCurrBlock();
    BlocksIndex _getSection(std::size_t index) const;
    void _printNumOf(inType type);
    void _printCommand() const;
    int _getInt(const String &str);

    void _addSelector(const char c);
    void _addAttribute();
    void _switchToCommandMode();
    void _switchToSelectorMode();
    void _saveAttributeName();
    void _saveCommandBuffer();
    void _command_i_S_j();
    void _command_z_S_quesMark();
    void _command_i_A_n();
    void _command_n_A_quesMark();
    void _command_z_E_n();
    void _command_i_D_star();
    void _command_i_D_n();
    void _executeCommands();
};
