#include "parser.h"

Parser::Parser() {
    _mode = SELECTORS;
    _list.push_back(Blocks());
    _buffer = "";
    _buffer2 = "";
    _curr_block = 0;
    _curr_buff = 0;
    _size = 0;
    _command_buffers = new String[COMMAND_PARTS];
    for (int i = 0; i < COMMAND_PARTS; ++i)
        _command_buffers[i] = "";
    _indexes = {0, 0};
}

Parser::~Parser() {
    delete[] _command_buffers;
}

bool Parser::parse(int ch) {
    char c = (char)ch;
    if (_mode != COMMANDS && c == EOF)
        return false;
    switch (_mode) {
        case SELECTORS:
            if (c == ',' || c == '{')
                _addSelector(c);
            else if (c == '?')
                _switchToCommandMode();
            else
                _buffer += c;
            break;
        case ATTRIBUTES:
            if (c == ':')
                _saveAttributeName();
            else if (c == '}')
                _switchToSelectorMode();
            else
                _buffer += c;
            break;
        case ATT_VALUES:
            if (c == ';' || c == '}') {
                _addAttribute();
                if (c == '}')
                    _switchToSelectorMode();
            }
            else
                _buffer += c;
            break;
        case COMMANDS: {
            if (c == '\n' || c == EOF) {
                if (_buffer == "?" && _curr_buff == 0)
                    std::cout << "? == " << _size << std::endl;
                else if (_curr_buff == 2 && _list.size() > 0) {
                    _command_buffers[_curr_buff] = _buffer;
                    // here commands are executed
                    _executeCommands();
                }
                else if (_buffer == "****") {
                    _updateCurrBlock();
                    _mode = SELECTORS;
                }
                _buffer = "";
                _curr_buff = 0;
                if (c == EOF)
                    return false;
            }
            else if (c == ',')
                _saveCommandBuffer();
            else
                _buffer += c;
            break;
        }
    }
    return true;
}

void Parser::_updateCurrBlock() {
    _curr_block = _list[_list.size() - 1].getLastOccupied();
    if (_curr_block == ARR_SIZE - 1) {
        _list.push_back(Blocks());
        _curr_block = (_list.size() - 1) * ARR_SIZE;
    }
    // if there is only one empty node, set index to 0
    else if (_curr_block == -1)
        _curr_block = (_list.size() - 1) * ARR_SIZE;
    else
        _curr_block += (_list.size() - 1) * ARR_SIZE + 1;
}

BlocksIndex Parser::_getSection(std::size_t index) const {
    std::size_t sum = 0;
    int i = 0;
    BlocksIndex b;
    for (auto it = _list.begin(); it != _list.end(); ++it) {
        sum += it->getOccupiedSections();
        if (sum >= index) {
            b.node_number = i;
            b.index = it->getOccupiedIndex(index - (sum - it->getOccupiedSections()));
            break;
        }
        ++i;
    }
    return b;
}

void Parser::_printNumOf(inType type) {
    std::size_t section = _getInt(_command_buffers[0]);
    if (section <= _size) {
        _indexes = _getSection(section);
        _printCommand();
        if (type == ATTRIBUTES)
            std::cout << _list[_indexes.node_number][_indexes.index].getNumOfAttributes();
        else if (type == SELECTORS)
            std::cout << _list[_indexes.node_number][_indexes.index].getNumOfSelectors();
        else
            throw std::invalid_argument("Couldn't print number of sth of invalid type.");
        std::cout << std::endl;
    }
}

void Parser::_printCommand() const {
    for (int i = 0; i < COMMAND_PARTS; ++i) {
        std::cout << _command_buffers[i];
        if (i + 1 != COMMAND_PARTS)
            std::cout << ",";
    }
    std::cout << " == ";
}

int Parser::_getInt(const String &str) {
    int i = str.toInt();
    if ( i < 0 )
        throw std::invalid_argument("Tried to convert bad string to int");
    return i;
}

void Parser::_addSelector(const char c) {
    _buffer.trimWhitespace();
    // if this is the end of selectors, occupy current section and start reading attributes
    if (c == '{') {
        _list[_curr_block/ARR_SIZE].occupy(_curr_block % ARR_SIZE);
        _mode = ATTRIBUTES;
    }
    // if there were any selectors, add them
    // if (_buffer != "") {
    if (_buffer.size() > 0) {
        _list[_curr_block/ARR_SIZE][_curr_block % ARR_SIZE].addSelector(std::move(_buffer));
    }
}

void Parser::_switchToCommandMode() {
    _buffer.trimWhitespace();
    _buffer += '?';
    if (_buffer == "????") {
        _mode = COMMANDS;
        _buffer = "";
    }
}

void Parser::_saveAttributeName() {
    _mode = ATT_VALUES;
    _buffer2 = std::move(_buffer);
    _buffer = "";
}

void Parser::_switchToSelectorMode() {
    ++_curr_block;
    ++_size;
    if (_curr_block / ARR_SIZE == _list.size())
        _list.push_back(Blocks());
    _mode = SELECTORS;
}

void Parser::_addAttribute() {
    _mode = ATTRIBUTES;
    _buffer.trimWhitespace();
    _buffer2.trimWhitespace();
    Attribute tmp_att(std::move(_buffer2), std::move(_buffer));
    _list[_curr_block/ARR_SIZE][_curr_block%ARR_SIZE].addAttribute(std::move(tmp_att));
}


void Parser::_executeCommands() {
    if (_command_buffers[1] == "S") {
        // i,S,?
        if (_command_buffers[0].isInt() && _command_buffers[2] == "?")
            _printNumOf(SELECTORS);
        // i,S,j
        else if (_command_buffers[0].isInt() && _command_buffers[2].isInt())
            _command_i_S_j();
        // z,S,?
        else
            _command_z_S_quesMark();
    }
    else if (_command_buffers[1] == "A") {
        // i,A,?
        if (_command_buffers[0].isInt() && _command_buffers[2] == "?")
            _printNumOf(ATTRIBUTES) ;
        // i,A,n
        else if (_command_buffers[0].isInt())
            _command_i_A_n();
        // n,A,?
        else
            _command_n_A_quesMark();
    }
    // z,E,n
    else if (_command_buffers[1] == "E") {
        _command_z_E_n();
    }
    else if (_command_buffers[1] == "D") {
        std::size_t index = _getInt(_command_buffers[0]);
        if (index <= _size) {
            _indexes = _getSection(index);
            // i,D,*
            if (_command_buffers[2] == "*")
                _command_i_D_star();
            // i,D,n
            else
                _command_i_D_n();
            // if this was the last section in a node, delete the node (if it isn't the last one)
            if (_list[_indexes.node_number].getOccupiedSections() == 0 && _list.size() > 1)
                _list.remove_node_by_index(_indexes.node_number);
        }
    }
}

void Parser::_command_i_S_j() {
    std::size_t i = _getInt(_command_buffers[0]);
    std::size_t j = _getInt(_command_buffers[2]);
    if (i <= _size) {
        _indexes = _getSection(i);
        if (j <= _list[_indexes.node_number][_indexes.index].getNumOfSelectors()) {
            _printCommand();
            std::cout << _list[_indexes.node_number][_indexes.index].getSelector(j - 1);
            std::cout << std::endl;
        }
    }
}

void Parser::_command_z_S_quesMark() {
    int sum = 0;
    for (auto it = _list.begin(); it != _list.end(); ++it) {
        sum += (*it).getNumOfSelectors(_command_buffers[0]);
    }
    _printCommand();
    std::cout << sum << std::endl;
}

void Parser::_command_i_A_n() {
    std::size_t i = _getInt(_command_buffers[0]);
    if (i <= _size) {
        _indexes = _getSection(i);
        int index = _list[_indexes.node_number][_indexes.index].getAttributeNameIndex(_command_buffers[2]);
        if (index >= 0) {
            _printCommand();
            std::cout << _list[_indexes.node_number][_indexes.index].getAttribute(index + 1).value;
            std::cout << std::endl;
        }
    }
}

void Parser::_command_n_A_quesMark() {
    int sum = 0;
    for (auto it = _list.begin(); it != _list.end(); ++it) {
        sum += (*it).sumOfAttributes(_command_buffers[0]);
    }
    _printCommand();
    std::cout << sum << std::endl;
}

void Parser::_command_z_E_n() {
    int index, index2;
    for (auto it = _list.beginFromEnd(); it != _list.endFromEnd(); --it) {
        index = (*it).getLastSelectorWithAttribute(_command_buffers[0], _command_buffers[2]);
        if (index >= 0) {
            index2 = (*it)[index].getAttributeNameIndex(_command_buffers[2]);
            if (index2 >= 0) {
                _printCommand();
                std::cout << (*it)[index].getAttribute(index2 + 1).value << std::endl;
                break;
            }
        }
    }
}

void Parser::_command_i_D_star() {
    _list[_indexes.node_number].removeSection(_indexes.index);
    --_size;
    _printCommand();
    std::cout << "deleted" << std::endl;
}

void Parser::_command_i_D_n() {
    // deletes the attribute, and if deleted successfully, then print "deleted"
    if (_list[_indexes.node_number][_indexes.index].removeAttribute(std::move(_command_buffers[2]))) {
        _printCommand();
        std::cout << "deleted" << std::endl;
    }
    // if this was the last attribute, remove the section
    if (_list[_indexes.node_number][_indexes.index].getNumOfAttributes() == 0) {
        _list[_indexes.node_number].removeSection(_indexes.index);
        --_size;
    }
}

void Parser::_saveCommandBuffer() {
    _command_buffers[_curr_buff] = std::move(_buffer);
    ++_curr_buff;
}
