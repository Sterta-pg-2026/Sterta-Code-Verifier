#include <iostream>
using namespace std;
#define CHAR_SIZE 30
#define INPUT_SIZE 200
#define T 8 //size of the array of blocks

class SelectorNode {
public:
	char name[CHAR_SIZE];
	SelectorNode* next;
	SelectorNode() {
		next = NULL;
	}
};

//print single linked list
void printSelectors(SelectorNode* n) {
	while (n != NULL) { //until the node points to nothing
		cout << n->name << endl;
		n = n->next;
	}
}

// inserting element at the end of the list
void addSelector(SelectorNode** head, char* name) {
	// prepararing a new node.
	SelectorNode* newNode = new SelectorNode();
	strcpy_s(newNode->name , name);
	if (head == nullptr) {
		return;
	}
	// If linked list is empty, newNode will be head node
	if (*head == NULL) {
		*head = newNode;
		return;
	}
	// finding the last node.
	SelectorNode* last = *head;
	while (last->next != NULL) {
		last = last->next;
	}
	// adding new node after last node(at the end)
	last->next = newNode;
}

class AttributeNode {
public:
	char property[CHAR_SIZE];
	char value[CHAR_SIZE];
	AttributeNode* next;
	AttributeNode() {
		next = NULL;
	}
};

//insert the element at the end of the list
void addAttributeProperty(AttributeNode** head, char* property) {
	// prepararing a new node.
	AttributeNode* newNode = new AttributeNode();
	strcpy_s(newNode->property, property);
	if (head == nullptr) {
		return;
	}
	// If linked list is empty, newNode will be head node
	if (*head == NULL) {
		*head = newNode;
		return;
	}
	// finding the last node.
	AttributeNode* last = *head;
	while (last->next != NULL) {
		last = last->next;
	}
	// adding new node after last node(at the end)
	last->next = newNode;
}

//insert the element at the end of the list
void addAttributeValue(AttributeNode** head, char* value) {
	// finding the last node.
	AttributeNode* last = *head;
	while (last->next != NULL) {
		last = last->next;
	}
	// adding new node after last node(at the end)
	strcpy_s(last->value, value);
}

void printAttributes(AttributeNode* n) {
	while (n != NULL) {
		cout << n->property <<": "<< n->value << ";" << endl;
		n = n->next;
	}
}

class Block {
public:
	SelectorNode* selectorHead;
	AttributeNode* attributeHead;
	
	Block() {
		selectorHead = nullptr;
		attributeHead = nullptr;
	}
};
class DoubleNode {
public:
	int counter;
	Block block[T];
	DoubleNode* next;
	DoubleNode* prev;
	DoubleNode() {
		next = nullptr;
		prev = nullptr;
		counter = 0;
	}
};

void addDoubleNode(DoubleNode** head) {
	// prepararing a new node.
	DoubleNode* newNode = new DoubleNode();
	if (head == nullptr) {
		return;
	}
	// If linked list is empty, newNode will be head node
	if (*head == NULL) {
		*head = newNode;
		return;
	}
	// finding the last node.
	DoubleNode* last = *head;
	while (last->next != NULL) {
		last = last->next;
	}
	// adding new node after last node(at the end)
	last->next = newNode;
	newNode->prev = last;
}

void getRidOfSpecial(char* s, int len) { // whitespaces, enter, tab, open curly bracket
	int j = 0;
	for (int i = 0; i < len; i++) {
		if (s[i] == ' ' || s[i] == '\n' || s[i] == '\t' || s[i]=='{') {
			
		}
		else {
			s[j] = s[i];
			j++;
		}
	}
}

int main() {
	DoubleNode* head_D;
	DoubleNode* tail_D = head_D = nullptr;

	addDoubleNode(&head_D);
	//strcpy_s(base->head_D->block[0].attributeHead->property , (char*)"hej");

	//head->block[head->counter].attributeHead->property;
	char input[INPUT_SIZE];
	char mycharacter = NULL;
	char* token = NULL;
	char* next_token = nullptr;

	while (scanf_s("%[^{]", input, INPUT_SIZE)) { //reading selectors
		token = strtok_s(input, ",", &next_token);
		//getRidOfSpecial(token);
		while (token != NULL) {
			addSelector(&(head_D->block[head_D->counter].selectorHead), token);
			token = strtok_s(NULL, ",", &next_token);
			//getRidOfSpecial(token);
		}

		while (scanf_s(" %[^:;}] %c ", input, INPUT_SIZE, &mycharacter, 1)) { //reading attributes
			getRidOfSpecial(input, INPUT_SIZE);
			if (mycharacter == ':') {
				
				addAttributeProperty(&head_D->block[head_D->counter].attributeHead, input);
			}
			else if (mycharacter == ';') {
				addAttributeValue(&head_D->block[head_D->counter].attributeHead, input);
			}
			else if (mycharacter == '}') {
				break;
			}
		}
		printAttributes(head_D->block[head_D->counter].attributeHead);
		if (head_D->counter == (T - 1)) { //if it was the last elment of array of blocks
			addDoubleNode(&head_D);
		}
		else {
			head_D->counter++;
		}
	}

	return 0;
}