#include "parser.h"
#include "list.h"
#include "array.h"
#include <iostream>

using namespace std;

bool Section::compare_selectors(Section& tested, Array<char>& to_test){
    bool result_flag = false;
    for(int i = 0; i < tested.Selectors.length(); i++){
        if (tested.Selectors[i] == to_test){
            result_flag = true;
            break;
        }
    }
    return result_flag;
}
bool Section::compare_attributes(Section& tested, Array<char>& to_test){
    bool result_flag = false;
    for(int i = 0; i < tested.Attributes.count(); i++){
        if( tested.Attributes[i]->Attribute == to_test ){
            result_flag = true;
            break;
        }
    }
    return result_flag;
}
bool Section::compare_attributes(Pair& tested, Array<char>& target){
    return tested.Attribute == target;
}

bool parse_css(List<Section>& blocks){
	Array<char> attr;
	Array<char> input;
	Array<char> val;
    ModeEnum MODE = ModeEnum::SELECTOR;   
    List<Pair> attributes;
	Array<Array<char>> selectors;
    char query_counter = 0;

    while( true ){
		char c = (char)getchar();
        if( c == -1 ){
            return true;
        }      
        if( ( c < ' ' ) || (  ( c == ' ' ) && ( input.length() == 0 )  ) ){
            continue;
        }
        if( MODE == ModeEnum::SELECTOR ){
            if( c == '{' ){
                input.remove_whitespaces();
				if( !( selectors.is_data(input) ) ){
					if( input.length() > 0 ){ // skip if blank
						selectors.push_back(input);
					}
				}  
                input.clear();
                MODE = ModeEnum::PROPERTY;
                continue;
            }
            if( c == ',' ){
                input.remove_whitespaces();
				if( !( selectors.is_data(input) ) ){
					if( input.length() > 0 ){ // skip if blank 
						selectors.push_back(input);
					}
				}
                input.clear();
                continue;
            }
            if( c == '?' ){ // entering cmd mode only in selector mode
                query_counter++;
                if(query_counter == 4){
                    return false;
                }
                continue;
            }
        }
        if( ( MODE == ModeEnum::PROPERTY ) || ( MODE == ModeEnum::VALUE ) ){
            if( c == '}' ){
                blocks.push_back(*new Section(selectors, attributes));
                selectors.clear();
                attributes.clear();
                input.clear();
                MODE = ModeEnum::SELECTOR;
                continue;
            }
            if( MODE == ModeEnum::PROPERTY ){
                if( c == ':' ){
                    attr = input;
                    input.clear();
                    MODE = ModeEnum::VALUE;
                    continue;
                }
            }
            if( MODE == ModeEnum::VALUE ){
                if(c == ';'){
                    val = input;
                    input.clear();
                    if( attributes.get( attr, Section::compare_attributes ) == nullptr ){
                        attributes.push_back(*new Pair(attr, val));
                    } else {
                        attributes.get(attr, Section::compare_attributes)->Value = val;
                    }     
                    MODE = ModeEnum::PROPERTY;
                    continue;
                }
            }
        }
        query_counter = 0;
        input.push_back(c);
    }
    return true;
}



bool evaluate_commands(List<Section>& blocks){
    ModeEnum MODE = ModeEnum::CMD_1;
    Array<char> input;
    Command cmd;
    while( true ){
		char c = (char)getchar();
        if( (c == '\n') || (c == '\r') || (c == '\t') || (c == -1) ){
            switch(MODE){
            case (ModeEnum::CMD_1):
                cmd.parameter_1 = input;
                break;

            case (ModeEnum::CMD_2):
                cmd.parameter_2 = input[0];
                break;

            case (ModeEnum::CMD_3):
                cmd.parameter_3 = input;
                break;
            }
            if( (cmd.parameter_1.length() == 0 ) && ( c != -1 ) ){
                continue;
            }

            input.clear();
            if( ( cmd.parameter_1[0] == '*' ) && ( cmd.parameter_1[1] == '*' ) && ( cmd.parameter_1[2] == '*' ) && ( cmd.parameter_1[3] == '*' ) ){
                return false; // return to reading input mode;

            } else if( ( cmd.parameter_2 == '0' ) && ( ( cmd.parameter_1[0] == '?' ))  || ( cmd.parameter_1[1] == '?' ) ){
                cout << "? == " << blocks.count() << '\n';
            } 
            
            switch( cmd.parameter_2 ){

            case ('S'):
                if( cmd.parameter_3[0] == '?' ){
					int block = cmd.parameter_1.to_int(true);
                    if( block == -1 ){
                        cout << cmd.parameter_1.to_string() << ",S,? == " << blocks.count(cmd.parameter_1, Section::compare_selectors) << '\n';
                    } else {
                        Section* target = blocks[block - 1];
                        if (target) {
                            cout << block << ",S,? == " << blocks[block - 1]->Selectors.length() << '\n';
                        }
                    }
                } else if( cmd.parameter_2 == 'S' ){
					int block = cmd.parameter_1.to_int();
					int selector = cmd.parameter_3.to_int();
                    Section* target = blocks[block - 1];
                    if( target ){
                        Array<char> name = target->Selectors[selector - 1];
                        if( name.length() ){
                            cout << block << ",S," << selector << " == " << name.to_string() << '\n';
                        }
                    }
                }
				break;

            case ('D'):
				if( (cmd.parameter_2 == 'D') && (cmd.parameter_3[0] == '*') ){
					int block = cmd.parameter_1.to_int();
					if( blocks.remove(block - 1) != -1 ){
						cout << block << ",D,* == deleted" << '\n';
					}
				} else {
					int block = cmd.parameter_1.to_int();
					Section* target = blocks[block - 1];
					if( target ){
						int elements_left = target->Attributes.remove(cmd.parameter_3, Section::compare_attributes);
						if( elements_left == 0 ){
							blocks.remove(block - 1);
						}
						if( elements_left != -1 ){
							cout << block << ",D," << cmd.parameter_3.to_string() << " == deleted" << '\n';
						}
					}
				}
				break;

            case ('A'):
				if( cmd.parameter_3[0] == '?' ){
					int block = cmd.parameter_1.to_int(true);
					if( block == -1 ){
						cout << cmd.parameter_1.to_string() << ",A,? == " << blocks.count(cmd.parameter_1, Section::compare_attributes) << '\n';
					} else {
						Section* target = blocks[block - 1];
						if( target ){
							cout << block << ",A,? == " << target->Attributes.count() << '\n';
						}
					}
				} else {
					int block = cmd.parameter_1.to_int();
					Section* target = blocks[block - 1];
					if( target ){
						Pair* value = target->Attributes.get(cmd.parameter_3, Section::compare_attributes);
						if( value ){
							if( value->Value.length() ){
								cout << block << ",A," << cmd.parameter_3.to_string() << " == " << value->Value.to_string() << '\n';
							}
						}

					}
				}
				break;

            case ('E'):
				Section* target = blocks.get(cmd.parameter_1, Section::compare_selectors);
				if( target ){
					Pair* value = target->Attributes.get(cmd.parameter_3, Section::compare_attributes);
					if( value ){
						if( value->Value.length() ){
							cout << cmd.parameter_1.to_string() << ",E," << cmd.parameter_3.to_string() << " == " << value->Value.to_string() << '\n';
						}
					}
				}
				break;
            }
            if(c == -1){
                return true;
            }
            MODE = ModeEnum::CMD_1;
            cmd.parameter_2 = '0';
            continue;
        } else if( ( c != -1 ) && ( c < 32 ) ){
            continue;
        }
        if( c == ',' ){
            if( MODE == ModeEnum::CMD_1 ){
                cmd.parameter_1 = input;
                MODE = ModeEnum::CMD_2;

            } else if( MODE == ModeEnum::CMD_2 ){
                cmd.parameter_2 = input[0];
                MODE = ModeEnum::CMD_3;
            }
            input.clear();
            continue;
        }
        input.push_back(c);
    }
    return true;
}