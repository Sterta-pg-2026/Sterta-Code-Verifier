#ifndef PARSER_H
#define PARSER_H

#include "list.h"
#include "array.h"


enum class ModeEnum {
    SELECTOR,
    PROPERTY,
    VALUE,
    CMD_1,
    CMD_2,
    CMD_3,
};

class Pair {
public:
    Array<char> Attribute;
    Array<char> Value;
    Pair( const Array<char>& attr, const Array<char>& val ) : Attribute(attr), Value(val) {}
};

class Section {
public:
    Array<Array<char>> Selectors;
    List<Pair> Attributes;
    Section(const Array<Array<char>>& selectors, const List<Pair>& attributes) : Selectors(selectors), Attributes(attributes) {}
	// at construction compare if elements already exist and replace older ones, after that skip 
    static bool compare_selectors(Section& tested, Array<char>& to_test);
    static bool compare_attributes(Section& tested, Array<char>& to_test);
    static bool compare_attributes(Pair& tested, Array<char>& target);
};

class Command {
public:
    Array<char> parameter_1;
    Array<char> parameter_3;
    char parameter_2 = '0';
	// second parameter is single character
};

bool evaluate_commands(List<Section>& blocks);
bool parse_css(List<Section>& blocks);


#endif /* PARSER_H */