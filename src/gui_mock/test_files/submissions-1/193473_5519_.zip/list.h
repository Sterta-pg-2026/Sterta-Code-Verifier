#ifndef LIST_H
#define LIST_H

#include <stdio.h>
#include "array.h"

template <typename T>
class List {
private:
	const static int BLOCK_SIZE = 8;
	int data_counter;
	int node_counter;

	// bad practise do not put Node in List class
	struct Node { 
		T* data[BLOCK_SIZE] = {};
		Node* next = nullptr;
		Node* prev = nullptr;
		int elements = 0;
	};

	Node* first;
	Node* last;
public:
	List(){
		first = nullptr;
		last = nullptr;
		data_counter = 0;
		node_counter = 0;
	}

	List(const List& list){	
		first = nullptr;
		last = nullptr;
		data_counter = 0;
		node_counter = 0;
		Node* temp_node = list.first;
		while( temp_node ){
			for(int i = 0; i < (temp_node->elements); i++ ){
				push_back( *( temp_node->data[i] ) );
			}
			temp_node = temp_node->next;
		}
	}

	~List(){
		Node* temp_node = first;
		while( temp_node ){
			Node* temp = temp_node;
			temp_node = temp_node->next;
			delete temp;
		}
	}

	List& operator=( const List& list ){
		if( this == &list ){
			return *this;
		}
		clear();
		Node* temp_node = list.first;
		while( temp_node ){
			for(int i = 0; i < (temp_node->elements); i++) {
				push_back(*(temp_node->data[i]));
			}
			temp_node = temp_node->next;
		}
		return *this;
	}

	void push_back( T& value ){
		if( node_counter == 0 ){
			Node* temp_node = new Node;
			temp_node->data[0] = &value;
			temp_node->elements++;
			node_counter++;
			first = temp_node;
			last = temp_node;
			data_counter++;

		} else if( last->elements == BLOCK_SIZE ){
			Node* temp_node = new Node;
			temp_node->data[0] = &value;
			temp_node->elements++;
			node_counter++;
			last->next = temp_node;
			temp_node->prev = last;
			last = temp_node;
			data_counter++;

		} else {
			last->data[last->elements] = &value;
			last->elements++;
			data_counter++;
		}
	}

	T* get( Array<char>& key, bool comparator( T&, Array<char>& ) ) const {
		Node* temp_node = last;
		while( temp_node ){
			for(int i = (temp_node->elements-1); i >= 0; i--){
				if( comparator( *( temp_node->data[i]), key ) ){
					return temp_node->data[i];
				}
			}
			temp_node = temp_node->prev;
		}
		return nullptr;
	}

	T* operator[]( int index ) const { // should be const?
		if( index > data_counter ){
			return nullptr;
		}
		int i = 0;
		Node* temp_node = first;

		while( temp_node ){
			for( int j = 0; j < (temp_node->elements); j++){
				if( i == index ){
					return temp_node->data[j];
				}
				i++;
			}
			temp_node = temp_node->next;
		}
		return nullptr;
	}

	int count() const {
		return data_counter;
	}

	int count( Array<char>& key, bool comparator( T&, Array<char>& ) ) const {
		int count = 0;
		Node* temp_node = last;

		while( temp_node ){
			for(int i = 0; i < (temp_node->elements); i++){
				if( comparator( *( temp_node->data[i]), key ) ){
					count++;
				}
			}
			temp_node = temp_node->prev;
		}
		return count;
	}

	int remove(Array<char>& key, bool comparator(T&, Array<char>&)){
		Node* temp_node = last;
		while( temp_node ){
			for(int i = 0; i < (temp_node->elements); i++){
				if( comparator( *( temp_node->data[i] ), key ) ){
					for(int j = i; j < (temp_node->elements - 1); j++){
						temp_node->data[j] = temp_node->data[j + 1];
					}
					temp_node->elements--;
					data_counter--;
					if( temp_node->elements == 0 ){
						if( temp_node->prev ){
							temp_node->prev->next = temp_node->next;
						}
						else {
							first = temp_node->next;
						}
						if (temp_node->next ){
							temp_node->next->prev = temp_node->prev;
						}
						else {
							last = temp_node->prev;
						}
						delete temp_node;
						node_counter--;
					}
					return data_counter;
				}
			}
			temp_node = temp_node->prev;
		}
		return -1;
	}

	int remove(int index ){
		if( index > data_counter ){
			return -1;
		}
		int i = 0;
		Node* temp_node = first;
		while( temp_node ){
			for(int j = 0; j < (temp_node->elements); j++){
				if( i == index ){
					for(int k = j; k < (temp_node->elements - 1); k++){
						temp_node->data[k] = temp_node->data[k + 1];
					}
					temp_node->elements--;
					data_counter--;
					if( temp_node->elements == 0 ){
						if( temp_node->prev ){ 
							temp_node->prev->next = temp_node->next; 
						} else {
							first = temp_node->next;
						}
						if ( temp_node->next ){
							temp_node->next->prev = temp_node->prev;
						} else {
							last = temp_node->prev;
						}					
						delete temp_node;
						node_counter--;
					}
					return data_counter;
				}
				i++;
			}
			temp_node = temp_node->next;
		}
		return -1;
	}

	void clear(){
		Node* temp_node = first;
		while( temp_node ){
			Node* temp = temp_node;
			temp_node = temp_node->next;
			delete temp;
		}
		data_counter = 0;
		node_counter = 0;
		first = nullptr;
		last = nullptr;
	}
};

#endif /* LIST_H */