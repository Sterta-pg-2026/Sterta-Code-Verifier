﻿#include "list.h"
#include "array.h"
#include "parser.h"
#include <stdio.h>
#include <iostream>

using namespace std;

int main(){
    List<Section> blocks;

    while(true){
		if( parse_css( blocks ) ){
			break;
		} 		
		if( evaluate_commands( blocks ) ){
			break;
		}
    }
    return 0;
}