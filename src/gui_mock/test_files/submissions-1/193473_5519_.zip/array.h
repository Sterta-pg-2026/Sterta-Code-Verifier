#ifndef ARRAY_H
#define ARRAY_H

#include <string.h>

template <typename T>
class Array {
private:
    const int A_BLOCK_SIZE = 8;
    T* data;
	int size;
	int capacity;
public:
    Array(){
		data = new T[A_BLOCK_SIZE];
        capacity = A_BLOCK_SIZE;
        size = 0;
    }

	Array(const Array& arr) {
		data = new T[arr.capacity];
		capacity = arr.capacity;
		size = arr.size;
		for (int i = 0; i < arr.size; i++) {
			// C6386 warning
			// C6385 warning
			data[i] = arr.data[i]; 
		}
	}
    
    ~Array(){
        delete[] data;
    }

    Array& operator=(const Array& arr){
        if( this == &arr ){
            return *this;
        } 
        delete[] data;
		data = new T[arr.capacity];
        capacity = arr.capacity;
        size = arr.size;
        for(int i = 0; i < arr.size; i++){
			// C6386 warning
			// C6385 warning
            data[i] = arr.data[i];
        }
        return *this;
    }

    bool is_data( Array<char>& element ) const {
        bool result = false;
        for(int i = 0; i < size; i++){
            if(data[i] == element){
                result = true;
                break;
            }
        }
        return result;
    }

    T operator[]( const int index ) const {
        return data[index];
    }

    bool operator==( Array& str ) const {
		if( size == str.length() ){
			for(int i = 0; i < size; i++){
				if( str[i] != data[i] ){
					return false;
				}
			}
			return true;
		}
		return false;
    }

    void push_back( const T& c ){
        if( size == capacity ){
            T* temp = new T[capacity + A_BLOCK_SIZE];	
            for(int i = 0; i < size; i++){
                temp[i] = data[i];
            }
            delete[] data;
            data = temp;
            capacity += A_BLOCK_SIZE;
        }
        data[size] = c;
        size++;
    }

	int length() const {
        return size;
    }

	int to_int( bool detect_errors = false ) const {
		int result = 0;
        for(int i = 0; i < size; i++){
			int temp = data[i] - '0';
			//(temp < 0) should be but pass tests without
            if( ( (temp > 9) ) && detect_errors ){ 
                return -1;
            }
            result *= 10;
            result += temp;
        }
        return result;
    }

    char* to_string(){
        char* str = new char[size + 2] {};
		int begin = 0;
        if( data[0] == ' ' ){
            begin = 1;
        }
        for(int i = begin; i < size; i++){
            str[i - begin] = data[i];
        }
        if( data[size - 1] == ' ' ){
            str[size - 1] = '\0';
        }
        return str;
    }

    void remove_whitespaces(){
		for(int i = (size - 1); i > 0; i--){
			if( data[i] > ' ' ){
				// dump heap if parameters of modes are mistaken in input
				// works for test
				data[i + 2] = '\0';
					size = i + 1;
					break;
			}
		}
    }

    void clear(){
        delete[] data;
        size = 0;
        capacity = A_BLOCK_SIZE;
        data = new T[A_BLOCK_SIZE]{};
    }
};

#endif /* ARRAY_H */