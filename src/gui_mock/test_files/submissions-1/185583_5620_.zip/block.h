#pragma once
#include "listelements.h"
class Block {
public:
    ListElements* selectors;
    ListElements* atrybuts;
    ListElements* atrybutsvalue;
    Block();
    Block(ListElements sel, ListElements atry, ListElements value);

    
};
