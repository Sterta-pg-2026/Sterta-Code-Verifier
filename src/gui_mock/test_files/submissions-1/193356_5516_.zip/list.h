#pragma once
#include <iostream>
using namespace std;

template <typename T> struct Node {
	T data;
	Node* next;
	Node* prev;
};

template <typename T> class List {
private:
	Node<T>* head;
	Node<T>* tail;
	int vol = 0; //volume = number of elements
public:
	List() {
		head = NULL;
		tail = NULL;
	}

	void add(T value) {
		Node<T>* n = new Node<T>();
		n->data = value;
		n->next = NULL;
		n->prev = tail;
		if (head == NULL) {
			head = n;
		}
		else {
			tail->next = n;
		}
		tail = n;
		vol++;
	}

	T& get(int index) {
		if (head != nullptr) {
			Node<T>* temp = head;
			for (int i = 0; i < index; i++) {
				temp = temp->next;
			}
			return temp->data;
		}
	}

	int search(T value) {
		Node<T>* temp = head;
		int pos = 0;
		while (temp != nullptr) {
			if (temp->data == value) {
				return pos;
			}
			else {
				temp = temp->next;
				pos++;
			}
		}
		return -1; //no such value
	}

	friend ostream& operator<<(ostream& out, const List<T>& list) {
		Node<T>* temp = list.head;
		while (temp != nullptr) {
			out << temp->data << " ";
			temp = temp->next;
		}
		return out;
	}

	int getVol() {
		return vol;
	}

	void deleteElement(int index) {
		if (head != nullptr) {
			Node<T>* temp = head;
			for (int i = 0; i < index; i++) {
				temp = temp->next;
			}
			if (temp->prev != nullptr)
				temp->prev->next = temp->next;
			if (temp->next != nullptr)
				temp->next->prev = temp->prev;
			if (temp == head)
				head = temp->next;
			delete temp;
			vol--;
		}
	}

	~List() {
		Node<T>* temp = head;
		while (temp != nullptr) {
			head = head->next;
			delete temp;
			temp = head;
		}
	}
};
