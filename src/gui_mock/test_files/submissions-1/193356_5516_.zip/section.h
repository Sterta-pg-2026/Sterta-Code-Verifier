#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "string.h"
#include "list.h"
#include "attribute.h"
using namespace std;

class Section {
private:
	List<String> selectors;
	List<Attribute> attributes;
public:
    Section() {}

    Section(const List<String>& s, const List<Attribute>& a) {
        selectors = s;
        attributes = a;
    }

    Section(const Section& other) {
        selectors = other.selectors;
        attributes = other.attributes;
    }

    Section& operator=(const Section& other) {
        if (this == &other) {
            return *this;
        }
        selectors = other.selectors;
        attributes = other.attributes;
        return *this;
    }

	void addAttribute(const String& name, const String& value) {
		Attribute attr(name, value);
		attributes.add(attr);
    }

	Attribute* getAttByName(const String& name) {
		for (int i = 0; i < attributes.getVol(); i++) {
			if (attributes.get(i).getName() == name) {
				return &attributes.get(i);
			}
		}
		return nullptr;
	}

	void deleteAttByName(const String& name) {
		for (int i = 0; i < attributes.getVol(); i++) {
			if (attributes.get(i).getName() == name) {
				attributes.deleteElement(i);
				break;
			}
		}
	}
        
    ~Section() {}
};
