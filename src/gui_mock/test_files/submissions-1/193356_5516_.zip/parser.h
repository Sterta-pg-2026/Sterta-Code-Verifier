#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "string.h"
#include "list.h"
#include "section.h"
using namespace std;

class Parser {
private:
	int mode; // 0 - read CSS, 1 - read commands
	int read_att; // 0-1, true between '{' and '}'
	String prev_input;
	List<Section> sections;
public:
    Parser() {
        mode = 0;
        read_att = 0;
        prev_input = "";
    }

    Parser(const Parser& other) {
        mode = other.mode;
        read_att = other.read_att;
        prev_input = other.prev_input;
        sections = other.sections;
    }

    Parser& operator=(const Parser& other) {
        if (this == &other) {
            return *this;
        }
        mode = other.mode;
        read_att = other.read_att;
        prev_input = other.prev_input;
        sections = other.sections;
        return *this;
    }

    void parse(String line) {
        String curr_input = "";
        for (int i = 0; i < line.getLength(); i++) {
            char c = line[i];
            if (c == '{') {
                read_att = 1;
                String section = curr_input + prev_input;
				//add current input gets added to section as selector
				//List<String> selectors = split(section, ',');
                curr_input = "";
                prev_input = "";
            }
            else if (c == '}') {
                read_att = 0;
                //last attribute added before closing "read_att" mode
                curr_input = "";
            }
            else {
                curr_input = curr_input + c;
            }
        }
        if (read_att == 1) {
            //add attribute to section
        }
        else {
            prev_input = prev_input + curr_input;
        }
    }

	Section* getLastSection() {
		return &sections.get(sections.getVol() - 1);
	}
    
	void deleteSection(int index) {
		sections.deleteElement(index);
	}

    ~Parser() {}
};
