#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

class String {
private:
    char* str;
    int len;
public:
    String() {
        str = new char[1];
        str[0] = '\0';
        len = 0;
    }

    String(const char* s) {
        len = strlen(s);
        str = new char[len + 1];
        strcpy(str, s);
    }

    String(const String& other) {
        len = other.len;
        str = new char[len + 1];
        strcpy(str, other.str);
    }

    String& operator=(const String& other) {
        if (this == &other) {
            return *this;
        }
        delete[] str;
        len = other.len;
        str = new char[len + 1];
        strcpy(str, other.str);
        return *this;
    }

    String operator+(const String& other) {
        int len1 = len;
        int len2 = other.len;
        char* temp = new char[len1 + len2 + 1];
        strcpy(temp, str);
        strcat(temp, other.str);
        String combined(temp);
        delete[] temp;
        return combined;
    }

	String operator+(const char& other) {
		int len1 = len;
		int len2 = 1;
		char* temp = new char[len1 + len2 + 1];
		strcpy(temp, str);
		temp[len1] = other;
		temp[len1 + len2] = '\0';
		String combined(temp);
		delete[] temp;
		return combined;
	}

    char& operator[](int index) {
        return str[index];
    }

    bool operator==(const String& other) {
        return strcmp(str, other.str) == 0;
    }

    friend ostream& operator<<(ostream& out, const String& s) {
        out << s.str;
        return out;
    }

    friend istream& operator>>(istream& in, String& s) {
        char temp[1000];
        in >> temp;
        s = String(temp);
        return in;
    }

    int getLength() {
        return len;
    }
    
    ~String()
    {
        delete[] str;
    }
};
