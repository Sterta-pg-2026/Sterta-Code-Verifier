ï»¿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "string.h"
#include "list.h"
#include "attribute.h"
#include "section.h"
#include "parser.h"
using namespace std;

List<String> split(String str, char c) {
	List<String> result;
	
	String temp = "";
	for (int i = 0; i < str.getLength(); i++) {
		if (str[i] == c) {
			result.add(temp);
			temp = "";
		}
		else if (str[i] != ' ') {
			temp = temp + str[i];
		}
	}
	result.add(temp);
	return result;
}

int main()
{
	String s1("Hello, world, cool");
	cout << s1 << "\n";
	List<String> l1(split(s1, ','));
	String s;
	s = l1.get(0);
	cout << "|" << l1.get(0) << "|" << l1.get(2) << "|" << "\n";
    return 0;
}
