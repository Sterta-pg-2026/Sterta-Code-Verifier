#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "string.h"
using namespace std;

class Attribute {
private:
	String name;
	String value;
public:
public:
    Attribute() {
        name = "";
        value = "";
    }

    Attribute(const String& n, const String& v) {
        name = n;
        value = v;
    }

    Attribute(const Attribute& other) {
        name = other.name;
        value = other.value;
    }

    Attribute& operator=(const Attribute& other) {
        if (this == &other) {
            return *this;
        }
        name = other.name;
        value = other.value;
        return *this;
    }

	String getName() const {
		return name;
	}

	String getValue() const {
		return value;
	}
    
    ~Attribute() {}
};
