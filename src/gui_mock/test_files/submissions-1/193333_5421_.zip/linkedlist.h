#pragma once
#include <cstdlib>
#include "node.h"
#include "telements.h"

template <class T>
class linked_list {
private:
	Node<T>* head;
	Node<T>* tail;
	int counter = 0;
public:
	linked_list();
	void AddFirst(T* t);
	void AddLast(T* t);
	Node<T>* GetFirst();
	Node<T>* GetLast();
	Node<T>* GetAtPos(int pos);
	int getCounter();
	void print();
};
