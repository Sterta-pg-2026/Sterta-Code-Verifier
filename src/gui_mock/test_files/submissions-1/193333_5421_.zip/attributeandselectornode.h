#pragma once
#include <cstdlib>
#include "telements.h"

template <class T>
struct AttriubteAndSelectorNode {
	T value;
	AttriubteAndSelectorNode<T>* next;
	AttriubteAndSelectorNode<T>* prev;
	AttriubteAndSelectorNode(T t)
	{
		this->value = t;
		this->next = NULL;
		this->prev = NULL;
	}
};