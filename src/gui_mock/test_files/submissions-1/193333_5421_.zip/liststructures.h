#pragma once
#include "string.h"
#include "attributeandselectorlist.h"
#include "telements.h"

struct Attribute {
	String name;
	String attr_value;
};

struct Section{
	attributeAndSelectorList<String> selectors;
	attributeAndSelectorList<Attribute> attributes;
	bool isUsed = 0;
	//String napis;
	
};
