#pragma once
#include <cstdlib>
#include "telements.h"
#include "attributeandselectornode.h"

template <class T>
class attributeAndSelectorList {
private:
	AttriubteAndSelectorNode<T>* head;
	AttriubteAndSelectorNode<T>* tail;
	int counter = 1;
public:
	attributeAndSelectorList();
	void AddFirst(T t);
	void AddLast(T t);
	AttriubteAndSelectorNode<T>* GetFirst();
	AttriubteAndSelectorNode<T>* GetLast();
	AttriubteAndSelectorNode<T>* GetAtPos(int pos);
	int GetCounter();
	void printAttributes();
	void printSelectors();
	~attributeAndSelectorList();
};
