#include "attributeandselectorlist.h"
#include "attributeandselectornode.h"
#include <cstdlib>
#include <iostream>
using namespace std;

template<class T>
attributeAndSelectorList<T>::attributeAndSelectorList() {
	head = NULL;
	tail = NULL;
}

template<class T>
void attributeAndSelectorList<T>::AddFirst(T item) {
	if (head == NULL)
	{
		head = new AttriubteAndSelectorNode<T>(item);
		tail = head;
		return;
	}
	AttriubteAndSelectorNode<T>* newNode = new AttriubteAndSelectorNode<T>(item);
	head->prev = newNode;
	newNode->next = head;
	head = newNode;
	counter++;
}

template<class T>
void attributeAndSelectorList<T>::AddLast(T item) {
	if (tail == NULL) {
		tail = new AttriubteAndSelectorNode<T>(item);
		head = tail;
		return;
	}
	AttriubteAndSelectorNode<T>* newNode = new AttriubteAndSelectorNode<T>(item);
	tail->next = newNode;
	newNode->prev = tail;
	tail = newNode;
	counter++;
}

template<class T>
AttriubteAndSelectorNode<T>* attributeAndSelectorList<T>::GetFirst() {
	return head;
}

template<class T>
AttriubteAndSelectorNode<T>* attributeAndSelectorList<T>::GetLast() {
	return tail;
}

template<class T>
AttriubteAndSelectorNode<T>* attributeAndSelectorList<T>::GetAtPos(int pos) 
{
	AttriubteAndSelectorNode<T>* tmp = head;
	while (tmp != NULL)
	{
		if (pos == 0)
		{
			return tmp;
		}
		pos--;
		tmp = tmp->next;
	}
	return NULL;
}

template<class T>
int attributeAndSelectorList<T>::GetCounter() {
	return counter;
}


template <class T>
void attributeAndSelectorList<T>::printAttributes() {
	if (head == NULL) {
		return;
	}
	else {
		AttriubteAndSelectorNode<T>* current = head;
		while (current != NULL) {
			current->value.name.PrintString();
			cout << " ";
			current->value.attr_value.PrintString();
			cout << endl;
			current = current->next;
		}
	}
}

template <class T>
void attributeAndSelectorList<T>::printSelectors () {
	if (head == NULL) {
		return;
	}
	else {
		AttriubteAndSelectorNode<T>* current = head;
		while (current != NULL) {
			current->value.PrintString();
			current = current->next;
		}
	}
	cout << endl;
}

template<class T>
attributeAndSelectorList<T>::~attributeAndSelectorList<T>()
{
	//AttriubteAndSelectorNode<T>* tmp = head;
	//while(tmp)
	//{
	//	AttriubteAndSelectorNode<T>* tmp = head;
	//	head = tmp->next;
	//	delete[] head;
	//}
}
