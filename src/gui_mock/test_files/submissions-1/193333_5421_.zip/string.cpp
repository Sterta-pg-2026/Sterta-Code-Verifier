#include <iostream>
#include "string.h"
using namespace std;

String::String()
{
	tab = new char[1];
}

void String::addLetter(char letter)
{
	char* tab_tmp;
	tab_tmp = tab;
	tab = new char[x];
	for (int i = 0; i < x - 1; i++)
	{
		tab[i] = tab_tmp[i];
	}
	tab[x - 1] = letter;
	x++;
	delete[] tab_tmp;
}

void String::PrintString()
{
	{
		for (int i = 0; i < x - 1; i++)
		{
			cout << tab[i];
		}
	}
}

void String::setString(char* word, int len)
{
	tab = new char[len];
	x = len + 1;
	for (int i = 0; i < len; i++)
	{
		tab[i] = word[i];
	}
}

void String::clearString()
{
	for (int i = 0; i < x - 1; i++)
		{
			tab[i] = NULL;
		}
		tab = new char[1];
		x = 1;
}

char* String::getTab()
{
	return tab;
}

int String::getLen()
{
	return x;
}

int String::convertStringNumberToInt()
{
	int liczba = 0;
	int k;
	k = 1;
	for (int i = x - 2; i >= 0; i--)
	{
		liczba += (int(tab[i]) - 48) * k;
		k *= 10;
	}
	return liczba;
}

bool String::ifEqualString(String m)
{
	if (m.getLen() != this->getLen())
	{
		return false;
	}
	for (int i = 0; i < x - 1; i++)
	{
		if (m.getTab()[i] != this->getTab()[i])
		{
			return false;
		}
	}
	return true;
}

String::~String(){}