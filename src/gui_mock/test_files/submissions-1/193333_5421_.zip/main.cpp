#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string.h"
#include "liststructures.h"
#include "linkedlist.cpp"
#include "attributeandselectorlist.cpp"
#include "telements.h"
using namespace std;

//Poczatek funkcji odpowiedzialnych za komendy
void printHowManySelectorsInISection(int i, linked_list<Section>* sekcje, int section_counter)
{
	int array_index = 0;
	int counter = 0;
	while (true)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(array_index)->value[j].isUsed)
			{
				if(counter==i)
				{
					if (sekcje->GetAtPos(array_index)->value[j].selectors.GetFirst() != NULL)
					{
						cout << i+1 << ",S,? == " << sekcje->GetAtPos(array_index)->value[j].selectors.GetCounter() << endl;
					}
					return;
				}
				counter++;
				if (counter >= section_counter)
				{
					return;
				}
			}
		}
		array_index++;
	}
	return;
}

void printJSelectorForISection(int i, int m, linked_list<Section>* sekcje, int section_counter)
{
	int array_index = 0;
	int counter = 0;
	while (true)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(array_index)->value[j].isUsed)
			{
				if (counter == i)
				{
					if (m >= sekcje->GetAtPos(array_index)->value[j].selectors.GetCounter())
					{
						return;
					}
					cout << i + 1 << ",S," << m + 1 << " == ";
					sekcje->GetAtPos(array_index)->value[j].selectors.GetAtPos(m)->value.PrintString();
					cout << endl;
					return;
				}
				counter++;
				if (counter >= section_counter)
				{
					return;
				}
			}
		}
		array_index++;
	}
	return;
}

void printHowManyZSelectors(String z, linked_list<Section> *sekcje, int section_counter)
{
	int counter = 0;

	for (int i = 0; i < sekcje->getCounter(); i++)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(i)->value[j].isUsed)
			{
				for (int k = 0; k < sekcje->GetAtPos(i)->value[j].selectors.GetCounter(); k++)
				{
					if (sekcje->GetAtPos(i)->value[j].selectors.GetAtPos(k)->value.ifEqualString(z))
						counter++;
					if (counter >= section_counter)
					{
						return;
					}
				}
			}
		}
	}
	z.PrintString();
	cout << ",S,? == " << counter << endl;
	return;
}

void printHowManyAttributesInISection(int i, linked_list<Section>* sekcje, int section_counter)
{
	int array_index = 0;
	int counter = 0;
	while (true)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(array_index)->value[j].isUsed)
			{
				if (counter == i)
				{
					cout << i+1 <<",A,? == " << sekcje->GetAtPos(array_index)->value[j].attributes.GetCounter() << endl;
					return;
				}
				counter++;
				if (counter >= section_counter)
				{
					return;
				}
			}
		}
		array_index++;
	}
	return;
}

void printNAttributeForISection(int i, String n, linked_list<Section>* sekcje, int section_counter)
{
	int array_index = 0;
	int counter = 0;
	while (true)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(array_index)->value[j].isUsed)
			{
				if (counter == i)
				{
					for (int k = 0; k < sekcje->GetAtPos(array_index)->value[j].attributes.GetCounter(); k++)
					{
						if (sekcje->GetAtPos(array_index)->value[j].attributes.GetAtPos(k)->value.name.ifEqualString(n))
						{
							cout << i + 1 << ",A,";
							sekcje->GetAtPos(array_index)->value[j].attributes.GetAtPos(k)->value.name.PrintString();
							cout << " ==";
							sekcje->GetAtPos(array_index)->value[j].attributes.GetAtPos(k)->value.attr_value.PrintString();
							cout << endl;
							return;
						}
					}
				}
				counter++;
				if (counter >= section_counter)
				{
					return;
				}
			}
		}
		array_index++;
	}
	return;
}

void printHowManyNAttributes(String n, linked_list<Section>* sekcje)
{
	int counter = 0;
	for (int i = 0; i < sekcje->getCounter(); i++)
	{
		for (int j = 0; j < Telements; j++)
		{
			if(sekcje->GetAtPos(i)->value[j].isUsed)
			{
				for (int k = 0; k < sekcje->GetAtPos(i)->value[j].attributes.GetCounter(); k++)
				{
					if (sekcje->GetAtPos(i)->value[j].attributes.GetAtPos(k)->value.name.ifEqualString(n))
					{
						counter++;
					}
				}
			}
		}
	}
	n.PrintString();
	cout << ",A,? == " << counter << endl;
}

void deleteSectionI(int i, linked_list<Section>* sekcje)
{

}

void deleteNAttributeFromISection(int i, String n, linked_list<Section>* sekcje)
{
}

void PrintValueOfNNameAttributeForZSelector(String z, String n, linked_list<Section>* sekcje)
{
	String value_needed;
	for (int i = 0; i < sekcje->getCounter(); i++)
	{
		for (int j = 0; j < Telements; j++)
		{
			if (sekcje->GetAtPos(i)->value[j].isUsed)
			{
				for (int k = 0; k < sekcje->GetAtPos(i)->value[j].selectors.GetCounter(); k++)
				{
					if (sekcje->GetAtPos(i)->value[j].selectors.GetAtPos(k)->value.ifEqualString(z))
					{
						for (int m = 0; m < sekcje->GetAtPos(i)->value[j].attributes.GetCounter(); m++)
						{
							if (sekcje->GetAtPos(i)->value[j].attributes.GetAtPos(m)->value.name.ifEqualString(n))
							{
								value_needed.clearString();
								value_needed.setString(sekcje->GetAtPos(i)->value[j].attributes.GetAtPos(m)->value.attr_value.getTab(), sekcje->GetAtPos(i)->value[j].attributes.GetAtPos(m)->value.attr_value.getLen()-1);
							}
						}
					}
				}
			}
		}
	}
	z.PrintString();
	cout << ",E,";
	n.PrintString();
	cout << " ==";
	value_needed.PrintString();
	cout << endl;
	return;
}
//Koniec funkcji odpowiedzialnych za komendy

//funkcja ktora wybiera ktora komende nalezy wykonac, po czym ja wywoluje
void chooseCommand(String komenda[3], linked_list<Section>* sekcje, int section_counter)
{
	int int_command1 = -1;
	int int_command3 = -1;
	if (komenda[0].getTab()[0] == '1' || komenda[0].getTab()[0] == '2' || komenda[0].getTab()[0] == '3' || komenda[0].getTab()[0] == '4' || komenda[0].getTab()[0] == '5' || komenda[0].getTab()[0] == '6' || komenda[0].getTab()[0] == '7' || komenda[0].getTab()[0] == '8' || komenda[0].getTab()[0] == '9')
	{
		int_command1 = komenda[0].convertStringNumberToInt();
	}
	if (komenda[2].getTab()[0] == '1' || komenda[2].getTab()[0] == '2' || komenda[2].getTab()[0] == '3' || komenda[2].getTab()[0] == '4' || komenda[2].getTab()[0] == '5' || komenda[2].getTab()[0] == '6' || komenda[2].getTab()[0] == '7' || komenda[2].getTab()[0] == '8' || komenda[2].getTab()[0] == '9')
	{
		int_command3 = komenda[2].convertStringNumberToInt();
	}
	switch (komenda[1].getTab()[0])
	{
	case('S'):
		if (int_command1 != -1 && komenda[2].getTab()[0] == '?')
		{
			printHowManySelectorsInISection(int_command1-1, sekcje, section_counter);

		}
		else if (int_command1 != -1 && int_command3 != -1)
		{
			printJSelectorForISection(int_command1-1, int_command3-1, sekcje, section_counter);
		}
		else if (int_command1 == -1 && komenda[2].getTab()[0] == '?')
		{
			printHowManyZSelectors(komenda[0], sekcje, section_counter);
		}
		break;
	case('A'):
		if (int_command1 != -1 && komenda[2].getTab()[0] == '?')
		{
			printHowManyAttributesInISection(int_command1-1, sekcje, section_counter);
		}
		else if (int_command1 != -1 && int_command3 == -1)
		{
			printNAttributeForISection(int_command1-1, komenda[2], sekcje, section_counter);
		}
		else if (int_command1 == -1 && komenda[2].getTab()[0] == '?')
		{
			printHowManyNAttributes(komenda[0], sekcje);
		}
		break;
	case('D'):
		if (int_command1 != -1 && komenda[2].getTab()[0] == '*')
		{
			deleteSectionI(int_command1, sekcje);
		}
		else if (int_command1 != -1 && int_command3 == -1)
		{
			deleteNAttributeFromISection(int_command1, komenda[2], sekcje);
		}
		break;
	case('E'):
		PrintValueOfNNameAttributeForZSelector(komenda[0], komenda[2], sekcje);
		break;
	default:
		break;
	}
}

void addSection(linked_list<Section> *sekcje, Section sekcja) 
{
	Section newTabSection[Telements];
	sekcja.isUsed = 1;
	if (sekcje->getCounter() == 0)
	{
		sekcje->AddLast(newTabSection);
	}
	int isNewSectionAdded = 0;
	while (!isNewSectionAdded)
	{
		for (int i = 0; i < sekcje->getCounter(); i++)
		{
			if (!isNewSectionAdded)
			{
				for (int j = 0; j < Telements; j++)
				{
					if (sekcje->GetAtPos(i)->value[j].isUsed == 0 && !isNewSectionAdded)
					{
						sekcje->GetAtPos(i)->value[j] = sekcja;
						isNewSectionAdded = 1;
					}
				}
			}
		}
		if (!isNewSectionAdded) {
			sekcje->AddLast(newTabSection);
		}
	}
}

//funkcja odpowiedzialna za wczytywanie
void loadChars(linked_list<Section> *sekcje)
{
	String new_word;
	String selector;
	Section new_section[1000];
	static int i = 0;
	Attribute new_attribute;
	String command[3];
	String tmp_command;
	int command_part = 0;
	char c = 0;
	int section_counter = 0;
	static int if_new_section_needed = 0;
	static int if_selectors = 1;
	static int if_attr_name = 1;
	static int if_attr_value = 0;
	static int if_css = 1;
	while (c != EOF)
	{
		int if_overwriting = 0;
		c = getchar();
		//przejscie na sekcje komend
		if (c == '?' && if_css)
		{
			while (c =='?')
			{
				c = getchar();
			}
			if_css = 0;
		}
		//przejscie na sekcje css
		if (c == '*' && !if_css && command_part == 0)
		{
			while (c == '*')
			{
				c = getchar();
			}
			if_css = 1;
		}
		//obslugia sekcji css
		if(if_css)
		{
			if (if_new_section_needed)
			{
				addSection(sekcje, new_section[i]);
				section_counter++;
				//sekcje->print();
				if_new_section_needed = 0;
				if_selectors = 1;
				if_attr_name = 1;
				if_attr_value = 0;
				i++;
			}
			switch (c)
			{
			case(':'):
				if (if_selectors)
				{
					new_word.addLetter(c);
					break;
				}
				new_attribute.name.setString(new_word.getTab(), new_word.getLen() - 1);
				new_word.clearString();
				if_attr_name = 0;
				if_attr_value = 1;
				break;
			case(';'):
				new_attribute.attr_value.setString(new_word.getTab(), new_word.getLen() - 1);
				for (int k = 0; k < new_section[i].attributes.GetCounter()-1; k++)
				{
					if (new_section[i].attributes.GetAtPos(k)->value.name.ifEqualString(new_attribute.name))
					{
						new_section[i].attributes.GetAtPos(k)->value.attr_value.setString(new_attribute.attr_value.getTab(), new_attribute.attr_value.getLen() - 1);
						new_word.clearString();
						if_attr_name = 1;
						if_attr_value = 0;
						if_overwriting = 1;
						break;
					}
				}
				if (if_overwriting == 0)
				{
					new_section[i].attributes.AddLast(new_attribute);
					new_word.clearString();
					if_attr_name = 1;
					if_attr_value = 0;
					break;
				}
				break;
			case(','):
				if (if_selectors)
				{
					selector.setString(new_word.getTab(), new_word.getLen() - 1);
					new_section[i].selectors.AddLast(selector);
					new_word.clearString();
				}
				else if (if_attr_value)
				{
					new_word.addLetter(c);
					break;
				}
				break;
			case('{'):
				if_selectors = 0;
				selector.setString(new_word.getTab(), new_word.getLen() - 1);
				new_section[i].selectors.AddLast(selector);
				new_word.clearString();
				break;
			case('}'):
				if (if_attr_name == 0) // zabezpiecznie przed brakiem ';' po ostanim atrybucie
				{
					new_attribute.attr_value.setString(new_word.getTab(), new_word.getLen() - 1);
					for (int k = 0; k < new_section[i].attributes.GetCounter() - 1; k++)
					{
						if (new_section[i].attributes.GetAtPos(k)->value.name.ifEqualString(new_attribute.name))
						{
							new_section[i].attributes.GetAtPos(k)->value.attr_value.setString(new_attribute.attr_value.getTab(), new_attribute.attr_value.getLen() - 1);
							new_word.clearString();
							if_attr_name = 1;
							if_attr_value = 0;
							if_overwriting = 1;
							break;
						}
					}
					if (if_overwriting == 0)
					{
						new_section[i].attributes.AddLast(new_attribute);
						new_word.clearString();
						if_attr_name = 1;
						if_attr_value = 0;
						break;
					}
				}
				if_new_section_needed = 1;
				break;
			default:
				if (c != ' ' && c != char(10) && c != char(11) && c != char(9) && c != char(12) || (if_attr_value == 1 || (if_selectors == 1 && c == ' ')))
				{
					new_word.addLetter(c);
					break;
				}
				break;
			}
		}
		//obsluga sekcji komend
		if (!if_css)
		{
			switch (c)
			{
			case('?'):
				if (command_part == 0)
				{
					cout << "? == " << section_counter << endl;
				}
				else
				{
					tmp_command.addLetter(c);
				}
				break;
			case(','):
				command[command_part].setString(tmp_command.getTab(), tmp_command.getLen() - 1);
				command_part++;
				tmp_command.clearString();
				break;

			case(char(10)):
				if (command_part == 0) break;
				else
				{
					command[command_part].setString(tmp_command.getTab(), tmp_command.getLen() - 1);
					command_part = 0;
					tmp_command.clearString();
					chooseCommand(command, sekcje, section_counter);
					for (int i = 0; i < 3; i++)
					{
						command[i].clearString();
					}
					break;
				}
			default:
				tmp_command.addLetter(c);
				break;
			}
		}
	}
}

int main()
{
	linked_list<Section>* sekcje = new linked_list<Section>;
	loadChars(sekcje);
	return 0;
}