#pragma once
#include "telements.h"
#include <stdlib.h>

template <class T>
class Node {
public:
	T value[8];
	Node<T>* next;
	Node<T>* prev;
	Node(T* t)
	{
		for (int i = 0; i < 8; i++)
		{
			this->value[i] = t[i];
		}
		this->next = NULL;
		this->prev = NULL;
	}
	bool isNodeFull()
	{
		for (int i = 0; i < 8; i++)
		{
			if (value[i] == NULL)
			{
				return false;
			}
		}
		return true;
	}
	bool isNodeTotallyEmpty()
	{
		for (int i = 0; i < 8; i++)
		{
			if (value[i] != NULL)
			{
				return false;
			}
		}
		return true;
	}
	int findEmptyIndex()
	{
		for (int i = 0; i < 8; i++)
		{
			if (value[i] == NULL)
			{
				return i;
			}
		}
	}
};