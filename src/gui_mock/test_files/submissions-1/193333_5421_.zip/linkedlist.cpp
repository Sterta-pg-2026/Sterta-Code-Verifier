#include "linkedlist.h"
#include "node.h"
#include <cstdlib>
#include <iostream>
using namespace std;

template<class T>
linked_list<T>::linked_list() {
	head = NULL;
	tail = NULL;
}

template<class T>
void linked_list<T>::AddFirst(T* item) {
	if (head == NULL)
	{
		head = new Node<T>(item);
		tail = head;
		return;
	}
	Node<T> *newNode = new Node<T>(item);
	head->prev = newNode;
	newNode->next = head;
	head = newNode;
	counter++;
}

template<class T>
void linked_list<T>::AddLast(T* item) {
	if (tail == NULL) {
		tail = new Node<T>(item);
		head = tail;
		return;
	}
	Node<T>* newNode = new Node<T>(item);
	tail->next = newNode;
	newNode->prev = tail;
	tail = newNode;
	counter++;
}

template<class T>
Node<T>* linked_list<T>::GetFirst() {
	return head;
}

template<class T>
Node<T>* linked_list<T>::GetLast() {
	return tail;
}

template<class T>
Node<T>* linked_list<T>::GetAtPos(int pos) {
	Node<T>* tmp = head;
	while (tmp != NULL)
	{
		if (pos == 0)
		{
			return tmp;
		}
		pos--;
		tmp = tmp->next;
	}
	return NULL;
}

template<class T>
int linked_list<T>::getCounter()
{
	return counter;
}

template <class T>
void linked_list<T>::print() {
	if (head == NULL) {
		cout << "Lista jest pusta!" << endl;
	}
	else {
		Node<T>* current = head;
		while (current != NULL) {
			for (int i = 0; i < 8; i++)
			{
				current->value[i].selectors.printSelectors();
				current->value[i].attributes.printAttributes();		
			}
			current = current->next;
		}
	}
}
