#pragma once
class String {
public:
	char* tab;
	int x = 1;
public:
	String();
	void addLetter(char letter);
	void PrintString();
	void setString(char* word, int len);
	char* getTab();
	int getLen();
	void clearString();
	int convertStringNumberToInt();
	bool ifEqualString(String word);
	~String();
};