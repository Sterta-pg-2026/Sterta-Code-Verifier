#include <iostream>
using namespace std;
#define SIZET 8
#define ENTER 10
#define SPACE 32
typedef struct letter
{
    struct letter* prev;
    struct letter* next;
    char letter;
} String;
typedef struct selector
{
    struct selector* next;
    String* nameHead;
    String* nameTail;
} Selector;
typedef struct attribute
{
    struct attribute* next;
    String* nameHead;
    String* nameTail;
    String* valueHead;
    String* valueTail;
} Attribute;
typedef struct section
{
    Selector* selectorList;
    Attribute* attributeList;
} Section;
typedef struct node
{
    struct node* prev;
    struct node* next;
    Section* section[SIZET];
    int indexes[SIZET];
    int freeSlots;
} List;
///////////////////////// String /////////////////////////
String* createString()
{
    String* head = (String*)malloc(sizeof(String));
    String* tail = (String*)malloc(sizeof(String));
    head->prev = NULL;
    head->next = tail;
    head->letter = NULL;
    tail->prev = head;
    tail->next = NULL;
    tail->letter = NULL;
    return head;
}
void addToString(String* tail, char letter)
{
    String* newNode = (String*)malloc(sizeof(String));
    newNode->letter = letter;

    (tail->prev)->next = newNode;
    newNode->prev = tail->prev;
    newNode->next = tail;
    tail->prev = newNode;
}
void clearString(String* head, String* tail)
{
    String* tmp1, * tmp2;
    tmp1 = head->next;
    while (tmp1 != tail)
    {
        tmp2 = tmp1->next;
        free(tmp1);
        tmp1 = tmp2;
    }
    head->next = tail;
    tail->prev = head;
}
void freeString(String* head, String* tail)
{
    clearString(head, tail);
    free(head);
    free(tail);
}
void printString(String* head, String* tail)
{
    String* tmp = head->next;
    while (tmp != tail)
    {
        cout << tmp->letter;
        tmp = tmp->next;
    }
}
void copyString(String* head, String* tail, String* destinationTail, bool trimSpaces)
{
    String* tmp;
    if (trimSpaces == 1)
    {
        tmp = head->next;
        bool swapped = 0;
        while (tmp != tail && swapped != 1)
        {
            if (tmp->letter == SPACE)
                tmp->letter = 0;
            else
                swapped = 1;
            tmp = tmp->next;
        }
        tmp = tail->prev;
        swapped = 0;
        while (tmp != head && swapped != 1)
        {
            if (tmp->letter == SPACE)
                tmp->letter = 0;
            else
                swapped = 1;
            tmp = tmp->prev;
        }
    }
    tmp = head->next;
    while (tmp != tail)
    {
        if(trimSpaces == 0 || tmp->letter != 0)
            addToString(destinationTail, (tmp->letter));
        tmp = tmp->next;
    }
}
bool stringCompare(String* head1, String* tail1, String* head2, String* tail2)
{
    String* tmp1 = head1->next;
    String* tmp2 = head2->next;
    while (tmp1 != tail1 && tmp2 != tail2)
    {
        if (tmp1->letter != tmp2->letter)
            return false;
        tmp1 = tmp1->next;
        tmp2 = tmp2->next;
    }
    return (tmp1 == tail1 && tmp2 == tail2);
}
bool stringEmpty(String* head, String* tail)
{
    String* emptyHead = createString();
    String* emptyTail = emptyHead->next;
    bool result = stringCompare(head, tail, emptyHead, emptyTail);
    freeString(emptyHead, emptyTail);
    return result;
}
///////////////////////// Big List ///////////////////////
List* createList()
{
    List* head = (List*)malloc(sizeof(List));
    List* tail = (List*)malloc(sizeof(List));
    head->prev = NULL;
    head->next = tail;
    head->freeSlots = NULL;
    tail->prev = head;
    tail->next = NULL;
    tail->freeSlots = NULL;
    for (int i = 0; i < SIZET; i++)
    {
        head->section[i] = NULL;
        head->indexes[i] = 0;
        tail->section[i] = NULL;
        tail->indexes[i] = 0;
    }
    return head;
}
void addNode(List* tail)
{
    List* newNode = (List*)malloc(sizeof(List));
    for (int i = 0; i < SIZET; i++)
    {
        newNode->section[i] = NULL;
        newNode->indexes[i] = 0;
    }
    newNode->freeSlots = SIZET;

    (tail->prev)->next = newNode;
    newNode->prev = tail->prev;
    newNode->next = tail;
    tail->prev = newNode;
}
void freeNode(List* node)
{
    (node->prev)->next = node->next;
    (node->next)->prev = node->prev;
    free(node);
}
int countFreeSlots(List* head, List* tail)
{
    int freeSlots = 0;
    List* tmp = head->next;
    while (tmp != tail)
    {
        freeSlots += tmp->freeSlots;
        tmp = tmp->next;
    }
    return freeSlots;
}
int countSections(List* head, List* tail)
{
    int sections = 0;
    List* tmp = head->next;
    while (tmp != tail)
    {
        sections += (SIZET - (tmp->freeSlots));
        tmp = tmp->next;
    }
    return sections;
}
void fixIndexes(List* head, List* tail, int& maxIndex, int removedIndex)
{
    List* tmp = head->next;
    while (tmp != tail)
    {
        for (int i = 0; i < SIZET; i++)
        {
            if (tmp->indexes[i] > removedIndex)
                (tmp->indexes[i])--;
        }
        tmp = tmp->next;
    }
    maxIndex--;
}
///////////////////////// Attributes /////////////////////
Attribute* createAttribute(String* nameHead, String* nameTail, String* valueHead, String* valueTail)
{
    Attribute* attribute = (Attribute*)malloc(sizeof(Attribute));
    attribute->next = NULL;
    attribute->nameHead = nameHead;
    attribute->nameTail = nameTail;
    attribute->valueHead = valueHead;
    attribute->valueTail = valueTail;
    return attribute;
}
void addAttribute(Section* section, String* nameHead, String* nameTail, String* valueHead, String* valueTail)
{
    Attribute* attribute = createAttribute(nameHead, nameTail, valueHead, valueTail);
    Attribute* tmp = section->attributeList;
    bool duplicate = 0;
    while (tmp->next != NULL && duplicate != 1)
    {
        tmp = tmp->next;
        if (stringCompare(nameHead, nameTail, tmp->nameHead, tmp->nameTail) == 1)
        {
            duplicate = 1;
            clearString(tmp->valueHead, tmp->valueTail);
            copyString(valueHead, valueTail, tmp->valueTail, 1);
        }
    }
    if (duplicate == 0)
        tmp->next = attribute;
    else if (duplicate == 1)
    {
        freeString(attribute->nameHead, attribute->nameTail);
        freeString(attribute->valueHead, attribute->valueTail);
        free(attribute);
    }
}
void removeAttribute(Attribute* attributeList, Attribute* attribute)
{
    Attribute* tmp = attributeList;
    bool done = 0;
    while (tmp->next != NULL && done != 1)
    {
        if (tmp->next == attribute)
        {
            tmp->next = attribute->next;
            freeString(attribute->nameHead, attribute->nameTail);
            freeString(attribute->valueHead, attribute->valueTail);
            free(attribute);
            done = 1;
        }
        else
            tmp = tmp->next;
    }
}
void freeAttributeList(Attribute* attributeList)
{
    Attribute* tmp;
    while (attributeList->next != NULL)
    {
        Attribute* pretmp = attributeList;
        tmp = attributeList->next;
        while (tmp->next != NULL)
        {
            pretmp = tmp;
            tmp = tmp->next;
        }
        pretmp->next = NULL;
        freeString(tmp->nameHead, tmp->nameTail);
        freeString(tmp->valueHead, tmp->valueTail);
        free(tmp);
    }
    free(attributeList);
}
///////////////////////// Selectors //////////////////////
Selector* createSelector(String* nameHead, String* nameTail)
{
    Selector* selector = (Selector*)malloc(sizeof(Selector));
    selector->next = NULL;
    selector->nameHead = nameHead;
    selector->nameTail = nameTail;
    return selector;
}
void addSelector(Section* section, String* nameHead, String* nameTail)
{
    Selector* selector = createSelector(nameHead, nameTail);
    Selector* tmp = section->selectorList;
    bool duplicate = 0;
    while (tmp->next != NULL && duplicate != 1)
    {
        tmp = tmp->next;
        if (stringCompare(nameHead, nameTail, tmp->nameHead, tmp->nameTail) == 1)
            duplicate = 1;
    }
    if (duplicate == 0)
        tmp->next = selector;
    else if (duplicate == 1)
    {
        freeString(selector->nameHead, selector->nameTail);
        free(selector);
    }
}
void freeSelectorList(Selector* selectorList)
{
    Selector* tmp;
    while (selectorList->next != NULL)
    {
        Selector* pretmp = selectorList;
        tmp = selectorList->next;
        while (tmp->next != NULL)
        {
            pretmp = tmp;
            tmp = tmp->next;
        }
        pretmp->next = NULL;
        freeString(tmp->nameHead, tmp->nameTail);
        free(tmp);
    }
    free(selectorList);
}
///////////////////////// Sections ///////////////////////
Section* createSection(List* head, List* tail, int& maxIndex)
{
    Selector* selector = createSelector(NULL, NULL);
    Attribute* attribute = createAttribute(NULL, NULL, NULL, NULL);
    Section* section = (Section*)malloc(sizeof(Section));
    section->selectorList = selector;
    section->attributeList = attribute;
    
    List* tmp;
    if (countFreeSlots(head, tail) == 0)
    {
        addNode(tail);
        tmp = tail->prev;
    }
    else
        tmp = head->next;

    bool done = 0;
    while (tmp != tail && done != 1)
    {
        for (int i = 0; i < SIZET && done != 1; i++)
        {
            if (tmp->section[i] == NULL)
            {
                maxIndex++;
                tmp->section[i] = section;
                tmp->indexes[i] = maxIndex;
                (tmp->freeSlots)--;
                done = 1;
            }
        }
        tmp = tmp->next;
    }
    return section;
}
Section* needNewSection(List* head, List* tail, int& maxIndex, Section* section, bool& newSection)
{
    if (newSection == 1)
    {
        section = createSection(head, tail, maxIndex);
        newSection = 0;
    }
    return section;
}
void freeSection(Section* section)
{
    freeAttributeList(section->attributeList);
    freeSelectorList(section->selectorList);
    free(section);
}
void removeSection(List* head, List* tail, Section* section)
{
    List* tmp = head->next;
    bool done = 0;
    while (tmp != tail && done != 1)
    {
        for (int i = 0; i < SIZET && done != 1; i++)
        {
            if (tmp->section[i] == section)
            {
                (tmp->section[i]) = NULL;
                (tmp->indexes[i]) = 0;
                (tmp->freeSlots)++;
                freeSection(section);
                done = 1;
            }
            if (done == 1 && tmp->freeSlots == SIZET)
            {
                freeNode(tmp);
            }
        }
        tmp = tmp->next;
    }
}
///////////////////////// Command funcitons //////////////
void endProgram(List* head, List* tail, String* inputHead, String* inputTail, String* questionMarksHead, String* questionMarksTail, String* asterisksHead, String* asterisksTail)
{
    List* tmp1, * tmp2;
    tmp1 = head->next;
    while (tmp1 != tail)
    {
        tmp2 = tmp1->next;
        for (int i = 0; i < SIZET; i++)
        {
            if(tmp1->section[i] != NULL)
                freeSection(tmp1->section[i]);
        }
        free(tmp1);
        tmp1 = tmp2;
    }
    free(head);
    free(tail);
    freeString(inputHead, inputTail);
    freeString(questionMarksHead, questionMarksTail);
    freeString(asterisksHead, asterisksTail);
    exit(0);
}
Section* findSection(List* head, List* tail, int index)
{
    List* tmp = head->next;
    Section* section = NULL;
    bool done = 0;
    while (tmp != tail && done != 1)
    {
        for (int i = 0; i < SIZET && done != 1; i++)
        {
            if (tmp->indexes[i] == index)
            {
                section = tmp->section[i];
                done = 1;
            }
        }
        tmp = tmp->next;
    }
    return section;
}
int countAttributes(Section* section)
{
    Attribute* tmp = section->attributeList;
    int count = 0;
    while (tmp->next != NULL)
    {
        tmp = tmp->next;
        count++;
    }
    return count;
}
int countAttributesByName(List* head, List* tail, String* zHead, String* zTail)
{
    List* tmp = head->next;
    Attribute* attribute = NULL;
    int count = 0;
    while (tmp != tail)
    {
        for (int i = 0; i < SIZET; i++)
        {
            if (tmp->section[i] != NULL)
            {
                attribute = (tmp->section[i])->attributeList;
                while (attribute->next != NULL)
                {
                    attribute = attribute->next;
                    if (stringCompare(zHead, zTail, attribute->nameHead, attribute->nameTail) == 1)
                        count++;
                }
            }
        }
        tmp = tmp->next;
    }
    return count;
}
Attribute* findAttribute(Section* section, String* nHead, String* nTail)
{
    Attribute* tmp = section->attributeList;
    Attribute* attribute = NULL;
    bool done = 0;
    while (tmp->next != NULL && done != 1)
    {
        tmp = tmp->next;
        if (stringCompare(tmp->nameHead, tmp->nameTail, nHead, nTail) == 1)
        {
            attribute = tmp;
            done = 1;
        }
    }
    return attribute;
}
Attribute* findAttributeBySelector(List* head, List* tail, int maxIndex, String* zHead, String* zTail, String* nHead, String* nTail)
{
    Section* section = NULL;
    Selector* selector = NULL;
    Attribute* attribute = NULL;
    bool done = 0;
    bool selectorFound = 0;
    for (int i = maxIndex; i > 0 && selectorFound != 1; i--)
    {
        section = findSection(head, tail, i);
        if (section != NULL)
        {
            selector = section->selectorList;
            while (selector->next != NULL && selectorFound != 1)
            {
                selector = selector->next;
                if (stringCompare(zHead, zTail, selector->nameHead, selector->nameTail) == 1)
                {
                    selectorFound = 1;
                    attribute = section->attributeList;
                    while (attribute->next != NULL && done != 1)
                    {
                        attribute = attribute->next;
                        if (stringCompare(nHead, nTail, attribute->nameHead, attribute->nameTail) == 1)
                            done = 1;
                    }
                }
            }
        }
    }
    if (done == 0)
        attribute = NULL;
    return attribute;
}
int countSelectors(Section* section)
{
    Selector* tmp = section->selectorList;
    int count = 0;
    while (tmp->next != NULL)
    {
        tmp = tmp->next;
        count++;
    }
    return count;
}
int countSelectorsByName(List* head, List* tail, String* zHead, String* zTail)
{
    List* tmp = head->next;
    Selector* selector = NULL;
    int count = 0;
    while (tmp != tail)
    {
        for (int i = 0; i < SIZET; i++)
        {
            if (tmp->section[i] != NULL)
            {
                selector = (tmp->section[i])->selectorList;
                while (selector->next != NULL)
                {
                    selector = selector->next;
                    if (stringCompare(zHead, zTail, selector->nameHead, selector->nameTail) == 1)
                        count++;
                }
            }
        }
        tmp = tmp->next;
    }
    return count;
}
Selector* findSelector(Section* section, int index)
{
    Selector* tmp = section->selectorList;
    Selector* selector = NULL;
    bool done = 0;
    int current = 1;
    while (tmp->next != NULL && done != 1)
    {
        tmp = tmp->next;
        if (current == index)
        {
            selector = tmp;
            done = 1;
        }
        else
            current++;
    }
    return selector;
}
///////////////////////// Commands ///////////////////////
void caseNumberA(List* head, List* tail, String* inputTail, String* tmp, int i, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        if (tmp->letter == '?' && tmp->next == inputTail)
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                int count = countAttributes(section);
                if (count != 0)
                    cout << i << ",A,? == " << count << endl;
            }
            done = 1;
        }
        else
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                String* nHead = createString();
                String* nTail = nHead->next;
                while (tmp != inputTail)
                {
                    addToString(nTail, tmp->letter);
                    tmp = tmp->next;
                }
                Attribute* attribute = findAttribute(section, nHead, nTail);
                if (attribute != NULL)
                {
                    cout << i << ",A,";
                    printString(nHead, nTail);
                    cout << " == ";
                    printString(attribute->valueHead, attribute->valueTail);
                    cout << endl;
                }
                freeString(nHead, nTail);
            }
            done = 1;
        }
    }
    else
        error = 1;
}
void caseNumberD(List* head, List* tail, int& maxIndex, String* inputTail, String* tmp, int i, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        if (tmp->letter == '*' && tmp->next == inputTail)
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                removeSection(head, tail, section);
                fixIndexes(head, tail, maxIndex, i);
                cout << i << ",D,* == deleted" << endl;
            }
            done = 1;
        }
        else
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                String* nHead = createString();
                String* nTail = nHead->next;
                while (tmp != inputTail)
                {
                    addToString(nTail, tmp->letter);
                    tmp = tmp->next;
                }
                Attribute* attribute = findAttribute(section, nHead, nTail);
                if (attribute != NULL)
                {
                    removeAttribute(section->attributeList, attribute);
                    if (countAttributes(section) == 0)
                    {
                        removeSection(head, tail, section);
                        fixIndexes(head, tail, maxIndex, i);
                    }
                    cout << i << ",D,";
                    printString(nHead, nTail);
                    cout << " == deleted" << endl;
                }
                freeString(nHead, nTail);
            }
            done = 1;
        }
    }
    else
        error = 1;
}
void caseNumberS(List* head, List* tail, String* inputTail, String* tmp, int i, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        if (tmp->letter == '?' && tmp->next == inputTail)
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                int count = countSelectors(section);
                cout << i << ",S,? == " << count << endl;
            }
            done = 1;
        }
        else
        {
            Section* section = findSection(head, tail, i);
            if (section != NULL)
            {
                int j = 0;
                while (tmp != inputTail)
                {
                    j = j * 10 + (tmp->letter - '0');
                    tmp = tmp->next;
                }
                Selector* selector = findSelector(section, j);
                if (selector != NULL)
                {
                    cout << i << ",S," << j << " == ";
                    printString(selector->nameHead, selector->nameTail);
                    cout << endl;
                }
            }
            done = 1;
        }
    }
    else
        error = 1;
}
void caseNumber(List* head, List* tail, int& maxIndex, String* inputTail, String* tmp, bool& done, bool& error)
{
    int i = 0;
    while (tmp->letter != ',' && tmp->next != inputTail)
    {
        if (tmp->letter >= '0' && tmp->letter <= '9')
        {
            i = i * 10 + (tmp->letter - '0');
            tmp = tmp->next;
        }
        else
            error = 1;
    }
    if (error != 1)
    {
        tmp = tmp->next;
        if (tmp->letter == 'A')
        {
            caseNumberA(head, tail, inputTail, tmp, i, done, error);
        }
        else if (tmp->letter == 'D')
        {
            caseNumberD(head, tail, maxIndex, inputTail, tmp, i, done, error);
        }
        else if (tmp->letter == 'S')
        {
            caseNumberS(head, tail, inputTail, tmp, i, done, error);
        }
        else
            error = 1;
    }
}
void caseLetterA(List* head, List* tail, String* tmp, String* zHead, String* zTail, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        if (tmp->letter == '?')
        {
            int count = countAttributesByName(head, tail, zHead, zTail);
            printString(zHead, zTail);
            cout << ",A,? == " << count << endl;
            done = 1;
        }
        else
            error = 1;
    }
    else
        error = 1;
}
void caseLetterE(List* head, List* tail, int maxIndex, String* inputTail, String* tmp, String* zHead, String* zTail, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        String* nHead = createString();
        String* nTail = nHead->next;
        while (tmp != inputTail)
        {
            addToString(nTail, tmp->letter);
            tmp = tmp->next;
        }
        Attribute* attribute = findAttributeBySelector(head, tail, maxIndex, zHead, zTail, nHead, nTail);
        if (attribute != NULL)
        {
            printString(zHead, zTail);
            cout << ",E,";
            printString(nHead, nTail);
            cout << " == ";
            printString(attribute->valueHead, attribute->valueTail);
            cout << endl;
        }
        done = 1;
        freeString(nHead, nTail);
    }
    else
        error = 1;
}
void caseLetterS(List* head, List* tail, String* inputTail, String* tmp, String* zHead, String* zTail, bool& done, bool& error)
{
    tmp = tmp->next;
    if (tmp->letter == ',')
    {
        tmp = tmp->next;
        if (tmp->letter == '?' && tmp->next == inputTail)
        {
            int count = countSelectorsByName(head, tail, zHead, zTail);
            printString(zHead, zTail);
            cout << ",S,? == " << count << endl;
            done = 1;
        }
        else
            error = 1;
    }
    else
        error = 1;
}
void caseLetter(List* head, List* tail, int maxIndex, String* inputTail, String* tmp, bool& done, bool& error)
{
    String* zHead = createString();
    String* zTail = zHead->next;
    while (tmp->letter != ',' && tmp->next != inputTail)
    {
        addToString(zTail, tmp->letter);
        tmp = tmp->next;
    }
    tmp = tmp->next;
    if (tmp->letter == 'A')
    {
        caseLetterA(head, tail, tmp, zHead, zTail, done, error);
    }
    else if (tmp->letter == 'E')
    {
        caseLetterE(head, tail, maxIndex, inputTail, tmp, zHead, zTail, done, error);
    }
    else if (tmp->letter == 'S')
    {
        caseLetterS(head, tail, inputTail, tmp, zHead, zTail, done, error);
    }
    else
        error = 1;
    freeString(zHead, zTail);
}
void parseCommand(List* head, List* tail, int& maxIndex, String* inputHead, String* inputTail, String* asterisksHead, String* asterisksTail, bool& nowCSS)
{
    if (stringCompare(inputHead, inputTail, asterisksHead, asterisksTail) == 1)
        nowCSS = 1;
    else
    {
        String* tmp = inputHead->next;
        if (tmp != inputTail)
        {
            bool done = 0;
            bool error = 0;
            if (tmp->letter == '?' && tmp->next == inputTail)
            {
                cout << "? == " << countSections(head, tail) << endl;
                done = 1;
            }
            if (tmp->letter >= '0' && tmp->letter <= '9' && done != 1)
            {
                caseNumber(head, tail, maxIndex, inputTail, tmp, done, error);
            }
            if (done != 1 && error != 1)
            {
                caseLetter(head, tail, maxIndex, inputTail, tmp, done, error);
            }
        }
    }
    clearString(inputHead, inputTail);
}
void commandLoop(List* head, List* tail, int& maxIndex, String* inputHead, String* inputTail, int& c, String* questionMarksHead, String* questionMarksTail, String* asterisksHead, String* asterisksTail)
{
    clearString(inputHead, inputTail);
    bool nowCSS = 0;
    while (nowCSS != 1)
    {
        c = getchar();
        if (c < SPACE)
        {
            if (c == ENTER)
            {
                parseCommand(head, tail, maxIndex, inputHead, inputTail, asterisksHead, asterisksTail, nowCSS);
            }
            else if (c == EOF)
            {
                parseCommand(head, tail, maxIndex, inputHead, inputTail, asterisksHead, asterisksTail, nowCSS);
                endProgram(head, tail, inputHead, inputTail, questionMarksHead, questionMarksTail, asterisksHead, asterisksTail);
            }
            else
                continue;
        }
        else
            addToString(inputTail, (char)c);
    }
}
///////////////////////// CSS ////////////////////////////
void caseSelector(Section* section, String* inputHead, String* inputTail)
{
    String* nameHead = createString();
    String* nameTail = nameHead->next;
    copyString(inputHead, inputTail, nameTail, 1);
    clearString(inputHead, inputTail);
    addSelector(section, nameHead, nameTail);
}
void caseAttribute(Section* section, String* inputHead, String* inputTail, int& c, bool& newSection)
{
    String* nameHead = createString();
    String* nameTail = nameHead->next;
    copyString(inputHead, inputTail, nameTail, 1);
    clearString(inputHead, inputTail);

    bool done = 0;
    while (done != 1)
    {
        c = getchar();
        if (c < SPACE)
            continue;
        switch (c)
        {
        case ';':
        {
            String* valueHead = createString();
            String* valueTail = valueHead->next;
            copyString(inputHead, inputTail, valueTail, 1);
            clearString(inputHead, inputTail);
            addAttribute(section, nameHead, nameTail, valueHead, valueTail);
            done = 1;
            break;
        }
        case '}':
        {
            String* valueHead = createString();
            String* valueTail = valueHead->next;
            copyString(inputHead, inputTail, valueTail, 1);
            clearString(inputHead, inputTail);
            addAttribute(section, nameHead, nameTail, valueHead, valueTail);
            done = 1;
            newSection = 1;
            break;
        }
        default:
        {
            addToString(inputTail, (char)c);
            break;
        }
        }
    }
}
void programLoop(List* head, List* tail, int& maxIndex, Section* section, String* inputHead, String* inputTail, int& c)
{
    String* asterisksHead = createString();
    String* asterisksTail = asterisksHead->next;
    String* questionMarksHead = createString();
    String* questionMarksTail = questionMarksHead->next;
    for (int i = 0; i < 4; i++)
    {
        addToString(asterisksTail, '*');
        addToString(questionMarksTail, '?');
    }
    bool newSection = 1;
    bool nowAttribute = 0;
    while (true)
    {
        if (stringCompare(inputHead, inputTail, questionMarksHead, questionMarksTail) == 1)
            commandLoop(head, tail, maxIndex, inputHead, inputTail, c, questionMarksHead, questionMarksTail, asterisksHead, asterisksTail);
        c = getchar();
        if (c < SPACE)
        {
            if (c == EOF)
                endProgram(head, tail, inputHead, inputTail, questionMarksHead, questionMarksTail, asterisksHead, asterisksTail);
            else
                continue;
        }
        else
        {
            switch (c)
            {
            case ',':
            {
                section = needNewSection(head, tail, maxIndex, section, newSection);
                caseSelector(section, inputHead, inputTail);
                break;
            }
            case '{':
            {
                if (stringEmpty(inputHead, inputTail) != 1)
                {
                    section = needNewSection(head, tail, maxIndex, section, newSection);
                    caseSelector(section, inputHead, inputTail);
                }
                nowAttribute = 1;
                break;
            }
            case ':':
            {
                if (nowAttribute == 1)
                {
                    section = needNewSection(head, tail, maxIndex, section, newSection);
                    caseAttribute(section, inputHead, inputTail, c, newSection);
                }
                else
                    addToString(inputTail, (char)c);
                break;
            }
            case '}':
            {
                newSection = 1;
                nowAttribute = 0;
                break;
            }
            default:
            {
                addToString(inputTail, (char)c);
                break;
            }
            }
        }
    }
}
///////////////////////// Main ///////////////////////////
int main()
{
    int maxIndex = 0;
    List* head = createList();
    List* tail = head->next;
    Section* section = NULL;
    String* inputHead = createString();
    String* inputTail = inputHead->next;
    int c = 0;
    programLoop(head, tail, maxIndex, section, inputHead, inputTail, c);
}