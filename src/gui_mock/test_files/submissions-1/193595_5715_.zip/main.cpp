#include <iostream>
#include <conio.h>
#include <stdlib.h>
using namespace std;

const int size_of_table = 8;
const int size_of_char = 1000;

size_t my_strlen(const char* str) {
    size_t len = 0;
    while (*str != '\0') {
        len++;
        str++;
    }
    return len;
}

void* my_memset(void* ptr, int value, size_t num) {
    char* p = (char*) ptr;
    while (num-- > 0) {
        *p++ = value;
    }
    return ptr;
}

char* my_strcpy(char* dest, const char* src) {
    char* p = dest;
    while ((*p++ = *src++) != '\0');
    return dest;
}

struct Atributes {
    char* name_atributes;
    char* value;
    Atributes* next;
};

struct Selectors {
    char* name_selectors;
    Selectors* next;
};

struct Block {
  struct Selectors* head1;
  struct Atributes* head2;
  int number_of_filled_Selectors = 0;
  int number_of_filled_Atributes = 0;
};

struct Node{
  Block table[size_of_table];
  Node* previous;
  Node* next;
  int number_of_filled_Block = 0;
};

void add_selector(Block* block, const char* name) {
    Selectors* new_selector = new Selectors;
    new_selector->name_selectors = new char[size_of_char];
    my_strcpy(new_selector->name_selectors, name);
    new_selector->next = nullptr;

    if (block->head1 == nullptr) {
        block->head1 = new_selector;
    }
    else {
        Selectors* current = block->head1;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = new_selector;
    }

    block->number_of_filled_Selectors++;
}
void add_block(Node* node){
    Block* new_block = &(node->table[node->number_of_filled_Block]);
    new_block->head1 = nullptr;
    new_block->head2 = nullptr;
    new_block->number_of_filled_Atributes = 0;
    new_block->number_of_filled_Selectors = 0;
    node->number_of_filled_Block++;
}
void add_attribute(Block* block, const char* name, const char* value) {
    Atributes* new_attribute = new Atributes;
    new_attribute->value = new char[size_of_char];
    my_strcpy(new_attribute->value, value);
    new_attribute->name_atributes = new char[size_of_char];
    my_strcpy(new_attribute->name_atributes, name);
    new_attribute->next = nullptr;
    bool create_new = true;

    Atributes* current_atributes = block->head2;
    int strlen_atribute = my_strlen(new_attribute->name_atributes);
    bool maybe_equal_name = false;


    for(int i = 0; i < block->number_of_filled_Atributes; i++){
      if(strlen_atribute == my_strlen(current_atributes->name_atributes)){
        maybe_equal_name = true;

      }
      
      if(maybe_equal_name){
        for(int j = 0; j < strlen_atribute; j++){
          if(new_attribute->name_atributes[j] != current_atributes->name_atributes[j]){
            break;
          }
          if(j == strlen_atribute-1){
            current_atributes->value = new_attribute->value;
            create_new = false;
          }
        }
      }
      current_atributes = current_atributes->next;
      continue;
    }


    if(create_new){
      if (block->head2 == nullptr) {
          block->head2 = new_attribute;
      }
      else {
          Atributes* current = block->head2;
          while (current->next != nullptr) {
              current = current->next;
          }
          current->next = new_attribute;
      }

      block->number_of_filled_Atributes++;
    }
}
void add_node(Node* current_node, Node* tail) {
    Node* new_node = new Node;
    new_node->previous = current_node;
    new_node->next = nullptr;
    current_node->next = new_node;
    tail = new_node;
}


int main(){
  Node* first_node = new Node;
  Node* current_node = first_node;
  int number_of_nodes = 1;
  bool keep_going = true;
  bool keep_loading = true;
  bool bool_commands = false;
  Node* tail = first_node;
  int number_of_removes = 0;
    while(keep_loading){
    char ch = getchar();
    if(ch == EOF){
      exit(0);
    }
    while (ch < 33 ){
      ch = getchar();
      if(ch == EOF){
        exit(0);
      }
    }


    if(ch == '?'){
      char possible_commands[size_of_char];
      my_memset(possible_commands, 0, size_of_char);
      cin.getline(possible_commands, size_of_char);
      if(possible_commands[0] == '?' && possible_commands[1] == '?' && possible_commands[2] == '?'){
        bool_commands = true;
      }
    }
    else{
    if(current_node->number_of_filled_Block == 8){
        add_node(current_node, tail);
        current_node = current_node->next;
        tail = current_node;
        current_node->number_of_filled_Block = 0;
        number_of_nodes++;
    }
    bool now_atributes = false;
    add_block(current_node);
    char temporary_table_chars[size_of_char];
    char temporary_table_selector[size_of_char];
    my_memset(temporary_table_selector, 0, size_of_char);
    (&current_node->table[current_node->number_of_filled_Block-1])->head1 = nullptr;
    (&current_node->table[current_node->number_of_filled_Block-1])->head2 = nullptr;

    if(ch != '{'){
    cin.getline(temporary_table_chars, size_of_char, '{');
    }
    int number = 0;
    int number_of_temporary_filled_chars = 0;
    if(ch != '\n' && ch != '\t'){
      temporary_table_selector[0] = ch;
      number_of_temporary_filled_chars = 1;
    }
    for (int i = 0; i <= my_strlen(temporary_table_chars) + number; i++) {
      if(temporary_table_chars[i] == '\n' || temporary_table_chars[i] == '\t' || temporary_table_chars[i] == ' '){
        continue;
      }
      if ((temporary_table_chars[i] != ',' )&& (i != my_strlen(temporary_table_chars)+number)) {
          temporary_table_selector[number_of_temporary_filled_chars] = temporary_table_chars[i];
          number_of_temporary_filled_chars++;
      }
      else if((temporary_table_chars[i] != ',' )&& (i = my_strlen(temporary_table_chars)+number)){
        add_selector(&current_node->table[current_node->number_of_filled_Block-1],temporary_table_selector);
        break;
      }
      else{
        if(ch != '{'){
        add_selector(&current_node->table[current_node->number_of_filled_Block-1],temporary_table_selector);
        }
        number_of_temporary_filled_chars = 0;
        my_memset(temporary_table_selector, 0, size_of_char);
        i++;
        number++;
      }
    }
    now_atributes = true;
    Selectors* current_selector = (&current_node->table[current_node->number_of_filled_Block-1])->head1;

    if(now_atributes){
      char temporary_table_chars_2[size_of_char];
      char temporary_table_atributes_name[size_of_char];
      char temporary_table_atributes_values[size_of_char];
      my_memset(temporary_table_atributes_name, 0, size_of_char);
      my_memset(temporary_table_atributes_values, 0, size_of_char);

      cin.getline(temporary_table_chars_2, size_of_char, '}');
      int number_2 = 0;
      int number_of_temporary_filled_chars_2 = 0;
      bool now_name = true;

      for (int i = 0; i <= my_strlen(temporary_table_chars_2) + number_2; i++) {
        if(temporary_table_chars_2[i] == '\n' || temporary_table_chars_2[i] == '\t' || temporary_table_chars_2[i] == '\0'){
          continue;
        }
        else if ((now_name == true) && (temporary_table_chars_2[i] != ':' )&& (i != my_strlen(temporary_table_chars_2)+number_2)) {
            temporary_table_atributes_name[number_of_temporary_filled_chars_2] = temporary_table_chars_2[i];
            number_of_temporary_filled_chars_2++;
        }
        else if ((now_name == false) && (temporary_table_chars_2[i] != ';' )) {
            temporary_table_atributes_values[number_of_temporary_filled_chars_2] = temporary_table_chars_2[i];
            number_of_temporary_filled_chars_2++;
        }
        else if ((now_name == true) && (temporary_table_chars_2[i] == ':' )&& (i != my_strlen(temporary_table_chars_2)+number_2)) {
          i++;
          number_2++;
          now_name = false;
          number_of_temporary_filled_chars_2 = 0;
        }
        else if ((temporary_table_chars_2[i] == ';' )&& (i != my_strlen(temporary_table_chars_2)+number_2)) {
          add_attribute(&current_node->table[current_node->number_of_filled_Block-1],temporary_table_atributes_name, temporary_table_atributes_values);
          number_of_temporary_filled_chars_2 = 0;
          my_memset(temporary_table_atributes_values, 0, size_of_char);
          my_memset(temporary_table_atributes_name, 0, size_of_char);
          i++;
          number_2++;
          now_name = true;
        }
      }

      Atributes* current_atribute = (&current_node->table[current_node->number_of_filled_Block-1])->head2;
      
      
    
      
      
      now_atributes = false;
      }
      
    
    }
     while(bool_commands){
      char ch = getchar();
      if(ch == EOF){
        exit(0);
      }
      if(ch == '\n'){
        ch = getchar();
        if(ch == EOF){
          exit(0);
        }
        if(ch == '\n'){
          ch = getchar();
          if(ch == EOF){
          exit(0);
        }
        }
      }
      int number = 0;
      char commands[size_of_char];
      my_memset(commands, 0, size_of_char);
      char quite_temporary_commands[size_of_char];
      my_memset(quite_temporary_commands, 0, size_of_char);
      char commands_2_letter[size_of_char];
      my_memset(commands_2_letter, 0, size_of_char);
      char commands_1[size_of_char];
      my_memset(commands_1, 0, size_of_char);
      char commands_3_letter[size_of_char];
      my_memset(commands_3_letter, 0, size_of_char);
      if(ch != '\n' || ch != '\t'){
        commands_1[0] = ch;
      }
      cin.getline(quite_temporary_commands, size_of_char);
      for(int a = 1; a <= my_strlen(quite_temporary_commands); a++){
        commands_1[a] = quite_temporary_commands[a-1];
      }
      bool letter_1 = true;
      bool letter_2 = false;
      bool letter_3 = false;
      if(my_strlen(commands_1)>4){
        for(int i = 0; i < my_strlen(commands_1);i++){
          if(commands_1[i] != ',' && letter_1 == true){
            commands[i] = commands_1[i];          
          }
          else if(letter_1 == true && commands_1[i] == ','){
            letter_1 = false;
            letter_2 = true;
          }
          else if(commands_1[i] != ',' && letter_2 == true){
              commands_2_letter[i-my_strlen(commands)-1] = commands_1[i];     
          }
          else if(letter_2 == true && commands_1[i] == ','){
            letter_2 = false;
            letter_3 = true;
          }
          else if(commands_1[i] != ',' && letter_3 == true){
              commands_3_letter[i-my_strlen(commands)-my_strlen(commands_2_letter)-2] = commands_1[i];     
          }
          else if(letter_3 == true && commands_1[i] == ','){
            letter_3 = false;
          }
        }
      }
      
      
      
      if(commands_1[0] == '*' && commands_1[1] == '*' && commands_1[2] == '*' && commands_1[3] == '*'){
        bool_commands = false;
        keep_loading = true;
        continue;
      }

      else if(commands_1[0] == '?'){
          int nr_of_section = 0;
          Node* current_node = first_node;
          nr_of_section = 0;
          for(int i = 1; i <= number_of_nodes; i++){
            nr_of_section += current_node->number_of_filled_Block;
            current_node = current_node->next;
          }
          cout << "?" << " == " << nr_of_section << endl;
          continue;
      }
      else if(commands_1[0]>47 && commands_1[0] < 58){
        number = 0;
        if(commands[0] == '\n'){
          for (int i = 1; i < my_strlen(commands); i++) {
            number = number * 10 + (commands[i] - '0');
        }
        }
        else{
        for (int i = 0; i < my_strlen(commands); i++) {
            number = number * 10 + (commands[i] - '0');
        }
        }

        if(commands_2_letter[0] == 'S'){
          if(commands_3_letter[0] == '?'){
              int temporary_number = 0;
              int temporary_number_2 = 0;
              temporary_number = number/size_of_table;
              temporary_number_2 = number-(8*temporary_number);
              if(number%size_of_table == 0){
                temporary_number_2 = size_of_table;
                temporary_number = number/size_of_table-1;
              }
              if(number_of_nodes < temporary_number){
                continue;
              }
              Node* current_node = first_node;
              for (int i = 0; i < temporary_number; i++) {
                  current_node = current_node->next;
              }
              if(current_node->number_of_filled_Block < temporary_number_2){
                continue;
              }
              Block* current_block = &(current_node->table[temporary_number_2-1]);
              cout << number << ",S,? == " << current_block->number_of_filled_Selectors << endl;

              continue;
            
          }
          else if(commands_3_letter[0]>47 && commands_3_letter[0] < 58){
            int number_2 = 0;
            for (int j = 0; j < my_strlen(commands_3_letter); j++) {
                number_2 = number_2 * 10 + (commands_3_letter[j] - '0');
            }

            int temporary_number = 0;
            int temporary_number_2 = 0;
            int temporary_number_3 = number_2%8;
            temporary_number = number/size_of_table;
            temporary_number_2 = number-(size_of_table*temporary_number);
            if(number_of_nodes < temporary_number){
              continue;
            }
            Node* current_node = first_node;
            for (int i = 0; i < temporary_number; i++) {
                current_node = current_node->next;
            }
            if(current_node->number_of_filled_Block < temporary_number_2){
              continue;
            }
            Block* current_block = &(current_node->table[temporary_number_2-1]);
            Selectors* current_selector = (current_block)->head1;
            for (int i = 1; i < temporary_number_3; i++) {
                current_selector = current_selector->next;
            }
            if(current_block->number_of_filled_Selectors<number_2){
            continue;
            }
            else{
            cout << number << ",S," << number_2 << " == " << current_selector->name_selectors << endl;
            }
          }

        }
        else if(commands_2_letter[0] == 'A'){
          if(commands_3_letter[0] == '?'){
            int temporary_number = 0;
            int temporary_number_2 = 0;
            temporary_number = number/size_of_table;
            temporary_number_2 = number-(8*temporary_number);
            if(number%size_of_table == 0){
                temporary_number_2 = size_of_table;
                temporary_number = number/size_of_table-1;
              }
            if(number_of_nodes < temporary_number){
              continue;
            }
            Node* current_node = first_node;
            for (int i = 0; i < temporary_number; i++) {
                current_node = current_node->next;
            }
            if(current_node->number_of_filled_Block < temporary_number_2){
              continue;
            }
            Block* current_block = &(current_node->table[temporary_number_2-1]);
            cout << number << ",A,? == " << current_block->number_of_filled_Atributes << endl;

            continue;
          }
          else{
            int temporary_number = 0;
            int temporary_number_2 = 0;
            temporary_number = number/size_of_table;
            temporary_number_2 = number-(8*temporary_number);
            if(number%size_of_table == 0){
                temporary_number_2 = size_of_table;
                temporary_number = number/size_of_table-1;
            }
            if(number_of_nodes < temporary_number){
               continue;
            }
            Node* current_node = first_node;
            for (int i = 0; i < temporary_number; i++) {
                current_node = current_node->next;
            }
            if(current_node->number_of_filled_Block < temporary_number_2){
              continue;
            }
            bool proper_value = false;
            int value = 0;
            Block* current_block = &(current_node->table[temporary_number_2-1]);
            Atributes* current_atributes_value = current_block->head2;
            for(int k = 0; k < current_block->number_of_filled_Atributes; k++){
              if(my_strlen(commands_3_letter) == my_strlen(current_atributes_value->name_atributes)){
                proper_value = true;

              }
              if(proper_value){
                for(int m = 0; m < my_strlen(commands_3_letter); m++){
                  if(commands_3_letter[m] != current_atributes_value->name_atributes[m]){
                    break;
                  }
                  if(m == my_strlen(commands_3_letter)-1){
                    cout << number << "," << "A," << commands_3_letter << " == " << current_atributes_value->value << endl;
                  }
                }
              }
              current_atributes_value = current_atributes_value->next;
            }
            
            
            continue;
          }
          
        }
        else if(commands_2_letter[0] == 'D'){
          if(commands_3_letter[0] == '*'){
            int temporary_number = 0;
            int temporary_number_2 = 0;
            temporary_number = number/size_of_table;
            temporary_number_2 = number-(8*temporary_number);
            if(number%size_of_table == 0){
                temporary_number_2 = size_of_table;
                temporary_number = number/size_of_table-1;
            }
            if(number_of_nodes < temporary_number){
               continue;
            }
            Node* current_node = first_node;
            for (int i = 0; i < temporary_number; i++) {
                current_node = current_node->next;
            }
            if(current_node->number_of_filled_Block < temporary_number_2){
              continue;
            }
            bool proper_value = false;
            int value = 0;
            Block* current_block = &(current_node->table[temporary_number_2-1]);
            Atributes* current_atributes_value = current_block->head2;
            Selectors* current_selector = current_block->head1;
            for(int v = 0; v < current_block->number_of_filled_Atributes; v++){
              for(int a = 0; a < my_strlen(current_atributes_value->name_atributes); a++){
                current_atributes_value->name_atributes[a] = '\n';
              }
              for(int b = 0; b < my_strlen(current_atributes_value->value); b++){
                current_atributes_value->value[b] = '\n';
              }
              current_block->number_of_filled_Atributes--;
              current_atributes_value = current_atributes_value->next;
            }
            for(int x = 0; x < current_block->number_of_filled_Selectors; x++){
              for(int s = 0; s < my_strlen(current_selector->name_selectors); s++){
                current_selector->name_selectors[s] = '\n';
              }
              current_selector = current_selector->next;
              current_block->number_of_filled_Selectors--;

            }
            current_node->number_of_filled_Block--;
            number_of_removes++;
            cout << number << ",D,* == deleted" << endl;


            continue;
          }
          else{
            int temporary_number = 0;
            int temporary_number_2 = 0;
            temporary_number = number/size_of_table;
            temporary_number_2 = number-(8*temporary_number);
            if(number%size_of_table == 0){
                temporary_number_2 = size_of_table;
                temporary_number = number/size_of_table-1;
            }
            if(number_of_nodes < temporary_number){
               continue;
            }
            Node* current_node = first_node;
            for (int i = 0; i < temporary_number; i++) {
                current_node = current_node->next;
            }
            if(current_node->number_of_filled_Block < temporary_number_2){
              continue;
            }
            bool proper_value = false;
            int value = 0;
            Block* current_block = &(current_node->table[temporary_number_2-1]);
            Atributes* current_atributes_value = current_block->head2;
            Selectors* current_selector = current_block->head1;
            bool remove_section = false;
            for(int k = 0; k < current_block->number_of_filled_Atributes; k++){
              if(my_strlen(commands_3_letter) == my_strlen(current_atributes_value->name_atributes)){
                proper_value = true;

              }
              if(proper_value){
                for(int m = 0; m < my_strlen(commands_3_letter); m++){
                  if(commands_3_letter[m] != current_atributes_value->name_atributes[m]){
                    break;
                  }
                  if(m == my_strlen(commands_3_letter)-1){
                    for(int a = 0; a < my_strlen(current_atributes_value->name_atributes); a++){
                      current_atributes_value->name_atributes[a] = '\n';
                    }
                    for(int b = 0; b < my_strlen(current_atributes_value->value); b++){
                      current_atributes_value->value[b] = '\n';
                    }
                    current_block->number_of_filled_Atributes--;
                    if(current_block->number_of_filled_Atributes == 0){
                      remove_section = true;
                       number_of_removes++;
                    }

                  }
                }
              }
              current_atributes_value = current_atributes_value->next;
            }
            if(remove_section == true){
              for(int x = 0; x < current_block->number_of_filled_Selectors; x++){
              for(int s = 0; s < my_strlen(current_selector->name_selectors); s++){
                current_selector->name_selectors[s] = '\n';
              }
              current_selector = current_selector->next;
              current_block->number_of_filled_Selectors--;
            }
            }
            current_node->number_of_filled_Block--;
            cout << number << ",D," << commands_3_letter << " == deleted" << endl;
            
            
            continue;

          }
          
        }

      }
      else{
        if(commands_2_letter[0] == 'A'){
          if(commands_3_letter[0] == '?'){
            int number_occurs_atributes = 0;
            Node* current_node = first_node;
            for(int b = 0; b < number_of_nodes+number_of_removes; b++){
                for(int c = 0; c < current_node->number_of_filled_Block ; c++){
                  bool proper_value = false;
                  int value = 0;
                  Block* current_block = &(current_node->table[c]);
                  Atributes* current_atributes_value = current_block->head2;
                  for(int q = 0; q < current_block->number_of_filled_Atributes; q++){
                    if(my_strlen(commands) == my_strlen(current_atributes_value->name_atributes)){
                      proper_value = true;

                    }
                    if(proper_value){
                      for(int w = 0; w < my_strlen(commands); w++){
                        if(commands[w] != current_atributes_value->name_atributes[w]){
                          break;
                        }
                        if(w == my_strlen(commands)-1){
                          number_occurs_atributes++;
                        }
                      }
                    }
                    current_atributes_value = current_atributes_value->next;
                  }
                  

                }
                if(current_node->next != nullptr){
                current_node = current_node->next;
                }

            }

            cout << commands << ",A,? == " << number_occurs_atributes << endl;
            continue;

          }
        }
        else if(commands_2_letter[0] == 'S'){
          if(commands_3_letter[0] == '?'){
            int number_occurs_selectors = 0;
            Node* current_node = first_node;
            for(int b = 0; b < number_of_nodes+number_of_removes; b++){
                for(int c = 0; c < current_node->number_of_filled_Block; c++){
                  bool proper_value = false;
                  Block* current_block = &(current_node->table[c]);
                  Selectors* current_selectors_value = current_block->head1;
                  for(int q = 0; q < current_block->number_of_filled_Selectors; q++){
                    if(my_strlen(commands) == my_strlen(current_selectors_value->name_selectors)){
                      proper_value = true;
                    }
                    if(proper_value){
                      for(int w = 0; w < my_strlen(commands); w++){
                        if(commands[w] != current_selectors_value->name_selectors[w]){
                          proper_value = false;
                          break;
                        }
                        if(w == my_strlen(commands)-1){
                          number_occurs_selectors++;
                          proper_value = false;
                        }
                      }
                    }
                    current_selectors_value = current_selectors_value->next;
                  }
                  

                }
                if(current_node->next != nullptr){
                current_node = current_node->next;
                }

            }

            cout << commands << ",S,? == " << number_occurs_selectors << endl;
            continue;
            
          }
        }
        else if(commands_2_letter[0] == 'E'){
            int number_occurs_selectors = 0;
            int nr_new_nodes = 0;
            int nr_of_table = 0;
            //tutaj
            Node* current_node = tail;
            bool found = false;
            char n_value[size_of_char];
            my_memset(n_value, 0, size_of_char);
            for(int b = 0; b < number_of_nodes; b++){
                for(int c = 0; c < current_node->number_of_filled_Block; c++){
                  bool proper_value = false;
                  int value = 0;
                  Block* current_block = &(current_node->table[c]);
                  Selectors* current_selectors_value = current_block->head1;
                  for(int q = 0; q < current_block->number_of_filled_Selectors; q++){
                    if(my_strlen(commands) == my_strlen(current_selectors_value->name_selectors)){
                      proper_value = true;

                    }
                    if(proper_value){
                      for(int w = 0; w < my_strlen(commands); w++){
                        if(commands[w] != current_selectors_value->name_selectors[w]){
                          break;
                        }
                        if(w == my_strlen(commands)-1){
                          Node* current_node_2 = tail;
                          nr_new_nodes = nr_new_nodes + b;
                          nr_of_table = nr_of_table+c;
                          for(int t = 0; t < nr_new_nodes; t++){
                            if(current_node_2->previous != nullptr){
                            current_node_2 = current_node_2->previous;
                          }
                          }
                          Block* current_block = &(current_node_2->table[c]);
                          bool proper_value_2 = false;
                          Atributes* current_atributes_value = current_block->head2;
                          for(int k = 0; k < current_block->number_of_filled_Atributes; k++){
                            if(my_strlen(commands_3_letter) == my_strlen(current_atributes_value->name_atributes)){
                              proper_value_2 = true;

                            }
                            if(proper_value_2){
                              for(int m = 0; m < my_strlen(commands_3_letter); m++){
                                if(commands_3_letter[m] != current_atributes_value->name_atributes[m]){
                                  break;
                                }
                                if(m == my_strlen(commands_3_letter)-1){
                                  for(int f = 0; f < my_strlen(current_atributes_value->value); f++){
                                    n_value[f] = current_atributes_value->value[f];
                                  }
                                  found = true;
                                }
                              }
                            }
                            current_atributes_value = current_atributes_value->next;
                            continue;
                          }

                          continue;


                          
                        }
                      }
                    }
                    if(current_selectors_value->next != nullptr){
                    current_selectors_value = current_selectors_value->next;
                    }
                  }
                  

                }
                //tutaj
                if(my_strlen(n_value)>0){
                cout << commands << ",E," << commands_3_letter << " == " << n_value << endl;
                break;
                }

                if(current_node-> previous != nullptr){
                current_node = current_node->previous;
                }

            }
            
          
          
        }
      }


    }
  }
    
  return 0;
}


