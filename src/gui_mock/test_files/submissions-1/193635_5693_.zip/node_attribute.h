//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "string.h"
class node_attribute {
public:
    string name;
    string value;
    node_attribute* next;
};


