//
// Created by jastr on 01.04.2023.
//

#pragma once

#include "block.h"

#define T 8

class section {
public:
    block blocks[T];
    int counter;
    section();
    void push_back(block& new_block);
    block& operator[](int index);
};

