//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "node_selector.h"
#include "string.h"

class list_selector {
public:
    node_selector* head;
    list_selector();
    void push_back(const string& sel);

    int selector_counter();
};



