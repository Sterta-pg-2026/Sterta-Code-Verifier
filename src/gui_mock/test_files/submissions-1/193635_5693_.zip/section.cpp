//
// Created by jastr on 01.04.2023.
//

#include "section.h"

section::section() {
    counter = 0;
}

void section::push_back(block& new_block)   {
    blocks[counter] = new_block;
}

block& section::operator[](int index) {
    return blocks[index];
}
