//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "string.h"
#include "node_attribute.h"

class list_attribute {
public:
    node_attribute* head;
    list_attribute();
    void push_back(const string& att_name, const string& att_value);

    int attribute_counter();
};



