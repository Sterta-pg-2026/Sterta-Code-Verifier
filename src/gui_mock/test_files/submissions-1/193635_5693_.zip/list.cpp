//
// Created by jastr on 31.03.2023.
//

#include "list.h"
#include "section.h"

list::list() {
    head = nullptr;
    tail = nullptr;
}

void list::push_back(block& new_block) {
    if (head == nullptr) {
        head = new node;
        head->sect.push_back(new_block);
        head->sect.counter ++;
        tail = head;
    }
    else {
        node* temp = tail;
        if(temp->sect.counter < T) {
            temp->sect.push_back(new_block);
            temp->sect.counter ++;
        }
        else {
            temp->next = new node;
            temp->next->previous = temp;
            temp = temp->next;
            temp->sect.push_back(new_block);
            temp->sect.counter ++;
            tail = temp;
        }
    }
}

int list::block_counter() {
    node* temp = head;
    int counter = 0;
    while(temp != nullptr){
        counter += temp->sect.counter;
        temp = temp->next;
    }
    return counter;
}