//
// Created by jastr on 31.03.2023.
//

#include "block.h"
void block::add_attribute(const string& att_name, const string& att_value){
    node_attribute* temp = attributes.head;
    while(temp != nullptr){
        if(temp->name == att_name){
            temp->value = att_value;
            return;
        }
        temp = temp->next;
    }
    attributes.push_back(att_name, att_value);
}

void block::add_selector(const string& sel){
    selectors.push_back(sel);
}

string block::selector_returner(int j) {
    node_selector* temp = selectors.head;
    int counter = 1; //COUNTER SHOULD START AT ONE
    string check = "empty";
    while (counter != j) {
        if(temp == nullptr) return check;
        counter++;
        temp = temp->next;
    }
    if(temp == nullptr){
        return check;
    }
    return temp->list_string;
}

string block::selector_returner_string(string& selector_wanted){
    node_selector* temp = selectors.head;
    string check = "empty";
    if(temp == nullptr) return check;

    while (!(selector_wanted == temp->list_string)) {
        temp = temp->next;
        if(temp == nullptr) return check;
    }
    return temp->list_string;
}

string block::value_returner(string& n) {
    node_attribute* temp = attributes.head;
    string check = "empty";
    if(temp == nullptr) return check;
    while(!(temp->name == n)){
        temp = temp->next;
        if(temp == nullptr) return check;
    }
    return temp->value;
}

int block::where_selector(string &selector_wanted) {
    node_selector* temp = selectors.head;
    int counter = 0;
    if(temp == nullptr) return 0;
    while (!(temp->list_string == selector_wanted)) {
        temp = temp->next;
        if(temp == nullptr) return 0;
    }
    counter ++;
    return counter;
}

int block::where_attribute(string &attribute_wanted)  {
    node_attribute* temp = attributes.head;
    int counter = 0;
    if(temp == nullptr) return 0;
    while (!(temp->name == attribute_wanted)) {
        temp = temp->next;
        if(temp == nullptr) return 0;
    }
    counter ++;
    return counter;
}
/*
string block::block_delete() {
    node_attribute* temp_att = attributes.head;
    node_attribute* temp_att_help = attributes.head;
    node_selector* temp_sel = selectors.head;
    node_selector* temp_sel_help = selectors.head;
    string check = "empty";

    if(temp_att == nullptr) return check;
    while(temp_att != nullptr) {
        temp_att_help = temp_att;
        temp_att = temp_att->next;
        delete temp_att_help;
    }

    if(temp_sel == nullptr) return check;
    while(temp_sel != nullptr) {
        temp_sel_help = temp_sel;
        temp_sel = temp_sel->next;
        delete temp_sel_help;
    }

    return "deleted";

}

string block::attribute_delete(string& attribute_wanted){
    node_attribute* temp_att = attributes.head;
    node_attribute* temp_att_help = attributes.head;
    node_selector* temp_sel = selectors.head;
    node_selector* temp_sel_help = selectors.head;
    string check = "empty";

    if(temp_att == nullptr) return check;
    while(!(temp_att->name == attribute_wanted)) {
        temp_att_help = temp_att;
        temp_att = temp_att->next;

    }
    if(temp_att == temp_att_help){
        return check;
    }
    else{
        temp_att_help->next = temp_att->next;
        delete temp_att_help;
    }

    if (attributes.head == nullptr){
        if(temp_sel == nullptr) return check;
        while(temp_sel != nullptr) {
            temp_sel_help = temp_sel;
            temp_sel = temp_sel->next;
            delete temp_sel_help;
        }
        return "whole_block_deleted";
    }
    else{
        return "attribute_deleted";
    }

}
*/