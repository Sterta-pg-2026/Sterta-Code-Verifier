//
// Created by jastr on 31.03.2023.
//

#include "list_selector.h"
list_selector::list_selector() {
    head = nullptr;
}

void list_selector::push_back(const string& sel) {
    node_selector* newNode = new node_selector;
    newNode->list_string = sel;
    newNode->next = nullptr;
    if (head == nullptr) {
        head = newNode;
    }

    else {
        node_selector* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

int list_selector::selector_counter(){
    node_selector* temp = head;
    int counter = 0;
    while (temp != nullptr) {
        counter++;
        temp = temp->next;
    }
    return counter;
}


