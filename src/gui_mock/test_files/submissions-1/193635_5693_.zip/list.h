//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "node.h"

class list {
private:
    node* head;
    node* tail;
public:
    list();
    void push_back(block& new_block);
    int block_counter();

    friend int number_of_selectors(string& part_one, list& new_list);
    friend int number_of_attributes(string& part_one, list& new_list);
    friend string wanted_selector(string& part_one, string& part_three, list& new_list);
    friend string attribute_values(string& part_one, string& part_three, list& new_list);
    friend int selector_occurences(string& part_one, list& new_list);
    friend int attribute_occurences(string& part_one,list& new_list);
    friend string attribute_value_for_selector(string& part_one,string& part_three,list& new_list);
    friend string delete_whole_block(string& part_one,list& new_list);
    friend string delete_part_of_block(string& part_one,string& part_three,list& new_list);
};

