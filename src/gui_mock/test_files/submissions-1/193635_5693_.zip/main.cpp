#include <iostream>
#include "string.h"
#include "list.h"

using std::cin, std::cout, std::endl ;

int number_of_selectors(string& part_one, list& new_list) {
    int block_wanted = part_one.string_to_int();
    int which_block = 0;
    node* help = new_list.head;
    while(help != nullptr){
        for(int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
              return help->sect.blocks[i].selectors.selector_counter();
            }
        }
        help = help->next;
    }
    return 0;
}

int number_of_attributes(string& part_one, list& new_list){
    int block_wanted = part_one.string_to_int();
    int which_block = 0;
    node* help = new_list.head;
    while(help != nullptr){
        for(int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
                return help->sect.blocks[i].attributes.attribute_counter();
            }
        }
        help = help->next;
    }
    return 0;
}

string wanted_selector(string& part_one, string& part_three, list& new_list){
    int block_wanted = part_one.string_to_int();
    int selector_wanted = part_three.string_to_int();
    int which_block = 0;
    node* help = new_list.head;
    while(help != nullptr){
        for(int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
                return help->sect.blocks[i].selector_returner(selector_wanted);
            }
        }
        help = help->next;
    }
    return "empty";
}

int selector_occurences(string& part_one, list& new_list){
    node* help = new_list.head;
    int occurences = 0;
    while(help != nullptr){
        for(int i = 0; i < T; i++ ){
           occurences += help->sect.blocks[i].where_selector(part_one) ;
        }
        help = help->next;
    }
    return occurences;
}

string attribute_values(string& part_one, string& part_three, list& new_list){
    int block_wanted = part_one.string_to_int();
    string attribute_name = part_three;
    int which_block = 0;
    node* help = new_list.head;
    while(help != nullptr){
        for(int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
                return help->sect.blocks[i].value_returner(attribute_name);
            }
        }
        help = help->next;
    }
    return "empty";
}

int attribute_occurences(string& part_one,list& new_list){
    node* help = new_list.head;
    int occurences = 0;
    while(help != nullptr){
        for(int i = 0; i < T; i++ ){
            occurences += help->sect.blocks[i].where_attribute(part_one) ;
        }
        help = help->next;
    }
    return occurences;
}

string attribute_value_for_selector(string& part_one,string& part_three,list& new_list){
    node* help = new_list.tail;
    while(help != nullptr) {
        for (int i = help->sect.counter - 1; i >= 0; i--) {
            if(part_one == help->sect.blocks[i].selector_returner_string(part_one)){
                return help->sect.blocks[i].value_returner(part_three);
            }
        }
        help = help->previous;
    }
    return "empty";
}
/*
string delete_whole_block(string& part_one,list& new_list){
    node* help = new_list.head;
    int block_wanted = part_one.string_to_int();
    int which_block = 0;
    while(help != nullptr){
        for (int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
                if(help->sect.blocks[i].block_delete() == "deleted"){
                    help->sect.counter --;
                    if(help->sect.counter == 0) {
                        if (help == new_list.head) {
                            help->next->previous = nullptr;
                            new_list.head = help->next;
                            delete help;
                        }
                        else if (help == new_list.tail){
                            help->previous->next = nullptr;
                            new_list.tail = help->previous;
                            delete help;
                        }
                        else {
                            help->next->previous = help->previous;
                            help->previous->next = help->next;
                            delete help;
                        }
                    }
                    return "deleted";
                }
                else return "empty";
            }
        }
        help = help->next;
    }
    return "empty";
}

string delete_part_of_block(string& part_one,string& part_three,list& new_list){
    node* help = new_list.head;
    int block_wanted = part_one.string_to_int();
    int which_block = 0;
    string result;
    while(help != nullptr){
        for (int i = 0; i < T; i++){
            if(help->sect.blocks[i].attributes.head != nullptr) which_block++;
            if(which_block == block_wanted){
                result = help->sect.blocks[i].attribute_delete(part_three);
                if(result  == "attribute_deleted"){
                    return "deleted";
                    }
                else if(result == "whole_block_deleted"){
                    help->sect.counter --;
                    if(help->sect.counter == 0) {
                        if (help == new_list.head) {
                            help->next->previous = nullptr;
                            new_list.head = help->next;
                            delete help;
                        }
                        else if (help == new_list.tail){
                            help->previous->next = nullptr;
                            new_list.tail = help->previous;
                            delete help;
                        }
                        else {
                            help->next->previous = help->previous;
                            help->previous->next = help->next;
                            delete help;
                        }
                    }
                    return "deleted";
                }
            }
        }
        help = help->next;
    }
    return "empty";
}
*/
void command_menu(string& part_one, string& part_two, string& part_three, list& new_list){
    char c = part_two[0];
    switch(c) {
        case 'A':
            if(!(part_three == "?")){
                if(!(attribute_values(part_one,part_three, new_list) == "empty")) {
                    cout << part_one << "," << part_two << "," << part_three << " == "<< attribute_values(part_one, part_three, new_list) << endl;
                }
            }
            else if (part_one[0] >= '0' & part_one[0] <= '9'){
                if(number_of_attributes(part_one, new_list) > 0) {
                    cout << part_one << "," << part_two << "," << part_three << " == "<< number_of_attributes(part_one, new_list)<<endl;
                }
            }
            else{
                cout << part_one << "," << part_two << "," << part_three << " == "<< attribute_occurences(part_one, new_list)<<endl;
            }
            break;
        case 'D':
             /*  if(part_three == "*"){
                    if(!((delete_whole_block(part_one, new_list)) == "empty")) {
                        cout << part_one << "," << part_two << "," << part_three << " == "<< "deleted" << endl;
                    }
                }
                else{
                    if(!((delete_part_of_block(part_one,part_three, new_list)) == "empty"))
                    cout << part_one << "," << part_two << "," << part_three << " == "<< "deleted" << endl;
                }
             */
            break;
        case 'E':
            if(!((attribute_value_for_selector(part_one, part_three, new_list)) == "empty")) {
                cout << part_one << "," << part_two << "," << part_three << " == "<< attribute_value_for_selector(part_one, part_three, new_list) << endl;
            }
            break;
        case 'S':
            if(!(part_three == "?")){
                if(!((wanted_selector(part_one, part_three, new_list)) == "empty")) {
                    cout << part_one << "," << part_two << "," << part_three << " == "<< wanted_selector(part_one, part_three, new_list) << endl;
                }
            }
            else if (part_one[0] >= '0' & part_one[0] <= '9'){
                if(number_of_selectors(part_one, new_list) > 0) {
                    cout << part_one << "," << part_two << "," << part_three << " == "<< number_of_selectors(part_one, new_list)<<endl;
                }
            }
            else{
                cout << part_one << "," << part_two << "," << part_three << " == "<< selector_occurences(part_one, new_list)<<endl;
            }
            break;
    }
}

void single_question_mark(list& new_list){
    cout<<"? == "<<new_list.block_counter()<<endl;
}

void parseCSS(string css, string& selector, bool& in_selector, string& attribute, bool& in_attribute, string& value, bool& in_value, block*& new_block, list& new_list) {

    for (int i = 0; i < css.length(); i++) {
        char c = css[i];
        if (in_selector) {
            switch (c) {
                case '{':
                    selector.remove_last_whitespace();
                    new_block->add_selector(selector);
                    selector = "";
                    in_selector = false;
                    in_attribute = true;
                    break;
                case ',':
                    selector.remove_last_whitespace();
                    new_block->add_selector(selector);
                    selector = "";
                    break;
                default:
                    if(!(isspace(c) && selector == ""))
                    selector = selector + c;
                    break;
            }
        }
        else if (in_attribute || in_value) {
            switch (c) {
                case ':':
                    if (in_attribute == true) {
                        in_attribute = false;
                        in_value = true;
                    }
                    break;
                case ';':
                    attribute.remove_last_whitespace();
                    value.remove_last_whitespace();
                    new_block->add_attribute(attribute, value);
                    attribute = "";
                    value = "";
                    in_value = false;
                    in_attribute = true;
                    break;
                case '}':
                    if (!(value == "")) {
                        attribute.remove_last_whitespace();
                        value.remove_last_whitespace();
                        new_block->add_attribute(attribute, value);
                        attribute = "";
                        value = "";
                    }
                    in_attribute = false;
                    in_value = false;
                    in_selector = true;
                    new_list.push_back(*new_block);
                    new_block = new block();
                    break;
                default:
                    if(in_attribute == true && !(isspace(c) && attribute == "")){
                       attribute = attribute + c;
                    }
                    else if(in_value == true && !(isspace(c) && value == "")){
                        value = value + c;
                    }
                    break;
            }
        }
    }
}

void commandCSS(string css, string& part_one, bool& in_part_one, string& part_two, bool& in_part_two, string& part_three, bool& in_part_three, list& new_list){
    for (int i = 0; i < css.length(); i++) {
        char c = css[i];

        if (in_part_one == true && c == '?') {
            single_question_mark(new_list);
            part_one = "";
            in_part_one = true;
            break;
        }
        switch(c) {
            case ',':
                if (in_part_one == true) {
                    in_part_one = false;
                    in_part_two = true;
                }
                else if (in_part_two == true) {
                    in_part_two = false;
                    in_part_three = true;
                }
                break;
            default:
                if (in_part_one && !(isspace(c) && part_one == "")){
                    part_one = part_one + c;
                }
                else if (in_part_two && !(isspace(c) && part_two == "")){
                    part_two = part_two + c;
                }
                else if (in_part_three && !(isspace(c) && part_three == "")){
                    part_three = part_three + c;
                }
        }

        if( i == css.length() - 1){
            command_menu(part_one, part_two, part_three, new_list);
            in_part_three = false;
            in_part_one = true;
            part_one = "";
            part_two = "";
            part_three = "";
        }
    }
}

int main() {
    block* new_block = new block();
    list new_list;

    string css = "";

    string selector = "";
    bool in_selector = true;
    string attribute = "";
    bool in_attribute = false;
    string value = "";
    bool in_value = false;

    string part_one = "";
    bool in_part_one = true;
    string part_two = "";
    bool in_part_two = false;
    string part_three = "";
    bool in_part_three = true;

    while (true) {
        while(!(css == "????")) {
            getline(cin, css);
            parseCSS(css, selector, in_selector, attribute, in_attribute, value, in_value, new_block, new_list);
        }
        while(!(css == "****")){
            getline(cin, css);
            commandCSS(css, part_one,in_part_one, part_two,in_part_two, part_three, in_part_three, new_list);
        }
    }
    return 0;
}