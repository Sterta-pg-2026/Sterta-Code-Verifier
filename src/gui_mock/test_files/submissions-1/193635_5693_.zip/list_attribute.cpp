//
// Created by jastr on 31.03.2023.
//
#include "list_attribute.h"
list_attribute::list_attribute() {
    head = nullptr;
}

void list_attribute::push_back(const string& att_name, const string& att_value) {
    node_attribute* newNode = new node_attribute;
    newNode->name = att_name;
    newNode->value = att_value;
    newNode->next = nullptr;

    if (head == nullptr) {
        head = newNode;
    }
    else {
        node_attribute* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

int list_attribute::attribute_counter(){
    node_attribute* temp = head;
    int counter = 0;
    while (temp != nullptr) {
        counter++;
        temp = temp->next;
    }
    return counter;
}


