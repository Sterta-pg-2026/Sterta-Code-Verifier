//
// Created by jastr on 24.03.2023.
//
#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#include "string.h"

string::string(){
    chars = nullptr;
}

string::string(const char* chars_array) {
    int length = strlen(chars_array);
    chars = new char[length + 1];
    strcpy(chars, chars_array);
}

string::string(const string& other){
    if(other.chars != nullptr){
        int length = strlen(other.chars);
        chars = new char[length + 1];
        strcpy(chars, other.chars);
    }
    else{
        chars = nullptr;
    }
}

string& string::operator=(const string &other) {
    if(chars != nullptr) delete[] chars;
    int length = strlen(other.chars);
    chars = new char[length + 1];
    strcpy(chars, other.chars);

    return *this;
}
string& string::operator=(char c){
    if(chars != nullptr) delete[] chars;
    int length = 1;
    chars = new char[length + 1];
    chars[0] = c;
    chars[1] = '\0';

    return *this;
}

bool string::operator==(const string &other) {
    return strcmp(chars, other.chars) == 0;
}

string& string::operator+(const string &other) {
    int size = strlen(chars) + strlen(other.chars) + 1;
    char* new_string = new char[size];

    strcpy(new_string, chars);
    strcat(new_string, other.chars);

    string sum_string(new_string);
    delete[] new_string;
    return sum_string;

}

string string::operator+(char c) {
    int size = length() + 2;
    char* new_string = new char[size];

    strcpy(new_string, chars);
    new_string[size-2] = c;
    new_string[size-1] = '\0';

    string sum_string(new_string);
    delete[] new_string;
    return sum_string;
}
int string::string_to_int(){
    int new_int = 0;
    for (int i= 0; chars[i] != '\0'; i++) {
        if (chars[i] < '0' || chars[i] > '9') {
            break;
        }
        new_int = new_int * 10 + (chars[i] - '0');
    }
    return new_int;
}

char& string::operator[](int index) {
    return chars[index];
}

std::ostream& operator<<(std::ostream& output, const string& string_out){
    output << string_out.chars;
    return output;
}

std::istream& operator>>(std::istream& input, string& string_in){
    char buff[64];
    input >> buff;
    string_in = string(buff);
    return input;
}

std::istream& getline(std::istream& input, string& string_in) {
    char* buffer = new char[256];
    buffer[255] = '\n';
    if(input.getline(buffer, 256)) {
        string_in = string(buffer);
    } else {
        delete[] buffer;
        exit(0);
    }
    delete[] buffer;
    return input;
}

int string::length() const {
    int length = 0;
    if(chars == nullptr) return 0;
    while (chars[length] != '\0') {
        ++length;
    }
    return length;
}

void string::remove_last_whitespace() {
    int length = strlen(chars);
    while (length > 0 && isspace(chars[length-1])) {
        chars[length-1] = '\0';
        length--;
    }
}

string::~string(){
    delete[] chars;
}