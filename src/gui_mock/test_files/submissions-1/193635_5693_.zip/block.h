//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "list_selector.h"
#include "list_attribute.h"

class block {

public:
    list_selector selectors;
    list_attribute attributes;
    block() {}

    void add_attribute(const string& att_name, const string& att_value);

    void add_selector(const string& sel);

    string selector_returner(int j);

    string selector_returner_string(string& selector_wanted);

    string value_returner(string& n);

    int where_selector(string& selector_wanted);

    int where_attribute(string& part_one);
    /*
    string block_delete();

    string attribute_delete(string& part_three);
    */
};

