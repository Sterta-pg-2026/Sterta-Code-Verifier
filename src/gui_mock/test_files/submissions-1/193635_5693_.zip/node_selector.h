//
// Created by jastr on 31.03.2023.
//
#pragma once

#include "string.h"
class node_selector {
public:
    string list_string;
    node_selector* next;
};



