//
// Created by jastr on 24.03.2023.
//

#pragma once

#include <iostream>


class string {
private:
    char* chars;

public:
    string();
    string(const char* chars_array);
    string(const string& other);

    string& operator=(const string& other);
    string& operator=(char c);
    bool operator==(const string& other);
    string& operator+(const string& other);
    char& operator[](int index);
    string operator+(char c);
    int string_to_int();
    void remove_last_whitespace();

    friend std::ostream& operator<<(std::ostream& os, const string& string_out);
    friend std::istream& operator>>(std::istream& is, string& string_in);
    friend std::istream& getline(std::istream& input, string& string_in);

    int length() const;

    ~string();
};

