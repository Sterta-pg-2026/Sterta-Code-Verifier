//
// Created by jastr on 31.03.2023.
//

#pragma once

#include "string.h"
#include "section.h"


class node {
public:
    node();
    section sect;
    node* next;
    node* previous;
};

