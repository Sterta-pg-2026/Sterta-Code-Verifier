#pragma once

template<typename T>
class pointer_list
{
public:
	class iterator;

public:
	pointer_list() noexcept
	{
		this->first = this->last = new node();
	}

	pointer_list(const pointer_list&) = delete;
	pointer_list(pointer_list&&) = delete;

	pointer_list& operator=(const pointer_list&) = delete;
	pointer_list& operator=(pointer_list&&) = delete;

	~pointer_list()
	{
		while (this->first) {
			node* to_delete = this->first;
			this->first = this->first->next;

			for (size_t i = 0; i < block_count; ++i)
				if (to_delete->data[i])
					delete to_delete->data[i];

			delete to_delete;
		}
	}

	iterator begin()
	{
		iterator b = iterator(this->first, 0);
		iterator e = this->end();

		while (b != e && !b.has_value())
			++b;

		return b;
	}
	iterator end()
	{
		return iterator(this->last, this->last->first_free());
	}

	T& back()
	{
		return *(--this->end());
	}

	void push_back(T* value)
	{
		size_t first_free = this->last->first_free();

		this->last->data[first_free] = value;
		++this->last->occupied;

		if (++first_free == block_count) {
			this->last->next = new node();
			this->last->next->previous = this->last;
			this->last = this->last->next;
		}
	}

	iterator erase(iterator it)
	{
#ifdef ITERATOR_CHECK
		if (!it.ptr->data[it.offset])
			throw "cannot erase null value";
#endif

		iterator next = it;
		next.advance_to_next_valued();

		delete it.ptr->data[it.offset];
		it.ptr->data[it.offset] = nullptr;

		if (--it.ptr->occupied == 0 && it.ptr != this->last)
		{
			if (it.ptr->next)
				it.ptr->next->previous = it.ptr->previous;
			if (it.ptr->previous)
				it.ptr->previous->next = it.ptr->next;

			if (it.ptr == this->first)
				this->first = it.ptr->next;

			delete it.ptr;
		}

		return next;
	}
	void erase(iterator it, size_t count)
	{
		for (; count != 0; --count)
			it = this->erase(it);
	}

private:
	static constexpr size_t block_count = 17;

	struct node
	{
		size_t first_free() const
		{
			for (size_t i = block_count; i > 0; --i)
				if (this->data[i - 1] != nullptr)
					return i;
			return 0;
		}

		T* data[block_count] = {};
		size_t occupied = 0;
		node* next = nullptr;
		node* previous = nullptr;
	};

private:
	node* first;
	node* last;
};

template<typename T>
class pointer_list<T>::iterator
{
public:
	iterator() = default;
	iterator(node* ptr, size_t offset)
		:ptr(ptr), offset(offset)
	{
	}

	iterator& operator++()
	{
#ifdef ITERATOR_CHECK
		if (!this->ptr)
			throw "cannot increment empty iterator";
#endif
		this->offset++;
		if (this->offset == block_count) {
			this->ptr = this->ptr->next;
			this->offset = 0;
		}

#ifdef ITERATOR_CHECK
		if (this->ptr == nullptr)
			throw "iterator out of range";
#endif
		return *this;
	}
	iterator& operator--()
	{
#ifdef ITERATOR_CHECK
		if (!this->ptr)
			throw "cannot decrement empty iterator";
#endif
		if (this->offset == 0) {
			this->ptr = this->ptr->previous;
			this->offset = block_count - 1;
		}
		else
			this->offset--;

#ifdef ITERATOR_CHECK
		if (this->ptr == nullptr)
			throw "iterator out of range";
#endif
		return *this;
	}

	void advance(size_t n)
	{
		while (true)
		{
			if (this->offset == 0)
				while (n > this->ptr->occupied) {
					n -= this->ptr->occupied;
					this->ptr = this->ptr->next;
#ifdef ITERATOR_CHECK
					if (this->ptr == nullptr)
						throw "iterator out of range";
#endif
				}

			if (this->ptr->data[this->offset])
				if (n == 0)
					return;
				else
					--n;

			this->offset++;
			if (this->offset == block_count) {
				this->offset = 0;
				this->ptr = this->ptr->next;
#ifdef ITERATOR_CHECK
				if (this->ptr == nullptr)
					throw "iterator out of range";
#endif
			}
		}
	}
	void advance_to_next_valued()
	{
#ifdef ITERATOR_CHECK
		if (!this->ptr)
			throw "cannot increment empty iterator";
#endif
		do {
			this->offset++;
			if (this->offset == block_count) {
				this->ptr = this->ptr->next;
				this->offset = 0;
			}
		} while (this->ptr && !this->ptr->data[this->offset]);
	}

	T& operator*() const
	{
		return *this->operator->();
	}
	T* operator->() const
	{
#ifdef ITERATOR_CHECK
		if (this->ptr == nullptr)
			throw "cannot dereference empty iterator";
#endif
		T* value = this->ptr->data[this->offset];

#ifdef ITERATOR_CHECK
		if (value == nullptr)
			throw "cannot dereference null value iterator";
#endif
		return value;
	}

	bool has_value() const
	{
		return this->ptr && this->ptr->data[this->offset];
	}

	bool operator==(const iterator& other) const noexcept
	{
		return this->ptr == other.ptr && this->offset == other.offset;
	}
	bool operator!=(const iterator& other) const noexcept
	{
		return !(*this == other);
	}

private:
	node* ptr = nullptr;
	size_t offset = 0;

	friend class pointer_list<T>;
};

template<typename Iter>
size_t distance(Iter first, Iter last)
{
	size_t i = 0;

	while (first != last) {
		if (first.has_value())
			++i;
		++first;
	}

	return i;
}

template<typename Iter, typename Elem, typename Comp>
auto find(Iter it, size_t count, Elem elem, Comp comp)
{
	for (; count != 0; ++it)
		if (it.has_value()) {
			--count;
			if (comp(*it, elem))
				return it;
		}

	return Iter();
}

template<typename Iter, typename Elem, typename Comp>
size_t count(Iter first, Iter last, Elem elem, Comp comp)
{
	size_t c = 0;

	for (; first != last; ++first)
		if (first.has_value() && comp(*first, elem))
			c++;

	return c;
}

template<typename Container, typename Iter, typename Comp>
void remove_duplicates(Container& cont, Iter it, size_t& cont_count, Comp comp)
{
	for (size_t count = cont_count; count != 0; ++it)
		if (it.has_value()) {
			count--;

			auto it2 = it;
			++it2;
			size_t count2 = count;

			for (; count2 != 0; ++it2)
				if (it2.has_value()) {
					count2--;

					if (comp(*it, *it2)) {
						cont.erase(it);
						cont_count--;
						break;
					}
				}
		}
}
