#include <string.h>
#include <cctype>
#include <cstdio>
#include <cstdlib>

//#define ITERATOR_CHECK
#include "utilities.h"

bool read_line(char** line)
{
	static char buffer[1024];

	*line = fgets(buffer, sizeof(buffer), stdin);
	if (*line == nullptr)
		return false;

	char& last_char = (*line)[strlen(*line) - 1];

	if(last_char == '\n')
		last_char = NULL;

	return true;
}

void ignore_space(char*& line)
{
	while (isspace(static_cast<unsigned char>(*line)))
		line++;
}
char* create_token(char*& line, const char* sep)
{
	ignore_space(line);

	char* end = strpbrk(line, sep);

	if (!end)
		end = line + strlen(line);

	if (line == end)
		return nullptr;
	else {
		char* token_end = end;

		while (isspace(static_cast<unsigned char>(*(token_end - 1))))
			token_end--;

		size_t str_len = token_end - line;
		char* new_token = new char[str_len + 1];
		memcpy(new_token, line, str_len);
		new_token[str_len] = NULL;

		line = end;
		return new_token;
	}
}

enum class css_tokenizer_state
{
	none, selector, attribute_name, attribute_separator, attribute_value, attribute_end
};

struct block;
struct attribute
{
	attribute() = default;

	attribute(const attribute&) = delete;
	attribute(attribute&&) = delete;

	~attribute()
	{
		delete[] name;
		delete[] value;
	}

	const char* name;
	const char* value;
};
struct selector
{
	selector() = default;

	selector(const selector&) = delete;
	selector(selector&&) = delete;

	~selector()
	{
		delete[] name;
	}

	const char* name;
	block* parent;
};
struct block
{
	pointer_list<selector>::iterator selectors_it;
	pointer_list<attribute>::iterator attributes_it;
	size_t selectors_count = 0;
	size_t attributes_count = 0;
};

struct css_data
{
	size_t blocks_count = 0;
	pointer_list<block> blocks;
	pointer_list<selector> selectors;
	pointer_list<attribute> attributes;

	css_tokenizer_state state = css_tokenizer_state::none;
};

void read_css_none(char*& line, css_data& data)
{
	ignore_space(line);

	if (*line == NULL)
		return;

	block* new_block = new block();
	new_block->selectors_it = data.selectors.end();
	new_block->attributes_it = data.attributes.end();

	data.blocks.push_back(new_block);

	if (*line != '{')
		data.state = css_tokenizer_state::selector;
	else {
		data.state = css_tokenizer_state::attribute_name;
		line++;
	}
}
void read_css_selector(char*& line, css_data& data)
{
	char* token = create_token(line, ",{");

	if (*line == '{') {
		data.state = css_tokenizer_state::attribute_name;
		line++;
	}
	else if (*line == ',')
		line++;

	if (!token)
		return;

	selector* new_selector = new selector();
	new_selector->name = token;
	new_selector->parent = &data.blocks.back();
	data.selectors.push_back(new_selector);
}
void read_css_attribute_name(char*& line, css_data& data)
{
	char* token = create_token(line, ":}");
	if (*line == '}') {
		block& last_block = data.blocks.back();
		last_block.selectors_count = distance(last_block.selectors_it, data.selectors.end());
		last_block.attributes_count = distance(last_block.attributes_it, data.attributes.end());
		data.blocks_count++;

		remove_duplicates(data.selectors, last_block.selectors_it, last_block.selectors_count,
						  [](selector& l, selector& r) { return strcmp(l.name, r.name) == 0; });
		remove_duplicates(data.attributes, last_block.attributes_it, last_block.attributes_count,
						  [](attribute& l, attribute& r) { return strcmp(l.name, r.name) == 0; });

		if (!last_block.selectors_it.has_value())
			last_block.selectors_it.advance_to_next_valued();
		if (!last_block.attributes_it.has_value())
			last_block.attributes_it.advance_to_next_valued();

		data.state = css_tokenizer_state::none;
		line++;
		return;
	}

	if (!token)
		return;

	attribute* new_attribute = new attribute();
	new_attribute->name = token;

	data.attributes.push_back(new_attribute);

	if (*line == ':') {
		line++;
		data.state = css_tokenizer_state::attribute_value;
	}
	else
		data.state = css_tokenizer_state::attribute_separator;
}
void read_css_attribute_separator(char*& line, css_data& data)
{
	ignore_space(line);

	if (*line == NULL)
		return;
	
	if (*line == ':')
		line++;
	else
		throw "invalid css attribute separator";

	data.state = css_tokenizer_state::attribute_value;
}
void read_css_attribute_value(char*& line, css_data& data)
{
	char* token = create_token(line, ";}");
	if (!token)
		return;

	data.attributes.back().value = token;

	if (*line != NULL) {
		if (*line == ';')
			line++;
		data.state = css_tokenizer_state::attribute_name;
	}
	else
		data.state = css_tokenizer_state::attribute_end;

}
void read_css_attribute_end(char*& line, css_data& data)
{
	ignore_space(line);

	if (*line == NULL)
		return;

	if (*line == ';')
		line++;
	else if (*line != '}')
		throw "invalid css attribute end";

	data.state = css_tokenizer_state::attribute_name;
}

void read_css(char* line, css_data& data)
{
	while (*line)
		switch (data.state)
		{
			case css_tokenizer_state::none:
				read_css_none(line, data);
				break;
			case css_tokenizer_state::selector:
				read_css_selector(line, data);
				break;
			case css_tokenizer_state::attribute_name:
				read_css_attribute_name(line, data);
				break;
			case css_tokenizer_state::attribute_separator:
				read_css_attribute_separator(line, data);
				break;
			case css_tokenizer_state::attribute_value:
				read_css_attribute_value(line, data);
				break;
			case css_tokenizer_state::attribute_end:
				read_css_attribute_end(line, data);
				break;
		}
}

struct command_type
{
	unsigned int section_index;
	const char* left;
	const char* middle;
	const char* right;
};
bool try_make_command(char* line, command_type* command)
{
	command->left = line;
	line = strchr(line, ',');
	if (line == nullptr)
		return false;

	*line++ = NULL;

	command->middle = line;
	line = strchr(line, ',');
	if (line == nullptr)
		return false;
	*line++ = NULL;

	command->right = line;

	command->section_index = (unsigned int)strtoul(command->left, nullptr, 10);

	return true;
}

void command_section_selectors(command_type& command, css_data& data)
{
	auto section_it = data.blocks.begin();
	section_it.advance(command.section_index - 1);

	if (strcmp(command.right, "?") == 0)
	{
		printf("%u,S,? == %u\n", command.section_index, (unsigned int)section_it->selectors_count);
	}
	else
	{
		unsigned int selector_index = strtoul(command.right, nullptr, 10);
		if (selector_index == 0)
			throw "invalid selector index";

		auto selector_it = section_it->selectors_it;
		if (section_it->selectors_count < selector_index)
			return;

		selector_it.advance(selector_index - 1);

		printf("%u,S,%u == %s\n", command.section_index, selector_index,
			   selector_it->name);
	}
}
void command_section_attributes(command_type& command, css_data& data)
{
	auto section_it = data.blocks.begin();
	section_it.advance(command.section_index - 1);

	if (strcmp(command.right, "?") == 0)
	{
		printf("%u,A,? == %u\n", command.section_index, (unsigned int)section_it->attributes_count);
	}
	else
	{
		auto it = find(section_it->attributes_it, section_it->attributes_count, command.right,
					   [](attribute& a, const char* n) { return strcmp(a.name, n) == 0; });

		if (!it.has_value())
			return;

		printf("%u,A,%s == %s\n", command.section_index, command.right, it->value);
	}
}
void command_section_delete(command_type& command, css_data& data)
{
	auto section_it = data.blocks.begin();
	section_it.advance(command.section_index - 1);

	if (strcmp(command.right, "*") == 0)
	{
		data.selectors.erase(section_it->selectors_it, section_it->selectors_count);
		data.attributes.erase(section_it->attributes_it, section_it->attributes_count);
		data.blocks.erase(section_it);
		data.blocks_count--;

		printf("%u,D,* == deleted\n", command.section_index);
	}
	else
	{
		auto it = find(section_it->attributes_it, section_it->attributes_count, command.right,
					   [](attribute& a, const char* n) { return strcmp(a.name, n) == 0; });

		if (!it.has_value())
			return;

		if (--section_it->attributes_count == 0) {
			data.attributes.erase(it);
			data.blocks.erase(section_it);
			data.blocks_count--;
		}
		else {
			bool remove_first = section_it->attributes_it == it;
			it = data.attributes.erase(it);

			if (remove_first)
				section_it->attributes_it = it;
		}

		printf("%u,D,%s == deleted\n", command.section_index, command.right);
	}
}

void command_selectors(command_type& command, css_data& data)
{
	size_t selectors_count = count(data.selectors.begin(), data.selectors.end(), command.left,
								   [](selector& s, const char* n) { return strcmp(s.name, n) == 0; });

	printf("%s,S,? == %u\n", command.left, (unsigned int)selectors_count);
}
void command_attributes(command_type& command, css_data& data)
{
	size_t attributes_count = count(data.attributes.begin(), data.attributes.end(), command.left,
									[](attribute& a, const char* n) { return strcmp(a.name, n) == 0; });

	printf("%s,A,? == %u\n", command.left, (unsigned int)attributes_count);
}
void command_selector_attributes(command_type& command, css_data& data)
{
	auto it = data.selectors.end();
	auto end = data.selectors.begin();

	while(it != end) {
		--it;

		if (it.has_value() && strcmp(it->name, command.left) == 0)
		{
			auto* parent = it->parent;
			auto ait = parent->attributes_it;

			for (size_t count = parent->attributes_count; count != 0; ++ait)
				if (ait.has_value()) {
					--count;
					if (strcmp(ait->name, command.right) == 0) {
						printf("%s,E,%s == %s\n", command.left, command.right, ait->value);
						return;
					}
				}
		}
	}
}

void read_command(char* line, css_data& data)
{
	ignore_space(line);

	if (*line == NULL)
		return;
	else if (strcmp(line, "?") == 0)
	{
		printf("? == %u\n", (unsigned int)distance(data.blocks.begin(), data.blocks.end()));
	}
	else
	{
		command_type command;
		if (!try_make_command(line, &command))
			return;

		if (command.section_index != 0)
		{
			if (command.section_index > data.blocks_count)
				return;

			if (strcmp(command.middle, "S") == 0)
			{
				command_section_selectors(command, data);
			}
			else if (strcmp(command.middle, "A") == 0)
			{
				command_section_attributes(command, data);
			}
			else if (strcmp(command.middle, "D") == 0)
			{
				command_section_delete(command, data);
			}
		}
		else if (strcmp(command.middle, "S") == 0 && strcmp(command.right, "?") == 0)
		{
			command_selectors(command, data);
		}
		else if (strcmp(command.middle, "A") == 0 && strcmp(command.right, "?") == 0)
		{
			command_attributes(command, data);
		}
		else if (strcmp(command.middle, "E") == 0)
		{
			command_selector_attributes(command, data);
		}
	}
}

int main()
{
	css_data data;

	bool reading_css = true;

	char* line;
	while (read_line(&line))
		if (strcmp(line, "????") == 0)
			reading_css = false;
		else if (strcmp(line, "****") == 0)
			reading_css = true;
		else if (reading_css)
			read_css(line, data);
		else
			read_command(line, data);
}