#include "mainnode.h"

//std::ostream& operator<<(std::ostream& out, const NodeMain& next) {
//	return out << next.section.attribute << " " << next.section.selector;
//}