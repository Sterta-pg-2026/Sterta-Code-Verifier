#pragma once
#define T 17
#include <iostream>
#include "string.h"
#include "attributenode.h"
#include "attributeslist.h"
#include "selectornode.h"
#include "selectorslist.h"
using namespace std;

struct Section {
	DoublyLinkedListAtt attribute;
	DoublyLinkedListSel selector;
	bool isUsed = 0;
};

struct NodeMain {
	Section section[T];
	int arrayCounter = 0;
	int arrayUsed = 0;
	NodeMain* next = NULL;
	NodeMain* prev = NULL;
	friend std::ostream& operator<<(std::ostream& out, const NodeMain& next);
};