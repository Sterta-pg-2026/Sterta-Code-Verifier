#pragma once
#include<iostream>
#include "funkcje.h"
using namespace std;

class Atrybut {
public:
	char nazwa[buffer];
	char wartosc[buffer];
	Atrybut* poprzedni;
	Atrybut* nastepny;
	Atrybut()
	{
		poprzedni = nullptr;
		nastepny = nullptr;
	}
};