#pragma once
#include<iostream>
#include "funkcje.h"
using namespace std;

class Selektor {
public:
	char nazwa[buffer];
	Selektor* poprzedni;
	Selektor* nastepny;
	Selektor()
	{
		poprzedni = nullptr;
		nastepny = nullptr;
	}
};