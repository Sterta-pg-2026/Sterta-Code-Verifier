#include "selektor.h"
/*
Selektor::Selektor()
{
	poprzedni = nullptr;
	nastepny = nullptr;
}
*/