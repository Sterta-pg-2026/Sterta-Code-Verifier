#include "listaglowna.h"
/*
ListaBlokow::ListaBlokow()
{
	pierwszy = nullptr;
	cssparser = true;
	selektormode = false;
	atrybutmode = false;
	komendymode = false;
	istniejeselektor = false;
	konieclinii = false;
	koniecsekcji = false;
	dodanosekcje = false;
	znakzapytania = false;
	sameselektory = false;
	LICZNIKSEKCJI = 0;
	LICZNIKBLOKOW = 0;
	ktoryblok = 1;
	ktoryindeks = 0;

	plik.open("1.in");
	if (plik.is_open())
	{
		//cout << "plik sie otwiera."<<endl;
	}
}
*/

bool ListaBlokow::SprawdzKomendy()
{
	for (int i = 0; i < 4; i++)
	{
		if (ost4[i] != ZP[i])
			return false;
	}
	return true;
}

bool ListaBlokow::SprawdzGwiazdki()
{
	for (int i = 0; i < 4; i++)
	{
		if (ost4[i] != GW[i])
			return false;
	}
	return true;
}


void ListaBlokow::AktualizujOst4(char zn)
{
	ost4[0] = ost4[1];
	ost4[1] = ost4[2];
	ost4[2] = ost4[3];
	ost4[3] = zn;
}


void ListaBlokow::DodajZero(char tab[], int i)
{
	tab[i] = '\0';
}

void ListaBlokow::ParserCSS()
{
	selektormode = true;
	atrybutmode = false;
	komendymode = false;
	if (pierwszy == nullptr)
	{
		DodajBlok();
	}
	while (cssparser)
	{
		sameselektory = true;
		istniejeselektor = false;
		while (selektormode)
		{
			WczytajSelektor();
		}
		if(atrybutmode)												//
		{
			WczytajAtrybuty();										// on w sobie ma petle z while(atrybutmode)
		}
		if (istniejeselektor && !SprawdzKomendy() && !sameselektory)
		{
			ktoryindeks++;
			if (ktoryindeks == 8)
			{
				DodajBlok();
				ktoryblok++;
				ktoryindeks = 0;
			}
		}
	}
	if (komendymode)												// while?
	{
		Komendy();
	}
	if (zakonczprogram)
		return;
}

void ListaBlokow::WczytajSelektor()
{
	koniecsekcji = false;
	int i = 0;														//licznik miejsca w biezacej tablicy char
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		AktualizujOst4(znak);										// aktualizuje ostatnie 4 znaki
		if (SprawdzKomendy())										// jesli ostatnie 4 znaki to ????, przelaczam na wczytywanie komend
		{
			selektormode = false;
			atrybutmode = false;
			komendymode = true;
			cssparser = false;
			break;
		}

		if (znak == '{')											// poczatek atrybutow
		{
			if (istniejeselektor)									// jesli zapisalismy jakis selektor przed {, to zapiszmy go
			{
				if (txt[i - 1] == ' ')
					DodajZero(txt, i - 1);
				else
					DodajZero(txt, i);								// dodanie zera na koniec
				ListaDodajSelektor();								// dodanie ostatniego selektora z wymienionych
			}
			selektormode = false;
			atrybutmode = true;
			break;													// wyjdzmy z petli, po zmianie booli przechodzimy do atrybutmode
		}
		else if (znak == ',')										// kolejny selektor
		{
			DodajZero(txt, i);										// dodajmy zero			
			ListaDodajSelektor();									// dodajmy selektor sprzed spacji

			char charspacja;										// "zjadam" spacje po przecinku
			cin.get(charspacja);
			AktualizujOst4(znak);									// taktycznie aktualizuję ost4
			break;													// wyjdzmy z petli zeby znowu wczytac kolejny selektor
		}
		//else if (znak == '\n' || znak == '\0' || znak == '\x0b' || znak == '\t' || znak == '\v' || znak == '\r' || znak == '\f') // bialy znak
		else if (znak<32) // bialy znak
		{
			continue;												// skipuje tabulator i enter itp, zczytujemy kolejny znak
		}
		else
		{
			txt[i] = znak;											// dopisuje znak do nazwy selektora
			i++;
			istniejeselektor = true;
			if(dodanosekcje == false && SprawdzKomendy())
			{
				dodanosekcje = true;
			}
		}
	}
	// i = 0; ? gdybym mial wiekszy zasieg dla i
}

void ListaBlokow::ListaDodajSelektor()
{
	Blok* temp = pierwszy;
	int wezel = 1;
	while (wezel != ktoryblok)
	{
		wezel++;
		temp = temp->nastepny;
	}
	temp->DodajSelektorDoSekcjiNr(txt, ktoryindeks);
}

void ListaBlokow::WczytajAtrybuty()
{
	while(atrybutmode)
	{
		WczytajNazweAtrybutu();										// w srodku wywoluje sie WczytajWartoscAtrybutu()
	}
}

void ListaBlokow::WczytajNazweAtrybutu()
{
	int i = 0;
	konieclinii = false;
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		if (znak == '}')											// przypadek bez atrybutow
		{
			if(!sameselektory)
			{
				LICZNIKSEKCJI++;
			}
			else
			{
				UsunTaSekcje();
			}
			selektormode = true;
			atrybutmode = false;									// powinien wyjsc z petli w WczytajAtrybuty
			dodanosekcje = false;
			//cout << "Koniec sekcji" << endl;
			//cout << "Blok nr: " << ktoryblok <<", indeks: "<< ktoryindeks <<  endl;
			//ListaWypiszAtt();
			//cout << endl;
			break;
		}
		else if (znak < 32) // bialy znak
		{
			continue;												// skipuje tabulator i enter itp, zczytujemy kolejny znak
		}
		else if (znak == ':')
		{
			DodajZero(txt, i);
			Nadpisz1Tablice2(tempnazwa, txt, buffer);				// tempnazwa dostaje wartosc txt
			char charspacja;										// "zjemy" spacje po dwukropku
			cin.get(charspacja);
			WczytajWartoscAtrybutu();
			ListaDodajAtrybut();
			if (konieclinii == true)
			{
				//WypiszTablice(txt);
				break;
			}
			if(koniecsekcji)
			{
				if (!sameselektory)
					LICZNIKSEKCJI++;
				else
				{
					UsunTaSekcje();
				}
				selektormode = true;
				atrybutmode = false;
				dodanosekcje = false;
				//cout << "Koniec sekcji" << endl;
				//cout << "Blok nr: " << ktoryblok << ", indeks: " << ktoryindeks << endl;
				//ListaWypiszAtt();
				//cout << endl;
				break;												// wychodzimy z petli w WczytajAtrybuty
			}
		}
		else
		{
			sameselektory = false;
			txt[i] = znak;											// dopisuje znak do nazwy atrybutu
			i++;
		}
	}
}

void ListaBlokow::WczytajWartoscAtrybutu()							// teraz txt[] bedzie wartoscia
{
	int i = 0;
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		if (znak < 32)
			continue;
		else if (znak == '}')
		{
			DodajZero(txt, i);
			konieclinii = false;
			koniecsekcji = true;
			break;
		}
		else if (znak == ';')
		{
			konieclinii = true;
			DodajZero(txt, i);
			break;
		}
		else														//  dopisuje znak do wartosci atrybutu
		{
			txt[i] = znak;
			i++;
		}
	}
}

void ListaBlokow::UsunTaSekcje()
{
	Blok* temp = pierwszy;
	int licznik = 0;
	if (ktoryblok == 1)
		temp->t[ktoryindeks]->UsunSelektory();
	else
	{
		while (temp)
		{
			if (licznik == ktoryblok)
			{
				temp->t[ktoryindeks]->UsunSelektory();
				break;
			}
			licznik++;
			temp = temp->nastepny;
		}
	}
}

void ListaBlokow::ListaDodajAtrybut()
{
	//ktora->dodajAtrybut(nazwaAt, wartoscAt);						// moglbym to zrobic wskaznikiem
	Blok* temp = pierwszy;
	int wezel = 1;
	while (wezel != ktoryblok)
	{
		wezel++;
		temp = temp->nastepny;
	}
	//WypiszTablice(tempnazwa);
	//WypiszTablice(txt);
	//cout << ktoryindeks;
	//cout << endl;
	temp->DodajAtrybutDoSekcjiNr(tempnazwa, txt, ktoryindeks);
}

void ListaBlokow::ListaWypiszAtt()
{
	Blok* temp = pierwszy;
	int wezel = 1;
	while (wezel != ktoryblok)
	{
		wezel++;
		temp = temp->nastepny;
	}
	cout << "Selektory:" << endl;
	temp->t[ktoryindeks]->WypiszSelektory();
	cout << "Atrybuty: " << endl;
	temp->t[ktoryindeks]->WypiszAtrybuty();
}

void ListaBlokow::DodajBlok()
{
	Blok* nowy = new Blok;

	if (pierwszy == nullptr)										// jesli nie ma jeszcze blokow
	{
		pierwszy = nowy;
	}
	else															// dodawanie bloku na koniec
	{
		Blok* temp = pierwszy;
		while (temp->nastepny)
		{
			temp = temp->nastepny;
		}
		temp->nastepny = nowy;
		nowy->poprzedni = temp;
		nowy->nastepny = nullptr;
	}
	LICZNIKBLOKOW++;
}

void ListaBlokow::Komendy()
{
	WczytajKomendy();
	if (zakonczprogram)
		return;
	ParserCSS();
}

void ListaBlokow::WczytajKomendy()
{
	//cout << endl << "wczytuje komendy";
	while(true)
	{
		znakzapytania = false;
		WczytajKomendep1();
		if (cssparser)
			break;
		if (znakzapytania)
		{
			Komenda_Q();
		}
		else
		{
			WczytajKomendep2();
			WczytajKomendep3();
			if (zakonczprogram)
				break;
			WykonajKomende(cmd1, cmd2, cmd3);
		}
		if (zakonczprogram)
		{
			break;
		}
	}
}

void ListaBlokow::WczytajKomendep1()
{
	int i = 0;
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		AktualizujOst4(znak);										// aktualizuje ostatnie 4 znaki
		if (SprawdzGwiazdki())										// jesli ostatnie 4 znaki to ****, przelaczam na parsowanie CSSa
		{
			selektormode = false;
			komendymode = false;									// komendymode chyba nie trzeba tu znowu falsowac
			cssparser = true;
			break;
		}

		if (znak == '?')
		{
			znakzapytania = true;
			break;
		}

		if (znak == ',')
		{
			DodajZero(cmd1, i);
			break;
		}
		if (znak < 32)
			continue;
		else
		{
			cmd1[i] = znak;
			i++;
		}
	}
}

void ListaBlokow::WczytajKomendep2()
{
	int i = 0;
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		if (znak == ',')
		{
			DodajZero(cmd2, i);
			break;
		}
		else
		{
			cmd2[i] = znak;
			i++;
		}
	}
}

void ListaBlokow::WczytajKomendep3()
{
	int i = 0;
	char znak;
	while (true)
	{
		znak = getchar();
		if (znak == EOF)
		{
			zakonczprogram = true;
			break;
		}
		if (znak == '\n' || znak == '\r')
		{
			DodajZero(cmd3, i);
			break;
		}
		else
		{
			cmd3[i] = znak;
			i++;
		}
	}
}

void ListaBlokow::WykonajKomende(char tab1[], char tab2[], char tab3[])
{
								//______________________________________________
	if (tab1[0] >= 48 && tab1[0] <= 57)								// i,_,_	|	
	{																//________	|
		if (TeSame(tab2, tabA, buffer))								// i,A,_  | |
		{															//........| |
			if (TeSame(tab3, tabQ, buffer))							//		  | |
			{														//		  | |
				Komenda_iAQ(atoi(tab1));							// i,A,? <| |
			}														//		  | |
			else													//		  | |
			{														//		  | |
				Komenda_iAn(atoi(tab1), tab3);										// i,A,n <|	|
			}														//________| |
		}															//		    |
		else														//		    |
		{															//________	|
			if (TeSame(tab2, tabS, buffer))							// i,S,_  | |
			{														//........| |
				if (TeSame(tab3, tabQ, buffer))						//		  | |
				{													//		  | |
					Komenda_iSQ(atoi(tab1));						// i,S,? <| |
				}													//		  | |
				else 												//        | |
				{													//        | |
					Komenda_iSj(atoi(tab1),atoi(tab3));				// i,S,j <| |
				}													//________| |
			}														//          |
			else 													//________	|
			{														// i,D,_  | |
				if (TeSame(tab3, tabG, buffer))						//........| |											// i,D,_  | |
				{													//        | |
					Komenda_iDG(atoi(tab1));						// i,D,* <| |
				}													//        | |
				else												//		  | |
				{													//        | |
					Komenda_iDn(atoi(tab1),tab3);									// i,D,n <| |
				}													//________| |
			}//															        |
		}//_____________________________________________________________________|
	}	 //_____________________________________________________________________
	else															//_,_,_		|
	{																//________  |
		if (TeSame(tab3, tabQ, buffer))								// _,_,?  | |
		{															//........| |
			if (TeSame(tab2, tabS, buffer))							//		  | |
			{														//		  | |
				Komenda_zSQ(tab1);									// z,S,? <| |
			}														//		  | |
			else													//		  | |
			{														//		  | |
				Komenda_nAQ(tab1);									// n,A,? <| |
			}														//		  | |
		}															//		  | |
		else														//________| |
		{															//________  |
			Komenda_zEn(tab1,tab3);									// z,E,n  | |
		}//															//________| |
	}//_________________________________________________________________________|
}

void ListaBlokow::Komenda_Q()
{
	cout << "? == " << LICZNIKSEKCJI << endl;
}

void ListaBlokow::Komenda_iSQ(int i)
{
	//int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int j = 0; j < ilosc; j++)
		{
			if (!temp->t[j]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[j]->ZliczWypiszSelektory(i);
				return;
			}
		}
		temp = temp->nastepny;
	}
}

void ListaBlokow::Komenda_iAQ(int i)
{
	//int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int j = 0; j < ilosc; j++)
		{
			if (!temp->t[j]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[j]->ZliczWypiszAtrybuty(i);
				return;
			}
		}
		temp = temp->nastepny;
	}
}

void ListaBlokow::Komenda_iSj(int i, int j)
{
	//int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int k = 0; k < ilosc; k++)
		{
			if (!temp->t[k]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[k]->WypiszJtySelektor(i, j);
				return;
			}
		}
		temp = temp->nastepny;
	}
}

void ListaBlokow::Komenda_iAn(int i, char n[])
{
	//int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int j = 0; j < ilosc; j++)
		{
			if (!temp->t[j]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[j]->WypiszWartoscAtrybutuONazwie(i, n);
				return;
			}
		}
		temp = temp->nastepny;
	}
}

void ListaBlokow::Komenda_nAQ(char n[])
{
	int suma = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int k = 0; k < ilosc; k++)
		{
			if(!temp->t[k]->dousuniecia)
			{
				if (temp->t[k]->pierwszyAt != nullptr && temp->t[k]->CzyJestAtrybutONazwie(n))
					suma++;
			}
		}
		temp = temp->nastepny;
	}
	WypiszTablice(n);
	cout << ",A,? == " << suma << endl;
}

void ListaBlokow::Komenda_zSQ(char z[])
{
	int suma = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int k = 0; k < ilosc; k++)
		{
			if(!temp->t[k]->dousuniecia)
			{
				if (temp->t[k]->pierwszySe != nullptr && temp->t[k]->CzyJestSelektorONazwie(z))
					suma++;
			}
		}
		temp = temp->nastepny;
	}
	WypiszTablice(z);
	cout << ",S,? == " << suma << endl;
}

void ListaBlokow::Komenda_zEn(char z[], char n[])
{
	char war[buffer];
	bool znaleziono = false;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int k = 0; k < ilosc; k++)
		{
			if(!temp->t[k]->dousuniecia)
			{
				if (temp->t[k]->pierwszySe != nullptr && temp->t[k]->CzyJestSelektorONazwie(z))
				{
					if (temp->t[k]->pierwszyAt != nullptr && temp->t[k]->CzyJestAtrybutONazwie(n))
					{
						Nadpisz1Tablice2(war, temp->t[k]->WartoscAtrybutuONazwie(n), buffer);
						znaleziono = true;
					}
				}
			}
		}
		temp = temp->nastepny;
	}
	if (znaleziono)
	{
		WypiszTablice(z);
		cout << ",E,";
		WypiszTablice(n);
		cout << " == ";
		WypiszTablice(war);
		cout << endl;
	}
}

void ListaBlokow::Komenda_iDG(int i) // usun cala sekcje nr i
{
	int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int j = 0; j < ilosc; j++)
		{
			if (!temp->t[j]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[j]->UsunSekcje();
				if (temp->CzyBlokJestPusty())
				{
					UsunBlok(kb);
					LICZNIKBLOKOW--;
				}
				LICZNIKSEKCJI--;
				cout << i << ",D,* == deleted" << endl;
				return;
			}
		}
		temp = temp->nastepny;
	}
}

void ListaBlokow::Komenda_iDn(int i, char n[])
{
	int kb = UstawKB(i);
	int licznik = 0;
	Blok* temp = pierwszy;
	while (temp)
	{
		for (int j = 0; j < ilosc; j++)
		{
			if (!temp->t[j]->dousuniecia)
				licznik++;
			if (licznik == i)
			{
				temp->t[j]->usunAtrybutONazwie(n);
				if (temp->t[j]->pierwszyAt == nullptr)
				{
					temp->t[j]->UsunSekcje();
					if (temp->CzyBlokJestPusty())
					{
						UsunBlok(kb);
						LICZNIKBLOKOW--;
					}
					LICZNIKSEKCJI--;
				}
				cout << i << ",D,";
				WypiszTablice(n);
				cout << " == deleted" << endl;
				return;
			}
		}
		temp = temp->nastepny;
	}
}

int ListaBlokow::UstawKB(int i)
{
	int kb;
	if (LICZNIKBLOKOW == 1)
		return 1;
	else kb = (i / ilosc) + 1;
	if (i > 0 && i % ilosc == 0) kb--;

	return kb;
}

void ListaBlokow::UsunBlok(int nr)
{
	int licznik = 1;
	Blok* temp = pierwszy;

	if (nr == 1)
	{
		pierwszy = temp->nastepny;
		temp->nastepny->poprzedni = nullptr;
		temp->WyczyscBlok();
		delete temp;
	}
	else
	{
		while (temp)
		{
			if (licznik + 1 == nr) break;
			temp = temp->nastepny;
			licznik++;
		}
		if (temp->nastepny->nastepny == nullptr)
		{
			temp->nastepny->WyczyscBlok();
			delete temp->nastepny;
			temp->nastepny = nullptr;
		}
		else
		{
			Blok* usuwany = temp->nastepny;
			temp->nastepny = temp->nastepny->nastepny;
			temp->nastepny->nastepny->poprzedni = temp;
			usuwany->WyczyscBlok();
			delete usuwany;
		}
	}
}