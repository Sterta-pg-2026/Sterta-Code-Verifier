#include "blok.h"
/*
Blok::Blok()
{
	for (int k = 0; k < ilosc; k++)
	{
		t[k] = new Sekcja;
	}
	poprzedni = nullptr;
	nastepny = nullptr;
}
*/

void Blok::DodajSelektorDoSekcjiNr(char n[], int miejsce)
{
	//cout << "dodaje selektor";
	t[miejsce]->dodajSelektor(n);
}

void Blok::DodajAtrybutDoSekcjiNr(char naz[], char wart[], int miejsce)
{
	//cout << "dodaje atrybut";
	t[miejsce]->dodajAtrybut(naz, wart);
}

bool Blok::CzyBlokJestPusty()
{
	for (int i = 0; i < ilosc; i++)
	{
		if (!t[i]->dousuniecia)
		{
			return false;
		}
	}
	return true;
}

void Blok::WyczyscBlok()
{
	for (int i = 0; i < ilosc; i++)
	{
		t[i]->UsunSekcje();
		delete t[i];
	}
	delete[] t;
}