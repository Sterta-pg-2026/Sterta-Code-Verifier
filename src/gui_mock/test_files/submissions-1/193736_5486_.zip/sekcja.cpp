﻿#include "Sekcja.h"


void Sekcja::dodajSelektor(char* nazwaSe)
{
	Selektor* nowy = new Selektor;
	Nadpisz1Tablice2(nowy->nazwa, nazwaSe, buffer);

	if (pierwszySe == nullptr)				//jesli nie ma jeszcze selektorow
	{
		pierwszySe = nowy;
		//ostatniSe = nowy;
	}
	else																									// dodawanie na koniec
	{
		Selektor* temp = pierwszySe;
		while (temp->nastepny)
		{
			if (TeSame(temp->nazwa, nazwaSe, buffer))														// jesli ten selektor juz jest
			{
				delete nowy;
				break;
			}
			temp = temp->nastepny;
		}
		temp->nastepny = nowy;
		nowy->poprzedni = temp;
		nowy->nastepny = nullptr;
		//ostatniSe = nowy;										//
	}
}

void Sekcja::dodajAtrybut(char* nazwaAt, char* wartoscAt)													// dodaje tam gdzie jest ta nazwa, tez zeby nadpisywac
{

	if (pierwszyAt == nullptr)																				//jesli nie ma jeszcze selektorow
	{

		Atrybut* nowy = new Atrybut;
		Nadpisz1Tablice2(nowy->nazwa, nazwaAt, buffer);
		Nadpisz1Tablice2(nowy->wartosc, wartoscAt, buffer);
		pierwszyAt = nowy;
	}
	else																									// dodawanie na koniec
	{
		if (TeSame(pierwszyAt->nazwa, nazwaAt, buffer))														// jesli pierwszy atrybut ma tą samą nazwę to nadpisujemy jego wartosc
		{
			//if (TeSame(pierwszyAt->wartosc, wartoscAt, buffer))
			//{
			//	return;
			//}
			Nadpisz1Tablice2(pierwszyAt->wartosc, wartoscAt, buffer);
			return;
		}
		Atrybut* temp = pierwszyAt;
		while (temp->nastepny)
		{
			if (TeSame(temp->nazwa, nazwaAt, buffer))														// jesli atrybut o tej nazwie juz jest, nadpisz jego wartosc
			{
				//if (TeSame(temp->wartosc, wartoscAt, buffer))
				//{
				//	delete nowy;
				//	return;
				//}
				Nadpisz1Tablice2(temp->wartosc, wartoscAt, buffer);
				return;
			}
			temp = temp->nastepny;
		}

		if (TeSame(temp->nazwa, nazwaAt, buffer))
		{
			Nadpisz1Tablice2(temp->wartosc, wartoscAt, buffer);
			return;
		}

		Atrybut* nowy = new Atrybut;
		Nadpisz1Tablice2(nowy->nazwa, nazwaAt, buffer);
		Nadpisz1Tablice2(nowy->wartosc, wartoscAt, buffer);
		temp->nastepny = nowy;
		nowy->poprzedni = temp;
		nowy->nastepny = nullptr;
		//ostatniAt = nowy;
	}
	dousuniecia = false;
	// juz nie jest pusta
}

/*
void Sekcja::dodajAtrybut(char* nazwaAt, char* wartoscAt)
{
	Atrybut* temp = pierwszyAt;
	if (pierwszyAt == nullptr)																				//jesli nie ma jeszcze selektorow
	{
		Atrybut* nowy = new Atrybut;
		pierwszyAt = nowy;
	}
	else
	{
		while (temp->nastepny)
		{
			if (TeSame(temp->nazwa, nazwaAt, buffer))
			{
				Nadpisz1Tablice2(temp->wartosc, wartoscAt, buffer);
				return;
			}
			temp = temp->nastepny;
		}
		Atrybut* nowy = new Atrybut;

		temp->nastepny = nowy;
		nowy->poprzedni = temp;
	}
}
*/

void Sekcja::usunAtrybutONazwie(char* nazwaAt)
{
	Atrybut* temp = pierwszyAt;

	if (pierwszyAt == nullptr)							// pusta lista?
	{
		return;
	}

	if (TeSame(temp->nazwa, nazwaAt, buffer))			// jesli usuwam pierwszy
	{
		if (temp->nastepny == nullptr)					// jesli usuwam jedyny element
		{
			pierwszyAt = temp->nastepny;
			delete temp;
		}
		else
		{
			pierwszyAt->poprzedni = nullptr;
			pierwszyAt = temp->nastepny;
			delete temp;
		}
	}
	else												// jesli usuwam inny niz pierwszy
	{
		while (temp)
		{
			if (TeSame(temp->nastepny->nazwa, nazwaAt, buffer))	// nie zalozylem przypadku ze nie znajde pasujacego
			{
				// if(temp->nastepny == ostatniAt)     to to samo
				if (temp->nastepny->nastepny == nullptr)		//jesli usuwam ostatni
				{
					delete temp->nastepny;
					temp->nastepny = nullptr;
					//ostatniAt = temp;							// chyba git
				}
				else
				{
					Atrybut* usuwany = temp->nastepny;
					temp->nastepny = temp->nastepny->nastepny;
					temp->nastepny->nastepny->poprzedni = temp;
					delete usuwany;
				}
				break;
			}
			temp = temp->nastepny;
		}
	}
}

void Sekcja::ZliczWypiszSelektory(int i)
{
	if (pierwszySe == nullptr)
	{
		cout << i << ",S,? == 0" << endl;
	}
	else
	{
		int suma = 1;
		Selektor* temp = pierwszySe;
		while (temp->nastepny)
		{
			suma++;
			temp = temp->nastepny;
		}
		cout << i << ",S,? == " << suma << endl;
	}
}

void Sekcja::ZliczWypiszAtrybuty(int i)
{
	if (pierwszyAt == nullptr)
	{
		cout << i << ",A,? == 0" << endl;
	}
	else
	{
		int suma = 1;
		Atrybut* temp = pierwszyAt;
		while (temp->nastepny)
		{
			suma++;
			temp = temp->nastepny;
		}
		cout << i << ",A,? == " << suma << endl;
	}
}

void Sekcja::WypiszJtySelektor(int liczba, int nr)
{
	int licznik = 1;
	Selektor* temp = pierwszySe;

	if (nr == 1)
	{
		cout << liczba << ",S," << nr << " == ";
		WypiszTablice(temp->nazwa);
		cout << endl;
	}
	else
	{
		while (temp)
		{
			if (licznik + 1 == nr)
			{
				if(temp->nastepny != nullptr)
				{
					cout << liczba << ",S," << nr << " == ";
					WypiszTablice(temp->nastepny->nazwa);	// to dodalem
					cout << endl;							// i to
					break;
				}
			}
			temp = temp->nastepny;
			licznik++;
		}
		// wskaznik temp wskazuje teraz na selektor nr-1 -ty
		//WypiszTablice(temp->nastepny->nazwa);
		//cout << endl;
	}
}

void Sekcja::WypiszWartoscAtrybutuONazwie(int i, char naz[])
{
	Atrybut* temp = pierwszyAt;

	if (TeSame(temp->nazwa, naz, buffer))
	{
		cout << i << ",A," << naz << " == ";
		WypiszTablice(temp->wartosc);
		cout << endl;
	}
	else
	{
		while (temp->nastepny)
		{
			if (TeSame(temp->nastepny->nazwa, naz, buffer))
			{
				cout << i << ",A," << naz << " == ";
				WypiszTablice(temp->nastepny->wartosc);
				cout << endl;
				break;
			}
			temp = temp->nastepny;
		}
	}
}

char* Sekcja::WartoscAtrybutuONazwie(char naz[])
{
	Atrybut* temp = pierwszyAt;

	if (TeSame(temp->nazwa, naz, buffer))
	{
		return temp->wartosc;
	}
	else
	{
		while (temp->nastepny)
		{
			if (TeSame(temp->nastepny->nazwa, naz, buffer))
			{
				return temp->nastepny->wartosc;
			}
			temp = temp->nastepny;
		}
	}
	return NULL;
	// moze bez returna jesli nie znajdzie ??
}

bool Sekcja::CzyJestAtrybutONazwie(char naz[])
{
	Atrybut* temp = pierwszyAt;

	if (TeSame(temp->nazwa, naz, buffer))
	{
		return true;
	}
	else
	{
		while (temp->nastepny)
		{
			if (TeSame(temp->nastepny->nazwa, naz, buffer))
			{
				return true;
			}
			temp = temp->nastepny;
		}
	}
	return false;
}

bool Sekcja::CzyJestSelektorONazwie(char naz[])
{
	Selektor* temp = pierwszySe;
	if (TeSame(temp->nazwa, naz, buffer))
	{
		return true;
	}
	else
	{
		while (temp->nastepny)
		{
			if (TeSame(temp->nastepny->nazwa, naz, buffer))
			{
				return true;
			}
			temp = temp->nastepny;
		}
	}
	return false;
}

void Sekcja::UsunSekcje()
{
	UsunSelektory();
	UsunAtrybuty();
}

void Sekcja::UsunSelektory()			// jest git chyba ze mam zachowac pierwszy
{
	while (pierwszySe != nullptr)
	{
		Selektor* temp = pierwszySe->nastepny;
		delete pierwszySe;
		pierwszySe = temp;
	}
}

void Sekcja::UsunAtrybuty()			// jest git chyba ze mam zachowac pierwszy
{
	while (pierwszyAt != nullptr)
	{
		Atrybut* temp = pierwszyAt->nastepny;
		delete pierwszyAt;
		pierwszyAt = temp;
	}
	dousuniecia = true;
}

void Sekcja::WypiszSelektory()
{
	
	Selektor* temp = pierwszySe;
	while (temp)
	{
		cout << "`";
		WypiszTablice(temp->nazwa);
		cout << "`";
		temp = temp->nastepny;
	}
}

void Sekcja::WypiszAtrybuty()
{
	
	Atrybut* temp = pierwszyAt;
	while (temp)
	{
		WypiszTablice(temp->nazwa);
		cout << ": ";
		WypiszTablice(temp->wartosc);
		cout << endl;
		temp = temp->nastepny;
	}
}