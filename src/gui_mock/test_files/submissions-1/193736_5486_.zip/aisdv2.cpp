#include <iostream>
#include "listaglowna.h"
#include <cstdlib>

using namespace std;

int main()
{
	ListaBlokow* lista = new ListaBlokow;
	lista->ParserCSS();
	delete lista;
	return 0;
}