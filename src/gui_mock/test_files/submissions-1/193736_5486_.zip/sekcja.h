#pragma once
#include <iostream>
#include "atrybut.h"
#include "selektor.h"
#include "funkcje.h"
using namespace std;

class Sekcja {
public:
	Selektor* pierwszySe;
	//Selektor* ostatniSe;
	Atrybut* pierwszyAt;
	//Atrybut* ostatniAt;
	Sekcja()
	{
		pierwszySe = nullptr;
		//ostatniSe = nullptr;
		pierwszyAt = nullptr;
		//ostatniAt = nullptr;
		dousuniecia = true;
	};
	bool dousuniecia;

	void dodajSelektor(char* nazwaSe);
	void dodajAtrybut(char* nazwaAt, char* wartoscAt);
	void usunAtrybutONazwie(char* nazwaAt);


	void ZliczWypiszSelektory(int i);
	void ZliczWypiszAtrybuty(int i);
	void WypiszJtySelektor(int l, int nr);
	void WypiszWartoscAtrybutuONazwie(int i, char naz[]);
	char* WartoscAtrybutuONazwie(char naz[]);
	bool CzyJestAtrybutONazwie(char naz[]);
	bool CzyJestSelektorONazwie(char naz[]);

	void UsunSekcje();
	void UsunSelektory();
	void UsunAtrybuty();

	void WypiszSelektory();
	void WypiszAtrybuty();
};