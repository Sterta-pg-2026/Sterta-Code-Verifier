#include "atrybut.h"
/*
Atrybut::Atrybut()
{
	poprzedni = nullptr;
	nastepny = nullptr;
}*/