#pragma once
#include<iostream>
using namespace std;

#define buffer 256
#define ilosc 17
#define malybuffer 4

void Nadpisz1Tablice2(char tab1[], char tab2[], int buff);
bool TeSame(char tab1[], char tab2[], int buff);
void WypiszTablice(char tab[]);