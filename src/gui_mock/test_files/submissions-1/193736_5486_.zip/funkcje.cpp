#include "funkcje.h"

void Nadpisz1Tablice2(char tab1[], char tab2[], int buff)
{
	for (int i = 0; i < buff; i++)
	{
		tab1[i] = tab2[i];
		if (tab2[i] == '\0')
			break;
	}
}

bool TeSame(char tab1[], char tab2[], int buff)
{
	for (int i = 0; i < buff; i++)
	{
		if (tab1[i] != tab2[i])
		{
			return false;
		}
		if (i > 0 && tab1[i] == '\0' && tab2[i] == '\0')
			break;
	}
	return true;
}

void WypiszTablice(char tab[])
{
	for (int i = 0; i < buffer; i++)
	{
		if (tab[i] == '\0')
			break;
		cout << tab[i];
	}
}