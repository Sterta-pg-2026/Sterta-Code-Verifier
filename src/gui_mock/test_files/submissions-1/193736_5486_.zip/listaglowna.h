#pragma once
#include <iostream>
#include <fstream>
#include "blok.h"
using namespace std;

class ListaBlokow {
public:
	Blok* pierwszy;
	ListaBlokow()
	{
		zakonczprogram = false;

		pierwszy = nullptr;
		cssparser = true;
		selektormode = false;
		atrybutmode = false;
		komendymode = false;
		istniejeselektor = false;
		konieclinii = false;
		koniecsekcji = false;
		dodanosekcje = false;
		znakzapytania = false;
		sameselektory = false;
		LICZNIKSEKCJI = 0;
		LICZNIKBLOKOW = 0;
		ktoryblok = 1;
		ktoryindeks = 0;

		//plik.open("1.in");
		//if (plik.is_open())
		//{
			//cout << "plik sie otwiera."<<endl;
		//}
	}
	void DodajBlok();
	void UsunBlok(int nr);

	bool zakonczprogram;

	bool cssparser;
	bool selektormode;
	bool atrybutmode;
	bool komendymode;
	bool istniejeselektor;
	bool konieclinii;
	bool koniecsekcji;
	bool dodanosekcje;
	bool znakzapytania;
	bool sameselektory;
	int LICZNIKSEKCJI;
	int LICZNIKBLOKOW;
	int ktoryblok;
	int ktoryindeks;
	char txt[buffer];
	char tempnazwa[buffer];
	char cmd1[buffer];
	char cmd2[buffer];
	char cmd3[buffer];
	char ZP[4] = { '?','?','?','?' };
	char GW[4] = { '*','*','*','*' };
	char ost4[4] = { '0','0','0','0' };
	char tabi[2] = { 'i', '\0' };
	char tabS[2] = { 'S', '\0' };
	char tabA[2] = { 'A', '\0' };
	char tabE[2] = { 'E', '\0' };
	char tabD[2] = { 'D', '\0' };
	char tabQ[2] = { '?', '\0' };
	char tabG[2] = { '*', '\0' };

	void AktualizujOst4(char zn);
	bool SprawdzKomendy();
	bool SprawdzGwiazdki();
	void DodajZero(char tab[], int i);

	fstream plik;

	void ListaDodajSelektor();
	void ListaDodajAtrybut();
	void ListaWypiszAtt();
	void UsunTaSekcje();

	void ParserCSS();
	void Komendy();

	void WczytajSelektor();
	void WczytajAtrybuty();
	void WczytajNazweAtrybutu();
	void WczytajWartoscAtrybutu();

	void WczytajKomendy();
	void WczytajKomendep1();
	void WczytajKomendep2();
	void WczytajKomendep3();
	void WykonajKomende(char tab1[], char tab2[], char tab3[]);


	// komendy
	void Komenda_Q();						// ?
	void Komenda_iSQ(int i);				// i,S,?
	void Komenda_iAQ(int i);				// i,A,?
	void Komenda_iSj(int i, int j);			// i,S,j
	void Komenda_iAn(int i, char n[]);		// i,A,n
	void Komenda_nAQ(char n[]);				// n,A,?
	void Komenda_zSQ(char z[]);				// z,S,?
	void Komenda_zEn(char z[], char n[]);	// z, E, n
	void Komenda_iDG(int i);				// i,D,*
	void Komenda_iDn(int i, char n[]);		// i,D,n

	int UstawKB(int i);
};