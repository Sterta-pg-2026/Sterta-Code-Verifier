#pragma once
#include <iostream>
#include "sekcja.h"
using namespace std;

class Blok {
public:
	Sekcja** t = new Sekcja* [ilosc];
	Blok* poprzedni;
	Blok* nastepny;
	Blok()
	{
		for (int k = 0; k < ilosc; k++)
		{
			t[k] = new Sekcja;
		}
		poprzedni = nullptr;
		nastepny = nullptr;
	}
	void DodajSelektorDoSekcjiNr(char n[], int miejsce);
	void DodajAtrybutDoSekcjiNr(char naz[], char wart[], int miejsce);

	bool CzyBlokJestPusty();

	void WyczyscBlok();
};