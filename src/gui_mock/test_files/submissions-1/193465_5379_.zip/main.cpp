#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

using namespace std;

const int NUMBER_OF_NODES_TO_ALLOCATE = 8;

template <typename T> class Node {

public:
    T data;
    Node<T>* next;
    Node<T>* prev;

    Node<T>() {
        next = nullptr;
        prev = nullptr;
    }
};

template <typename T> class DoublyLinkedList {
private:
    void allocateNodes() {
        int nodesCreated = 0;
        if (size == 0)
        {
            head = new Node<T>();
            nodesCreated++;
        }

        Node<T>* temp = head;
        while (true) {
            if (temp->next == nullptr)
            {
                temp->next = new Node<T>();
                temp->next->prev = temp;
                nodesCreated++;

                if (nodesCreated == NUMBER_OF_NODES_TO_ALLOCATE)
                {
                    this->nodesCreated += nodesCreated;
                    return;
                }
            }
            temp = temp->next;
        }
    }

public:
    Node<T>* head;
    int size = 0;
    int nodesCreated = 0;

    DoublyLinkedList() {
        allocateNodes();
    }

    Node<T>* getNodeAtIndex(int index) {
        if (index > size)
        {
            return nullptr;
        }

        Node<T>* temp = head;
        for (int i = 0; i < index; i++)
        {
            temp = temp->next;
        }
        return temp;
    }

    void Add(T data) {
        if (size >= nodesCreated)
        {
            allocateNodes();
        }

        Node<T>* temp = head;
        if (size == 0)
        {
            temp->data = data;
        }
        else {
            temp = getNodeAtIndex(size);
            temp->data = data;
        }
        size++;
    }

    bool Delete(int index) {
        Node<T>* temp = getNodeAtIndex(index);
        if (index >= size) {
            return false;
        }
        if (size == 1) {
            temp->data = T();
        } 
        else if (index == 0)
        {
            head = head->next;
            nodesCreated--;
        }
        else if (index == size - 1) {
            temp->data = T();
        } else {
            temp->next->prev = temp->prev;
            temp->prev->next = temp->next;
            nodesCreated--;
        }
        size--;
        return true;
    }

    void DeleteAll() {
        Node<T>* temp = head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
            delete temp->prev;
        }
        delete temp;
    }

//    void Print() {
//       Node<T>* temp = head;
//
//        for (int i = 0; i < size; i++)
//        {
//            cout << temp->data << endl;
//            temp = temp->next;
//        }
//    }
};

template <typename T> class LinkedList {
public:
    Node<T>* head;
    int size = 0;

    LinkedList() {
        head = new Node<T>();
    }

    Node<T>* getNodeAtIndex(int index) {
        if (index >= size)
        {
            return nullptr;
        }

        Node<T>* temp = head;
        for (int i = 0; i < index; i++)
        {
            temp = temp->next;
        }
        return temp;
    }

    void Add(T data) {
        if (size == 0)
        {
            head->data = data;
        }
        else {
            Node<T>* temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            Node<T>* newNode =  new Node<T>();
            newNode->data = data;
            temp->next = newNode;
            newNode->prev = temp;
        }
        size++;
    }

    bool Delete(int index) {
        Node<T>* temp = getNodeAtIndex(index);
        if (index >= size) {
            return false;
        }
        if (size == 1) {
            temp->data = T();
        }
        else if (index == 0)
        {
            head = head->next;
        }
        else if (index == size - 1) {
            temp->data = T();
        }
        else {
            temp->next->prev = temp->prev;
            temp->prev->next = temp->next;
        }
        size--;
        return true;
    }

    void DeleteAll() {
        Node<T>* temp = head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
            delete temp->prev;
        }
        delete temp;
    }

    //    void Print() {
    //       Node<T>* temp = head;
    //
    //        for (int i = 0; i < size; i++)
    //        {
    //            cout << temp->data << endl;
    //            temp = temp->next;
    //        }
    //    }
};

class MyString {
public:
    const char* text;

    friend std::ostream& operator<<(std::ostream& os, const MyString& mString) {
        os << mString.text;
        return os;
    }

    MyString() {
        this->text = "\0";
    }

    MyString(const char* text) {
        this->text = text;
    }

    void Print() {
        cout << text;
    }

    int Length() {
        int len = 0;
        while (text[len] != '\0')
        {
            len++;
        }
        return len;
    }

    bool Equals(MyString string) {
        if (string.Length() != Length())
        {
            return false;
        }
        for (int i = 0; i < Length(); i++)
        {
            if (text[i] != string.text[i])
            {
                return false;
            }
        }
        return true;
    }

    //index of 'character' or -1 if not found
    int getFirstAppearence(char character) {
        int i = 0;
        while (text[i] != '\0')
        {
            if (text[i] == character)
            {
                return i;
            }
            i++;
        }
        return -1;
    }

    int getFirstAppearence(MyString charSeq) {
        int charSeqLen = charSeq.Length();
        int i = 0;
        while (text[i] != '\0')
        {
            bool match = true;
            for (int j = 0; j < charSeqLen; j++)
            {
                if (text[i + j] != charSeq.text[j])
                {
                    match = false;
                }
            }
            if (match) return i;
            i++;
        }
        return -1;
    }

    int getNthAppearence(int n, char character) {
        int whichAppearence = 0;
        int i = 0;
        while (text[i] != '\0')
        {
            if (text[i] == character)
            {
                whichAppearence++;
                if (whichAppearence == n)
                {
                    return i;
                }
            }
            i++;
        }
        return -1;
    }

    int getNumberOfAppearences(char character) {
        int whichAppearence = 0;
        int i = 0;
        while (text[i] != '\0')
        {
            if (text[i] == character)
            {
                whichAppearence++;
            }
            i++;
        }
        return whichAppearence;
    }

    const char* CutOut(int begining, int end) {
        if (begining > end)
        {
            return "\0";
        }
        int length = end - begining + 1; // begining and end inclusive (+1) 
        char* newString = new char[length + 1]; // and '\0' (+1)
        
        int i = 0;

        while (i < length)
        {
            newString[i] = text[i + begining];
            i++;
        }
        newString[length] = '\0';
        return newString;
    }

    const char* Trim() {
        char* newString = new char[Length() + 1];
        int newStringIterator = 0;
        for (int i = 0; i < Length(); i++)
        {
            if (text[i] > ' ')
            {
                newString[newStringIterator] = text[i];
                newStringIterator++;
            }
        }
        newString[newStringIterator] = '\0';
        return newString;
    }

    const char* TrimLeftRight() {
        int i = 0;
        while (i < Length())
        {
            if (text[i] <= ' ')
            {
                i++;
            }
            else {
                break;
            }
        }

        int j = Length() - 1;
        while (j >= 0) {
            if (text[j] <= ' ')
            {
                j--;
            }
            else {
                break;
            }
        }
        return CutOut(i, j);
    }

    bool IsANumber() {
        for (int i = 0; i < Length(); i++)
        {
            if (text[i] < '0' || text[i] > '9')
            {
                return false;
            }
        }
        return true;
    }

    int ToInt() {
        int number = 0;
        for (int i = 0; i < Length(); i++)
        {
            number += (text[i] - '0') * pow(10, Length() - i - 1);
        }
        return number;
    }

    DoublyLinkedList<MyString> SplitD(MyString text, char character) {
        DoublyLinkedList<MyString> list = DoublyLinkedList<MyString>();
        int nextCharIndex = text.getFirstAppearence(character);
        while (nextCharIndex != -1) {
            list.Add(text.CutOut(0, nextCharIndex - 1));
            text = text.CutOut(nextCharIndex + 1, text.Length());
            nextCharIndex = text.getFirstAppearence(character);
        }
        if (MyString(text.TrimLeftRight()).Length() > 0)
        {
            list.Add(text);
        }
        return list;
    }

    LinkedList<MyString> Split(MyString text, char character) {
        LinkedList<MyString> list = LinkedList<MyString>();
        int nextCharIndex = text.getFirstAppearence(character);
        while (nextCharIndex != -1) {
            list.Add(text.CutOut(0, nextCharIndex - 1));
            text = text.CutOut(nextCharIndex + 1, text.Length());
            nextCharIndex = text.getFirstAppearence(character);
        }
        if (MyString(text.TrimLeftRight()).Length() > 0)
        {
            list.Add(text);
        }
        return list;
    }
};

class Selectors {
private:

    bool deleteDuplicates() {
        for (int i = 0; i < selectorList.size; i++)
        {
            for (int j = 0; j < selectorList.size; j++)
            {
                if (i != j)
                {
                    if (selectorList.getNodeAtIndex(i)->data.Equals(selectorList.getNodeAtIndex(j)->data))
                    {
                        selectorList.Delete(i);
                        return true;
                    }
                }
            }
        }
        return false;
    }

public:
    LinkedList<MyString> selectorList;

    Selectors(MyString input) {
        selectorList = input.Split(input, ',');
        for (int i = 0; i < selectorList.size; i++)
        {
            selectorList.getNodeAtIndex(i)->data = selectorList.getNodeAtIndex(i)->data.TrimLeftRight();
        }

        bool keepDeleting = true;
        while (keepDeleting) {
            keepDeleting = deleteDuplicates();
        }
    }
};

class Atributes {
private:

    bool deleteDuplicates() {
        for (int i = 0; i < atributeList.size; i++)
        {
            for (int j = 0; j < atributeList.size; j++)
            {
                if (i != j)
                {
                    if (getAtributeName(i).Equals(getAtributeName(j)))
                    {
                        atributeList.Delete(i);
                        return true;
                    }
                }
            }
        }
        return false;
    }

public:
    LinkedList<MyString> atributeList;

    Atributes(MyString input) {
        atributeList = input.Split(input, ';');
        
        for (int i = 0; i < atributeList.size; i++)
        {
            atributeList.getNodeAtIndex(i)->data = atributeList.getNodeAtIndex(i)->data.TrimLeftRight();
        }

        bool keepDeleting = true;
        while (keepDeleting) {
            keepDeleting = deleteDuplicates();
        }
    }

    MyString getAtributeValue(MyString name) {
        for (int i = 0; i < atributeList.size; i++)
        {
            if (atributeList.getNodeAtIndex(i)->data.getFirstAppearence(name) != -1) {
                MyString value = atributeList.getNodeAtIndex(i)->data.CutOut(atributeList.getNodeAtIndex(i)->data.getFirstAppearence(':') + 1, atributeList.getNodeAtIndex(i)->data.Length());
                return value.TrimLeftRight();
            }
        }
        return "\0";
    }

    MyString getAtributeName(int index) {
        MyString name = atributeList.getNodeAtIndex(index)->data.CutOut(0, atributeList.getNodeAtIndex(index)->data.getFirstAppearence(':') - 1);
        return name.TrimLeftRight();
    }

    bool deleteAtributeByName(MyString name) {
        for (int i = 0; i < atributeList.size; i++)
        {
            if (atributeList.getNodeAtIndex(i)->data.getFirstAppearence(name) != -1) {
                atributeList.Delete(i);
                return true;
            }
        }
        return false;
    }
};

class CSSBlock {
public:
    Selectors* selectors;
    Atributes* atributes;

    CSSBlock(MyString input) {
        MyString selectorsInput = input.CutOut(0, input.getFirstAppearence('{') - 1);
        selectors = new Selectors(selectorsInput);

        MyString atributesInput = input.CutOut(input.getFirstAppearence('{') + 1, input.Length() - 1);
        atributes = new Atributes(atributesInput);
    }

    CSSBlock() {
        
    }
};

int findEndOfCSSBlock(MyString input) {
    int firstCloseBraceIndex = input.getFirstAppearence('}');
    MyString potentialFirstBlock = input.CutOut(0, firstCloseBraceIndex - 1);
    int numberOfOpenBraces = potentialFirstBlock.getNumberOfAppearences('{');
    return input.getNthAppearence(numberOfOpenBraces, '}');
}

DoublyLinkedList<CSSBlock> divideIntoBlocks(MyString input) {
    DoublyLinkedList<CSSBlock> newList = DoublyLinkedList<CSSBlock>();
    while (input.getFirstAppearence('{') != -1)
    {
        int endOfBlock = findEndOfCSSBlock(input);
        CSSBlock block = CSSBlock(input.CutOut(0, endOfBlock - 1));
        newList.Add(block);
        input = input.CutOut(endOfBlock + 1, input.Length());
    }
    return newList;
}


void PrintSection(DoublyLinkedList<CSSBlock> cssBlocks) {
    for (int i = 0; i < cssBlocks.size; i++)
    {
        cout << "Block: " << i + 1 << endl;
        for (int j = 0; j < cssBlocks.getNodeAtIndex(i)->data.selectors->selectorList.size; j++)
        {
            cout << "selector: " << j + 1 << ": ";
            cssBlocks.getNodeAtIndex(i)->data.selectors->selectorList.getNodeAtIndex(j)->data.Print();
            cout << endl;
        }
        for (int j = 0; j < cssBlocks.getNodeAtIndex(i)->data.atributes->atributeList.size; j++)
        {
            cout << "atribute: " << j + 1 << ": ";
            cssBlocks.getNodeAtIndex(i)->data.atributes->atributeList.getNodeAtIndex(j)->data.Print();
            cout << endl;
        }
    }
}

void PrintAll(DoublyLinkedList<CSSBlock> cssBlocks) {
    for (int i = 0; i < cssBlocks.size; i++)
    {
        cout << "Block: " << i + 1 << endl;
        PrintSection(cssBlocks);
    }
}

void ExecuteECommand(LinkedList<MyString> commandParts, DoublyLinkedList<CSSBlock>* cssBlocks, MyString noWSCommand) {
    Node<CSSBlock>* block = cssBlocks->getNodeAtIndex(cssBlocks->size - 1);
    while (block != nullptr)
    {
        for (int i = 0; i < block->data.selectors->selectorList.size; i++)
        {
            if (block->data.selectors->selectorList.getNodeAtIndex(i)->data.Equals(commandParts.getNodeAtIndex(0)->data))
            {
                MyString value = block->data.atributes->getAtributeValue(commandParts.getNodeAtIndex(2)->data);
                if (!value.Equals("\0"))
                {
                    cout << noWSCommand << " == " << value << endl;
                    return;
                }
            }
        }
        block = block->prev;
    }
}

void ExecuteDCommand(LinkedList<MyString> commandParts, DoublyLinkedList<CSSBlock>* cssBlocks, MyString noWSCommand) {
    int blockIndex = commandParts.getNodeAtIndex(0)->data.ToInt() - 1;
    if (blockIndex >= cssBlocks->size) return;
    if (commandParts.getNodeAtIndex(2)->data.Equals("*\0"))
    {
        if (cssBlocks->getNodeAtIndex(blockIndex) != nullptr)
        {
            if (cssBlocks->Delete(blockIndex)) {
                cout << noWSCommand << " == deleted" << endl;
            }
        }
    }
    else {
        MyString name = commandParts.getNodeAtIndex(2)->data;
        if (cssBlocks->getNodeAtIndex(blockIndex) == nullptr) return;
        if (cssBlocks->getNodeAtIndex(blockIndex)->data.atributes->deleteAtributeByName(name.TrimLeftRight()))
        {
            cout << noWSCommand << " == deleted" << endl;
        }
        if (cssBlocks->getNodeAtIndex(blockIndex)->data.atributes->atributeList.size == 0)
        {
            cssBlocks->Delete(blockIndex);
        }
    }
}

void ExecuteACommand(LinkedList<MyString> commandParts, DoublyLinkedList<CSSBlock> cssBlocks, MyString noWSCommand) {
    if (commandParts.getNodeAtIndex(0)->data.IsANumber())
    {
        int blockIndex = commandParts.getNodeAtIndex(0)->data.ToInt() - 1;
        if (blockIndex >= cssBlocks.size) return;
        if (commandParts.getNodeAtIndex(2)->data.Equals("?\0")) {
            if (cssBlocks.getNodeAtIndex(blockIndex) != nullptr)
            {
                cout << noWSCommand << " == " << cssBlocks.getNodeAtIndex(blockIndex)->data.atributes->atributeList.size << endl;
            }
        }
        else {
            if (!cssBlocks.getNodeAtIndex(blockIndex)->data.atributes->getAtributeValue(commandParts.getNodeAtIndex(2)->data).Equals("\0"))
            cout << noWSCommand << " == " << cssBlocks.getNodeAtIndex(blockIndex)->data.atributes->getAtributeValue(commandParts.getNodeAtIndex(2)->data) << endl;
        }
    }
    else if (commandParts.getNodeAtIndex(2)->data.Equals("?\0")) {
        int numberOfOccurances = 0;
        for (int i = 0; i < cssBlocks.size; i++)
        {
            for (int j = 0; j < cssBlocks.getNodeAtIndex(i)->data.atributes->atributeList.size; j++)
            {
                if (commandParts.getNodeAtIndex(0)->data.Equals(cssBlocks.getNodeAtIndex(i)->data.atributes->getAtributeName(j)))
                {
                    numberOfOccurances++;
                }
            }
        }
        cout << noWSCommand << " == " << numberOfOccurances << endl;
    }
}

void ExecuteSCommand(LinkedList<MyString> commandParts, DoublyLinkedList<CSSBlock> cssBlocks, MyString noWSCommand) {
    if (commandParts.getNodeAtIndex(0)->data.IsANumber())
    {
        int blockIndex = commandParts.getNodeAtIndex(0)->data.ToInt() - 1;
        if (blockIndex >= cssBlocks.size) return;
        if (commandParts.getNodeAtIndex(2)->data.IsANumber())
        {
            int selectorIndex = commandParts.getNodeAtIndex(2)->data.ToInt() - 1;
            if (selectorIndex >= cssBlocks.getNodeAtIndex(blockIndex)->data.selectors->selectorList.size) return;
            cout << noWSCommand << " == " << cssBlocks.getNodeAtIndex(blockIndex)->data.selectors->selectorList.getNodeAtIndex(selectorIndex)->data << endl;
        }
        else if (commandParts.getNodeAtIndex(2)->data.Equals("?\0")) {
            if (cssBlocks.getNodeAtIndex(blockIndex) != nullptr)
            {
                cout << noWSCommand << " == " << cssBlocks.getNodeAtIndex(blockIndex)->data.selectors->selectorList.size << endl;
            }
        }
    }
    else if (commandParts.getNodeAtIndex(2)->data.Equals("?\0")) {
        int numberOfOccurances = 0;
        for (int i = 0; i < cssBlocks.size; i++)
        {
            for (int j = 0; j < cssBlocks.getNodeAtIndex(i)->data.selectors->selectorList.size; j++)
            {
                if (commandParts.getNodeAtIndex(0)->data.Equals(cssBlocks.getNodeAtIndex(i)->data.selectors->selectorList.getNodeAtIndex(j)->data))
                {
                    numberOfOccurances++;
                }
            }
        }
        cout << noWSCommand << " == " << numberOfOccurances << endl;
    }
}

void ExecuteCommand(MyString command, DoublyLinkedList<CSSBlock> *cssBlocks) {
    MyString noWSCommand = MyString(command.TrimLeftRight());
    if (MyString("?\0").Equals(noWSCommand))
    {
        cout << "? == " << (*cssBlocks).size << endl;
    }
    else {
        LinkedList<MyString> commandParts = noWSCommand.Split(noWSCommand, ',');
        if (commandParts.size != 3) return;
        if (commandParts.getNodeAtIndex(1)->data.Equals("S\0"))
        {
            ExecuteSCommand(commandParts, *cssBlocks, noWSCommand);
        }
        else if (commandParts.getNodeAtIndex(1)->data.Equals("A\0"))
        {
            ExecuteACommand(commandParts, *cssBlocks, noWSCommand);
        }
        else if (commandParts.getNodeAtIndex(1)->data.Equals("D\0"))
        {
            ExecuteDCommand(commandParts, cssBlocks, noWSCommand);
        }
        else if (commandParts.getNodeAtIndex(1)->data.Equals("E\0"))
        {
            ExecuteECommand(commandParts, cssBlocks, noWSCommand);
        }
    }
}

void ExecuteCommands(LinkedList<MyString> commands, DoublyLinkedList<CSSBlock>* cssBlocks) {
    for (int i = 0; i < commands.size; i++)
    {
        ExecuteCommand(commands.getNodeAtIndex(i)->data, cssBlocks);
    }
}

LinkedList<MyString> ParseCommands(MyString commandSection) {
    return commandSection.Split(commandSection, '\n');
}

void ParseInput(MyString inputText, DoublyLinkedList<CSSBlock>* cssBlocks) {
    int startOfCommandSection = inputText.getFirstAppearence(MyString("????\0"));

    while (startOfCommandSection != -1)
    {
        MyString nextCSSSectionText = inputText.CutOut(0, startOfCommandSection - 1);
        DoublyLinkedList<CSSBlock> newList = divideIntoBlocks(nextCSSSectionText.TrimLeftRight());
        for (int i = 0; i < newList.size; i++)
        {
            (*cssBlocks).Add(newList.getNodeAtIndex(i)->data);
        }

        int endOfCommandSection = inputText.getFirstAppearence(MyString("****\0"));
        if (endOfCommandSection == -1)
        {
            endOfCommandSection = inputText.Length();
        }
        else {
            endOfCommandSection += 3;
        }
        MyString nextCommandSectionText = inputText.CutOut(startOfCommandSection, endOfCommandSection);

        ExecuteCommands(ParseCommands(nextCommandSectionText), cssBlocks);

        inputText = inputText.CutOut(endOfCommandSection + 1, inputText.Length());
        startOfCommandSection = inputText.getFirstAppearence(MyString("????\0"));
    }
}

/*
FILE* f = fopen("C:\\Users\\micha\\Documents\\test.txt", "rb");
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);

    char* input = (char*)malloc(fsize + 1);
    fread(input, fsize, 1, f);
    fclose(f);

    input[fsize] = '\0';
*/

int main()
{
    DoublyLinkedList<CSSBlock> cssBlocks = DoublyLinkedList<CSSBlock>();
    char buffer[1000000];

    int c, size = 0, numberOfStars = 0;
    c = getchar();
    while (c != EOF)
    {
        buffer[size] = (char)c;
        size++;
        if ((char)c == '*')
        {
            numberOfStars++;
            if (numberOfStars == 4)
            {
                buffer[size] = '\0';
                ParseInput(MyString(buffer), &cssBlocks);
                size = 0;
                numberOfStars = 0;
            }
        }
        else {
            numberOfStars = 0;
        }
        c = getchar();
    }
    buffer[size] = '\0';
    ParseInput(MyString(buffer), &cssBlocks);  
}