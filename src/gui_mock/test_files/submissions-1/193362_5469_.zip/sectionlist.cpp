#include "sectionlist.h"
#include "functions.h"
#include <iostream>


SectionNode::SectionNode() {
	next = nullptr;
	prev = nullptr;

	for (Block& b : block) {
		b.attr_head = nullptr;
		b.selector_head = nullptr;
	}
	taken_slots = 1;
	last_index = 0;
}

SectionList::~SectionList() {
	if (head == nullptr) return;
	SectionNode* current = head;
	while (current->next != nullptr) {
		for (int i = 0; i < T; i++) {
			current->block[i].deleteBlock();
		}
		current = current->next;
		if (current->prev != nullptr) {
			delete current->prev;
		}
	}
	for (int i = 0; i < T; i++) {
		current->block[i].deleteBlock();
	}
	delete current;
	head = nullptr;
}


SectionList::SectionList() {
	head = nullptr;
	last = head;
}

void SectionList::push_back() {
	if (head == nullptr) {
		head = new SectionNode();
		last = head;
		return;
	}
	if (head->next == nullptr) {
		if (head->taken_slots < T && head->block[T - 1].attr_head == nullptr) {
			head->taken_slots++;
			head->last_index++;
		}
		else {
			head->next = new SectionNode();
			head->next->prev = head;
			last = head->next;
		}
		return;
	}
	SectionNode* current = last;
	if (current->taken_slots < T && current->block[T - 1].attr_head == nullptr) {
		current->taken_slots++;
		current->last_index++;
		return;
	}

	current->next = new SectionNode();
	current->next->prev = current;
	last = current->next;
	return;
}

void SectionList::push_back_selector(String set_selector) {
	if (head == nullptr) {
		return;
	}
	SectionNode* current = last;

	int searched_section_index = 0;
	searched_section_index = current->last_index;

	current->block[searched_section_index].push_back_selector(set_selector);
	return;
}

void SectionList::push_back_attribute(String set_attribute, String option) {
	if (head == nullptr) {
		return;
	}
	SectionNode* current = last;
	int searched_section_index = 0;
	searched_section_index = current->last_index;
	current->block[searched_section_index].push_back_attribute(set_attribute, option);
	return;
}

int SectionList::sectionsCount() {
	if (head == nullptr) {
		return 0;
	}
	SectionNode* current = head;
	int count = 0;
	while (current != nullptr) {
		count += current->taken_slots;
		current = current->next;
	}
	return count;
}

// returns -1 if doesnt exist
int SectionList::selectorsCountInSection(int section) {
	if (section < 1) {
		return FAILED;
	}
	if (head == nullptr) {
		return FAILED;
	}
	SectionNode* current = head;
	int current_section = 0;
	int searched_section_index = -1;
	while (current_section != section) {

		if (current_section + current->taken_slots >= section) {
			for (int i = 0; i < section - current_section; i++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					i--;
				}
			}
			break;
		}

		current_section += current->taken_slots;
		if (current->next != nullptr) {
			current = current->next;
		}
		else {
			return FAILED;
		}
	}
	int selectors_count = 0;
	SelectorNode* selector_node = current->block[searched_section_index].selector_head;
	while (selector_node != nullptr) {
		selectors_count++;
		selector_node = selector_node->next;
	}
	return selectors_count;
}

// returns -1 if doesnt exist
int SectionList::attributesCountInSection(int section) {
	if (section < 1) {
		return FAILED;
	}
	if (head == nullptr) {
		return FAILED;
	}
	SectionNode* current = head;
	int current_section = 0;
	int searched_section_index = -1;
	while (current_section != section) {

		if (current_section + current->taken_slots >= section) {
			for (int i = 0; i < section - current_section; i++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					i--;
				}
			}
			break;
		}

		current_section += current->taken_slots;
		if (current->next != nullptr) {
			current = current->next;
		}
		else {
			return FAILED;
		}
	}
	int attribute_count = 0;
	AttributeNode* attribute_node = current->block[searched_section_index].attr_head;
	while (attribute_node->next != nullptr) {
		attribute_node = attribute_node->next;
	}
	while (attribute_node != nullptr) {
		attribute_count++;
		attribute_node = attribute_node->prev;
	}
	return attribute_count;
}

String SectionList::findSelectorInBlock(int i, int j) {
	if (head == nullptr || i < 1 || j < 1) {
		return "NOT_FOUND";
	}
	SectionNode* current = head;
	int current_section = 0;
	int searched_section_index = -1;
	while (current != nullptr) {

		if (current_section + current->taken_slots >= i) {
			for (int k = 0; k < i - current_section; k++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					k--;
				}
			}
			return current->block[searched_section_index].findSelector(j);
		}
		current_section += current->taken_slots;
		current = current->next;
	}
	return "NOT_FOUND";
}

String SectionList::findAttributeValueInBlock(int i, String searched) {
	if (head == nullptr || i < 1) {
		return "NOT_FOUND";
	}
	SectionNode* current = head;
	int searched_section_index = -1;
	int current_section = 0;
	while (current != nullptr) {
		if (current_section + current->taken_slots >= i) {
			for (int k = 0; k < i - current_section; k++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					k--;
				}
			}
			return current->block[searched_section_index].findAttributeValue(searched);
		}
		current_section += current->taken_slots;
		current = current->next;
	}
	return "NOT_FOUND";

}

int SectionList::getCountOfAttributeInBlocks(String& searched_property) {
	if (head == nullptr) {
		return 0;
	}
	SectionNode* current = head;
	int counter = 0;
	int j = 0;
	while (current != nullptr) {
		j = 0;
		for (int i = 0; i < current->taken_slots; i++) {
			if (current->block[j].attr_head == nullptr) {
				i--;
			}
			else {
				if (current->block[j].findAttribute(searched_property)) {
					counter++;
				}
			}
			j++;
		}
		current = current->next;
	}
	return counter;
}

int SectionList::getCountOfSelectorInBlocks(String& searched_selector) {
	if (head == nullptr) {
		return 0;
	}
	SectionNode* current = head;
	int counter = 0;
	int j = 0;
	while (current != nullptr) {
		j = 0;
		for (int i = 0; i < current->taken_slots; i++) {
			if (current->block[j].attr_head == nullptr) {
				i--;
			}
			else {
				if (current->block[j].findSelector(searched_selector)) {
					counter++;
				}
			}
			j++;
		}
		current = current->next;
	}
	return counter;
}

String SectionList::findAttributeValueForSelector(String& selector, String& property) {
	String not_found = "NOT_FOUND";
	if (head == nullptr) {
		return not_found;
	}
	SectionNode* current = last;

	while (current != nullptr) {
		for (int i = T - 1; i >= 0; i--) {
			if (current->block[i].findSelector(selector)) {
				return current->block[i].findAttributeValue(property);
			}
		}
		current = current->prev;
	}
	return not_found;
}

bool SectionList::deleteBlock(int i) {
	if (head == nullptr || i < 1) {
		return false;
	}
	
	SectionNode* current = head;
	if (head == nullptr) {
		return false;
	}
	int searched_section_index = -1;
	int current_section = 0;
	while (current != nullptr) {
		if (current_section + current->taken_slots >= i) {
			for (int k = 0; k < i - current_section; k++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					k--;
				}
			}
			current->block[searched_section_index].deleteBlock();
			while (current->block[current->last_index].attr_head == nullptr && current->last_index >= 0) {
				current->last_index--;
			}
			current->taken_slots--;

			if (current->taken_slots == 0) {
				deleteSectionNode(current);
			}
			return true;
		}
		current_section += current->taken_slots;
		current = current->next;
	}
	return false;
}

bool SectionList::deleteAttribute(int section, String& property) {
	if (head == nullptr) {
		return false;
	}
	SectionNode* current = head;
	int searched_section_index = -1;
	int current_section = 0;
	while (current != nullptr) {
		if (current_section + current->taken_slots >= section) {
			for (int k = 0; k < section - current_section; k++) {
				searched_section_index++;
				if (current->block[searched_section_index].attr_head == nullptr) {
					k--;
				}
			}
			if (current->block[searched_section_index].deleteAttribute(property)) {
				if (current->block[searched_section_index].attr_head == nullptr) {
					current->block[searched_section_index].deleteBlock();
					while (current->block[current->last_index].attr_head == nullptr && current->last_index >= 0) {
						current->last_index--;
					}
					current->taken_slots--;
				}
				if (current->taken_slots == 0) {
					deleteSectionNode(current);
				}
				return true;
			}
			else return false;
		}
		current_section += current->taken_slots;
		current = current->next;
	}
	return false;
}

void SectionList::deleteSectionNode(SectionNode*& current) {
	if (current == head) {
		if (current->next == nullptr) {
			delete head;
			head = nullptr;
			last = head;
		}
		else {
			head = head->next;
			head->prev = nullptr;
			delete current;
		}
	}
	else {
		if (current->next == nullptr) {
			current->prev->next = nullptr;
			last = current->prev;
			delete current;
		}
		else {
			current->prev->next = current->next;
			current->next->prev = current->prev;
			delete current;
		}
	}
}