#pragma once
#include <iostream>
#include <stdio.h>
#include "string.h"
#include "sectionlist.h"

#define reading_command 2
#define reading_selector 1
#define reading_attribute 0
#define reading_property 1
#define reading_value 0
#define FAILED -1

void ReadingCommands(String& text, SectionList& list, int& mode, bool& end);

void ReadingSection(String& tmp, SectionList& list, int& mode, bool& created_new_section, int& attribute_part, bool& end);

void ReadingSelector(String& tmp, SectionList& list, bool& created_new_section, int& mode, char new_char);

void ReadingAttribute(String& tmp, SectionList& list, bool& created_new_section, int& mode, int& attribute_part, char new_char);

void Delete_index(String&text, int index);

void Print_element(String& text, bool mode);

void Move_to_left(String& text, int number);

void countSelectors(String& left, String& text, SectionList& list);

void findSelectorInBlock(String& left, String& right, SectionList& list, String& text);

void countAttributesInBlock(String& text, String& left, SectionList& list);

void handleNewChar(int commasCount, bool empty_sign, String& text, bool& readyCommand, char new_char);

void CommandA(String& right, String& text, String& left, SectionList& list);
