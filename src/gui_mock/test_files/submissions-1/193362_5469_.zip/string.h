#pragma once
#include <iostream>

#define BUFFOR 2

class String {
private:
	int size;
	char* string;
public:
	friend class SectionList;
	String();
	String(const char* other);
	String(const String& other);
	String(String&& other);
	~String();

	String& operator=(const char* other);
	String& operator=(const String& other);
	String operator+(const char* other);
	char& operator[](int i);
	String& operator=(String&& other);

	bool operator==(const char* other);
	bool operator!=(const char* other);
	bool operator==(const String& other);

	String& operator+=(const char other);
	String& operator+=(const String& other);
	void Reset();

	friend std::ostream& operator<<(std::ostream& output, const String& text);
	friend std::istream& operator>>(std::istream& input, String& text);
	friend void SectionNode(const String& selector_name);

	int GetSize() const;
	int GetInput();
	char* ToChar();
	bool findInString(String searching);
	void deleteInString(String searching);
	int stringToInt();

	void getline();
	String getFirstCommandSegment();
	String getLastCommandSegment();

	void removeSpacesAtStart();
	void removeSpacesAtEnd();

	int commasCount();
	char getCommand();
};
