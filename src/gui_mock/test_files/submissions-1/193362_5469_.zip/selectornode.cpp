#include "selectornode.h"

SelectorNode::SelectorNode() {
	next = nullptr;
}

SelectorNode::SelectorNode(String set_selector) {
	selector = set_selector;
	next = nullptr;
}

SelectorNode::~SelectorNode() {
	next = nullptr;
}

