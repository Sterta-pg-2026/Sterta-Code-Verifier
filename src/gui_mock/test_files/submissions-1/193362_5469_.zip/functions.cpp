#include "functions.h"

#define TESTING 0


using std::cout;
using std::cin;

void ReadingCommands(String& text, SectionList& list, int& mode, bool& end) {
	int length;
	char new_char;
	text.Reset();
	bool readyCommand = false;
	String result;
	while (true) {

		if ((new_char = getchar()) == EOF) {
			end = true;
			break;
		}
		else {
			int commasCount = text.commasCount();
			bool empty_sign = isspace(new_char);
			handleNewChar(commasCount, empty_sign, text, readyCommand, new_char);
		}

		length = text.GetSize();
		if (text == "?") {
			cout << text << " == " << list.sectionsCount() << '\n';
			text.Reset();
		}
		if (text == "****") {
			mode = reading_selector;
			return;
		}
		else if (end) {
			return;
		}
		if (readyCommand) {
			char command = text.getCommand();
			String left = text.getFirstCommandSegment();
			String right = text.getLastCommandSegment();
			if (left[0] == '\0' || right[0] == '\0') {
				text.Reset();
				readyCommand = false;
				continue;
			}
			switch (command) {
			case ('S'):
				if (right == "?") {
					countSelectors(left, text, list);
				}
				else {
					findSelectorInBlock(left, right, list, text);
				}
				break;
			case('A'):
				CommandA(right, text, left, list);
				break;
			case('E'):
				result = list.findAttributeValueForSelector(left, right);
				if (result != "NOT_FOUND") {
					cout << text << " == ";
					cout << result << "\n";
				}
				break;
			case('D'):
				if (right == "*") {
					int i = left.stringToInt();
					if (list.deleteBlock(i)) {
						cout << text << " == " << "deleted\n";
					}
				}
				else {
					int i = left.stringToInt();
					if (list.deleteAttribute(i, right)) {
						cout << text << " == " << "deleted\n";
					}
				}
				break;
			};

			readyCommand = false;
			text.Reset();
		}
	}
}

void ReadingSection(String& tmp, SectionList& list, int& mode, bool& created_new_section, int& attribute_part, bool& end) {
	int length;
	tmp.Reset();
	char new_char;
	while (true) {
		if ((new_char = getchar()) == EOF) {
			end = true;
			return;
		}
		if (attribute_part == reading_property && mode == reading_attribute && !isspace(new_char)) {
			tmp += new_char;
		}
		else if (!isspace(new_char) || new_char == ' ') {
			tmp += new_char;
		}

		if (tmp == "????") {
			mode = reading_command;
			return;
		}
		if (end) {
			return;
		}

		if (mode == reading_selector) {
			ReadingSelector(tmp, list, created_new_section, mode, new_char);
		}
		else if (mode == reading_attribute) {
			ReadingAttribute(tmp, list, created_new_section, mode, attribute_part, new_char);
		}
	}
}

void ReadingSelector(String& tmp, SectionList& list, bool& created_new_section, int& mode, char new_char) {
	switch (new_char) {
	case ',':
		if (created_new_section == false) {
			list.push_back();
			created_new_section = true;
		}
		// found a selector

		tmp[tmp.GetSize() - 1] = '\0';

		tmp.removeSpacesAtStart();

		list.push_back_selector(tmp);


		if (TESTING == 1) {
			Print_element(tmp, mode);
		}
		tmp.Reset();

		break;
	case '{':
		if (created_new_section == false) {
			list.push_back();
			created_new_section = true;
		}
		// found start of attribute block
		// if there is anything in the tmp, it should be added to selectors now

		tmp[tmp.GetSize() - 1] = '\0';
		tmp.removeSpacesAtStart();
		tmp.removeSpacesAtEnd();

		if (tmp != "") {
			list.push_back_selector(tmp);
		}

		if (TESTING == 1) {
			Print_element(tmp, mode);
		}
		tmp.Reset();
		mode = reading_attribute;

		break;
	}
}

void ReadingAttribute(String& tmp, SectionList& list, bool& created_new_section, int& mode, int& attribute_part, char new_char) {
	if (attribute_part == reading_property) {
		switch (new_char) {
		case ':':

			// found property
			// save it and then load value reading state

			tmp[tmp.GetSize() - 1] = '\0';
			tmp.removeSpacesAtStart();
			tmp.removeSpacesAtEnd();

			if (tmp[0] != '\0' || !isspace(tmp[0])) {
				list.push_back_attribute(tmp, "prop");
			}

			if (TESTING) {
				cout << "property: " << tmp << std::endl;
			}
			tmp.Reset();
			attribute_part = reading_value;
			break;
		case '}':

			// found end of attribute block after there was semicolon
			// terminate the attribute-reading process
			// start loading selectors again

			tmp[tmp.GetSize() - 1] = '\0';
			tmp.removeSpacesAtStart();
			tmp.removeSpacesAtEnd();

			tmp.Reset();


			created_new_section = false;
			mode = reading_selector;
			break;
		};
	}
	else {
		switch (new_char) {
		case ';':

			tmp.removeSpacesAtStart();
			tmp.removeSpacesAtEnd();
			
			// found end of an attribute
			// add tmp to the value list

			tmp[tmp.GetSize() - 1] = '\0';
			list.push_back_attribute(tmp, "val");

			if (TESTING) {
				cout << "value: " << tmp << std::endl;
			}
			tmp.Reset();

			attribute_part = reading_property;
			break;
		case '}':

			tmp.removeSpacesAtStart();
			tmp.removeSpacesAtEnd();
			// found end of attribute block tho there was no semicolon
			// tmp needs to be saved to the value of last property

			tmp[tmp.GetSize() - 1] = '\0';
			list.push_back_attribute(tmp, "val");

			if (TESTING) {
				cout << "value: " << tmp << std::endl;
			}
			tmp.Reset();

			attribute_part = reading_property;
			mode = reading_selector;

			created_new_section = false;
			break;
		};
	}
}

void Delete_index(String& text, int index) {
	int length = text.GetSize();
	text[index] = '\0';
	int i;
	for (i = index+1; i < length; i++) {
		text[i - 1] = text[i];
	}
	text[i-1] = '\0';
}

void Print_element(String& text, bool mode) {
	if (mode == reading_selector) {
		cout << "selector: " << text << "\n";
	}
	else {
		cout << "attribute: " << text << "\n";
	}
}

void Move_to_left(String& text, int number) {
	if (number < 0) {
		return;
	}
	int i;
	number++;
	for (i = 0; text[i+number] != '\0'; i++) {
		text[i] = text[i + number];
	}
	text[i] = '\0';
}

void countSelectors(String& left, String& text, SectionList& list) {
	if (left[0] <= '9' && left[0] >= '0') {
		int selector_count = list.selectorsCountInSection(left.stringToInt());
		if (selector_count != FAILED) {
			cout << text << " == " << selector_count << '\n';
		}
	}
	else {
		int selector_count = list.getCountOfSelectorInBlocks(left);
		cout << text << " == " << selector_count << '\n';
	}
}

void findSelectorInBlock(String& left, String& right, SectionList& list, String& text) {
	int i = left.stringToInt();
	int j = right.stringToInt();
	String result = list.findSelectorInBlock(i, j);
	if (result != "NOT_FOUND") {
		cout << text << " == ";
		cout << result << "\n";
	}
}

void countAttributesInBlock(String& text, String& left, SectionList& list) {
	if (left[0] <= '9' && left[0] >= '0') {
		int attribute_count = list.attributesCountInSection(left.stringToInt());
		if (attribute_count != FAILED) {
			cout << text << " == " << attribute_count << '\n';
		}
	}
}

void handleNewChar(int commasCount, bool empty_sign, String& text, bool& readyCommand, char new_char) {
	if (commasCount > 2 && empty_sign) {
		text.Reset();
	}
	else if (commasCount == 2 && empty_sign) {
		readyCommand = true;
	}
	else if (commasCount == 0 && (!empty_sign || new_char == ' ')) {
		text += new_char;
		if (text[0] == ' ') text[0] = '\0';

	}
	else if (!empty_sign) {
		text += new_char;
	}
}

void CommandA(String& right, String& text, String& left, SectionList& list) {
	if (right == "?") {
		if (left[0] <= '9' && left[0] >= '0') {
			countAttributesInBlock(text, left, list);
		}
		else {
			int i = list.getCountOfAttributeInBlocks(left);
			cout << text << " == " << i << '\n';
		}
	}
	else {
		int i = left.stringToInt();
		String result = list.findAttributeValueInBlock(i, right);
		if (result != "NOT_FOUND") {
			cout << text << " == ";
			cout << result << "\n";
		}
	}
}