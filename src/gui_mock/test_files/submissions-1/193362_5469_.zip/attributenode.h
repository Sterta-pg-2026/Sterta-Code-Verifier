#pragma once
#include "string.h"


class AttributeNode {
private:
	AttributeNode* next;
	AttributeNode* prev;
	String property; // the name of an attribute
	String value;	// the vaule of an attribute
public:
	AttributeNode(String set_attr);
	AttributeNode();

	friend class SectionList;
	friend class Block;
};

