#include "attributenode.h"

AttributeNode::AttributeNode() {
	next = nullptr;
	prev = nullptr;
}

AttributeNode::AttributeNode(String set_attr) {
	next = nullptr;
	prev = nullptr;
	property = set_attr;
}
