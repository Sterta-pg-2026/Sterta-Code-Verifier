#include "sectionlist.h"
#include "functions.h"

Block::Block() {
	selector_head = nullptr;
	attr_head = nullptr;
}

void Block::push_back_selector(String set_selector) {
	if (selector_head == nullptr) {
		selector_head = new SelectorNode(set_selector);
		return;
	}
	SelectorNode* current = selector_head;
	while (current->next != nullptr) {
		current = current->next;
	}
	current->next = new SelectorNode(set_selector);
}

void Block::push_back_attribute(String set_attribute, String option) {
	if (option == "prop") {
		if (attr_head == nullptr) {
			attr_head = new AttributeNode(set_attribute);
			return;
		}
		AttributeNode* current = attr_head;
		while (current->next != nullptr) {
			current = current->next;
		}
		current->next = new AttributeNode(set_attribute);
		current->next->prev = current;
		findAttribute(set_attribute);
		deleteDuplicates(set_attribute);
	}
	else {
		AttributeNode* current = attr_head;
		while (current->next != nullptr) {
			current = current->next;
		}
		current->value = set_attribute;
	}
}

String Block::findSelector(int i) {
	String not_found = "NOT_FOUND";
	if (selector_head == nullptr) {
		return not_found;
	}
	SelectorNode* current = selector_head;
	int counter = 1;
	while (current != nullptr) {
		if (counter == i) {
			return current->selector;
		}
		current = current->next;
		counter++;
	}
	return not_found;
}

String Block::findAttributeValue(String searched) {
	String not_found = "NOT_FOUND";
	if (attr_head == nullptr) {
		return not_found;
	}
	AttributeNode* current = attr_head;
	while (current != nullptr) {
		if (current->property[0] == ' ') {
			Move_to_left(current->property, 0);
		}
		if (current->property == searched) {
			return current->value;
		}
		current = current->next;
	}
	return not_found;
}

bool Block::findAttribute(String& searched_property) {
	if (attr_head == nullptr) {
		return false;
	}
	if (attr_head->next == nullptr) {
		if (attr_head->property == searched_property) {
			return true;
		}
		else return false;
	}
	AttributeNode* current = attr_head;
	bool found = false;
	while (current != nullptr) {
		if (current->property == searched_property && found == false) {
			found = true;
			return found;
		}
		current = current->next; //we get to the end

	}
	return found;
}

void Block::deleteDuplicates(String& searched_property) {
	if (attr_head == nullptr) {
		return;
	}
	AttributeNode* current = attr_head;
	while (current->next != nullptr) {
		current = current->next; //we get to the end
	}
	bool found = false;
	while (current != nullptr) {
		if (current->property == searched_property && found == false) {
			found = true;
		}
		else if (current->property == searched_property && found == true) {
			AttributeNode* tmp = current;
			if (current != attr_head) {
				current = current->next;
				current->prev = tmp->prev;
				tmp->prev->next = current;
			}
			else {
				current = current->next;
				attr_head = current;
				current->prev = nullptr;
			}
			delete tmp;
		}
		current = current->prev;
	}
}

bool Block::findSelector(String& searched_selector) {
	if (selector_head == nullptr) {
		return false;
	}
	SelectorNode* current = selector_head;
	bool found = false;
	while (current != nullptr) {
		if (current->selector == searched_selector) {
			found = true;
			break;
		}
		current = current->next;
	}
	return found;
}

void Block::deleteBlock() {
	SelectorNode* current_sel = selector_head;
	SelectorNode* tmp_sel = selector_head;
	AttributeNode* current_attr = attr_head;
	AttributeNode* tmp_attr = attr_head;
	while (current_attr != nullptr) {
		current_attr->prev = nullptr;
		current_attr = current_attr->next;
		tmp_attr->next = nullptr;
		delete tmp_attr;
		tmp_attr = current_attr;
	}
	while (current_sel != nullptr) {
		current_sel = current_sel->next;
		tmp_sel->next = nullptr;
		delete tmp_sel;
		tmp_sel = current_sel;
	}
	selector_head = nullptr;
	attr_head = nullptr;
}

bool Block::deleteAttribute(String& property) {
	AttributeNode* current = attr_head;
	if (attr_head == nullptr) {
		return false;;
	}
	while (current != nullptr) {
		if (current->property == property) {
			if (current == attr_head) {
				if (attr_head->next != nullptr) {
					attr_head = attr_head->next;
					attr_head->prev = nullptr;
					delete current;
				}
				else {
					deleteBlock();
				}
			}
			else if (current->next == nullptr) {
				current->prev->next = nullptr;
				delete current;
			}
			else {
				current->next->prev = current->prev;
				current->prev->next = current->next;
				delete current;
			}
			return true;
		}
		current = current->next;
	}
	return false;
}