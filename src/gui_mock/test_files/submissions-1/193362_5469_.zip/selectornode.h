#pragma once
#include "string.h"

class SelectorNode {
private:
	String selector;
	SelectorNode* next;
	friend class Block;
public:
	friend class SectionList;
	SelectorNode();
	SelectorNode(String set_selector);
	~SelectorNode();
};

