#include "string.h"

#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#include <iostream>
#include "functions.h"

String::String() {
    string = nullptr;
    size = 0;
}

String::String(const char* other) {
    int length = strlen(other);
    size = length + BUFFOR;
    string = new char[size + 1];
    strcpy(string, other);
    string[length] = '\0';
}

String::String(const String& other) {
    int length = other.size;
    size = length;
    string = new char[size + 1];
    strcpy(string, other.string);
    string[length] = '\0';
}

String::String(String&& other) {
    int length = other.size;
    size = length;
    string = new char[size + 1];
    strcpy(string, other.string);
    string[length] = '\0';
}

String::~String() {
    delete[] string;
    size = 0;
    string = nullptr;
}

String& String::operator=(const char* other) {
    int length = strlen(other);
    if (length == 0) {
        delete[] string;
        size = 0;
        string = nullptr;
        return *this;
    }
    if (size < length) {
        delete[] string;
        size = length + BUFFOR;
        string = new char[size + 1];
        strcpy(string, other);
        string[length] = '\0';
    }
    else {
        strcpy(string, other);
        string[length] = '\0';
    }

    return *this;
}


String& String::operator=(const String& other) {
    int length = strlen(other.string);
    if (size < length) {
        delete[] string;
        size = length + BUFFOR;
        string = new char[size + 1];
        strcpy(string, other.string);
        string[length] = '\0';
    }
    else {
        strcpy(string, other.string);
        string[length] = '\0';
    }

    return *this;
}

String& String::operator=(String&& other) {
    int length = strlen(other.string);
    if (size < length) {
        delete[] string;
        size = length + BUFFOR;
        string = new char[size + 1];
        strcpy(string, other.string);
        string[length] = '\0';
    }
    else {
        strcpy(string, other.string);
        string[length] = '\0';
    }

    return *this;
}

String String::operator+(const char* other) {
    String tmp;
    int length1 = GetSize();
    int length2 = strlen(other);
    tmp.string = new char[length1 + length2 + 1];
    if (string != nullptr) {
        strcpy(tmp.string, string);
    }
    strcat(tmp.string, other);
    tmp.string[length1 + length2] = '\0';
    return tmp;
}

String& String::operator+=(const char other) {
    int length = GetSize();
    if (size < length + 1) {
        char* tmp = new char[length + 2];
        if (string != nullptr) {
            strcpy(tmp, string);
        }
        delete[] string;
        size += BUFFOR;
        string = new char[size + 1];
        tmp[length] = other;
        tmp[length + 1] = '\0';
        strcpy(string, tmp);
        delete[] tmp;
        tmp = nullptr;
    }
    else {
        string[length] = other;
        string[length + 1] = '\0';
    }
    return *this;
}

String& String::operator+=(const String& other) {
    int length1 = GetSize();
    int length2 = other.GetSize();
    if (size < length1 + length2 + 1) {
        char* tmp = new char[length2 + length1 + 1];
        if (string != nullptr) {
            strcpy(tmp, string);
        }
        if (other.string != nullptr) {
            strcat(tmp, other.string);
        }
        tmp[length2 + length1] = '\0';
        delete[] string;
        size = length1 + length2 + BUFFOR;
        string = new char[size + 1];
        strcpy(string, tmp);
        delete[] tmp;
        tmp = nullptr;
    }
    else {
        strcat(string, other.string);
    }
    return *this;
}

int String::GetSize() const {
    if(string == nullptr) return 0;
    return strlen(string);
}

int String::GetInput() {
    char tmp[64];
    if (scanf("%s", tmp) != EOF) {
        tmp[strlen(tmp)] = '\0';
        string = new char[strlen(tmp) + 1];
        strcpy(string, tmp);
        return 1;
    }
    else {
        return FAILED;
    }
}

char& String::operator[](int i) {
    return string[i];
}

std::ostream& operator<<(std::ostream& output, const String& text) {
    output << text.string;
    return output;
}

std::istream& operator>>(std::istream& input, String& text) {
    char tmp[128];
    scanf("%s", tmp);
    int length = strlen(tmp);
    tmp[length] = '\0';
    text.string = new char[length + 1];
    strcpy(text.string, tmp);
    return input;
}

bool String::operator==(const char* other) {
    if (string == nullptr) {
        return false;
    }
    if (strcmp(string, other) == 0) {
        return true;
    }
    return false;
}

bool String::operator==(const String& other) {
    if (string == nullptr) {
        return false;
    }
    if (strcmp(string, other.string) == 0) {
        return true;
    }
    return false;
}

bool String::operator!=(const char* other) {
    if (string == nullptr) {
        return true;
    }
    if (*this == other) {
        return false;
    }
    return true;
}

char* String::ToChar() {
    char* tmp = new char[GetSize() + 1];
    strcpy(tmp, string);
    return tmp;
}

void String::Reset() {
    if (string != nullptr) {
        string[0] = '\0';
    }
}

bool String::findInString(String searching) {
    char* tmp = strstr(string, searching.string);
    if (tmp != nullptr) {
        return true;
    }
    return false;
}

void String::deleteInString(String searching) {
    char* tmp = strstr(string, searching.string);
    if (tmp != nullptr) {
        *tmp = '\0';
    }
}

void String::getline() {
    char tmp[64];
    fgets(tmp, 64, stdin);
    string = tmp;
}

int String::stringToInt() {
    int number = 0;
    int i = 0;
    int sign;
    if (string[0] == '-') {
        sign = -1;
        i++;
    }
    else {
        sign = 1;
    }
    while (string[i] != '\0') {
        number = 10 * number + ((int)string[i] - 48);
        i++;
    }
    return sign * number;
}

String String::getFirstCommandSegment() {
    String tmp = string;
    tmp.deleteInString(",");
    return tmp;
}

String String::getLastCommandSegment() {
    String tmp = string;
    int i = tmp.GetSize() - 1;
    for (i; i >= 0; i--) {
        if (tmp[i] == ',') {
            Move_to_left(tmp, i);
        }
    }
    return tmp;
}

void String::removeSpacesAtStart() {
    int i = 0;
    if (GetSize() < 1) {
        return;
    }
    while (isspace(string[i])) {
        i++;
    }
    i--;
    Move_to_left(*this, i);
}

void String::removeSpacesAtEnd() {
    int i = this->GetSize() - 1;
    if (i < 0) {
        return;
    }
    while (isspace(string[i])) {
        string[i] = '\0';
        i--;
    }
}

int String::commasCount() {
    int counter = 0;
    for (int i = 0; i < GetSize(); i++) {
        if (string[i] == ',') {
            counter++;
        }
    }
    return counter;
}

char String::getCommand() {
    char* tmp = strstr(string, ",");
    tmp += 1;
    if (tmp != nullptr) {
        return *tmp;
    }
    else return '\0';
}