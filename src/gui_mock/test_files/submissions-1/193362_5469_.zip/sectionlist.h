#pragma once
#include "attributenode.h"
#include "string.h"
#include "selectornode.h"

#define T 8

class Block {
private:
	SelectorNode* selector_head;
	AttributeNode* attr_head;
	friend class SectionNode;
	friend class SectionList;

	Block();

	String findSelector(int i);
	String findAttributeValue(String searched);
	void push_back_attribute(String set_attribute, String option);
	void push_back_selector(String set_selector);

	bool findAttribute(String& searched_property);
	void deleteDuplicates(String& searched_property);
	bool findSelector(String& searched_selector);

	void deleteBlock();
	bool deleteAttribute(String& property);
};

class SectionNode {
private:
	Block block[T];
	SectionNode* next;
	SectionNode* prev;
	int taken_slots;
	int last_index;
public:
	friend class SectionList;
	SectionNode();
};

class SectionList {
public:
	SectionNode* head;
	SectionNode* last;
public:
	SectionList();
	~SectionList();

	void push_back();
	void push_back_selector(String set_selector);
	void push_back_attribute(String set_attribute, String option);

	int sectionsCount();
	int selectorsCountInSection(int section);
	int attributesCountInSection(int section);

	String findSelectorInBlock(int i, int j);
	String findAttributeValueInBlock(int i, String searched);

	int getCountOfAttributeInBlocks(String& searched_property);
	int getCountOfSelectorInBlocks(String& searched_selector);

	String findAttributeValueForSelector(String& selector, String& property);

	bool deleteBlock(int i);
	bool deleteAttribute(int section, String& property);

	void deleteSectionNode(SectionNode*& current);
};