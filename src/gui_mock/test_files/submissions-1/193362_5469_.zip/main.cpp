#include "sectionlist.h"
#include "functions.h"
#include <stdio.h>


using std::cout;
using std::cin;

int main() {
	SectionList list;
	String text;
	String tmp;
	bool end = false;
	int mode = reading_selector;
	int attribute_part = reading_property;
	bool created_new_section = false;


	while (true) {
		if (mode == reading_command) {
			ReadingCommands(text, list, mode, end);
		}

		if (mode == reading_selector) {
			ReadingSection(tmp, list, mode, created_new_section, attribute_part, end);
		}
		if (end) {
			break;
		}
	}
	return 0;
}