#pragma once
#include "wordsstring.h"

class Attribute {
public:
	wordsString name;
	wordsString value;
	void print() const;
	void deleteAttribute();
	void addName(myString& newName);
	void addValue(myString& newValue);
	Attribute(wordsString* name, wordsString* value);
	Attribute();
	Attribute(const Attribute& attr);
};