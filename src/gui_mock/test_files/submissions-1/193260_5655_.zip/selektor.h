#pragma once
#include "mystring.h"
#include "wordsstring.h"
#include "atrybutlist.h"

class Selektor
{
public:
	wordsString name;
	AttributeList listaAtrybutow;
	int liczbaAtrybutow = 0;

public:
	void addName(myString& string);
	void addAttribute(Attribute newAttribute);
	void deleteAttribute(myString& name);
	void printName();
	void print();
	Selektor();
	~Selektor();
};