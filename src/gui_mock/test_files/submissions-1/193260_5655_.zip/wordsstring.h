#pragma once
#include "mystring.h"

class wordsString
{
public:
	int liczbaSlow = 0;
	myString* head;
	wordsString();
	~wordsString();
	void addNewWord(myString& string);
	void printList() const;
	bool checkIfInclude(myString& phrase) const;
	void deleteList();
	void wypiszNty(int n) const;
};