#include "app.h"
#include <iostream>
using namespace std;

bool operator==(const myString& str, const char* tablica)
{
    myString tmp(tablica);
    Litera* currThis = str.head;
    Litera* currTmp = tmp.head;
    while (currThis != nullptr && currTmp != nullptr)
    {
        if (currThis->znak != currTmp->znak)
        {
            return false;
        }
        currThis = currThis->nastepna;
        currTmp = currTmp->nastepna;
    }
    return (currThis == nullptr && currTmp == nullptr);
}

void App::toggle()
{
    this->startAnalize = !this->startAnalize;
    this->startReading = !this->startReading;
}


void App::manageCommends()
{

    if (tmpString == "??") {
        tmpString.deleteString();
        return;
    }
    if ((firstCommend->isMyStringDigit()) && !(*firstCommend == ""))
    {
        int index = firstCommend->convertToNumber();
        if (thirdCommend->isMyStringDigit() && !(*thirdCommend == ""))
        {
            int index2 = thirdCommend->convertToNumber();
            if (*secondCommend == "S")
            {
                MainList.WypiszNTySelektorDlaSekcjiNr(index, index2);
            }
        }
        else if (*secondCommend == "S" && *thirdCommend == "?")
        {
            MainList.WypiszLiczbeSelektorowDlaSekcjiNr(index);
            tmpString.deleteString();
        }
        else if (*secondCommend == "A" && *thirdCommend == "?")
        {
            MainList.WypiszLiczbeAtrybutowDlaSekcjiNr(index);
            tmpString.deleteString();
        }
        else if (*secondCommend == "A")
        {
            MainList.WypiszWartoscAtrybutyDlaSekcjiNr(index, *thirdCommend);
            tmpString.deleteString();
        }
        else if (*secondCommend == "D" && *thirdCommend == "*") {
            MainList.UsunSekcje(index);
            tmpString.deleteString();
        }
        else if (*secondCommend == "D" && !(*thirdCommend == "*")) {
            MainList.UsunAtrybut(index, *thirdCommend);
            tmpString.deleteString();
        }
        
    }
    else if (!(firstCommend->isMyStringDigit()) && !(*firstCommend == ""))
    {
        if (*firstCommend == "?")
        {
            cout <<"? == " << MainList.selectorCounter << endl;
            tmpString.deleteString();
        }
        else if (*secondCommend == "A" && *thirdCommend == "?")
        {
            MainList.WypiszLacznaAtrybut(*firstCommend);
        }
        else if (*secondCommend == "S" && *thirdCommend == "?")
        {
            MainList.WypiszLacznySelektor(*firstCommend);
        }
        else if (*secondCommend == "E") {
            MainList.WypiszWartoscDlaSelektora(*thirdCommend, *firstCommend);
        }
        else {
            commendNumber = 0;
        }
    }
}

void App::analizeData(char c)
{
    tmpString.addNew(c);
    if (c < ' ') {
        tmpString.deleteLast();
    }
    if (c == '\n')
    {
        enterClick = 1;
    }
    else
    {
        enterClick = 0;
    }
    if (c == ' ' && tmpString == " ")
    {
        tmpString.deleteLast();
    }

    if ((tmpString == "????") && startReading)
    {
        tmpString.deleteString();
        toggle();
        readHeader = 0;
    }
    else if ((tmpString == "****") && startAnalize)
    {
        tmpString.deleteString();
        toggle();
        readHeader = 1;
    }

    if (startAnalize)
    {
        if (c == ',')
        {
            commendNumber++;
            tmpString.deleteString();
        }
        if (commendNumber == 0)
        {
            secondCommend = nullptr;
            thirdCommend = nullptr;
            firstCommend = new myString(tmpString);
        }
        else if (commendNumber == 1)
        {
            secondCommend = new myString(tmpString);
        }
        else if (commendNumber == 2)
        {
            thirdCommend = new myString(tmpString);
            if (enterClick)
            {
                commendNumber = 0;
                tmpString.deleteString();
            }
        }
        if (enterClick)
        {
            manageCommends();
            tmpString.deleteLast();
        }
    }

    if (startReading)
    {

        if ((c == ',' || c == '{') && readHeader)
        {

            
            tmpString.deleteLast();
            tmpString.trimmBack();
            tmpSelektor.addName(tmpString);
            tmpString.deleteString();
            if (c == '{')
            {
                readHeader = 0;
                readAttributeName = 1;
            }
        }
        else if (readAttributeName && c == ':')
        {
            tmpString.deleteLast();
            tmpAtrybut.addName(tmpString);
            tmpString.deleteString();
            readAttributeName = 0;
            readAttributeValue = 1;
        }
        else if ((c == ';' || c == '}'))
        {
            tmpString.deleteLast();
            tmpAtrybut.addValue(tmpString);
            if (tmpAtrybut.name.head != nullptr)
            {
                tmpSelektor.addAttribute(Attribute(tmpAtrybut));
            }
            tmpAtrybut = Attribute();
            tmpString.deleteString();
            readAttributeValue = 0;
            if (c == '}')
            {
                readAttributeName = 0;
                readHeader = 1;
                if (tmpSelektor.liczbaAtrybutow) {
                    MainList.addSelector(tmpSelektor);
                }
                tmpSelektor = Selektor();
            }
            else
            {
                readAttributeName = 1;
            }
        }
    }
}

void App::startApp()
{
    char c;
    while (cin.get(c))
    {
        analizeData(c);
    }
    if (secondCommend == nullptr && !enterClick) {
        manageCommends();
    }
    delete firstCommend;
    delete secondCommend;
    delete thirdCommend;
}
    