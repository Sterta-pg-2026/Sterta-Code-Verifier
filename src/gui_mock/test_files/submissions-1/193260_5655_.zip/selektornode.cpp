#include "selektornode.h"

SelectorNode::SelectorNode(const Selektor& s)
{
    for (int i = 0; i < ARRAY_SIZE; i++) {
        this->selektor[i].liczbaAtrybutow = 0;
    }

    this->selektor[0] = s;
    this->next = nullptr;
    this->prev = nullptr;
    this->LiczbaDodanych = 1;
    this->LiczbaUsunietych = 0;
}

void SelectorNode::addNewSelector(const Selektor& s)
{
    this->selektor[LiczbaDodanych] = s;
    if (LiczbaDodanych < ARRAY_SIZE) {
        LiczbaDodanych++;
    }
}

void SelectorNode::print()
{
    for (int i = 0; i < LiczbaDodanych; i++)
    {
        cout << endl;
        selektor[i].print();
        cout << endl;
    }
}