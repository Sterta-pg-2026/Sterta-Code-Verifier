#include <iostream>
#include "mystring.h"
#include "app.h"
using namespace std;


int main(int argc, char *argv[])
{
   App aplikacja;
   aplikacja.startApp();
   return 0;
}
