#pragma once
#include "selektornode.h"

class SelectorList
{
public:
	SelectorNode* head;
	SelectorNode* tail;
	int selectorCounter;
	SelectorList();
	~SelectorList();
	void addSelector(const Selektor& s);
	void print() const;
	void removeSelectorNode(SelectorNode* nodeToRemove);
	void WypiszLiczbeSelektorowDlaSekcjiNr(int nrSekcji) const;
	void WypiszLiczbeAtrybutowDlaSekcjiNr(int nrSekcji) const;
	void WypiszNTySelektorDlaSekcjiNr(int nrSekcji, int Nty) const;
	void WypiszWartoscAtrybutyDlaSekcjiNr(int nrSekcji, myString& nazwaAtrybutu) const;
	void WypiszLacznaAtrybut(myString& nazwaAtrybutu) const;
	void WypiszLacznySelektor(myString& nazwaAtrybutu) const;
	void WypiszWartoscDlaSelektora(myString& nazwaAtrybutu, myString& nazwaSelektora) const;
	void UsunSekcje(int nrSekcji);
	void UsunAtrybut(int nrSekcji, myString& nazwaAtrybutu);
};