#pragma once
#include "mystring.h"
#include "wordsstring.h"
#include "selektor.h"
#include "selektorlist.h"

class App {
public:
	bool enterClick = 0;
	bool startAnalize = 0;
	bool startReading = 1;
	bool testingMode = 0;
	int commendNumber = 0;
	bool readHeader = 1;
	bool readAttributeName = 0;
	bool readAttributeValue = 0;
	myString tmpString;
	myString* firstCommend;
	myString* secondCommend;
	myString* thirdCommend;
	Attribute tmpAtrybut;
	Selektor tmpSelektor;
	SelectorList MainList;
	void manageCommends();
	void startApp();
	void analizeData(char c);
	void toggle();
};