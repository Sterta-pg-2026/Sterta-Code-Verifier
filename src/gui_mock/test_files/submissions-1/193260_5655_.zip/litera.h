#pragma once

class Litera
{
public:
	char znak;
	Litera* nastepna;
	Litera* poprzednia;
	Litera(char z);
};