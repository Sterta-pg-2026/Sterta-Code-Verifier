#include "selektor.h"
#include <iostream>
using namespace std;

void Selektor::addName(myString& string) {
    name.addNewWord(string);
}

void Selektor::printName() {
    name.printList();
}


void Selektor::addAttribute(Attribute newAttribute) {
    if (listaAtrybutow.checkIfInclude(*newAttribute.name.head)) {
        listaAtrybutow.swapAttributes(newAttribute);
    }
    else {
        listaAtrybutow.addNew(newAttribute);
        liczbaAtrybutow++;
    }

}

void Selektor::deleteAttribute(myString& name) {
        listaAtrybutow.deleteAttributes(name);
        liczbaAtrybutow--;
}


void Selektor::print() {
    printName();
    cout << "{" << endl;
    listaAtrybutow.printAttributes();
    cout << "}" << endl;
}
Selektor::Selektor()
{
    liczbaAtrybutow = 0;
    this->name = wordsString();
    this->listaAtrybutow = AttributeList();
}

Selektor::~Selektor()
{
}