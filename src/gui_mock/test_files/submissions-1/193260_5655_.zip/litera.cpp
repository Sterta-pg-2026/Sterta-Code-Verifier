#include "litera.h"
#include <iostream>
using namespace std;

Litera::Litera(char z) :znak(z) {
	this->nastepna = nullptr;
	this->poprzednia = nullptr;
}
