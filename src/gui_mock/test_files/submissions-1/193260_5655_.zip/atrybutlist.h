#pragma once
#include "atrybutnode.h"

class AttributeList {
public:
	AttributeNode* head;
	AttributeList();
	void addNew(Attribute nowyAtrybut);
	void printAttributes() const;
	bool checkIfInclude(myString& value) const;
	void swapAttributes(Attribute nowyAtrybut) ;
	void printValue(myString& name) const;
	void deleteAttributes(myString& name);
};