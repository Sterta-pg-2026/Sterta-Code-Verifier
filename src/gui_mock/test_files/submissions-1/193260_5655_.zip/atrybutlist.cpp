#include <iostream>
#include "atrybutlist.h"
using namespace std;

AttributeList::AttributeList()
{
    head = nullptr;
}

bool AttributeList::checkIfInclude(myString& value) const
{
    AttributeNode* currentNode = head;
    while (currentNode != nullptr)
    {
        if (currentNode->atrybut.name.checkIfInclude(value))
        {
            return true;
        }
        currentNode = currentNode->next;
    }
    return false;
}

void AttributeList::swapAttributes(Attribute nowyAtrybut)
{
    AttributeNode* currentNode = head;
    while (currentNode != nullptr)
    {
        if (currentNode->atrybut.name.checkIfInclude(*nowyAtrybut.name.head))
        {
            currentNode->atrybut.value = nowyAtrybut.value;
            return;
        }
        currentNode = currentNode->next;
    }
}

void AttributeList::addNew(Attribute nowyAtrybut)
{
    AttributeNode* newNode = new AttributeNode(nowyAtrybut);
    if (head == nullptr)
    {
        head = newNode;
    }
    else
    {
        AttributeNode* curr = head;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = newNode;
    }
}

void AttributeList::printAttributes() const
{
    AttributeNode* currentNode = head;
    while (currentNode != nullptr)
    {
        currentNode->atrybut.print();
        cout << endl;
        currentNode = currentNode->next;
    }
}

void AttributeList::printValue(myString& name) const
{
    if (checkIfInclude(name))
    {
        AttributeNode* currentNode = head;
        while (currentNode != nullptr)
        {
            if (currentNode->atrybut.name.checkIfInclude(name))
            {
                currentNode->atrybut.value.printList();
                cout << endl;
                return;
            }

            currentNode = currentNode->next;
        }
    }
}


void AttributeList::deleteAttributes(myString& name)
{
    if (checkIfInclude(name))
    {
        AttributeNode* curr = head;
        AttributeNode* prev = nullptr;
        while (curr != nullptr)
        {
            if (curr->atrybut.name.checkIfInclude(name)) {
                if (prev == nullptr) {
                    head = curr->next;

                }
                else {
                    prev->next = curr->next;
                }
                delete curr;
                return;
            }
            prev = curr;
            curr = curr->next;

        }
    }
}