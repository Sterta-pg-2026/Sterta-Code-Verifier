#include "atrybut.h"
#include <iostream>
using namespace std;

void Attribute::print() const {
    name.printList();
    cout << ":";
    value.printList();
    cout << ";";
}

void Attribute::deleteAttribute() {
    name.deleteList();
    value.deleteList();
}

Attribute::Attribute(wordsString* name, wordsString* value) {
    this->name = *name;
    this->value = *value;
}

Attribute::Attribute() {

}

Attribute::Attribute(const Attribute& attr) {
    this->name = attr.name;
    this->value = attr.value;
}

void Attribute::addName(myString& newName) {
    name.addNewWord(newName);
}

void Attribute::addValue(myString& newValue) {
    value.addNewWord(newValue);
}