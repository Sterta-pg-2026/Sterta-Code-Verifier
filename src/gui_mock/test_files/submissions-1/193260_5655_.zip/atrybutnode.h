#pragma once
#include "atrybut.h"

class AttributeNode {
public:
	Attribute atrybut;
	AttributeNode* next;
	AttributeNode(Attribute nowyAtrybut);
};