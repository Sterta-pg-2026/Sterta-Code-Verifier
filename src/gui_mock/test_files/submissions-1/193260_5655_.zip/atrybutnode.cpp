#pragma once
#include "atrybutnode.h"

AttributeNode::AttributeNode(Attribute nowyAtrybut) {
	Attribute* tmp = new Attribute(nowyAtrybut);
	this->atrybut.name = tmp->name;
	this->atrybut.value = tmp->value;
	this->next = nullptr;
}