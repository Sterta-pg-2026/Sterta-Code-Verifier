#pragma once
#include "litera.h"

class myString
{

public:
	Litera* head;
	Litera* tail;
	myString* next;
	myString();
	myString(char* tablica);
	myString(const char* tablica);
	myString(myString& other);
	~myString();
	void addNew(char c);
	void print() const;
	int convertToNumber() const;
	bool isDigit(char c);
	bool isMyStringDigit();
	bool isEqual(char* tablica) const;
	bool isEqual(myString string) const;
	void deleteString();
	void deleteLast();
	void trimmBack();
};