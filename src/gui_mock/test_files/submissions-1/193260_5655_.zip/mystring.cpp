#include "mystring.h"
#include <iostream>
using namespace std;

myString::myString()
{
    head=NULL;
    tail = NULL;
    next = NULL;
}

myString::myString(myString& other)
{
    head = NULL;
    tail = NULL;
    next = NULL;
    Litera* currOther = other.head;
    Litera* prev = NULL;
    while (currOther != NULL)
    {
        Litera* nowa = new Litera(currOther->znak);
        nowa->nastepna = NULL;

        if (head == NULL)
        {
            head = nowa;
        }
        else
        {
            prev->nastepna = nowa;
            nowa->poprzednia = prev;
        }

        prev = nowa;
        currOther = currOther->nastepna;
    }
}

myString::myString(char* tablica)
{
    head = NULL;
    next = NULL;
    int i = 0;
    while (tablica[i] != '\0')
    {
        this->addNew(tablica[i]);
        i++;
    }
}

myString::myString(const char* tablica) : head(NULL)
{
    next = NULL;
    int i = 0;
    while (tablica[i] != '\0')
    {
        this->addNew(tablica[i]);
        i++;
    }
}

myString::~myString()
{
    while (head != NULL)
    {
        Litera* usuwany = head;
        head = head->nastepna;
        delete usuwany;
    }
}

bool myString::isEqual(myString string) const
{
    Litera* currtmp = string.head;
    Litera* currThis = head;
    while (currThis != NULL && currtmp != NULL)
    {
        if (currThis->znak != currtmp->znak)
        {
            return false;
        }
        currThis = currThis->nastepna;
        currtmp = currtmp->nastepna;
    }
    return (currThis == NULL && currtmp == NULL);

}

bool myString::isEqual(char* tablica) const
{
    myString tmp(tablica);
    Litera* currThis = head;
    Litera* currTmp = tmp.head;
    while (currThis != NULL && currTmp != NULL)
    {
        if (currThis->znak != currTmp->znak)
        {
            return false;
        }
        currThis = currThis->nastepna;
        currTmp = currTmp->nastepna;
    }
    return (currThis == NULL && currTmp == NULL);
}





int myString::convertToNumber() const
{
    Litera* curr = head;
    int number = 0;
    while (curr != NULL)
    {
        number = number * 10 + (curr->znak - '0');
        curr = curr->nastepna;
    }
    return number;
}



void myString::deleteString()
{
    while (head != NULL)
    {
        Litera* usuwany = head;
        head = head->nastepna;
        delete usuwany;
    }
}

void myString::addNew(char c)
{
    Litera* nowa = new Litera(c);
    nowa->nastepna = NULL;
    nowa->poprzednia = tail;

    if (head == NULL)
    {
        head = nowa;
        tail = nowa;
    }
    else
    {
        tail->nastepna = nowa;
        tail = nowa;
    }
}

bool isWhite(char c) {
    return (c == ' ' || c=='/t');
}

void myString::trimmBack() {
    if (head != nullptr) {
        Litera* curr = tail;
        while (curr != nullptr && isWhite(curr->znak)) 
        {
            Litera* prev = curr->poprzednia;
            if (prev != nullptr) {
                prev->nastepna = nullptr;
            }
            else {
                head = nullptr;
            }
            delete curr;
            curr = prev;
        }
    }
}

void myString::deleteLast()
{
    if (head != NULL)
    {
        if (head->nastepna == NULL)
        {
            delete head;
            head = NULL;
            tail = NULL;
        }
        else
        {
            Litera* prev = tail->poprzednia;
            delete tail;
            tail = prev;
            tail->nastepna = NULL;
        }
    }
}

void myString::print() const
{
    Litera* curr = head;
    while (curr != NULL)
    {
        cout << curr->znak;
        curr = curr->nastepna;
    }
}

bool myString::isMyStringDigit()
{
    if (head != nullptr) {
        Litera* curr = head;
        while (curr != NULL)
        {
            if (!isDigit(curr->znak))
            {
                return false;
            }
            curr = curr->nastepna;
        }
        return true;
    }
    return false;
}



bool myString::isDigit(char c)
{
    return (c >= '0' && c <= '9');
}