#include "wordsstring.h"
#include <iostream>
using namespace std;

void wordsString::addNewWord(myString& string) {
    myString* nowe = new myString(string);

    if (head == nullptr) {
        head = nowe;
    }
    else {
        myString* curr = head;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = nowe;
    }
    if (!(nowe->head==nullptr)){
        liczbaSlow++;
    }
    
}

void wordsString::wypiszNty(int n) const {
    myString* curr = head;
    if (n > liczbaSlow) {
        return;
    }
    else {
        for (int i = 1; i < n; i++) {
            curr = curr->next;
        }
        curr->print();
        cout << endl;
    }
}

void wordsString::printList() const  {
    myString* curr = head;
    while (curr != nullptr)
    {
        curr->print();
        if (curr->next != nullptr) {
            cout << ", ";
        }
        curr = curr->next;
    }
}

bool wordsString::checkIfInclude(myString& phrase) const {
    myString* curr = head;
    while (curr != nullptr)
    {
        if (curr->isEqual(phrase)) {
            return true;
        }
        curr = curr->next;
    }
    return false;
}

void wordsString::deleteList() {

    while (head != nullptr)
    {
        myString* usuwany = head;
        head = head->next;
        usuwany->deleteString();
        delete usuwany;
    }
}

wordsString::wordsString() :head(nullptr)
{
}

wordsString::~wordsString()
{

}