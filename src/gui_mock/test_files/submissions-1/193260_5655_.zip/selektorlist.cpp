#include "selektorlist.h"
#include <iostream>
using namespace std;

SelectorList::SelectorList()
{
    head = nullptr;
    selectorCounter = 0;
    tail = nullptr;
}

SelectorList::~SelectorList()
{
    while (head != nullptr)
    {
        SelectorNode* temp = head;
        head = head->next;
        delete temp;
    }
    tail = nullptr;
    selectorCounter = 0;
}

void SelectorList::UsunSekcje(int nrSekcji)
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow)
            {
                i++;
            }
            if (j == ARRAY_SIZE-1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        curr->selektor[j] = Selektor();
        curr->LiczbaUsunietych++;
        if ((curr->LiczbaDodanych) == (curr->LiczbaUsunietych))
        {
            removeSelectorNode(curr);
        }
        selectorCounter--;
        cout <<nrSekcji<< ",D,* == deleted" << endl;
    }
}

void SelectorList::addSelector(const Selektor& s)
{
    SelectorNode* newNode = new SelectorNode(s);

    if (head == nullptr)
    {
        head = newNode;
        tail = newNode;
    }
    else if (tail->LiczbaDodanych < ARRAY_SIZE)
    {
        tail->addNewSelector(s);
    }
    else
    {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
        tail->LiczbaDodanych = 1;
    }
    selectorCounter++;
}

void SelectorList::print() const
{
    SelectorNode* curr = head;
    int j = 0;
    for (int i = 0; i < this->selectorCounter;)
    {
        if (curr->selektor[j].liczbaAtrybutow)
        {
            curr->selektor[j].print();
            i++;
        }
        if (j == ARRAY_SIZE - 1)
        {
            j = 0;
            curr = curr->next;
        }
        else
        {
            j++;
        }
    }
}

void SelectorList::WypiszLiczbeSelektorowDlaSekcjiNr(int nrSekcji) const
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow != 0)
            {

                i++;
            }
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        cout <<nrSekcji<<",S,? == "<< (curr->selektor[j].name.liczbaSlow) << endl;
    }
}

void SelectorList::WypiszWartoscAtrybutyDlaSekcjiNr(int nrSekcji, myString& nazwa) const
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow)
            {
                i++;
            }
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        if (curr->selektor[j].listaAtrybutow.checkIfInclude(nazwa)) {
            cout << nrSekcji << ",A,";
            nazwa.print();
            cout << " == ";
            curr->selektor[j].listaAtrybutow.printValue(nazwa);
        }
        
    }
}

void SelectorList::WypiszLacznaAtrybut(myString& nazwaAtrybutu) const
{
    SelectorNode* curr = head;
    int j = 0;
    int suma = 0;
    for (int i = 0; i < this->selectorCounter;)
    {
        if (curr->selektor[j].liczbaAtrybutow)
        {
            if (curr->selektor[j].listaAtrybutow.checkIfInclude(nazwaAtrybutu))
            {
                suma++;
            }
            i++;
        }
        if (j == ARRAY_SIZE - 1)
        {
            j = 0;
            curr = curr->next;
        }
        else
        {
            j++;
        }
    }
    nazwaAtrybutu.print();
    cout <<",A,? == " << suma << endl;
}
 
void SelectorList::WypiszWartoscDlaSelektora(myString& nazwaAtrybutu, myString& nazwaSelektora) const
{
    nazwaAtrybutu.trimmBack();
    nazwaSelektora.trimmBack();
    SelectorNode* curr = tail;
    int j = ARRAY_SIZE - 1;
    for (int i = 0; i < this->selectorCounter;)
    {
        if (curr->selektor[j].liczbaAtrybutow)
        {
            if (curr->selektor[j].name.checkIfInclude(nazwaSelektora))
            {
                if (curr->selektor[j].listaAtrybutow.checkIfInclude(nazwaAtrybutu))
                {
                    nazwaSelektora.print();
                    cout << ",E,";
                    nazwaAtrybutu.print();
                    cout << " == ";
                    curr->selektor[j].listaAtrybutow.printValue(nazwaAtrybutu);
                    return;
                }
            }
            i++;
        }
        if (j == 0)
        {
            j = ARRAY_SIZE - 1;
            curr = curr->prev;
        }
        else
        {
            j--;
        }
    }
};

void SelectorList::WypiszLacznySelektor(myString& nazwaSelektora) const
{
    nazwaSelektora.trimmBack();
    SelectorNode* curr = head;
    int j = 0;
    int suma = 0;
    for (int i = 0; i < this->selectorCounter;)
    {
        if (curr->selektor[j].liczbaAtrybutow)
        {
            if (curr->selektor[j].name.checkIfInclude(nazwaSelektora))
            {
                suma++;
            }
            i++;
        }
        if (j == ARRAY_SIZE - 1)
        {
            j = 0;
            curr = curr->next;
        }
        else
        {
            j++;
        }
    }
    nazwaSelektora.print();
    cout <<",S,? == "<< suma << endl;
}

void SelectorList::WypiszNTySelektorDlaSekcjiNr(int nrSekcji, int Nty) const
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow)
            {
                i++;
            }
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        if (curr->selektor[j].name.liczbaSlow >= Nty) {
            cout << nrSekcji << "," << "S," << Nty << " == ";
            curr->selektor[j].name.wypiszNty(Nty);
        }
       
    }
}

void SelectorList::WypiszLiczbeAtrybutowDlaSekcjiNr(int nrSekcji) const
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow)
            {
                i++;
            }
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        cout << nrSekcji<<",A,? == "<<(curr->selektor[j].liczbaAtrybutow) << endl;
    }
}


void SelectorList::removeSelectorNode(SelectorNode* nodeToRemove)
{
    if (!head)
    {
        return;
    }
    if (head == nodeToRemove)
    {
        head = head->next;
        delete nodeToRemove;
        return;
    }
    SelectorNode* current = head;
    while (current->next && current->next != nodeToRemove)
    {
        current = current->next;
    }
    if (!current->next)
    {
        return;
    }
    current->next = current->next->next;
    delete nodeToRemove;
}

void SelectorList::UsunAtrybut(int nrSekcji, myString& nazwaAtrybutu)
{
    SelectorNode* curr = head;
    int j = 0;
    if (nrSekcji > this->selectorCounter)
    {
        return;
    }
    else
    {
        for (int i = 1; i < nrSekcji;)
        {
            if (curr->selektor[j].liczbaAtrybutow)
            {
                i++;
            }
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        while (curr->selektor[j].liczbaAtrybutow == 0)
        {
            if (j == ARRAY_SIZE - 1)
            {
                j = 0;
                curr = curr->next;
            }
            else
            {
                j++;
            }
        }
        if (curr->selektor[j].listaAtrybutow.checkIfInclude(nazwaAtrybutu)) {
            curr->selektor[j].deleteAttribute(nazwaAtrybutu);

            if (curr->selektor[j].liczbaAtrybutow == 0)
            {
                curr->selektor[j] = Selektor();
                curr->LiczbaUsunietych++;
                this->selectorCounter--;
                if ((curr->LiczbaDodanych) == (curr->LiczbaUsunietych))
                {
                    removeSelectorNode(curr);
                }
            }
            cout << nrSekcji << ",D,";
            nazwaAtrybutu.print();
            cout << " == deleted" << endl;
        }
    }
}