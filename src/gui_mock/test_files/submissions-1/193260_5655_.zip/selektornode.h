#pragma once
#include "selektor.h"
#include <iostream>
using namespace std;

const int ARRAY_SIZE = 8;

class SelectorNode {
public:
	int LiczbaDodanych = 0;
	int LiczbaUsunietych = 0;
	Selektor selektor[ARRAY_SIZE];
	SelectorNode* next;
	SelectorNode* prev;
	void addNewSelector(const Selektor& s);
	void print();
	SelectorNode(const Selektor& s);
};