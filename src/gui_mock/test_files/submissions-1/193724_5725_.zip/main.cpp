#include <iostream>
#include <cstring>
#include <cstdlib>


using namespace std;

const int T = 30;

struct Block {
    int attributes_count = 0;
    char* attributes_names_array[T];
    char* attributes_values_array[T];

    int selectors_count = 0;
    char* selectors_array[T];

    int get_attributes_count() {
        return attributes_count;
    }

    void add_selector(char* selector_str, int selector_length) {
        if (selectors_count >= T)
            throw "can not add selector, block is full";
        selectors_array[selectors_count] = new char[selector_length + 1];
        int i;
        for (i = 0; i < selector_length; i++) {
            selectors_array[selectors_count][i] = selector_str[i];
        }
        selectors_array[selectors_count][i] = '\0';
        selectors_count++;
    }

    void add_attribute_name(char* attribute_name_str, int name_length) {
        if (attributes_count >= T)
            throw "can not add attribute name, block is full";
        attributes_names_array[attributes_count] = new char[name_length + 1];
        int i;
        for (i = 0; i < name_length; i++) {
            attributes_names_array[attributes_count][i] = attribute_name_str[i];
        }
        attributes_names_array[attributes_count][i] = '\0';
        attributes_count++;
    }

    void add_attribute_value(char* attribute_value_str, int attribute_value_length) {
        if (attributes_count >= T)
            throw "can not add attribute value, block is full";
        attributes_values_array[attributes_count - 1] = new char[attribute_value_length + 1];
        int i;
        for (i = 0; i < attribute_value_length; i++) {
            attributes_values_array[attributes_count - 1][i] = attribute_value_str[i];
        }
        attributes_values_array[attributes_count - 1][i] = '\0';
    }
    int number_of_ocurences_of_selector(char* selector) {
        int number_of_ocurences_of_selector = 0;
        for (int i = 0; i < selectors_count; i++) {
            if (strcmp(selector, selectors_array[i]) == 0)
                number_of_ocurences_of_selector++;
        }
        return number_of_ocurences_of_selector;
    }
    int number_of_ocurences_of_attribute(char* attribute) {
        int number_of_ocurences_of_attribute = 0;
        for (int i = 0; i < attributes_count; i++) {
            if (strcmp(attribute, attributes_names_array[i]) == 0)
                number_of_ocurences_of_attribute++;
        }
        return number_of_ocurences_of_attribute;
    }

    char* get_value_of_attribute(char* attribute_name) {
        for (int i = attributes_count - 1; i >= 0; i--) {
            if (strcmp(attribute_name, attributes_names_array[i]) == 0)
                return attributes_values_array[i];
        }
        return nullptr;
    }
    bool check_if_selector_exists(char* selector) {
        for (int i = selectors_count - 1; i >= 0; i--) {
            if (strcmp(selector, selectors_array[i]) == 0)
                return true;
        }
        return false;
    }
    void remove_attribute(char* attribute_name) {
        for (int i = attributes_count - 1; i >= 0; i--) {
            if (strcmp(attribute_name, attributes_names_array[i]) == 0) {
                // attribute found - remove
                for (int j = i + 1; j < attributes_count; j++) {
                    attributes_names_array[j - 1] = attributes_names_array[j];
                    attributes_values_array[j - 1] = attributes_values_array[j];
                }
                attributes_count--;
            }
        }
    }

    ~Block() {
        for (int i = 0; i < selectors_count; i++) {
            delete[] selectors_array[i];
        }
        for (int i = 0; i < attributes_count; i++) {
            delete[] attributes_names_array[i];
            delete[] attributes_values_array[i];
        }
    }

};

struct DoublyLinkedListElement {
    DoublyLinkedListElement* next = nullptr;
    DoublyLinkedListElement* previous = nullptr;

    Block data;
};

struct DoublyLinkedList {
    DoublyLinkedListElement* first = nullptr;
    DoublyLinkedListElement* last = nullptr;

    bool is_empty() {
        return first == nullptr;
    }

    void push_back() {
        DoublyLinkedListElement* old_last = last;
        last = new DoublyLinkedListElement();

        if (!is_empty()) {
            last->previous = old_last;
            old_last->next = last;
        }
        else {
            first = last;
        }
    }
    Block& get_first() {
        return first->data;
    }
    Block& get_last() {
        return last->data;
    }

    //void push_front() { }
    void delete_element(int index) {
        if (is_empty()) {
            throw "Cannot delete_element() - list is empty";
        }
        DoublyLinkedListElement* current_element = first;

        for (int j = 0; j < index; j++) {
            if (current_element->next != NULL)
                current_element = current_element->next;
            else
                throw "Cannot delete_element() - list is too short";
        }

        if (first == current_element)
            first = current_element->next;
        if (last == current_element)
            last = current_element->previous;
        if (current_element->next != NULL)
            current_element->next->previous = current_element->previous;
        if (current_element->previous != NULL)
            current_element->previous->next = current_element->next;

        delete current_element;
        return;

        // w tym momencie current_element jest i-tym elementem

        // usunąć element i połączyć jego previous i next
        // zwrócić uwagę na to, co się dzieje, gdy nie ma previous lub next
    }
    void pop_back() {
        if (!is_empty()) {
            DoublyLinkedListElement* new_last = last->previous;
            delete last;
            last = new_last;
            if (last == nullptr) {
                first = nullptr;
            }
            else {
                last->next = nullptr;
            }
        }
        else {
            throw "Cannot pop_back() - list is empty";
        }
    }

    int get_size()
    {
        DoublyLinkedListElement* current_element = first;
        int result = 0;
        while (current_element != NULL)
        {
            result++;
            current_element = current_element->next;
        }
        return result;
    }

    int number_of_occurences_of_selector(char* selector) {
        DoublyLinkedListElement* current_element = first;
        int result = 0;
        while (current_element != NULL)
        {
            // do dokończenia
            result += current_element->data.number_of_ocurences_of_selector(selector);
            current_element = current_element->next;
        }
        return result;
    }
    int number_of_occurences_of_attribute(char* attribute) {
        DoublyLinkedListElement* current_element = first;
        int result = 0;
        while (current_element != NULL)
        {
            // do dokończenia duplikaty
            result += current_element->data.number_of_ocurences_of_attribute(attribute);
            current_element = current_element->next;
        }
        return result;
    }
    char* get_value_of_attribute_for_selector(char* selector, char* attribute_name) {
        DoublyLinkedListElement* current_element = last;
        int result = 0;
        while (current_element != NULL)
        {

            if (current_element->data.check_if_selector_exists(selector)) {
                char* value;
                value = current_element->data.get_value_of_attribute(attribute_name);
                if (value != NULL)
                    return value;
            }
            current_element = current_element->previous;
        }
        return nullptr;
    }

    Block& operator[](int index) {
        DoublyLinkedListElement* current_element = first;
        if (current_element == NULL) {
            throw "no such element on list";
        }
        for (int j = 0; j < index; j++) {
            current_element = current_element->next;
            if (current_element == NULL) {
                throw "no such element on list";
            }
        }

        return current_element->data;
    }

    ~DoublyLinkedList() {
        while (!is_empty()) {
            pop_back();
        }
    }
};

bool is_number(char* str) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] < '0' || str[i] > '9') {
            return false;
        }
    }
    return true;
}

int main() {
    int count_of_occurences = 0;
    char c;
    char buffer[254];
    int i = 0;

    DoublyLinkedList list_of_blocks;
    while ((c = cin.get())) {
        if (c == '\n')
            continue;
        // jeżeli aktualny znak jest inny niż '?':
        else if (c != '?') {
            list_of_blocks.push_back();
            while (true) {


                i = 0;
                // przetwarzanie css
                // utwórz nowy blok na liście

                // wczytaj tekst do momentu napotkania ',' lub '{' 
                //(pomijamy białe znaki) (do tekstu bierzemy wcześniej wczytany znak)
                if (c != '\t' && c != '\n') {
                    buffer[i] = c;
                    i++;
                }
                while (c != ',' && c != '{') {
                    c = cin.get();
                    if (c != '\t' && c != '\n') {
                        buffer[i] = c;
                        i++;
                    }
                }

                // dodaj do bloku wczytany selektor
                list_of_blocks.get_last().add_selector(buffer, i - 1);
                //cout << "napotkano selektor " << list_of_blocks.get_last().selectors_array[list_of_blocks.get_last().selectors_count - 1] << endl;

                //c = '0';
                if (c == ',')
                    c = cin.get();
                if (c == '{') // kończymy pętle gdy nie ma selektorów
                    break;
            }




            while (true) {
                // przetwarzanie atrybutów, wczytaj znak, ale nie enter
                c = cin.get();
                while (c == '\n' || c == ' ' || c == '\t')
                    c = cin.get();
                if (c == '}')
                    break;// jeżeli napotakno } to wychodzimy z pętli
                // wczytaj tekst do momentu napotkania ':'  //(pomijamy białe znaki)
                i = 0;
                buffer[i] = c;
                i++;
                while (c != ':') {
                    c = cin.get();
                    if (c != ' ' && c != '\t' && c != '\n') {
                        buffer[i] = c;
                        i++;
                    }
                }

                // jeżeli napotkano ':' :
                if (c == ':') {
                    // dodaj wczytany atrybut do bloku
                    list_of_blocks.get_last().add_attribute_name(buffer, i - 1);
                    //cout << "napotkano atrybut " << list_of_blocks.get_last().attributes_names_array[list_of_blocks.get_last().attributes_count - 1] << endl;
                    while (c == ' ') {
                        c = cin.get(); // pomijamy spacje
                    }

                    // wczytaj tekst do momentu napotkania ';'
                    i = 0;
                    buffer[i] = c;
                    i++;

                    while (c != ';') {
                        c = cin.get();
                        buffer[i] = c;
                        i++;
                    }
                    // dodaj wczytaną wartość atrybutu do bloku, nie pomijamy spacji
                    list_of_blocks.get_last().add_attribute_value(buffer, i - 1);
                    //cout << "napotkano wartosc atrybutu " << list_of_blocks.get_last().attributes_values_array[list_of_blocks.get_last().attributes_count - 1] << endl;
                    //cout << "napotkano wartosc atrybutu " << attribute_value << endl;
                }
            }


        }

        // w przeciwnym wypadku :
        else {
            //pomiń 3 kolejne znaki ?
            c = cin.get();
            c = cin.get();
            c = cin.get();
            c = cin.get();

            // przetwarzanie kodu
            while (true) {
                c = cin.get();
                if (c == '\n')
                    continue;
                else if (c == '?') {
                    cout << "? == " << list_of_blocks.get_size() << endl;
                }

                else if (c == '*') {
                    c = cin.get();
                    c = cin.get();
                    c = cin.get();
                    c = cin.get();
                    break;
                }
                else {
                    //wczytuj znaki tak długo aż nie napotkasz przecinka 2 razy i znaku nowej linii
                    i = 0;
                    buffer[i] = c;
                    i++;

                    c = cin.get();
                    while (c != ',') {
                        buffer[i] = c;
                        i++;
                        c = cin.get();
                    }

                    char* first_variable = new char[i + 1];
                    for (int j = 0; j < i; j++) {
                        first_variable[j] = buffer[j];
                    }
                    first_variable[i] = '\0';

                    char second_variable = cin.get();
                    c = cin.get();

                    i = 0;
                    c = cin.get();
                    while (c != '\n') {
                        buffer[i] = c;
                        i++;
                        c = cin.get();
                    }

                    char* third_variable = new char[i + 1];
                    for (int j = 0; j < i; j++) {
                        third_variable[j] = buffer[j];
                    }
                    third_variable[i] = '\0';

                    //cout << "wykryto komende " << first_variable << " " << second_variable << " " << third_variable << endl;

                    // przetwarzanie komend
                    if (second_variable == 'S') {
                        if (third_variable[0] == '?') {
                            if (is_number(first_variable)) {
                                // print the number of selectors for section number 'first_variable' - 1
                                int section_number = atoi(first_variable) - 1;
                                try {
                                    cout << first_variable << ",S,? == " << list_of_blocks[section_number].selectors_count << endl;
                                }
                                catch (const char* exception) {
                                    // no such element - skip
                                }
                            }
                            else {
                                // print the total (for all blocks) number of occurrences of selector 'first_variable'
                                cout << first_variable << ",S,? == " << list_of_blocks.number_of_occurences_of_selector(first_variable) << endl;
                            }
                        }
                        else {
                            //print the j - th selector for the i - th block
                            int i = atoi(first_variable) - 1;
                            int j = atoi(third_variable) - 1;
                            // to-do try catch
                            try {
                                char* selector = list_of_blocks[i].selectors_array[j];

                                if (selector != NULL) {
                                    cout << first_variable << ",S," << third_variable << " == " << list_of_blocks[i].selectors_array[j] << endl;
                                }
                            }
                            catch (const char* exception) {
                                // no such element - skip
                            }
                        }
                    }


                    else if (second_variable == 'A') {
                        if (third_variable[0] == '?') {
                            if (is_number(first_variable)) {
                                //print the number of attributes for section number i,
                                int section_number = atoi(first_variable) - 1;
                                try {
                                    cout << first_variable << ",A,? == " << list_of_blocks[section_number].attributes_count << endl;
                                }
                                catch (const char* exception) {
                                    // no such element - skip
                                }
                            }
                            else {
                                //print the total (for all blocks) number of occurrences of attribute named n
                                cout << first_variable << ",A,? == " << list_of_blocks.number_of_occurences_of_attribute(first_variable) << endl;
                            }

                        }
                        else {
                            //print the value of the attribute with the name n for the i - th section
                            int i = atoi(first_variable) - 1;
                            try {
                                char* value = list_of_blocks[i].get_value_of_attribute(third_variable);
                                if (value != NULL) {
                                    cout << first_variable << ",A," << third_variable << " == " << value << endl;
                                }
                                // else - skip
                            }
                            catch (const char* exception) {
                                // no such element - skip
                            }
                        }
                    }


                    else if (second_variable == 'E') {
                        char* value = list_of_blocks.get_value_of_attribute_for_selector(first_variable, third_variable);
                        if (value != NULL)
                            cout << first_variable << ",A," << third_variable << " == " << value << endl;
                        //else cout << endl;
                        //print the value of the attribute named n for the selector z, in case of multiple
                           // occurrences of selector z, take the last one.I
                    }
                    else if (second_variable == 'D') {
                        if (third_variable[0] == '*') {
                            //remove the entire section number i(i.e., separators + attributes), after successful
                                //execution, print "deleted";
                            int i = atoi(first_variable) - 1;
                            list_of_blocks.delete_element(i);
                            cout << first_variable << ",D,* == " << "deleted" << endl;
                        }
                        else {
                            //remove the attribute named n from the i - th section, if the section becomes empty as a
                                //result of the operation, it should also be removed(along with any selectors), after successful
                                //execution, print "deleted"
                            try {
                                int i = atoi(first_variable) - 1;
                                Block& block = list_of_blocks[i];
                                block.remove_attribute(third_variable);
                                if (block.get_attributes_count() < 1) {
                                    list_of_blocks.delete_element(i);
                                }
                                
                                cout << first_variable << ",D," << third_variable << " == " << "deleted" << endl;
                            }
                            catch (const char* exception) {

                            }
                        }
                    }

                    delete[] first_variable;
                    delete[] third_variable;
                }
            }
        }
    }
}