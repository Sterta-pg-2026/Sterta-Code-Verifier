#pragma once
#include "selectorlist.h"
#include "attributelist.h"

class Block
{
public:
	Block();
	Block(SelectorList* selectorList, AttributeList* attributeList);
	~Block();

	SelectorList* selectorList;
	AttributeList* attributeList;
};

