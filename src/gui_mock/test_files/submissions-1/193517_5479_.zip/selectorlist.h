#pragma once
#include "selector.h"

class SelectorList
{
public:
	SelectorList();
	~SelectorList();

	Selector* head, * tail;

	Selector* find(const String& s);
	void add(Selector* selector);

	std::size_t size;
};

