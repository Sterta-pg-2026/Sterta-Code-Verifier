#pragma once
#define T 19
#include <iostream>
#include "block.h"

class Section
{
public:
	Section();
	~Section();

	void append(Block* block);
	void remove(Block* block);

	Block* blocksArr[T];
	Section* next, * prev;

	std::size_t blocksSize;
};

