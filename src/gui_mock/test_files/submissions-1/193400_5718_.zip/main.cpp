#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include "structures.h"
#include "engine.h"
#include "mystring.h"
using namespace std;

int main()
{
	Engine engine;
	engine.getInput();
	return 0;
}