#include <iostream>

#define CZYTAJ_CSS 0
#define CZYTAJ_KOMENDY 1
#define CZYTAJ_SELEKTORY 0
#define CZYTAJ_ATRUBUTY 1
#define MAKS_DLUGOSC_POLECENIA 100
#define MAKS_DLUGOSC_KOMENDY 6
#define LICZBA_BLOKOW 8

using namespace std;

// STOS DO SELEKTOROW PO PRZECINKU I PO KOLEJI JECHANIE PO ATRYBUTACH

// STOS DLA ATRYBUTUW

struct Atrybut // LISTA ATRYBUTOW
{
    Atrybut* next;
    char nazwa[MAKS_DLUGOSC_POLECENIA];
    char wartosc[MAKS_DLUGOSC_POLECENIA];
};

struct Blok // LISTA BLOKOW
{
    char selektory[MAKS_DLUGOSC_POLECENIA];
    Atrybut elementy;
};

struct Sekcja // LISTA SEKCJI
{
    Sekcja* next;
    Sekcja* previous;
    Blok blok[LICZBA_BLOKOW];
    int zajete_bloki = 0;
};


void wczytuj_nazwe(int* i, char tresc[], Atrybut* nowy_atrybut)
{
    cin >> tresc;
    int j = 0;
    for (*i; (*i) < MAKS_DLUGOSC_POLECENIA && tresc[j] != '\0'; (*i)++)
    {
        nowy_atrybut->wartosc[*i] = tresc[j];
        j++;
    }
    (*i)--;
}

int dodaj_atrybut(Atrybut** head)
{
    char tresc[MAKS_DLUGOSC_POLECENIA];
    int kontynuuj_dodawanie_atrybutow = 1, i, j;
    Atrybut* nowy_atrybut = new Atrybut;
    nowy_atrybut->next = nullptr;
    //Atrybut* ostatni_atrybut = *head;
    while (kontynuuj_dodawanie_atrybutow)
    {
        cin >> tresc;

        if (tresc[0] == '}')
        {
            kontynuuj_dodawanie_atrybutow = 0;
        }
        else if (tresc[0] == '{' && tresc[1] == '\0')
        {
            kontynuuj_dodawanie_atrybutow = 1;
        }
        else
        {


            //DODAWANIE NAZWY
            i = 0, j = 0;
            for (i = 0; i < MAKS_DLUGOSC_POLECENIA && tresc[i] != '\0' && tresc[i] != ':'; i++)
            {
                if (tresc[i] != '{')
                {
                    nowy_atrybut->nazwa[j] = tresc[i];
                    j++;
                }
                
            }      
            nowy_atrybut->nazwa[j] = '\0';

            if (*head == nullptr)
            {
                *head = nowy_atrybut;
            }
            else
            {
                
                //while (ostatni_atrybut->next != nullptr)
                //{
                   // ostatni_atrybut = ostatni_atrybut->next;
                //}
                nowy_atrybut->next = nowy_atrybut;
            }

    
            // DODAWANIE WARTOSCI
            cin >> tresc;
            for (i = 0; i < MAKS_DLUGOSC_POLECENIA-1 && tresc[i] != '\0'; i++)
            {
                nowy_atrybut->wartosc[i] = tresc[i];
                if (tresc[i + 1] == '}')
                {
                    kontynuuj_dodawanie_atrybutow = 0;
                }
            }
            if (i > 0)
            {
                i--;
            }

            while (nowy_atrybut->wartosc[i] != ';' && nowy_atrybut->wartosc[i] != '}')
            {
                i++;
                nowy_atrybut->wartosc[i] = ' ';
                i++;
                wczytuj_nazwe(&i, tresc, nowy_atrybut);
            }/*
            if (tresc[i] == '}')
            {
                kontynuuj_dodawanie_atrybutow = 0;
            }*/
            nowy_atrybut->wartosc[i] = '\0';

            //TEST DZIALANIA STRUKTURY - 2.04.2023 15:02:57
            for (i = 0; i < 50; i++)
            {
                if (nowy_atrybut->nazwa[i] == '\0')
                {
                    i = 50;
                }
                else
                {
                    cout << nowy_atrybut->nazwa[i];
                }
            }
            cout << " ";
            for (i = 0; i < 50; i++)
            {
                if (nowy_atrybut->wartosc[i] == '\0')
                {
                    i = 50;
                }
                else
                {
                    cout << nowy_atrybut->wartosc[i];
                }
            }
            cout << endl;
        }

       
    }

    return kontynuuj_dodawanie_atrybutow;
}

void wczytaj_selektor(int* i, char tresc[], Blok *nowy_blok)
{
    cin >> tresc;
    int j = 0;
    for (*i; (*i) < MAKS_DLUGOSC_POLECENIA && tresc[j] != '\0'; (*i)++)
    {
        nowy_blok->selektory[*i] = tresc[j];
        j++;
    }
    (*i)--;
}

int dodaj_blok(Sekcja* nowy_element)
{
    int numer_bloku = nowy_element->zajete_bloki;
    char tresc[MAKS_DLUGOSC_POLECENIA];
    Blok* nowy_blok = new Blok;
    Atrybut* head = nullptr;
    
    cin >> tresc;
    if (tresc[0] == '?' && tresc[1] == '?' && tresc[2] == '?' && tresc[3] == '?')
    {
        return 0; // koniec sekcji css
    }

    int i;
    for (i = 0; i < MAKS_DLUGOSC_POLECENIA && tresc[i] != '\0'; i++)
    {
        nowy_blok->selektory[i] = tresc[i];
    }
    if (i > 0)
    {
        i--;
    }

    while (nowy_blok->selektory[i] == ',')
    {
        nowy_blok->selektory[i] = ' ';
        i++;
        wczytaj_selektor(&i, tresc, nowy_blok);
    }
    i++;
    nowy_blok->selektory[i] = '\0';
    cout << nowy_blok->selektory << endl;

    int kontynuuj_dodawanie_atrybutow = 1;
    
    //while (kontynuuj_dodawanie_atrybutow)
    //{
        kontynuuj_dodawanie_atrybutow = dodaj_atrybut(&head);
    //}
    nowy_blok->elementy = *head;

    if (numer_bloku < LICZBA_BLOKOW)
    {
        nowy_element->blok[numer_bloku] = *nowy_blok;
        nowy_element->zajete_bloki = numer_bloku++;
    }
    else
    {
        cout << "PRZEKROCZONO DOMYSLNA LICZBE BLOKOW" << endl;
        delete nowy_blok;
    }
    //*nowy_element->blok = *nowy_blok;
    return 1;
}

void czytaj_css(Sekcja** head) // dodawanie sekcji
{
    int dodawaj_bloki = 1;

    Sekcja* nowy_element = new Sekcja;
    nowy_element->next = nullptr;

    if (*head == nullptr)
    {
        
        nowy_element->previous = nullptr;       
    }
    else
    {
        Sekcja* ogon = *head;
        while (ogon->next != nullptr)
        {
            ogon = ogon->next;
        }
        ogon->next = nowy_element;
        nowy_element->previous = ogon;
    }
    *head = nowy_element;

    while(dodawaj_bloki)
    {
        dodawaj_bloki = dodaj_blok(nowy_element);
        nowy_element->zajete_bloki++;
    }
}

void wypisz_liczbe_sekcji_css(Sekcja* head)
{
    int liczba_sekcji = 0;
    Sekcja* biezaca_sekcja = head;

    while (biezaca_sekcja != nullptr)
    {
        liczba_sekcji++;
        biezaca_sekcja = biezaca_sekcja->next;
    }

    cout << "? == " << liczba_sekcji << endl;
}

void wypisz_liczbe_selektorow(Sekcja* head, int numer_sekcji)
{

}

int czytaj_komendy(Sekcja** head)
{
    char polecenie[MAKS_DLUGOSC_KOMENDY];
    while (!(cin.eof()))
    {
        cin >> polecenie;/*
        if (polecenie[0] == '*' && polecenie[1] == '*' && polecenie[2] == '*' && polecenie[3] == '*')
        {
            return 1;
        }
        else if (polecenie[0] == '?')
        {
            wypisz_liczbe_sekcji_css(*head);
        }
        else
        {
            int i = 1;
            char litera;
            while(polecenie[i] != ',')
            {
                i++;
            }
            litera = polecenie[++i];
            //cout << litera;
        }*/
    }
    return 0;
 
    /*   
    i, S, ? – wypisz liczbę selektorów dla sekcji nr i(numery zaczynają się od 1), jeśli nie ma takiego bloku
        pomiń;
    i, A, ? -wypisz liczbę atrybutów dla sekcji nr i, jeśli nie ma takiego bloku lub sekcji pomiń;
    i, S, j – wypisz j - ty selector dla i - tego bloku(numery sekcji oraz atrybutów zaczynają się od 1) jeśli nie
        ma sekcji lub selektora pomiń;
    i, A, n – wypisz dla i - tej sekcji wartość atrybutu o nazwie n, jeśli nie ma takiego pomiń;
    n, A, ? – wypisz łączną(dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n. (W ramach
        pojedynczego bloku duplikaty powinny zostać usunięte na etapie wczytywania).Możliwe jest 0;
    z, S, ? – wypisz łączną(dla wszystkich bloków) liczbę wystąpień selektora z.Możliwe jest 0;
    z, E, n – wypisz wartość atrybutu o nazwie n dla selektora z, w przypadku wielu wystąpień selektora z
        bierzemy ostatnie.W przypadku braku pomiń;
    i, D, * -usuń całą sekcję nr i(tj.separatory + atrybuty), po poprawnym wykonaniu wypisz deleted;
    i, D, n – usuń z i - tej sekcji atrybut o nazwie n, jeśli w wyniku operacji pozostaje pusta sekcja powinna
        zostać również usunięta(wraz z ew.selektorami), po poprawnym wykonaniu wypisz deleted.
*/
}

void wyswietl_liste_sekcji(Sekcja* head)
{
    Sekcja* sekcja = head;
    while (sekcja != nullptr)
    {
        cout << "SEKCJA:" << endl;
        for (int i = 0; i < sekcja->zajete_bloki; i++)
        {
            cout << "Bloku " << i + 1 << ": " << sekcja->blok[i].selektory << endl;
            Atrybut* atrybut = &(sekcja->blok[i].elementy);
            while (atrybut != nullptr)
            {
                cout << atrybut->nazwa << " = " << atrybut->wartosc << endl;
                atrybut = atrybut->next;
            }
        }
        sekcja = sekcja->next;
    }
}


int main()
{
    int tryb_czytania = CZYTAJ_CSS, kontynuuj_czytanie = 1;
    Sekcja* head = nullptr;

    while (kontynuuj_czytanie)
    {
        if (tryb_czytania == CZYTAJ_CSS)
        {
            czytaj_css(&head);
            tryb_czytania = CZYTAJ_KOMENDY;
            kontynuuj_czytanie=0;
        }
        else
        {
            kontynuuj_czytanie = czytaj_komendy(&head);
            //wyswietl_liste_sekcji(head);
            tryb_czytania = CZYTAJ_CSS;
        }
    }
}