#include <iostream>
using namespace std;

constexpr int s = 8;

class String {
public:
	char* arr;
	int size;
	int capacity;
	String(int capacity) :capacity(capacity), size(0) {
		arr = new char[capacity];
	}

	void pushback(char c) {
		if (size < capacity) {
			arr[size] = c;
			size++;
		}
		else {
			capacity *= 2;
			char* newarr = new char[capacity];
			for (int i = 0; i < size; i++) {
				newarr[i] = arr[i];
			}
			delete[] arr;
			newarr[size] = c;
			arr = newarr;
			size++;
		}
	}

	void printString() {
		for (int i = 0; i < size; i++) {
			cout << arr[i];
		}
	}
	char getLastLetter() {
		return arr[size - 1];
	}
	~String() {
		delete[] arr;
	}

};


template <typename Type>
class Node {
public:
	Node* next;
	Node* prev;
	Type* values[s];
	int size = 0;
	Node(Type* value, Node* next, Node* prev) {
		this->next = next;
		this->prev = prev;
		for (int i = 1; i < s; i++) {
			values[i] = nullptr;
		}
		values[0] = value;
		size++;
	}
	~Node() {
		for (int i = 0; i < s; i++) {
			if (values[i] != nullptr) {
				delete values[i];
				values[i] = nullptr;
			}
		}
	}
};
template <typename Type>
class List {
public:
	Node<Type>* head;
	Node<Type>* tail;
	List(Node<Type>* head, Node<Type>* tail, bool isEmpty) {
		this->head = head;
		this->tail = tail;
		this->isEmpty = isEmpty;
		idlast = 0;
		n = 0;
	}
	int n;
	bool isEmpty;
	int idlast;
	void pushBack(Type* value) {
		n++;
		idlast++;
		value->id = idlast;
		if (head == nullptr && tail == nullptr) {
			Node<Type>* node = new Node<Type>(value, NULL, NULL);
			head = node;
			tail = node;
			isEmpty = false;
		}
		else {
			if (tail->values[s-1] == nullptr) {
				for (int i = s - 1; i >= 0; i--) {
					if (tail->values[i] != nullptr) {
							tail->values[i + 1] = value;
							tail->size++;
							return;
					}
					else if (i == 0) {
						tail->values[i] = value;
						tail->size++;
						return;
					}
				}
			}
			else {
				Node<Type>* node = new Node<Type>(value, NULL, NULL);
				tail->next = node;
				node->prev = tail;
				tail = node;
			}
		}
	}
	Node<Type>* getNode(int i) {
		int numberNode;
		numberNode = (i - 1) / s;
		Node<Type>* node = head;
		while (node != nullptr && numberNode > 0) {
			numberNode--;
			node = node->next;
		}
		return node;
	}

	Type* getElement(int i) {
		Node<Type>* node = getNode(i);
		int indeks = (i - 1) % s;
		Type* element = node->values[indeks];
		return element;
	}

	Type* getElement3(int i) {
		Node<Type>* node = head;
		int nElement = 0;
		while (node != nullptr) {
			for (int j = 0; j < s; j++) {
				if (node->values[j] != nullptr) {
					nElement++;
					if (nElement == i) {
						return node->values[j];
					}
					else if (nElement > i) {
						return nullptr;
					}
				}
			}
			node = node->next;
		}
		return nullptr;
	}
	void removeNode(Node<Type>* node) {
		if (node == head && node == tail) {
			head = nullptr;
			tail = nullptr;
			delete node;
		}
		else if (node == head) {
			head = node->next;
			delete node;
			head->prev = nullptr;
		}
		else if (node == tail) {
			tail = node->prev;
			delete node;
			tail->next = nullptr;
		}
		else {
			Node<Type>* prevNode = node->prev;
			Node<Type>* nextNode = node->next;
			delete node;
			prevNode->next = nextNode;
			nextNode->prev = prevNode;
		}
	}


	~List() {
		while (head != NULL) {
			Node<Type>* node = head;
			head = head->next;
			delete node;
		}
		tail = NULL;
	}
};

struct Attribute {
	Attribute() :name(16), value(64) {
	}
	String name;
	String value;
	int id = 0;
};

struct Selector {
	Selector() :name(64) {
	}
	String name;
	int id = 0;
};
class Section {
public:
	Section() : listSelectors(NULL, NULL, true), listAtributes(NULL, NULL, true), id(0) {
	}
	List<Attribute> listAtributes;
	List<Selector> listSelectors;
	int id;
};
enum class ReadType { CSS, Commands };

char readChar(bool& endOfInput);
char readCharWithSpaces(bool& endOfInput);
void readSelectors(List<Selector>& selectors, char znak);
void readAttributes(List<Attribute>& attributes);
bool areStringsEven(String& string1, String& string2);
void numberOfSections(List<Section>& sections);//?
void numberOfSelectorsForSection(List<Section>& sections, int i);//i,S,?
void numberOfAttributesForSection(List<Section>& sections, int i);//i,A,?
void nameOfSelectorForSection(List<Section>& sections, int i, int j);//i,S,j
void valueOfAttributeByName(List<Section>& sections, String& name, int i);//i,A,n
void numberOfAttribiutesByName(List<Section>& sections, String& name); //n,A,?
void numberOfSelectorsByName(List<Section>& sections, String& name);//z,S,?
void valueOfAttribute(List<Section>& sections, String& nameAttribute, String& nameSelector);//z,E,n
void deleteSection(List<Section>& sections, int i);//i,D,*
void deleteAttribute(List<Section>& sections, String& name, int i);//i,D,n
void readInput(List<Section>& sections);
void readNext3Chars();
void readSectionCSS(List<Section>& sections, char znak);
void readCommand(List<Section>& sections, char znak);
int readNumber(char znak);
bool isDigit(char znak);
char readChar();
char readCharWithSpaces();
void readAttributeName(String& attributeName, char znak);
void readString(String& name, char znak);
int readLastNumber(char znak);

int main()
{
	List<Section> sections(NULL, NULL, true);
	readInput(sections);
	return 0;
}
void readInput(List<Section>& sections) {
	ReadType readType = ReadType::CSS;
	while (true) {
		bool endOfInput = false;
		char znak = readChar(endOfInput);
		if (endOfInput == true) {
			return;
		}
		if (znak == '?' && readType == ReadType::CSS) {
			readNext3Chars();
			readType = ReadType::Commands;
			continue;
		}
		else if (znak == '*' && readType == ReadType::Commands) {
			readNext3Chars();
			readType = ReadType::CSS;
			continue;
		}
		if (readType == ReadType::CSS) {
			readSectionCSS(sections, znak);
		}
		else if (readType == ReadType::Commands) {
			readCommand(sections, znak);
		}
	}
}


void readNext3Chars() {
	char znak;
	for (int i = 0; i < 3; i++) {
		cin.get(znak);
	}
}

void readSectionCSS(List<Section>& sections, char znak) {
	Section* section = new Section();
	if (znak != '{') {
		readSelectors(section->listSelectors, znak);
	}
	readAttributes(section->listAtributes);
	sections.pushBack(section);
}

void readCommand(List<Section>& sections, char znak) {

	if (isDigit(znak)) {
		int i = readNumber(znak);
		znak = readChar();
		readChar();
		if (znak == 'S') {
			znak = readChar();
			if (znak == '?') {
				numberOfSelectorsForSection(sections, i);
			}
			else {
				int j = readLastNumber(znak);
				nameOfSelectorForSection(sections, i, j);
			}
		}
		else if (znak == 'A') {
			znak = readChar();
			if (znak == '?') {
				numberOfAttributesForSection(sections, i);
			}
			else {
				String attributeName(32);
				readAttributeName(attributeName, znak);
				valueOfAttributeByName(sections, attributeName, i);
			}
		}
		else if (znak == 'D') {
			znak = readChar();
			if (znak == '*') {
				deleteSection(sections, i);
			}
			else {
				String attributeName(32);
				readAttributeName(attributeName, znak);
				deleteAttribute(sections, attributeName, i);
			}
		}
		else {
			while (znak != '\n') {
				cin.get(znak);
			}
		}
	}
	else if (znak == '?') {
		numberOfSections(sections);
	}
	else {
		String name(64);
		readString(name, znak);
		znak = readChar();
		readChar();
		if (znak == 'A') {
			znak = readChar();
			if (znak == '?') {
				numberOfAttribiutesByName(sections, name);
			}
		}
		else if (znak == 'S') {
			znak = readChar();
			if (znak == '?') {
				numberOfSelectorsByName(sections, name);
			}
			else {
				while (znak != '\n') {
					cin.get(znak);
				}
			}
		}
		else if (znak == 'E') {
			znak = readChar();
			String attributeName(32);
			readAttributeName(attributeName, znak);
			valueOfAttribute(sections, attributeName, name);
		}
		else {
			while (znak != '\n') {
				cin.get(znak);
			}
		}
	}
}

void readString(String& name, char znak) {
	name.pushback(znak);
	znak = readCharWithSpaces();
	while (znak != ',') {
		name.pushback(znak);
		znak = readCharWithSpaces();
	}
}

void readAttributeName(String& attributeName, char znak) {
	attributeName.pushback(znak);
	znak = readCharWithSpaces();
	while (znak != ' ' && znak != '\n') {
		attributeName.pushback(znak);
		znak = readCharWithSpaces();
	}
}


int readNumber(char znak) {
	int number = 0;
	while (true) {
		int digit = znak - '0';
		cin.get(znak);
		number += digit;
		if (znak == ',') {
			return number;
		}
		else {
			number *= 10;
		}
	}
}

int readLastNumber(char znak) {
	int number = 0;
	while (true) {
		int digit = znak - '0';
		cin.get(znak);
		number += digit;
		if (znak == '\n') {
			return number;
		}
		else {
			number *= 10;
		}
	}
}


bool isDigit(char znak) {
	if (znak >= '0' && znak <= '9') {
		return true;
	}
	else {
		return false;
	}
}


char readChar(bool& endOfInput) {
	char znak;
	if (!cin.get(znak)) {
		endOfInput = true;
		return znak;
	}
	while (znak == ' ' || znak == '\n' || znak == '\t') {
		if (!cin.get(znak)) {
			endOfInput = true;
			return znak;
		}
	}
	return znak;
}

char readChar() {
	char znak = ' ';
	while (znak == ' ' || znak == '\n' || znak == '\t') {
		cin.get(znak);
	}
	return znak;
}

char readCharWithSpaces() {
	char znak;
	cin.get(znak);
	return znak;
}

char readCharWithSpaces(bool& endOfInput) {
	char znak;
	if (!cin.get(znak)) {
		endOfInput = true;
	}
	while (znak == '\n') {
		if (!cin.get(znak)) {
			endOfInput = true;
		}
	}
	return znak;
}

void readSelectors(List<Selector>& selectors, char znak) {
	bool endOfInput = false;
	Selector* selector = nullptr;
	while (znak <= ' ') {
		cin.get(znak);
	}
	while (znak != '{') {
		selector = new Selector();
		selectors.pushBack(selector);
		while (znak != ',' && znak != '{') {
			selector->name.pushback(znak);
			znak = readCharWithSpaces(endOfInput);
			if (znak < ' ') {
				continue;
			}
		}
		if (znak == ',') {
			znak = readChar(endOfInput);
		}
	}
	if (selector->name.getLastLetter() == ' ') {
		selector->name.size--;
	}
}

void ifAttributesNotDuplicate(List<Attribute>& attributes, Attribute* newAttribute) {
	Node<Attribute>* attribute = attributes.head;
	while (attribute != nullptr) {
		for (int i = 0; i < s; i++) {
			if (attribute->values[i] != nullptr) {
				if (areStringsEven(attribute->values[i]->name, newAttribute->name) == true) {
					Attribute* tmp = attribute->values[i];
					attribute->values[i] = newAttribute;
					delete tmp;
					return;
				}
			}
		}
		attribute = attribute->next;
	}
	attributes.pushBack(newAttribute);
}

void readAttributes(List<Attribute>& attributes) {
	char znak = 'x';
	bool endOfInput = false;
	while (znak != '}') {
		char znak = readChar(endOfInput);
		if (znak == '}') {
			return;
		}
		if (znak == '{') {
			znak = readChar(endOfInput);
		}
		Attribute* attribute = new Attribute;
		while (znak != ':') {
			attribute->name.pushback(znak);
			znak = readChar(endOfInput);
		}
		znak = readChar(endOfInput);
		while (znak != ';' && znak != '}') {
			attribute->value.pushback(znak);
			znak = readCharWithSpaces(endOfInput);
		}
		ifAttributesNotDuplicate(attributes, attribute);

	}
}

bool areStringsEven(String& string1, String& string2) {
	if (string1.size == string2.size) {
		for (int ii = 0; ii < string1.size; ii++) {
			if (string1.arr[ii] != string2.arr[ii]) {
				return false;
			}
		}
		return true;
	}
	else {
		return false;
	}
}

void numberOfSections(List<Section>& sections) {
	Node<Section>* section = sections.head;
	int n = 0;
	while (section != nullptr) {
		for (int i = 0; i < s; i++) {
			if (section->values[i] != nullptr) {
				n++;
			}
		}
		section = section->next;
	}
	cout << "? == " << n << endl;
}

void numberOfSelectorsForSection(List<Section>& sections, int i) {
	if (i > sections.n) {
		return;
	}
	Section* section = sections.getElement3(i);
	if (section != nullptr) {
		cout << i << ",S,? == " << section->listSelectors.n << endl;
	}
}

void numberOfAttributesForSection(List<Section>& sections, int i) {
	if (i > sections.n) {
		return;
	}
	Section* section = sections.getElement3(i);
	if (section != nullptr) {
		cout << i << ",A,? == " << section->listAtributes.n << endl;
	}
}

void nameOfSelectorForSection(List<Section>& sections, int i, int j) {
	if (i > sections.n) {
		return;
	}
	Section* section = sections.getElement3(i);
	List<Selector>& selectors = section->listSelectors;
	if (j > selectors.n) {
		return;
	}
	Selector* selector = selectors.getElement(j);
	if (selector) {
		cout << i << ",S," << j << " == ";
		selector->name.printString();
		cout << endl;
	}
}

void valueOfAttributeByName(List<Section>& sections, String& name, int i) {
	if (i > sections.n) {
		return;
	}
	Section* section = sections.getElement3(i);
	if (section != nullptr) {
		List<Attribute>& attributes = section->listAtributes;
		Node<Attribute>* attribute = attributes.head;
		while (attribute != nullptr) {
			for (int ii = 0; ii < s; ii++) {
				if (attribute->values[ii] != nullptr && areStringsEven(attribute->values[ii]->name, name) == true) {
					cout << i << ",A,";
					name.printString();
					cout << " == ";
					attribute->values[ii]->value.printString();
					cout << endl;
					return;
				}
			}
			attribute = attribute->next;
		}
	}
}

void numberOfAttribiutesByName(List<Section>& sections, String& name) {
	Node<Section>* node = sections.head;
	int counter = 0;
	while (node != nullptr) {
		for (int j = 0; j < s; j++) {
			if (node->values[j] != nullptr) {
				List<Attribute>& attributesList = node->values[j]->listAtributes;
				Node<Attribute>* attribute = attributesList.head;
				while (attribute != nullptr) {
					for (int i = 0; i < s; i++) {
						if (attribute->values[i] != nullptr) {
							if (areStringsEven(attribute->values[i]->name, name) == true) {
								counter++;
								break;
							}
						}
					}
					attribute = attribute->next;
				}
			}
		}
		node = node->next;
	}
	name.printString();
	cout << ",A,? == ";
	cout << counter << endl;;
}

void numberOfSelectorsByName(List<Section>& sections, String& name) {
	Node<Section>* node = sections.head;
	int counter = 0;
	while (node != nullptr) {
		for (int j = 0; j < s; j++) {
			if (node->values[j] != nullptr) {
				List<Selector>& selectorsList = node->values[j]->listSelectors;
				Node<Selector>* selector = selectorsList.head;
				while (selector != nullptr) {
					for (int i = 0; i < s; i++) {
						if (selector->values[i] != nullptr) {
							if (areStringsEven(selector->values[i]->name, name) == true) {
								counter++;
								break;
							}
						}
					}
					selector = selector->next;
				}
			}
		}
		node = node->next;
	}
		name.printString();
		cout << ",S,? == ";
		cout << counter << endl;
}

void valueOfAttribute(List<Section>& sections, String& nameAttribute, String& nameSelector) {
	Node<Section>* node = sections.tail;
	while (node != nullptr) {
		for (int j = s - 1; j >= 0; j--) {
			if (node->values[j] != nullptr) {
				List<Selector>& selectorsList = node->values[j]->listSelectors;
				Node<Selector>* selector = selectorsList.head;
				while (selector != nullptr) {
					for (int i = 0; i < s; i++) {
						if (selector->values[i] != nullptr) {
							if (areStringsEven(selector->values[i]->name, nameSelector) == true) {
								List<Attribute>& attributesList = node->values[j]->listAtributes;
								Node<Attribute>* attribute = attributesList.head;
								while (attribute != nullptr) {
									for (int k = 0; k < s; k++) {
										if (attribute->values[k] != nullptr) {
											if (areStringsEven(attribute->values[k]->name, nameAttribute) == true) {
												nameSelector.printString();
												cout << ",E,";;
												nameAttribute.printString();
												cout << " == ";
												attribute->values[k]->value.printString();
												cout << endl;
												return;
											}
										}
									}
									attribute = attribute->next;
								}
								break;
							}
						}
					}
					selector = selector->next;
				}
			}
		}
		node = node->prev;
	}
}

void deleteSection(List<Section>& sections, int i) {
	if (i > sections.n) {
		return;
	}
	int sectionNumber = 0;
	Node<Section>* node = sections.head;
	while (node != nullptr) {
		for (int j = 0; j < s; j++) {
			if (node->values[j] != nullptr) {
				sectionNumber++;
				if (sectionNumber == i) {
					delete node->values[j];
					node->values[j] = nullptr;
					node->size--;
					sections.n--;
					cout << i << ",D,* == deleted" << endl;
					if (node->size == 0) {
						sections.removeNode(node);
					}
					return;
				}
				else if (sectionNumber > i) {
					return;
				}
			}
		}
		node = node->next;
	}
}

void deleteAttribute(List<Section>& sections, String& name, int i) {
	if (i > sections.n) {
		return;
	}
	int sectionNumber = 0;
	Node<Section>* sectionNode = sections.head;
	while (sectionNode != nullptr) {
		for (int j = 0; j < s; j++) {
			if (sectionNode->values[j] != nullptr) {
				sectionNumber++;
				if (sectionNumber == i) {
					Section* section = sectionNode->values[j];
					if (section != nullptr) {
						List<Attribute>& attributes = section->listAtributes;
						Node<Attribute>* attribute = attributes.head;
						while (attribute != nullptr) {
							for (int ii = 0; ii < s; ii++) {
								if (attribute->values[ii] != nullptr && areStringsEven(attribute->values[ii]->name, name) == true) {
									delete attribute->values[ii];
									attribute->size--;
									attributes.n--;
									attribute->values[ii] = nullptr;
									if (attributes.n == 0) {
										delete section;
										sectionNode->values[j] = nullptr;
										sectionNode->size--;
										sections.n--;
										if (sectionNode->size == 0) {
											sections.removeNode(sectionNode);
										}
									}
									cout << i << ",D,";
									name.printString();
									cout << " == deleted" << endl;
									return;
								}
							}
							attribute = attribute->next;
						}
						return;
					}
				}
				else if (sectionNumber > i) {
					return;
				}
			}
		}
		sectionNode = sectionNode->next;
	}

}