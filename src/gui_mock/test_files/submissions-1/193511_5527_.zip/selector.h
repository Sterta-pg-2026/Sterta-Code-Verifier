#pragma once
#ifndef PARSER_CSS_SELECTOR_H
#define PARSER_CSS_SELECTOR_H
#include "string.h"

class Selector {
private:
    String name;
public:
    Selector();
    String& getName();
    bool isEmpty();
    friend std::ostream& operator<<(std::ostream& out, const Selector& selector);
    ~Selector();
};


#endif //PARSER_CSS_SELECTOR_H
