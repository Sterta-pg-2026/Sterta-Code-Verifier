
#define T 8
#define LINE 200
#define COMMAND 40
using namespace std;

//structs
struct Selectors {
    char selector_name[LINE] = {
};
    int lp = 0;
    Selectors* next = nullptr;
};

struct Atributes {
    char attribute_name[LINE] = {
};
    char attribute_value[LINE] = {
};
    Atributes* next = nullptr;
};
struct SelectorAttribute {
    int n_selectors = 0;
    int n_attributes = 0;
    Selectors* heads = nullptr;
    Atributes* heada = nullptr;
};

struct Node {
    int number;
    int spaceOccupied = 0;
    SelectorAttribute* array[T];
    Node* next = nullptr;
    Node* previous;
};

//Node operations
//create new node
Node* createNode() {
    Node* newNode = new Node;
    newNode->number = 0;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    for (int i = 0; i < T; i++) {
        newNode->array[i] = nullptr;
    
}

    return newNode;
}
//
Node* goToFirstNode(Node* currentNode) {
    while (currentNode->number != 1) {
        currentNode = currentNode->previous;
    
}
    // currentNode teraz wskazuje na pierwszy element
    return currentNode;
}
Node* goToLastNode(Node* element) {
    Node* lastNode = element;
    while (lastNode->next != nullptr) {
        lastNode = lastNode->next;
    
}
    return lastNode;
}
Node* go_to_Node(Node* first_node, int number, int* liczba) {
    Node* current = first_node;
    while (current != nullptr) {
        number -= current->spaceOccupied;
        if (number <= 0) {
            *liczba = number + current->spaceOccupied;
            return current;
        
}
        current = current->next;
    
}
    return nullptr;
}



//commands
// print number of occupied blocks
int countOccupiedSpaces(Node* firstNode) {
    int totalOccupiedSpaces = 0;
    Node* currentNode = firstNode;
    while (currentNode != nullptr) {
        totalOccupiedSpaces += currentNode->spaceOccupied;
        currentNode = currentNode->next;
    
}
    return totalOccupiedSpaces;
}

//i,S,?,   
//i,A,?  
//count Selectors or attributes / funkcja słuzy i do atrybutów i do selektorów
int SelectorsAttributes_count(Node* element, int n, char SorA) {
    int liczba = 0;
    Node* current = go_to_Node(element, n, &liczba);
    //jesli nie ma takiego Node zwracamy, wartosc nie bedzie brana pod uwage
    if (current == nullptr) return -1;
    //znajdujemy które miejjsce sposród T zajmuje
    for (int i = 0; i < T; i++) {
        if (current->array[i] != nullptr) {
            liczba--;
        
}
        if (!liczba) {
            liczba = i;
            break;
        
}
    
}
    //w zaleznosci od znaku komendy funkcja liczy co innego
    if (SorA == 'S') {
        return current->array[liczba]->n_selectors;
    
}
    else
        return current->array[liczba]->n_attributes;
}

//i,S,j 
//print jth selector ith block 
int print_selector_name(Node* node, int selector_attribute_num, int selector_num) {
    int liczba = 0;
    Node* current = go_to_Node(node, selector_attribute_num, &liczba);
    //znajdujemy które miejsce sposrod 8 zajmuje
    if (current == nullptr)return 0;
    for (int i = 0; i < T; i++) {
        if (current->array[i] != nullptr) {
            liczba--;
        
}
        if (!liczba) {
            liczba = i;
            break;
        
}
    
}
    Selectors* s = current->array[liczba]->heads;
    //znajdujemy selektor o danym numerze
    for (int i = 1; i < selector_num; i++) {
        s = s->next;
    
}
    if (s->selector_name == NULL)return 0;
    cout << selector_attribute_num << ",S," << selector_num << " == " << s->selector_name << endl;
    return 0;
}

//i,A,n
int print_value(Node* node, int selector_attribute_num, const char* attribute) {
    int liczba = 0;
    Node* current = go_to_Node(node, selector_attribute_num, &liczba);
    if (current == nullptr)return 0;
    //szukamy miejsca sposród 8 w Node które zajmuje
    for (int i = 0; i < T; i++) {
        if (current->array[i] != nullptr) {
            liczba--;
        
}
        if (!liczba) {
            liczba = i;
            break;
        
}
    
}
    Atributes* a = current->array[liczba]->heada;
    //szukamy wartosci danego atrybutu
    while (a != nullptr) {
        if (strcmp(a->attribute_name, attribute) == 0) {
            cout << selector_attribute_num << ",A," << attribute << " == ";
            cout << a->attribute_value << endl;
            return 0;

        
}
        a = a->next;

    
}
    return 0;
}

//n,A,? 
//count n named attributes in whole structure/ przeszukujemy wszystkie Node i wszystie sekcje i znajdujemy pasujacy atrybut
void count_attributes(Node* first_node, const char* attribute) {
    int count = 0;
    if (first_node == nullptr)return;
    Node* current = first_node;
    while (current != nullptr) {
        for (int i = 0; i < T; i++) {
            if (current->array[i] != nullptr) {
                Atributes* A = current->array[i]->heada;
                while (A != nullptr) {
                    if (!strcmp(attribute, A->attribute_name)) {
                        count++;
                        break;
                    
}
                    A = A->next;
                
}
            
}
        
}
        current = current->next;
    
}
    cout << attribute << ",A,? == " << count << endl;
}

//n,S,? count how many times n named selector occurs/ przeszukujemy wszystkie Node i wszystie sekcje i znajdujemy pasujacy selektor
void print_selector_count(Node* first_node, const char* selector_name) {
    int count = 0;
    //zaczynamy od pierwszego Node
    Node* current_node = first_node;
    while (current_node != nullptr) {
        for (int i = 0; i < T; i++) {
            SelectorAttribute* sa = current_node->array[i];
            if (sa == nullptr) continue;
            if (sa->heads == nullptr) continue;
            Selectors* s = sa->heads;
            while (s != nullptr) {
                if (strcmp(s->selector_name, selector_name) == 0) {
                    count++;
                
}
                s = s->next;
            
}
        
}
        current_node = current_node->next;
    
}
    cout << selector_name << ",S,?" << " == " << count << endl;
}


//z,E,n
int print_last_value(Node* last_node, const char* selector_name, const char* attribute_name) {
    //zaczynamy w ostatnim Node
    Node* current = last_node;
    //szukamy w kazdym Node
    while (current->number > 0) {
        //szukamy w kazdej sekcji
        for (int i = T; i > 0; i--) {
            SelectorAttribute* sa = current->array[i - 1];
            if (sa == nullptr) continue;
            Selectors* S = sa->heads;
            //sprawdzamy selektory
            while (S != nullptr) {
                if (!strcmp(selector_name, S->selector_name)) {
                    Atributes* A = sa->heada;
                    //sprawdzamy atrybuty
                    while (A != nullptr) {
                        if (!strcmp(attribute_name, A->attribute_name)) {
                            cout << selector_name << ",E," << attribute_name << " == " << A->attribute_value << endl;
                            return 0;
                        
}
                        A = A->next;
                    
}
                
}
                S = S->next;
            
}

        
}
        if (current->number == 1)return 0;
        current = current->previous;
    
}
    return 0;
}


//i,D,*

//deletes lists/funkcje usuwaja element listy zwracajac nastepny
Selectors* delete_selector(Selectors* sel) {
    Selectors* next = sel->next;
    delete[] sel;
    return next;
}
//
Atributes* delete_attributes(Atributes* att) {
    Atributes* next = att->next;
    delete[] att;
    return next;
}
//usuwanie obu list
void delete_blockv2(SelectorAttribute* array) {
    SelectorAttribute* sa = array;

    while (sa->heads != nullptr)
        sa->heads = delete_selector(sa->heads);

    while (sa->heada != nullptr)
        sa->heada = delete_attributes(sa->heada);
    sa->heads = nullptr;
    sa->heada = nullptr;
    delete[]sa;
}
//i,D,* deletes ith block 
void delete_block(Node* first_node, int number) {
    int liczba = 0;
    Node* current = go_to_Node(first_node, number, &liczba);
    if (current == nullptr)return;
    for (int i = 0; i < T; i++) {
        if (current->array[i] != nullptr) {
            liczba--;
        
}
        if (!liczba) {
            liczba = i;
            break;
        
}
    
}

    delete_blockv2(current->array[liczba]);
    current->array[liczba] = nullptr;
    current->spaceOccupied--;
    current->array[liczba] = nullptr;
    cout << number << ",D,* == " << "deleted" << endl;
}

//i,D,n deleting attributes

//function checks if the block has more than one attribute if not delete, same thing with Node
void check_if_not_empty(Node* node_to_check, int liczba) {
    if (node_to_check->array[liczba] != nullptr) {
        SelectorAttribute* sa = node_to_check->array[liczba];
        if (sa->n_attributes == 0)delete_blockv2(node_to_check->array[liczba]);
        else return;
        node_to_check->array[liczba] = nullptr;
        node_to_check->spaceOccupied--;
        if (node_to_check->spaceOccupied == 0) {
            Node* previous = node_to_check->previous;
            Node* next = node_to_check->next;
            previous->next = next;
            next->previous = previous;
            while (next != nullptr) {
                next->number--;
                next->next;
            
}
            delete[] node_to_check;
        
}
    
}

}


//i,D,n 
//deleting attribute 
void delete_attribute(Node* first_node, int number, const char* attribute) {
    int liczba = 0;
    Node* current = go_to_Node(first_node, number, &liczba);
    if (current == nullptr)return;
    //znajdujemy numer w którym znajduje sie dana sekcja
    for (int i = 0; i < T; i++) {
        if (current->array[i] != nullptr) {
            liczba--;
        
}
        if (!liczba) {
            liczba = i;
            break;
        
}
    
}
    SelectorAttribute* sa = current->array[liczba];
    Atributes* a = sa->heada;
    Atributes* prev = sa->heada;
    //szukamy atrybutu do usuniecia
    while (a != nullptr) {
        if (!strcmp(a->attribute_name, attribute)) {
            if (prev->next == a->next) sa->heada = a->next;
            else prev->next = a->next;
            delete[] a;
            sa->n_attributes--;
            if (sa->n_attributes == 0) {
                sa->heada = nullptr;
                //sprawdzamy czy sekcja i node nie są puste
                check_if_not_empty(current, liczba);
            
}
            cout << number << ",D," << attribute << " == deleted" << endl;
            return;
        
}
        prev = a;
        a = a->next;
    
}
}





//sprawdza czy to numer, słuzy do analizowania czesci komend, konwertuje char do int
bool check_if_number(char* str, int* number) {
    //porównywanie pierwszego znaku z cyframi od 0-9 
    for (char j = 48; j < 58; j++) {
        if (str[0] == j) {
            *number = atoi(str);
            return true;
        
}
    
}
    return false;
}

//liczy znaki
int countCharacters(const char* str) {

    int count = 0;
    for (int i = 0; str[i] != '\0'; ++i) {
        count++;
    
}
    return count;
}






//adding to structures
//add selector
void add_selector(SelectorAttribute* array, const char* temp) {
    // Tworzenie nowego elementu listy
    Selectors* check = array->heads;
    //sprawdzamy czy selektor sie nie powtórzył
    while (check != nullptr) {
        if (!strcmp(check->selector_name, temp))return;
        check = check->next;
    
}
    Selectors* new_selector = new Selectors;
    new_selector->next = nullptr;

    // Wczytywanie nazwy selektora
    strcpy_s(new_selector->selector_name, temp);

    // Dodawanie nowego elementu na koniec listy
    if (array->heads == nullptr) {
        array->heads = new_selector;
    
}
    else {
        Selectors* current = array->heads;
        while (current->next != nullptr) {
            current = current->next;
        
}
        current->next = new_selector;
    
}
    array->n_selectors++;
}

Atributes* add_attribute2(SelectorAttribute* array, const char* temp) {
    //dodawanie pierwszego atrybutu z listy
    if (array->heada == nullptr) {
        array->heada = new Atributes;
        strcpy_s(array->heada->attribute_name, temp);
        array->n_attributes++;
        return array->heada;
    
}

    Atributes* current = array->heada;
    Atributes* prev = array->heada;
    //szukamy atrybutu o tej samej nazwie jesli taki wysapił zwracamy go jesli nie wpisujemy
    while (current != nullptr) {
        if (strcmp(current->attribute_name, temp) == 0) {
            break;
        
}
        prev = current;
        current = current->next;
    
}
    if (current == nullptr) {
        current = new Atributes;
        array->n_attributes++;
        prev->next = current;
    
}
    strcpy_s(current->attribute_name, temp);
    return current;

}
bool add_value2(Atributes* current, const char* value) {
    if (value == NULL) {
        strcmp(current->attribute_name, '\0');
        for (int i = 0; i < sizeof(current->attribute_name); i++)
            if (current->attribute_name[i] != '\0')current->attribute_name[i] = '\0';
        return false;
    
}
    strcpy_s(current->attribute_value, value);

    return true;
}

bool read_line_selectors(const char* str, char* rest, SelectorAttribute* array)
{
    int i = 0, substr_count = 0;
    char tmp[LINE] = "";
    int index = 0;
    int selectors = 0;
    while (str[i] != '\0') {
        switch (str[i])
        {
        case '{':
            if (index > 0) {
                selectors++;
                tmp[index++] = '\0';
                // tu zapisac selektor
                add_selector(array, tmp);
            
}
            // ostatni kawałek przekazac do analizy body
            if (str[i + 1] == 9)return true;
            for (int g = i + 1; g < countCharacters(str); g++)
                rest[substr_count++] = str[g];
            return true; /// przejdz do analizy bloku atrybutow
            break;
            //dla tych znaków pomijamy
        case 9:
            break;
        case 10:
            break;
        case 13:
            break;
            //
        case ',': // nowy selektor
            if (index > 0) {
                tmp[index++] = '\0';
                selectors++;
                add_selector(array, tmp);
                strcpy_s(tmp, "\0"); index = 0; // kasujemy stary selektor
            
}
            break;
        case   ' ':
            if ((str[i + 1] != '\0') && ((str[i + 1] == ' ') || (str[i + 1] == ',') || (str[i + 1] == '{')))
            {
                i++; continue;
            
}
            if ((str[i + 1] == '\0') || (index == 0)) { i++; continue; 
}
            tmp[index++] = str[i];
            break;
        default: tmp[index++] = str[i];
        
}
        i++;
    
}
    if (index > 0) {
        tmp[index++] = '\0';
        selectors++;
        // tu zapisac selektor
        add_selector(array, tmp);
    
}
    return false; // czytac dalej selektory
}

bool read_line_attributes(const char* str, SelectorAttribute* array, int* block_array)
{
    int i = 0;
    char tmp[LINE] = "";
    int index = 0;
    int attributes = 0;
    int values = 0;
    bool attr_val = true;
    Atributes* new_att = new Atributes;
    while (str[i] != '\0') {
        switch (str[i])
        {
        case '}':
            if (index > 0) {
                values++;
                tmp[index++] = '\0';
                add_value2(new_att, tmp);
            
}
            return false; // przejdz do analizy kolejnego bloku
            break;
        case ';':
            attr_val = true;
            if (index > 0) {
                values++;
                tmp[index++] = '\0';
                add_value2(new_att, tmp);
                strcpy_s(tmp, "\0"); index = 0; // kasujemy bufor
            
}
            break;
        case ':': // nowy atrybut
            attr_val = false; // wczytany atrybut i teraz wartosc
            if (index > 0) {
                tmp[index++] = '\0';
                attributes++;
                new_att = add_attribute2(array, tmp);
                strcpy_s(tmp, "\0"); index = 0; // kasujemy bufor
            
}
            break;
        case 9:
            break;

        case   ' ':
            if (attr_val == false && index > 0) { tmp[index++] = str[i];  i++; continue; 
}

            if ((str[i + 1] != '\0') && (str[i + 1] == ' ')) {
                i++; continue;
            
}
            if (index > 0)
            {
                if (attr_val)
                {
                    tmp[index++] = '\0';
                    attributes++;
                    attr_val = false; // wczytany atrybut i teraz wartosc
                    new_att = add_attribute2(array, tmp);
                
}
                else
                {
                    tmp[index++] = '\0';
                    values++;
                    attr_val = true; // wczytana wartosc
                    add_value2(new_att, tmp);
                
}
            
}
            strcpy_s(tmp, "\0"); index = 0; // kasujemy stary selektor
            break;
        default: tmp[index++] = str[i];
        
}
        i++;
    
}
    /*if (index > 0) {
        values++;
        tmp[index++] = '\0';
        add_value2(new_att, tmp);
    }*/
    return true;
}

bool parse_command(const char* str, char* str1, char* str2, char* sign)
{

    int i = 0;
    int k = 0;
    int command = 0;
    while (str[i] != '\0') {
        if (str[i] == ',') {
            if (command == 0)str1[i] = '\0';
            command++;
            k = 0;
            i++;
            continue;
        
}
        //pierwsza czesc komendy
        if (command == 0)str1[k] = str[i];
        //znak A,S,D,E
        if (command == 1)*sign = str[i];
        //druga czesc komendy
        if (command == 2)str2[k] = str[i];
        i++;
        k++;
    
}
    if (command == 0)str1[i] = '\0';
    str2[k] = '\0';
    if (command == 0)return false;
    else return true;
}
//analize command, maintain instructions
bool read_command(const char* str, Node* element) {
    int n1 = 0, n2 = 0;
    int i = 0;
    char sign;
    char first_c_part[COMMAND];
    char last_c_part[COMMAND];
    bool command_long = parse_command(str, first_c_part, last_c_part, &sign);
    //dłuższa komenda skladajaca sie z 3 czesci
    if (command_long) {

        switch (sign) {
        case('S'):
            if (last_c_part[0] == '?') {
                //i,S,?
                if (check_if_number(first_c_part, &n1)) {
                    int sel_count = SelectorsAttributes_count(goToFirstNode(element), n1, 'S');
                    if (sel_count > -1) {
                        cout << str;
                        cout << " == ";
                        cout << sel_count << endl;
                    
}
                
}
                //z,S,?
                else print_selector_count(goToFirstNode(element), first_c_part);
                return true;
            
}
            //i,S,j 
            if (check_if_number(last_c_part, &n2)) {
                n1 = atoi(first_c_part);
                print_selector_name(goToFirstNode(element), n1, n2);
            
}
            return true;
        case('D'):
            //i,D,*
            if (check_if_number(first_c_part, &n1)) {
                if (last_c_part[0] == '*') {
                    delete_block(goToFirstNode(element), n1);
                    return true;
                
}
                //i,D,n
                else {

                    delete_attribute(goToFirstNode(element), n1, last_c_part);
                    return true;
                
}
            
}
        case('A'):
            //z,S,?
            if (last_c_part[0] == '?') {
                if (check_if_number(first_c_part, &n1)) {
                    int att_cmd = SelectorsAttributes_count(goToFirstNode(element), n1, 'A');
                    if (att_cmd > 0)
                    {
                        cout << str;
                        cout << " == ";
                        cout << att_cmd << endl;
                        return true;
                    
}
                
}
                //n,A,?
                else {
                    count_attributes(goToFirstNode(element), first_c_part);
                    return true;
                
}
            
}
            //i,A,n
            else {
                check_if_number(first_c_part, &n1);
                Node* e = goToFirstNode(element);
                print_value(e, n1, last_c_part);
            
}
            return true;
        case('E'):
            //z,E,n
            print_last_value(goToLastNode(element), first_c_part, last_c_part);
            return true;
        
}
    
}
    //komendy typu ? i ****
    else {
        while (first_c_part[i] != '\0')
        {
            switch (str[i]) {
            case('?'):
                //?
                cout << "? == " << countOccupiedSpaces(goToFirstNode(element)) << endl;
                return true;
            case('*'):
                if (!strcmp(str, "****"))return false;
            default:
                return true;
            
}
        
}


    
}

    return true;
}

void read_css(Node* element)
{
    //tworzenie pierwszego miejsca w array
    element->array[0] = new SelectorAttribute;
    char line[LINE];
    bool attribute = false;
    bool command = false;

    char rest[LINE] = "";
    int block_array = 0;
    while (cin.getline(line, LINE)) {
        if (!command) {
            //????
            command = strcmp(line, "????") == 0;
            if (command) {
                continue;
            
}
        
}
        if (command) {
            command = read_command(line, element);
            if (!command) {
                continue;
            
}
        
}
        else {
            if (!attribute) {
                //wczytywanie selektorów
                attribute = read_line_selectors(line, rest, element->array[block_array]);

            
}
            else {
                //wczytywanie atrybutów
                attribute = read_line_attributes(line, element->array[block_array], &block_array);
                if (!attribute)element->spaceOccupied++;
                if (!attribute) {
                    block_array++;
                    //tworzenie nowego elementu tablicy; po kazdej zapisanej sekcji tworzony jest element array
                    if (block_array < T) {
                        element->array[block_array] = new SelectorAttribute;
                        element->array[block_array]->heads = nullptr;
                        element->array[block_array]->heada = nullptr;
                    
}
                    else {
                        block_array = 0;
                        Node* newElement = createNode();
                        newElement->number = element->number + 1;
                        newElement->previous = element;
                        element->next = newElement;
                        newElement->array[block_array] = new SelectorAttribute;
                        element = newElement;
                    
}
                
}
            
}
            //wczytywanie atrybutów kiedy w jednej linii jest atrybut i selektor
            if (countCharacters(rest) > 0)
            {
                attribute = read_line_attributes(rest, element->array[block_array], &block_array);
                if (!attribute)element->spaceOccupied++;
                rest[0] = '\0';
                block_array++;
                if (block_array < T) {
                    element->array[block_array] = new SelectorAttribute;
                    element->array[block_array]->heads = nullptr;
                    element->array[block_array]->heada = nullptr;
                
}
                //tworzymy nowego Node jesli miejsca były juz zajete
                else {
                    block_array = 0;
                    Node* newElement = createNode();
                    newElement->number = element->number + 1;
                    newElement->previous = element;
                    element->next = newElement;
                    newElement->array[block_array] = new SelectorAttribute;
                    element = newElement;
                
}

            
}
        
}

    
}

}
int main() {
    Node* First = createNode();//new Node;
    First->number = 1;
    read_css(First);

}