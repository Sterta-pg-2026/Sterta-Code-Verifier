#include <iostream>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

using namespace std;

const int BLOCKSIZE = 19;
const int BUFFORSIZE = 1024;
const int COMMANDCOMPONENTS = 3;

bool isNumber(char* arr) {
	if (!arr) {
		return false;
	}
	int k = 0;
	while (arr[k] != '\0') {
		if (!isdigit(arr[k])) {
			return false;
		}
		k++;
	}
	return true;
}

class Selector {
public:
	char* selectorName;
	Selector* next;
	Selector* prev;
	Selector(char* text) {
		selectorName = text;
		next = nullptr;
		prev = nullptr;
	}

	Selector* getNext() {
		return next;
	}

	Selector* getPrev() {
		return prev;
	}

	void setNext(Selector& next_p) {
		next = &next_p;
	}

	void setPrev(Selector& prev_p) {
		prev = &prev_p;
	}

	char* getSelectorName() {
		return selectorName;
	}

	~Selector() {
		delete[] selectorName;
		selectorName = nullptr;
	}
};

class SelectorList {
private:
	int selectorCounter;
	Selector* head;
	Selector* last;
public:
	bool global;
	SelectorList() {
		head = nullptr;
		last = nullptr;
		selectorCounter = 0;
		global = false;
	}

	int getAmmount() const{
		return selectorCounter;
	}

	void addLast(char* text) {
		Selector* newNode = new Selector(text);
		if (head == nullptr && last == nullptr) {
			head = newNode;
			last = newNode;
		}
		else {
			newNode->setPrev(*last);
			last->setNext(*newNode);
			last = newNode;
		}
		selectorCounter++;
		
	}
	void setCounter(int n) {
		this->selectorCounter = n;
	}

	bool findSelector(char* text) const{
		if (head != nullptr && last != nullptr) {
			Selector* temp1 = head;
			Selector* temp2 = last;
			int i = 0;
			while (i <= selectorCounter / 2) {
				if (!strcmp(temp1->getSelectorName(), text) || !strcmp(temp2->getSelectorName(), text)) {
					return true;
				}
				temp1 = temp1->getNext();
				temp2 = temp2->getPrev();
				i++;
			}
		}

		return false;
	}

	char* find(int j) {
		Selector* temp = head;
		int i = 1;
		while (temp != nullptr && j <= selectorCounter && i != j) {
			temp = temp->getNext();
			i++;
		}
		if (i == j) {
			return temp->getSelectorName();
		}
		return nullptr;
	}

	~SelectorList() {
		Selector* temp = head;
		while (temp != nullptr) {
			Selector* next = temp->next;
			delete temp;
			temp = nullptr;
			temp = next;
		}
	}
};

class Attribute {
public:
	char* property;
	char* value;
	Attribute* next;
	Attribute* prev;
	Attribute(char* property_p, char* value_p) {
		property = property_p;
		value = value_p;
		next = nullptr;
		prev = nullptr;
	}

	void setAttributeValue(char* text) {
		delete[] value;
		value = nullptr;
		value = text;
	}

	Attribute* getNext() {
		return next;
	}

	Attribute* getPrev() {
		return prev;
	}

	void setNext(Attribute& next_p) {
		this->next = &next_p;
	}

	void setPrev(Attribute& prev_p) {
		this->prev = &prev_p;
	}

	char* getAttributeProperty() {
		return property;
	}

	char* getAttributeValue() {
		return value;
	}

	~Attribute() {
		delete[] property;
		property = nullptr;
		delete[] value;
		value = nullptr;
	}
};

class AttributeList {
public:
	int attributeCounter;
	Attribute* head;
	Attribute* last;
	AttributeList() {
		head = nullptr;
		last = nullptr;
		attributeCounter = 0;
	}

	int getAmmount() const{
		return attributeCounter;
	}

	void addLast(char* property, char* value) {
		Attribute* newNode = new Attribute(property, value);
		if (head == nullptr && last == nullptr) {
			head = newNode;
			last = newNode;
		}
		else {
			newNode->setPrev(*last);
			last->setNext(*newNode);
			last = newNode;
		}
		attributeCounter++;
	}

	Attribute* findAttribute(char* text) {
		if (head != nullptr && last != nullptr) {
			Attribute* temp1 = head;
			Attribute* temp2 = last;
			int i = 0;
			while (i <= attributeCounter / 2) {
				if (!strcmp(temp1->getAttributeProperty(), text)) {
					return temp1;
				}

				if (!strcmp(temp2->getAttributeProperty(), text)) {
					return temp2;
				}
				temp1 = temp1->getNext();
				temp2 = temp2->getPrev();
				i++;
			}
		}
		return nullptr;
	}

	bool findValue(char* text) const{
		if (head != nullptr && last != nullptr) {
			Attribute* temp1 = head;
			Attribute* temp2 = last;
			int i = 0;
			while (i <= attributeCounter / 2) {
				if (!strcmp(temp1->getAttributeProperty(), text) || !strcmp(temp2->getAttributeProperty(), text)) {
					return true;
				}
				temp1 = temp1->getNext();
				temp2 = temp2->getPrev();
				i++;
			}
		}
		return false;
	}

	~AttributeList() {
		Attribute* temp = head;
		while (temp != nullptr) {
			Attribute* next = temp->next;
			delete temp;
			temp = nullptr;
			temp = next;
		}
	}
};

class Section {
public:
	SelectorList* selectors;
	AttributeList* attributes;
	Section() {
		selectors = new SelectorList();
		attributes = new AttributeList();
	}

	~Section() {
		delete selectors;
		selectors = nullptr;
		delete attributes;
		attributes = nullptr;
	}
};

class SectionListNode {
public:
	int sectionsAmmount;
	int deletedAmmount;
	Section** SectionBlock;
	SectionListNode* next;
	SectionListNode* prev;
	int* SectionBlockMap;

	SectionListNode() {
		sectionsAmmount = 0;
		deletedAmmount = 0;
		next = nullptr;
		prev = nullptr;
		SectionBlock = new Section*[BLOCKSIZE];
		for (int i = 0; i < BLOCKSIZE; i++) {
			SectionBlock[i] = nullptr;
		}
		SectionBlockMap = new int[BLOCKSIZE];
		for (int i = 0; i < BLOCKSIZE; i++) {
			SectionBlockMap[i] = 0;
		}
	}

	~SectionListNode() {
		for (int i = 0; i < BLOCKSIZE; i++) {
			if (SectionBlockMap[i]==1) delete SectionBlock[i];
		}
		delete[] SectionBlock;
		if (SectionBlockMap != nullptr) {
			delete[] SectionBlockMap;
			SectionBlockMap = nullptr;
		}
	}
};

class SectionsList {
public:
	SectionListNode* head;
	SectionListNode* last;
	SectionsList() {
		head = nullptr;
		last = nullptr;
	}

	void addNewSection() {
		Section* newSection = new Section();
		if (head == nullptr && last == nullptr) {
			SectionListNode* newNode = new SectionListNode();
			newNode->SectionBlock[0] = newSection;
			newNode->SectionBlockMap[0] = 1;
			newSection = nullptr;
			newNode->sectionsAmmount++;
			head = newNode;
			last = newNode;
			newNode = nullptr;
		}
		else {
			int sectionAmmount = last->sectionsAmmount + last->deletedAmmount;
			if (sectionAmmount < BLOCKSIZE) {
				last->SectionBlock[last->deletedAmmount + last->sectionsAmmount] = newSection;
				last->SectionBlockMap[last->deletedAmmount + last->sectionsAmmount] = 1;
				last->sectionsAmmount++;
			}
			else {
				SectionListNode* newNode = new SectionListNode();
				SectionListNode* temp = last;
				last = newNode;
				temp->next = last;
				last->prev = temp;
				last->SectionBlock[0] = newSection;
				last->SectionBlockMap[0] = 1;
				last->sectionsAmmount++;
				newNode = nullptr;
			}
		}
	}

	void addSelector(char* text) {
		if (last != nullptr) {
			int index = last->deletedAmmount + last->sectionsAmmount;
			last->SectionBlock[index - 1]->selectors->addLast(text);
		}
	}

	void addGlobalSelector(char* text) {
		if (last != nullptr) {
			int index = last->deletedAmmount + last->sectionsAmmount;
			last->SectionBlock[index - 1]->selectors->addLast(text);
			last->SectionBlock[index - 1]->selectors->setCounter(0);
			last->SectionBlock[index - 1]->selectors->global = true;;
		}
	}

	void addAttribute(char* prop, char* val) {
		if (last != nullptr) {
			int index = last->deletedAmmount + last->sectionsAmmount;
			last->SectionBlock[index - 1]->attributes->addLast(prop, val);
		}
	}

	int countSections() const {
		int counter = 0;
		SectionListNode* temp = head;
		while (temp != nullptr) {
			counter += temp->sectionsAmmount;
			temp = temp->next;
		}
		return counter;
	}

	int countSelectors(char* text) const {
		int counter = 0;
		SectionListNode* temp = head;
		while (temp != nullptr) {
			for (int i = 0; i < BLOCKSIZE; i++) {
				if (temp->SectionBlockMap[i] == 0) continue;
				counter += temp->SectionBlock[i]->selectors->findSelector(text);
			}
			temp = temp->next;
		}
		return counter;
	}

	int countAttributeValue(char* text) const {
		int counter = 0;
		SectionListNode* temp = head;
		while (temp != nullptr) {
			for (int i = 0; i < BLOCKSIZE; i++) {
				if (temp->SectionBlockMap[i] == 0) continue;
				counter += temp->SectionBlock[i]->attributes->findValue(text);
			}
			temp = temp->next;
		}
		return counter;
	}

	char* lastAttributeValue(char* selector, char* property) {
		SectionListNode* temp = last;
		while (temp != nullptr) {
			for (int i = BLOCKSIZE - 1; i >= 0; i--) {
				if (temp->SectionBlockMap[i] == 0) continue;
				bool find = temp->SectionBlock[i]->selectors->findSelector(selector);
				if (find) {
					Attribute* temp2 = temp->SectionBlock[i]->attributes->findAttribute(property);
					if (temp2 != nullptr) {
						return temp2->getAttributeValue();
					}
				}
			}
			temp = temp->prev;
		}
		return nullptr;
	}

	Attribute* findAttribute(char* text) {
		return last->SectionBlock[last->deletedAmmount + last->sectionsAmmount - 1]->attributes->findAttribute(text);
	}

	bool findSelector(char* text) {
		return last->SectionBlock[last->deletedAmmount + last->sectionsAmmount - 1]->selectors->findSelector(text);
	}

	Section* findSection(int i) {
		SectionListNode* temp = head;
		int sectionsCounter = 0;
		while (temp != nullptr) {
			for (int j = 0; j < BLOCKSIZE; j++) {
				if (temp->SectionBlockMap[j] == 1) {
					sectionsCounter++;
				}
				if (sectionsCounter == i) {
					return temp->SectionBlock[j];
				}
			}
			temp = temp->next;
		}
		return nullptr;
	}

	Section* findSectionToDelete(int i) {
		SectionListNode* temp = head;
		int sectionsCounter = 0;
		while (temp != nullptr) {
			for (int j = 0; j < BLOCKSIZE; j++) {
				if (temp->SectionBlockMap[j] == 1) {
					sectionsCounter++;
					if (sectionsCounter == i) {
						temp->SectionBlockMap[j] = 0;
						return temp->SectionBlock[j];
					}
				}
			}
			temp = temp->next;
		}
		return nullptr;
	}

	SectionListNode* findSectionNode(int i) {
		int foundSectionsCounter = 0;
		SectionListNode* temp = head;
		while (temp != nullptr) {
			foundSectionsCounter += (temp->sectionsAmmount);
			if (i <= foundSectionsCounter) {
				return temp;
			}
			temp = temp->next;
		}
		return nullptr;
	}

	void deleteSection(int i) {
		SectionListNode* s = findSectionNode(i);
		Section* toDelete = findSectionToDelete(i);
		if (s == nullptr || toDelete == nullptr) {
			return;
		}
		delete toDelete;
		toDelete = nullptr;
		s->deletedAmmount++;
		s->sectionsAmmount--;
		if (s->sectionsAmmount == 0) {
			if (s == head) {
				head = s->next;
			}
			else {
				s->prev->next = s->next;
			}
			if (s == last) {
				last = s->prev;
			}
			else {
				s->next->prev = s->prev;
			}
			delete s;
		}
		s = nullptr;
		cout << i << ",D,* == deleted" << endl;
	}

	void deleteSection(int i, char* text) {
		SectionListNode* s = findSectionNode(i);
		Section* temp = findSection(i);
		if (s == nullptr || temp == nullptr) {
			return;
		}
		Attribute* toDelete = temp->attributes->findAttribute(text);
		if (toDelete == nullptr) {
			return;
		}
		if (toDelete == temp->attributes->head) {
			temp->attributes->head = toDelete->next;
		}
		else {
			toDelete->prev->next = toDelete->next;
		}
		if (toDelete == temp->attributes->last) {
			temp->attributes->last = toDelete->prev;
		}
		else {
			toDelete->next->prev = toDelete->prev;
		}
		delete toDelete;
		toDelete = nullptr;
		temp->attributes->attributeCounter -= 1;
		if (temp->attributes->getAmmount() == 0) {
			temp = findSectionToDelete(i);
			delete temp;
			temp = nullptr;
			s->deletedAmmount++;
			s->sectionsAmmount--;
		}
		if (s->sectionsAmmount == 0) {
			if (s == head) {
				head = s->next;
			}
			else {
				s->prev->next = s->next;
			}
			if (s == last) {
				last = s->prev;
			}
			else {
				s->next->prev = s->prev;
			}
			delete s;
		}
		s = nullptr;
		cout << i << ",D," << text << " == deleted" << endl;
	}


	~SectionsList() {
		SectionListNode* temp = head;
		while (temp != nullptr) {
			SectionListNode* next = temp->next;
			delete temp;
			temp = next;
		}
	}
};

class Procesor {
public:
	SectionsList* sections;
	char* buffor;
	char* helpingBuffor;
	char* output;
	char* output2;
	bool readCSS;
	int global_i;
public:
	bool checkEndOfProgramOrEmptyLine() {
		if (feof(stdin)) {
			return true;
		}
		if (buffor[0] == '\n') {
			return true;
		}
		return false;
	}

	Procesor() {
		sections = new SectionsList();
		buffor = new char[BUFFORSIZE];
		helpingBuffor = new char[BUFFORSIZE];
		readCSS = true;
		output = nullptr;
		output2 = nullptr;
		global_i = 0;
	}

	void RUN() {
		while (true) {
			if (feof(stdin)) {
				break;
			}
			if (readCSS) {
				handleCssInput();
			}
			else {
				handleCommandInput();
			}
		}
	};

	void prepareSelectors() {
		int i = 0;
		int j = 0;
		bool outsideSelector = true;
		fgets(buffor, BUFFORSIZE, stdin);
		if (checkEndOfProgramOrEmptyLine()) {
			return;
		}
		if (buffor[0] == '?' && buffor[1] == '?' && buffor[2] == '?' && buffor[3] == '?') {
			readCSS = false;
			return;
		}
		//atrybut globalny
		if (buffor[0] == '{') {
			helpingBuffor[0] = buffor[0];
			return;
		}
		while (buffor[i] != '{') {
			if (buffor[i] == '\0') {
				outsideSelector = true;
				fgets(buffor, BUFFORSIZE, stdin);
				i = 0;
				continue;
			}
			if (outsideSelector && (buffor[i] <= ' ')) {
				i++;
				continue;
			}
			else {
				outsideSelector = false;
				if (buffor[i] == ',') outsideSelector = true;
			}
			helpingBuffor[j] = buffor[i];
			j++;
			i++;
		}
		//usuwanie niepotrzebnych znakow po ostatnim selektorze
		while (helpingBuffor[j - 1] <= ' ') {
			j--;
		}
		helpingBuffor[j] = '\0';
		global_i = i + 1;
	}

	void saveSelectors() {
		if (checkEndOfProgramOrEmptyLine()) {
			return;
		}
		if (!readCSS) {
			return;
		}
		sections->addNewSection();
		if (helpingBuffor[0] == '{') {
			output = new char[1];
			output[0] = '\0';
			sections->addGlobalSelector(output);
			output = nullptr;
			return;
		}
		int i = 0;
		int copyFrom = 0;
		while (helpingBuffor[i] != '\0') {
			if (helpingBuffor[i] == ',' || helpingBuffor[i + 1] == '\0') {
				if (helpingBuffor[i + 1] == '\0') {
					i++;
				}
				size_t selectorSize = i - copyFrom + 1;
				output = new char[selectorSize];
				for (int j = 0; j < selectorSize - 1; j++) {
					output[j] = helpingBuffor[j + copyFrom];
				}
				output[selectorSize - 1] = '\0';
				if (!sections->findSelector(output)) {
					sections->addSelector(output);
				}
				else {
					delete[] output;
				}
				output = nullptr;
				if (helpingBuffor[i] == '\0') {
					break;
				}
				else {
					i++;
					copyFrom = i;
					continue;
				}
			}
			i++;
		}
	}
	bool doesAttributeEndInThisLine(int i, bool& parse, int& j) {
		int copyOfi = i;
		if (buffor[i] == ';') {
			return true;
		}
		while (buffor[i + 1] != '\0') {
			if (buffor[i + 1] == '}') break;
			if (!(buffor[i + 1] <= ' ')) {
				return false;
			}
			i++;
		}
		helpingBuffor[j] = buffor[copyOfi];
		j++;
		parse = false;
		if (buffor[i + 1] == '}') return true;
		//pobiera } z nastepnej lini
		fgets(buffor, BUFFORSIZE, stdin);
		return true;
	}

	void parseAttributes() {
		if (checkEndOfProgramOrEmptyLine()) {
			return;
		}
		if (!readCSS) {
			return;
		}
		int i = global_i;
		int j = 0;
		bool saveProperty = true;
		bool outsideAttributeValue = true;
		bool parse = true;
		while (buffor[i] != '}' && parse) {
			if (buffor[i] == '\0') {
				fgets(buffor, BUFFORSIZE, stdin);
				i = 0;
				continue;
			}
			if ((saveProperty || outsideAttributeValue) && buffor[i] <= ' ') {
				i++;
				continue;
			}

			if (saveProperty) {
				if (buffor[i] == ':') {
					i++;
					helpingBuffor[j] = '\0';
					output = new char[j + 1];
					for (int k = 0; k < j + 1; k++) {
						output[k] = helpingBuffor[k];
					}
					j = 0;
					saveProperty = false;
					continue;
				}
			}
			else {
				if (doesAttributeEndInThisLine(i, parse, j)) {
					i++;
					helpingBuffor[j] = '\0';
					output2 = new char[j + 1];
					for (int k = 0; k < j + 1; k++) {
						output2[k] = helpingBuffor[k];
					}
					j = 0;
					saveProperty = true;
					outsideAttributeValue = true;
					Attribute* temp = sections->findAttribute(output);
					if (temp == nullptr) {
						sections->addAttribute(output, output2);
						output = nullptr;
						output2 = nullptr;
					}
					else {
						temp->setAttributeValue(output2);
						output2 = nullptr;
						delete[] output;
						output = nullptr;
					}
					continue;
				}
				if (!(buffor[i] <= ' ')) {
					outsideAttributeValue = false;
				}
			}
			helpingBuffor[j] = buffor[i];
			j++;
			i++;
		}
	}

	void parseSelectors() {
		prepareSelectors();
		saveSelectors();
	}

	void handleCssInput() {
		parseSelectors();
		parseAttributes();
	}

	void handleCommandInput() {
		bool validCommand = true;
		fgets(buffor, BUFFORSIZE, stdin);
		if (checkEndOfProgramOrEmptyLine()) {
			if (buffor[0] == '?' && buffor[1]!='\n') {
				cout << "? == " << sections->countSections() << endl;
			}
			return;
		}
		char** commands = new char* [COMMANDCOMPONENTS];
		for (int k = 0; k < COMMANDCOMPONENTS; k++) {
			commands[k] = nullptr;
		}
		parseCommand(commands,validCommand);
		if (validCommand) {
			handleCommands(commands);
		}
		for (int k = 0; k < COMMANDCOMPONENTS; k++) {
			if (commands[k] != nullptr) {
				delete[] commands[k];
				commands[k] = nullptr;
			}
		}
		delete[] commands;
	}

	void parseCommand(char** commands,bool &validateCommand) {
		if (checkEndOfProgramOrEmptyLine()) {
			return;
		}
		if (buffor[0] == '*' || buffor[1] == '*' || buffor[2] == '*' || buffor[3] == '*') {
			readCSS = true;
			return;
		}
		if (buffor[0] == '?') {
			return;
		}
		int i = 0;
		int copyFrom = 0;
		int commaCounter = 0;
		while (buffor[i] != '\0') {
			if (commaCounter > 2) {
				validateCommand = false;
				break;
			}
			if (buffor[i] == ',' || buffor[i + 1] == '\0' || buffor[i + 1] == '\n') {
				if (buffor[i + 1] == '\0' || buffor[i + 1] == '\n') {
					i++;
				}
				int commandSize = i - copyFrom + 1;
				commands[commaCounter] = new char[commandSize];
				for (int j = 0; j < commandSize - 1; j++) {
					commands[commaCounter][j] = buffor[j + copyFrom];
				}
				commands[commaCounter][commandSize - 1] = '\0';
				commaCounter++;
				if (buffor[i] == '\0' || buffor[i] == '\n') {
					break;
				}

				else {
					i++;
					copyFrom = i;
					continue;
				}
			}
			i++;
		}
	}

	void handleCommands(char** commands) {
		if (checkEndOfProgramOrEmptyLine()) {
			return;
		}
		if (buffor[0] == '*' || buffor[1] == '*' || buffor[2] == '*' || buffor[3] == '*') {
			readCSS = true;
			return;
		}
		int k = 0;
		while (buffor[k] != '\n') {
			if (buffor[k + 1] != '?' && buffor[k+1] != '\n' ) {
				break;
			}
			if (buffor[k] == '?' ) {
				cout << "? == "  << sections->countSections() << endl;
			}
			k++;
		}
		if (buffor[0] == '?') {
			return;
		}
		int i = 0;
		int j = 0;
		bool isDigit_i = isNumber(commands[0]);
		bool isDigit_j = isNumber(commands[2]);
		if (isDigit_i) {
			i = atoi(commands[0]);
		}
		if (isDigit_j) {
			j = atoi(commands[2]);
		}
		if (commands[1][0] == 'S') {
			if (isDigit_i) {
				Section* temp = sections->findSection(i);
				if (temp != nullptr) {
					if (commands[2][0] == '?') {
						cout << i << ",S,? == " << temp->selectors->getAmmount() << endl;
						temp = nullptr;
						return;
					}
					if (isDigit_j) {
						char* text = temp->selectors->find(j);
						if (text != nullptr && !temp->selectors->global) {
							cout << i << ",S," << j << " == " << text << endl;
						}
						text = nullptr;
						temp = nullptr;
						return;
					}
				}
			}
			else {
				if (commands[2][0] == '?') {
					cout << commands[0] << ",S,? == " << sections->countSelectors(commands[0]) << endl;
				}
				return;
			}
		}
		else if (commands[1][0] == 'A') {
			if (isDigit_i) {
				Section* temp = sections->findSection(i);
				if (temp != nullptr) {
					if (commands[2][0] == '?') {
						if (temp->attributes == nullptr) return;
						cout << i << ",A,? == " << temp->attributes->getAmmount() << endl;
						temp = nullptr;
						return;
					}
				}
				if (!isDigit_j) {
					if (temp != nullptr) {
						Attribute* temp2 = temp->attributes->findAttribute(commands[2]);
						if (temp2 != nullptr ) {
							cout << i << ",A," << commands[2] << " == " << temp2->getAttributeValue() << endl;
						}
						temp = nullptr;
						return;
					}
				}
			}
			else {
				if (commands[2][0] == '?') {
					cout << commands[0] << ",A,? == " << sections->countAttributeValue(commands[0]) << endl;
				}
				return;
			}
		}
		else if (commands[1][0] == 'E') {
			char* text = sections->lastAttributeValue(commands[0], commands[2]);
			if (text != nullptr) {
				cout << commands[0] << ",E," << commands[2] << " == " << text << endl;
			}
			text = nullptr;
			return;
		}
		else if (commands[1][0] == 'D') {
			if (isDigit_i) {
				if (commands[2][0] == '*') {
					sections->deleteSection(i);
					return;
				}
				else {
					sections->deleteSection(i, commands[2]);
				}
			}
		}
		return;
	}

	~Procesor() {
		if (buffor != nullptr) delete[] buffor;
		if (helpingBuffor != nullptr) delete[] helpingBuffor;
		if (sections != nullptr) delete sections;
		if (output != nullptr) delete[] output;
		if (output2 != nullptr) delete[] output2;
	}
};

int main() {
	Procesor p;
	p.RUN();

	return 0;
}