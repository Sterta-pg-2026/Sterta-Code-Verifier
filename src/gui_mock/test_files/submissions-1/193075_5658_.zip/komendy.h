#pragma once
#include "function.h"

void komendy(Node* node, char new_line[], int len_line);

void wypisz(Node* node, char symbol, int ktory, char name[], int len_name, char new_line[], int len_line);

void wypisz(Node* node, char symbol, char ktory[],int len_ktory, char name[], int len_name, char new_line[], int len_line);

void wypisz(Node* node, char symbol, int strukt, int sel, char new_line[], int len_line);

int ile(Node* node, char symbol, int ktory);

int ile(Node* node, char symbol, char ktory[], int len_name);

bool usun(Node* node, int ktory);

bool usun(Node* node, int ktory, char name[], int len_name);

void wypiszkomende(char new_lline[], int len_line);
