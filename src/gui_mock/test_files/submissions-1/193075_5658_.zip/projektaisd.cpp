﻿#include <iostream>
#include <cstdio>
#include <string.h>
#include "function.h"
#include"komendy.h"
using namespace std;
#define KOMENDA		0
#define CSS			1


int main()
{
	char* line, * new_line, *tmpname, *tmpvalue;
	int separator = 0, separator_name = 0;;
	int len_line = 0, len_tmp = 0, len_tmp_value =0;
	int counter = 0;
	bool komenda = false;
	bool atrybut = false;		//po { -> wstawiamy atrybuty do listy
	bool struktura = true;
	bool value = false;
	Node* node = new Node;
	node->next = new Node;
	node->next->prev = node;
	Struktura* strukt = new Struktura;



	while (cin) {
		line = new char[256];
		separator = 0, separator_name =0;

		for (int i = 0; i < 256; i++) {
			line[i] = cin.get();
			len_line++;
			if (line[i] == 10) {
				//cout << "Wykryto nowa linie/znak" << endl;
				break;
			}
		}

		new_line = new char[len_line];
		int i = 0;
		for (int j = 0; j < len_line; j++) {
			while (line[i] == 34 || line[i] == 39 || line[i] == 9 || line[i] == 60 || line[i] == 62 || (line[i] == 32 && value == false)) {
			
				if (line[i] == 34 || line[i] == 39 || (line[i+1] >= 65 && line[i+1]<=90 && line[i]==32) || (line[i + 1] >= 97 && line[i + 1] <= 122 && line[i]==32) || (line[i+1] >=48 && line[i+1] <=57 && line[i] == 32) || (line[i] == 32&& line[i-1]==44 && line[i+1]==34)) {
					if (value == true) {
						value = false;
					}
					else {
						value = true;
					}
				}
				if ((line[i] == 32 && value == false) || (line[i] == 32 && line[i+1]== 10) || line[i] == 9 || line[i] == 60 || line[i] == 62)
				{
					i++;
				}
				else {
					break;
				}

			}
			new_line[j] = line[i];
			i++;

			//cout <<"Znak "<<j<<" w tablicy " << new_line[j] << endl;
		}
		delete[] line;

		if (len_line > 1 && new_line[1] == 63) {
			komenda = true;
		}
		else if (len_line > 1 && new_line[1] == 42) {
			komenda = false;
			struktura = true;
		}
		else {
			if (komenda == false) {
				if (struktura == true && new_line[0]!=10) {
					insertStruktura(node, strukt);
					struktura = false;
				}
				for (int i = 0; i < len_line; i++) {
					//cout << new_line[i];
					if ((new_line[i] == 44 || (new_line[i]== 10 && (i>0 &&new_line[i-1] != 123)) || new_line[i]==123 ) && atrybut == false ) {
						len_tmp = i - separator;
						if (new_line[separator] == 32) {
							separator++;
						}
						while(new_line[len_line - 1] == 32){ //|| new_line[len_line - 1] == 10 ){// || new_line[len_line - 1] == 59 || new_line[len_line - 1] == 125) {
							len_tmp--;
							len_line--;

						}
						if (len_tmp > 0) {
							tmpname = new char[len_tmp];
							tmpname = createTmpName(len_tmp, new_line, separator);
							//for (int i = 0; i < len_tmp; i++) {
								//cout << tmpname[i];
							//}
							//cout << endl;
							insertSelektor(strukt,tmpname,len_tmp );
							delete [] tmpname;
						}

						separator = i + 1;
						len_tmp = 0;
						if (new_line[i] == 123) {
							atrybut = true;
						}
						//counter++;

					}
					else if (new_line[i] == 58 && atrybut == true) {
						len_tmp = i - separator;
						separator_name = separator;
						separator = i + 1;
						if (new_line[separator] == 32) {
							separator++;
						}
					}
					else if (new_line[i] == 59 || new_line[i]==125){// || (new_line[i] == 44 && atrybut == true)) {
						len_tmp_value = i - separator;
						if (new_line[separator] == 32) {
							separator++;
						}
						while (new_line[len_line - 1] == 32){// || new_line[len_line - 1] == 59 || new_line[len_line - 1] == 125) {
							len_tmp_value --;
							len_line--;
						}
						if (len_tmp > 0 && len_tmp_value > 0) {
							tmpvalue = new char[len_tmp_value];
							tmpvalue = createTmpName(len_tmp_value, new_line, separator);
							tmpname = new char[len_tmp];
							tmpname = createTmpName(len_tmp, new_line, separator_name);
							insertAtrybut(strukt, tmpname, tmpvalue, len_tmp, len_tmp_value);
							delete[] tmpname;
							delete[] tmpvalue;
						}
						//for (int i = 0; i < strukt->firstA->next_atribut->size_name; i++) {
							//cout << strukt->firstA->next_atribut->name[i];
						//}
						//cout << endl;
						//for (int i = 0; i < strukt->firstA->next_atribut->size_value; i++) {
							//cout << strukt->firstA->next_atribut->value[i];
						//}

						if (new_line[i] == 125) {
							atrybut = false;
							struktura = true;
						}

						separator = i+1;
					}
					else {

						//counter++;

					}
				}
			}
			else {
				komendy(node, new_line, len_line);

			}
		}

		len_line = 0;
		delete[] new_line;


	}
}
