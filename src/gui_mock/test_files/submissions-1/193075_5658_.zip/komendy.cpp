#include "function.h"
#include "komendy.h"
#include <iostream>

using namespace std;

void komendy(Node* node, char new_line[], int len_line) {
	char* atrybut = new char, *tmpname = new char, *tmpvalue = new char;
	char symbol = ' ', rezultat = ' ';
	bool wszystko = false;
	int sekcja = 0, selektor = 0, ile_przecinek = 0, separator =0;
	int len_name = 0, len_value = 0, liczba = 0, wynik = 0;

	for (int i = 0; i < len_line; i++) {
		if (new_line[0] == 63) {
			symbol = new_line[0];
			break;
		}
		if (new_line[i] == 44) {
			if (ile_przecinek == 0) {
				len_name = i - separator;
				tmpname = new char[len_name];
				tmpname = createTmpName(len_name, new_line, separator);
				separator = i + 1;

			}
			else if (ile_przecinek == 1) {
				if (i - separator == 1) {
					symbol = new_line[separator];
				}
				else {
					return;
				}
				separator = i + 1;

			}
			ile_przecinek++;
		}
		else if (new_line[i] == 10) {
			len_value = i - separator;
			if (len_value == 1 && new_line[i-1]==63 ) {
				wszystko = true;
			}
			else {
				tmpvalue = new char[len_value];
				tmpvalue = createTmpName(len_value, new_line, separator);
				separator = i + 1;

			}
			
		}
	}
	if (symbol == 63) {
		cout << symbol << " == " << ile(node, symbol, NULL)<<endl;
		return;
	}
	if (sprawdzInt(tmpname, len_name)){
		sekcja = createInt(tmpname, len_name);
	}
	if (sprawdzInt(tmpvalue, len_value)) {
		selektor = createInt(tmpvalue, len_value);
	}

	if (wszystko == true) {
		if (sekcja == 0) {
			wypiszkomende(new_line, len_line);
			cout << ile(node, symbol, tmpname, len_name) << endl;
			
		}
		else {
			wynik = ile(node, symbol, sekcja);
			if (wynik > 0) {
				wypiszkomende(new_line, len_line);
				cout<<wynik << endl;
			}
		}
	}
	else {
		if (selektor != 0 && sekcja != 0 && symbol == 'S') {
			 wypisz(node,symbol, sekcja, selektor, new_line, len_line);
		}
		else if (sekcja != 0 && selektor == 0) {
			if (symbol == 'D'){
				if (tmpvalue[0] == '*' && len_value ==1) {
					if (usun(node, sekcja)) {
						wypiszkomende(new_line, len_line);
						cout << "deleted" << endl;
					}
				}
				else {
					if (usun(node, sekcja, tmpvalue, len_value)) {
						wypiszkomende(new_line, len_line);
						cout << "deleted" << endl;
					}
				}
			}
			else if (symbol == 'A') {
				wypisz(node, symbol, sekcja, tmpvalue,len_value, new_line, len_line);
			}

		}
		else if (sekcja == 0 && selektor == 0 && symbol=='E') {
			wypisz(node, symbol, tmpname, len_name, tmpvalue, len_value, new_line, len_line);
		}
		else {
			return;
		}

	}

}

int ile(Node* node, char symbol, int ktory) {
	Node* tmp = node;
	Struktura* strukt = new Struktura;
	Selektor* sel = new Selektor;
	Atrybut* atr = new Atrybut;
	int numer = 0, index = 0, wynik =0;
	bool pelna = false;
	if (symbol == 63) {
	
		while (tmp->next != nullptr) {
			tmp = tmp->next;
			if (tmp->ile_ele == SIZE && tmp->deleted == 0) {
				wynik += SIZE;
			}
			else {
				wynik += (tmp->ile_ele - tmp->deleted);
			}
		}
		
		return wynik;
	}
	else if (symbol == 83) {
		if (ktory > SIZE) {
			numer = ktory / SIZE;
			index = ktory % SIZE;
			if (index == 0) {
				index = 7;
			}
			else {
				index--;
			}
		}
		else {
			numer = 1;
			index = ktory - 1;
		}
		for (int i = 0; i < numer; i++) {
			if (tmp->next != nullptr) {
				tmp = tmp->next;
			}
			else if(i < (numer -1)) {
				return 0;
			}

		}
		if (index < tmp->ile_ele) {
			if (tmp->array[index] != nullptr) {
				
				sel = tmp->array[index]->lastS;
				return (sel->number_sel);

			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	else if (symbol == 65) {
		if (ktory > SIZE) {
			numer = ktory / SIZE;
			index = ktory % SIZE;
			if (index == 0) {
				index = 7;
			}
			else {
				index--;
				numer++;
			}
		}
		else {
			numer = 1;
			index = ktory-1;
		}
		for (int i = 0; i < numer; i++) {
			if (tmp->next != nullptr) {
				tmp = tmp->next;
			}
			else if (i < (numer - 1)){
				return 0;
			}
		}
		if (index < tmp->ile_ele) {
			if(tmp->array[index] != nullptr){
				if (tmp->array[index ]->lastA != nullptr) {
					atr = tmp->array[index]->lastA;
					return (atr->numer_atr - tmp->array[index ]->deleted);
				}
				else {
					return 0;
				}
			}

		}
		else {
			return 0;
		}
	}
	return 0;
}

int ile(Node* node, char symbol, char ktory[], int len_name) {
	Node* tmp = node;
	Struktura* strukt = new Struktura;
	Selektor* sel = new Selektor;
	Atrybut* atr = new Atrybut;
	int countr = 0, nazwa =0;
	
	if (symbol == 65) {
		while (tmp->next != nullptr){
			tmp = tmp->next;
			for (int i = 0; i < tmp->ile_ele; i++) {
				if (tmp->array[i] != nullptr) {
					strukt = tmp->array[i];
				}
				else {
					return countr;
				}
				if (strukt->firstA->next_atribut != nullptr) {
					atr = strukt->firstA;
				}
				while (atr->next_atribut!= nullptr) {
					atr = atr->next_atribut;
					for (int j = 0; (j < atr->size_name) || (j<len_name); j++) {
						if (atr->size_name != len_name) {
							break;
						}
						if (atr->name[j] == ktory[j]) {
							nazwa++;
						}
						else{
							nazwa = 0;
							break;
						}
					}
					if (nazwa == len_name) {
						countr++;
						nazwa = 0;
					}
					nazwa = 0;
				}
			}
		}
		return countr;
	}
	else if (symbol == 83) {
		while (tmp->next != nullptr) {
			tmp = tmp->next;
			for (int i = 0; i < tmp->ile_ele; i++) {
				if (tmp->array[i] != nullptr) {
					strukt = tmp->array[i];
				}
				else {
					return 0;
				}
				if (strukt->firstS->next_selector != nullptr) {
					sel = strukt->firstS;
				}
				while (sel->next_selector!= nullptr) {
					sel = sel->next_selector;

					for (int j = 0; (j < sel->size_name) || (j < len_name); j++) {
						if (sel->size_name != len_name) {
							break;
						}
						if (sel->name[j] == ktory[j]) {
							nazwa++;
						}
						else {
							nazwa = 0;
							break;
						}
					}
					if (nazwa == len_name) {
						countr++;
						nazwa = 0;
					}
					nazwa = 0;
				}
			}
		}
		return countr;
	}
	return 0;

}

void wypisz(Node* node, char symbol, int ktory, char name[], int len_name, char new_line[], int len_line) {
	
	if (symbol != 'A') {
		return;
	}

	Node* tmp = node;
	Struktura* strukt = new Struktura;
	Atrybut* atr = new Atrybut;
	int numer = 0, index = 0, nazwa =0;
	if (ktory > SIZE) {
		numer = ktory / SIZE;
		index = ktory % SIZE;
		if (index == 0) {
			index = 7;
		}
		else {
			index--;
			numer++;
		}
	}
	else {
		numer = 1;
		index = ktory-1;
	}
	char* wynik = new char;

	for (int i = 0; i < numer; i++) {
		if (tmp->next != nullptr) {
			tmp = tmp->next;
		}
		else if (i < (numer - 1)) {
			return;
		}
	}
	if (index < tmp->ile_ele) {
		if (tmp->array[index] != nullptr) {

			atr = tmp->array[index]->firstA;
		}
		else {
			return;
		}

	}
	else {
		return;
	}
	while (atr->next_atribut != nullptr) {
		atr = atr->next_atribut;
		for (int i = 0; (i < len_name || i < atr->size_name); i++) {
			if (atr->name[i] == name[i]) {
				nazwa++;
			}
			else {
				nazwa = 0;
				break;
			}
		}
		if (nazwa == len_name) {
			wypiszkomende(new_line, len_line);
			for (int j = 0; j < atr->size_value; j++) {
				cout << atr->value[j];
			}
			cout << endl;
			break;
		}
		nazwa = 0;
	}

}

void wypisz(Node* node, char symbol, char ktory[], int len_ktory, char name[], int len_name, char new_line[], int len_line) {
	//poprawic komenda E dla 1 i wieu node
	Node* tmp = node;
	Struktura* strukt = new Struktura;
	Selektor* sel = new Selektor;
	Selektor* headsel = new Selektor;
	Atrybut* atr = new Atrybut;
	Atrybut* headatr = new Atrybut;
	Node* head = node;
	int nazwa = 0, atrybut =0;

	if (node->last != nullptr) {
		tmp = node->last;
	}
	else {
		tmp = node->next;
	}
		while (tmp->prev != nullptr)
		{
			for (int i = (tmp->ile_ele)-1 ; i >= 0; i--) {
				if (tmp->array[i] != nullptr) {
				sel = tmp->array[i]->lastS;
				headsel = tmp->array[i]->firstS;
				}
				else {
					return;
				}
				while (sel->prev_selector != nullptr) {
					for (int j = 0; (j < len_ktory || j < (sel->size_name)); j++) {
						if (len_ktory != sel->size_name) {
							break;
						}
						if (sel->name[j] == ktory[j]) {
							nazwa++;
						}
						else {
							nazwa = 0;
							break;
						}
					}
					if (nazwa == len_ktory) {
						atr = tmp->array[i]->firstA;
						while (atr->next_atribut != nullptr) {
							atr = atr->next_atribut;
							for (int j = 0; (j < len_name && j < (atr->size_name)); j++) {
								if (atr->name[j] == name[j]) {
									atrybut++;
								}
								else {
									atrybut = 0;
									break;
								}
							}
							if (atrybut == len_name) {
								wypiszkomende(new_line, len_line);
								for (int j = 0; j < (atr->size_value); j++) {
									cout << atr->value[j];
								}
								cout << endl;
								return;
							}
						}
					}
					nazwa = 0;
					sel = sel->prev_selector;
				}
			}
			tmp = tmp->prev;
		}

}

void wypisz(Node* node, char symbol, int sekcja, int selekt, char new_line[], int len_line) {
	
	if (symbol != 'S') {
		return;
	}
	
	Node* tmp = node;
	Struktura* strukt = new Struktura;
	Selektor* sel = new Selektor;
	int numer = 0, index = 0;
	if (sekcja > SIZE){
		numer = sekcja / SIZE;
		index = sekcja % SIZE;
		if (index == 0) {
			index = 7;
		}
		else{
			index--;
			numer++;
		}
	}
	else {
		numer = 1;
		index = sekcja-1;
	}

	for (int i = 0; i < numer; i++) {
		if (tmp->next != nullptr) {
			tmp = tmp->next;
		}
		else if (i < (numer - 1)) {
			return;
		}
	}
	if (index < tmp->ile_ele) {
		if (tmp->array[index ] != nullptr) {
			sel = tmp->array[index ]->firstS;
		}
		else {
			return;
		}
	}
	else {
		return;
	}
	for (int i = 0; i < selekt; i++) {
		if (sel->next_selector != nullptr && sel->next_selector->number_sel<=sekcja) {
			sel = sel->next_selector;
		}
		else if (i < (selekt - 1)) {
			return;
		}
		else {
			return;
		}
	}

	wypiszkomende(new_line, len_line);
	for (int i = 0; i < sel->size_name; i++) {
		cout << sel->name[i];
	}
	cout << endl;

}

bool usun(Node* node, int ktory) {
	Node* tmp = node;
	Node* one = new Node;
	Node* two = new Node;
	Node* usun = new Node;
	Struktura* befor = new Struktura;
	Struktura* after = new Struktura;
	Struktura* bufor = new Struktura;
	int numer = 0, index = 0;
	if (ktory > SIZE) {
		numer = ktory / SIZE;
		index = ktory % SIZE;
		if (index == 0) {
			index = 7;
		}
		else {
			index --;
			numer++;
		}
	}
	else {
		numer = 1;
		index = ktory-1;
	}
	for (int i = 0; i < numer; i++) {
		if (tmp->next != nullptr) {
			tmp = tmp->next;
		}
		else if (i < (numer - 1)) {
			return false;
		}
	}
	if (tmp->array[index] != nullptr) {
		bufor = tmp->array[index];
	}
	else {
		return false;
	}
	if (bufor->next_element != nullptr) {
		after = bufor->next_element;
		befor = bufor->prev_element;

		befor->next_element = after;
		after->prev_element = befor;
		while (befor->next_element != nullptr) {
			befor = befor->next_element;
			(befor->number_of_struct)--;
		 }
	}
	else {
		befor->next_element = nullptr;
	}

	(tmp->deleted)++;
	tmp->array[index] = nullptr;
	delete bufor;

	if (tmp->deleted == tmp->ile_ele) {
		usun = tmp;
		one = tmp->prev;
		two = tmp->next;
		one->next = two;
		two->prev = one;
	}
	return true;
}



bool usun(Node* node, int ktory, char name[], int len_name) {
	Node* tmp = node;
	Atrybut* atr = new Atrybut;
	Atrybut* one = new Atrybut;
	Atrybut* two = new Atrybut;
	int numer = 0, index = 0, atrybut=0;
	if (ktory > SIZE) {
		numer = ktory / SIZE;
		index = ktory % SIZE;
		if (index == 0) {
			index = 7;
			numer--;
		}
		else {
			index--;
			numer++;
		}
	}
	else {
		numer = 1;
		index = ktory;
	}
	for (int i = 0; i < numer; i++) {
		if (tmp->next != nullptr) {
			tmp = tmp->next;
		}
		else if (i < (numer - 1)) {
			return false;
		}
	}
	if (index < tmp->ile_ele && index > tmp->deleted) {
		if (tmp->array[index ] != nullptr) {
			atr = tmp->array[index]->firstA;
		}
		else {
			return false;
		}
		while (atr->next_atribut != nullptr) {
			atr = atr->next_atribut;
			for (int j = 0; (j < len_name && j < (atr->size_name)); j++) {
				if (atr->name[j] == name[j]) {
					atrybut++;
				}
				else {
					atrybut = 0;
					break;
				}
			}
			if (atrybut == len_name) {
				(tmp->array[index]->deleted)++;
				one = atr->prev_atribut;
				if (atr->next_atribut != nullptr) {
					two = atr->next_atribut;
					one->next_atribut = two;
					two->prev_atribut = one;
					while (one->next_atribut != nullptr) {
						one = one->next_atribut;
						(one->numer_atr)--;
					}
				}
				else {
					one->next_atribut = nullptr;
				}
				if (tmp->array[index ]->lastA == atr) {
					if (atr->next_atribut != nullptr) {
						tmp->array[index ]->lastA = two;

					}
					else {
						tmp->array[index]->lastA = nullptr;
					}
				}
				if (tmp->array[index]->lastA == nullptr) {
					usun(node, ktory);
				}
				return true;
			}
		}
		return false;
	}
	return false;
}

void wypiszkomende(char new_line[], int len_line) {
	for (int i = 0; i < len_line; i++) {
		if (new_line[i] == 10) {
			break;
		}
		cout << new_line[i];
	}
	cout << " == ";
}

