#include "function.h"
#include <iostream>
#include <math.h>

using namespace std;

void createNode(Node* node, Struktura *struk) {
	Node* newNode = new Node;
	newNode->array[0] = new Struktura;
	newNode->array[0] = struk;
	newNode->next = nullptr;
	Node* tmp = node;
	if (tmp->last != nullptr) {
		tmp = tmp->last;
	}
	else {
		while (tmp->next!=nullptr)
		{
			tmp = tmp->next;
		}
	}
	newNode->ile_ele = 1;
	struk->prev_element = tmp->array[SIZE - 1];
	struk->number_of_struct = (tmp->array[SIZE - 1]->number_of_struct) + 1;
	tmp->array[SIZE - 1]->next_element = newNode->array[0];
	tmp->next = newNode;
	newNode->prev = tmp;
	node->last = new Node;
	node->last = newNode;
	//delete newNode;
	//delete tmp;
}



void insertStruktura(Node* node, Struktura *strukt) {
	Node* end = new Node;
	end = node;
	Struktura* tmp = new Struktura;
	Struktura* newStrukt = new Struktura;
	newStrukt->firstA = new Atrybut;
	newStrukt->firstS = new Selektor;
	newStrukt->lastA = new Atrybut;
	newStrukt->lastS = new Selektor;

	tmp = strukt;

	if (end->last != nullptr) {
		end = end->last;
	}
	else {
		while (end->next != nullptr) {
			end = end->next;
		}
	}
	while (tmp->next_element != nullptr) {
		tmp = tmp->next_element;
	}
	newStrukt->number_of_struct = (tmp->number_of_struct) + 1;
	tmp->next_element = newStrukt;
	newStrukt->prev_element = tmp;
	if (end->ile_ele == 0) {
		end->array[0] = newStrukt;
		end->ile_ele = 1;
	}
	else if (end->ile_ele < SIZE) {
		int i = (end->ile_ele);
		end->array[i] = newStrukt;
		(end->ile_ele)++;
	}
	else if (end->ile_ele == SIZE) {
		createNode(node, newStrukt);
	}

	//end = nullptr;
	//delete end;
}


void insertSelektor(Struktura* strukt, char name_tmp[], int size) {
	bool powtorka = false;
	Selektor* newsel = new Selektor;
	Struktura* tmpS = new Struktura;
	tmpS = strukt;
	newsel->name = new char[size];
	int nazwa = 0;
	while (name_tmp[size - 1] == 32 || name_tmp[size - 1] == 10 || name_tmp[size-1]==44) {
		size--;
	}
	newsel->size_name = size;
	for (int i = 0; i < size; i++) {
		newsel->name[i] = name_tmp[i];
	}

	while (tmpS->next_element!= nullptr){
		tmpS =tmpS->next_element;
	}

	Selektor* tmp = tmpS->firstS;

	while (tmp->next_selector != nullptr) {
		tmp = tmp->next_selector;
		for (int i = 0; i < size || i < tmp->size_name; i++) {
			if (tmp->size_name != size) {
				break;
			}

			if (tmp->name[i] == name_tmp[i]) {
				nazwa++;
			}
			else {
				nazwa = 0;
				break;
			}
		}
		if (nazwa == size) {
			powtorka = true;
			break;
		}
		nazwa = 0;
	}
	if (powtorka != true) {
		newsel->number_sel = (tmp->number_sel)+1;
		tmp->next_selector = newsel;
		newsel->prev_selector = tmp;
		tmpS->lastS= new Selektor;
		tmpS->lastS = newsel;
	}
	else {
		newsel->name = nullptr;
		newsel->size_name = 0;
		delete newsel;
	}

}

char* createTmpName(int size, char new_line[], int separator) {
	char* tmpname;
	tmpname = new char[size];
	
	for (int j = 0; j < size; j++) {
		tmpname[j] = new_line[separator + j];
	}
	return tmpname;
}

void insertAtrybut(Struktura* strukt, char name[], char value[], int size_n, int size_v) {
	bool powtorka = false;
	Atrybut* atr = new Atrybut;
	Struktura* tmpS = new Struktura;
	tmpS = strukt;
	atr->name = new char[size_n];
	atr->value = new char[size_v];
	atr->size_name = size_n;
	atr->size_value = size_v;
	int nazwa = 0;
	while(name[size_n - 1] == 32 || name[size_n - 1] == 10 || name[size_n -1] == 44) {
		size_n--;
	}
	while(value[size_v - 1] == 32 || value[size_v - 1] == 10 || value[size_v-1]==44) {
		size_v--;
	}
	for (int i = 0; i < size_n; i++) {
		atr->name[i] = name[i];
	}
	for (int i = 0; i < size_v; i++) {
		atr->value[i] = value[i];
	}

	while (tmpS->next_element != nullptr){
		tmpS = tmpS->next_element;
	}

	Atrybut* tmp = tmpS->firstA;


	while (tmp->next_atribut != nullptr) {
		tmp = tmp->next_atribut;
		for (int i = 0; i < size_n || i < tmp->size_name; i++) {
			if (tmp->size_name != size_n) {
				break;
			}
			
			if (tmp->name[i] == name[i]) {
				nazwa++;
			}
			else {
				nazwa = 0;
				break;
			}
		}
		if (nazwa==size_n) {
			tmp->value = new char[size_v];
			for (int i = 0; i < size_v; i++) {
				tmp->value[i] = value[i];
			}
			tmp->size_value = size_v;
			powtorka = true;
			break;
		}
		nazwa = 0;
	}
	if (powtorka != true) {
		atr->numer_atr = (tmp->numer_atr) + 1;
		tmp->next_atribut = atr;
		atr->prev_atribut = tmp;
		tmpS->lastA = new Atrybut;
		tmpS->lastA = atr;
	}
	else {
		atr->name = nullptr;
		atr->value = nullptr;
		delete atr;
	}
}

int createInt(char tmpname[], int size) {
	int ile = 0;
	for (int i = 0; i < size; i++) {
		ile += (tmpname[i] - 48) * pow( 10.0 ,double (size - i - 1));
	}

	return ile;
}

bool sprawdzInt(char tmpname[], int size) {
	int liczba = 0;
	for (int i = 0; i < size; i++) {
		if (tmpname[i] >= 48 && tmpname[i] <= 57) {
			liczba++;
		}
	}
	if (liczba == size) {
		return true;
	}
	return false;
}
