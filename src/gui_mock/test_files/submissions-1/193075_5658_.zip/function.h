#pragma once
#pragma once
#define SIZE	17


typedef struct Atrybut
{
	char* name= nullptr;
	char* value = nullptr;
	int size_name = 0;
	int size_value = 0;
	int numer_atr = 0;
	Atrybut* prev_atribut = nullptr;
	Atrybut* next_atribut = nullptr;
}Atrybut;

typedef struct  Selektor {
	char* name= nullptr;
	int size_name = 0;
	int number_sel = 0;
	Selektor* next_selector = nullptr;
	Selektor* prev_selector = nullptr;
}Selektor;

typedef struct Struktura {
	Selektor* firstS = nullptr;
	Atrybut* firstA = nullptr;
	Selektor* lastS = nullptr;
	Atrybut* lastA = nullptr;

	int number_of_struct = 0;
	int deleted = 0;

	Struktura* prev_element = nullptr;
	Struktura* next_element = nullptr;
}Struktura;
typedef struct Node
{
	Struktura* array[SIZE];
	int ile_ele=0;
	int deleted = 0;
	Node* prev = nullptr;
	Node* next = nullptr;
	Node* last = nullptr;
}Node;



void createNode(Node* node, Struktura *struk);

void insertStruktura(Node* node, Struktura *strukt);

void insertSelektor(Struktura*strukt, char name[], int size);

void insertAtrybut(Struktura* strukt, char name[], char value[], int size_n, int size_v);

char* createTmpName(int size, char new_line[], int separator);

int createInt(char tmpname[], int size);

bool sprawdzInt(char tmpname[], int size);
