#include <iostream>
#include "listacss.h"
using namespace std;
int main()
{
	ListaCSS* lista = new ListaCSS;
	lista->ParserCSS();
	delete lista;

	return 0;
}