#pragma once
#include <iostream>
//#define _CRT_SECURE_NO_WARNINGS
#define ARRAY_SIZE 8
#include "singlylinkedlist.h"

using namespace std;

struct LinkedListsArray {
    SinglyLinkedList selectorsList;
    SinglyLinkedList attributesList;
    LinkedListsArray& operator=(const LinkedListsArray& other) {
        if (this != &other) {
            selectorsList = other.selectorsList;
            attributesList = other.attributesList;
        }
        return *this;
    }
};

class Node {
public:
    struct LinkedListsArray sections[ARRAY_SIZE];
    Node* next;
    Node* prev;
    int size = 0;

    Node() {
        for (int i = 0; i < ARRAY_SIZE; i++) {
            sections[i] = LinkedListsArray();
        }
        next = nullptr;
        prev = nullptr;
    }
};

class DoublyLinkedList {
private:
    Node* head;
    Node* tail;
    int size;
public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

    Node* getHead() {
        return head;
    }
    void addFront(struct LinkedListsArray sections) {
        if (size == 0 || size % ARRAY_SIZE == 0) {
            Node* newNode = new Node();

            newNode->sections[0] = sections;
            newNode->size++;
            newNode->next = head;
            if (head != nullptr) {
                head->prev = newNode;
            }
            head = newNode;
            if (tail == nullptr) {
                tail = newNode;
            }
            size++;
        }
        else {
            head->sections[size % ARRAY_SIZE] = sections;
            head->size++;
            size++;
        }
    }


    void addBack(struct LinkedListsArray sections) {
        if (size == 0 || size % ARRAY_SIZE == 0) {
            Node* newNode = new Node();

            newNode->sections[0] = sections;
            newNode->size++;
            newNode->prev = tail;
            if (tail != nullptr) {
                tail->next = newNode;
            }
            tail = newNode;
            if (head == nullptr) {
                head = newNode;
            }
            size++;
        }
        else {
            tail->sections[size % ARRAY_SIZE] = sections;
            tail->size++;
            size++;
        }
    }

    int findSection(Node* ac,string name) {
        int counter = 0;
        for (int i = 0; i < ac->size; i++) {
            counter += (ac->sections[i].selectorsList.findHowManySelectors(name));
        }
        return counter;
    }

    int getSectionByName(string name) {
        Node* ac = head;
        int counter = 0;
        if (ac->size <= ARRAY_SIZE) {
            counter = findSection(ac, name);
        }
        else {
            while (ac != nullptr) {

                counter += findSection(ac, name);
                ac = ac->next;
                
            }
        }
        return counter;
    }

    int getSection(int i) {
        int nrOFNode = i / ARRAY_SIZE;
        int nrOfSection = i % ARRAY_SIZE;
        Node* ac = head;
        for (int j = 0; j < nrOFNode; j++) {
            ac = ac->next;
        }
        int nrOfSelecotrs = ac->sections[nrOfSection - 1].selectorsList.getSize();
        return nrOfSelecotrs;
    };

    int getAttribute(int i) {
        int nrOFNode = i / ARRAY_SIZE;
        int nrOfSection = i % ARRAY_SIZE;
        Node* ac = head;
        for (int j = 0; j < nrOFNode; j++) {
            ac = ac->next;
        }
        int nrOfAttribute = ac->sections[nrOfSection - 1].attributesList.getSize();
        return nrOfAttribute;
    };

    string getAttributeValue(int i, string value) {
        int nrOFNode = i / ARRAY_SIZE;
        int nrOfSection = i % ARRAY_SIZE;
        Node* ac = head;
        for (int j = 0; j < nrOFNode; j++) {
               ac =  ac->next;       
        }
        string name = ac->sections[nrOfSection-1].attributesList.findNafindAttributeValue(value);
        return name;
    }

    string getSectionName(int i, int j) {
        int nrOFNode = i / ARRAY_SIZE;
        int nrOfSection = i % ARRAY_SIZE;
        Node* ac = head;
        for (int j = 0; j < nrOFNode; j++) {
            ac = ac->next;
        }
        string name = ac->sections[nrOfSection - 1].selectorsList.getName(j);
        return name;
    };


    void removeFront() {
        if (head == nullptr) {
            return;
        }
        if (size % ARRAY_SIZE == 1) {
            Node* temp = head;
            head = head->next;
            if (head != nullptr) {
                head->prev = nullptr;
            }
            else {
                tail = nullptr;
            }
            delete temp;
            size--;
        }
        else {
            size--;
            for (int i = 0; i < size % ARRAY_SIZE; i++) {
                head->sections[i] = head->sections[i + 1];
            }
        }
    }

    void removeBack() {
        if (tail == nullptr) {
            return;
        }
        if (size % ARRAY_SIZE == 1) {
            Node* temp = tail;
            tail = tail->prev;
            if (tail != nullptr) {
                tail->next = nullptr;
            }
            else {
                head = nullptr;
            }
            delete temp;
            size--;
        }
        else {
            size--;
            for (int i = ARRAY_SIZE - 1; i > size % ARRAY_SIZE; i--) {
                tail->sections[i] = tail->sections[i - 1];
            }
        }
    }

    void print() {
        Node* current = head;
        while (current != nullptr) {
            for (int i = 0; i < ARRAY_SIZE; i++) {
            }
            current = current->next;
        }
        cout << endl;
    }
};

