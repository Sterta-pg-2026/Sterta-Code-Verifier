#include <iostream>
#include <cstring>
#include <stdio.h>
#include <string.h>
#include "singlylinkedlist.h"
#include "doublylinkedlist.h"
#pragma warning(disable : 4996)
//#define _CRT_SECURE_NO_WARNINGS

using namespace std;

int str_length(char str[]) {
	// initializing count variable (stores the length of the string)
	int count;

	// incrementing the count till the end of the string
	for (count = 0; str[count] != '\0'; ++count);

	// returning the character count of the string
	return count;
}


bool is_num(char* text) {
	for (int i = 0; i < strlen(text); i++) {
		int asciinum = text[i] - '0';
		if (0 > asciinum || asciinum > 9) {
			return false;
		}
	}
	return true;
}

void parserCSS(DoublyLinkedList list) {

	bool selector = true;
	bool newSelector = true;
	int nrLinkedList = 0;
	bool commends = false;

	struct LinkedListsArray arr;
	char str[256];
	while (std::cin >> str) {
		
		if (newSelector) {
			arr.selectorsList =  SinglyLinkedList(); 
			arr.attributesList = SinglyLinkedList();
			newSelector = false;
		}
		if (memchr(str, '{', sizeof(str))) {
			selector = false;
			if (str_length(str) > 1) {
				if (str[0] == '{') {
					char tempstr = str[strlen(str) - 1];
					char* name;
					char value[256];
					char temp[256];
					int size = 0;
					if (str[strlen(str) - 1] == ':') {
						name = strtok(str + 1, ":");
						std::cin >> value;
						tempstr = value[strlen(value) - 1];
						if(tempstr == '}') {
							value[strlen(value) - 1] = '\0';
							selector = true;
							newSelector = true;
						}
						tempstr = value[strlen(value) - 1];
						if (tempstr == ';') {
							value[strlen(value) - 1] = '\0';
						}
						arr.attributesList.addBack(name, value);
					}
					if (selector && newSelector) {
						nrLinkedList++;
						list.addBack(arr);
					}
				}
				else{
					str[strlen(str) - 1] = '\0';
					arr.selectorsList.addBack(str, "");
				}
			}
		}
		else if (memchr(str, '}', sizeof(str))) {
			selector = true;
			list.addBack(arr);
			nrLinkedList++;
			newSelector = true;
		}
		else if (strcmp(str, "????") == 0) {
			commends = true;
		}
		else if (strcmp(str, "****") == 0) {
			commends = false;
		}
		else if (commends) {
			if (strcmp(str, "?") == 0) {
				cout << "? == " << nrLinkedList << endl;
			}
			else {
				char* temp = strtok(str, ",");
				if (is_num(temp)) {
					int i = atoi(temp);
					char* name = strtok(NULL, ":");
					if (strcmp(name, "S,?") == 0) {
						cout << i << ",S,? == " << list.getSection(i) << endl;
					}
					else if (memchr(name, 'S', sizeof(name))) {
						name = strtok(name, ",");
						char* value = strtok(NULL, ",");
						int j = atoi(value);
						cout << i << ",S," << j << " == " << list.getSectionName(i, j) << endl;
					}
					else if (strcmp(name, "A,?") == 0) {
						cout << i << ",A,? == " << list.getAttribute(i) << endl;
					}
					else if (memchr(name, 'A', sizeof(name))) {
						name = strtok(name, ",");
						char* value = strtok(NULL, ",");
						cout << i << ",A," << value << " == " << list.getAttributeValue(i, value) << endl;
					}
				}
				else {
					char* name = strtok(NULL, ":");
					if (strcmp(name, "S,?") == 0) {
						cout << temp << ",S,? == " << list.getSectionByName(temp) << endl;
					}
					else if (strcmp(name, "A,?") == 0) {
						cout << temp << ",A,? == " << list.getSectionByName(temp) << endl;
					}
				}
			}
		}
		else if (selector) {
			if (strchr(str, ',')!=NULL) { 
				str[strlen(str) - 1] = '\0';
			}
			arr.selectorsList.addBack(str, "");
		}
		else {
			char* name = str;
			name[strlen(name) - 1] = '\0';
			char temp[256];
			std::cin.getline(temp, 256);
			temp[strlen(temp) - 1] = '\0';
			char* value = temp + 1;
			arr.attributesList.addBack(name, value);
		}
	}
}

int main()
{
	DoublyLinkedList list = DoublyLinkedList();
	parserCSS(list);
	return 0;
}

