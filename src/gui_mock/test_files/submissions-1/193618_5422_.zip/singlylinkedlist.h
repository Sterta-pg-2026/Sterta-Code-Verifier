#pragma once
#include <iostream>
#include <cstring>
#include <stdio.h>
#include <string.h>
//#define _CRT_SECURE_NO_WARNINGS

using namespace std;

class Node2 {
public:
    string name;
    string value;
    Node2* next;

    Node2(string name, string value) {
        this->name = name;
        this->value = value;
        next = nullptr;
    }
};

class SinglyLinkedList {
private:
    Node2* head;
    Node2* tail;
    int size;
public:
    SinglyLinkedList() {
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

    int getSize() {
        return size;
    }

    string getName(int i) {
        Node2* ac = nullptr;
        for (int j = 0; j <= i-1; j++) {
            if (j == 0) {
                ac = head;
            }
            else {
               ac = ac->next;
            }
        }
        return ac->name;
     
    }


    int findHowManySelectors(string name) {
        Node2* ac = head;
        while (ac != nullptr) {
            if (ac->name == name) {
                return 1;
            }
            ac = ac->next;
        }
        return 0;

    }

    string findNafindAttributeValue(string name) {
        Node2* ac = head;
        if (ac->name == name) {
            return ac->value;
        }
        while (ac != nullptr) {
            if (ac->name == name) {
                return ac->value;
            }
            else {
                ac = ac->next;
            }
        }
        return "";

    }

    void addFront(string name, string value) {
        Node2* newNode = new Node2(name, value);
        newNode->next = head;
        head = newNode;
        if (tail == nullptr) {
            tail = newNode;
        }
        size++;
    }

    void addBack(string name, string value) {
        Node2* newNode = new Node2(name, value);
        if (tail != nullptr) {
            tail->next = newNode;
        }
        tail = newNode;
        if (head == nullptr) {
            head = newNode;
        }
        size++;
    }

    void removeFront() {
        if (head == nullptr) {
            return;
        }
        Node2* temp = head;
        head = head->next;
        delete temp;
        size--;
        if (size == 0) {
            tail = nullptr;
        }
    }

    void removeBack() {
        if (tail == nullptr) {
            return;
        }
        if (size == 1) {
            delete tail;
            head = nullptr;
            tail = nullptr;
            size--;
            return;
        }
        Node2* current = head;
        while (current->next != tail) {
            current = current->next;
        }
        delete tail;
        tail = current;
        tail->next = nullptr;
        size--;
    }

    void print() {
        Node2* current = head;
        while (current != nullptr) {
            cout << current->name << " " << current->value << endl;
            current = current->next;
        }
    }
};
