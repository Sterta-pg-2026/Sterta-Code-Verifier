#ifndef PTR_BASE_H_INCLUDED
#define PTR_BASE_H_INCLUDED

#include "exc.h"
#include <cstdio>

struct ptr_count{
    int pn, wn;
};

template<class S, typename T>
class ptr_base{
    public:
        T *px = nullptr;
        ptr_count * c = nullptr;
        void (*del)(T*) = nullptr;

    public:
        ptr_base();
        ~ptr_base();
        ptr_base(T*, void(*)(T*), ptr_count*);
        ptr_base(T*, void (*)(T*));
        ptr_base(T*);

        ptr_base(const ptr_base<S, T>&);
        ptr_base<S, T>& operator=(const ptr_base<S, T>&);

        template<class O>
        ptr_base(const ptr_base<O, T>&);

        template<class O>
        ptr_base<S, T>& operator=(const ptr_base<O, T>&);

        int use_count() const;
        T* get() const;
        void reset();
        bool expired() const;

        T& operator*();
        T* operator->();
        operator bool() const;
};

template<class S, typename T>
ptr_base<S, T>::ptr_base() {}

template<class S, typename T>
ptr_base<S, T>::~ptr_base() {
    S::release(&px, &c, del);
}

template<class S, typename T>
ptr_base<S, T>::ptr_base(T* px): px(px) {
    S::acquire(px, &c);
}

template<class S, typename T>
ptr_base<S, T>::ptr_base(T* px, void (*del)(T*)): px(px), del(del) {
    S::acquire(px, &c);
}

template<class S, typename T>
ptr_base<S, T>::ptr_base(T* px, void (*del)(T*), ptr_count * c): px(px), c(c), del(del) {
    S::acquire(px, &c);
};

template<class S, typename T>
ptr_base<S, T>& ptr_base<S, T>::operator=(const ptr_base<S, T>& p){
    ptr_base<S, T> temp(*this);

    S::release(&px, &c, del);
    px = p.px;
    del = p.del;
    c = p.c;
    S::acquire(px, &c);
    return *this;
}


template<class S, typename T>
ptr_base<S, T>::ptr_base(const ptr_base<S, T>& p): ptr_base<S, T>(p.px, p.del, p.c) { }

template<class S, typename T>
template<class O>
ptr_base<S, T>::ptr_base(const ptr_base<O, T>& p) {
    ptr_base<O, T> t = p;
    if(p.expired())
        t = ptr_base<O, T>();

    px = t.px;
    del = t.del;
    c = t.c;

    S::acquire(px, &c);
}

template<class S, typename T>
template<class O>
ptr_base<S, T>& ptr_base<S, T>::operator=(const ptr_base<O, T>& p){
    ptr_base<S, T> temp(*this);

    ptr_base<O, T> t = p;
    if(p.expired())
        t = ptr_base<O, T>();

    S::release(&px, &c, del);
    px = t.px;
    del = t.del;
    c = t.c;
    S::acquire(px, &c);
    return *this;
}

template<class S, typename T>
int ptr_base<S, T>::use_count() const{
    if(c == nullptr)
        return 0;

    return c->pn;
}

template<class S, typename T>
T* ptr_base<S, T>::get() const{
    return px;
}

template<class S, typename T>
void ptr_base<S, T>::reset() {
    S::release(&px, &c, del);
    S::acquire(px, &c);
}

template<class S, typename T>
bool ptr_base<S, T>::expired() const{
    return c == nullptr || c->pn == 0;
}

template<class S, typename T>
T& ptr_base<S, T>::operator*(){
    //if(expired())
    //    throw ExpiredPointerException();

    return *px;
}

template<class S, typename T>
T* ptr_base<S, T>::operator->(){
    //if(expired())
    //    throw ExpiredPointerException();

    return px;
}

template<class S, typename T>
ptr_base<S, T>::operator bool() const{
    return !expired();
}

#endif
