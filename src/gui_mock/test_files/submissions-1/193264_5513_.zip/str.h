#ifndef STR_H_INCLUDED
#define STR_H_INCLUDED

#include <cstdio>
#include <cstring>
#include <csignal>

#include "mem.h"

template<typename T>
class basic_str{
    private:
        s_ptr<T> content;
        int n;
        unsigned long hashVal;
        unsigned long hashCalc() const;
    public:
        basic_str();
        basic_str(const T*);
        basic_str(const T*, int);
        basic_str<T> strip(bool (*isspace)(T));
        unsigned long hash() const;
        int len() const;
        const T* get() const;
        T operator[](int idx);
        bool operator==(const basic_str<T>&) const;
        basic_str<T> operator+(const basic_str<T>) const;
        operator bool() const;
    private:
        static void del(T[]);
};

using str = basic_str<char>;

template<typename T>
basic_str<T>::basic_str(){
    content = s_ptr<char>();
    n = 0;
    hashVal = 0;
}

template<typename T>
basic_str<T>::basic_str(const T* r){
    n = strlen(r) + 1;
    content = s_ptr<T>(new T[n], del);
    std::memcpy(content.get(), r, n);
    hashVal = hashCalc();
}

template<typename T>
basic_str<T>::basic_str(const T* r, int len){
    n = len + 1;
    content = s_ptr<T>(new T[n], del);
    std::memcpy(content.get(), r, n - 1);
    content.get()[n - 1] = 0;
    hashVal = hashCalc();
}

template<typename T>
unsigned long basic_str<T>::hashCalc() const{
    // http://www.cse.yorku.ca/~oz/hash.html
    unsigned long hash = 5381;
    const T* t = get();

    for(int i = 0; i < len(); i++)
        hash = ((hash << 5) + hash) + t[i];

    return hash;
}

template<typename T>
unsigned long basic_str<T>::hash() const{
    return hashVal;
}

template<typename T>
int basic_str<T>::len() const{
    return n - 1;
}

template<typename T>
T basic_str<T>::operator[](int idx){
    return get()[idx];
}

template<typename T>
bool basic_str<T>::operator==(const basic_str<T>& other) const{
    return get() == other.get() ||
           (hash() == other.hash() &&
           n == other.n &&
           std::memcmp(get(), other.get(), n) == 0);
}

template<typename T>
basic_str<T> basic_str<T>::operator+(const basic_str<T> o) const{
    if(n <= 1)
        return o;

    if(o.n <= 1)
        return *this;

    s_ptr<char> buf(new char[n + o.n - 1], del);

    strcpy(buf.get(), get());
    strcat(buf.get(), o.get());

    return basic_str<T>(buf.get());
}

template<typename T>
basic_str<T>::operator bool() const{
    return n > 1;
}

template<typename T>
const T* basic_str<T>::get() const{
    return content.get();
}

template<typename T>
void basic_str<T>::del(T p[]){
    delete[] p;
}

template<typename T>
basic_str<T> basic_str<T>::strip(bool (*isspace)(T)) {
    int s = -1;
    int e = n - 1;
    if(n <= 1)
        return basic_str<T>();

    while(isspace(content.get()[(++s)])) {
        if(s == e - 1)
            return basic_str<T>();
    }

    while(isspace(content.get()[(--e)])) {}

    //printf("%d %d %d\n", n, s, e);

    return basic_str<T>(content.get() + s, e - s + 1);
}


#endif