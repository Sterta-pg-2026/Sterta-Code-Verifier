#ifndef BLKLST_H_INCLUDED
#define BLKLST_H_INCLUDED

#include "mem.h"
#include "lst.h"
#include "blk.h"
#include <cstdio>

template<typename T>
class BlockListIter;

template<typename T>
class ReverseBlockListIter;

template<typename T>
class BlockList{
    private:
        List<Block<T>> l;
        s_ptr<int> n;
        int bs;

    public:
        BlockList();
        BlockList(int bs);

        void add(s_ptr<T> v);
        s_ptr<T> pop(int idx);
        s_ptr<T> operator[](int idx);
        int length();

        BlockListIter<T> begin();
        BlockListIter<T> end();

        ReverseBlockListIter<T> rbegin();
        ReverseBlockListIter<T> rend();
};

template<typename T>
BlockList<T>::BlockList() { }

template<typename T>
BlockList<T>::BlockList(int bs): bs(bs), n(new int(0)) { }

template<typename T>
void BlockList<T>::add(s_ptr<T> v) {
    (*n)++;
    s_ptr<Block<T>> f;
    for(auto i = l.rbegin(); l.rend() != i; ++i){
        if((*i)->val->getUsed() > 0){
            f = (*i)->val;
            break;
        }
    }

    if(f && f->addR(v)) {
        return;
    }

    s_ptr<Block<T>> nb(new Block<T>(bs));
    nb->add(v);
    l.push_back(nb);
}

template<typename T>
s_ptr<T> BlockList<T>::operator[](int idx){
    int c = 0;
    for(auto i: l){
        if(idx >= i->val->getUsed()){
            idx -= i->val->getUsed();
            continue;
        }

        for(auto j: *(i->val)){
            if(j && (c++) == idx){
                return j;
            }
        }
    }

    return s_ptr<T>();
}

template<typename T>
s_ptr<T> BlockList<T>::pop(int idx){
    int d;
    if(idx >= (*n))
        return s_ptr<T>();

    (*n)--;
    int c = 0;
    s_ptr<ListNode<Block<T>>> node;
    for(auto i: l){
        if(node)
            break;
        d = 0;
        if(idx >= i->val->getUsed()){
            idx -= i->val->getUsed();
            continue;
        }

        for(auto j: *(i->val)){
            if(j){
                if((c++) == idx){
                    node = i;
                    break;
                }
            }
            d++;
        }
    }

    if(node){
        s_ptr<T> out = node->val->pop(d);
        if(node->val->getUsed() == 0)
            node->pop();

        return out;
    }

    return s_ptr<T>();
}

template<typename T>
int BlockList<T>::length() {
    return *n;
}

template<typename T>
BlockListIter<T> BlockList<T>::begin() {
    if(!l.getHead())
        return BlockListIter<T>(l, l.begin(), BlockIter<T>());

    BlockListIter<T> i = BlockListIter<T>(l, l.begin(), l.getHead()->val->begin());
    if(!(*l.getHead()->val)[0])
        ++i;
    
    return i;
}

template<typename T>
BlockListIter<T> BlockList<T>::end() {
    if(!l.getTail())
        return BlockListIter<T>(l, l.end(), BlockIter<T>());

    return BlockListIter<T>(l, l.end(), l.getTail()->val->end());
}

template<typename T>
ReverseBlockListIter<T> BlockList<T>::rbegin() {
    if(!(l.getTail()->val))
        return ReverseBlockListIter<T>(l, l.rbegin(), ReverseBlockIter<T>());

    ReverseBlockListIter<T> i = ReverseBlockListIter<T>(l, l.rbegin(), l.getTail()->val->rbegin());
    if(!(*l.getTail()->val)[l.getTail()->val->getCapacity() - 1])
        ++i;
    
    return i;
}

template<typename T>
ReverseBlockListIter<T> BlockList<T>::rend() {
    if(!(l.getHead()->val))
        return ReverseBlockListIter<T>(l, l.rend(), ReverseBlockIter<T>());

    return ReverseBlockListIter<T>(l, l.rend(), l.getHead()->val->rend());
}

template<typename T>
class BlockListIter{
    protected:
        List<Block<T>> l;
        ListIter<Block<T>> li;
        BlockIter<T> bi;

    public:
        BlockListIter(List<Block<T>> l, ListIter<Block<T>> li, BlockIter<T> bi);
        bool operator!=(BlockListIter&);
        s_ptr<T> operator*();
        BlockListIter<T>& operator++();
};

template<typename T>
BlockListIter<T>::BlockListIter(List<Block<T>> l, ListIter<Block<T>> li, BlockIter<T> bi): l(l), li(li), bi(bi) {}

template<typename T>
bool BlockListIter<T>::operator!=(BlockListIter& i) {
    return (li != i.li || bi != i.bi);
}

template<typename T>
BlockListIter<T>& BlockListIter<T>::operator++(){
    do{
        BlockIter<T> bend = (*li)->val->end();
        ListIter<Block<T>> lend = l.end();

        if(++bi != bend)
            continue;

        if(++li != lend){
            bi = (*li)->val->begin();
            continue;
        }

        bi = l.getTail()->val->end();
        return *this;
        
    } while(!*bi);

    return *this;
}

template<typename T>
s_ptr<T> BlockListIter<T>::operator*(){
    return *bi;
}


template<typename T>
class ReverseBlockListIter{
    protected:
        List<Block<T>> l;
        ReverseListIter<Block<T>> li;
        ReverseBlockIter<T> bi;

    public:
        ReverseBlockListIter(List<Block<T>> l, ReverseListIter<Block<T>> li, ReverseBlockIter<T> bi);
        bool operator!=(ReverseBlockListIter&);
        s_ptr<T> operator*();
        ReverseBlockListIter<T>& operator++();
};

template<typename T>
ReverseBlockListIter<T>::ReverseBlockListIter(List<Block<T>> l, ReverseListIter<Block<T>> li, ReverseBlockIter<T> bi): l(l), li(li), bi(bi) {}

template<typename T>
bool ReverseBlockListIter<T>::operator!=(ReverseBlockListIter& i) {
    return (li != i.li || bi != i.bi);
}

template<typename T>
ReverseBlockListIter<T>& ReverseBlockListIter<T>::operator++(){
    do{
        ReverseBlockIter<T> bend = (*li)->val->rend();
        ReverseListIter<Block<T>> lend = l.rend();

        if(++bi != bend)
            continue;

        if(++li != lend){
            bi = (*li)->val->rbegin();
            continue;
        }

        bi = l.getHead()->val->rend();
        return *this;
        
    } while(!*bi);

    return *this;
}

template<typename T>
s_ptr<T> ReverseBlockListIter<T>::operator*(){
    return *bi;
}



#endif