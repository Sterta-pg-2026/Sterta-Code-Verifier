#ifndef MEM_H_INCLUDED
#define MEM_H_INCLUDED

#include "ptr_base.h"
#include "s_ptr.h"
#include "w_ptr.h"

#endif
