#ifndef EXC_H_INCLUDED
#define EXC_H_INCLUDED

class Exception{};

class ExpiredPointerException: public Exception {};
class FullBlockException: public Exception {};
class OutOfRangeException: public Exception {};

#endif