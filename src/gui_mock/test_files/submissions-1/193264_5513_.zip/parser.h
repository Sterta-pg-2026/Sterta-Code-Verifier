#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "css.h"
#include "str.h"

static const int BUFFER_SIZE=4096;

enum State{SELECTOR, PROPERTY, VALUE};

class Parser{
    private:
        s_ptr<FILE> f;
        s_ptr<char> buffer;
        s_ptr<int> pos;
        str carry;
        s_ptr<State> s;
        CssBlock block;
        CssAttribute attr;

        void resetBuffer();
        void appendToBuffer(char c);
        void appendNToBuffer(char c, int n);
        str readBuffer();
        static bool isspace(char);

    public:
        CssDoc doc;
        Parser(s_ptr<FILE> f);
        Parser(s_ptr<FILE> f, CssDoc doc);

        bool parse();


};

#endif