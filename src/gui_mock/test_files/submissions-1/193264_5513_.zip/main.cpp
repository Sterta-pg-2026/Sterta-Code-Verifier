#include <cstring>
#include <cstdio>
#include <cstdlib>

#include "css.h"
#include "str.h"
#include "parser.h"

int main() {
    const int bufferSize = 4096;
    char lineBuffer[bufferSize];

    char cmdBuffer[3][1024];
    str arg1, arg2, op;

    int i, j;
    bool cmd = false;

    s_ptr<FILE> input(stdin, [](FILE *f){fclose(f);});
    Parser a(input);
    while(true){
        if(!cmd)
            cmd = a.parse();

        if(!fgets(lineBuffer, bufferSize, input.get()))
            break;
        
        if(strstr(lineBuffer, "?") == lineBuffer){
            printf("? == %d\n", a.doc.blocks.length());
            continue;
        }
        
        if(strstr(lineBuffer, "****") == lineBuffer){
            cmd = false;
            continue;
        }

        if(sscanf(lineBuffer, " %[^,],%1s,%s ", (char*)(cmdBuffer), (char*)(cmdBuffer + 1), (char*)(cmdBuffer + 2)) != 3)
            continue;

        arg1 = str((char*)cmdBuffer);
        op = str((char*)(cmdBuffer + 1));
        arg2 = str((char*)(cmdBuffer + 2));
        
        i = atoi(arg1.get());
        j = atoi(arg2.get());

        int resD = -1;
        str resS;


        if(op == str("S")){
            if(i){
                if(j){
                    // puts("iSj");

                    resS = a.doc.nthSelector(i - 1, j - 1);

                }else{
                    //puts("iS?");
                    resD = a.doc.selectorCount(i - 1);

                }
            }else{
                // puts("zS?");

                resD = a.doc.selectorCount(arg1);
            }
        }else if(op == str("A")){
            if(arg2 == str("?")){
                if(i){
                    // puts("iA?");
                    resD = a.doc.attrCount(i - 1);

                }else{
                    // puts("nA?");

                    resD = a.doc.attrCount(arg1);
                }
            }else{
                if(i){
                    // puts("iAn");
                    resS = a.doc.getValue(i - 1, arg2);
                }

            }
        }else if(op == str("D")){
            if(i){
                if(arg2 == str("*")){
                    // puts("iD*");
                    if(a.doc.remove(i - 1))
                        resS = str("deleted");
                }else{
                    // puts("iDn");
                    if(a.doc.remove(i - 1, arg2))
                        resS = str("deleted");
                }
            }
        }else if(op == str("E")){
            // puts("zEn");
            resS = a.doc.getValue(arg1, arg2);

        }

        if(resS || resD >= 0){
            if(resS){
                printf("%s,%s,%s == %s\n", arg1.get(), op.get(), arg2.get(), resS.get());
            }else{
                printf("%s,%s,%s == %d\n", arg1.get(), op.get(), arg2.get(), resD);
            }
        }

    }

}