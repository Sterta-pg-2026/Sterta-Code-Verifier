#include "css.h"

#include "mem.h"
#include "str.h"
#include "blklst.h"

CssAttribute::CssAttribute(str prop, str value): prop(prop), value(value) {}

CssBlock::CssBlock(): selectors(BLOCK_SIZE), attributes(ATTR_BLOCK_SIZE) {}

void CssBlock::addSelector(str& s) {
    if(!s)
        return;
        
    removeSelector(s);
    selectors.add(s_ptr<str>(new str(s)));
}

void CssBlock::addAttribute(CssAttribute& a) {
    removeAttribute(a.prop);
    attributes.add(s_ptr<CssAttribute>(new CssAttribute(a)));
}

void CssBlock::removeSelector(str& s) {
    int i = 0;
    for(auto j: selectors){
        if(*j == s){
            selectors.pop(i);
            return;
        }
        i++;
    }
}

bool CssBlock::removeAttribute(str& s){
    int i = 0;
    for(auto j: attributes){
        if(j->prop == s)
            break;
        i++;
    }
    if(i != attributes.length()){
        attributes.pop(i);
        return true;
    }

    return false;
}

bool CssBlock::hasSelector(str& s){
    for(auto j: selectors){
        if(*j == s)
            return true;
    }

    return false;
}

bool CssBlock::hasProperty(str& s){
    for(auto j: attributes){
        if(j->prop == s)
            return true;
    }

    return false;
}

str CssBlock::getValue(str& s){
    for(auto j: attributes){
        if(j->prop == s)
            return j->value;
    }
    return str(); // exception?
}

str CssBlock::nthSelector(int n){
    int i = 0;
    for(auto j: selectors){
        if(i++ == n)
            return *j;
    }
    return str(); //exception?
}

int CssBlock::attrCount() {
    return attributes.length();
}

int CssBlock::selectorCount() {
    return selectors.length();
}

bool CssBlock::empty() {
    return attrCount() == 0;
}

CssDoc::CssDoc(): blocks(BLOCK_SIZE) {}

void CssDoc::add(CssBlock& b) {
    blocks.add(s_ptr<CssBlock>(new CssBlock(b)));
}

bool CssDoc::remove(int idx) {
    return blocks.pop(idx);
}

bool CssDoc::remove(int idx, str& s){
    s_ptr<CssBlock> b = blocks[idx];
    if(!b)
        return false;
        
    bool r = b->removeAttribute(s);
    if(b->empty())
        remove(idx);

    return r;
}

int CssDoc::attrCount(str& s) {
    int i = 0;
    for(auto j: blocks){
        i += j->hasProperty(s);
    }
    return i;
}

int CssDoc::attrCount(int idx) {
    s_ptr<CssBlock> b = blocks[idx];
    if(!b)
        return -1;

    return b->attrCount();
}

int CssDoc::selectorCount(str& s) {
    int i = 0;
    for(auto j: blocks){
        i += j->hasSelector(s);
    }
    return i;
}

int CssDoc::selectorCount(int idx) {
    s_ptr<CssBlock> b = blocks[idx];
    if(!b)
        return -1;

    return b->selectorCount();
}

str CssDoc::getValue(int idx, str& s){
    s_ptr<CssBlock> b = blocks[idx];
    if(!b)
        return str();

    return b->getValue(s);
}

str CssDoc::getValue(str& z, str& s){
    str v;
    for(auto i = blocks.rbegin(); blocks.rend() != i; ++i){
        if(((*i)->hasSelector(z) || (*i)->selectorCount() == 0 ) && (v = (*i)->getValue(s)))
            return v;
    }
    return v;
}

str CssDoc::nthSelector(int idx, int n){
    s_ptr<CssBlock> b = blocks[idx];
    if(!b)
        return str();

    return b->nthSelector(n);
}
