#ifndef LST_H_INCLUDED
#define LST_H_INCLUDED

#include "exc.h"
#include "mem.h"
#include <cstdio>

template<typename T>
class List;

template<typename T>
class ListInfo;

template<typename T>
class ListNode{
    private:
        friend List<T>;
        w_ptr<ListInfo<T>> li;

        w_ptr<ListNode<T>> prev;
        s_ptr<ListNode<T>> next;
        w_ptr<ListNode<T>> self;

        ListNode();
        ListNode(w_ptr<ListInfo<T>> li, s_ptr<T> val);
        ListNode(w_ptr<ListInfo<T>> li, s_ptr<T> val, s_ptr<ListNode<T>> prev, s_ptr<ListNode<T>> next);
        void setSelf(s_ptr<ListNode<T>> self);

    public:
        s_ptr<T> val;

        static s_ptr<ListNode<T>> create(w_ptr<ListInfo<T>> li, s_ptr<T> val);

        s_ptr<ListNode<T>> after(s_ptr<T>);
        s_ptr<ListNode<T>> before(s_ptr<T>);
        s_ptr<ListNode<T>> getNext();
        s_ptr<ListNode<T>> getPrev();
        s_ptr<T> pop();
};

template<typename T>
ListNode<T>::ListNode() { }

template<typename T>
ListNode<T>::ListNode(w_ptr<ListInfo<T>> li, s_ptr<T> val): li(li), val(val) {} 

template<typename T>
ListNode<T>::ListNode(w_ptr<ListInfo<T>> li, s_ptr<T> val, s_ptr<ListNode<T>> prev, s_ptr<ListNode<T>> next): li(li), prev(prev), next(next), val(val) {} 

template<typename T>
void ListNode<T>::setSelf(s_ptr<ListNode<T>> self){
    this->self = self;
}

template<typename T>
s_ptr<ListNode<T>> ListNode<T>::create(w_ptr<ListInfo<T>> li, s_ptr<T> val){
    s_ptr<ListNode<T>> n(new ListNode<T>(li, val));
    n->setSelf(n);
    return n;
}

template<typename T>
s_ptr<ListNode<T>> ListNode<T>::after(s_ptr<T> v){
    if(!self)
        return s_ptr<ListNode<T>>();

    s_ptr<ListNode<T>> n(new ListNode(li, v, self, next));
    n->setSelf(n);

    if(next)
        next->prev = n;
    else
        li->tail = n;

    next = n;

    (*(li->n))++;

    return n;
}

template<typename T>
s_ptr<ListNode<T>> ListNode<T>::before(s_ptr<T> v){
    if(!self)
        return s_ptr<ListNode<T>>();

    s_ptr<ListNode<T>> n(new ListNode(li, v, prev, self));
    n->setSelf(n);

    if(prev)
        prev->next = n;
    else
        li->head = n;

    prev = n;

    (*(li->n))++;

    return n;


}

template<typename T>
s_ptr<T> ListNode<T>::pop(){
    //s_ptr<ListNode<T>> t = self;
    (*(li->n))--;

    if(next)
        next->prev = prev;
    else
        li->tail = prev;

    if(prev)
        prev->next = next;
    else
        li->head = next;
    

    return val;
}

template<typename T>
s_ptr<ListNode<T>> ListNode<T>::getNext() {
    return next;
}

template<typename T>
s_ptr<ListNode<T>> ListNode<T>::getPrev() {
    return prev;
}

template<typename T>
class ListIter;

template<typename T>
class ReverseListIter;

template<typename T>
class ListInfo{
    public:
        s_ptr<int> n;
        s_ptr<ListNode<T>> head;
        w_ptr<ListNode<T>> tail;
        ListInfo() = default;
};

template<typename T>
class List{
    private:
        friend ListNode<T>;
        friend ListIter<T>;
        s_ptr<ListInfo<T>> li;

        void push_first(s_ptr<T>);
        s_ptr<T> pop_last();

    public:
        List();
        int length();
        void push_back(s_ptr<T>);
        void push_front(s_ptr<T>);
        s_ptr<T> pop_back();
        s_ptr<T> pop_front();
        s_ptr<ListNode<T>> getHead();
        s_ptr<ListNode<T>> getTail();

        ListIter<T> begin();
        ListIter<T> end();

        ReverseListIter<T> rbegin();
        ReverseListIter<T> rend();
};

template<typename T>
List<T>::List() { 
    li = s_ptr<ListInfo<T>>(new ListInfo<T>());
    li->n = s_ptr<int>(new int(0));
}

template<typename T>
int List<T>::length() {
    if(!li->n)
        return 0;
    
    return *(li->n);
}

template<typename T>
void List<T>::push_first(s_ptr<T> ptr){
    li->n = s_ptr<int>(new int(1));
    li->head = ListNode<T>::create(li, ptr);
    li->tail = li->head;
}

template<typename T>
void List<T>::push_back(s_ptr<T> ptr){
    if(!li->tail)
        push_first(ptr);
    else
        li->tail->after(ptr);
    
}

template<typename T>
void List<T>::push_front(s_ptr<T> ptr){
    if(!li->head)
        push_first(ptr);
    else
        li->head->before(ptr);
}

template<typename T>
s_ptr<T> List<T>::pop_last(){
    li->n = s_ptr<int>();
    return li->head->pop();

}

template<typename T>
s_ptr<T> List<T>::pop_back(){
    return li->tail->pop();
}

template<typename T>
s_ptr<T> List<T>::pop_front(){
    return li->head->pop();
}

template<typename T>
s_ptr<ListNode<T>> List<T>::getHead(){
    return li->head;
}

template<typename T>
s_ptr<ListNode<T>> List<T>::getTail(){
    return li->tail;
}

template<typename T>
ListIter<T> List<T>::begin() {
    return ListIter<T>(li->head);
}

template<typename T>
ListIter<T> List<T>::end() {
    if(li->tail)
        return ListIter<T>(li->tail->getNext());
    
    return ListIter<T>(li->tail);
}

template<typename T>
ReverseListIter<T> List<T>::rbegin() {
    return ReverseListIter<T>(li->tail);
}

template<typename T>
ReverseListIter<T> List<T>::rend() {
    if(li->head)
        return ReverseListIter<T>(li->head->getPrev());
    
    return ReverseListIter<T>(li->head);
}

template<typename T>
class ListIter{
    protected:
        s_ptr<ListNode<T>> cur;

    public:
        ListIter(s_ptr<ListNode<T>>);
        bool operator!=(ListIter&);
        s_ptr<ListNode<T>> operator*();
        ListIter<T>& operator++();
};

template<typename T>
ListIter<T>::ListIter(s_ptr<ListNode<T>> cur): cur(cur) {}

template<typename T>
bool ListIter<T>::operator!=(ListIter& other) {
    return cur.get() != other.cur.get();
}

template<typename T>
ListIter<T>& ListIter<T>::operator++() {
    cur = cur->getNext();
    return *this;
}

template<typename T>
s_ptr<ListNode<T>> ListIter<T>::operator*(){
    return cur;
}

template<typename T>
class ReverseListIter: public ListIter<T>{
    private:
        using ListIter<T>::cur;
    public:
        ReverseListIter(s_ptr<ListNode<T>>);
        ReverseListIter<T>& operator++();
};

template<typename T>
ReverseListIter<T>::ReverseListIter(s_ptr<ListNode<T>> cur): ListIter<T>(cur) {}

template<typename T>
ReverseListIter<T>& ReverseListIter<T>::operator++() {
    cur = cur->getPrev();
    return *this;
}

#endif