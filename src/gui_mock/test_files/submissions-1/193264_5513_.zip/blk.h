#ifndef BLK_H_INCLUDED
#define BLK_H_INCLUDED

#include "exc.h"
#include "mem.h"
#include "lst.h"

template<typename T>
class BlockIter;

template<typename T>
class ReverseBlockIter;

template<typename T>
class Block{
    private:
        s_ptr<s_ptr<T>> items;
        s_ptr<int> used, capacity;

        static void del(s_ptr<T>*);

    public:
        Block();
        Block(int capacity);

        void add(s_ptr<T> v);
        bool addR(s_ptr<T> v);
        s_ptr<T> pop(int idx);

        bool isFull();
        int getUsed();
        int getCapacity();

        BlockIter<T> begin();
        BlockIter<T> end();
        ReverseBlockIter<T> rbegin();
        ReverseBlockIter<T> rend();

        s_ptr<T> operator[](int idx);
        operator bool();
};

template<typename T>
void Block<T>::del(s_ptr<T>* ptr){
    delete[] ptr;
}

template<typename T>
Block<T>::Block() {}

template<typename T>
Block<T>::Block(int capacity) {
    items = s_ptr<s_ptr<T>>(new s_ptr<T>[capacity], del);
    used = s_ptr<int>(new int(0));
    this->capacity = s_ptr<int>(new int(capacity));
}

template<typename T>
void Block<T>::add(s_ptr<T> v) {
    if(isFull())
        throw FullBlockException();

    for(int i = 0; i < getCapacity(); i++){
        if(items.get()[i])
            continue;
        
        items.get()[i] = v;
        (*used)++;
        return;
    }
    
}

template<typename T>
bool Block<T>::addR(s_ptr<T> v) {
    if(isFull())
        return false;

    int i = getCapacity() - 1;
    for(; !items.get()[i] && i >= 0; i--) {}
    if((++i) == getCapacity())
        return false;

    (*used)++;
    items.get()[i] = v;

    return true;
    
}

template<typename T>
s_ptr<T> Block<T>::pop(int idx){
    s_ptr<T> out = items.get()[idx];
    items.get()[idx] = s_ptr<T>();
    (*used)--;
    return out;
}

template<typename T>
bool Block<T>::isFull() {
    return !items || (items && *used == *capacity);
}

template<typename T>
int Block<T>::getUsed() {
    if(!items)
        return 0;

    return *used;
}

template<typename T>
int Block<T>::getCapacity() {
    if(!items)
        return 0;

    return *capacity;
}

template<typename T>
BlockIter<T> Block<T>::begin() {
    return BlockIter<T>(*this, 0);
}

template<typename T>
BlockIter<T> Block<T>::end() {
    return BlockIter<T>(*this, getCapacity());
}

template<typename T>
ReverseBlockIter<T> Block<T>::rbegin() {
    return ReverseBlockIter<T>(*this, getCapacity() - 1);
}

template<typename T>
ReverseBlockIter<T> Block<T>::rend() {
    return ReverseBlockIter<T>(*this, -1);
}

template<typename T>
Block<T>::operator bool() {
    return bool(items);
}

template<typename T>
s_ptr<T> Block<T>::operator[](int idx) {
    return items.get()[idx];
}

template<typename T>
class BlockIter{
    protected:
        Block<T> blk;
        int pos;
    public:
        BlockIter() = default;
        BlockIter(Block<T> b, int pos);
        bool operator!=(BlockIter<T>&);
        s_ptr<T> operator*();
        BlockIter<T>& operator++();
};

template<typename T>
BlockIter<T>::BlockIter(Block<T> blk, int pos): blk(blk), pos(pos) {}

template<typename T>
bool BlockIter<T>::operator!=(BlockIter<T>& other){
    return pos != other.pos;
}

template<typename T>
s_ptr<T> BlockIter<T>::operator*(){
    return blk[pos];
}

template<typename T>
BlockIter<T>& BlockIter<T>::operator++() {
    pos++;
    return *this;
}

template<typename T>
class ReverseBlockIter: public BlockIter<T> {
    private:
        using BlockIter<T>::blk;
        using BlockIter<T>::pos;
    public:
        ReverseBlockIter() = default;
        ReverseBlockIter(Block<T> b, int pos);
        ReverseBlockIter<T>& operator++();
};

template<typename T>
ReverseBlockIter<T>::ReverseBlockIter(Block<T> blk, int pos): BlockIter<T>(blk, pos) {}

template<typename T>
ReverseBlockIter<T>& ReverseBlockIter<T>::operator++() {
    pos--;
    return *this;
}


#endif