#ifndef ATTRIBUTE_H_INCLUDED
#define ATTRIBUTE_H_INCLUDED

#include "str.h"
#include "lst.h"
#include "blklst.h"

const int BLOCK_SIZE=17;
const int ATTR_BLOCK_SIZE=4;

struct CssAttribute{
    str prop, value;
    CssAttribute() = default;
    CssAttribute(str, str);
};

struct CssBlock{
    BlockList<str> selectors;
    BlockList<CssAttribute> attributes;
    CssBlock();

    void addSelector(str&);
    void addAttribute(CssAttribute&);

    void removeSelector(str&);
    bool removeAttribute(str&);

    bool hasSelector(str&);
    bool hasProperty(str&);

    int attrCount();
    int selectorCount();

    str getValue(str&);
    str nthSelector(int);

    bool empty();
};

struct CssDoc{
    BlockList<CssBlock> blocks;
    CssDoc();

    void add(CssBlock&);

    bool remove(int);
    bool remove(int, str&);

    int attrCount(str&);
    int attrCount(int);
    int selectorCount(str&);
    int selectorCount(int);

    str getValue(str&, str&);
    str getValue(int, str&);

    str nthSelector(int, int);

};

#endif