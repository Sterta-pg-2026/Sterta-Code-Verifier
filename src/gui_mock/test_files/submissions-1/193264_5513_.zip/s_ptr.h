#ifndef S_PTR_H_INCLUDED
#define S_PTR_H_INCLUDED

#include "ptr_base.h"
#include <cstdio>

template<typename T>
class shared {
    friend class ptr_base<shared, T>;
    static void acquire(T*, ptr_count**);
    static void release(T**, ptr_count**, void (*del)(T*));
};

template<typename T>
void shared<T>::acquire(T* px, ptr_count** c){
    if(px == nullptr)
        return;
    
    if(*c == nullptr)
        *c = new ptr_count();
    
    (*c)->pn++;
}

template<typename T>
void shared<T>::release(T** px, ptr_count** c, void (*del)(T*)){
    if(*c == nullptr)
        return;

    ((*c)->pn)--;

    if((*c)->pn == 0){
        if((*c)->wn == 0)
            delete *c;
        
        if(del != nullptr)
            del(*px);
        else
            delete *px;

        *px = nullptr;
        *c = nullptr; // ???

    }
}

template<typename T>
using s_ptr = ptr_base<shared<T>, T>;

#endif