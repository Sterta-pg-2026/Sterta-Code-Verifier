#ifndef W_PTR_H_INCLUDED
#define W_PTR_H_INCLUDED

#include "ptr_base.h"

template<typename T>
class weak {
    friend class ptr_base<weak, T>;
    static void acquire(T*, ptr_count**);
    static void release(T**, ptr_count**, void (*del)(T*));
};

template<typename T>
void weak<T>::acquire(T* px, ptr_count** c){
    if(*c == nullptr)
        return;

    (*c)->wn++;
}

template<typename T>
void weak<T>::release(T** px, ptr_count** c, void (*del)(T*)){
    if(*c == nullptr)
        return;

    if((*c)->wn == 0)
        return;

    (*c)->wn--;

    if((*c)->wn != 0 || (*c)->pn != 0)
        return;
    
    delete *c;
    *c = nullptr;
}

template<typename T>
using w_ptr = ptr_base<weak<T>, T>;

#endif