#include "parser.h"

#include <stdio.h>
#include <cctype>

#include "str.h"
#include "css.h"

Parser::Parser(s_ptr<FILE> f, CssDoc doc): f(f), doc(doc) {}

Parser::Parser(s_ptr<FILE> f): Parser(f, CssDoc()) {
    buffer = s_ptr<char>(new char[BUFFER_SIZE], [](char *f){delete[] f;});
    pos = s_ptr<int>(new int(0));
    s = s_ptr<State>(new State(SELECTOR));
}

void Parser::resetBuffer() {
    carry = str();
    *pos = 0;
}

void Parser::appendToBuffer(char c) {
    if(*pos == BUFFER_SIZE){
        carry = carry + str(buffer.get(), BUFFER_SIZE);
        *pos = 0;
    }

    buffer.get()[(*pos)++] = c;
}

void Parser::appendNToBuffer(char c, int n){
    for(int i = 0; i < n; i++)
        appendToBuffer(c);
}

str Parser::readBuffer() {
    return (carry + str(buffer.get(), *pos)).strip(isspace);
}

bool Parser::isspace(char c){
    return std::isspace(c);
}

bool Parser::parse() {
    int qc = 0;
    int c = EOF;

    while((c = getc(f.get())) != EOF) {
        if(c == '?'){
            if(++qc == 4){
                return true;
            }

            continue;

        }else{
            appendNToBuffer('?', qc);
            qc = 0;
        }

        if(*s == SELECTOR){
            if(c == ','){
                str sel = readBuffer();
                resetBuffer();
                block.addSelector(sel);
                continue;
            }
            else if(c == '{'){
                str sel = readBuffer();
                resetBuffer();
                block.addSelector(sel);
                *s = PROPERTY;
                continue;

                
            }

        }
        else if(*s == PROPERTY){
            if(c == ':'){
                attr.prop = readBuffer();
                resetBuffer();
                *s = VALUE;
                continue;
            }
            else if(c == '}'){
                *s = SELECTOR;
                resetBuffer();

                doc.add(block);
                block = CssBlock();
                continue;
            }
        }
        else if(*s == VALUE){
            if(c == ';'){
                attr.value = readBuffer();
                resetBuffer();
                *s = PROPERTY;

                block.addAttribute(attr);
                attr = CssAttribute();
                continue;

            }
            else if(c == '}'){
                attr.value = readBuffer();
                resetBuffer();
                block.addAttribute(attr);
                *s = SELECTOR;

                attr = CssAttribute();

                doc.add(block);
                block = CssBlock();
                continue;
                
            }
        }

        appendToBuffer(c);
    }

    return false;

}