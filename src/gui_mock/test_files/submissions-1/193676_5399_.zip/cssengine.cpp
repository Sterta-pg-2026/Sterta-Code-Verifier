#include "cssengine.hpp"

void CssEngine::createBlock()
{
    Block *new_block = new Block();
    blocks.push_back(new_block);
}

Section *&CssEngine::getSection(int section_index)
{
    int counter = 0;
    // Iterate over all Blocks
    for (auto block = blocks.begin(); block != nullptr; ++block)
        // Iterate over all sections in the block
        for (int i = 0; i < SINGLE_BLOCK_SIZE; ++i)
        {
            if ((*block)->sections[i] == nullptr)
                continue;

            if (counter == section_index)
                return (*block)->sections[i];

            counter++;
        }

    // If section not found, return reference to a null pointer
    static Section *null_section_ptr = nullptr;
    return null_section_ptr;
}

void CssEngine::getSelectors(DoubleLinkedList<String> &selectors)
{
    String selector;

    while (true)
    {
        char c = cin.get();

        if (cin.eof())
            exit(0);

        if (c == '{' || c == ',')
        {
            if (selector.getSize() != 0)
            {
                selector.trim();
                selectors.push_back(selector);
                selector.clear();
            }

            if (c == '{')
                return;
        }
        else
        {
            selector.addChar(c);
        }
    }
}

void CssEngine::getAttributes(DoubleLinkedList<Attribute> &attributes)
{
    Attribute attribute;
    bool is_reading_property = true; // If false, the value is reading

    while (true)
    {
        char c = cin.get();

        if (cin.eof())
            exit(0);

        if (c == '}' || c == ';')
        {
            if (attribute.property.getSize() != 0 && !is_reading_property)
            {
                attribute.property.trim();
                attribute.value.trim();

                bool is_duplicate = false;

                // Check if attribute already exists (if it does, replace it)
                for (auto attr = attributes.begin(); attr != nullptr; ++attr)
                    if ((*attr).property == attribute.property)
                    {
                        (*attr).value = attribute.value;
                        is_duplicate = true;
                        break;
                    }

                if (!is_duplicate)
                    attributes.push_back(attribute);

                attribute.property.clear();
                attribute.value.clear();

                is_reading_property = true;
            }

            if (c == '}')
                return;
        }
        else if (c == ':')
        {
            is_reading_property = !is_reading_property;
            continue;
        }
        else
        {
            is_reading_property ? attribute.property.addChar(c) : attribute.value.addChar(c);
        }
    }
}

bool CssEngine::deleteSection(int section_index)
{
    Section *&section = getSection(section_index);
    if (section == nullptr)
        return false;

    delete section;
    section = nullptr;

    num_of_sections--;
    return true;
}

bool CssEngine::deleteAttribute(int section_index, String &property)
{
    Section *section = getSection(section_index);
    if (section == nullptr)
        return false;

    int attribute_index = -1;

    for (auto attribute = section->attributes.begin(); attribute != nullptr; ++attribute)
    {
        attribute_index++;

        if ((*attribute).property == property)
        {
            section->attributes.pop(attribute_index);

            if (section->attributes.getSize() == 0)
                deleteSection(section_index);

            return true;
        }
    }

    return false;
}

void CssEngine::printCommand(String *params)
{
    cout << params[0] << "," << params[1] << "," << params[2] << " == ";
}

void CssEngine::S(String *params)
{
    // z,S,?
    if (!params[0].toInt())
    {
        int counter = 0;

        // Iterate over all Blocks
        for (auto block = blocks.begin(); block != nullptr; ++block)
            // Iterate over all sections in the block
            for (int i = 0; i < SINGLE_BLOCK_SIZE; ++i)
            {
                if ((*block)->sections[i] == nullptr)
                    continue;

                if ((*block)->sections[i]->selectors.findIndex(params[0]) != -1)
                    counter++;
            }

        printCommand(params);
        cout << counter << endl;
        return;
    }

    int section_index = params[0].toInt() - 1;
    Section *section = getSection(section_index);

    if (section == nullptr)
        return;

    // i,S,?
    if (params[2] == "?")
    {
        printCommand(params);
        cout << section->selectors.getSize() << endl;
    }
    // i,S,j
    else
    {
        int selector_index = params[2].toInt() - 1;
        if (selector_index >= section->selectors.getSize())
            return;

        printCommand(params);
        cout << section->selectors[selector_index] << endl;
    }
}

void CssEngine::D(String *params)
{
    bool success = false;

    if (params[2] == "*")
        success = deleteSection(params[0].toInt() - 1);
    else
        success = deleteAttribute(params[0].toInt() - 1, params[2]);

    if (success)
    {
        printCommand(params);
        cout << "deleted" << endl;
    }
}

void CssEngine::A(String *params)
{
    // n,A,?
    if (!params[0].toInt())
    {
        int counter = 0;

        // Iterate over all Blocks
        for (auto block = blocks.begin(); block != nullptr; ++block)
            // Iterate over all sections in the block
            for (int i = 0; i < SINGLE_BLOCK_SIZE; ++i)
            {
                if ((*block)->sections[i] == nullptr)
                    continue;

                for (auto attribute = (*block)->sections[i]->attributes.begin(); attribute != nullptr; ++attribute)
                    if ((*attribute).property == params[0])
                        counter++;
            }

        printCommand(params);
        cout << counter << endl;
        return;
    }

    int section_index = params[0].toInt() - 1;
    Section *section = getSection(section_index);

    if (section == nullptr)
        return;

    // i,A,?
    if (params[2] == "?")
    {
        printCommand(params);
        cout << section->attributes.getSize() << endl;
    }
    // i,A,n
    else
        for (auto attribute = section->attributes.begin(); attribute != nullptr; ++attribute)
            if ((*attribute).property == params[2])
            {
                printCommand(params);
                cout << (*attribute).value << endl;
            }
}

void CssEngine::E(String *params)
{
    // Iterate over all Blocks
    for (auto block = blocks.end(); block != nullptr; --block)
        // Iterate over all sections in the block
        for (int i = SINGLE_BLOCK_SIZE - 1; i >= 0; --i)
        {
            // Skip if section has been removed before
            if ((*block)->sections[i] == nullptr)
                continue;

            // Find selector in attribute
            for (auto selector = (*block)->sections[i]->selectors.begin(); selector != nullptr; ++selector)
                // If selector is found, iterate over all attributes
                if ((*selector) == params[0])
                    // ... and if found, find attribute value
                    for (auto attribute = (*block)->sections[i]->attributes.begin(); attribute != nullptr; ++attribute)
                        // if found, print it
                        if ((*attribute).property == params[2])
                        {
                            printCommand(params);
                            cout << (*attribute).value << endl;
                            return;
                        }
        }
}

// PUBLIC:

void CssEngine::addSection()
{
    Section *section = new Section();

    getSelectors(section->selectors);
    getAttributes(section->attributes);

    size_t block_number = last_section_index / SINGLE_BLOCK_SIZE;
    size_t section_index = last_section_index % SINGLE_BLOCK_SIZE;

    if (section_index == 0)
        createBlock();

    blocks[block_number]->sections[section_index] = section;

    last_section_index++;
    num_of_sections++;
}

void CssEngine::executeCommand()
{
    String *params = new String[3]; // list of parameters (each command has 3 parameters)
    char c;

    cin >> c;

    if (cin.eof())
        exit(0);

    if (c == '?')
    {
        cout << "? == " << num_of_sections << endl;
        delete[] params;
        return;
    }

    params[0].addChar(c);

    // Load all three parameters
    for (size_t i = 0; i < 3; i++)
    {
        while (true)
        {
            c = cin.get();

            if (cin.eof())
                exit(0);

            if (c == ',' || c == '\n')
                break;

            params[i].addChar(c);
        }

        if (c == '\n')
            break;

        params[i].trim();
    }

    switch (params[1][0])
    {
    case 'S':
        S(params);
        break;

    case 'D':
        D(params);
        break;

    case 'A':
        A(params);
        break;

    case 'E':
        E(params);
        break;

    default:
        // It's incorrect command so skip it:

        // 1. Put back last character (because it can be \n)
        cin.putback(c);

        // 2. Skip all characters until end of command
        while (cin.get() != '\n')
            continue;
        break;
    }

    delete[] params;
}
