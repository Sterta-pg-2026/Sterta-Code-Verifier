#pragma once

#include <iostream>

#define BUFFER_INIT_SIZE 16

class String
{
private:
	char *str;
	size_t str_size;
	size_t buffer_size;

	friend std::ostream &operator<<(std::ostream &os, const String &s);

public:
	String() : str(nullptr), str_size(0), buffer_size(BUFFER_INIT_SIZE) {}
	String(const char *s);
	String(const String &other); // Copy constructor

	size_t getSize() const;
	void addChar(char c);
	void clear();
	void trim();
	int toInt();

	const char &operator[](int index) const;
	String &operator=(const String &other);
	String &operator=(const char *s);
	bool operator==(const String &right);

	~String();
};
