#include <iostream>

#include "cssengine.hpp"
#include "doublelinkedlist.hpp"
#include "string.hpp"

using namespace std;

int main()
{
  CssEngine engine;
  bool isParsingCss = true;
  char c;

  while (true)
  {
    cin >> c;

    if (cin.eof())
      exit(0);

    // Check if is mode change
    if (c == '?' && isParsingCss)
    {
      for (size_t i = 0; i < 3; i++)
      {
        cin >> c;
        if (c != '?')
          cout << "ISSUE WITH CHANGING MODES (from parsing css to commands)";
      }

      isParsingCss = false;
      continue;
    }
    else if (c == '*' && !isParsingCss)
    {
      for (size_t i = 0; i < 3; i++)
      {
        cin >> c;
        if (c != '*')
          cout << "ISSUE WITH CHANGING MODES (from parsing commands to css)";
      }

      isParsingCss = true;
      continue;
    }

    // There isn't mode change. Putback char and continue
    cin.putback(c);

    if (isParsingCss)
      engine.addSection();
    else
      engine.executeCommand();
  }

  return 0;
}
