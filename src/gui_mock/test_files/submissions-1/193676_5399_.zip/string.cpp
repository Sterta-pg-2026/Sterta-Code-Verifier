#define _CRT_SECURE_NO_WARNINGS
#include "string.hpp"

#include <string.h>

#include <iostream>

using namespace std;

String::String(const char *s)
{
	str_size = strlen(s);
	buffer_size = BUFFER_INIT_SIZE;

	str = new char[str_size + 1];
	strcpy(str, s);

	str[str_size] = '\0';
}

String::String(const String &other)
{
	str_size = other.str_size;
	str = new char[str_size + 1];

	strcpy(str, other.str);

	str[str_size] = '\0';
}

size_t String::getSize() const
{
	return str_size;
}

void String::addChar(char c)
{
	if (str == nullptr)
	{
		str = new char[buffer_size];
	}
	else if (str_size + 1 >= buffer_size)
	{
		buffer_size = str_size + BUFFER_INIT_SIZE;

		char *temp = str;
		str = new char[buffer_size];

		strcpy(str, temp);

		delete[] temp;
	}

	str[str_size] = c;
	str_size++;
	str[str_size] = '\0';
}

void String::clear()
{
	str_size = 0;
}

void String::trim()
{
	size_t startpos = 0;
	while (isspace(str[startpos]))
	{
		startpos++;
	}

	size_t endpos = str_size - 1;
	while (endpos > startpos && isspace(str[endpos]))
	{
		endpos--;
	}

	// Move the elements of the str array so that
	// the first non-whitespace character is the first element
	if (startpos > 0)
	{
		memmove(str, str + startpos, endpos - startpos + 1);
	}

	str_size = endpos - startpos + 1;
	str[str_size] = '\0';
}

int String::toInt()
{
	return atoi(str);
}

// char& String::operator[]( int index) {
//     return str[index];
// }

const char &String::operator[](int index) const
{
	return str[index];
}

String &String::operator=(const String &other)
{
	if (this != &other)
	{
		delete[] str;
		str_size = other.str_size;
		str = new char[str_size + 1];
		strcpy(str, other.str);
		str[str_size] = '\0';
	}

	return *this;
}

String &String::operator=(const char *s)
{
	delete[] str;
	str_size = strlen(s);
	str = new char[str_size + 1];
	strcpy(str, s);
	str[str_size] = '\0';

	return *this;
}

bool String::operator==(const String &right)
{
	if (str_size != right.getSize())
	{
		return false;
	}

	for (size_t i = 0; i < str_size; i++)
	{
		if (str[i] != right[i])
		{
			return false;
		}
	}

	return true;
}

ostream &operator<<(ostream &os, const String &s)
{
	for (size_t i = 0; i < s.str_size; ++i)
	{
		os << s[i];
	}

	return os;
}

String::~String()
{
	if (str != nullptr)
		delete[] str;
}
