#pragma once

#include <iostream>

#include "doublelinkedlist.hpp"
#include "string.hpp"

#define SINGLE_BLOCK_SIZE 17

struct Attribute
{
	String property;
	String value;
};

struct Section
{
	DoubleLinkedList<String> selectors;
	DoubleLinkedList<Attribute> attributes;
};

struct Block
{
	Section *sections[SINGLE_BLOCK_SIZE];
};

class CssEngine
{
private:
	size_t last_section_index;
	size_t num_of_sections;

	DoubleLinkedList<Block *> blocks;

	// Helpers
	void createBlock();
	Section *&getSection(int section_index);
	void getSelectors(DoubleLinkedList<String> &selectors);
	void getAttributes(DoubleLinkedList<Attribute> &attributes);
	bool deleteSection(int section_index);
	bool deleteAttribute(int section_index, String &property);

	// Cover commands
	void printCommand(String *params);
	void S(String *params);
	void D(String *params);
	void A(String *params);
	void E(String *params);

public:
	CssEngine() : last_section_index(0), num_of_sections(0){};

	void addSection();
	void executeCommand();
};
