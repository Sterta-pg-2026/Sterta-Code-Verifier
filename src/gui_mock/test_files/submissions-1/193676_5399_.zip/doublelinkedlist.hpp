#pragma once

#ifndef DOUBLY_LINKED_LIST
#define DOUBLY_LINKED_LIST

#include <iostream>
#include "string.hpp"
using namespace std;

template <class T>
class DoubleLinkedList
{
private:
	struct Node
	{
		T value;
		Node *prev;
		Node *next;
		Node(const T &value) : value(value), prev(nullptr), next(nullptr){};
	};

	Node *head;
	Node *tail;
	int list_size;

public:
	DoubleLinkedList() : head(nullptr), tail(nullptr), list_size(0){};
	~DoubleLinkedList();

	void push_front(const T &value);
	void push_back(const T &value);
	void push(int index, const T &value);

	void pop_front();
	void pop_back();
	void pop(int index);

	T &operator[](int index) const;

	void print() const;
	size_t getSize() const;
	void validIndex(int i) const;

	int findIndex(T &value) const;

	class DLLIterator
	{
	private:
		Node *current;

	public:
		DLLIterator(Node *head) : current(head){};

		DLLIterator &operator++()
		{
			current = current->next;
			return *this;
		}

		DLLIterator &operator--()
		{
			current = current->prev;
			return *this;
		}

		bool operator!=(const DLLIterator &other) const
		{
			return current != other.current;
		}

		T &operator*() const
		{
			return current->value;
		}
	};

	DLLIterator begin() const
	{
		return DLLIterator(head);
	}

	DLLIterator end() const
	{
		return DLLIterator(tail);
	}
};

template <class T>
DoubleLinkedList<T>::~DoubleLinkedList()
{
	while (head != nullptr)
	{
		Node *temp = head;
		head = head->next;
		delete temp;
	}
}

template <class T>
void DoubleLinkedList<T>::push_front(const T &value)
{
	Node *new_node = new Node(value);
	if (list_size == 0)
	{
		head = tail = new_node;
	}
	else
	{
		new_node->next = head;
		head->prev = new_node;
		head = new_node;
	}

	list_size++;
}

template <class T>
void DoubleLinkedList<T>::push_back(const T &value)
{
	Node *new_node = new Node(value);
	if (list_size == 0)
	{
		head = tail = new_node;
	}
	else
	{
		new_node->prev = tail;
		tail->next = new_node;
		tail = new_node;
	}

	list_size++;
}

template <class T>
void DoubleLinkedList<T>::push(int index, const T &value)
{
	validIndex(index);

	if (index == 0)
		push_front(value);
	else if (index == list_size)
		push_back(value);
	else
	{
		Node *current = head;

		for (int i = 0; i < index - 1; i++)
		{
			current = current->next;
		}

		Node *newNode = new Node(value);
		newNode->prev = current;
		newNode->next = current->next;

		current->next->prev = newNode;
		current->next = newNode;

		list_size++;
	}
}

template <class T>
void DoubleLinkedList<T>::pop_front()
{
	if (list_size == 0)
		return;

	Node *node_to_delete = head;

	if (list_size == 1)
	{
		head = tail = nullptr;
	}
	else
	{
		head = head->next;
		head->prev = nullptr;
	}

	delete node_to_delete;

	list_size--;
}

template <class T>
void DoubleLinkedList<T>::pop_back()
{
	if (list_size == 0)
		return;
	if (list_size == 1)
	{
		pop_front();
		return;
	}

	Node *node_to_delete = tail;

	tail = tail->prev;
	tail->next = nullptr;
	list_size--;

	delete node_to_delete;
}

template <class T>
void DoubleLinkedList<T>::pop(int index)
{
	validIndex(index);

	if (list_size == 0)
		return;
	else if (index == 0)
		pop_front();
	else if (index == list_size - 1)
		pop_back();
	else
	{
		Node *current = head;

		for (int i = 0; i < index - 1; i++)
		{
			current = current->next;
		}

		Node *node_to_delete = current->next;
		current->next = node_to_delete->next;
		current->next->prev = current;

		delete node_to_delete;

		list_size--;

		if (list_size == 0)
		{
			head = tail = nullptr;
		}
	}
}

template <class T>
T &DoubleLinkedList<T>::operator[](int index) const
{
	validIndex(index);

	Node *current;

	if (index < list_size / 2)
	{
		current = head;
		for (size_t i = 0; i < index; i++)
			current = current->next;
	}
	else
	{
		current = tail;
		for (size_t i = list_size - 1; i > index; i--)
			current = current->prev;
	}

	return current->value;
}

template <class T>
void DoubleLinkedList<T>::print() const
{
	Node *current = head;
	cout << "Lista(" << list_size << "): ";
	while (current != nullptr)
	{
		cout << current->value << ", ";
		current = current->next;
	}
	cout << endl;
}

template <class T>
size_t DoubleLinkedList<T>::getSize() const
{
	return list_size;
}

template <class T>
void DoubleLinkedList<T>::validIndex(int i) const
{
	if (i < 0 || i >= list_size)
		try
		{
			throw out_of_range("DLL: index out of range");
		}
		catch (const exception &e)
		{
			cerr << e.what() << endl;
		}
};

template <class T>
int DoubleLinkedList<T>::findIndex(T &value) const
{
	int index = 0;
	Node *current = head;

	while (current != nullptr)
	{
		if (current->value == value)
			return index;

		index++;
		current = current->next;
	}

	return -1;
};

#endif