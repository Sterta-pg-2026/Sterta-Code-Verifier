#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define SIZE_BLOCK 6
#define NO 0
#define YAS 1
#include <iostream>
#include"string.h"
using namespace std;

typedef struct NodeSelec {

    String data;
    NodeSelec* next = 0;

    NodeSelec() {
    }
    NodeSelec(String d) {
        data = d;
    }
};

typedef class ListSelec {

    NodeSelec* head;// , * tail;

public:

    ListSelec() { // constructor
        head = NULL;
    }

    void printList() {

        NodeSelec* temp = head;
        cout << "Selectors list: ";
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void addFirst(String val) {
        // make a new node
        NodeSelec* new_node = new NodeSelec(val);

        if (head == NULL) {  // If list is empty
            head = new_node;
            // tail = new_node;
             //tail->next = NULL;
        }
        else {
            new_node->next = head;
            head = new_node;
        }
    }
    NodeSelec* getTail() {
        NodeSelec* tmp = head;
        while (tmp->next != NULL) {
            tmp = tmp->next;
        }
        return tmp;
    }
    void addLast(String val) {
        // make a new node
        NodeSelec* new_node = new NodeSelec(val);
        if (head == NULL) {  // If list is empty
            head = new_node;
        }
        else {
            NodeSelec* oldTail = getTail();
            oldTail->next = new_node;
        }
    }
    int searchName(String name) {
        // make a new node
        NodeSelec* node = head;
        if (head == NULL) {  // If list is empty
            return 0;
        }
        else {

            if (node->data == name) { // name found
                return 1;
            }
            else if (!(node->data == name) && node->next != NULL) { // it's not compatible or it's the end of the list
                node = node->next;
            }
            return 0;
        }
    }
    String searchByNumber(int number) {
        // function returns string at position number (0-based)

        NodeSelec* node = head;
        int i = 1;
        if (head == NULL) { // return an empty string if not exists
            return "";
        }
        else {
            while (i < number && node != NULL) {
                node = node->next;
                i++;
            }
            if (node != NULL) {
                return node->data;
            }
            else {
                return "";
            }
        }
    }
  
};

typedef struct NodeAtri {

    String name;
    String value;
    NodeAtri* next = 0;

    NodeAtri() {
    }

    NodeAtri(String namee, String valuee) { //idk if works
        name = namee;
        value = valuee;
    }
};

typedef class ListAtri {

    NodeAtri* head;// , * tail;

public:

    ListAtri() { // constructor
        head = NULL;
    }

    void printList() {

        NodeAtri* temp = head;
        cout << "Atributes list: ";
        while (temp != NULL) {
            cout << temp->name << " ";
            cout << temp->value << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void addFirst(String name, String value) {
        // make a new node
        NodeAtri* new_node = new NodeAtri(name, value);

        if (head == NULL) {  // If list is empty
            head = new_node;
            // tail = new_node;
             //tail->next = NULL;
        }
        else {
            new_node->next = head;
            head = new_node;
        }
    }
    NodeAtri* getTail() {
        NodeAtri* tmp = head;
        while (tmp->next != NULL) {
            tmp = tmp->next;
        }
        return tmp;
    }
    NodeAtri* getHead() {
        return head;
    }

    void addLast(String nam, String val) {

        NodeAtri* new_node = new NodeAtri(nam, val);
        if (head == NULL) {  // If list is empty
            head = new_node;
        }
        else {
            NodeAtri* oldTail = getTail();
            oldTail->next = new_node;
        }
    }
    int searchName(String name) {
        // make a new node
        NodeAtri* node = head;
        if (head == NULL) {  // If list is empty
            return 0;
        }
        else {
            while (node != NULL) {
                if (node->name == name) { // name found
                    return 1;
                }
                node = node->next;
            }
            return 0;
        }
    }
    String searchByNumber(int number) {
        // function returns string at position number (0-based)

        NodeAtri* node = head;
        int i = 1;
        if (head == NULL) { // return an empty string if not exists
            return "";
        }
        else {
            while (i < number && node != NULL) {
                node = node->next;
                i++;
            }
            if (node != NULL) {
                return node->name;
            }
            else {
                return "";
            }
        }
    }
    String getValue(String namee) {
        String temp;
        NodeAtri* node = head;
        while (node != NULL) {
            if (node->name == namee) {
                temp = node->value;
            }
            node = node->next;
        }
        return temp;
    }
    void removeAtri(String namee) {
        NodeAtri* node = head;
        if (head == NULL) {
            return;
        }
        if (head->name == namee) {
            head = head->next;
            return;
        }
        while (node->next != NULL) {
            if (node->next->name == namee) {
                node->next = node->next->next;
                return;
            }
            node = node->next;
        }
    }
    void changeValue(String namee, String valuee) {
        String temp;
        NodeAtri* node = head;

        while (node != NULL) {

            if (node->name == namee) { // node founded
                node->value = valuee;
                exit;
            }
            node = node->next;
        }
    }
    void cut() {
        head = NULL;
    }
};

typedef struct Block {
    ListSelec selectors;
    ListAtri atributes;
    int selectorNumber = 0;
    int atributeNumber = 0;
    int full = NO;

    Block() { // default constructor
    }

    Block(ListSelec s, ListAtri a, int sN, int aN) {
        selectors = s;
        atributes = a;
        full = YAS;
        selectorNumber = sN;
        atributeNumber = aN;

    }
};

typedef struct DoubleNode {

    Block block[SIZE_BLOCK];
    DoubleNode* next = 0;
    DoubleNode* previous = 0;

    DoubleNode() {
        next = NULL;
        previous = NULL;
    }
    DoubleNode(Block b[SIZE_BLOCK]) {

        for (int i = 0; i < SIZE_BLOCK; i++) {
            block[i] = b[i];
        }
    }
};

typedef class DoubleList {

    DoubleNode* head;// , * tail;

public:

    DoubleList() { // constructor
        head = NULL;
    }
    DoubleNode* getTail() {
        DoubleNode* tmp = head;

        // Check if the list is empty
        if (tmp == NULL) {
            return NULL;
        }
        while (tmp->next != NULL) {
            tmp = tmp->next;
        }
        return tmp;
    }

    void AddLast(Block b[SIZE_BLOCK]) {
        DoubleNode* newNode = new DoubleNode(b);

        if (head == NULL) { // if the list is empty
            head = newNode;
        }
        else {
            DoubleNode* tail = getTail();
            tail->next = newNode;
            newNode->previous = tail;
        }
    }
    void addNode(DoubleNode* newNode) {
        if (head == NULL) { // if the list is empty
            head = newNode;
        }
        else {
            DoubleNode* tail = getTail();
            tail->next = newNode;
            newNode->previous = tail;
        }
    }
    DoubleNode* GetAtPos(DoubleNode* head, int position) {
        // #function returns element at position pos(0 - based)
        // # or None if not exists
        DoubleNode* tmp = head;
        while (tmp != NULL) {
            if (position == 0) {
                return tmp;
            }
            position = position - 1;
            tmp = tmp->next;
        }
        return NULL;
    }
    DoubleNode* getHead() {
        return head;
    }
    ListAtri isSelector(String name, DoubleList *doubleList) { // for z,E,n
       // ListAtri extra;
        DoubleNode* tmp = getTail();

        int i = SIZE_BLOCK - 1;

        while (tmp != NULL) {

            if (tmp->block[i].selectors.searchName(name) == 1 && tmp->block[i].full ==YAS) { // if selector exist here

               // if (tmp->block[i].atributes.getHead() == NULL) {
                   
                 //   return extra;
               // }
                return tmp->block[i].atributes;                // return current list of atributes for this section
            }
            i--; // get to the previous cell in the array
            if (i < 0) {
                i = SIZE_BLOCK - 1;
                tmp = tmp->previous; // go to previous node
            }
        }
        ListAtri emptyList;
        return emptyList;
    }
};