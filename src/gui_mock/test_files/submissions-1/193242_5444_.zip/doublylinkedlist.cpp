#define _CRT_SECURE_NO_WARNINGS
#define SIZE 600
#define SIZE_SMALL 200
#define SIZE_SUPER_SMALL 40
#define SIZE_BLOCK 6
#define R_CODE 0//for reader flag, reading code
#define R_COMMAND 1//for reader flag, reading commands
#define YAS 1 // cell in an array of blocks is full
#define NO 0 // cell in an array of blocks is empty
#define DELETED 2 // cell in an array of blocks was DELETED
#define PARTIALY 3 // array of blocks is partially filled
#include <iostream>
#include "string.h"
#include "list.h"
using namespace std;

int getSize(char c[]) {
	for (int i = 0; 100; i++) {
		if (c[i] == '\0') {
			return i;
		}
	}
}

void clearSupSmallArray(char arr[SIZE_SUPER_SMALL]) {

	for (int j = 0; j < SIZE_SUPER_SMALL; j++) {
		arr[j] = '\0';
	}
}
void clearSmallArray(char arr[SIZE_SMALL]) {
	for (int k = 0; k < SIZE_SMALL; k++) {// clearing the arrays
		arr[k] = NULL;
	}
}
void clearBigArray(char arr[SIZE]) {
	for (int k = 0; k < SIZE; k++) {// clearing the arrays
		arr[k] = '\0';
	}
}
ListAtri getAtributes(char c[], int* counterAtributes);
ListSelec getSelectors(char c[], ListAtri* listAtri, int* oneLineBlock, int* counter, int* counterAtributes) {

	ListSelec lSelec;
	char selec[SIZE][SIZE];
	char other[SIZE];
	int countSelectors = 0;
	int j = 0;
	int k = 0;
	int size = 0; // counts how big is c

	
		for (int i = 0; c[i] != '\0'; i++) { //how big is c?
			//if (c[i] != ' ') {
				size++;
			//}
			if (c[i] == '{') {// ommiting '{
				c[i] = ',';
				if (size == 1) {// when there is no selectors 
					cin.getline(c, 500, '}');
					*listAtri = getAtributes(c, counterAtributes);
					*oneLineBlock = YAS;
				}
				//if we have oneLineBlock -> read atributes
				else if ((c[i + 1] >= 'a' && c[i + 1] <= 'z') || c[i + 1] == ' ') {

					for (int p = i + 1; c[p] != '}'; p++) {
						other[k] = c[p];
						k++;
					}
					*listAtri = getAtributes(other, counterAtributes);
					c[i + 1] = '\0';
					*oneLineBlock = YAS;
				}
			}
		}

		countSelectors = 0;
		c[size] = ','; //we add coma at the end of c too make spliting by commas easier
		c[size + 1] = '\0'; // ending the array
		k = 0;
		for (int i = 0; c[i] != '\0'; i++) {

			if (c[i] != ',' && c[i] != ' ') {
				selec[j][k] = c[i];
				k++;
			}

			else if (c[i] == ',') {// making first list
				selec[j][k] = '\0';
				if (selec[j][0] != '\0' && selec[j][0] != '\t') { // not to add empty string
					countSelectors++;
					String s = String(selec[j]);
					lSelec.addLast(s);
					j++;
					k = 0;
				}

			}
		}
		*(counter) = countSelectors;
		//lSelec.printList();
		return lSelec;
	// the end of selectors
}
ListAtri getAtributes(char c[], int* counterAtributes) {

	ListAtri lAtri;
	char atr[100][100];
	char atriName[SIZE_SMALL];
	char atriValue[SIZE_SMALL];
	int k = 0;
	int j = 0;
	int size = 0;
	(*counterAtributes) = 0;
	size = getSize(c);
	c[size + 1] = ';'; // we add semicolon at the end of c too make spliting by semicolons easier
	c[size + 2] = '\0';

	for (int i = 0; c[i] != '\0'; i++) {


		if (c[i] != ';') {
			if (c[i] == '{' || c[i] == '\t' || c[i] == '\r') {  // skip white chars
				i++;
			}
			atr[j][k] = c[i];
			k++;
		}
		else {// making second list, end of previous atribute
			atr[j][k] = '\0';
			//here i have to split 1 row into 2 strings , name and value
			k = 0;

			int atriFlag = 0;
			int n = 0;
			int r = 0;

			clearSmallArray(atriName);
			clearSmallArray(atriValue);
			int l = 0;
			for (k = 0; atr[j][k] != '\0'; k++) {

				if (atriFlag == 0) { //getting name

					if (atr[j][l] == '\n') { // ommit endline
						l++;
					}
					atriName[k] = atr[j][l];
					if (atriName[k] == ':') { // split by :
						atriName[k] = '\0';
					}
				}
				if (atr[j][k] == ':' && atriFlag == 0) { // marking end of atribute name
					atriFlag = 1;
				}
				else if (atriFlag == 1) { // getting value

					if (atr[j][k] == '\n' || atr[j][k] == '\t' || atr[j][k] == '\r' || (n == 0 && atr[j][k] == ' ')) { // ommit space or /n
						k++;
					}
					atriValue[n] = atr[j][k];
					n++;
				}
				l++;
			}
			if (atriName[0] != '\0' && atriValue[0] != '\0') {
				//here add node
				String name = String(atriName);
				String value = String(atriValue); // stack around atriValue was corrupted

				// checking if there is existing atribute of this name
				if (lAtri.searchName(name) != 0) {
					lAtri.changeValue(name, value);

				}
				else { // this is new atribute
					lAtri.addLast(name, value); // add it to the list
					(*counterAtributes)++;
				}
				j++;
				k = 0;
			}
		}
	}
	return lAtri;
}

int convertNumber(char command[SIZE_SUPER_SMALL]) {

	int sectionNumber = 0;
	sectionNumber = int(command[0]) - (int('0')); // for one digit

	if (command[1] != '\0') {                          // if second digit
		int secondDigit = (int(command[1]) - (int('0')));
		sectionNumber = sectionNumber * 10 + secondDigit;
	}
	// do i need to do also for 3 digit?
	return sectionNumber;
}
DoubleNode* findNode(DoubleList* doubleList, int blockNumber) {

	int i = 0;
	DoubleNode* node = doubleList->getHead();
	int numBlocks = 0;
	while (node != NULL) {

		for (int j = 0; j < SIZE_BLOCK; j++) {
			if (node->block[j].full == YAS) {
				numBlocks++;
				if (numBlocks == blockNumber) {
					return node;
				}
			}
			if (numBlocks >= blockNumber) {
				return node;
			}
		}
		node = node->next;
	}
	return NULL; // blockNumber not found
}
int getIndex(int blockNumber, DoubleList* doubleList) {
	DoubleNode* doubleNode = doubleList->getHead();

	int i = 0;
	int gaps = 0, fullNumber = 0, omitted = 0;
	while (i + (fullNumber * SIZE_BLOCK - omitted) < blockNumber && doubleNode != NULL && doubleNode->block[i].full != NO) {// czy tu mniejsze rowne?

		if (doubleNode->block[i % SIZE_BLOCK].full == YAS) {
			i++;
		}
		else if (doubleNode->block[i % SIZE_BLOCK].full == PARTIALY) {
			gaps++;
			omitted++;
		}
		else if ((doubleNode->block[i % SIZE_BLOCK].full == DELETED)) {
			omitted++;
			i++;
		}
		if ((i % SIZE_BLOCK == 0 && doubleNode != NULL) || gaps == (SIZE_BLOCK - (i % SIZE_BLOCK))) {
			doubleNode = doubleNode->next;
			gaps = 0;
			i = 0;
			fullNumber++;
		}
	}
	return (i % SIZE_BLOCK);
}
void doCommand(char command[SIZE_SUPER_SMALL][SIZE_SUPER_SMALL], ListSelec* listSelec, Block block[], DoubleList* doubleList) {
	DoubleNode* doubleNode = doubleList->getHead();
	String first, second, third;
	first = command[0];
	second = command[1];
	third = command[2];
	ListAtri listAtri = doubleList->isSelector(first, doubleList); // list of atributes for selector z

	switch (command[1][0]) {
	case 'S': // selectors commands

		if (command[2][0] == '?') {
			//i,S,? - print the number of selectors for section number i (section and attribute numbers start from 1), if there is no such block, skip
			if (isdigit(command[0][0])) {

				int blockNumber = convertNumber(command[0]);

				int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks
				doubleNode = findNode(doubleList, blockNumber);
				if (cellIndex == 0) {
					cellIndex = 6;
				}
				if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS) {

					cout << first << "," << second << ',' << third << " == " << doubleNode->block[cellIndex - 1].selectorNumber << endl; // trzeba endl usunac?
				}
			}
			// z,S,? - print the total (for all blocks) number of occurrences of selector z. It can be 0;	
			else {
				ListSelec selectorList;
				String selectorName = command[0];
				int i = 0;
				int selectorNumber = 0;

				while (doubleNode != NULL && doubleNode->block[i].full != NO) { // till the end of doubleList		

					selectorNumber += doubleNode->block[i].selectors.searchName(selectorName); // add number off occurances

					i++;
					if (i >= SIZE_BLOCK) {
						doubleNode = doubleNode->next;   //go to next node	
						i = 0;
					}

				}
				cout << first << "," << second << ',' << third << " == " << selectorNumber << endl;
			}
		}
		//i,S,j - print the j - th selector for the i - th block(section and attribute numbers start from 1), if there is no section or selector, skip;
		else {
			int blockNumber = convertNumber(command[0]); // for ith block
			int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks    
			if (cellIndex == 0) {
				cellIndex = 1;
			}
			doubleNode = findNode(doubleList, blockNumber);

			int number = convertNumber(command[2]);
			if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS && !(doubleNode->block[cellIndex - 1].selectors.searchByNumber(number) == "")) {

				cout << first << "," << second << ',' << third << " == " << doubleNode->block[cellIndex - 1].selectors.searchByNumber(number) << endl;
			}
		}
		break;

	case 'A':
		//i,A,?-print the number of attributes for section number i, if there is no such block or section, skip;
		if (command[2][0] == '?') {
			if (isdigit(command[0][0])) {

				int blockNumber = convertNumber(command[0]);

				int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks
				doubleNode = findNode(doubleList, blockNumber);
				if (cellIndex == 0) {
					cellIndex = 6;
				}
				if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS) {

					cout << first << "," << second << ',' << third << " == " << doubleNode->block[cellIndex - 1].atributeNumber << endl; // trzeba endl usunac?
				}
			}
			//n,A,? -print the total(for all blocks) number of occurrences of attribute named n(duplicates should be removed when reading).It can be 0;
			else {

				ListAtri atriList;
				String atributeName = command[0];
				int i = 0;
				int atributeNumber = 0;

				while (doubleNode != NULL && doubleNode->block[i].full != NO) { // till the end of doubleList		

					atributeNumber += doubleNode->block[i].atributes.searchName(atributeName); // add number off occurances

					i++;
					if (i >= SIZE_BLOCK) {
						doubleNode = doubleNode->next;   //go to next node	
						i = 0;
					}

				}
				cout << first << "," << second << ',' << third << " == " << atributeNumber << endl;
			}
		}
		//i,A,n - print the value of the attribute with the name n for the i - th section, if there is no suchattribute, skip;
		else {

			ListAtri atriList;

			int blockNumber = convertNumber(command[0]);

			int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks
			doubleNode = findNode(doubleList, blockNumber);
			// w 25 full = 1432 costam
			if (cellIndex == 0) {
				cellIndex = 6;
			}
			if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS && !(doubleNode->block[cellIndex - 1].atributes.getValue(third) == "")) {

				cout << first << "," << second << ',' << third << " == " << doubleNode->block[cellIndex - 1].atributes.getValue(third) << endl;
			}
		}
		break;

	case 'E':
		//z, E, n - print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one.If there is no such attribute, skip;
		if (listAtri.searchName(third) > 0) { // if there is one atru=ibute named n

			cout << first << "," << second << ',' << third << " == " << listAtri.getValue(third) << endl;
		}
		break;
	case 'D':
		//i,D,* - remove the entire section number i (i.e., separators+attributes), after successful execution, print "deleted";
		if (command[2][0] == '*') {
			int blockNumber = convertNumber(command[0]);
			int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks
			doubleNode = findNode(doubleList, blockNumber);

			if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS) {

				doubleNode->block[cellIndex - 1].full = DELETED;
				doubleNode->block[cellIndex - 1].atributes.cut();
				cout << first << "," << second << ',' << third << " == deleted" << endl; // trzeba endl usunac?
			}
		}
		// i,D,n - remove the attribute named n from the i-th section, if the section becomes empty as a 
		// result of the operation, it should also be removed(along with any selectors), after successful execution, print "deleted"
		else {
			int blockNumber = convertNumber(command[0]);
			int cellIndex = getIndex(blockNumber, doubleList); // which cell from the array of blocks
			doubleNode = findNode(doubleList, blockNumber);

			if (doubleNode != NULL && doubleNode->block[cellIndex - 1].full == YAS && doubleNode->block[cellIndex-1].atributes.searchName(third)>0) {

				doubleNode->block[cellIndex - 1].atributes.removeAtri(third);
				doubleNode->block[cellIndex - 1].atributeNumber = doubleNode->block[cellIndex - 1].atributeNumber - 1 ;

				if (doubleNode->block[cellIndex - 1].atributes.getHead() == NULL) { // if there are no atributes - delete whole block
					doubleNode->block[cellIndex - 1].full = DELETED;

				}

				cout << first << "," << second << ',' << third << " == deleted" << endl;
			}
		}
		break;
	}
}
int countSections(DoubleList* doubleList) { // command "?"
	int i = 0, j = 0, omitted = 0; // i = index of node, j= index of blocks array
	int gaps = 0;
	DoubleNode* node = doubleList->getHead(); // sprawdzic 4 raxz

	while (node != NULL && node->block[j].full != NO && gaps < SIZE_BLOCK) {

		if (node->block[j].full == YAS) { // block is full
			j++;
		}
	    if (node->block[j].full == PARTIALY) {
			gaps++;
			omitted++;
		}
		else if (node->block[j].full == DELETED) {
			omitted++;
			j++;
		}
		if (j >= SIZE_BLOCK - 1 || gaps == SIZE_BLOCK - j) { // || gaps == SIZE_BLOCK - j - 1

			if (node != NULL) {
				node = node->next;
				j = 0;
				gaps = 0;
				i++;
			}

		}
	}
		return (j + (i * SIZE_BLOCK) - omitted); // return number of sections
}
void readCommand(char c[], ListSelec* listSelec, Block block[], DoubleList* doubleList) {

	int  size = 0; // czy musze usunac k
	int part = 0, data = 0;
	char command[3][SIZE_SUPER_SMALL];
	clearSupSmallArray(command[0]);
	clearSupSmallArray(command[1]);
	clearSupSmallArray(command[2]);

	while (cin) {

		cin.getline(c, 100, '\n');// getting one command
		if ((c[0] == '*') && (c[1] == '*')) {
			break;
		}
		else if (c[0] != '\0') {
			size = getSize(c);
			c[size] = ',';
			c[size + 1] = '\0';

			if (c[0] == '?') { // command "?"

				cout << "? == " << countSections(doubleList) << endl;
			}
			else {

				for (int p = 0; c[p] != '\0'; p++) { // extracting one command to other columns in 2D array

					if (c[p] != ',') { //reading first section of command  
						command[part][data] = c[p];
						data++;


						if (c[p + 1] == ',') { // switching to other section of one command 
							command[part][data] = '\0';// cos tu sie clearuje a nie ma tak byc
							part++;
							p++;// 
							data = 0;
							if (command[2][0] != '\0') {// command is finnished, do instruction
								//seperate by S, A, D and E commands
								doCommand(command, listSelec, block, doubleList);
								part = 0;
								clearSupSmallArray(command[0]);
								clearSupSmallArray(command[2]);

							}
						}
					}
				}
			}
		}
	}
}

int main() {
	ListAtri listAtri;
	ListSelec listSelec;
	Block block[SIZE_BLOCK];
	DoubleList lBloks;

	char c[SIZE];                    // pomocnicza, tylko do wpisywania, przechowalnia
	int oneLineBlock = 0;            // flag if there r selec and atri in 1 block
	int countSelectors = 0;
	int counterAtributes = 0;        // num of atributes in 1 block
	int i = 0;

	DoubleNode* currNode = new DoubleNode(block);

	while (cin) {

		// readlig the first line of code (selectors or ????)
		clearBigArray(c);
		cin.getline(c, 100, '\n');   // here read to { ot \n?

		// if we are in CSS-mode
		if (c[0] != '?' && c[0] != '\0') {
			if (c[0] != '\t' && c[1] != '\t') {
				ListSelec listSelec = getSelectors(c, &listAtri, &oneLineBlock, &countSelectors, &counterAtributes);

				if (oneLineBlock == NO) {
					clearBigArray(c);
					cin.getline(c, 600, '}'); // now c stores everything between {}
					listAtri = getAtributes(c, &counterAtributes);

				}
				currNode->block[i].selectors = listSelec;
				currNode->block[i].selectorNumber = countSelectors;
				currNode->block[i].atributes = listAtri;
				currNode->block[i].atributeNumber = counterAtributes;
				currNode->block[i].full = YAS;
				oneLineBlock = NO;
				i++;
			}
		}
		// if we are in command-mode
		else if (c[0] == '?') {
			// filing rest of the node woth PARTIALY in order not to stop iterrations in later functions

			if (i < SIZE_BLOCK && currNode != NULL) {
				int z = SIZE_BLOCK - 1;
				for (z; (currNode->block[z].full != YAS) && (z >= 0); z--) {
					currNode->block[z].full = PARTIALY;
				}
				if (currNode->block[0].full != PARTIALY) { // byc moze trzeba przestawic
					lBloks.addNode(currNode);
					currNode = new DoubleNode(block);
				}
			}
			i = 0;
			readCommand(c, &listSelec, block, &lBloks);
		}
		//adding new node of doubly linked list
		if (i >= SIZE_BLOCK && currNode != NULL) {
			//currNode = currNode->next;
			lBloks.addNode(currNode);
			currNode = new DoubleNode(block);
			i = 0;
		}
	}
	return 0;
}