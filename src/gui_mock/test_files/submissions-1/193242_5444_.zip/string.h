#pragma once
#pragma once
#include <iostream>
using namespace std;

// Class String
class String {
private:
    char* data; // wska�nik na tablic� znak�w
    size_t length=0; // d�ugo�� tablicy znak�w

public:
    // ... konstruktory, destruktor i inne metody ...

    // przeci��enie operatora przypisania
    String& operator=(const String& other) {
        if (this != &other) {
            delete[] data;
            length = other.length;
            data = new char[length + 1];
            for (size_t i = 0; i < length; i++) data[i] = other.data[i];
            data[length] = '\0';
        }
        return *this;
    }

    // przeci��enie operatora << do wypisywania obiektu String na strumie� wyj�ciowy
    friend std::ostream& operator<<(std::ostream& os, const String& str) {
        return os << str.data;
    }

    // przeci��enie operatora >> do wczytywania obiektu String ze strumienia wej�ciowego
    friend std::istream& operator>>(std::istream& is, String& str) {
        char buffer[4096];
        is >> buffer;
        str = buffer;
        return is;
    }
    bool operator==(const String& other) const {
        if (length != other.length) {
            return false;
        }
        for (size_t i = 0; i < length; i++) {
            if (data[i] != other.data[i]) {
                return false;
            }
        }
        return true;
    }

    String() { // konstruktor domy�lny
        data = NULL;
        length = 0;
    }

    String(const char* str) { // konstruktor przyjmuj�cy wska�nik na tablic� znak�w
        length = 0;
        while (str[length] != '\0') length++; // obliczenie d�ugo�ci tablicy
        data = new char[length + 1]; // alokacja pami�ci na tablic� znak�w
        for (size_t i = 0; i < length; i++) data[i] = str[i]; // kopiowanie znak�w z przekazanej tablicy
        data[length] = '\0'; // dodanie znaku ko�ca ci�gu
    }

    String(const String& other) { // konstruktor kopiuj�cy
        length = other.length;
        data = new char[length + 1];
        for (size_t i = 0; i < length; i++) data[i] = other.data[i];
        data[length] = '\0';
    }

    ~String() { // destruktor
        delete[] data;
    }

    size_t size() const { // zwraca d�ugo�� ci�gu
        return length;
    }

    void clear() {// czy�ci ci�g
        length = 0;
        if (data != NULL) {
            delete[] data;
            data = NULL;
        }
    }

};