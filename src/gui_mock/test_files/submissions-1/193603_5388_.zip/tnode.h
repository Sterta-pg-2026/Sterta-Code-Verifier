//
// Created by Karol Zwierz on 27/03/2023.
//

#pragma once

#include <iostream>

using namespace std;

template <size_t t, typename T> class TNode {
public:
    T data [t];
    T **effectiveData;
    TNode <t, T> *prev;
    TNode <t, T> *next;
    size_t occupied;
    size_t data_size;

public:

    TNode() : prev(nullptr), next(nullptr), occupied(0), effectiveData(nullptr), data_size(0) {}

    TNode* getNext() { return next; }

    TNode* getPrev() { return prev; }

    size_t getOccupied () { return occupied; }

    size_t getDataSize () { return data_size; }

    void setNext( TNode <t, T> *pointer ) { next = pointer; }

    void setPrev( TNode <t, T> *pointer ) { prev = pointer; }

    void removeData (size_t index) {
        if (data_size > 0 && occupied > 0) {
            T **temp = new T*[occupied-1];
            if (index == 0) {
                for (size_t i = 0 ; i < occupied-1 ; i++) {
                    temp[i] = effectiveData[i+1];
                }
                delete [] effectiveData;
                effectiveData = temp;
                occupied--;
                return;
            }
            occupied--;
            size_t correction = 0;
            for (size_t i = 0 ; i < occupied ; i++) {
                if(i == index) {
                    correction = 1;
                }
                temp[i] = effectiveData[i+correction];
            }
            effectiveData = temp;
        }
    }

    void updateData (size_t index, T new_data) {
        *effectiveData[index] = new_data;
    }

    void popData () {
        if ( data_size > 0 && occupied > 0 ) {
            //data[occupied] = NULL;
            occupied--;
            T **temp = new T*[occupied];
            for (size_t i = 0 ; i < occupied ; i++) {
                temp[i] = effectiveData[i];
            }
            effectiveData = temp;
        }
    }

    void pushData(T item) {
        if (data_size < t && occupied < t) {
            data[data_size] = item;
            data_size++;
            occupied++;

            T **temp = new T*[occupied];
            for (size_t i = 0; i < occupied - 1; i++) {
                temp[i] = effectiveData[i];
            }
            temp[occupied - 1] = &(data[data_size - 1]);
            delete[] effectiveData;
            effectiveData = temp;
        }
    }

    T& operator[](size_t index) const {
        return *(effectiveData[index]);
    }

    TNode& operator = (const TNode& other) {
        if (this == &other) {
            return *this;
        }
        occupied = other.occupied;
        data_size = other.data_size;
        for (size_t i = 0 ; i < data_size ; i++) {
            data[i] = other.data[i];
        }
        for (size_t i = 0 ; i < other.occupied ; i++) {
            effectiveData[i] = other.effectiveData[i];
        }
        return *this;
    }

    bool operator == ( TNode other ){
        if (other.getOccupied() != occupied) return false;
        for (int i = 0 ; i < occupied ; i++) {
            if ( !( *(other.effectiveData[i]) == *(effectiveData[i]) ) ) return false;
        }
        return true;
    }

    friend ostream& operator << (ostream& os, const TNode<t, T> node)
    {
        for (size_t i = 0; i < node.occupied ; i++) {
            os << *(node.effectiveData[i]) << " ";
        }
        return os;
    }

    ~TNode() {
        if (data != nullptr && effectiveData != nullptr) {
            delete [] data;
            delete [] effectiveData;
        }
    }
};

