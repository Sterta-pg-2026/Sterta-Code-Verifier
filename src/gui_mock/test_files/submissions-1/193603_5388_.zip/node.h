//
// Created by Karol Zwierz on 24/03/2023.
//

#pragma once

#include <iostream>

using namespace std;

template <typename T> class Node {
public:
    T data;
    Node <T> *prev;
    Node <T> *next;
public:

    Node() : prev(nullptr), next(nullptr) {  }

    Node* getNext() {
        return this->next;
    }

    Node* getPrev() {
        return this->prev;
    }

    T getData() {
        return this->data;
    }

    void setNext( Node <T> *pointer ) {
        this->next = pointer;
    }

    void setPrev( Node <T> *pointer ) {
        this->prev = pointer;
    }

    void setData( T new_data ) {
        this->data = new_data;
    }

    friend ostream& operator<<(ostream& os, const Node& node) {
        os << node.data;
        return os;
    }

    Node& operator=(const Node& other) {
        if (this == &other) {
            return *this;
        }
        data = other.data;

        return *this;
    }

    bool operator == ( Node other ){
        return other.data == data;
    }

    Node &operator + ( Node other ) {
        Node temp = other;
        temp.data += other.data;
        return *temp;
    }

    void operator += ( T new_data ) {
        data += new_data;
    }

    void operator += ( Node other ) {
        data += other.data;
    }

    ~Node() {
        if (data != nullptr) {
            delete [] data;
        }
    }
};
