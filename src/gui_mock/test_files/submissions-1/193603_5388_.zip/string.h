//
// Created by Karol Zwierz on 23/03/2023.
//

#ifndef PROJEKT1_STRING_H
#define PROJEKT1_STRING_H

#include "vector.h"
#include <cmath>

class String : public Vector<char> {

    using Vector<char>::Vector;

public:
    void trim() {
        int start = 0;
        int end = current_length - 1;
        while (start <= end && (int)buffer[start] <= 32) {
            start++;
        }
        while (end >= start && (int)buffer[end] <= 32) {
            end--;
        }
        String temp;
        for (int i = start; i <= end; i++) {
            temp.push(buffer[i]);
        }
        buffer = temp.buffer;
        current_length = temp.current_length;
    }


    bool isNumber() {
        for(int i = 0; i < current_length; i++) {
            if ( !(buffer[i] >= 48 && buffer[i] <= 57) ) return false;
        }
        return true;
    }

    int strToInt() {
        int sum = 0;
        for(int i = current_length-1; i >= 0; i--) {
            int digit = ((int)buffer[i]-48);
            int subsum = pow(10,(current_length-i-1))*digit;
            sum += subsum;
        }
        return sum;
    }

    bool operator == ( String other ) {
        if (other.size() != size()) return false;
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other.buffer[i] != buffer[i] ) return false;
        }
        return true;
    }

    bool operator == ( char *other ) {
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other[i] != buffer[i] ) return false;
        }
        return true;
    }

    bool operator != ( String other ) {
        if (other.size() != size()) return true;
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other.buffer[i] != buffer[i] ) return true;
        }
        return false;
    }

    bool operator != ( char *other ) {
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other[i] != buffer[i] ) return true;
        }
        return false;
    }

    friend ostream& operator <<(ostream& os, const String& string) {
        for (size_t i = 0; i < string.current_length; i++) {
            os << string.buffer[i];
        }
        return os;
    }

    friend istream& operator >>(istream& is, String& string) {
        char temp;
        string.clear();
        while (is.get(temp)) {
            if (temp == '\n') {
                break;
            }
            string.push(temp);
        }
        string.trim();
        return is;
    }
};


#endif //PROJEKT1_STRING_H
