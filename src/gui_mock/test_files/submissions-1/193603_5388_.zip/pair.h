//
// Created by Karol Zwierz on 26/03/2023.
//

#pragma once

#include "string.h"

template <typename T1, typename T2> class Pair {
public:
    T1 name;
    T2 value;
public:
    Pair() {}
    Pair(T1 new_name) {
        name = new_name;
    }
    Pair(T1 new_name, T2 new_value) {
        name = new_name;
        value = new_value;
    }
    void setName( T1 new_name ) {
        name = new_name;
    }
    void setValue( T2 new_value ) {
        value = new_value;
    }
    T1& getName( ) {
        return name;
    }
    T2& getValue( ) {
        return value;
    }

    friend ostream& operator<<(ostream& os, const Pair<T1,T2> pair) {
        os << pair.name << " " << pair.value << endl;
        return os;
    }

    ~Pair() {}
};
