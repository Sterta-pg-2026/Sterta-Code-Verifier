//
// Created by Karol Zwierz on 23/03/2023.
//

#pragma once

#include <iostream>
#include "string.h"
#include "list.h"
#include "tlist.h"
#include "vector.h"
#include "pair.h"
#include <stdio.h>

#define T_NUMBER    17

using namespace std;

class Parser {
public:

    static void start() {

        TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > list;

        bool isExit = false;

        while ( !isExit ) {
            String css = getCSS();
            listifyCSS( list , css );
            css.clear();
            //cout << list;
            List < List < String > > cmd = getCommands( isExit );
            //cout << cmd;
            executeCommands(list, cmd);
        }
    }

    static String getCSS() {
        char current_key;
        String buffer;
        String four(4);
        int index = 0;
        do {
            current_key = getchar();
            four[index%4] = current_key;
            if(current_key != '?' && ( (int)current_key >= 32 || (int)current_key == 10 ) && (int)current_key < 128 ) buffer.push(current_key);
            index++;
        } while(!(four == String("????") && current_key != '\xff' && (int)current_key != EOF));
        return buffer;
    }

    static void listifyCSS( TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > &css_list, String css ) {
        String name;
        String value;
        List<String> list;
        bool selector_search = true;
        bool attribute_search = false;
        bool value_search = false;
        int selector_index = 0;
        int attribute_index = 0;

        Pair < List <String>, List < Pair < String, String > > > selector;

        for ( int i = 0 ; i < css.current_length ; i++ )
        {
            if ( selector_search ) {
                if ( css[i] == '{' ) {
                    if( name.current_length != 0 )
                    {
                        name.trim();
                        Node < String > *node = selector.name.getFirst();
                        size_t indexForDeletion = -1;
                        for ( int k = 0 ; node != nullptr ; k++ )  {
                            String current_name = node->getData();
                            if( current_name == name ) indexForDeletion = k;
                            if (node != nullptr) node = (*node).getNext();
                        }
                        if ( indexForDeletion != -1 ) {
                            selector.name.remove( indexForDeletion );
                        }
                        selector.name.push(name);
                        name = String("");
                    }
                    else if (name.current_length == 0)
                    {
                        selector.name.push("");
                    }
                    selector_search = false;
                    attribute_search = true;
                    selector_index++;
                    i++;
                }
                else if ( css[i] == ',') {
                    name.trim();
                    //list.push(name);
                    Node < String > *node = selector.name.getFirst();
                    size_t indexForDeletion = -1;
                    for ( int k = 0 ; node != nullptr ; k++ )  {
                        String current_name = node->getData();
                        if( current_name == name ) indexForDeletion = k;
                        if (node != nullptr) node = (*node).getNext();
                    }
                    if ( indexForDeletion != -1 ) {
                        selector.name.remove( indexForDeletion );
                    }
                    selector.name.push(name);
                    name = String("");
                    //i++;
                } else if( !(css[i] == ' ' && name.size() == 0) && !( css[i] == ' ' && ( css[i+1] == ' ' || css[i+1] == ',' || css[i+1] == '{' ) ) && css[i] != '\n' ) {
                    name.push(css[i]);
                }
            }

            if ( attribute_search )
            {
                if ( css[i] == '}' ) {
                    selector_search = true;
                    attribute_search = false;
                    if(selector.value.size() > 0) css_list.push(selector);
                    selector = {};
                    attribute_index = 0;
                }
                else if ( css[i] == ':' ) {
                    if( name.current_length != 0 )
                    {
                        name.trim();
                        list.push(name);
                    }
                    attribute_search = false;
                    value_search = true;
                    i++;
                    if ( css[i] <= ' ') i++;
                } else if( css[i] > ' ' && css[i] != '\n' ) {
                    name.push(css[i]);
                }
            }
            if ( value_search )
            {
                if ( css[i] == ';' || css[i] == '}' ) {
                    if( value.current_length != 0 )
                    {
                        value.trim();
                        list.push(value);
                        Pair <String , String> temp (name, value);
                        Node < Pair <String , String> > *node = selector.value.getFirst();
                        size_t indexForDeletion = -1;
                        for ( int k = 0 ; node != nullptr ; k++ )  {
                            String current_name = node->getData().getName();
                            if( current_name == name ) indexForDeletion = k;
                            if (node != nullptr) node = (*node).getNext();
                        }
                        if ( indexForDeletion != -1 ) {
                            selector.value.remove( indexForDeletion );
                        }
                        selector.value.push(temp);
                        name = String("");
                        value = String("");
                    }
                    attribute_search = true;
                    value_search = false;
                    if (css[i] == '}') i--;
                    attribute_index++;
                } else {
                    char key = css[i];
                    value.push(key);
                }
            }
        }
    }

    static List < List < String > > getCommands ( bool &isExit ) {
        List < List < String > > buffer;
        String four(4);
        String temp = "";
        List <String> commands;
        int commas = 0;

        String line = "";
        String endMarker("****");

        while (!cin.eof()) {
            cin >> line;
            if (line == endMarker || cin.eof()) {
                break;
            }
            for (int i = 0 ; i < line.current_length ; i++) {
                temp.push(line[i]);
            }
            temp.push('\n');
        }

        if ( cin.eof() ) {
            temp.push('\n');
            for (int i = 0 ; i < line.current_length ; i++) {
                temp.push(line[i]);
            }
            temp.push('\n');
            isExit = true;
        }

        String command_part;

        for (int i = 0 ; i < temp.current_length+1 ; ) {
            do {
                do {
                    char current_char = temp[i];
                    if(current_char != '\n' && current_char != '\xff') command_part.push(current_char);
                    i++;
                } while (!(temp[i] == '\n' || temp[i] == ',' || temp[i] == '\0' || temp[i] == '\xff') /*&& i < temp.current_length+1*/);
                commands.push(command_part);
                command_part = "";
                if(temp[i] == ',') commas++;
                if(temp[i] != '\n') i++;
            } while (temp[i] != '\n' && temp[i] != '\0' && temp[i] != '\xff' && !(temp[i] == ',' && commas > 2));
            buffer.push((commands));
            commands.clear();
            commas = 0;
            i++;
        }

        return buffer;
    }

    static void executeCommands( TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > & css_list, List < List <String> > commands ) {
        for (int k = 0 ; k < commands.size() ; k++ ) {
            List <String> current_command;
            current_command = commands[k].getData();
            if ( current_command.size() == 1 && current_command[0].getData().size() == 1 && current_command[0].getData()[0] == '?' ) print_number_of_all_sections( css_list );
            if ( current_command.size() == 3 ) {
                int number_i = 0, number_j = 0; // i ; type ; j
                String name_n = "", name_z = "", type = current_command[1].getData(); // n ; type ; z
                if ( current_command[0].getData().isNumber() && !current_command[2].getData().isNumber() ) {
                    // number ; str ; str = i ; X ; z
                    number_i = current_command[0].getData().strToInt();
                    name_z = current_command[2].getData();
                    if ( type == "S" && name_z == "?" ) print_number_of_selectors(number_i, css_list);
                    if ( type == "A" && name_z == "?" ) print_number_of_attributes(number_i, css_list);
                    if ( type == "A" && !(name_z == "?") ) print_value_of_attribute(number_i, name_z, css_list);
                    if ( type == "D" && name_z == "*" ) print_delete_section(number_i, css_list);
                    if ( type == "D" && !(name_z == "*") ) print_delete_attribute(number_i, name_z, css_list);
                }
                if ( current_command[0].getData().isNumber() && current_command[2].getData().isNumber() ) {
                    // number ; str ; number = i ; X ; j
                    number_i = current_command[0].getData().strToInt();
                    number_j = current_command[2].getData().strToInt();
                    if ( type == "S" ) print_selector(number_i, number_j, css_list);
                }
                if ( !current_command[0].getData().isNumber() && !current_command[2].getData().isNumber() ) {
                    // str ; str ; str = n ; X ; z
                    name_n = current_command[0].getData();
                    name_z = current_command[2].getData();
                    if ( type == "A" && name_z == "?" ) print_number_of_attribute_occurencies(name_n, css_list);
                    if ( type == "S" && name_z == "?" ) print_number_of_selector_occurencies(name_n, css_list);
                    if ( type == "E" ) print_attribute_value(name_n, name_z, css_list);
                }
            }
        }
    }

    static void print_number_of_all_sections ( TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list ) {
        cout << "? == " << css_list.size() << endl;
    }

    /// IMPORTANT: MAY NOT SKIP WHEN THE INDEX IS FAULTY
    static void print_number_of_selectors (int i, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        size_t sum = 0;
        if(css_list.getFirst() != nullptr && i-1 >= 0 && i-1 < css_list.size()) {
            Pair < List <String>, List < Pair < String, String > > > section = css_list[i-1];
            sum = section.name.size();
            if ( sum == 1 && section.name[0].getData() == "" ) sum = 0;
            cout << i <<",S,? == " << sum << endl;
        }
    }
    static void print_number_of_attributes (int i, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        size_t sum = 0;
        if(css_list.getFirst() != nullptr && i-1 >= 0 && i-1 < css_list.size()) {
            Pair < List <String>, List < Pair < String, String > > > section = css_list[i-1];
            sum = section.value.size();
            cout << i <<",A,? == " << sum << endl;
        }
    }
    /**
     * Prints selector (j) for section (i)
     */
    static void print_selector (int i, int j, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        if(css_list.getFirst() != nullptr && i-1 >= 0 && i-1 < css_list.size()) {
            Pair < List <String>, List < Pair < String, String > > > section = css_list[i-1];
            if ( j-1 < section.getName().size() && section.name[j-1].getData() != "" ) cout << i <<",S," << j << " == " << section.name[j-1] << endl;
        }
    }
    /**
     * Prints value of attribute (n) in section (i)
     */
    static void print_value_of_attribute (int i, String n, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        if(css_list.getFirst() != nullptr && i-1 >= 0 && i-1 < css_list.size()) {
            Pair < List <String>, List < Pair < String, String > > > section = css_list[i-1];
            String value = "";
            for ( int k = 0 ; k < section.value.size() ; k++ ) if( section.value[k].getData().name == n ) value = section.value[k].getData().value;
            if(value != "") cout << i <<",A," << n << " == " << value << endl;
        }
    }
    static void print_number_of_attribute_occurencies (String n, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        if(css_list.getFirst() != nullptr) {
            int counter = 0;
            for ( int k = 0 ; k < css_list.size() ; k ++ ) {
                for ( int p = 0 ; p < css_list[k].value.size() ; p++ ) {
                    if ( css_list[k].value[p].getData().name == n ) {
                        counter++;
                        break;
                    }
                }
            }
            cout << n <<",A,? == " << counter << endl;
        }
    }
    static void print_number_of_selector_occurencies (String z, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list) {
        if(css_list.getFirst() != nullptr) {
            int counter = 0;
            for ( int k = 0 ; k < css_list.size() ; k ++ ) {
                for ( int p = 0 ; p < css_list[k].name.size() ; p++ ) {
                    if ( css_list[k].name[p].getData() == z ) counter++;
                }
            }
            cout << z <<",S,? == " << counter << endl;
        }
    }
    /**
     * Prints value of attribute (z) for selector (n)
     */
    static void print_attribute_value ( String n, String z, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > css_list ) {
        if(css_list.getFirst() == nullptr) return;
        String value = "";
        for ( int i = css_list.size()-1 ; i >= 0 ; i-- ) {
            for ( int j = 0 ; j < css_list[i].name.size() ; j++ ) {
                String current_selector = css_list[i].name[j].getData();
                if ( current_selector == n ) {
                    for ( int k = 0 ; k < css_list[i].value.size() ; k++ ) {
                        String current_attribute = css_list[i].value[k].getData().name;
                        if ( current_attribute == z ) { value = css_list[i].value[k].getData().value; break; }
                    }
                    if (value != "") break;
                }
                if (value != "") break;
            }
            if (value != "") break;
        }
        if ( value != "" ) cout << n <<",E," << z << " == " << value << endl;
    }
    static void print_delete_section ( int i, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > &css_list ) {
        if(css_list.getFirst() == nullptr) return;
        if( i-1 >= 0 && i-1 < css_list.size() ) {
            css_list.remove(i-1);
            cout << i <<",D,* == deleted" << endl;
        }
    }
    /**
     * Deletes attribute (n) from section (i)
     */
    static void print_delete_attribute ( int i, String n, TList < T_NUMBER, Pair < List <String>, List < Pair < String, String > > > > &css_list ) {
        if(css_list.getFirst() == nullptr) return;
        if( i-1 >= 0 && i-1 < css_list.size() ) {
            int index = -1;
            for ( int k = 0 ; k < css_list[i-1].value.size() ; k++ ) {
                if ( css_list[i-1].value[k].getData().name == n ) { index = k; break; }
            }
            if ( index != -1 ) {
                css_list[i-1].getValue().remove(index);
                size_t size = css_list[i-1].getValue().size();
                if ( size == 0 ) css_list.remove(i-1);
                cout << i <<",D," << n << " == deleted" << endl;
            }
        }
    }
};
