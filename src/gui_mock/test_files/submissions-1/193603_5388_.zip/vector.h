//
// Created by Karol Zwierz on 22/03/2023.
//

#pragma once

#include <iostream>

#define VECTOR_INIT_SIZE    16

using namespace std;

template< typename T > class Vector {
public:
    size_t current_length;
    size_t max_length;
    T *buffer;
public:
    Vector() {
        current_length = 0;
        max_length = VECTOR_INIT_SIZE;
        buffer = new T[max_length];
    }
    explicit Vector( size_t size ) {
        current_length = size;
        max_length = 2 * size;
        buffer = new T [size];
    }

    // vector <T> a = b;
    Vector(const Vector& other) : buffer(other.buffer), max_length(other.max_length), current_length(other.current_length) {}

    // vector <T> a = move(b);
    //Vector(Vector&& other)  noexcept : buffer(move(other.buffer)), max_length(move(other.max_length)), current_length(move(other.current_length)) {}

    // Vector <T> a = "abc"
    Vector (const T* str) : Vector() {
        if (buffer != nullptr) delete[] buffer;
        if (str) {
            int length = 0;
            while (str[length]) {
                ++length;
            }
            current_length = length;
            max_length = length * 2;
            buffer = new char[current_length];
            for (int i = 0; i < current_length; i++) {
                buffer[i] = str[i];
            }
        } else {
            buffer = nullptr;
        }
    }
    // Vector <T> a = {1,2,3}
    Vector (initializer_list<T> newBuffer) : Vector() {
        if (buffer != nullptr) delete[] buffer;
        current_length = newBuffer.size();
        max_length = current_length * 2;
        buffer = new T[max_length];
        copy(newBuffer.begin(), newBuffer.end(), buffer);
    }

    const size_t size () { return current_length; }

    // a = "abc"
    Vector& operator=(const T* str) {
        if (buffer) {
            delete[] buffer;
        }
        if (str) {
            int length = 0;
            while (str[length]) {
                ++length;
            }
            current_length = length;
            max_length = length * 2;
            buffer = new char[current_length];
            for (int i = 0; i < current_length; i++) {
                buffer[i] = str[i];
            }
        } else {
            buffer = nullptr;
        }
        return *this;
    }
    // a = {1,2,3}
    Vector& operator=(initializer_list<T> newBuffer) {
        if (buffer == newBuffer.begin()) {
            return *this;
        }
        //if(newBuffer == nullptr) { delete[] buffer; return; }
        current_length = newBuffer.size();
        max_length = current_length * 2;
        buffer = new T[max_length];
        copy(newBuffer.begin(), newBuffer.end(), buffer);
        return *this;
    }
    // Vector <T> a = b
    Vector& operator=(const Vector& other) {
        if (this == &other) {
            return *this;
        }
        //if(other.buffer == nullptr) { delete[] buffer; return; }
        buffer = new T [other.max_length];
        max_length = other.max_length;
        current_length = other.current_length;
        for (std::size_t i = 0; i < current_length; ++i) {
            buffer[i] = other.buffer[i];
        }
        return *this;
    }

    bool operator == ( Vector &other ) {
        if (other.size() != size()) return false;
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other.buffer[i] != buffer[i] ) return false;
        }
        return true;
    }

    bool operator == ( T *other ) {
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other[i] != buffer[i] ) return false;
        }
        return true;
    }

    bool operator != ( Vector &other ) {
        if (other.size() != size()) return true;
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other.buffer[i] != buffer[i] ) return true;
        }
        return false;
    }

    bool operator != ( T *other ) {
        for (size_t i = 0 ; i < size() ; i++ ){
            if( other[i] != buffer[i] ) return true;
        }
        return false;
    }

    void clear () {
        delete [] buffer;
        current_length = 0;
        max_length = VECTOR_INIT_SIZE;
        buffer = new T [max_length];
    }

    /*void push( const T item ){
        if ( max_length == 0 ) max_length = VECTOR_INIT_SIZE;
        if( current_length < max_length && max_length != 0 )
        {
            buffer[current_length] = item;
            current_length++;
        }
        else
        {
            max_length = current_length*2;
            T *temp = new T[max_length];
            for ( size_t i = 0 ; i < current_length ; i++ ) {
                temp[i] = buffer[i];
            }
            temp[current_length] = item;
            buffer = new T[current_length + 1];
            for ( size_t i = 0 ; i < current_length + 1 ; i++ ) {
                buffer[i] = temp[i];
            }
            delete[] temp;
            current_length++;
        }
    }*/

    void push(const T item) {
        if (current_length >= max_length) {
            max_length = max_length == 0 ? VECTOR_INIT_SIZE : max_length * 2;
            T* temp = new T[max_length];
            for (size_t i = 0; i < current_length; i++) {
                temp[i] = buffer[i];
            }
            delete[] buffer;
            buffer = temp;
        }
        buffer[current_length++] = item;
    }

    friend ostream& operator<<(ostream& os, const Vector& vector) {
        os << "[";
        for ( size_t i = 0 ; i < vector.current_length ; i++ )
        {
            os << vector.buffer[i];
            if (i != vector.current_length-1) os << ",";
        }
        os << "]";
        return os;
    }
    virtual ostream& print(ostream& os) const {
        os << "[";
        for (size_t i = 0; i < current_length; i++) {
            os << buffer[i];
            if (i != current_length - 1) {
                os << ",";
            }
        }
        os << "]";
        return os;
    }
    friend istream& operator>>(istream& input, Vector<T>& vector) {
        T item;
        while (input >> item) {
            vector.push(item);
        }
        return input;
    }
    T& operator[](size_t i) const {
        return buffer[i];
    }
    ~Vector() {}
};

