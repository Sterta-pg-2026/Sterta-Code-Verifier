//
// Created by Karol Zwierz on 24/03/2023.
//

#pragma once

#include "node.h"
#include <iostream>

using namespace std;

template <typename T> class List {
    Node<T> *first;
    Node<T> *last;
    int l;

public:

    List() : first(nullptr), last(nullptr), l(0) {}

    void setFirst(Node <T> *pointer) {
        this->first = pointer;
    }

    void setLast(Node <T> *pointer) {
        this->last = pointer;
    }

    void setSize( int s ) {
        l = s;
    }

    Node <T> *getFirst() {
        return first;
    }

    Node <T> *getLast() {
        return last;
    }

    void clear() {
        this->first = nullptr;
        this->last = nullptr;
        this->l = 0;
    }

    void push(T data)
    {
        Node <T> *node = new Node <T> ();
        (*node).setData(data);
        l++;
        if (first == nullptr && last == nullptr) {
            setFirst(node);
            setLast(node);
        } else {
            (*node).setPrev(last);
            (*node).setNext(nullptr);
            (*node).getPrev()->setNext(node);
            setLast(node);
        }
    }

    void pop()
    {
        if(l != 0) {
            if((*last).getPrev() != nullptr) {
                (*last).getPrev()->setNext(nullptr);
                Node <T> *temp = (*last).getPrev();
                last = temp;
                l--;
            } else {
                first = nullptr;
                last = nullptr;
                l--;
            }
        }
    }

    void remove( int index )
    {
        if(l != 0 && index >= 0 && index < l) {
            if (index == 0 && size() == 1) {
                first = nullptr;
                last = nullptr;
                l=0;
                return;
            }
            setSize(l-1);
            Node<T> *node = first;
            for (int i = 0; node != nullptr && i != index; i++) node = (*node).getNext();
            if (node == last || node == nullptr) {
                this->pop();
                return;
            } else if (node == first) {
                setFirst((*node).getNext());
            }
            if ((*node).getPrev() != nullptr) (*node).getPrev()->setNext((*node).getNext());
            if ((*node).getNext() != nullptr) (*node).getNext()->setPrev((*node).getPrev());
        }
    }

    size_t calculateSize() {
        size_t sum = 0;
        Node <T> * node = first;
        while (node != nullptr) {
            sum++;
            node = node->getNext();
        }
        setSize(sum);
        return sum;
    }

    size_t size() {
        return l;
    }

    /**
     * Inserts on the position
     * @param index
     */
    void insert( int index, const T data )
    {
        Node <T> *node = first;
        Node <T> *new_node = new Node <T> ();
        (*new_node).setData(data);
        l++;
        if ( index == 0 ) {
            (new_node)->setPrev(nullptr);
            (new_node)->setNext(first);
            first->setPrev(new_node);
            setFirst(new_node);
            return;
        }
        for ( int i = 0 ; node != nullptr && i != index-1 ; i++ ) node = (*node).getNext();
        if ( node == last || node == nullptr ) {
            push(data);
            return;
        } else if ( node != first ) {
            (new_node)->setPrev(node);
            (new_node)->setNext((*node).getNext());
            (*node).getNext()->setPrev(new_node);
            node->setNext(new_node);
            return;
        }
    }

    /**
     * Updates on the position
     * @param index
     */
    void update( int index, const T data )
    {
        Node <T> *node = first;

        if ( index == 0 ) {
            first->setData(data);
            return;
        }
        for ( int i = 0 ; node != nullptr && i != index ; i++ ) node = (*node).getNext();
        if ( node == nullptr ) {
            push(data);
            return;
        } else if ( node != first ) {
            node->setData(data);
            return;
        }
    }

    void operator += (T data) {
        push(data);
    }

    Node <T> & operator[](int index) const {
        Node <T> *node = first;
        for ( int i = 0 ; node != nullptr && i != index ; i++ ) node = (*node).getNext();
        return *node;
    }

    friend ostream& operator<<(ostream& os, const List<T> list)
    {
        Node <T> *node = list.first;
        //os << "Forward" << endl;
        while (node != nullptr) {
            os << (*node) << " ";
            node = (*node).getNext();
        }
        /*Node <T> *node2 = list.last;
        os << "Backward" << endl;
        while (node2 != nullptr) {
            os << (*node2) << " ";
            node2 = (*node2).getPrev();
        }*/
        return os;
    }
    ~List () {}
};