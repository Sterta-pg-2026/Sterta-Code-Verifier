//
// Created by Karol Zwierz on 27/03/2023.
//

# pragma once

#include "tnode.h"
#include <iostream>
#include <cmath>

using namespace std;

template <size_t t, typename T> class TList {
    TNode<t, T> *first;
    TNode<t, T> *last;

public:

    TList() : first(nullptr), last(nullptr) {}

    void setFirst(TNode <t, T> *pointer) {
        this->first = pointer;
    }

    void setLast(TNode <t, T> *pointer) {
        this->last = pointer;
    }

    TNode <t,T> * getFirst() {
        return first;
    }

    TNode <t,T> * getLast() {
        return last;
    }

    void clear() {
        this->first = nullptr;
        this->last = nullptr;
    }

    void push(T data) {
        if( last == nullptr && first == nullptr ) pushTNode(data);
        else if( (*last).getDataSize() < t ) (*last).pushData(data);
        else pushTNode(data);
    }

    void pop() {
        if( last == nullptr && first == nullptr ) return;
        if( (*last).getOccupied() > 0 ) (*last).popData();
        else popTNode();
    }

    void remove(int index) {
        if (first == nullptr || index >= size()) {
            return;
        }
        TNode<t, T> *node = first;
        size_t nodeIndex = 0;
        while (node != nullptr && index >= node->getOccupied()) {
            index -= node->getOccupied();
            nodeIndex++;
            node = node->getNext();
        }
        if (node == nullptr) {
            return;
        }
        node->removeData(index);
        if (node->getOccupied() == 0) {
            removeNode(nodeIndex);
        }
    }

    size_t size() {
        size_t i = 0;
        TNode <t, T> *node = this->first;
        while (node != nullptr) {
            i += node->getOccupied();
            node = node->getNext();
        }
        return i;
    }

    T& operator[](size_t index) const {

        TNode <t, T> *node = first;
        int i = 0;
        size_t occupiedSum = first->getOccupied();
        if ( occupiedSum <= index ) {
            for ( ; node != nullptr && occupiedSum <= index ; i++ ) {
                node = node->getNext();
                occupiedSum += node->getOccupied();
            }
        }
        occupiedSum -= node->getOccupied();

        return (*node)[index - occupiedSum];
    }

    friend ostream& operator<<(ostream& os, const TList<t, T> list)
    {
        TNode <t, T> *node = list.first;
        while (node != nullptr) {
            os << (*node) << " ";
            node = (*node).getNext();
        }
        return os;
    }
    ~TList () {}
private:

    void pushTNode(T data)
    {
        TNode <t, T> *node = new TNode <t, T> ();
        (*node).pushData(data);

        if (first == nullptr && last == nullptr) {
            setFirst(node);
            setLast(node);
        } else {
            (*node).setPrev(last);
            (*node).setNext(nullptr);
            (*node).getPrev()->setNext(node);
            setLast(node);
        }
    }

    void popTNode() {
        if((*last).getPrev() != nullptr) {
            (*last).getPrev()->setNext(nullptr);
            TNode <t, T> *temp = (*last).getPrev();
            last = temp;
        } else {
            first = nullptr;
            last = nullptr;
        }
    }

    void removeNode( int index )
    {
        TNode <t, T> *node = first;
        if ( node != nullptr ) {
            for ( int i = 0 ; node != nullptr && i != index ; i++ ) node = (*node).getNext();
            if(node == last || node == nullptr){
                popTNode();
                return;
            } else if (node == first) {
                setFirst((*node).getNext());
            }
            if((*node).getPrev() != nullptr) (*node).getPrev()->setNext((*node).getNext());
            if((*node).getNext() != nullptr) (*node).getNext()->setPrev((*node).getPrev());
        }
    }
};

