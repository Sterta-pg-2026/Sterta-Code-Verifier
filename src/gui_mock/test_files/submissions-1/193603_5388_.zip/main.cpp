#include "parser.h"

using namespace std;

int main() {

    Parser::start();

    return 0;
}
