
//
//  main.cpp
//  cssProcessingLanguage
//
//  Created by Michał Sondej on 25/03/2023.
//
#include <iostream>
const int T = 8;
const int N = 1000; //initial buffer size for the css code (in letters)
using namespace std;
class myString
{
private:
    char* str;
    int length;

public:
    myString()
    {
        str = new char[1];
        str[0] = '\0';
        length = 0;
    }
    myString(char* value)
    {
        length = 0;
        if (value == nullptr)
        {
            str = new char[1];
            str[0] = '\0';
        }
        else
        {
            length = 0;
            while (value[length] != '\0')
            {
                length++;
            }
            str = new char[length + 1];
            str[length] = '\0';
            for (int i = 0; i < length; i++)
            {
                str[i] = value[i];
            }
        }
    }
    void putToString(char* value)
    {
        delete[] str;
        length = 0;
        if (value == nullptr)
        {
            str = new char[1];
            str[0] = '\0';
        }
        else
        {
            length = 0;
            while (value[length] != '\0')
            {
                length++;
            }
            str = new char[length + 1];
            str[length] = '\0';
            for (int i = 0; i < length; i++)
            {
                str[i] = value[i];
            }
        }
    }
    void clearString()
    {
        delete[] str;
        str = new char[1];
        str[0] = '\0';
        length = 0;
    }
    bool isNumber()
    {
        bool isThisANuber = 0;
        char digits[10] = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        for (int i = 0; i < length; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (str[i] == digits[j])
                {
                    isThisANuber = true;
                    break;
                }
            }
            if (isThisANuber == false)
            {
                return false;
            }
            isThisANuber = false;
        }
        return true;
    }
    bool isCommandLetter()
    {
        if (str[0] != 'S' && str[0] != 'A')
        {
            return false;
        }
        char letters[10] = { 'S', 'A' };
        for (int i = 0; i < length - 1; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (str[i] != letters[j])
                {
                    return false;
                }
            }
        }
        return true;
    }
    int toNumber()
    {
        int result = 0;
        int finalResult = 0;
        if (this->isNumber())
        {
            for (int i = 0; i < length; i++)
            {
                result += (int(str[i]) - 48);
                for (int j = 0; j < length - i - 1; j++)
                {
                    result *= 10;
                }
                finalResult += result;
                result = 0;
            }
        }
        return finalResult;
    }
    bool compareToALetter(char a)
    {
        if (length == 1 && str[0] == a)
        {
            return true;
        }
        return false;
    }
    bool compareToAnotherString(myString a)
    {
        if (length != a.length)
        {
            return false;
        }
        for (int i = 0; i < length; i++)
        {
            if (str[i] != a.str[i])
            {
                return false;
            }
        }
        return true;
    }
    void printMyString()
    {
        for (int i = 0; i < length; i++)
        {
            cout << str[i];
        }
    }
    myString& operator+=(const char letter)
    {
        if (length != 0 && str[0] != '\0')
        {
            char* updatedString;
            length += 1;
            updatedString = new char[length + 1];
            for (int i = 0; i < length - 1; i++)
            {
                updatedString[i] = str[i];
            }
            updatedString[length - 1] = letter;
            updatedString[length] = '\0';
            char* tmp;
            tmp = str;
            str = updatedString;
            updatedString = tmp;
            delete[] tmp;
            return *this;
        }
        else
        {
            length += 1;
            str[0] = letter;
            return *this;
        }

    }
    myString& operator=(const myString& other)
    {
        if (this != &other)
        {
            str = new char[1];
            delete[] str;
            length = other.length;
            str = new char[length + 1];
            for (int i = 0; i < length; ++i)
            {
                str[i] = other.str[i];
            }
            str[length] = '\0';
        }
        return *this;
    }
    //~myString()
    //{
    //    delete[] str;
    //}

};
class AttributeNode {
public:
    myString name;
    myString value;
    AttributeNode* previousNode;
    AttributeNode* nextNode;

    AttributeNode(AttributeNode* previous)
    {
        nextNode = nullptr;
        previousNode = previous;
    }
};
class doublyLinkedListAttributes {
public:
    AttributeNode* head;
    AttributeNode* tail;
    int numberOfNodes = 0;
    doublyLinkedListAttributes()
    {
        head = nullptr;
        tail = nullptr;
    }

    void createNewNode()
    {
        AttributeNode* newNode = new AttributeNode(tail);
        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->nextNode = newNode;
            tail = newNode;
        }
        numberOfNodes++;
    }
    AttributeNode returnAnAttributeNode(int i)
    {
        if (i > this->numberOfNodes)
        {
            return nullptr;
        }
        AttributeNode* ptr = this->head;
        for (int j = 0; j < (i - 1); j++)
        {
            ptr = ptr->nextNode;
        }
        return *ptr;
    }
    AttributeNode* returnPointerToAnAttributeNode(int i)
    {
        if (i > this->numberOfNodes)
        {
            return nullptr;
        }
        AttributeNode* ptr = this->head;
        for (int j = 0; j < (i - 1); j++)
        {
            ptr = ptr->nextNode;
        }
        return ptr;
    }
    void deleteNode(AttributeNode* del)
    {
        /* base case */
        if (del == NULL)
            return;

        /* If node to be deleted is head node */
        if (head == del)
        {
            head = del->nextNode;
            numberOfNodes--;
            free(del);
            return;
        }

        /* Change next only if node to be
        deleted is NOT the last node */
        if (del->nextNode != NULL)
            del->nextNode->previousNode = del->previousNode;

        /* Change prev only if node to be
        deleted is NOT the first node */
        if (del->previousNode != NULL)
            del->previousNode->nextNode = del->nextNode;

        /* Finally, free the memory occupied by del*/
        free(del);
        numberOfNodes--;
        return;
    }
};
class SelectorNode {
public:
    myString selector;
    SelectorNode* previousNode;
    SelectorNode* nextNode;

    SelectorNode(SelectorNode* previous)
    {
        nextNode = nullptr;
        previousNode = previous;
    }
};
class doublyLinkedListSelectors {
public:
    SelectorNode* head;
    SelectorNode* tail;
    int numberOfNodes = 0;
    doublyLinkedListSelectors()
    {
        head = nullptr;
        tail = nullptr;

    }

    void createNewNode()
    {
        SelectorNode* newNode = new SelectorNode(tail);
        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->nextNode = newNode;
            tail = newNode;
        }
        numberOfNodes++;
    }
    SelectorNode returnASelectorNode(int i)
    {
        if (i > this->numberOfNodes)
        {
            return nullptr;
        }
        SelectorNode* ptr = this->head;
        for (int j = 0; j < (i - 1); j++)
        {
            ptr = ptr->nextNode;
        }
        return *ptr;
    }

};
struct command {
    myString left;
    myString middle;
    myString right;
};
struct section {
    doublyLinkedListAttributes attributes;
    doublyLinkedListSelectors selectors;
    bool isTaken = false;
};
class Node {
public:
    section data[T];
    Node* previousNode;
    Node* nextNode;

    Node(Node* previous)
    {
        nextNode = nullptr;
        previousNode = previous;
    }
    bool freeASection(int x)
    {
        if (data[x].isTaken == false)
        {
            return false;
        }
        data[x].isTaken = false;
        return true;
    }
};
class doublyLinkedList {
public:
    Node* head;
    Node* tail;
    int numberOfNodes = 0;
    doublyLinkedList()
    {
        head = nullptr;
        tail = nullptr;

    }

    void createNewNode()
    {
        Node* newNode = new Node(tail);
        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->nextNode = newNode;
            tail = newNode;
        }
        numberOfNodes++;
    }
    Node returnANode(int i)
    {
        if (i > this->numberOfNodes)
        {
            return nullptr;
        }
        Node* ptr = this->head;
        for (int j = 0; j < (i - 1); j++)
        {
            ptr = ptr->nextNode;
        }
        return *ptr;
    }
    Node& returnANode2(int i)
    {
        if (i > this->numberOfNodes)
        {
            throw std::out_of_range("Node index out of bounds");
        }
        Node* ptr = this->head;
        for (int j = 0; j < (i - 1); j++)
        {
            ptr = ptr->nextNode;
        }
        return *ptr;
    }
};
void command1(int sectionCounter)// ?-print the number of CSS sections;
{
    cout << "? == " << sectionCounter << endl;
}
void command2(command command, doublyLinkedList list)// i,S,? - print the number of selectors for section number i (section and attribute numbers start from 1), if there is no such block, skip;
{
    int i = command.left.toNumber();
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int j = 0; j < (list.numberOfNodes) * T; j++)
    {
        int nodeNumber2 = j / T;
        int sectionInNodeNumber2 = j % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
        }
    }
    if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
    {
        command.left.printMyString();
        cout << ",S,? == ";
        cout << list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.numberOfNodes << endl;
    }
}
void command3(command command, doublyLinkedList list)// i,A,? - print the number of attributes for section number i, if there is no such block or section, skip;
{
    int i = command.left.toNumber();
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int j = 0; j < (list.numberOfNodes) * T; j++)
    {
        int nodeNumber2 = j / T;
        int sectionInNodeNumber2 = j % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
        }
    }
    if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
    {
        command.left.printMyString();
        cout << ",A,? == ";
        cout << list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes << endl;
    }
}
void command4(command command, doublyLinkedList list)// i,S,j - print the j-th selector for the i-th block (section and attribute numbers start from 1), if there is no section or selector, skip;
{
    int i = command.left.toNumber();
    int j = command.right.toNumber();
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int k = 0; k < (list.numberOfNodes)+1 * T; k++)
    {
        int nodeNumber2 = k / T;
        int sectionInNodeNumber2 = k % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
        }
    }
    if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1 && list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.numberOfNodes >= j)
    {
        command.left.printMyString();
        cout << ",S,";
        command.right.printMyString();
        cout << " == ";
        list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.returnASelectorNode(j).selector.printMyString();
        cout << endl;
    }
}
void command5(command command, doublyLinkedList list)// i,A,n - print the value of the attribute with the name n for the i-th section, if there is no such attribute, skip;
{
    int i = command.left.toNumber();
    myString n(command.right);
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int j = 0; j < (list.numberOfNodes) * T; j++)
    {
        int nodeNumber2 = j / T;
        int sectionInNodeNumber2 = j % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
            break;
        }
    }
    int whichAttribute = 1;
    if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
    {
        for (whichAttribute; whichAttribute <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes; whichAttribute++)
        {
            if (n.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(whichAttribute).name) == true)
            {
                command.left.printMyString();
                cout << ",A,";
                command.right.printMyString();
                cout << " ==";
                list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(whichAttribute).value.printMyString();
                cout << endl;
                return;
            }
        }
    }
}
void command6(command command, doublyLinkedList list)// n,A,? - print the total (for all blocks) number of occurrences of attribute named n (duplicates should be removed when reading).It can be 0;
{
    myString n(command.left);
    int numberOfOcurrences = 0;
    int nodeNumber;
    int sectionInNodeNumber;
    for (int i = 0; i < (list.numberOfNodes) * T; i++)
    {
        nodeNumber = i / T;
        sectionInNodeNumber = i % T;
        while (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken != 1 && i < list.numberOfNodes * T)
        {
            i++;
            nodeNumber = i / T;
            sectionInNodeNumber = i % T;
        }
        if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
        {
            for (int j = 1; j <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes; j++)
            {
                if (n.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(j).name) == true)
                {
                    numberOfOcurrences++;
                }
            }
        }
    }
    command.left.printMyString();
    cout << ",A,? == " << numberOfOcurrences << endl;
}
void command7(command command, doublyLinkedList list)// z,S,? - print the total (for all blocks) number of occurrences of selector z. It can be 0;
{
    myString n(command.left);
    int numberOfOcurrences = 0;
    int nodeNumber;
    int sectionInNodeNumber;
    for (int i = 0; i < (list.numberOfNodes) * T; i++)
    {
        nodeNumber = i / T;
        sectionInNodeNumber = i % T;
        while (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken != 1 && i<list.numberOfNodes*T)
        {
            i++;
            nodeNumber = i / T;
            sectionInNodeNumber = i % T;
        }
        if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
        {
            for (int j = 1; j <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.numberOfNodes; j++)
            {
                if (n.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.returnASelectorNode(j).selector) == true)
                {
                    numberOfOcurrences++;
                }
            }
        }
    }
    command.left.printMyString();
    cout << ",S,? == " << numberOfOcurrences << endl;
}
void command8(command command, doublyLinkedList list)// z,E,n - print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one.If there is no such attribute, skip;

{
    myString z(command.left);
    myString n(command.right);
    myString value;
    int nodeNumber;
    int sectionInNodeNumber;
    bool happened = 0;
    for (int i = 0; i < (list.numberOfNodes) * T; i++)
    {
        nodeNumber = i / T;
        sectionInNodeNumber = i % T;
        while (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken != 1 && i < list.numberOfNodes * T)
        {
            i++;
            nodeNumber = i / T;
            sectionInNodeNumber = i % T;
        }
        if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
        {
            for (int j = 1; j <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.numberOfNodes; j++)
            {
                if (z.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].selectors.returnASelectorNode(j).selector) == true)
                {
                    for (int k = 1; k <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes; k++)
                    {
                        if (n.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(k).name) == true)
                        {
                            value = list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(k).value;
                            happened = 1;
                        }
                    }
                }
            }
        }
    }
    if (happened == 1)
    {
        command.left.printMyString();
        cout << ",E,";
        command.right.printMyString();
        cout << " ==";
        value.printMyString();
        cout << endl;
    }
}
void command9(command command, doublyLinkedList& list, int& sectionCounter)// i,D,* - remove the entire section number i (i.e., separators+attributes), after successful execution, print "deleted";
{
    int i = command.left.toNumber();
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int j = 0; j < (list.numberOfNodes) * T; j++)
    {
        int nodeNumber2 = j / T;
        int sectionInNodeNumber2 = j % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
            break;
        }
    }
    while (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken != 1)
    {
        i++;
        nodeNumber = (i - 1) / T;
        sectionInNodeNumber = (i - 1) % T;
    }
    if (list.returnANode2(nodeNumber + 1).freeASection(sectionInNodeNumber) == true)
    {
        sectionCounter--;
        command.left.printMyString();
        cout << ",D,* == deleted" << endl;
    }
}
void command10(command command, doublyLinkedList& list, int& sectionCounter)// i,D,n - remove the attribute named n from the i-th section, if the section becomes empty as a result of the operation, it should also be removed(along with any selectors), after successful execution, print "deleted".

{
    int i = command.left.toNumber();
    bool happened = false;
    myString n(command.right);
    int nodeNumber = (i - 1) / T;
    int sectionInNodeNumber = (i - 1) % T;
    int countNonEmptySections = 0;
    for (int j = 0; j < list.numberOfNodes * T; j++)
    {
        int nodeNumber2 = j / T;
        int sectionInNodeNumber2 = j % T;
        if (list.returnANode(nodeNumber2 + 1).data[sectionInNodeNumber2].isTaken == 1)
        {
            countNonEmptySections++;
        }
        if (countNonEmptySections == i)
        {
            nodeNumber = nodeNumber2;
            sectionInNodeNumber = sectionInNodeNumber2;
            break;
        }
    }
    if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].isTaken == 1)
    {
        for (int j = 1; j <= list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes; j++)
        {
            if (n.compareToAnotherString(list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.returnAnAttributeNode(j).name) == true)
            {
                happened = true;
                //cout<<list.returnANode(nodeNumber+1).data[sectionInNodeNumber].attributes.numberOfNodes;
                list.returnANode2(nodeNumber).data[sectionInNodeNumber].attributes.deleteNode(list.returnANode(nodeNumber).data[sectionInNodeNumber].attributes.returnPointerToAnAttributeNode(j));
                //cout<<list.returnANode(nodeNumber+1).data[sectionInNodeNumber].attributes.numberOfNodes;
                if (list.returnANode(nodeNumber + 1).data[sectionInNodeNumber].attributes.numberOfNodes == 0)
                {
                    list.returnANode2(nodeNumber + 1).freeASection(sectionInNodeNumber);
                    sectionCounter--;
                }
            }
        }
        if (happened)
        {
            command.left.printMyString();
            cout << ",D,";
            command.right.printMyString();
            cout << " == deleted" << endl;
        }
    }
}
int recogniseCommand(command command)
{
    if (command.middle.isCommandLetter() == false && command.right.compareToALetter('?'))
    {
        return 1; // ? - print the number of CSS sections;
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('S') && command.right.compareToALetter('?'))
    {
        return 2; // i,S,? - print the number of selectors for section number i (section and attribute numbers start from 1), if there is no such block, skip;
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('A') && command.right.compareToALetter('?'))
    {
        return 3; // i,A,? - print the number of attributes for section number i, if there is no such block or section, skip;
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('S') && command.right.isNumber() == true)
    {
        return 4; // i,S,j - print the j-th selector for the i-th block (section and attribute numbers start from 1), if there is no section or selector, skip;
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('A') && command.right.isNumber() == false)
    {
        return 5; // i,A,n - print the value of the attribute with the name n for the i-th section, if there is no such attribute, skip;
    }
    else if (command.left.isNumber() == false && command.middle.compareToALetter('A') && command.right.compareToALetter('?'))
    {
        return 6; // n,A,? - print the total (for all blocks) number of occurrences of attribute named n (duplicates should be removed when reading). It can be 0;
    }
    else if (command.left.isNumber() == false && command.middle.compareToALetter('S') && command.right.compareToALetter('?'))
    {
        return 7; // z,S,? - print the total (for all blocks) number of occurrences of selector z. It can be 0;
    }
    else if (command.left.isNumber() == false && command.middle.compareToALetter('E') && command.right.isNumber() == false)
    {
        return 8; // z,E,n - print the value of the attribute named n for the selector z, in case of multiple occurrences of selector z, take the last one. If there is no such attribute, skip;
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('D') && command.right.compareToALetter('*'))
    {
        return 9; // i,D,* - remove the entire section number i (i.e., separators+attributes), after successful execution, print "deleted";
    }
    else if (command.left.isNumber() == true && command.middle.compareToALetter('D') && command.right.isNumber() == false)
    {
        return 10; // i,D,n - remove the attribute named n from the i-th section, if the section becomes empty as a result of the operation, it should also be removed (along with any selectors), after successful execution, print "deleted".
    }
    return 0;
}
int main(int argc, const char* argv[]) {
    doublyLinkedList nodes;
    nodes.createNewNode();
    char a = ' ';
    char b = ' ';
    int n = N;
    int textSize = 0;
    char switchSection2[4];
    bool isCommandSection2 = 0;
    bool switchCommandSection2 = 0;
    bool isCssSection2 = 1;
    bool isAttributeValue2 = 0;
    char* wholeText = new char[n];
    while (a != EOF)
    {
        if (textSize == n)
        {
            char* newWholeText = new char[n * 2];
            for (int i = 0; i < n; i++)
            {
                newWholeText[i] = wholeText[i];
            }
            delete[] wholeText;
            wholeText = newWholeText;
            n *= 2;
        }
        if (switchCommandSection2 == 1)
        {
            isCommandSection2 = 1;
        }
        switchCommandSection2 = 0;
        switchSection2[textSize % 4] = a;
        if (switchSection2[0] == '?' && switchSection2[1] == '?' && switchSection2[2] == '?' && switchSection2[3] == '?')
        {
            switchSection2[0] = '^';
            switchSection2[1] = '^';
            switchSection2[2] = '^';
            switchSection2[3] = '^';
            switchCommandSection2 = 1;
            isCssSection2 = 0;
        }
        if (switchSection2[0] == '*' && switchSection2[1] == '*' && switchSection2[2] == '*' && switchSection2[3] == '*')
        {
            isCommandSection2 = 0;
            isCssSection2 = 1;
        }
        //        if(isCommandSection2)
        //        {
        //            a = getchar();
        //        }
        //        if(isCssSection2)
        //        {
        //            cin >> a;
        //        }
        a = getchar();
        ///wholeText ;
        if (a == ':' && isAttributeValue2 == 1)
        {
            isAttributeValue2 = 1;
        }
        if (a == ';' && isAttributeValue2 == 1)
        {
            isAttributeValue2 = 0;
        }
        if (a != '\n' || isCommandSection2 == true)
        {

            wholeText[textSize] = a;
            textSize++;
        }
    }
    ///for (int i = 0; i < textSize; i++)
    ///{
        ///cout << wholeText[i] << endl;
    ///}
    int sectionCounter = 0;
    int selectorCounter = 0;

    int commandSection = 0;
    command command;
    int whichCommand = 0;

    bool isAttribute = 0;
    bool isSelector = 1;
    bool isAttributeValue = 0;

    bool switchCommandSection = 0;
    bool isCommandSection = 0;
    bool isCssSection = 1;

    int sectionCounterModulo = 0;

    char switchSection[4];

    myString stringBuffer;
    myString previousStringBuffer;
    for (int i = 0; i < textSize; i++)
    {
        sectionCounterModulo = sectionCounter;
        sectionCounterModulo %= T;
        previousStringBuffer = stringBuffer;
        if ((wholeText[i] != '\n' && wholeText[i] != ',' && wholeText[i] != '{' && wholeText[i] != '}' && wholeText[i] != ' ' && wholeText[i] != ':' && wholeText[i] != ';' && wholeText[i] > 32) || (wholeText[i] == ',' && isAttribute == 1) || (wholeText[i] == ' ' && isAttributeValue == 1))
        {
            stringBuffer += wholeText[i];
        }
        switchSection[i % 4] = wholeText[i];
        if (switchCommandSection == 1)
        {
            isCommandSection = 1;
        }
        switchCommandSection = 0;
        if (switchSection[0] == '?' && switchSection[1] == '?' && switchSection[2] == '?' && switchSection[3] == '?')
        {
            switchSection[0] = '^';
            switchSection[1] = '^';
            switchSection[2] = '^';
            switchSection[3] = '^';
            switchCommandSection = 1;
            isCssSection = 0;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
        }
        if (switchSection[0] == '*' && switchSection[1] == '*' && switchSection[2] == '*' && switchSection[3] == '*')
        {
            isCommandSection = 0;
            isCssSection = 1;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
        }
        if (wholeText[i] == '{')
        {
            nodes.tail->data[sectionCounterModulo].selectors.createNewNode();
            nodes.tail->data[sectionCounterModulo].selectors.tail->selector = stringBuffer;
            nodes.tail->data[sectionCounterModulo].isTaken = true;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
            isAttribute = 1;
            isSelector = 0;
        }
        if (wholeText[i] == '}')
        {
            isAttribute = 0;
            isSelector = 1;

            sectionCounter++;
            if (sectionCounter%T == 0 && sectionCounter!=0)
            {
                nodes.createNewNode();
            }
        }
        if (wholeText[i] == ',' && isSelector == 1 && isCssSection == 1)
        {
            nodes.tail->data[sectionCounterModulo].selectors.createNewNode();
            nodes.tail->data[sectionCounterModulo].selectors.tail->selector = stringBuffer;
            nodes.tail->data[sectionCounterModulo].isTaken = true;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
        }
        if (wholeText[i] == ':' && isAttribute == 1 && isCssSection == 1)
        {
            nodes.tail->data[sectionCounterModulo].attributes.createNewNode();
            nodes.tail->data[sectionCounterModulo].attributes.tail->name = stringBuffer;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
            isAttributeValue = 1;
        }
        if (wholeText[i] == ';' && isAttribute == 1 && isCssSection == 1)
        {
            //nodes.tail->data[sectionCounter].attributes.createNewNode();
            nodes.tail->data[sectionCounterModulo].attributes.tail->value = stringBuffer;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
            isAttributeValue = 0;
        }
        if (wholeText[i] == ',' && isCommandSection == 1)
        {
            if (commandSection == 0)
            {
                command.left = stringBuffer;
                stringBuffer.clearString();
                previousStringBuffer.clearString();
            }
            if (commandSection == 1)
            {
                command.middle = stringBuffer;
                stringBuffer.clearString();
                previousStringBuffer.clearString();
            }
            commandSection++;
        }
        if (wholeText[i] == '\n' && isCommandSection == 1)
        {
            command.right = stringBuffer;
            stringBuffer.clearString();
            previousStringBuffer.clearString();
            whichCommand = recogniseCommand(command);
            if (whichCommand == 1)
            {
                command1(sectionCounter);
            }
            else if (whichCommand == 2)
            {
                command2(command, nodes);
            }
            else if (whichCommand == 3)
            {
                command3(command, nodes);
            }
            else if (whichCommand == 4)
            {
                command4(command, nodes);
            }
            else if (whichCommand == 5)
            {
                command5(command, nodes);
            }
            else if (whichCommand == 6)
            {
                command6(command, nodes);
            }
            else if (whichCommand == 7)
            {
                command7(command, nodes);
            }
            else if (whichCommand == 8)
            {
                command8(command, nodes);
            }
            else if (whichCommand == 9)
            {
                command9(command, nodes, sectionCounter);
            }
            else if (whichCommand == 10)
            {
                command10(command, nodes, sectionCounter);
            }
            commandSection = 0;
        }
    }
    delete[] wholeText;
    return 0;
}

//PYTANIA
//czy mogę uzyc list z stl czy mam sam sobie zaimplementowac
//o co chodzi z tą tablicą t8
//what E command
//