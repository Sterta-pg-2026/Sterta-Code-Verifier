#include <iostream>
#include <string.h>
#include <ctype.h>

using namespace std;

#define T 8
#define INPUT_SIZE 100
#define PAIR 2
#define PROPERTY 0
#define VALUE 1
#define PART1 0
#define PART2 1
#define PART3 2

typedef struct Selector {
    Selector* prev;
    char data[INPUT_SIZE];
    Selector* next;
} Selector;

typedef struct Attribute {
    Attribute* prev;
    char data[PAIR][INPUT_SIZE];
    Attribute* next;
} Attribute;

typedef struct SelectorHolder {
    Selector* head;
    Selector* tail;
} SelectorHolder;

typedef struct AttributeHolder {
    Attribute* head;
    Attribute* tail;
} AttributeHolder;

typedef struct Section {
    SelectorHolder* selectors;
    AttributeHolder* attributes;
} Section;

typedef struct Node {
    Node* prev;
    Section* sections[T];
    int counter;
    Node* next;
} Node;

Node* initNode() {
    Node* node = new Node;
    node->prev = NULL;
    node->next = NULL;
    node->counter = 0;
    for(int i = 0; i < T; i++)
        node->sections[i] = NULL;
    return node;
}

Node* addNewNode(Node* tail) {
    Node* node = initNode();
    tail->next = node;
    node->prev = tail;
    return node;
}

char* initArray() {
    char* tab = new char[INPUT_SIZE];
    for(int i = 0; i < INPUT_SIZE; i++)
        tab[i] = '\0';
    return tab;
}

void trim(char* input) {
    // prawa strona
    for(int i = INPUT_SIZE - 1; i >= 0; i--){
        if(input[i] != '\0' && input[i] > ' ') {
            input[i+1] = '\0';
            break;
        }
    }
    
    // lewa strona
    int j = 0;
    for(int i = 0; i < INPUT_SIZE; i++) {
        if(input[i] != '\0' && input[i] > ' ') {
            j = i;
            break;
        }
        else
            input[i] = '\0';
    }
    for(int i = 0; i < INPUT_SIZE; i++) {
        input[i] = input[j];
        j++;
    }
}

void printText(char* text) {
    for(int i = 0; text[i] != '\0'; i++)
        printf("%c", text[i]);
    printf("\n");
}

Selector* createSelector() {
    char* templateInput = initArray();
    Selector* tmp = new Selector;
    strcpy(tmp->data, templateInput);
    tmp->prev = NULL;
    tmp->next = NULL;
    delete[] templateInput;
    return tmp;
}

void addFirstSelector(SelectorHolder* holder) {
    Selector* tmp = createSelector();
    holder->head = tmp;
    holder->tail = tmp;
}

Selector* addNextSelector(Selector* selector) {
    Selector* tmp = createSelector();
    selector->next = tmp;
    tmp->prev = selector;
    return tmp;
}

Attribute* createAttribute() {
    char* templateInput = initArray();
    Attribute* tmp = new Attribute;
    strcpy(tmp->data[PROPERTY], templateInput);
    strcpy(tmp->data[VALUE], templateInput);
    tmp->prev = NULL;
    tmp->next = NULL;
    delete[] templateInput;
    return tmp;
}

void addFirstAttribute(AttributeHolder* holder) {
    Attribute* tmp = createAttribute();
    holder->head = tmp;
    holder->tail = tmp;
}

Attribute* addNextAttribute(Attribute* attribute) {
    Attribute* tmp = createAttribute();
    attribute->next = tmp;
    tmp->prev = attribute;
    return tmp;
}

void createHolders(Section* section) {
    SelectorHolder* selectors = new SelectorHolder;
    section->selectors = selectors;
    addFirstSelector(selectors);
    
    AttributeHolder* attributes = new AttributeHolder;
    section->attributes = attributes;
    addFirstAttribute(attributes);
}

void createSection(Node* node, int sectionNumber) {
    Section* tmp = new Section;
    createHolders(tmp);
    node->sections[sectionNumber] = tmp;
}

void sectionCheck(Node* node) {
    if(node->sections[node->counter] == NULL)
        createSection(node, node->counter);
}

void addSelectorToList(char* input, Node* node) {
    sectionCheck(node);
    
    if(node->sections[node->counter]->selectors->tail->data[0] == '\0')
        strcpy(node->sections[node->counter]->selectors->tail->data, input);
    else {
        node->sections[node->counter]->selectors->tail = addNextSelector(node->sections[node->counter]->selectors->tail);
        strcpy(node->sections[node->counter]->selectors->tail->data, input);
    }
}

bool checkIfEqual(char* textA, char* textB) {
    for (int i = 0; i < INPUT_SIZE; i++) {
        if (textA[i] != textB[i])
            return false;
        if (textA[i] == '\0' && textB[i] == '\0') {
            return true;
        }
    }
    return true;
}

bool checkIfAttributeExists(char* property, char* value, Node* node) {
    Attribute* tmp = node->sections[node->counter]->attributes->head;
    
    while(1) {
        if(checkIfEqual(tmp->data[PROPERTY], property)) {
            strcpy(tmp->data[VALUE], value);
            return true;
        }
        if(tmp->next == NULL)
            return false;
        tmp = tmp->next;
    }
}

void addAttributeToList(char* property, char* value, Node* node) {
    sectionCheck(node);
    
    if(checkIfAttributeExists(property, value, node))
        return;
    
    if(node->sections[node->counter]->attributes->tail->data[PROPERTY][0] == '\0' &&
       node->sections[node->counter]->attributes->tail->data[VALUE][0] == '\0') {
        strcpy(node->sections[node->counter]->attributes->tail->data[PROPERTY], property);
        strcpy(node->sections[node->counter]->attributes->tail->data[VALUE], value);
    }
    else {
        node->sections[node->counter]->attributes->tail = addNextAttribute(node->sections[node->counter]->attributes->tail);
        strcpy(node->sections[node->counter]->attributes->tail->data[PROPERTY], property);
        strcpy(node->sections[node->counter]->attributes->tail->data[VALUE], value);
    }
}

void getAttribute(char* input, Node* node) {
    char* property = initArray();
    char* value = initArray();
    bool isValue = false;
    int j = 0;
    
    strcpy(property, input);
    for(int i = 0; i < INPUT_SIZE; i++){
        if(isValue){
            value[j] = property[i];
            if(property[i] == '\0')
                break;
            j++;
        }
        if(property[i] == ':') {
            property[i] = '\0';
            isValue = true;
        }
    }
    trim(property);
    trim(value);
    
    if(property[0] != '\0')
        addAttributeToList(property, value, node);
}

char* countSections(Node* node) {   // ?
    Node* tmp = node;
    char* output = initArray();
    int counter = 0;
    while(1) {
        counter += tmp->counter;
        if(tmp->prev == NULL)
            break;
        else
            tmp = tmp->prev;
    }
    sprintf(output, "%i", counter);
    return output;
}

void setOutput(char* output, char* respond) {
    int k = 0;
    for(int i = 0; i < INPUT_SIZE; i++) {
        if(output[i] == '\0') {
            k = i;
            break;
        }
    }
    
    output[k] = output[k+3] = ' ';
    output[k+1] = output[k+2] = '=';
    
    k += 4;
    for(int i = 0; respond[i] != '\0'; i++) {
        output[k] = respond[i];
        k++;
    }
}

void divideCommand(char* input, char* part1, char* part2, char* part3) {
    int partNumber = PART1, part2Cur = 0, part3Cur = 0;
    
    strcpy(part1, input);
    for(int i = 0; i < INPUT_SIZE; i++) {
        if(partNumber == PART3) {
            part3[part3Cur] = part1[i];
            part3Cur++;
            if(part1[i] == '\0')
                break;
        }
        if(partNumber == PART2) {
            if(part1[i] == ',') {
                part2[part2Cur] = '\0';
                partNumber++;
            }
            else {
                part2[part2Cur] = part1[i];
                part2Cur++;
            }
        }
        if(partNumber == PART1 && part1[i] == ',') {
            part1[i] = '\0';
            partNumber++;
        }
    }
}

bool isNumber(char* input) {
    bool isNumber = true;
    int i = 0;
    while(input[i] != '\0') {
        if(!isdigit(input[i]))
            isNumber = false;
        i++;
    }
    return isNumber;
}

Section* getIthSection(char* i, Node* head) {
    Node* tmp = head;
    int sectionNumber;
    sscanf(i, "%d", &sectionNumber);
    
    while(1) {
        if(sectionNumber > tmp->counter) {
            if(tmp->next == NULL)
                return NULL;
            sectionNumber -= tmp->counter;
            tmp = tmp->next;
        }
        else {
            sectionNumber--;
            break;
        }
    }
    
    return tmp->sections[sectionNumber];
}

char* getNumberForSection(char* part1, char* part2, Node* head) {   // i,S,? and i,A,?
    Section* tmp = getIthSection(part1, head);
    if(tmp == NULL)
        return NULL;
    
    char* output = initArray();
    int counter = 1;
    
    switch (part2[0]) {
        case 'S': {
            Selector* tmpSel = tmp->selectors->head;
            if(tmpSel->data[0] != '\0'){
                while(1) {
                    if(tmpSel->next != NULL && tmpSel->next->data[0] != '\0') {
                        counter++;
                        tmpSel = tmpSel->next;
                    }
                    else
                        break;
                }
            }
            else
                counter--;
            break;
        }
        case 'A': {
            Attribute* tmpAttr = tmp->attributes->head;
            while(1) {
                if(tmpAttr->next != NULL && tmpAttr->next->data[PROPERTY][0] != '\0') {
                    counter++;
                    tmpAttr = tmpAttr->next;
                }
                else
                    break;
            }
            break;
        }
        default: {
            delete[] output;
            return NULL;
        }
    }
    
    sprintf(output, "%i", counter);
    return output;
}

char* getSelectorForSection(char* part1, char* part3, Node* head) { // i,S,j
    Section* tmp = getIthSection(part1, head);
    if(tmp == NULL)
        return NULL;
    
    Selector* tmpSel = tmp->selectors->head;
    int selectorNumber;
    sscanf(part3, "%d", &selectorNumber);
    
    selectorNumber--;
    while(1) {
        if(selectorNumber == 0)
            break;
        
        if(tmpSel->next != NULL && tmpSel->next->data[0] != '\0') {
            selectorNumber--;
            tmpSel = tmpSel->next;
        }
        else {
            break;
        }
    }
    
    if(selectorNumber != 0 || tmpSel->data[0] == '\0')
        return NULL;
    
    return tmpSel->data;
}

char* getAttrValue(char* part1, char* part3, Node* head) {  // i,A,n
    Section* tmp = getIthSection(part1, head);
    if(tmp == NULL)
        return NULL;
    
    Attribute* tmpAttr = tmp->attributes->head;
    
    while(1) {
        if(checkIfEqual(tmpAttr->data[PROPERTY], part3))
            break;
        if(tmpAttr->next == NULL || tmpAttr->next->data[PROPERTY][0] == '\0')
            return NULL;
        tmpAttr = tmpAttr->next;
    }
    
    return tmpAttr->data[VALUE];
}

char* countAttributes(char* part1, Node* head) {   // n,A,?
    Node* tmp = head;
    char* output = initArray();
    int counter = 0;
    
    while(1) {
        for(int i = 0; i < tmp->counter; i++) {
            Attribute* tmpAttr = tmp->sections[i]->attributes->head;
            while(1){
                if(checkIfEqual(tmpAttr->data[PROPERTY], part1)){
                    counter++;
                    break;
                }
                if(tmpAttr->next != NULL && tmpAttr->next->data[PROPERTY][0] != '\0')
                    tmpAttr = tmpAttr->next;
                else
                    break;
            }
        }
        if(tmp->next == NULL)
            break;
        tmp = tmp->next;
    }
    
    sprintf(output, "%i", counter);
    return output;
}

char* countSelectors(char* part1, Node* head) {   // z,S,?
    Node* tmp = head;
    char* output = initArray();
    int counter = 0;
    
    while(1) {
        for(int i = 0; i < tmp->counter; i++) {
            Selector* tmpSel = tmp->sections[i]->selectors->head;
            while(1){
                if(checkIfEqual(tmpSel->data, part1)){
                    counter++;
                    break;
                }
                if(tmpSel->next != NULL && tmpSel->next->data[0] != '\0')
                    tmpSel = tmpSel->next;
                else
                    break;
            }
        }
        if(tmp->next == NULL)
            break;
        tmp = tmp->next;
    }
    
    sprintf(output, "%i", counter);
    return output;
}

char* getAttrValueForSelector(char* part1, char* part3, Node* tail) {   // z,E,n
    Node* tmp = tail;
    char* output = initArray();
    bool isFound = false;
    
    while(1) {
        for(int i = tmp->counter-1; i >= 0; i--) {
            Selector* tmpSel = tmp->sections[i]->selectors->head;
            while(1) {
                if(checkIfEqual(tmpSel->data, part1)) {
                    isFound = true;
                    break;
                }
                if(tmpSel->next != NULL && tmpSel->next->data[0] != '\0')
                    tmpSel = tmpSel->next;
                else
                    break;
            }
            if(isFound){
                Attribute* tmpAttr = tmp->sections[i]->attributes->head;
                while(1) {
                    if(checkIfEqual(tmpAttr->data[PROPERTY], part3)) {
                        strcpy(output, tmpAttr->data[VALUE]);
                        break;
                    }
                    if(tmpAttr->next != NULL && tmpAttr->next->data[PROPERTY][0] != '\0')
                        tmpAttr = tmpAttr->next;
                    else {
                        isFound = false;
                        break;
                    }
                }
                if(isFound)
                    break;
            }
        }
        if(isFound)
            break;
        if(tmp->prev != NULL)
            tmp = tmp->prev;
        else
            return NULL;
    }
    
    return output;
}

void writeDelete(char* input) {
    input[0] = input[6] = 'd';
    input[1] = input[3] = input[5] = 'e';
    input[2] = 'l';
    input[4] = 't';
}

bool deleteIthSection(char* i, Node* head) {
    Node* tmp = head;
    int sectionNumber;
    sscanf(i, "%d", &sectionNumber);
    
    while(1) {
        if(sectionNumber > tmp->counter) {
            if(tmp->next == NULL)
                return false;
            sectionNumber -= tmp->counter;
            tmp = tmp->next;
        }
        else {
            sectionNumber--;
            break;
        }
    }
    
    delete tmp->sections[sectionNumber];
    tmp->counter--;
    
    if(sectionNumber != T - 1) {
        for(int j = sectionNumber+1; j < T; j++)
            tmp->sections[j-1] = tmp->sections[j];
        tmp->sections[T-1] = NULL;
    }
    
    return true;
}

char* deleteSectionCommand(char* part1, Node* head) {  // i,D,*
    char* output = initArray();
    
    if(deleteIthSection(part1, head)) {
        writeDelete(output);
        return output;
    }
    
    delete[] output;
    return NULL;
}

bool deleteAttribute(char* secNum, char* attr, Section* section, Node* head) {
    Attribute* tmp = section->attributes->head;
    while(1) {
        if(checkIfEqual(tmp->data[PROPERTY], attr)) {
            if(tmp->prev != NULL && tmp->next != NULL){
                tmp->next->prev = tmp->prev;
                tmp->prev->next = tmp->next;
            }
            if(tmp->prev == NULL && tmp->next != NULL){
                tmp->next->prev = NULL;
                section->attributes->head = tmp->next;
            }
            if(tmp->prev != NULL && tmp->next == NULL){
                tmp->prev->next = NULL;
                section->attributes->tail = tmp->prev;
            }
            if(tmp->prev == NULL && tmp->next == NULL) {
                delete tmp;
                if(!deleteIthSection(secNum, head))
                    return false;
                return true;
            }
            delete tmp;
            return true;
        }
        if(tmp->next != NULL && tmp->next->data[PROPERTY][0] != '\0')
            tmp = tmp->next;
        else
            return false;
    }
}

char* deleteAttributeCommand(char* part1, char* part3, Node* head) {   // i,D,n
    Section* tmp = getIthSection(part1, head);
    if(tmp == NULL)
        return NULL;
    
    if(deleteAttribute(part1, part3, tmp, head)) {
        char* output = initArray();
        writeDelete(output);
        return output;
    }
    
    return NULL;
}

void getCommand(char* input, Node* head, Node* tail) {
    char* part1 = initArray();
    char* part2 = initArray();
    char* part3 = initArray();
    
    char* output = initArray();
    char* respond = NULL;
    
    strcpy(output, input);
    
    if(input[0] == '?' && input[1] == '\0')
        respond = countSections(tail);
    
    if(respond == NULL) {
        divideCommand(input, part1, part2, part3);
        
        if(isNumber(part1) && part3[0] == '?')
            respond = getNumberForSection(part1, part2, head);
        if(isNumber(part1) && part2[0] == 'S' && isNumber(part3))
            respond = getSelectorForSection(part1, part3, head);
        if(isNumber(part1) && part2[0] == 'A' && part3[0] != '?')
            respond = getAttrValue(part1, part3, head);
        if(!isNumber(part1) && part2[0] == 'A' && part3[0] == '?')
            respond = countAttributes(part1, head);
        if(!isNumber(part1) && part2[0] == 'S' && part3[0] == '?')
            respond = countSelectors(part1, head);
        if(part2[0] == 'E')
            respond = getAttrValueForSelector(part1, part3, tail);
        if(isNumber(part1) && part2[0] == 'D' && part3[0] == '*')
            respond = deleteSectionCommand(part1, head);
        if(isNumber(part1) && part2[0] == 'D' && part3[0] != '*')
            respond = deleteAttributeCommand(part1, part3, head);
    }
    
    if(respond != NULL){
        setOutput(output, respond);
        printText(output);
    }
    
    delete[] part1;
    delete[] part2;
    delete[] part3;
    delete[] output;
}

bool checkIfModeChanged(char* input) {
    int i = 0, cssMark = 0, comMark = 0;
    while(input[i] != '\0') {
        if(input[i] == '?')
            comMark++;
        else if(input[i] == '*')
            cssMark++;
        i++;
    }
    
    if(cssMark == 4 || comMark == 4)
        return true;
    return false;
}

int main(int argc, const char * argv[]) {
    Node* head = initNode();
    Node* tail = head;
    char ch = getchar();
    int curInp = 0;
    bool isCommand = false, isAttribute = false;
    char* input = initArray();
    
    while(ch != EOF) {
        if(!isCommand) {
            if (ch == ',' || ch == '{') {
                if(!isAttribute) {
                    trim(input);
                    if(input[0] != '\0') {
                        addSelectorToList(input, tail);
                        input = initArray();
                        curInp = 0;
                    }
                }
                else{
                    input[curInp] = ch;
                    curInp++;
                }
                    
                if(ch == '{')
                    isAttribute = true;
            }
            else if (ch == ';' || ch == '}') {
                trim(input);
                getAttribute(input, tail);
                input = initArray();
                curInp = 0;
                if(ch == '}') {
                    isAttribute = false;
                    tail->counter++;
                }
            }
            else {
                input[curInp] = ch;
                curInp++;
            }
        }
        else {
            if(ch == '\n' && curInp > 1 ) {
                trim(input);
                getCommand(input, head, tail);
                input = initArray();
                curInp = 0;
            }
            input[curInp] = ch;
            curInp++;
        }
        
        if(tail->counter == T) {
            tail = addNewNode(tail);
        }
        
        if(checkIfModeChanged(input)) {
            isCommand = !isCommand;
            input = initArray();
            curInp = 0;
        }
        
        ch = getchar();
    }
    
    trim(input);
    getCommand(input, head, tail);
    
    delete head;
    return 0;
}
