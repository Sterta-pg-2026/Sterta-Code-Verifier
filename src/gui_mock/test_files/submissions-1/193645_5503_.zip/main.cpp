#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

const int T = 29;
const int BUFFER_SIZE = 1000;

using namespace std;

struct String {
	char* str;
	int length;

	String(const char* string = "") {
		length = strlen(string);
		str = new char[length + 1];
		strcpy(str, string);
	}

	void assign(const String& string) {
		if (this == &string) return;
		length = string.length;
		str = new char[length + 1];
		strcpy(str, string.str);
	}
};
void add(String* s, char* p_str) {
	s->str = p_str;
	s->length = strlen(p_str);
}

struct Selector {
	Selector* next = nullptr;
	String name;
};

struct Attribute{
	Attribute* next = nullptr;
	String name;
	String value;
};

class Section {
private:
	Selector* selectorList;
	Attribute* attributeList;
	int counter_selector;
	int counter_attribute;

public:
	Section() {
		selectorList = nullptr;
		attributeList = nullptr;
		counter_attribute = 0;
		counter_selector = 0;
	}

	int getNumberOfSelectors() const {
		return counter_selector;
	}

	int getNumberOfAttributes() const {
		return counter_attribute;
	}

	void addSelector(String p_name) {
		Selector* newSelector = new Selector;
		newSelector->name.assign(p_name);

		if (selectorList == nullptr) {
			selectorList = newSelector;
		}
		else {
			Selector* temp = selectorList;

			while (temp->next){
				temp = temp->next;
			}
			temp->next = newSelector;
			newSelector->next = nullptr;

			findDuplicates(newSelector);
		}
		counter_selector++;
	}

	void addAttribute(String p_name, String p_value) {

		Attribute* newAttribute = new Attribute;
		newAttribute->name.assign(p_name);
		newAttribute->value.assign(p_value);

		if (attributeList == nullptr) {
			attributeList = newAttribute;
		}
		else {
			Attribute* temp = attributeList;

			while (temp->next) {
				temp = temp->next;
			}
			temp->next = newAttribute;
			newAttribute->next = nullptr;

			findDuplicates(newAttribute);
		}
		counter_attribute++;
	}

	void findDuplicates(Attribute* newAttribute) {
		Attribute* temp = attributeList;
		while (temp != newAttribute) {
			if (strcmp(newAttribute->name.str, temp->name.str) == 0) {
				removeAttribute(temp);
				break;
			}
			temp = temp->next;
		}
	}

	void findDuplicates(Selector* newSelector) {
		Selector* temp = selectorList;
		while (temp != newSelector) {
			if (strcmp(newSelector->name.str, temp->name.str) == 0) {
				removeSelector(temp);
				break;
			}
			temp = temp->next;
		}
	}

	void removeSelector(Selector* selector) {
		Selector* temp = selectorList;

		if (temp == selector) {
			selectorList = temp->next;
			delete temp;
			this->counter_selector--;
			temp = nullptr;
			return;
		}
		else {
			while (temp) {
				if (temp->next == selector) break;
				temp = temp->next;
			}
			Selector* toRemove = temp->next;
			temp->next = temp->next->next;
			delete toRemove;
			this->counter_selector--;
		}
	}

	void removeAttribute(Attribute *attribute) {
		Attribute* temp = attributeList;

		if (temp == attribute) {
			attributeList = temp->next;
			delete temp;
			this->counter_attribute--;
			temp = nullptr;
			return;
		}
		else {
			while (temp) {
				if (temp->next == attribute) break;
				temp = temp->next;
			}
			Attribute* toRemove = temp->next;
			temp->next = temp->next->next;
			delete toRemove;
			this->counter_attribute--;
		}
	}

	Selector* getSelector() {
		return selectorList;
	}

	Attribute* getAttrubute() {
		return attributeList;
	}

	void clearSection() {
		delete attributeList;
		delete selectorList;
	}
};

struct Block {
	Block* prev = nullptr;
	Block* next = nullptr;
	Section* sectionArr = nullptr;
	bool sectionsUsed[T]; 
	int counter_section;

	Block() {
		sectionArr = new Section[T];
		counter_section = 0;
		for (int i = 0; i < T; i++) {
			sectionsUsed[i] = false;
		}
	}

	Section* changeSection() {

		counter_section++;
		Section* section = &this->sectionArr[counter_section - 1];
		sectionsUsed[counter_section - 1] = true;

		return section;
	}

	void removeSection(const Section &section, int i) {
		counter_section--;
		sectionsUsed[i] = false;
	}

	void checkSection(const Section &section, int i) {
		if (section.getNumberOfAttributes() == 0) {
			removeSection(section, i);
		}
	}
};

int countSections(Block* firstBlock) {
	Block* tempBlock = firstBlock;
	int result = 0;

	while (tempBlock) {
		result += tempBlock->counter_section;
		tempBlock = tempBlock->next;
	}
	return result;
}

Block* addBlock(Block *currBlock) {
	Block* newBlock = new Block();
	Block* temp = currBlock;

	while (temp->next) {
		temp = temp->next;
	}
	temp->next = newBlock;
	newBlock->next = nullptr;
	newBlock->prev = temp;

	return newBlock;
}

bool isInt(String text) {
	for (int i = 0; i < text.length; i++) {
		if (!isdigit(text.str[i])) return false;
	}
	return true;
}

void commandManager(const String A, char B, const String C, Block* firstBlock) {
	Block* temp = firstBlock;

	// LICZBA SELEKTORÓW W DANEJ SEKCJI
	if (isInt(A) && B == 'S' && strcmp(strcat(C.str, "\0"), "?") == 0) {

		int num_of_section = atoi(A.str);
		int num_of_block = (num_of_section - 1)/ T;

		for (int i = 0; i < num_of_block; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}
		if (!temp->sectionsUsed[(num_of_section - 1) % T]) return;
		cout << A.str << ',' << B << ',' << C.str << " == " << temp->sectionArr[(num_of_section - 1) % T].getNumberOfSelectors() << endl;
	}

	// LICZBA ATRYBUTÓW W DANEJ SEKCJI
	else if (isInt(A) && B == 'A' && strcmp(C.str, "?") == 0) {

		int num_of_section = atoi(A.str);
		int num_of_block = (num_of_section - 1) / T;

		for (int i = 0; i < num_of_block; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}
		cout << A.str << ',' << B << ',' << C.str << " == " << temp->sectionArr[(num_of_section - 1) % T].getNumberOfAttributes() << endl;
	}

	// WYPISANIE DANEGO SELEKTORA W DANEJ SEKCJI
	else if (isInt(A) && (B == 'S' || B == 's') && isInt(C)) {

		int num_of_section = atoi(A.str);
		int num_of_selector = atoi(C.str);
		int num_of_block = num_of_section / T;


		for (int i = 0; i < num_of_block - 1; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}
		Selector* chosenSelector = temp->sectionArr[(num_of_section - 1) % T].getSelector();
		
		if (chosenSelector == nullptr) return;

		for (int i = 0; i < num_of_selector - 1; i++) {
			if (chosenSelector->next) chosenSelector = chosenSelector->next;
			else return;
		}
		cout << A.str << ',' << B << ',' << C.str << " == " << chosenSelector->name.str << endl;
	}

	// WYPISANIE WARTOŚCI ATRYBUTU W DANEJ SEKCJI
	else if (isInt(A) && B == 'A') {

		int num_of_section = atoi(A.str);
		String name_of_attribute = C;
		int num_of_block = (num_of_section - 1) / T;

		for (int i = 0; i < num_of_block; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}
		Attribute* chosenAttribute = temp->sectionArr[(num_of_section - 1) % T].getAttrubute();

		if (chosenAttribute == nullptr) return;

		while (chosenAttribute) {
			if (strcmp(chosenAttribute->name.str, name_of_attribute.str) == 0) {
				cout << A.str << ',' << B << ',' << C.str << " == " << chosenAttribute->value.str << endl;
				return;
			}
			chosenAttribute = chosenAttribute->next;
		}
	}

	// LICZBA ATRYBUTÓW O DANEJ NAZWIE
	else if (!isInt(A) && B == 'A' && strcmp(C.str, "?") == 0) {
		
		Attribute* currAttribute;
		String name_of_attribute = A;
		int counter = 0;

		while (temp) {
			for (int i = 0; i < T; i++) {
				if (!temp->sectionsUsed[i]) continue;
				currAttribute = temp->sectionArr[i].getAttrubute();
				while (currAttribute) {
					if (strcmp(currAttribute->name.str, name_of_attribute.str) == 0) counter++;
					currAttribute = currAttribute->next;
				}
			}
			temp = temp->next;
		}
		cout << A.str << ',' << B << ',' << C.str << " == " << counter << endl;
	}

	// LICZBA SELEKTORÓW O DANEJ NAZWIE
	else if (!isInt(A) && B == 'S' && strcmp(C.str,"?") == 0) {

		Selector* currSelector;
		String name_of_selector = A;
		int counter = 0;

		while (temp) {
			for (int i = 0; i < T; i++) {
				if (!temp->sectionsUsed[i]) continue;
				currSelector = temp->sectionArr[i].getSelector();
				while (currSelector) {
					if (strcmp(currSelector->name.str, name_of_selector.str) == 0) counter++;
					currSelector = currSelector->next;
				}
			}
			temp = temp->next;
		}
		cout << A.str << ',' << B << ',' << C.str << " == " << counter << endl;
	}

	// SZUKANIE OSTATNIEGO WYSTĄPIENIA ATRYBUTU 
	else if (B == 'E') {
		Selector* currSelector;
		Attribute* currAttribute;
		String name_of_selector = A;
		String name_of_attribute = C;

		while (temp->next) {
			temp = temp->next;
		}

		while (temp) {
			for (int i = T - 1; i >= 0; i--) {
				if (!temp->sectionsUsed[i]) continue;
				currSelector = temp->sectionArr[i].getSelector();
				currAttribute = temp->sectionArr[i].getAttrubute();
				while (currSelector) {
					if (strcmp(currSelector->name.str, name_of_selector.str) == 0) {
						while (currAttribute) {
							if (strcmp(currAttribute->name.str, name_of_attribute.str) == 0) {
								cout << A.str << ',' << B << ',' << C.str << " == " << currAttribute->value.str << endl;
								return;
							}
							else currAttribute = currAttribute->next;
						}
						break;
					}
					else currSelector = currSelector->next;
				}
			}
			temp = temp->prev;
		}	
	}

	// USUWANIE CAŁEJ SEKCJI
	else if (B == 'D' && strcmp(C.str, "*") == 0) {
		Section currSection;
		int num_of_section = atoi(A.str);
		int num_of_block = (num_of_section - 1) / T;

		for (int i = 0; i < num_of_block; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}

		int i, cnt = 0;
		for (i = 0; i < T; i++) {
			if (!temp->sectionsUsed[i]) continue;
			if (cnt == (num_of_section - 1) % T) {
				currSection = temp->sectionArr[i];
				break;
			}
			cnt++;
		}

		currSection.clearSection();
		temp->removeSection(currSection, i);
		cout << A.str << ',' << B << ',' << C.str << " == " << "deleted" << endl;
	}

	// USUWANIE DANEGO ATRYBUTU
	else if (B == 'D' && !isInt(C)) {
		Attribute* currAttribute = nullptr;
		Section currSection;
		String name_of_attribute = C;
		int num_of_section = atoi(A.str);
		int num_of_block = num_of_section / T;

		for (int i = 0; i < num_of_block; i++) {
			if (temp->next) temp = temp->next;
			else return;
		}

		int i, cnt = 0;
		for (i = 0; i < T; i++) {
			if (!temp->sectionsUsed[i]) continue;
			if (cnt == (num_of_section - 1) % T) {
				currAttribute = temp->sectionArr[i].getAttrubute();
				break;
			}
			cnt++;
		}
		while (currAttribute) {
			if (strcmp(currAttribute->name.str, name_of_attribute.str) == 0) {
				temp->sectionArr[i].removeAttribute(currAttribute);
				cout << A.str << ',' << B << ',' << C.str << " == " << "deleted" << endl;
				break;
			}
			currAttribute = currAttribute->next;
		}
		temp->checkSection(temp->sectionArr[i], i);
	}
}

String Stringify(char* array, int size) {
	String str;
	array[size] = '\0';
	add(&str, &array[0]);
	return str;
}

int main()
{
	Block* currBlock = new Block();
	Block* firstBlock = currBlock;
	Section* currSection;
	currSection = currBlock->changeSection();

	char buffer[BUFFER_SIZE];
	int c = 0, i = 0, optCounter = 0, index = 0, commas = 0, lastChar = -1, beforeLast;
	bool isInside = false, cssInput = true, ignoreSpace = true, ignoreNewLine = true, sectionFinished = false, needNewLine = false;
	String opt;
	char tempArr[3][50];
	do {
		beforeLast = lastChar;
		lastChar = c;
		c = getchar();
		buffer[i] = c;

		if (c == ' ' && ignoreSpace) continue;
		if (c == 9) continue;
		if (c == '\r') continue;

		if (c == '?' || c == '*') {
			if ((++optCounter) == 4) {
				cssInput = (c == '?' ? false : true);
				ignoreSpace = false;
				c = '\0';
				optCounter = 0;
				i = 0;
				continue;
			}
		}
		else {
			optCounter = 0;
		}

		if (cssInput) {
			if (c == '\n' && ignoreNewLine) continue;
			if (c == ',' && !isInside) {
				if (sectionFinished) {
					sectionFinished = false;
					if (currBlock->counter_section >= T) {
						currBlock = addBlock(currBlock);
						currSection = currBlock->changeSection();
					}
					else {
						currSection = currBlock->changeSection();
					}
				}
				ignoreSpace = true;
				currSection->addSelector(Stringify(buffer, i));
				i = 0;
				continue;
			}

			if (c == '{') {

				if (lastChar == ' ' || beforeLast == ' ') {
					i--;
				}

				ignoreSpace = false;
				if (sectionFinished) {
					sectionFinished = false;
					if (currBlock->counter_section >= T) {
						currBlock = addBlock(currBlock);
						currSection = currBlock->changeSection();
					}
					else {
						currSection = currBlock->changeSection();
					}
				}
				currSection->addSelector(Stringify(buffer, i));
				isInside = true;
				i = 0;
				continue;
			}

			if (c == '}') {
				ignoreSpace = true;
				isInside = false;
				sectionFinished = true;
				i = 0;
				continue;
			}

			if ((c == ';' || c == '}' || c == '\n') && isInside) {
				char temp[BUFFER_SIZE];
				char temp2[BUFFER_SIZE];
				int buffer_iterator = 0;
				String name, value;
				bool nameSet = false;
				for (int j = 0; j < i; j++) {
					if (buffer[buffer_iterator] <= ' ' && j == 0) {
						buffer_iterator++;
						j--;
						continue;
					}
					if (buffer[buffer_iterator] == ':') {
						name = Stringify(temp, j);
						j = -1;
						buffer_iterator++;
						nameSet = true;
						continue;
					}
					if (buffer[buffer_iterator] == ';' || buffer[buffer_iterator] == '}') {
						value = Stringify(temp2, j);
						break;
					}
					if (buffer[buffer_iterator] == ' ' && buffer[buffer_iterator-1] == ':') {
						buffer_iterator++;
						j--;
						continue;
					}
					if (!nameSet) temp[j] = buffer[buffer_iterator];
					temp2[j] = buffer[buffer_iterator];
					buffer_iterator++;
				}
				currSection->addAttribute(name, value);
				i = 0;
				continue;
			}
			else {
				ignoreSpace = false;
			}
		}
		else {
			if (c != '\n' && needNewLine) {
				continue;
			}
			else if (c == '\n' && needNewLine) {
				needNewLine = false;
				continue;
			}
			if (c == '?' && index == 0) {
				cout << "? == " << countSections(firstBlock) << endl;
				i = 0;
				continue;
			}
			if (c == ',') commas++;
			if (c == ',' || c == '\n') {
				if (c == '\n' && index != 2) continue;
				if (commas >= 3) {
					needNewLine = true;
					commas = 0;
					index = 0;
					i = 0;
					continue;
				}
				opt = Stringify(buffer, i);
				strcpy(tempArr[index], opt.str);

				i = 0;
				index++;
				if(index <= 2) continue;
			}
			if (index > 2) {
				index = 0;
				commas = 0;
				commandManager(tempArr[0], tempArr[1][0], tempArr[2], firstBlock);
				continue;
			}
		}
		i++;
	}
	while (c != EOF);

	return 0;
}