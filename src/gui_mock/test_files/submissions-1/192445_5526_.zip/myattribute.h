#include "mystring.h"
#pragma once

class MyAttribute {
public:
	MyString* Name;
	MyString* Value;
};
