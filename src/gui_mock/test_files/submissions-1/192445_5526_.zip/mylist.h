#pragma once
template <class T>
class MyList
{
private: int delta = 4;
	   int capasity;
	   int size;
	   T** array;

public:

	MyList()
	{
		size = 0;
		capasity = 2 * delta;
		array = new T * [8];
	}

	~MyList()
	{
		delete[] array;
	}

	void Add(T* element)
	{
		if (capasity < size + 1)
		{
			capasity += delta;
			T** newArray = new T * [capasity];
			for (int i = 0; i < size; i++)
			{
				newArray[i] = array[i];
			}
			array = newArray;
		}
		array[size] = element;
		size++;
	}

	void Del(int idElement)
	{
		array[idElement] = array[size-1];
		size--;
	}


	int GetSize()
	{
		return size;
	}
	
	T* GetElement(int index) 
	{
		if (index + 1 > size)
		{
			return nullptr;
		}
		return array[index];
	}

};