#include <iostream>

#pragma once
class MyString
{
public:
	MyString();
	MyString(int size);  // Default constructor
	MyString(const char* s);  // Constructor with char* parameter
	~MyString();  // Destructor

	int size() const;  // Member function: size
	bool find(const char substr);
	MyString* Substr(int pos, int len) const;
	void AddWithOutEndLine(MyString* inStr);
	char** Split(char element);

	bool Compare(MyString* other);  // Member function: operator==
	char& operator[](int index);
	char* GetValue();
	void Trim();
	bool IsEmptyLine();
private:
	int length;
	char* str;

};

