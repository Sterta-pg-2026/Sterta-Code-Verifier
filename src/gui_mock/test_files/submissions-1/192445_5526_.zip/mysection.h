#include "mystring.h"
#include "mylist.h"
#include "myattribute.h"
#include "myattribute.h"
#pragma once

class MySection
{

public:
	MySection()
	{
		Selectors = new MyList<MyString>();
		Attributes = new MyList<MyAttribute>();
	}

	void AddSelector(MyString* selector)
	{
		for (int i = 0; i < Selectors->GetSize(); i++)
		{
			if (selector->Compare(Selectors->GetElement(i)))
			{
				return;
			}
		}

		Selectors->Add(selector);
	}

	void AddAttribute(MyAttribute* attribute)
	{
		for (int i = 0; i < Attributes->GetSize(); i++)
		{
			MyAttribute* val = Attributes->GetElement(i);
			if (attribute->Name->Compare(val->Name))
			{
				val->Value = attribute->Value;
				return;
			}
		}

		Attributes->Add(attribute);
	}

	int GetCountSelectors(MyString* str)
	{
		int countElement = 0;
		if (str == nullptr)
		{
			return Selectors->GetSize();
		}
		for (int i = 0; i < Selectors->GetSize(); i++)
		{
			if (str->Compare(Selectors->GetElement(i)))
			{
				countElement++;
			}
		}
		return countElement;
	}

	MyString* GetValueAttributes(MyString* str)
	{
		for (int i = 0; i < Attributes->GetSize(); i++)
		{
			MyAttribute* val = Attributes->GetElement(i);
			if (str->Compare(val->Name))
			{
				return val->Value;
			}
		}
		return nullptr;
	}

	int GetCountAttributes(MyString* str)
	{
		int countElement = 0;
		if (str == nullptr)
		{
			return Attributes->GetSize();
		}
		for (int i = 0; i < Attributes->GetSize(); i++)
		{
			MyAttribute* val = Attributes->GetElement(i);
			
			if (str->Compare(val->Name))
			{
				countElement++;
			}
		}
		return countElement;
	}

	MyString* GetValueSelectors(int index)
	{
		return Selectors->GetElement(index);
	}

	bool GetValueSelectors(MyString* name)
	{
		for (int i = 0; i < Selectors->GetSize(); i++)
		{
			if (name->Compare(Selectors->GetElement(i)))
			{
				return true;
			}
		}
		return false;
	}

	MyString* GetValueAttribute(MyString* key)
	{
		for (int i = 0; i < Attributes->GetSize(); i++)
		{
			MyAttribute* val = Attributes->GetElement(i);
			if (key->Compare(val->Name))
			{
				return val->Value;
			}
		}

		return nullptr;
	}

	bool DeleteAttributes(MyString* str)
	{
		for (int i = 0; i < Attributes->GetSize(); i++)
		{
			MyAttribute* val = Attributes->GetElement(i);
			
			if (str->Compare(val->Name))
			{
				Attributes->Del(i);
				return true;
			}
		}
		return false;
	}

	MyString* GetSelector()
	{
		if (Selectors->GetSize() == 0)
		{
			return new MyString("---");
		}
		return Selectors->GetElement(0);
	}
private:
	MyList<MyString>* Selectors;
	MyList<MyAttribute>* Attributes;
};