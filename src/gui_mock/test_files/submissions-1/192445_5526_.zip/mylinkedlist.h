#pragma once
#include "mysection.h"

template <typename T>
class MyNode
{
private: MyNode<T>* previous;
	   MyNode<T>* next;
	   T* value;

public: MyNode(T* element, MyNode<T>* previous)
{
	this->previous = previous;
	next = nullptr;
	value = element;
}

	  void AddNext(MyNode<T>* nextElement)
	  {
		  next = nextElement;
	  }

	  void AddPrevious(MyNode<T>* previousElement)
	  {
		  previous = previousElement;
	  }

	  T* GetValue()
	  {
		  return value;
	  }

	  MyNode<T>* GetNext()
	  {
		  return next;
	  }
	  MyNode<T>* GetPrevious()
	  {
		  return previous;
	  }
};

class MyLinkedList
{
private: MyNode<MySection>* first;
	   MyNode<MySection>* end;
	   int count;
public:
	MyLinkedList() {
		first = nullptr;
		end = nullptr;
		count = 0;
	}

	void AddLast(MySection* value) {
		count++;
		if (first == nullptr)
		{
			first = new MyNode<MySection>(value, nullptr);
			return;
		}

		if (end == nullptr)
		{
			end = new MyNode<MySection>(value, first);
			first->AddNext(end);
			return;
		}

		MyNode<MySection>* newEnd = new MyNode<MySection>(value, end);
		end->AddNext(newEnd);
		end = newEnd;
	}

	int Count() const
	{
		return count;
	}

	MySection* GetSection(int idT)
	{
		if (count < idT)
		{
			return nullptr;
		}

		MyNode<MySection>* result = first;

		while (idT > 1)
		{
			if (result == nullptr)
				return nullptr;
			result = result->GetNext();
			idT--;

		}
		if (result == nullptr)
			return nullptr;
		return result->GetValue();
	}

	int GetCountSelectors(MyString* strIn) const
	{
		MyNode<MySection>* current = first;
		int countElement = 0;
		while (current != nullptr)
		{
			MySection* v = current->GetValue();
				countElement = countElement + v->GetCountSelectors(strIn);
				current = current->GetNext();
		}
		return countElement;
	}

	int GetCountAttributes(MyString* strIn) const
	{
		MyNode<MySection>* current = first;
		int countElement = 0;
		int count1 = 0;
		while (current != nullptr)
		{
			MySection* v = current->GetValue();
				countElement = countElement + v->GetCountAttributes(strIn);
				current = current->GetNext();
				count1++;
		}
		return countElement;
	}

	MyString* GetValueAttribute(MyString* selectorName, MyString* attributeName)
	{
		MyNode<MySection>* current = first;
		MyString* valueAttrtebute = nullptr;
		while (current != nullptr)
		{
			MySection* v = current->GetValue();
			if (v->GetValueSelectors(selectorName))
			{
				MyString* temp = v->GetValueAttributes(attributeName);
				if (temp != nullptr)
				{
					valueAttrtebute = temp;
				}
			}
			current = current->GetNext();
		}

		return valueAttrtebute;
	}

	bool DeleteElement(int idElement)
	{
		if (idElement < 1 || first == nullptr)
		{
			return false;
		}
		if (idElement == 1)
		{
			MyNode<MySection>* temp = first->GetNext();
			delete first;
			first = temp;
			if (first == nullptr)
			{
				count--;
				return true;
			}
			first->AddPrevious(nullptr);
			count--;
			return true;
		}

		MyNode<MySection>* current = first;
		idElement--;

		while (current != nullptr)
		{
			if (idElement == 0)
			{
				MyNode<MySection>* previous = current->GetPrevious();
				MyNode<MySection>* next = current->GetNext();
				previous->AddNext(next);
				if (next != nullptr)
				{
					next->AddPrevious(previous);
				}
				delete current;
				if (next == nullptr)
				{
					end = previous;
				}
				count--;
				return true;
			}
			current = current->GetNext();
			idElement--;
		}
		return false;
	}

	bool DeleteAttribute(int idElement, MyString* nameAttribute)
	{
		if (idElement < 1 || first == nullptr)
		{
			return false;
		}
		int delId = idElement;
		MyNode<MySection>* current = first;
		idElement--;
		while (current != nullptr)
		{
			if (idElement == 0)
			{
				MySection* v = current->GetValue();
				if (v == nullptr) return false;

				bool res = v->DeleteAttributes(nameAttribute);
				if (!res) return false;
				
				if (v->GetCountAttributes(nullptr) == 0)
				{
					return DeleteElement(delId);
				}
				return true;
			}
			current = current->GetNext();
			idElement--;
		}
		return false;
	}
};
