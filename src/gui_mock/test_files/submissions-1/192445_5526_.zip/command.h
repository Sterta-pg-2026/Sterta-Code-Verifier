#pragma once
#include "mystring.h"
class Command
{
private :	char* first;
	char command;
	char* second;

public: Command(MyString* inStr)
{

}
};

