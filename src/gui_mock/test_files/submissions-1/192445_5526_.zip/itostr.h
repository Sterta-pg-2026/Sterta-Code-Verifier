#pragma once

int mx_strlen(const char* str) {
	int count = 0;

	while (*str != '\0') {
		str++;
		count++;
	}
	return count;
}
void mx_swap_char(char* s1, char* s2) {
	char temp = *s1;
	*s1 = *s2;
	*s2 = temp;
}
void mx_str_reverse(char* s) {
	if (s == nullptr) return;

	int len = mx_strlen(s);

	if (len <= 1) return;

	int centre = (len - (len % 2 == 0 ? 0 : 1)) / 2;

	for (int i = 0; i < centre; i++)
		mx_swap_char(&s[i], &s[len - 1 - i]);
}
static int mx_int_len(int number) {
	int len = 0;

	if (number < 0) {
		number *= -1;
		len++;
	}

	while (number > 0) {
		number /= 10;
		len++;
	}

	return len;
}
char* mx_strnew(const int size) {
    if (size < 0) return nullptr;

    char* string = new char[size + 1];

    for (int i = 0; i <= size+1; i++) string[i] = '\0';

    return string;
}
char* mx_itoa(int number) {
	if (number == -2147483648)
	{
		return new char[12]("-2147483648");
	}

	if (number == 0)
	{
		return new char[2]("0");
	}
	char* ascii = nullptr;


	int pow = number < 0 ? -1 : 1;
	int len = mx_int_len(number);
	ascii = mx_strnew(len);

	if (number < 0) ascii[--len] = '-';

	for (int i = number; i >= 10 || i <= -10; i /= 10) pow *= 10;

	while (pow != 0) {
		ascii[--len] = 48 + number / pow;
		number %= pow;
		pow /= 10;
	}

	mx_str_reverse(ascii);

	return ascii;
}