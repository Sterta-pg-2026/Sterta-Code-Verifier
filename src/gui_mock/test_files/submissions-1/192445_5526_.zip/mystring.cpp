#include <iostream>
#include "mystring.h"
#pragma once

MyString::MyString()
{
	str = new char[1];
	length = 0;
	str[0] = '\0';
}

MyString::MyString(int size) {
	str = new char[size + 1];
	length = size;
	str[0] = '\0';
}

MyString::MyString(const char* s) {
	length = 0;
	while ((s[length]) != '\0') {
		length++;
	}
	str = new char[length + 1];
	for (int i = 0; i < length; i++) {
		str[i] = s[i];
	}
	str[length] = '\0';
}

MyString::~MyString() {
	delete[] str;
}

int MyString::size() const {
	return length;
}

bool MyString::find(const char substr)
{
	for (int i = 0; i <= this->length; i++) {
		if (str[i] == substr) {
			return true;
		}
	}
	return false;
}

bool MyString::Compare(MyString* other) {
	if (length != other->length) {
		return false;
	}
	for (int i = 0; i < length; i++) {
		if (str[i] != other->str[i]) {
			return false;
		}
	}
	return true;
}

MyString* MyString::Substr(int pos, int len) const {
	if (pos < 0 || pos >= length || len <= 0) {
		return new MyString(0);
	}
	if (pos + len > length) {
		len = length - pos;
	}
	MyString* result = new MyString(len);
	for (int i = 0; i < len; i++) {
		result->str[i] = str[pos + i];
	}
	result->str[len] = '\0';
	return result;
}

void MyString::AddWithOutEndLine(MyString* inStr)
{
	char* newStr = new char[length + inStr->length + 1];
	int i = 0;
	int j = 0;

	while ((this->str[i]) != '\0') {

		if (((this->str[i]) == '\n') ||
			((this->str[i]) == '\r'))
		{
			i++;
			continue;
		}

		newStr[j] = this->str[i];
		i++; j++;
	}
	i = 0;
	while ((inStr->str[i]) != '\0') {
		if (((inStr->str[i]) == '\n') ||
			((inStr->str[i]) == '\r'))
		{
			i++;
			continue;
		}

		newStr[j] = inStr->str[i];
		i++; j++;
	}
	newStr[j] = '\0';
	length = j;
	delete str;
	str = newStr;
}

char** MyString::Split(char element)
{
	int index = 0;
	int start = 0;
	char** mass = new char* [3];
	for (int i = 0; i < length; i++)
	{
		if (str[i] == element)
		{
			mass[index] = Substr(start, i - start)->str;
			index++;
			start = i + 1;
		}
	}
	mass[index] = Substr(start, length - start)->str;
	return mass;
}

char& MyString::operator[](int index) {
	return str[index];
}

char* MyString::GetValue()
{
	return str;
}

void MyString::Trim()
{
	int delta = 0;
	for (int i = 0; i < length; i++)
	{
		if (!((str[i] == ' ') || (str[i] == '\t')))
		{
			break;
		}
		delta++;
	}
	if (delta > 0)
	{
		int j = 0;
		for (int i = delta; i < length; i++)
		{
			str[j] = str[i];
			j++;
		}
		length -= delta;
		str[length] = '\0';
	}
	delta = 0;
	for (int i = length-1; i > -1; i--)
	{
		if (str[i] != ' ')
		{
			break;
		}
		delta++;
	}
	if (delta > 0)
	{
		length -= delta;
		str[length] = '\0';
	}
}

bool MyString::IsEmptyLine()
{
	for (int i = 0; i < length; i++)
	{
		if (str[i] != ' ')
		{
			return false;
		}
	}
	return true;
}
