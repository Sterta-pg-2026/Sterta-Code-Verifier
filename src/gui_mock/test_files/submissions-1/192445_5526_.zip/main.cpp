#include <iostream>
#include "mystring.h"
#include "mysection.h"
#include "mylinkedlist.h"
#include "itostr.h"

using namespace std;

MySection* GetSection(MyString* str)
{
	MySection* section = new MySection();
	bool isSelector = false;
	bool isSection = false;
	MyAttribute* val = nullptr;
	int startElementIndex = 0;
	for (int i = 0; i < str->size(); i++)
	{
		char element = (*str)[i];

		if ((element == ',') && (!isSection))
		{
			MyString* newStr = str->Substr(startElementIndex, i - startElementIndex);
			newStr->Trim();
			if (newStr->size() != 0) {
				section->AddSelector(newStr);
			}
			startElementIndex = i + 1;
			continue;
		}
		if (element == '{')
		{
			MyString* newStr = str->Substr(startElementIndex, i - startElementIndex);
			newStr->Trim();
			if (newStr->size() != 0) {
				section->AddSelector(newStr);
			}
			startElementIndex = i + 1;
			isSection = true;
			continue;
		}
		if (element == '}')
		{
			break;
		}
		if ((element == ':') && isSection)
		{
			val = new MyAttribute();
			MyString* newStr = str->Substr(startElementIndex, i - startElementIndex);
			newStr->Trim();
			val->Name = newStr;

			startElementIndex = i + 1;
			continue;
		}
		if (element == ';')
		{
			MyString* newStr = str->Substr(startElementIndex, i - startElementIndex);
			newStr->Trim();

			val->Value = newStr;
			isSelector = false;
			section->AddAttribute(val);
			startElementIndex = i + 1;
			continue;
		}
	}

	return section;
}

int main()
{
	MyString* twoEquals = new MyString(" == ");
	MyString* deleted = new MyString("deleted");
	MyString* cssStart = new MyString("****");
	MyString* cssEnd = new MyString("????");
	MyString* commandCountSections = new MyString("?");

	MyList< MyString>* resultList = new MyList< MyString>();

	MyLinkedList* linkedList = new MyLinkedList();
	int i = 0;
	int const lineSize = 5000;

	MyString* strElement = new MyString();
	bool isCss = true;
	char line[lineSize];

	while (cin.getline(line, lineSize))
	{
		MyString* str = new MyString(line);

		if (str->size() == 0)
		{
			continue;
		}
		/*if (str->Compare(new MyString("----")))
		{
			break;
		}*/


		if (str->Compare(cssStart))
		{
			isCss = true;
			continue;
		}

		if (str->Compare(cssEnd))
		{
			isCss = false;
			continue;
		}

		if (isCss)
		{
			strElement->AddWithOutEndLine(str);

			if (strElement->find('}'))
			{
				MySection* v = GetSection(strElement);
				linkedList->AddLast(v);
				strElement = new MyString();
			}
		}
		else
		{
			if (str->Compare(commandCountSections))
			{
				str->AddWithOutEndLine(twoEquals);
				str->AddWithOutEndLine(new MyString(mx_itoa(linkedList->Count())));
				resultList->Add(str);

				continue;
			}
			
			if (str->IsEmptyLine())
			{
				continue;
			}

			char** command = str->Split(',');

			if (command[1][0] == 'S')
			{
				char* second = command[2];
				char* first = command[0];

				if (second[0] == '?')
				{
					int s = atoi(first);

					if (s > 0)
					{
						if (s == 14)
						{
							cout << "";
						}
						MySection* v = linkedList->GetSection(s);
						if (v != nullptr)
						{
							str->AddWithOutEndLine(twoEquals);
							str->AddWithOutEndLine(new MyString(mx_itoa(v->GetCountSelectors(nullptr))));
							//str->AddWithOutEndLine(v->GetSelector());
							resultList->Add(str);
						}
					}
					else {
						str->AddWithOutEndLine(twoEquals);
						str->AddWithOutEndLine(new MyString(mx_itoa(linkedList->GetCountSelectors(new MyString(first)))));
						resultList->Add(str);
					}
				}
				else {
					int f = atoi(first);
					int s = atoi(second);
					

					if (f > 0 && s > 0)
					{
						MySection* v = linkedList->GetSection(f);
						if (v != nullptr)
						{
							MyString* val = v->GetValueSelectors(s - 1);
							if (val != nullptr) {
								str->AddWithOutEndLine(twoEquals);
								str->AddWithOutEndLine(val);
								resultList->Add(str);
							}
						}
					}
				}
			}

			if (command[1][0] == 'A')
			{
				char* second = command[2];
				char* first = command[0];

				if (second[0] == '?')
				{
					int s = atoi(first);

					if (s > 0)
					{
						MySection* v = linkedList->GetSection(s);
						if (v != nullptr)
						{
							str->AddWithOutEndLine(twoEquals);
							str->AddWithOutEndLine(new MyString(mx_itoa(v->GetCountAttributes(nullptr))));
							resultList->Add(str);
						}
					}
					else {
						str->AddWithOutEndLine(twoEquals);
						str->AddWithOutEndLine(new MyString(mx_itoa(linkedList->GetCountAttributes(new MyString(first)))));
						resultList->Add(str);
					}
				}
				else {
					int f = atoi(first);
					if (f > 0)
					{
						MySection* v = linkedList->GetSection(f);
						if (v != nullptr)
						{
							MyString* newStr = v->GetValueAttribute(new MyString(second));
							if (newStr != nullptr)
							{
								str->AddWithOutEndLine(twoEquals);
								str->AddWithOutEndLine(newStr);
								resultList->Add(str);
							}
						}
					}
				}
			}

			if (command[1][0] == 'E')
			{
				char* nameAttrebute = command[2];
				char* selector = command[0];

				MyString* newStr = linkedList->GetValueAttribute(new MyString(selector), new MyString(nameAttrebute));
				if (newStr != nullptr)
				{
					str->AddWithOutEndLine(twoEquals);
					str->AddWithOutEndLine(newStr);
					resultList->Add(str);
				}
			}

			if (command[1][0] == 'D')
			{
				bool isDone = false;
				int f = atoi(command[0]);
				if (command[2][0] == '*')
				{
					if (f > 0)
					{
						isDone = linkedList->DeleteElement(f);
					}
				}
				else
				{
					char* nameAttrebute = command[2];
					if (f > 0)
					{
						isDone = linkedList->DeleteAttribute(f, new MyString(nameAttrebute));
					}
				}
				if (isDone) {
					str->AddWithOutEndLine(twoEquals);
					str->AddWithOutEndLine(deleted);
					resultList->Add(str);
				}
			}
		}
	}

	for (int k = 0; k < resultList->GetSize(); k++)
	{
		cout << resultList->GetElement(k)->GetValue() << "\n";
	}
}
