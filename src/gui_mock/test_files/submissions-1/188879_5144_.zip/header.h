#pragma once
#include <iostream>
#include <stdint.h>
#include <initializer_list>
#define INPUTSIZE 64
