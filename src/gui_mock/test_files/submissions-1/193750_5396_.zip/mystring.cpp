#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "mystring.h"
#define MAX_CHAR 1000
MyString::MyString(const char* s)
{
    size = 0;
    while (s[size] != '\0') {
        size++;
    }
    data = new char[size + 1];
    for (int i = 0; i < size; i++) {
        data[i] = s[i];
    }
    data[size] = '\0';
}

void MyString::push_back(char c) {
    char* new_data = new char[size + 2];
    for (int i = 0; i < size; i++) {
        new_data[i] = data[i];
    }
    new_data[size] = c;
    new_data[size + 1] = '\0';
    if (data)
        delete[] data;
    data = new_data;
    size++;
}


bool MyString::operator==(const MyString& s2) const {
    return strcmp(data, s2.data) == 0;
}

bool MyString::operator==(const char* s2) const {
	return strcmp(data, s2) == 0;
}


void MyString::clear() {
    size = 0;
    delete[] data;
    data = nullptr;
}

MyString* MyString::split(const char del)
{
	int length = this->count(del);
	MyString* result = new MyString[length+1];

	int which = 0;

	for (int i = 0; i < size; i++)
	{
		if (data[i] == del) {
			result[which].strip();
			which++;
			continue;
		}
			result[which].push_back(data[i]);
	}
	result[which].strip();
	return result;
}

void MyString::strip()
{
	int removeFirst = 0;
	int removeLast = 0;
	for (int i = 0; i < size; i++)
	{
		const char* res = strchr(" \n\t", data[i]);
		if (res)
		{
			removeFirst++;
		}
		else
			break;
	}

	for (int i = 0; i < removeFirst; i++)
	{
		this->removeFirst();
	}
	for (int i = 0; i < size; i++)
	{
		if (data[size - 1 - i] == ' ' || data[size - 1 - i] == '\n')
		{
			removeLast++;
		}
		else
			break;
	}
	data[size - removeLast] = '\0';
	size -= removeLast;
}

void MyString::removeFirst()
{
	if (size > 0) {
		char* new_data = new char[size]; // allocate new array with one less element
		for (int i = 1; i < size; i++) {
			new_data[i - 1] = data[i]; // copy all but the first element to the new array
		}
		delete[] data; // deallocate old array
		data = new_data; // set member variable to new array
		size--; // decrement size
	}
}

int MyString::count(char c) const {
	int count = 0;
	for (int i = 0; i < size; i++) {
		if (data[i] == c) {
			count++;
		}
	}
	return count;
}

char MyString::operator[](int s) const
{
	return data[s];
}

MyString& MyString::operator=(const MyString& other) {
	if (this == &other) {
		return *this;
	}
	if (data)
		delete[] data; // deallocate old data
	size = other.size;
	data = new char[size + 1];
	strcpy(data, other.data);
	data[size] = '\0';
	return *this;
}

int MyString::toInt()
{
	int result = 0;
	int i = 0;
	while (data[i] != '\0') {
		int digit = data[i] - '0';
		result = result * 10 + digit;
		i++;
	}
	return result;
}

int MyString::getSize() const
{
	return size;
}