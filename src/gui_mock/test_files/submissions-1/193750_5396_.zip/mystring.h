#pragma once
#include <iostream>

using namespace std;

class MyString {
    char* data;
    int size;
public:
    MyString() : data(nullptr), size(0) {}
    MyString(const char* s);

    void push_back(char c);

    bool operator==(const MyString& s2) const;

    bool operator==(const char* s2) const;

    void clear();

    MyString* split(const char del);

    void strip();

    void removeFirst();

    int count(char c) const;

    char operator[](int s) const;

    MyString& operator=(const MyString& other);

    int toInt();

    int getSize() const;

    ~MyString() { 
        if (data) 
            delete[] data; 
        data = nullptr;
    };

    friend ostream& operator<<(ostream& out, const MyString& s) { return out << s.data; };
};