#define _CRT_SECURE_NO_WARNINGS
#define T 17
#define MAX_CHAR 1000

#include <iostream>
#include "mystring.h"
#include <ctype.h>



typedef struct _AtributeNode
{
	MyString name;
	MyString value;
	struct _AtributeNode* next;
	_AtributeNode() : next(nullptr) {}
} AtributeNode;

typedef struct
{
	AtributeNode* head, * tail;
} AtributeList;

typedef struct _SelectorNode
{
	MyString name;
	struct _SelectorNode* next;
	_SelectorNode() : next(nullptr) {}
} SelectorNode;

typedef struct
{
	SelectorNode* head, * tail;
} StructureList;

typedef struct _StrukturaCSS
{
	//lista stringow, gdzie kazdy element to jeden selektor
	StructureList* selektory;
	//lista atrybutow
	AtributeList* atrybuty;
	int iloscAtrybutow;
	int iloscSelektorow;

} StrukturaCSS;

typedef struct _Node
{
	StrukturaCSS* tablica[T];
	int zajete;
	struct _Node* prev;
	struct _Node* next;

} Node;

typedef struct _Lista
{
	Node* head;
	Node* tail;
}Lista;

void printStructure(StrukturaCSS* struktura)
{
	cout << "Selektory: ";
	SelectorNode* tmpSelector = struktura->selektory->head;
	while (tmpSelector)
	{
		cout << tmpSelector->name << ", ";
		tmpSelector = tmpSelector->next;
	}
	cout << endl << "Atrybuty:" << endl;

	AtributeNode* tmpAtribute = struktura->atrybuty->head;
	while (tmpAtribute)
	{
		cout << "\t" << tmpAtribute->name << " : " << tmpAtribute->value << endl;
		tmpAtribute = tmpAtribute->next;
	}
}


StructureList* initStructureList()
{
	StructureList* list = new StructureList;
	list->head = list->tail = nullptr;
	return list;
}

AtributeList* initAtributeList()
{
	AtributeList* list = new AtributeList;
	list->head = list->tail = nullptr;
	return list;
}

StrukturaCSS* initStrukturaCSS() {
	StrukturaCSS* tmp = new StrukturaCSS;
	tmp->selektory = initStructureList();
	tmp->atrybuty = initAtributeList();
	tmp->iloscAtrybutow = 0;
	tmp->iloscSelektorow = 0;
	return tmp;
}

Node* initNode() {
	Node* tmp = new Node;
	tmp->next = tmp->prev = nullptr;
	tmp->zajete = 0;
	for (int i = 0; i < T; i++) {
		tmp->tablica[i] = nullptr;
	}
	return tmp;
}

Lista* initList() {
	Lista* tmp = new Lista;
	tmp->head = tmp->tail = initNode();
	return tmp;
}

AtributeNode* initAtributeNode(MyString* name, MyString* value) {
	AtributeNode* tmp = new AtributeNode;
	tmp->name = *name;
	tmp->value = *value;
	tmp->next = nullptr;
	return tmp;
}

SelectorNode* initSelectorNode(MyString& name) {
	SelectorNode* tmp = new SelectorNode;
	tmp->name = name;
	tmp->next = nullptr;
	return tmp;
}

bool checkSelectorRepetition(SelectorNode* selector, StrukturaCSS* struktura)
{
	SelectorNode* tmpselector = struktura->selektory->head;
	while (tmpselector)
	{
		if (tmpselector->name == selector->name)
		{
			return true;
		}
		tmpselector = tmpselector->next;
	}
	return false;
}

void addSelector(SelectorNode* selector, StrukturaCSS* struktura) {
	if (struktura->iloscSelektorow == 0)
	{
		struktura->selektory->head = struktura->selektory->tail = selector;
		struktura->iloscSelektorow++;
		return;
	}
	if (checkSelectorRepetition(selector, struktura))
	{
		return;
	}
	struktura->selektory->tail->next = selector;
	struktura->selektory->tail = selector;
	struktura->iloscSelektorow++;

}

// true if repeated, else false
bool checkAtributeRepetition(AtributeNode* atribute, StrukturaCSS* struktura)
{
	AtributeNode* tmpatribute = struktura->atrybuty->head;
	while (tmpatribute)
	{
		if (tmpatribute->name == atribute->name)
		{
			tmpatribute->value = atribute->value;
			return true;
		}
		tmpatribute = tmpatribute->next;
	}
	return false;
}

void addAtribute(AtributeNode* atribute, StrukturaCSS* struktura) {
	if (struktura->iloscAtrybutow == 0)
	{
		struktura->atrybuty->head = struktura->atrybuty->tail = atribute;
		struktura->iloscAtrybutow++;
		return;
	}

	if (checkAtributeRepetition(atribute, struktura))
	{
		return;
	}
	struktura->atrybuty->tail->next = atribute;
	struktura->atrybuty->tail = atribute;
	struktura->iloscAtrybutow++;
	
}

void addNode(Lista* lista)
{
	if (!lista->head)
	{
		lista->head = lista->tail = initNode();
		return;
	}
	Node* newNode = initNode();
	lista->tail->next = newNode;
	newNode->prev = lista->tail;
	lista->tail = newNode;
}

void addStructure(Lista* lista, StrukturaCSS* struktura)
{
	Node* tmpNode = lista->head;
	if (tmpNode == nullptr)
	{
		addNode(lista);
		tmpNode = lista->head;
	}
	while (tmpNode)
	{
		for (int i = 0; i < T; i++)
		{
			if (tmpNode->tablica[i] == nullptr)
			{
				tmpNode->tablica[i] = struktura;
				tmpNode->zajete++;
				return;
			}
		}
		tmpNode = tmpNode->next;
	}
	addNode(lista);
	lista->tail->tablica[0] = struktura;
	lista->tail ->zajete++;
}

void numOfStructures(Lista* lista)
{
	Node* tmpNode = lista->head;
	int counter = 0;
	while (tmpNode)
	{
		counter += tmpNode->zajete;
		tmpNode = tmpNode->next;
	}
	cout << "? == " << counter << endl;
}

void numOfSelectorsForStructure(Lista* lista, MyString& number)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}
			
		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}
	cout << index << ",S,? == " << tmpNode->tablica[correctIndex]->iloscSelektorow << endl;

}

void selectorValueForStructure(Lista* lista, MyString& number, MyString& selector)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}

		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}
	SelectorNode* tmpSelector = tmpNode->tablica[correctIndex]->selektory->head;
	int counter = 1;
	int whichSelector = selector.toInt();
	while (tmpSelector)
	{
		if (counter == whichSelector)
		{
			cout << index << ",S," << whichSelector << " == " << tmpSelector->name << endl;
			return;
		}
		counter++;
		tmpSelector = tmpSelector->next;
	}
}

void numOfSelector(Lista* lista, MyString& selector)
{
	Node* tmpNode = lista->head;
	int counter = 0;
	while (tmpNode)
	{
		for (int i = 0; i < T; i++)
		{
			if (tmpNode->tablica[i])
			{
				SelectorNode* tmpSelector = tmpNode->tablica[i]->selektory->head;
				while (tmpSelector)
				{
					if (selector == tmpSelector->name)
					{
						counter++;
					}
					tmpSelector = tmpSelector->next;
				}
				
			}
		}
		tmpNode = tmpNode->next;
	}
	cout << selector << ",S,? == " << counter << endl;
}

void numOfAtributesForStructure(Lista* lista, MyString& number)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}

		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}
	cout << index << ",A,? == " << tmpNode->tablica[correctIndex]->iloscAtrybutow << endl;
}

void atributeValueForStructure(Lista* lista, MyString& number, MyString& atribute)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}

		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}
	AtributeNode* tmpAtribute = tmpNode->tablica[correctIndex]->atrybuty->head;
	while (tmpAtribute)
	{
		if (tmpAtribute->name == atribute)
		{
			cout << index << ",A," << atribute << " == " << tmpAtribute->value << endl;
			return;
		}
		tmpAtribute = tmpAtribute->next;
	}
}

void numOfAtribute(Lista* lista, MyString& atribute)
{
	Node* tmpNode = lista->head;
	int counter = 0;
	while (tmpNode)
	{
		for (int i = 0; i < T; i++)
		{
			if (tmpNode->tablica[i])
			{
				AtributeNode* tmpAtribute = tmpNode->tablica[i]->atrybuty->head;
				while (tmpAtribute)
				{
					if (atribute == tmpAtribute->name)
					{
						counter++;
					}
					tmpAtribute = tmpAtribute->next;
				}

			}
		}
		tmpNode = tmpNode->next;
	}
	cout << atribute << ",A,? == " << counter << endl;
}

void deleteStructure(StrukturaCSS* structure)
{
	SelectorNode* tmpSelector = structure->selektory->head;
	while (tmpSelector) {
		SelectorNode* next = tmpSelector->next;
		delete tmpSelector;
		tmpSelector = next;
	}
	delete structure->selektory;
	structure->selektory = nullptr;
	structure->iloscAtrybutow = 0;

	// Delete atributes
	AtributeNode* tmpAtribute= structure->atrybuty->head;
	while (tmpAtribute) {
		AtributeNode* next = tmpAtribute->next;
		delete tmpAtribute;
		tmpAtribute = next;
	}
	delete structure->atrybuty;
	structure->atrybuty = nullptr;
	structure->iloscAtrybutow = 0;

	delete structure;

}

void checkEmpty(Node* tmpNode, Lista* lista)
{
	if (tmpNode->zajete == 0)
	{
		if (tmpNode == lista->head)
		{
			lista->head = tmpNode->next;
			if (lista->head)
			{
				lista->head->prev = nullptr;
			}
			delete tmpNode;
			return;
		}
		lista->tail = tmpNode->prev;
		if (lista->tail)
		{
			lista->tail->next = nullptr;
		}
		delete tmpNode;
		return;

	}
}

void removeStructure(Lista* lista, MyString& number)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}

		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}

	deleteStructure(tmpNode->tablica[correctIndex]);
	tmpNode->tablica[correctIndex] = nullptr;
	tmpNode->zajete--;
	checkEmpty(tmpNode, lista);
	cout << index << ",D,* == deleted" << endl;
}

void removeAtribute(Lista* lista, MyString& number, MyString& atribute)
{
	int index = number.toInt();
	int i = 0;
	int correctIndex = -1;
	Node* tmpNode = lista->head;
	while (tmpNode)
	{
		for (int j = 0; j < T; j++)
		{
			if (tmpNode->tablica[j])
			{
				i++;
			}
			if (i == index)
			{
				correctIndex = j;
				break;
			}

		}
		if (correctIndex != -1)
		{
			break;
		}

		tmpNode = tmpNode->next;

	}
	if (correctIndex == -1 || tmpNode == nullptr)
	{
		return;
	}
	AtributeNode* tmpAtribute = tmpNode->tablica[correctIndex]->atrybuty->head;
	if (tmpAtribute)
	{
		if (tmpAtribute->name == atribute)
		{
			tmpNode->tablica[correctIndex]->atrybuty->head = tmpAtribute->next;
			tmpNode->tablica[correctIndex]->iloscAtrybutow--;
			delete tmpAtribute;
			tmpAtribute = nullptr;
		}
	}
	if (tmpAtribute != nullptr)
	{
		while (tmpAtribute->next)
		{
			if (tmpAtribute->next->name == atribute)
			{
				AtributeNode* toDelete = tmpAtribute->next;
				tmpAtribute->next = tmpAtribute->next->next;
				delete toDelete;
				tmpNode->tablica[correctIndex]->iloscAtrybutow--;
				break;
			}
			tmpAtribute = tmpAtribute->next;
		}
	}
	if (tmpNode->tablica[correctIndex]->iloscAtrybutow == 0)
	{
		deleteStructure(tmpNode->tablica[correctIndex]);
		tmpNode->tablica[correctIndex] = nullptr;
		tmpNode->zajete--;
		checkEmpty(tmpNode, lista);
	}
	cout << index << ",D," << atribute << " == deleted" << endl;
}

void atributeValueForSelector(Lista* lista, MyString& selector, MyString& atribute)
{
	StrukturaCSS* last_structure = nullptr;
	Node* tmpNode = lista->head;
	
	while (tmpNode)
	{
		for (int i = 0; i < T; i++)
		{
			if (!tmpNode->tablica[i])
				continue;
			SelectorNode* tmpSelector = tmpNode->tablica[i]->selektory->head;
			while (tmpSelector)
			{
				if (tmpSelector->name == selector)
				{
					last_structure = tmpNode->tablica[i];
				}
				tmpSelector = tmpSelector->next;
			}
		}
		tmpNode = tmpNode->next;
	}
	if (!last_structure)
		return;
	
	AtributeNode* tmpAtribute = last_structure->atrybuty->head;
	while (tmpAtribute)
	{
		if (tmpAtribute->name == atribute)
		{
			cout << selector << ",E," << atribute << " == " << tmpAtribute->value << endl;
			return;
		}
		tmpAtribute = tmpAtribute->next;
	}
}

bool input(Lista* lista)
{
	bool parse = true;
	// parsing structures
	while (parse)
	{
		char ch = getchar();
		if (ch == EOF)
		{
			return false;
		}
		StrukturaCSS* struktura = initStrukturaCSS();

		// parse selectors 
		MyString selector;
		while (ch != '{' && ch != '?')
		{
			if (ch == '\n' || ch == '\t')
			{
				ch = getchar();
				continue;
			}
			if (ch == ',')
			{
				selector.strip();
				addSelector(initSelectorNode(selector), struktura);
				selector.clear();
				ch = getchar(); 
				continue;
			}
			selector.push_back(ch);
			ch = getchar();
		}
		if (ch == '?')
		{
			ch = getchar();
			ch = getchar();
			ch = getchar();
			parse = false;
			break;
		}
		else if (ch == '{')
		{
			if (selector.getSize() != 0)
			{
				selector.strip();
				addSelector(initSelectorNode(selector), struktura);
				selector.clear();	
			}
			ch = getchar();
		}
		MyString atribute;
		while (ch != '}')
		{
			if (ch == '\n'|| ch == '\t')
			{
				ch = getchar();
				continue;
			}
			if (ch == ';')
			{
				atribute.strip();
				MyString* name_value = atribute.split(':');
				addAtribute(initAtributeNode(&name_value[0], &name_value[1]), struktura);
				ch = getchar();
				atribute.clear();
				continue;
			}
			atribute.push_back(ch);
			ch = getchar();
		}
		if (ch == '}')
		{
			addStructure(lista, struktura);
		}
	}

	while (!parse)
	{
 		char ch = getchar();
		if (ch == EOF)
		{
			return false;
		}
		if (isspace(ch))
		{
			continue;
		}
		if (ch == '?')
		{
			numOfStructures(lista);
			continue;
		}
		if (ch == '*')
		{
			ch = getchar();
			ch = getchar();
			ch = getchar();
			parse = true;
			break;
		}
		MyString command;
		while (ch != '\n' && ch != EOF)
		{
			command.push_back(ch);
			ch = getchar();
		}
		if (command.count(',') != 2 || command.count(' ') != 0)
		{
			continue;
		}
		MyString* splitted = command.split(',');
		MyString* first = splitted;
		MyString* second = splitted+ 1;
		MyString* third = splitted + 2;
		
		if (*second == "S") {
			if ((*first)[0] - '0' <= 9 && (*first)[0] - '0' >= 0) {
				if (*third == "?")
				{
					numOfSelectorsForStructure(lista, *first);
				}
				else
				{
					selectorValueForStructure(lista, *first, *third);
				}
			}
			else {
				numOfSelector(lista, *first);
			}
		}
		else if (*second == "A") {
			if ((*first)[0] - '0' <= 9 && (*first)[0] - '0' >= 0) {
				if (*third == "?")
				{
					numOfAtributesForStructure(lista, *first);
				}
				else {
					
					atributeValueForStructure(lista, *first, *third);
				}
			}
			else
			{
				numOfAtribute(lista, *first);
			}
		}
		else if (*second == "D") {
			if ((*first)[0] - '0' <= 9 && (*first)[0] - '0' >= 0) {
		
				if (*third == "*")
				{
					removeStructure(lista, *first);
				}
				else
				{
					removeAtribute(lista, *first, *third);
				}
			}
		}
		else if (*second == "E") {
			atributeValueForSelector(lista, *first, *third);
		}
		delete[] splitted;
		splitted = nullptr;
		if (ch == EOF)
		{
			return false;
		}
	}
	return true;
}



int main()
{

	Lista* list = initList();
	while (true)
		if (!input(list)) return 0;
	return 0;
}