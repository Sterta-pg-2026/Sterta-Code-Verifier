#ifndef TEXTCLASS_H
#define TEXTCLASS_H
#include <iostream>
using namespace std;

#define PLUS0 1
#define ALLOCATELENGTH length+PLUS0


class Text {
private:
	char* string;
	int length;
	friend ostream& operator<<(ostream& ostr, const Text& string);
public:
	Text();
	Text(const char* string);
	Text(const Text& other); // copy constructor

	char* getString();
	int getLength(const char* string) const;
	int getLength() const;

	int convertToInt();

	void operator=(const Text& right); 
	const char operator[](int index) const;
	bool operator==(const Text& right) const;
	bool operator!=(const Text& right) const;
	Text operator+(const Text& right) const; // za appenda

	~Text();
};

int power(int number, int power);

#endif // !TEXT_H
