#include "textclass.h"

using namespace std;

Text::Text() {
	string = nullptr;
	length = NULL;
}

Text::Text(const char* string) {
	if (string != nullptr) {
		length = getLength(string);
		this->string = new char[ALLOCATELENGTH];
		for (int i = 0; i < ALLOCATELENGTH; i++) {
			this->string[i] = string[i];
		}
	}
}

Text::Text(const Text& other) { 
	if (other.string != nullptr) {
		length = other.length;
		string = new char[ALLOCATELENGTH];
		for (int i = 0; i < ALLOCATELENGTH; i++) {
			string[i] = other[i];
		}
	}
}

char* Text::getString() {
	return string;
}

int Text::getLength(const char* string) const { // counting length
	if (string != nullptr) {
		int lengthOfString = 0;
		while (string[lengthOfString] != '\0') {
			lengthOfString++;
		}
		return lengthOfString;
	}
	else return 0;
}

int Text::getLength() const {
	return length;
}

int Text::convertToInt() { // converting string to int
	int stringAsInt = 0;
	for (int i = 0; i < length; i++) {
		if ('0' <= string[i] && string[i] <= '9') {
			stringAsInt += int(string[i] - '0') * power(10, length - 1 - i);
		}
		else {
			return -1;
		}
	}
	return stringAsInt;
}

void Text::operator=(const Text& right) {	// assigning	
	if (this == nullptr) return;
	int newLength = right.length;
	if (string != nullptr) delete[] string;
	string = new char[newLength + PLUS0];
	length = newLength;
	for (int i = 0; i < newLength + PLUS0; i++) { 
		string[i] = right.string[i];
	}
}

ostream& operator<<(ostream& out, const Text& string) { // printing
	if (string.getLength() > 0) {
		out << string.string;
	}
	return out;
}

const char Text::operator[](int index) const { // get given char
	if (0 <= index && length >= index) {
		return this->string[index];
	}
	return NULL; 
}

bool Text::operator==(const Text& right) const { // if equal
	if (length == right.length) {
		int i = 0;
		while (string[i] != '\0' && right.string[i] != '\0') {
			if (string[i] != right.string[i]) return false;
			i++;
		}
		return true;
	}
	else {
		return false;
	}
}

bool Text::operator!=(const Text& right) const { // if different
	if (length == right.length) {
		int i = 0;
		while (string[i] != '\0' && right.string[i] != '\0') {
			if (string[i] != right.string[i]) return true;
			i++;
		}
		return false;
	}
	else {
		return true;
	}
}

Text Text::operator+(const Text& right) const { // appending to string
	if (string != nullptr) {
		int newLength = right.length + length;
		char* newString = new char[newLength + PLUS0];
		int j = 0;
		for (int i = 0; i < newLength + PLUS0; i++) {
			if (i < length) newString[i] = string[i];
			else newString[i] = right.string[j], j++;
		}
		Text newText = newString;
		return newText;
	}
	return NULL;
}

Text::~Text() {
	if (string != nullptr) delete[] string;
	length = NULL;
}

int power(int number, int power) { // power function 
	if (power == 0) return 1;
	else {
		int finalNumber = 1;
		for (int i = 0; i < power; i++) finalNumber *= number;
		return finalNumber;
	}
}