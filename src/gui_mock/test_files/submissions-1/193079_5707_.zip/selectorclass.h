#ifndef SELECTORCLASS_H
#define SELECTORCLASS_H
#define EMPTYTEXT ""
#include "textclass.h"
#include <iostream>



class Selector {
private:
	Text name;
	Selector* next;
public:
	Selector();
	Selector(Text& name);
	Selector(Text& name, Selector* next);

	int countSelectors();
	Selector* findSelector(Text& name); 
	Selector* findTail();

	void setName(Text& name);
	void setNext(Selector* next);

	Text getName(int numberInOrder);
	Text getName() const;
	Selector* getNext() const;

	void addSelector(Text& name);
	void removeSelector(Text& name);

	~Selector();
};

#endif // !SELECTORCLASS_H

