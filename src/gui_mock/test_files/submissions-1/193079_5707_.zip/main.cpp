#pragma warning(disable : 4996)

#include "segmentclass.h"
using namespace std;


int main() {

	runTheCSSEngine();
	
	return 0;
}
