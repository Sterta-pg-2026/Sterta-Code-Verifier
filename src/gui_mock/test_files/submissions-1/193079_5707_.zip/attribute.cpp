#include "attributeclass.h"
using namespace std;

Attribute::Attribute() {
	this->next = nullptr;
	this->previous = nullptr;
}

Attribute::Attribute(Text& name) {
	setName(name);

	this->next = nullptr;
	this->previous = nullptr;
}

Attribute::Attribute(Text& name, Text& value) {
	setName(name);
	setValue(value);

	this->next = nullptr;
	this->previous = nullptr;
}

Attribute::Attribute(Text& name, Attribute* previous) {
	setName(name);

	this->next = nullptr;
	this->previous = previous;
}

Attribute::Attribute(Text& name, Text& value, Attribute* previous) {
	setName(name);
	setValue(value);

	this->next = nullptr;
	this->previous = previous;
}

Attribute::Attribute(Text& name, Attribute* next, Attribute* previous) {
	setName(name);

	this->next = next;
	this->previous = previous;
}

Attribute::Attribute(Text& name, Text& value, Attribute* next, Attribute* previous) {
	setName(name);
	setValue(value);

	this->next = next;
	this->previous = previous;
}

int Attribute::countAttributes() {
	int howManyAttributes = 0;
	Attribute* currentAttribute = new Attribute(name, value, next, previous);
	while (currentAttribute != nullptr) {
		if (currentAttribute->name.getString() != nullptr){
			howManyAttributes++;
		}
		currentAttribute = currentAttribute->getNext();
	}
	delete currentAttribute;
	return howManyAttributes;
}

void Attribute::setName(const char* name) {
	this->name = name;
}

void Attribute::setName(Text& name) {
	if (name.getString() == nullptr) return;
	int newLength = name.getLength();
	char* newName = new char[newLength + PLUS0];
	for (int i = 0; i < newLength + PLUS0; i++) newName[i] = name[i];
	this->name = newName;
}

void Attribute::setValue(const char* value) {
	this->value = value;
}

void Attribute::setValue(Text& value) {
	if (value.getString() == nullptr) return;
	int newLength = value.getLength();
	char* newValue = new char[newLength + PLUS0];
	for (int i = 0; i < newLength + PLUS0; i++) newValue[i] = value[i];
	this->value = newValue;
}

void Attribute::setNext(Attribute* next) {
	this->next = next;
}

void Attribute::setPrevious(Attribute* previous) {
	this->previous = previous;
}

Text Attribute::getName() const {
	return name;
}

Text Attribute::getValue() const {
	return value;
}

Attribute* Attribute::getNext() const {
	return next;
}

Attribute* Attribute::getPrevious() const {
	return previous;
}

Attribute* Attribute::findTail() {
	Attribute* currentAttribute = this;
	if (currentAttribute == nullptr) return nullptr;
	while (currentAttribute->next != nullptr) {
		currentAttribute = currentAttribute->next;
	}
	return currentAttribute;
}

Attribute* Attribute::findAttribute(Text& name) {
	if (name.getString() != nullptr) {
		if (this == nullptr) return nullptr; //dodane
		else if (this->name == name) return this;
		Attribute* currentAttribute = this; // new Attribute(this->name, value, next, previous);
		while (currentAttribute != nullptr) {
			if (currentAttribute->name == name) return currentAttribute;
			currentAttribute = currentAttribute->next;
		}
	}
	return nullptr;
}

void Attribute::addAttribute(Text& name) {
	Attribute* tail = findTail();
	Attribute* currentAttribute = new Attribute(name);
	tail->setNext(currentAttribute);
	currentAttribute->setPrevious(tail);
}

void Attribute::addAttribute(Text& name, Text& value) {
	Attribute* tail = findTail();
	Attribute* currentAttribute = new Attribute(name, value);
	tail->setNext(currentAttribute);
	currentAttribute->setPrevious(tail);
}

Attribute::~Attribute() {
	next = nullptr;
	previous = nullptr;
}