#ifndef SECTIONCLASS_H
#define SECTIONCLASS_H
#define EMPTYSTRING "EmptY"
#include "attributeclass.h"
#include "selectorclass.h"
#include "textclass.h"


class Section {
private:
	Selector* firstSelector;
	Attribute* firstAttribute;
public:
	Section();
	Section(Text& nameOfattribute);
	Section(Text& nameOfselector, Text& nameOfattribute);
	Section(Text& nameOfselector, Text& nameOfattribute, Text& valueOfattribute);

	void clearFirstAttribute();
	void clearFirstSelector();

	int getNumberOfSelectors() const;
	int getNumberOfAttributes() const;
	Text getSelectorByNumber(int number);
	Text getAttributeValueByName(Text& name);
	Attribute* getAttributeAddress(Text& name);

	bool ifEmpty();

	void addAttribute(Text& name);
	void addAttribute(Text& name, Text& value);
	void addSelector(Text& name);

	bool findSelector(Text& name);
	bool findAttribute(Text& name);
	void removeAttribute(Text& name, int* takenStructures);
	void removeSelector(Text& name);
	void removeAllSelectors();
	void removeAllAttributes();

	~Section();
};


#endif // !SECTION_H
