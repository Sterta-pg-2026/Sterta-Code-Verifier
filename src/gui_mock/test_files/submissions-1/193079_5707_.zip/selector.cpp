#include "selectorclass.h"
using namespace std;

Selector::Selector() {
	next = nullptr;
}

Selector::Selector(Text& name) {
	this->name = name;
	next = nullptr;
}

Selector::Selector(Text& name, Selector* next) {
	this->name = name;
	this->next = next;
}


int Selector::countSelectors() {
	int howManySelectors = 0;
	Selector* currentSelector = this; 
	while (currentSelector != nullptr) { 
		howManySelectors++;
		currentSelector = currentSelector->getNext();
	}
	return howManySelectors;
}

Selector* Selector::findSelector(Text& name) {
	if (name.getString() != nullptr) {
		if (this->name == name) return this;
		Selector* currentSelector = new Selector(this->name, next);
		while (currentSelector != nullptr) {
			if (currentSelector->name == name) return currentSelector;
			currentSelector = currentSelector->next;
		}
	}
	return nullptr;
}


Selector* Selector::findTail() {
	Selector* currentSelector = this;
	if (currentSelector == nullptr) return nullptr;
	while (currentSelector->next != nullptr) {
		currentSelector = currentSelector->next;
	}
	return currentSelector;
}

void Selector::setName(Text& name) {
	if (name.getString() == nullptr) return;
	int newLength = name.getLength();
	char* newName = new char[newLength + PLUS0];
	for (int i = 0; i < newLength + PLUS0; i++) newName[i] = name[i];
	this->name = newName;
}

void Selector::setNext(Selector* next) {
	this->next = next;
}


Text Selector::getName(int numberInOrder) {
	int howManySelectors = 0;
	Selector* currentSelector = new Selector(name, next);
	while (currentSelector != nullptr) {
		if (howManySelectors == numberInOrder) return currentSelector->name;
		howManySelectors++;
		currentSelector = currentSelector->getNext();
	}
	delete currentSelector;
	return EMPTYTEXT;
}

Text Selector::getName() const {
	return name;
}

Selector* Selector::getNext() const {
	return next;
}

void Selector::addSelector(Text& name) {
	if (name.getString() != nullptr) {
		Selector* tail = findTail();
		if (tail == nullptr) this->setName(name);
		else {
			Selector* currentSelector = new Selector(name);
			tail->setNext(currentSelector);
		}
	}
}

void Selector::removeSelector(Text& name) {
	Selector* currentSelector = findSelector(name);
	if (currentSelector == this) {
		currentSelector = currentSelector->next;
		setName(currentSelector->name);
		setNext(currentSelector->next);
	}
	else if (currentSelector != nullptr) {
		Selector* previousSelector = new Selector(this->name, next);
		while (previousSelector->next != currentSelector) previousSelector = previousSelector->next;
		previousSelector->setNext(currentSelector->next);
	}
}


Selector::~Selector() {
	if (next != nullptr) next = nullptr;
}
