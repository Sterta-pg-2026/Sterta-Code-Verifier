#include "sectionclass.h"
using namespace std;

Section::Section() {
	firstSelector = nullptr;
	firstAttribute = nullptr;
}

Section::Section(Text& nameOfattribute) {
	firstSelector = nullptr;
	firstAttribute = new Attribute(nameOfattribute);
}

Section::Section(Text& nameOfselector, Text& nameOfattribute) {
	firstSelector = new Selector(nameOfselector);
	firstAttribute = new Attribute(nameOfattribute);
}

Section::Section(Text& nameOfselector, Text& nameOfattribute, Text& valueOfattribute) {
	firstSelector = new Selector(nameOfselector);
	firstAttribute = new Attribute(nameOfattribute, valueOfattribute);
}

void Section::clearFirstAttribute() {
	firstAttribute = nullptr;
}
void Section::clearFirstSelector() {
	firstSelector = nullptr;
}

int Section::getNumberOfSelectors() const {
	if (firstSelector == nullptr || firstSelector->getName().getLength() == 0) return 0;
	return firstSelector->countSelectors();
}

int Section::getNumberOfAttributes() const {
	if (firstAttribute == nullptr || firstAttribute->getName().getLength() == 0) return 0;
	return firstAttribute->countAttributes();
}

Text Section::getSelectorByNumber(int number) {
	if (firstSelector == nullptr || firstSelector->getName().getLength() == 0) return NULL;
	return firstSelector->getName(number);
}

Text Section::getAttributeValueByName(Text & name) {
	Text empty = EMPTYSTRING;
	Attribute* attributeFound = firstAttribute->findAttribute(name);
	if (attributeFound != nullptr) return (attributeFound)->getValue();
	else return empty;
}

Attribute* Section::getAttributeAddress(Text& name) {
	return firstAttribute->findAttribute(name);
}

bool Section::ifEmpty() {
	if (firstAttribute == nullptr) return true;
	return false;
}

void Section::addAttribute(Text& name) {
	if (firstAttribute == nullptr) firstAttribute = new Attribute(name);
	else firstAttribute->addAttribute(name);
}

void Section::addAttribute(Text& name, Text& value) {
	if (firstAttribute == nullptr) firstAttribute = new Attribute(name, value);
	else firstAttribute->addAttribute(name, value);
}

void Section::addSelector(Text& name) {
	if (firstSelector == nullptr) firstSelector = new Selector(name);
	else firstSelector->addSelector(name);
}

bool Section::findSelector(Text& name) {
	if (name.getString() != nullptr) {
		Selector* currentSelector = firstSelector;
		while (currentSelector != nullptr) {
			if (currentSelector->getName() == name) return true;
			currentSelector = currentSelector->getNext();
		}
	}
	return false;
}

bool Section::findAttribute(Text& name) {
	if ((firstAttribute->findAttribute(name)) != nullptr) return true;
	return false;
}

void Section::removeAttribute(Text& name, int* takenStructures) {
	Attribute* currentAttribute = firstAttribute->findAttribute(name);
	if (currentAttribute == firstAttribute) {
		if (firstAttribute->countAttributes() > 1) {
			firstAttribute = firstAttribute->getNext();
			delete firstAttribute->getPrevious();
			firstAttribute->setPrevious(nullptr);
		}
		else {
			*takenStructures -= 1;
			Text empty;
			Selector* currentSelector = firstSelector->getNext();
			firstAttribute = nullptr;
			while (currentSelector != nullptr) {
				Selector* deleteSelector = currentSelector;
				currentSelector = currentSelector->getNext();
				delete deleteSelector;
			}
			firstSelector = nullptr;
		}
	}
	else if (currentAttribute != nullptr) {
		(currentAttribute->getPrevious())->setNext(currentAttribute->getNext());
		if (currentAttribute->getNext() != nullptr) (currentAttribute->getNext())->setPrevious(currentAttribute->getPrevious());
	}
}

void Section::removeSelector(Text& name) {
	firstSelector->removeSelector(name);
}


void Section::removeAllSelectors() {
	if (firstSelector == nullptr) return;
	Selector* previousSelector = firstSelector;
	Selector* currentSelector = firstSelector->getNext();
	while (previousSelector != nullptr) {
		delete previousSelector;
		previousSelector = currentSelector;
		if (currentSelector != nullptr) currentSelector = currentSelector->getNext();
	}
	if (currentSelector != nullptr) delete currentSelector;
}

void Section::removeAllAttributes() { 
	if (firstAttribute != nullptr) {
		Attribute* currentAttribute = firstAttribute->getNext();
		if (currentAttribute == nullptr) delete firstAttribute; 
		else {
			while (currentAttribute != nullptr && currentAttribute->getPrevious() != nullptr) {
				delete currentAttribute->getPrevious();
				if (currentAttribute != nullptr) currentAttribute = currentAttribute->getNext();
			}
			if (currentAttribute != nullptr) delete currentAttribute;
		}
	}
}


Section::~Section() { 
	removeAllSelectors();
	removeAllAttributes(); 
}