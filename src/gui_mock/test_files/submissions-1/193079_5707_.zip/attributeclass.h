#ifndef ATTRIBUTECLASS_H
#define ATTRIBUTECLASS_H

#include <iostream>
#include "textclass.h"

class Attribute {
private:
	Text name;
	Text value;

	Attribute* next;
	Attribute* previous;
public:
	Attribute();
	Attribute(Text& name); 
	Attribute(Text& name, Text& value); 
	Attribute(Text& name, Attribute* previous); 
	Attribute(Text& name, Text& value, Attribute* previous); 
	Attribute(Text& name, Attribute* next, Attribute* previous); 
	Attribute(Text& name, Text& value, Attribute* next, Attribute* previous);

	int countAttributes();

	void setName(const char* name);
	void setName(Text& name);
	
	void setValue(const char* value);
	void setValue(Text& value);

	void setNext(Attribute* next);
	void setPrevious(Attribute* previous);

	Text getName() const;
	Text getValue() const;

	Attribute* getNext() const;
	Attribute* getPrevious() const;

	Attribute* findTail();
	Attribute* findAttribute(Text& name);
	
	void addAttribute(Text& name);
	void addAttribute(Text& name, Text& value);

	~Attribute();
};

#endif // !ATTRIBUTECLASS_H

