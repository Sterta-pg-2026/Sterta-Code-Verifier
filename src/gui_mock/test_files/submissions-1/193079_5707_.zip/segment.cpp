#include "segmentclass.h"
#pragma warning(disable : 4996)
using namespace std;


Segment::Segment() {
	takenStructures = 0;
	next = nullptr;
	previous = nullptr;
}

Segment::Segment(Segment* next, Segment* previous) {
	takenStructures = 0;
	this->next = next;
	this->previous = previous;
}

void Segment::setNext(Segment* next) {
	this->next = next;
}

void Segment::setPrevious(Segment* previous) {
	this->previous = previous;
}

void Segment::setTakenStructures(int newValue) {
	takenStructures = newValue;
}

int Segment::getTakenStructures() {
	return takenStructures;
}

Segment* Segment::getNext() {
	return next;
}

Segment* Segment::getPrevious() {
	return previous;
}

void Segment::addSelector(Section* addressOfSection, Text& nameOfSelector) {
	addressOfSection->addSelector(nameOfSelector);

}

void Segment::addAttribute(Section* addressOfSection, Text& nameOfAttribute) {
	addressOfSection->addAttribute(nameOfAttribute);
	modifyTakenStructures();
}

void Segment::addAttribute(Section* addressOfSection, Text& nameOfAttribute, Text& valueOfAttribute) {
	addressOfSection->addAttribute(nameOfAttribute, valueOfAttribute);
	findTail()->modifyTakenStructures();
}

bool Segment::swapAttributeValue(Section* addressOfSection, Text& nameOfAttribute, Text& newValue) {
	Attribute* sameAttribute = addressOfSection->getAttributeAddress(nameOfAttribute);
	if (sameAttribute != nullptr) {
		sameAttribute->setValue(newValue);
		return true;
	}
	return false;
}

void Segment::modifyTakenStructures() { 
	int takenStructs = 0;
	Segment* currentSegment = this;
	for (int i = 0; i < BLOCKSIZE; i++) {
		if (currentSegment->ifEmpty(i) == false) takenStructs++;
	}
	currentSegment->takenStructures = takenStructs;
}

bool Segment::ifEmpty(int numberOfSection) {
	if (block[numberOfSection].getNumberOfAttributes() == 0) return true;
	else return false;
}


Segment* Segment::getAddressOfSegment(int ithSection) { 
	Segment* currentSegment = this;
	int sectionNumber = 0;
	if (currentSegment != nullptr) {
		while (currentSegment != nullptr) {
			for (int i = 0; i < BLOCKSIZE; i++) {
				if (!(currentSegment->block[i].ifEmpty())) sectionNumber++;
				if (sectionNumber == ithSection) return currentSegment;
			}
			currentSegment = currentSegment->next;
		}
	}
	return nullptr;
}

Section* Segment::getNextAddressOfSection(int sectionNumber) {
	int numberOfNode = sectionNumber / BLOCKSIZE;
	if (numberOfNode > 0 && sectionNumber % BLOCKSIZE == 0) addSegment();
	Segment* currentSegment = findTail();
	return &(currentSegment->block[sectionNumber % BLOCKSIZE]);
}

Section* Segment::getSectionByNumber(int ithSection) {
	Segment* currentSegment = this;
	int sectionNumber = 0;
	if (currentSegment != nullptr) {
		while (currentSegment != nullptr) {
			for (int i = 0; i < BLOCKSIZE; i++) {
				if (!(currentSegment->block[i].ifEmpty())) sectionNumber++;
				if (sectionNumber == ithSection) return &currentSegment->block[i];
			}
			currentSegment = currentSegment->next;
		}
	}
	return nullptr;
}

Segment* Segment::findTail() {
	Segment* currentSegment = this;
	if (currentSegment == nullptr) return nullptr;
	while (currentSegment->next != nullptr) currentSegment = currentSegment->next;
	return currentSegment;
}

void Segment::addSegment() {
	Segment* tail = findTail();
	Segment* currentSegment = new Segment;
	tail->setNext(currentSegment);
	currentSegment->setPrevious(tail);
}

int Segment::getSections() {
	int howManySections = 0;
	Segment* currentSegment = this;
	while (currentSegment != nullptr) {
		howManySections += currentSegment->takenStructures;
		currentSegment = currentSegment->next;
	}
	return howManySections;
}

void Segment::getNumberOfSections() {
	int howManySections = getSections();
	cout << "? == " << howManySections << endl;
} 

void Segment::getNumberOfSelectors(int ithSection) { //zmienic od 1
	// i,S,?  wypisz liczb selektorw dla sekcji nr i (numery zaczynaj si od 1), jeli nie ma takiego bloku pomi;
	//ogranicz i
	int howManySections = getSections();
	if (ithSection <= howManySections) {
		Section* currentSection = getSectionByNumber(ithSection);
  		cout << ithSection << ",S,? == " << currentSection->getNumberOfSelectors() << endl;
	}
}

void Segment::getNumberOfAttributes(int ithSection) {
	// i,A,? - wypisz liczb atrybutw dla sekcji nr i, jeli nie ma takiego bloku lub sekcji pomi;
	int howManySections = getSections();
	if (ithSection <= howManySections) {
		Section* currentSection = getSectionByNumber(ithSection);
		cout << ithSection << ",A,? == " << currentSection->getNumberOfAttributes() << endl;
	}
}

void Segment::getJthSelector(int ithSection, int jthSelector) {
	// i,S,j  wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutw zaczynaj si od 1) jeli nie ma sekcji lub selektora pomi;
	int howManySections = getSections();
	if (ithSection <= howManySections) {
		Section* currentSection = getSectionByNumber(ithSection);
		int maxSelector = currentSection->getNumberOfSelectors();
		if (jthSelector <= maxSelector) {
			cout << ithSection << ",S," << jthSelector << " == " << currentSection->getSelectorByNumber(jthSelector - 1) << endl;
		}
	}
}

void Segment::getValueOfAttribute(int ithSection, Text& nameOfAttribute) {
	// i,A,n  wypisz dla i-tej sekcji warto atrybutu o nazwie n, jeli nie ma takiego pomi;
	int howManySections = getSections();
	if (ithSection <= howManySections) {
		Section* currentSection = getSectionByNumber(ithSection);
		Text nameOfAttr = nameOfAttribute;
		Text value = currentSection->getAttributeValueByName(nameOfAttribute);
		if (value != EMPTYSTRING) cout << ithSection << ",A," << nameOfAttr << " == " << value << endl;
	}
}

void Segment::getNumberOfAttributeOccurences(Text& nameOfAttribute) { // do poprawy 
	// n,A,?  wypisz czn (dla wszystkich blokw) liczb wystpie atrybutu nazwie n. (W ramach pojedynczego bloku duplikaty powinny zosta usunite na etapie wczytywania). Moliwe jest 0;
	int occurencesOfAttribute = 0;
	Segment* currentSegment = this;
	Text nameOfAttr = nameOfAttribute;
	while (currentSegment != nullptr) {
		for (int i = 0; i < BLOCKSIZE; i++) {
			if (currentSegment->block[i].ifEmpty() == false && currentSegment->block[i].findAttribute(nameOfAttribute)) occurencesOfAttribute++;
		}
		currentSegment = currentSegment->next;
	}
	cout << nameOfAttr << ",A,? == " << occurencesOfAttribute << endl;
}

void Segment::getNumberOfSelectorOccurences(Text& nameOfSelector) {
	// z,S,?  wypisz czn (dla wszystkich blokw) liczb wystpie selektora z. Moliwe jest 0;
	int occurences = 0;
	Segment* currentSegment = this;
	while (currentSegment != nullptr) {
		for (int i = 0; i < BLOCKSIZE; i++) {
			if (currentSegment->block[i].findSelector(nameOfSelector)) occurences++;
		}
		currentSegment = currentSegment->next;
	}
	cout << nameOfSelector << ",S,? == " << occurences << endl;
}

void Segment::getLastAttributeValue(Text& nameOfSelector, Text& nameOfAttribute) {
	// z,E,n  wypisz warto atrybutu o nazwie n dla selektora z, w przypadku wielu wystpie selektora z bierzemy ostatnie. W przypadku braku pomi;
	Segment* currentSegment = findTail();
	bool found = false;
	Text lastValue;
	while (currentSegment != nullptr) {
		for (int i = BLOCKSIZE - 1; i >= 0; i--) {
			if (currentSegment->block[i].getNumberOfSelectors() > 0 && currentSegment->block[i].findSelector(nameOfSelector) && currentSegment->block[i].findAttribute(nameOfAttribute)) {
				lastValue = currentSegment->block[i].getAttributeValueByName(nameOfAttribute);
				found = true;
				break;
			}
		}
		if (found) break;
		currentSegment = currentSegment->previous;
	}
	if (lastValue.getString() != nullptr) cout << nameOfSelector << ",E," << nameOfAttribute << " == " << lastValue << endl;
}

void Segment::deleteSection(int ithSection, Segment* head) {
	// i,D,* - usu ca sekcj nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted;
	if (ithSection <= getSections()) {
		Segment* segmentToModify = getAddressOfSegment(ithSection);
		int newTaken = segmentToModify->getTakenStructures() - 1;
		segmentToModify->setTakenStructures(newTaken);
		Section* sectionToBeDeleted = head->getSectionByNumber(ithSection);
		sectionToBeDeleted->removeAllSelectors();
		sectionToBeDeleted->removeAllAttributes();
		sectionToBeDeleted->clearFirstAttribute();
		sectionToBeDeleted->clearFirstSelector();
		cout << ithSection << ",D,* == deleted" << endl;
	}
}

void Segment::deleteAttribute(int ithSection, Text& nameOfAttribute) {
	// i,D,n  usu z i-tej sekcji atrybut o nazwie n, jeli w wyniku operacji pozostaje pusta sekcja powinna zosta rwnie usunita (wraz z ew. selektorami), po poprawnym wykonaniu wypisz deleted.
	int howManySections = getSections();
	if (ithSection <= howManySections) {
		Section* toDeleteFrom = getSectionByNumber(ithSection);
		Text nameOfAttr = nameOfAttribute;
		Segment* toBeRemovedFrom = getAddressOfSegment(ithSection);
		if (toDeleteFrom->findAttribute(nameOfAttribute)) {
			toDeleteFrom->removeAttribute(nameOfAttribute, &(toBeRemovedFrom->takenStructures));
			cout << ithSection << ",D," << nameOfAttr << " == deleted" << endl;
		}
	}
}

Segment::~Segment() {
	if (takenStructures != NULL) takenStructures = NULL;
	if (next != nullptr) next = nullptr;
	if (previous != nullptr) previous = nullptr;
}

void freeSegmentsList(Segment* head) {
	if (head->getNext() != nullptr) {
		Segment* currentSegment = head->getNext();
		while (currentSegment->getNext() != nullptr) {
			delete currentSegment->getPrevious();
			currentSegment = currentSegment->getNext();
		}
		delete currentSegment;
	}
	else delete head;
}

void manageBuffer(char buffer[], int* bufferIndex) {
	int index = 1;
	buffer[(*bufferIndex)] = STRINGSIGN;
	while (buffer[(*bufferIndex) - index] == SPACE || buffer[(*bufferIndex) - index] == ENTER || buffer[(*bufferIndex) - index] == TABULATOR) {
		buffer[(*bufferIndex) - index] = STRINGSIGN;
		index++;
	}
	*bufferIndex = 0;
}

void manageCommandBuffer(char buffer[], int* bufferIndex) {
	int index = 1;
	buffer[(*bufferIndex)] = STRINGSIGN;
	while (buffer[(*bufferIndex) - index] == SPACE || buffer[(*bufferIndex) - index] == TABULATOR) {
		buffer[(*bufferIndex) - index] = STRINGSIGN;
		index++;
	}
	*bufferIndex = 0;
}

void executeCommand(Segment* head, Text& firstPart, Text& secondPart, Text& thirdPart) {
	int firstArgumentInt = firstPart.convertToInt();
	int thirdArgumentInt;
	if (firstArgumentInt >= 0) {
		if (secondPart == "A") {
			if (thirdPart == "?") head->getNumberOfAttributes(firstArgumentInt); //	i,A,?
			else head->getValueOfAttribute(firstArgumentInt, thirdPart); //	i,A,n
		}
		else if (secondPart == "S") {
			if (thirdPart == "?") { //	i,S,?
				head->getNumberOfSelectors(firstArgumentInt);
			}
			else { //	i,S,j
				thirdArgumentInt = thirdPart.convertToInt();
				head->getJthSelector(firstArgumentInt, thirdArgumentInt);
			} 
		}
		else if (secondPart == "D") {
			if (thirdPart == "*") head->deleteSection(firstArgumentInt, head);//	i,D,*
			else head->deleteAttribute(firstArgumentInt, thirdPart); //	i,D,n
		}
	}
	else {
		if (secondPart == "A") head->getNumberOfAttributeOccurences(firstPart); //	n,A,?
		else if (secondPart == "S") head->getNumberOfSelectorOccurences(firstPart); // z,S,?
		else if (secondPart == "E") head->getLastAttributeValue(firstPart, thirdPart); // z,E,n
	}

}

char* enlargeBuffer(int bufferOldSize, char buffer[]) {
	char* biggerBuffer = new char[bufferOldSize * 2];
	for (int i = 0; i < bufferOldSize; i++) biggerBuffer[i] = buffer[i];
	delete buffer;
	return biggerBuffer;
}

void runTheCSSEngine() { 
	Segment* head = new Segment;

	char* buffer = new char[BUFFERSIZE];
	char charBuffer = '.';
	int bufferIndex = 0;
	char inputState = 's';	//initializing variables
	int nextSection = 0;

	Text name;
	Text value;
	Text command;

	int loading = 1;
	Text firstArgument;
	Text secondArgument;
	Text thirdArgument;

	Section* firstEmptySection = head->getNextAddressOfSection(nextSection);

	while (charBuffer != EOF) {
		charBuffer = getchar();
		if (inputState == 's') { // loading selectors
			if (charBuffer == '?') {
				int howManyQ = 1;
				while (howManyQ != 4) {
					charBuffer = getchar();
					if (charBuffer == '?') howManyQ++;
					else break;
				}
				inputState = 'c';
			}
			else if (charBuffer == '{') {
				if (bufferIndex == 0) inputState = 'a';
				manageBuffer(buffer, &bufferIndex);
				name = buffer;
				head->addSelector(firstEmptySection, name);
				inputState = 'a';
			}
			else if (bufferIndex == 0 && (charBuffer == ENTER || charBuffer <= SPACE || charBuffer == TABULATOR)) continue;
			else if (charBuffer == ',') {
				manageBuffer(buffer, &bufferIndex);
				name = buffer;
				head->addSelector(firstEmptySection, name);
			}
			else {
				
				buffer[bufferIndex] = charBuffer;
				bufferIndex++;
				if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
			}
		}
		else if (inputState == 'a') { // loading attributes
			if (bufferIndex == 0 && (charBuffer == SPACE || charBuffer == TABULATOR || charBuffer == ENTER)) continue;
			else if (bufferIndex == 0 && charBuffer == '}') {
				inputState = 's';
				nextSection++;
				firstEmptySection = head->getNextAddressOfSection(nextSection);
			}
			else if (charBuffer == ':') {
				manageBuffer(buffer, &bufferIndex);
				name = buffer;
				while (true) {
					charBuffer = getchar();
					if (bufferIndex == 0 && (charBuffer == SPACE || charBuffer == TABULATOR || charBuffer == ENTER)) continue;
					else if (charBuffer == ';') {
						manageBuffer(buffer, &bufferIndex);
						value = buffer;
						if (!head->swapAttributeValue(firstEmptySection, name, value)) head->addAttribute(firstEmptySection, name, value);
						break;
					}
					else if (charBuffer == '}') {
						if (bufferIndex == 0) inputState = 's';
						manageBuffer(buffer, &bufferIndex);
						value = buffer;
						if (!head->swapAttributeValue(firstEmptySection, name, value)) head->addAttribute(firstEmptySection, name, value);
						inputState = 's';
						nextSection++;
						firstEmptySection = head->getNextAddressOfSection(nextSection);
						break;
					}
					else {
						buffer[bufferIndex] = charBuffer;
						bufferIndex++;
						if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
					}
				}
			}
			else {
				buffer[bufferIndex] = charBuffer;
				bufferIndex++;
				if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
			}
		}
		else { // command line
			while (true) {
				charBuffer = getchar();
				if (charBuffer == EOF) break;
				if (loading == 1) {
					if (bufferIndex == 0 && (charBuffer <= SPACE || charBuffer == TABULATOR)) continue;
					else if (bufferIndex == 0 && charBuffer == '*') {
						int howManyStars = 1;
						while (howManyStars != 4) {
							charBuffer = getchar();
							if (charBuffer == '*') howManyStars++;
							else break;
						}
						inputState = 's';
						break;
					}
					else if (bufferIndex == 0 && charBuffer == '?') head->getNumberOfSections();
					else if (charBuffer == ',') {
						manageCommandBuffer(buffer, &bufferIndex);
						firstArgument = buffer;
						loading = 2;
					}
					else {
						buffer[bufferIndex] = charBuffer;
						bufferIndex++;
						if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
					}

				}
				else if (loading == 2) {
					if (bufferIndex == 0 && (charBuffer <= SPACE || charBuffer == TABULATOR)) continue;
					if (charBuffer == ',') {
						manageCommandBuffer(buffer, &bufferIndex);
						secondArgument = buffer;
						loading = 3;
						if (secondArgument != "A" && secondArgument != "D" && secondArgument != "E" && secondArgument != "S") {
							loading = 1;
							while (charBuffer != ENTER) charBuffer = getchar();
						}
					}
					else {
						buffer[bufferIndex] = charBuffer;
						bufferIndex++;
						if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
					}
				}
				else {
					if (charBuffer == ENTER || charBuffer == EOF) {
						manageCommandBuffer(buffer, &bufferIndex);
						thirdArgument = buffer;
						loading = 1;
						executeCommand(head, firstArgument, secondArgument, thirdArgument);

					}
					else {
						buffer[bufferIndex] = charBuffer;
						bufferIndex++;
						if (bufferIndex == BUFFERSIZE) buffer = enlargeBuffer(BUFFERSIZE, buffer);
					}
				}
			}
		}
	}
	delete[] buffer;
	freeSegmentsList(head);
}

