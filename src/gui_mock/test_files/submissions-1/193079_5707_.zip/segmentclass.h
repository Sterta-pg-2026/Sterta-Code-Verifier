#ifndef SEGMENTCLASS_H
#define SEGMENTCLASS_H
#define BLOCKSIZE 8 
#define BUFFERSIZE 100
#define ENTER '\n'
#define STRINGSIGN '\0'
#define TABULATOR '\t'
#define SPACE ' '
#include <stdio.h>
#include "attributeclass.h"
#include "selectorclass.h"
#include "sectionclass.h"
#include "textclass.h"

using namespace std;

class Segment {
private:
	Section block[BLOCKSIZE];
	int takenStructures;

	Segment* next;
	Segment* previous;
public:
	Segment();
	Segment(Segment* next, Segment* previous);
	
	void setNext(Segment* next);
	void setPrevious(Segment* previous);
	void setTakenStructures(int newValue);

	int getTakenStructures();
	Segment* getNext();
	Segment* getPrevious();

	void addSelector(Section* addressOfSection, Text& nameOfSelector);
	void addAttribute(Section* addressOfSection, Text& nameOfAttribute);
	void addAttribute(Section* addressOfSection, Text& nameOfAttribute, Text& valueOfAttribute);

	bool swapAttributeValue(Section* addressOfSection, Text& nameOfAttribute, Text& newValue);
	
	void modifyTakenStructures();

	bool ifEmpty(int numberOfSection); // checking if field of block array is empty
	Section* getNextAddressOfSection(int sectionNumber);

	Section* getSectionByNumber(int ithSection);
	Segment* getAddressOfSegment(int ithSection);

	Segment* findTail();
	void addSegment();
	int getSections();

	void getNumberOfSections(); // ?
	void getNumberOfSelectors(int ithSection); // i,S,?
	void getNumberOfAttributes(int ithSection); // i,A,?
	void getJthSelector(int ithSection, int jthSelector); // i,S,j
	void getValueOfAttribute(int ithSection, Text& nameOfAttribute); // i,A,n
	void getNumberOfAttributeOccurences(Text& nameOfAttribute); // n,A,?
	void getNumberOfSelectorOccurences(Text& nameOfSelector);// z,S,?
	void getLastAttributeValue(Text& nameOfSelector, Text& nameOfAttribute); //z,E,n
	void deleteSection(int ithSection, Segment* head); // i,D,*
	void deleteAttribute(int ithSection, Text& nameOfAttribute); // i,D,n

	~Segment();
};

void freeSegmentsList(Segment* head);
void manageBuffer(char buffer[], int* bufferIndex);
void manageCommandBuffer(char buffer[], int* bufferIndex);
void executeCommand(Segment* head, Text& firstPart, Text& secondPart, Text& thirdPart);
char* enlargeBuffer(int bufferOldSize, char buffer[]);
void runTheCSSEngine();


#endif 
