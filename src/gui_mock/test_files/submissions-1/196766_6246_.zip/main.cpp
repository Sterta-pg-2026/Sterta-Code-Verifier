#include <iostream>
#include <stdio.h>

#define BLOCKSIZE 10

class String
{
    char *str = nullptr;
    int len = 0;
    int max_len = 0;

public:
    String()
    {
        if (str != nullptr)
        {
            delete[] str;
        }
        str = new char[41];
        max_len = 40;
    }

    String(const char *s)
    {
        len = 0;
        if (str != nullptr)
        {
            delete[] str;
        }
        while (s[len])
            ++len;
        max_len = len + 40;
        str = new char[max_len + 1];
        for (int i = 0; i <= len; ++i)
        {
            str[i] = s[i];
        }
    }

    String(const String &s)
    {
        if (str != nullptr)
        {
            delete[] str;
        }
        len = s.len;
        max_len = s.max_len;
        str = new char[max_len + 1];
        for (int i = 0; i <= len; ++i)
        {
            str[i] = s.str[i];
        }
    }

    void append(const char *other)
    {
        int other_len = 0;
        while (other[other_len])
            ++other_len;
        if (other_len + this->len > this->max_len)
        {
            char *new_str = new char[other_len + this->len + 41];
            for (int i = 0; i < this->len; ++i)
            {
                new_str[i] = this->str[i];
            }
            for (int i = 0; i <= other_len; ++i)
            {
                new_str[i + this->len] = other[i];
            }
            delete[] str;
            str = new_str;
            max_len = other_len + this->len + 40;
            len = other_len + this->len;
        }
        else
        {
            for (int i = 0; i <= other_len; ++i)
            {
                this->str[i + this->len] = other[i];
            }
            len = other_len + this->len;
        }
    }

    bool operator==(const char *other)
    {
        int i = 0;
        while (other[i])
        {
            i++;
        }
        if (this->len != i)
        {
            return false;
        }
        for (int j = 0; j < this->len; j++)
        {
            if (this->str[j] != other[j])
            {
                return false;
            }
        }
        return true;
    }

    bool operator==(const String &other)
    {
        if (this->len != other.len)
        {
            return false;
        }
        for (int j = 0; j < this->len; j++)
        {
            if (this->str[j] != other.str[j])
            {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const char other)
    {
        if (this->len != 1)
        {
            return true;
        }
        if (this->str[0] != other)
        {
            return true;
        }
        return false;
    }

    String &operator=(String &&other)
    {
        if (this->str)
        {
            delete[] this->str;
        }
        this->len = other.len;
        this->str = other.str;
        this->max_len = other.max_len;
        other.str = nullptr;
        return *this;
    }

    int scan()
    {
        delete[] str;
        this->str = new char[191];
        this->max_len = 190;
        if (!std::cin.getline(this->str, 150))
        {
            return -1;
        }
        if (this->str[0] == '\0')
        {
            return 0;
        }
        int i = 0;
        while (this->str[i] != 0)
        {
            i++;
        }
        this->len = i;
        this->str[i] = '\0';
        return 1;
    }

    void strip(const char symbol)
    {
        int start = 0, end = this->len - 1;
        while ((this->str[start] <= 32 or this->str[start] == symbol) and start < this->len)
        {
            start++;
        }
        while ((this->str[end] <= 32 or this->str[end] == symbol) and end >= 0)
        {
            end--;
        }
        if (start > end)
        {
            this->str[0] = '\0';
            this->len = 0;
            return;
        }
        if (start == 0 && end == this->len - 1)
        {
            return;
        }
        if (start == 0)
        {
            this->str[end + 1] = '\0';
            this->len = end + 1;
            return;
        }
        char *new_str = new char[end - start + 42];
        this->max_len = end - start + 41;
        for (int i = start; i <= end; i++)
        {
            new_str[i - start] = this->str[i];
        }
        new_str[end - start + 1] = '\0';
        delete[] this->str;
        this->str = new_str;
        this->len = end - start + 1;
    }

    void delete_symbol(const char symbol)
    {
        for (int i = this->len - 1; i >= 0; i--)
        {
            if (this->str[i] == symbol)
            {
                for (int j = i; j < this->len; j++)
                {
                    this->str[j] = this->str[j + 1];
                }
                this->len--;
                return;
            }
        }
    }

    int count(const char sumbol, const bool ignore_last = false)
    {
        int count = 0;
        for (int i = 0; i < this->len; i++)
        {
            if (this->str[i] == sumbol)
            {
                count++;
            }
        }
        if (ignore_last and this->str[this->len - 1] == sumbol)
        {
            count--;
        }
        return count;
    }

    int get_len()
    {
        return this->len;
    }

    bool is_numeric()
    {
        for (int i = 0; i < this->len; i++)
        {
            if (this->str[i] < '0' or this->str[i] > '9')
            {
                return false;
            }
        }
        return true;
    }

    int to_int()
    {
        int result = 0;
        for (int i = 0; i < this->len; i++)
        {
            result = result * 10 + this->str[i] - '0';
        }
        return result;
    }

    String *split(const char symol)
    {
        int count = this->count(symol, true) + 1;
        String *result = new String[count];
        int start = 0, end = 0;
        for (int i = 0; i < count; i++)
        {
            while (this->str[end] != symol and end < this->len)
            {
                end++;
            }
            char *new_str = new char[end - start + 1];
            for (int j = start; j < end; j++)
            {
                new_str[j - start] = this->str[j];
            }
            new_str[end - start] = '\0';
            result[i] = std::move(String(new_str));
            delete[] new_str;
            start = end + 1;
            end = start;
        }
        return result;
    }

    char get_char(int index)
    {
        if (index >= 0 && index < this->len)
            return this->str[index];
        else if (index < 0 && index >= -this->len)
            return this->str[this->len + index];
        else
        {
            throw std::out_of_range("Index out of range");
        }
        return this->str[index];
    }

    ~String()
    {
        if (this->str)
        {
            delete[] this->str;
        }
    }

    friend std::ostream &operator<<(std::ostream &os, const String &s)
    {
        os << s.str;
        return os;
    }
};

class StrNode
{
public:
    String str;
    StrNode *next;
    StrNode(String str, StrNode *next = nullptr)
    {
        this->str = std::move(str);
        this->next = next;
    }
    ~StrNode()
    {
    }
};

class StrList
{
    StrNode *head;
    int size = 0;

public:
    StrList()
    {
        this->head = nullptr;
    }

    void push_back(String str)
    {
        if (this->head == nullptr)
        {
            this->head = new StrNode(std::move(str));
            size++;
            return;
        }
        StrNode *current = this->head;
        while (current->next != nullptr)
        {
            current = current->next;
        }
        current->next = new StrNode(std::move(str));
        size++;
    }

    void remove(int index)
    {
        if (index < 0 || index >= this->size)
        {
            return;
        }
        if (index == 0)
        {
            StrNode *temp = this->head;
            this->head = this->head->next;
            delete temp;
            size--;
            return;
        }
        StrNode *current = this->head;
        for (int i = 0; i < index - 1; i++)
        {
            current = current->next;
        }
        StrNode *temp = current->next;
        current->next = current->next->next;
        delete temp;
        size--;
    }

    int get_size()
    {
        return this->size;
    }

    String &operator[](int index)
    {
        int i = 0;
        if (index < 0 || index >= this->size)
        {
            throw std::out_of_range("Index out of range");
        }
        StrNode *current = this->head;
        while (i < index)
        {
            current = current->next;
            i++;
        }
        return current->str;
    }

    friend std::ostream &operator<<(std::ostream &os, const StrList &s)
    {
        StrNode *current = s.head;
        while (current != nullptr)
        {
            os << current->str << std::endl;
            current = current->next;
        }
        return os;
    }
};

struct CssBlock
{
    StrList selectors;
    StrList properties_names;
    StrList properties_values;
};

class CssDoubleLinkedNode
{
    CssBlock block[BLOCKSIZE];
    CssDoubleLinkedNode *next;
    CssDoubleLinkedNode *prev;
    int amount = 0;

public:
    friend class CssDoubleLinkedList;
    CssDoubleLinkedNode()
    {
        this->next = nullptr;
        this->prev = nullptr;
    }

    void push_back(const CssBlock block)
    {
        if (this->amount == BLOCKSIZE)
        {
            return;
        }
        this->block[this->amount] = block;
        this->amount++;
    }

    void remove(const int index)
    {
        if (index < 0 || index >= this->amount)
        {
            return;
        }
        for (int i = index; i < this->amount - 1; i++)
        {
            this->block[i] = std::move(this->block[i + 1]);
        }
        this->amount--;
    }

    int get_size()
    {
        return this->amount;
    }

    CssBlock &operator[](const int index)
    {
        return this->block[index];
    }
};

class CssDoubleLinkedList
{
    CssDoubleLinkedNode *head;
    CssDoubleLinkedNode *tail;
    int size;

public:
    CssDoubleLinkedList()
    {
        this->head = nullptr;
        this->tail = nullptr;
        this->size = 0;
    }

    void push_back(CssBlock block)
    {
        if (this->head == nullptr)
        {
            this->head = new CssDoubleLinkedNode();
            this->tail = this->head;
            this->head->push_back(block);
            this->size++;
            return;
        }
        if (this->tail->get_size() == BLOCKSIZE)
        {
            this->tail->next = new CssDoubleLinkedNode();
            this->tail->next->prev = this->tail;
            this->tail = this->tail->next;
        }
        this->tail->push_back(block);
        this->size++;
    }

    void remove(int index)
    {
        if (index < 0 || index >= this->size)
        {
            return;
        }
        CssDoubleLinkedNode *current = this->head;
        while (true)
        {
            if (index < current->get_size())
            {
                current->remove(index);
                break;
            }
            index -= current->get_size();
            current = current->next;
        }
        this->size--;
    }

    int get_size()
    {
        return this->size;
    }

    CssBlock &operator[](int index)
    {
        if (index < 0 || index >= this->size)
        {
            throw std::out_of_range("Index out of range");
        }
        CssDoubleLinkedNode *current = this->head;
        while (true)
        {
            if (index < current->get_size())
            {
                return current->block[index];
            }
            index -= current->get_size();
            current = current->next;
        }
    }

    void print_last_property_value(String property_name, String selector_name)
    {
        if (this->size == 0)
        {
            return;
        }
        CssDoubleLinkedNode *current = this->tail;
        while (current != nullptr)
        {
            for (int i = current->get_size() - 1; i >= 0; i--)
            {
                StrList properties = current->block[i].properties_names;
                for (int j = 0; j < properties.get_size(); j++)
                {
                    if (property_name == properties[j])
                    {
                        StrList selectors = current->block[i].selectors;
                        for (int k = 0; k < selectors.get_size(); k++)
                        {
                            if (selector_name == selectors[k])
                            {
                                std::cout << selector_name << ",E," << property_name << " == " << current->block[i].properties_values[j] << std::endl;
                                return;
                            }
                        }
                    }
                }
            }
            current = current->prev;
        }
    }

    int count_property_amound(String property)
    {
        int result = 0;
        CssDoubleLinkedNode *current = this->head;
        while (current != nullptr)
        {
            for (int i = 0; i < current->get_size(); i++)
            {
                StrList properties = current->block[i].properties_names;
                for (int j = 0; j < properties.get_size(); j++)
                {
                    if (property == properties[j])
                    {
                        result++;
                    }
                }
            }
            current = current->next;
        }
        return result;
    }

    int count_selector_amound(String selector)
    {
        int result = 0;
        CssDoubleLinkedNode *current = this->head;
        while (current != nullptr)
        {
            for (int i = 0; i < current->get_size(); i++)
            {
                StrList selectors = current->block[i].selectors;
                for (int j = 0; j < selectors.get_size(); j++)
                {
                    if (selector == selectors[j])
                    {
                        result++;
                    }
                }
            }
            current = current->next;
        }
        return result;
    }
};

void parse_selectors(String str, CssBlock *css)
{
    String *splitted_str = str.split(',');
    if (splitted_str == nullptr or str.get_len() == 0)
    {
        return;
    }
    int size = str.count(',', true) + 1;
    for (int i = 0; i < size; i++)
    {
        splitted_str[i].delete_symbol('{');
        splitted_str[i].strip(',');
        if (splitted_str[i].get_len() == 0)
            continue;
        int j;
        for (j = 0; j < css->selectors.get_size(); j++)
        {
            if (splitted_str[i] == css->selectors[j])
                break;
        }
        if (j < css->selectors.get_size())
            continue;
        css->selectors.push_back(splitted_str[i]);
    }
    delete[] splitted_str;
}

void parse_properties(String str, CssBlock *css)
{
    if (str.count('{'))
    {
        str.delete_symbol('{');
    }
    if (str.count('}'))
    {
        str.delete_symbol('}');
    }
    if (str.get_char(-1) != ';')
    {
        str.append(";");
    }
    if (str.count(';') > 1)
    {
        String *splitted_str = str.split(';');
        int size = str.count(';', true) + 1;
        for (int i = 0; i < size; i++)
        {
            parse_properties(splitted_str[i], css);
        }
        delete[] splitted_str;
        return;
    }
    String *splitted_str = str.split(':');
    int size = str.count(':', true) + 1;
    if (size != 2)
    {
        delete[] splitted_str;
        return;
    }
    splitted_str[0].strip(':');
    splitted_str[1].strip(';');
    for (int i = 0; i < css->properties_names.get_size(); i++)
    {
        if (css->properties_names[i] == splitted_str[0])
        {
            css->properties_values[i] = std::move(splitted_str[1]);
            delete[] splitted_str;
            return;
        }
    }
    css->properties_names.push_back(splitted_str[0]);
    css->properties_values.push_back(splitted_str[1]);
    delete[] splitted_str;
}

void ParseCss(CssDoubleLinkedList &list)
{
    String input;
    CssBlock block;
    bool block_opened = false;
    while (true)
    {
        input = String();
        input.scan();
        if (input == "????")
            return;

        if (input.count('}'))
        {
            if (input != '}')
            {
                if (block_opened)
                    parse_properties(input, &block);
                else
                {
                    String *splitted_str = input.split('{');
                    input.delete_symbol('}');
                    int size = input.count('{', true) + 1;
                    if (size == 2)
                    {
                        parse_selectors(splitted_str[0], &block);
                        parse_properties(splitted_str[1], &block);
                    }
                    else
                    {
                        parse_properties(input, &block);
                    }
                    delete[] splitted_str;
                }
            }
            list.push_back(block);
            block_opened = false;
            block = CssBlock();
            continue;
        }
        else if (block_opened)
        {
            parse_properties(input, &block);
        }
        else if (input.count('{'))
        {
            if (input != '{')
            {
                parse_selectors(input, &block);
            }
            block_opened = true;
        }
        else
        {
            parse_selectors(input, &block);
        }
    }
}

int get_selectors_amount(CssDoubleLinkedList &csslist, int index)
{
    if (index > csslist.get_size() or index < 1)
        return -1;
    return csslist[index - 1].selectors.get_size();
}

void print_selector(CssDoubleLinkedList &csslist, int block_index, int selector_index)
{
    if (block_index > csslist.get_size() or block_index < 1)
        return;
    if (selector_index > csslist[block_index - 1].selectors.get_size() or selector_index < 1)
        return;
    String selector = csslist[block_index - 1].selectors[selector_index - 1];
    std::cout << block_index << ",S," << selector_index << " == " << selector << std::endl;
}

void S_command_dispather(CssDoubleLinkedList &csslist, String *splited_command)
{
    if (splited_command[2] == "?")
    {
        if (splited_command[0].is_numeric())
        {
            int index = splited_command[0].to_int();
            int amount = get_selectors_amount(csslist, index);
            if (amount != -1)
            {
                std::cout << index << ",S,? == " << amount << std::endl;
            }
        }
        else
        {
            int amount = csslist.count_selector_amound(splited_command[0]);
            std::cout << splited_command[0] << ",S,? == " << amount << std::endl;
        }
    }
    else
    {
        int block_index = splited_command[0].to_int();
        int selector_index = splited_command[2].to_int();
        print_selector(csslist, block_index, selector_index);
    }
}

int get_properties_amount(CssDoubleLinkedList &csslist, int index)
{
    if (index > csslist.get_size() or index < 1)
        return -1;
    return csslist[index - 1].properties_names.get_size();
}

void print_property(CssDoubleLinkedList &csslist, int block_index, String property_name)
{
    if (block_index > csslist.get_size() or block_index < 1)
        return;
    StrList properties = csslist[block_index - 1].properties_names;
    for (int i = 0; i < properties.get_size(); i++)
    {
        if (property_name == properties[i])
        {
            std::cout << block_index << ",A," << property_name << " == " << csslist[block_index - 1].properties_values[i] << std::endl;
        }
    }
}

void A_command_dispather(CssDoubleLinkedList &csslist, String *splited_command)
{
    if (splited_command[2] == "?")
    {
        if (splited_command[0].is_numeric())
        {
            int index = splited_command[0].to_int();
            int amound = get_properties_amount(csslist, index);
            if (amound != -1)
                std::cout << index << ",A,? == " << amound << std::endl;
        }
        else
        {
            int amount = csslist.count_property_amound(splited_command[0]);
            std::cout << splited_command[0] << ",A,? == " << amount << std::endl;
        }
    }
    else
    {
        int block_index = splited_command[0].to_int();
        print_property(csslist, block_index, splited_command[2]);
    }
}

void D_command_dispather(CssDoubleLinkedList &csslist, String *splited_command)
{
    int index = splited_command[0].to_int();
    if (splited_command[2] == "*")
    {
        if (index > 0 && index <= csslist.get_size())
        {
            csslist.remove(index - 1);
            std::cout << index << ",D,* == deleted" << std::endl;
        }
    }
    else
    {
        int block_index = splited_command[0].to_int();
        String property_name = splited_command[2];
        try
        {
            for (int i = 0; i < csslist[block_index - 1].properties_names.get_size(); i++)
            {
                if (property_name == csslist[block_index - 1].properties_names[i])
                {
                    csslist[block_index - 1].properties_names.remove(i);
                    csslist[block_index - 1].properties_values.remove(i);
                    std::cout << block_index << ",D," << property_name << " == deleted" << std::endl;
                    if (csslist[block_index - 1].properties_names.get_size() == 0)
                        csslist.remove(block_index - 1);
                    return;
                }
            }
        }
        catch (const std::exception &e)
        {
        }
    }
}

int main(int, char **)
{
    CssDoubleLinkedList list;
    ParseCss(list);
    String command;
    while (command.scan() != -1)
    {
        if (command == "****")
        {
            ParseCss(list);
        }
        else if (command == "?")
        {
            std::cout << "? == " << list.get_size() << std::endl;
        }
        else if (command == "P")
        {
            for (int i = 0; i < list.get_size(); i++)
            {
                std::cout << "Selectors:" << std::endl;
                for (int j = 0; j < list[i].selectors.get_size(); j++)
                {
                    std::cout << list[i].selectors[j] << " ";
                }
                std::cout << std::endl
                          << "Properties:" << std::endl;
                for (int j = 0; j < list[i].properties_names.get_size(); j++)
                {
                    std::cout << list[i].properties_names[j] << ": " << list[i].properties_values[j] << std::endl;
                }
                std::cout << std::endl;
            }
        }
        else
        {
            String *splited_comm = command.split(',');
            if (splited_comm[1] == "S")
            {
                S_command_dispather(list, splited_comm);
            }
            else if (splited_comm[1] == "A")
            {
                A_command_dispather(list, splited_comm);
            }
            else if (splited_comm[1] == "E")
            {
                list.print_last_property_value(splited_comm[2], splited_comm[0]);
            }
            else if (splited_comm[1] == "D")
            {
                D_command_dispather(list, splited_comm);
            }
            delete[] splited_comm;
        }
    }
    return 0;
}