#pragma once
#include "mystring.h"

class Attribute
{
public:
	MyString attributesName;
	MyString attributesValue;

	Attribute();
	Attribute(const MyString& name, const MyString& value);
};

