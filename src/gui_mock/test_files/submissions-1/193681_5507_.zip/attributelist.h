#pragma once
#include "nodeattribute.h"

class AttributeList
{
	friend class List;
	NodeAttribute* firstNode;
	NodeAttribute* lastNode;

public:
	int counter;
	AttributeList();
	~AttributeList();

	int GetListLen();
	void AddLast(const MyString& newName, const MyString& newValue);
	void RemoveLast();
	NodeAttribute* FindNode(const MyString& name);
	void PrintList();
	MyString* FindAttribute(const MyString& attribute);
	bool IfFindAttribute(const MyString& selector2);
	bool RemoveAttribute(const MyString& attrName);
};

