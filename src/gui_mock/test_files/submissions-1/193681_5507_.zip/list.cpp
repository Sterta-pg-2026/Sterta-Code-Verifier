#include "list.h"
#include "nodelist.h"
#include "section.h"

List::List() {
    firstNode = nullptr;
    lastNode = nullptr;
    counter = 0;
}

List::~List() {
    NodeList* tmp = firstNode;
    NodeList* tmp2 = nullptr;
    while (tmp != nullptr) {
        tmp2 = tmp->nextNode;
        delete tmp;
        tmp = tmp2;
    }
}

void List::PrintList() {
    NodeList* tmp = firstNode;

    std::cout << "Lista selektorow i atrybutow: listy dwukierunkowej\n";
    if (tmp == nullptr) {
        return;
    }
    while (tmp != nullptr) {

        for (int i = 0; i < T; i++) {
            if (tmp->sections[i] != nullptr) {
                tmp->sections[i]->ListOfSelectors.PrintList();
                tmp->sections[i]->ListOfAttributes.PrintList();
            }
			std::cout << '\n';
        }
        tmp = tmp->nextNode;
    }
}

int List::GetListLen() {
    return counter;
}


Section* List::AddSection() {

    if (lastNode == nullptr || lastNode->tabIndex==T) {
        if (firstNode == nullptr) {
            firstNode = new NodeList();
            lastNode = firstNode;
        }
        else {
            NodeList* tmp = lastNode;
            lastNode = new NodeList();
            tmp->nextNode = lastNode;
            lastNode->previousNode = tmp;
        }
        counter++;
    }

    lastNode->sections[lastNode->tabIndex] = new Section();
    lastNode->tabIndex++;
    lastNode->numberOfSections++;

    return lastNode->sections[lastNode->tabIndex-1];
}


bool List::RemoveByIndex(int index) {
    if (firstNode == nullptr) {
        return false;
    }
	
    NodeList* tmp = firstNode;
    int counter = 0;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if(tmp->sections[i] != nullptr) {
                counter++;
            }
            if (counter == index) {
                delete tmp->sections[i];
                tmp->sections[i] = nullptr;
                tmp->numberOfSections--; 
                if(tmp->numberOfSections == 0) {
                    if (tmp->previousNode != nullptr)
                        tmp->previousNode->nextNode = tmp->nextNode;
                    else
                        this->firstNode = tmp->nextNode;

                    if (tmp->nextNode != nullptr)
                        tmp->nextNode->previousNode = tmp->previousNode;
                    else
                        this->lastNode = tmp->previousNode;

                    counter--;
                }
                return true;
            }
        }
        tmp = tmp->nextNode;
    }
    return false;
}


int List::FindNumberOfSelectors(int whichSection) {
    NodeList* tmp = firstNode;
    int number = 0;
    int result = 0;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                number++;
                result = tmp->sections[i]->ListOfSelectors.GetListLen();
            }
            if (number == whichSection) {
                return result;
            }
        }
        tmp = tmp->nextNode;
    }
    return -1;
}


int List::FindNumberOfAttributes(int whichSection) {
    NodeList* tmp = firstNode;
    int number = 0;
    int result;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                number++;
                result = tmp->sections[i]->ListOfAttributes.GetListLen();
            }
            if (number == whichSection) {
                return result;
            }
        }
        tmp = tmp->nextNode;
    }
    return 0;
}


MyString* List::ShowSelector(int whichSection, int whichSelector) {
    NodeList* tmp = firstNode;
    int number = 0;
    MyString sel;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                number++;
            }
            if (number == whichSection) {
                return tmp->sections[i]->ListOfSelectors.FindSelector(whichSelector);
            }
        }
        tmp = tmp->nextNode;
    }
    return nullptr;
}


int List::CountSelectors(const MyString& sel) {
    NodeList* tmp = firstNode;
    int number = 0;
    int result;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                result = tmp->sections[i]->ListOfSelectors.FindNode(sel);
                if (result) {
                    number++;
                }
            }
        }
        tmp = tmp->nextNode;
    }
    return number;
}


int List::CountAttributes(const MyString& attr) {
    NodeList* tmp = firstNode;
    int number = 0;
    int result;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                result = tmp->sections[i]->ListOfAttributes.IfFindAttribute(attr);
                if (result) {
                    number++;
                }
            }
        }
        tmp = tmp->nextNode;
    }
    return number;
}



MyString* List::FindAttributeValue(const MyString& attribute, int whichSection) {
    NodeList* tmp = firstNode;
    int number = 0;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                number++;
            }
            if (number == whichSection) {
                return tmp->sections[i]->ListOfAttributes.FindAttribute(attribute);
            }
        }
        tmp = tmp->nextNode;
    }
    return nullptr;
}



MyString* List::AttributeValueForSelector(const MyString& attrName, const MyString& selector) {
    NodeList* tmp = lastNode;
    MyString* result;

    while (tmp != nullptr) {
        for (int i = tmp->tabIndex-1; i >=0; i--) {
            if (tmp->sections[i] != nullptr) {
                result = tmp->sections[i]->ListOfSelectors.GiveNode(selector);
                if (result) {
                    //Szukamy wartosci atrybutu
                    return tmp->sections[i]->ListOfAttributes.FindAttribute(attrName);
                }
            }
        }
        tmp = tmp->previousNode;
    }
    return nullptr;
}



bool List::RemoveAttribute(const MyString& attr, int whichSection) {
    NodeList* tmp = firstNode;
    int number = 0;

    while (tmp != nullptr) {
        for (int i = 0; i < tmp->tabIndex; i++) {
            if (tmp->sections[i] != nullptr) {
                number++;
            }
            if (number == whichSection) {
                NodeAttribute* pom = tmp->sections[i]->ListOfAttributes.FindNode(attr);

                if (pom != nullptr) {
                    AttributeList* current = &tmp->sections[i]->ListOfAttributes;
                    if(current->counter == 0) {
                        current->firstNode = nullptr;
                        current->lastNode = nullptr;
                    }
                    else if(pom == current->firstNode) {
                        current->firstNode = pom->nextNode;
                    }
                    else {
                        NodeAttribute* p = current->firstNode;
                        while(p != nullptr && p->nextNode != pom) {
                            p = p->nextNode;
                        }
                        p->nextNode = pom->nextNode;
                        if(pom == current->lastNode) {
							current->lastNode = p;
                        }
                    }
                    delete pom;
                    tmp->sections[i]->ListOfAttributes.counter--;
                    if (tmp->sections[i]->ListOfAttributes.counter == 0) {
                        RemoveByIndex(whichSection);
                    }
                    return true;
                }
            }
        }
        tmp = tmp->nextNode;
    }


    return false;
}

