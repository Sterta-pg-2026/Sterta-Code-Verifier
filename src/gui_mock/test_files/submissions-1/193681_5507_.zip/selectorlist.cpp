#include "selectorlist.h"
#include "nodeselector.h"

SelectorList::SelectorList() {
    firstNode = nullptr;
    lastNode = nullptr;
    counter = 0;
}


SelectorList::~SelectorList() {
    NodeSelector* tmp = firstNode;
    NodeSelector* tmp2 = nullptr;

    while (tmp != nullptr) {
        tmp2 = tmp->nextNode;
        delete tmp;
        tmp = tmp2;
    }
}


void SelectorList::PrintList() {
    NodeSelector *tmp = firstNode;

    if (tmp == nullptr) {
        return;
    }
    std::cout << "Lista selektorow:\n";
    while (tmp != nullptr) {
        std::cout << tmp->selector << "\n";
        tmp = tmp->nextNode;
    }
}


int SelectorList::GetListLen() {
    return counter;
}


void SelectorList::AddLast(const MyString& selector) {

    if (firstNode == nullptr) {
        firstNode = new NodeSelector(selector);
        lastNode = firstNode;
        counter++;
    }

    else {
        if (!FindNode(selector)) {
            NodeSelector* tmp = new NodeSelector(selector);
            lastNode->nextNode = tmp;
            lastNode = tmp;
            counter++;
        }
    }
}


void SelectorList::RemoveLast() {
    NodeSelector p;
    char temp[] = "\0";
    MyString empty{ temp };
    if (firstNode==nullptr) {
        return;
    }
    NodeSelector* tmp = firstNode;
    while (tmp->nextNode->nextNode != nullptr) {

        tmp->selector = tmp->nextNode->selector;
        tmp->nextNode = tmp->nextNode->nextNode;
    }
    tmp->nextNode = nullptr;
    counter--;
}


bool SelectorList::FindNode(const MyString& selector2) {
    NodeSelector *tmp = firstNode;

    while (tmp != nullptr) {
        if (tmp->selector == selector2)
            return true;
        tmp = tmp->nextNode;
    }

    return false;
}


MyString* SelectorList::GiveNode(const MyString& selector2) {
    NodeSelector* tmp = firstNode;

    while (tmp != nullptr) {
        if (tmp->selector == selector2)
            return &tmp->selector;
        tmp = tmp->nextNode;
    }

    return nullptr;
}


MyString* SelectorList::FindSelector(int index) {
    NodeSelector* tmp = firstNode;

    if (index > counter) {
        return nullptr;
    }

    for(int i = 1; i < index; i++) {
        tmp = tmp->nextNode;
    }

    return &tmp->selector;
}
