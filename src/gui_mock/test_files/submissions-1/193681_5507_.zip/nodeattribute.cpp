#include "nodeattribute.h"
#include "attribute.h"

NodeAttribute::NodeAttribute() {
	nextNode = nullptr;
};
NodeAttribute::NodeAttribute(const MyString& name, const MyString& value) {
	attribute = Attribute(name, value);
	nextNode = nullptr;
}
NodeAttribute::~NodeAttribute() {}