#pragma once
#include "section.h"

#define T 17

class NodeList
{
	friend class List;
	friend class CSSProcessor;

	NodeList* previousNode;
	NodeList* nextNode;
	Section* sections[T];
	int numberOfSections;   //maleje gdy usuwamy
	int tabIndex;    //nie maleje gdy tabIndex==8 tworzymy nowy w�ze�

public:
	NodeList();
	NodeList(const SelectorList& SelList, const AttributeList& AttrList);
	~NodeList();
};

