#pragma once
#include "nodeselector.h"

class SelectorList
{

	int counter;
	NodeSelector* firstNode;
	NodeSelector* lastNode;

public:
	SelectorList();
	~SelectorList();

	int GetListLen();
	void AddLast(const MyString& newNode);
	void RemoveLast();
	bool FindNode(const MyString& selector2);
	void PrintList();
	MyString* FindSelector(int index);
	MyString* GiveNode(const MyString& selector2);
};

