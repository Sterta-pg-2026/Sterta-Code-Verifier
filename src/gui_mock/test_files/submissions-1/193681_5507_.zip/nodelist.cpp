#include "nodelist.h"
NodeList::NodeList() {
	previousNode = nullptr;
	nextNode = nullptr;
	numberOfSections = 0;
	tabIndex = 0;
	for(int i = 0; i < T; i++) {
		sections[i] = nullptr;
	}
}
NodeList::NodeList(const SelectorList& SelList, const AttributeList& AttrList) {
	sections[tabIndex] = new Section(SelList, AttrList);
	numberOfSections++;
	tabIndex++;
}
NodeList::~NodeList() {
	for (int i = 0; i < T; i++) {
		if (sections[i] != nullptr) {
			delete sections[i];
		}
	}
}