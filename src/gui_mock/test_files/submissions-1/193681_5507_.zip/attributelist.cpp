#include "attributelist.h"
#include "nodeattribute.h"

AttributeList::AttributeList() {
    firstNode = nullptr;
    lastNode = nullptr;
    counter = 0;
}

AttributeList::~AttributeList() {
    NodeAttribute* tmp = firstNode;
    NodeAttribute* tmp2 = nullptr;

    while (tmp != nullptr) {
        tmp2 = tmp->nextNode;
        delete tmp;
        tmp = tmp2;
    }
}

void AttributeList::PrintList() {
    NodeAttribute* tmp = firstNode;
    if (tmp == nullptr) {
        return;
    }
    std::cout << "Lista atrybutow:\n";

    while (tmp != nullptr) {
        std::cout << tmp->attribute.attributesName << ": " << tmp->attribute.attributesValue << "\n";
        tmp = tmp->nextNode;
    }
}

int AttributeList::GetListLen() {
    return counter;
}


void AttributeList::AddLast(const MyString& newName, const MyString& newValue) {

    if (firstNode == nullptr) {
        firstNode = new NodeAttribute(newName, newValue);
        lastNode = firstNode;
        counter++;
    }
    else {
        NodeAttribute* existingNode= FindNode(newName);
        if (existingNode == nullptr) {
            NodeAttribute* tmp = new NodeAttribute(newName, newValue);
            lastNode->nextNode = tmp;
            lastNode = tmp;
            counter++;
        }
        else {
            existingNode->attribute.attributesValue = newValue;
        }
    }
}


NodeAttribute* AttributeList::FindNode(const MyString& name) {
    NodeAttribute* tmp = firstNode;

    while (tmp != nullptr) {
        if (tmp->attribute.attributesName == name)
            return tmp;
        tmp = tmp->nextNode;
    }

    return nullptr;
}

MyString* AttributeList::FindAttribute(const MyString& attribute) {
    NodeAttribute* tmp = firstNode;

    for (int i = 0; i < counter; i++) {
        if (tmp->attribute.attributesName == attribute) {
            return &tmp->attribute.attributesValue;
        }
        tmp = tmp->nextNode;
    }

    return nullptr;
}

bool AttributeList::IfFindAttribute(const MyString& attr) {
    NodeAttribute* tmp = firstNode;

    while (tmp != nullptr) {
        if (tmp->attribute.attributesName == attr)
            return true;
        tmp = tmp->nextNode;
    }

    return false;
}



