#pragma once
#include <iostream>
#include "mystring.h"
#include "nodeselector.h"
#include "selectorlist.h"
#include "list.h"

class CSSProcessor
{
    bool inSection;
    bool inBlock;
    bool prevAttrName;
    bool gotNextSel;
    bool endOfCommands;
    bool bracket;
    bool commands;
    MyString atrybut;
    MyString atrybutValue;
    MyString selector;

    List MainList;
    Section* CurrentSection;

public:
    CSSProcessor();
    void load();
    void eachKey(bool& endOfLine, int& i, char buffor[], char key);
    void Interpreter(char text[], int i);
    void findChar(char key, int counter, char text[]);
    void getSelectors(char text[], int counter);
    void getCommands();
    void eachKeyOfCommand(bool& endOfLine, int& i, char buffor[], char key);
    void InterpreterCommands(char buffor[], int i);
    void doCommands(char buffor[], int counter);

};

