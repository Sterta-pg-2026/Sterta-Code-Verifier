#include "nodeselector.h"

NodeSelector::NodeSelector() {
	selector = { "\0" };
	nextNode = nullptr;
}
NodeSelector::NodeSelector(const MyString& selector2) {
	selector = selector2;
	nextNode = nullptr;
};
NodeSelector::NodeSelector(const MyString& selector2, NodeSelector* ptr) {
	selector = selector2;
	nextNode = ptr;
};