#include "cssprocessor.h"
#include "nodeselector.h"
#include "selectorlist.h"

CSSProcessor::CSSProcessor() {
    inSection = false;
    inBlock = false;
    prevAttrName = false;
    gotNextSel = false;
    endOfCommands = false;
    bracket = false;
    commands = false;
}


void CSSProcessor::load() {
    char buffor[1000];
    char key;
    int i = 0;
    int n = 0;

    bool ignoreAllSpaces = true;
    bool endOfLine = false;
    bool endOfFile = false;

    while (key = getchar()) {
        if (key == '\r') {
            continue;
        }
        if(endOfFile) {
            break;
        }
        if(key == '\xff') {
            endOfFile = true;
            endOfLine = true;
        }
        else if (key == '?')
        {
            if (i == 0)
                commands = true;
        }
        else if(key == ' ') {
            if(!ignoreAllSpaces) {
                endOfLine = true;
            }
        }
        else if(key == '{') {
            ignoreAllSpaces = false;
            endOfLine = true;
            bracket = true;
            inBlock = true;
        }

        else if(key == '}')
        {
			ignoreAllSpaces = true;
            endOfLine = true;
            inBlock = false;
            inSection = false;
        }
        else if(key == ':') {
            if (inBlock) {
				ignoreAllSpaces = true;
            }
        }
        else if(key == ';') {
            ignoreAllSpaces = false;
            endOfLine = true;
        }
        else if(key == ',') {
            ignoreAllSpaces = true;
        }
        else if(key == '\t') {
            endOfLine = true;
        }
        else if(key == '\n') {
            if (inSection || commands)
                endOfLine = true;
            else
                continue;
        }

        eachKey(endOfLine, i, buffor, key);
    }
}



void CSSProcessor::eachKey(bool& endOfLine, int& i, char buffor[], char key) {

    if (endOfLine) {
        buffor[i] = '\0';
        i++;
        Interpreter(buffor, i);
        i = 0;
        endOfLine = false;
    }
    else {
        buffor[i] = key;
        i++;
    }
}



void CSSProcessor::Interpreter(char text[], int i) {
    MyString t = text;
    MyString s = { "????" };

    if (t==s) {
        getCommands();
    }
    else if (inSection) {

        if (inBlock) {
			findChar(':', i, text);
        }
    }
    else {

        if (bracket)
        {
            CurrentSection = MainList.AddSection();
            if (i > 1) {
                getSelectors(text, i);
            }
            inSection = true;
            bracket = false;
        }
    }
}



void CSSProcessor::getSelectors(char text[], int counter) {

    char tmp[1000];
    int k = 0;
    bool frontSpaces = false;

    for (int j = 0; j < counter; j++) {
        if ((text[j] == ' ' || text[j] == '\n' )&& !frontSpaces)
            continue;

        frontSpaces = true;
        tmp[k] = text[j];

        if (text[j] == ',') {
			tmp[k] = '\0';
            frontSpaces = false;
            CurrentSection->ListOfSelectors.AddLast(tmp);
            k = -1;
        }

        k++;
    }

    tmp[k] = '\0';
    
    for(int j = k-2; j >= 0; j--) {
        if (tmp[j] == ' ' || tmp[j] == '\n')
            tmp[j] = '\0';
        else
            break;
    }

    if (tmp[0] != '\0') {
        CurrentSection->ListOfSelectors.AddLast(tmp);
    }
}



void CSSProcessor::findChar(char key, int counter, char text[]) {
    for (int j = 0; j < counter; j++) {
        if (key == ';') {
            if (text[j] == ';') {
                text[j] = '\0';
            }
        }

        if (key == ':') {
            if (text[j] == ':') {
                text[j] = '\0';
                atrybut = text;
                if (text[j + 1] == ' ') {
                    text++;
                }

                if(text[j+1] != '\0'){
					CurrentSection->ListOfAttributes.AddLast(atrybut, text+j+1);
                    return;
                }
            }
        }
    }
}



void CSSProcessor::getCommands() {
    char buffor[100];
    char key;
    int i = 0;
    bool endOfLine = false;
    bool endOfFile = false;

    while (key = getchar()) {
        if(endOfFile) {
            break;
        }
        if (key == '\xff') {
            endOfFile = true;
            endOfLine = true;
        }
        else if (key == '\n') {
            endOfLine = true;
        }

        eachKeyOfCommand(endOfLine, i, buffor, key);
		if (endOfCommands) {
			endOfCommands = false;
			return;
		}
    }
}



void CSSProcessor::eachKeyOfCommand(bool& endOfLine, int& i, char buffor[], char key) {
    if (endOfLine) {
        buffor[i] = '\0';
        i++;
        InterpreterCommands(buffor, i);
        i = 0;
        endOfLine = false;
    }
    else {
        buffor[i] = key;
        i++;
    }
}



void CSSProcessor::InterpreterCommands(char buffor[], int i) {
    int n = 0;
    bool shortCommand = false;
    MyString t = buffor;
    MyString s = { "****" };

    if (t == s) {
        endOfCommands = true;
        commands = false;
        return;
    }

    else if (buffor[0] == '?') {
        NodeList* tmp = MainList.firstNode;
        int number = 0;

        while (tmp != nullptr) {
            number += tmp->numberOfSections;
            tmp = tmp->nextNode;
        }

        if (n == 0) {
            std::cout << "? == " << number << "\n";
        }
        n++;
        shortCommand = true;
    }

    if (buffor[0] != '\0' && shortCommand==false) {
        doCommands(buffor, i);
    }
}



void CSSProcessor::doCommands(char buffor[], int counter) {
    char tmp[100];
    int k = 0;
    char firstValue[100]="\0";
    char secondValue='\0';
    char thirdValue[100]= "\0";
    long firstNumber=-1, thirdNumber=-1;
    int n = 0;
    bool frontSpaces = false;

    for (int j = 0; j < counter; j++) {
        if (buffor[j] == ' ' && !frontSpaces) {
            continue;
        }

        frontSpaces = true;
        tmp[k] = buffor[j];

        if (buffor[j] == ',') {
            tmp[k] = '\0';
            if (n == 0) {

                frontSpaces = false;
                if (atol(tmp)!=0) {
                    firstNumber = atol(tmp);
                }

                else {
                    for (int a = 0; a <= k; a++) {

                        firstValue[a] = tmp[a];
                    }
                }
            }

            else if (n == 1) {
                secondValue = tmp[k - 1];
            }
            n++;
            k = -1;
        }
        k++;
    }

    tmp[k] = '\0';
    if (n == 2) {
        if (atol(tmp) != 0) {
            thirdNumber = atol(tmp);
        }
        else {
            for (int a = 0; a <= k; a++) {
                thirdValue[a] = tmp[a];
            }
        }
    }
    n = 0;



    if (secondValue == 'S') {
        MyString t = thirdValue;
        MyString s = { "?" };

        if (t==s) {
            //i,S,? Â wypisz liczbe selektorow dla sekcji nr i (numery zaczynaja sie od 1), 
            //jesli nie ma takiego bloku pomin.
            if (firstNumber!=-1) {
                int number = MainList.FindNumberOfSelectors(firstNumber);
                if (number != -1) {
                    std::cout << buffor << " == " << number << "\n";
                }
            }

            // z,S,? Â wypisz laczna(dla wszystkich blokow) liczbe wystapien selektora z. Mozliwe jest 0.
            else if (firstValue[0] != '\0') {
                MyString sel = firstValue;
                int result= MainList.CountSelectors(sel);
                std::cout << buffor << " == " << result << "\n";
            }
        }

        //i,S,j Â wypisz j-ty selector dla i-tej sekcji (numery sekcji oraz atrybutow zaczynaja sie od 1) 
        //jesli nie ma sekcji lub selektora pomin.
        if (thirdNumber!=-1) {
            MyString* result = MainList.ShowSelector(firstNumber, thirdNumber);
            if (result != nullptr) {
                std::cout << buffor << " == " << *result << "\n";
            }
        }
    }

    if (secondValue == 'A') {

        //i,A,? - wypisz liczbe atrybutow dla sekcji nr i, jesli nie ma takiego bloku lub sekcji pomin.
        if (thirdValue[0]=='?') {
            if (firstNumber != -1) {
                int number = MainList.FindNumberOfAttributes(firstNumber);
                if (number != 0) {
                    std::cout << buffor << " == " << number << "\n";
                }
            }

            //n,A,? Â wypisz Â³aczna (dla wszystkich blokow) liczbe wystapien atrybutu nazwie n. (W ramach
            //pojedynczego bloku duplikaty powinny zostac usuniete na etapie wczytywania). Mozliwe jest 0.
            else if (firstValue[0] != '\0') {
                MyString attr = firstValue;
                int result = MainList.CountAttributes(attr);
                std::cout << buffor << " == " << result << "\n";
            }

        }

        //i,A,n Â wypisz dla i-tej sekcji wartosc atrybutu o nazwie n, jesli nie ma takiego pomin.
        if (thirdValue[0] != '\0') {
            if (firstNumber != -1) {
                MyString attr = thirdValue;
                MyString* result = MainList.FindAttributeValue(attr, firstNumber);
                if (result != nullptr) {
                    std::cout << buffor << " == " << *result << "\n";
                }
            }
        }

    }

    if (secondValue == 'E') {
        //z,E,n Â wypisz wartosc atrybutu o nazwie n dla selektora z, w przypadku wielu 
        //wystapien selektora z bierzemy ostatnie.W przypadku braku pomin.

        if (thirdValue[0] != '\0') {
            if (firstValue[0] != '\0') {
                MyString* result = MainList.AttributeValueForSelector(thirdValue, firstValue);
                if (result != nullptr) {
                    std::cout << buffor << " == " << *result << "\n";
                }
            }
        }
    }

    if (secondValue == 'D') {
        //i,D,* - usun cala sekcje nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted.
        if (thirdValue[0] == '*') {
            if (firstNumber!=-1) {
                bool result = MainList.RemoveByIndex(firstNumber);
                if (result) {
                    std::cout << buffor << " == " << "deleted\n";
                }
            }
        }

        //i,D,n Â usun z i-tej sekcji atrybut o nazwie n, jesli w wyniku operacji pozostaje 
        //pusta sekcja powinna zostac rowniez usunieta(wraz z ew.selektorami), po poprawnym 
        //wykonaniu wypisz deleted.
        else if (thirdValue[0] != '\0') {
            if (firstNumber != -1) {
                bool result = MainList.RemoveAttribute(thirdValue, firstNumber);
                if (result) {
                    std::cout << buffor << " == " << "deleted\n";
                }
            }
        }
    }
}

