#pragma once
#include "attribute.h"

class NodeAttribute
{
	friend class AttributeList;

	Attribute attribute;

public:
	NodeAttribute* nextNode;
	NodeAttribute();
	NodeAttribute(const MyString& name, const MyString& value);
	~NodeAttribute();

};

