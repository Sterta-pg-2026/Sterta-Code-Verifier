#pragma once
#include "mystring.h"

class NodeSelector
{
	friend class SelectorList;

	MyString selector;
	NodeSelector* nextNode;

public:
	NodeSelector();
	NodeSelector(const MyString& selector2);
	NodeSelector(const MyString& selector2, NodeSelector* ptr);

};

