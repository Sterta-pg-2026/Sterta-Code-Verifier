#pragma once
#include "nodelist.h"

class List
{
	friend class CSSProcessor;
	NodeList* firstNode;
	NodeList* lastNode;
	
	
public:
	int counter;

	List();
	~List();

	void PrintList();
	int GetListLen();
	Section* AddSection();
	bool RemoveByIndex(int index);
	NodeList* FindNode(int index);
	int FindNumberOfSelectors(int whichSection);
	int FindNumberOfAttributes(int whichAttribute);
	MyString* ShowSelector(int whichSection, int whichSelector);
	int CountSelectors(const MyString& sel);
	int CountAttributes(const MyString& attr);
	MyString* FindAttributeValue(const MyString& attribute, int whichSection);
	MyString* AttributeValueForSelector(const MyString& attrName, const MyString& selector);
	bool RemoveAttribute(const MyString& attr, int whichSection);

};

