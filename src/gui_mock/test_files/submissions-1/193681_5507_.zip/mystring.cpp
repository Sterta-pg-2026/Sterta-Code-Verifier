#include "mystring.h"

MyString& MyString::operator=(const MyString& string)
{
    if (this == &string)
        return *this;

    delete[] str;
    str = new char[strlen(string.str) + 1];
    strcpy(str, string.str);

    return *this;
}

bool operator==(const MyString& string1, const MyString& string2)
{
    if (strlen(string1.str) != strlen(string2.str))
        return false;

    for (int i = 0; i < strlen(string1.str); i++) {
        if (string1.str[i] != string2.str[i]) {
            return false;
        }
    }

    return true;
}

bool MyString::operator!=(const MyString& string)
{
    if (this != &string)
        return true;
    else
        return false;
}


MyString operator+(const MyString& lhs, const MyString& rhs)
{
    int length = strlen(lhs.str) + strlen(rhs.str);

    char* buff = new char[length + 1];

    strcpy(buff, lhs.str);
    strcat(buff, rhs.str);
    buff[length] = '\0';

    MyString temp{ buff };
    delete[] buff;

    return temp;
}

std::istream& operator>>(std::istream& is, MyString& obj)
{
    char* buff = new char[1000];
    memset(&buff[0], 0, sizeof(buff));  
    is >> buff;
    obj = MyString{ buff };
    delete[] buff;
    return is;
}


std::ostream& operator<<(std::ostream& os, const MyString& obj)
{
    os << obj.str;
    return os;
}


int MyString::get_length()
{
    return strlen(str);
}


MyString::MyString()
    : str{ nullptr }
{
    str = new char[1];
    str[0] = '\0';
}


MyString::MyString(const char* value)
{
    if (value == nullptr) {
        str = new char[1];
        str[0] = '\0';
    }

    else {

        str = new char[strlen(value) + 1];

        strcpy(str, value);
        str[strlen(value)] = '\0';
    }
}


MyString::MyString(const MyString& source)
{
    str = new char[strlen(source.str) + 1];
    strcpy(str, source.str);
}


MyString::MyString(MyString&& source)
{
    str = source.str;
    source.str = nullptr;
}