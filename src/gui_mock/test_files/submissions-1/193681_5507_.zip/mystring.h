#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

class MyString
{
    friend std::ostream& operator<<(std::ostream& os, const MyString& obj);
    friend std::istream& operator>>(std::istream& is, MyString& obj);
    friend MyString operator+(const MyString& lhs, const MyString& rhs);
    friend bool operator==(const MyString& string1, const MyString& string2);
    char* str;

public:
    MyString();
    MyString(const char* value);
    MyString(const MyString& source);
    MyString(MyString&& source);
    int get_length();
    MyString& operator=(const MyString& string);
    bool operator!=(const MyString& string);

    ~MyString() { 
        delete str; 
    }
};

