#pragma once
#include "selectorlist.h"
#include "attributelist.h"

class Section
{
	friend class List;
	friend class NodeList;

public:
	SelectorList ListOfSelectors;
	AttributeList ListOfAttributes;

	Section();
	Section(SelectorList SelList, AttributeList AttrList);
};

