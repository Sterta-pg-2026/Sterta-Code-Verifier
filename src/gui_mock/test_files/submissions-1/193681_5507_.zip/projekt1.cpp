﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include "cssprocessor.h"


int main()
{
    CSSProcessor *main = new CSSProcessor();
    main->load();
    delete main;

    return 0;
}
