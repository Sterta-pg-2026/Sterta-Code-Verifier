#include "section.h"

Section::Section(){
	ListOfSelectors = SelectorList();
	ListOfAttributes = AttributeList();
}

Section::Section(SelectorList SelList, AttributeList AttrList) {
	ListOfSelectors = SelList;
	ListOfAttributes = AttrList;
}