#include "attribute.h"

Attribute::Attribute() {
	char temp[] = "\0";
	MyString empty = temp;
	attributesName = empty;
	attributesValue = empty;
}
Attribute::Attribute(const MyString& name, const MyString& value) {
	attributesName = name;
	attributesValue = value;
}