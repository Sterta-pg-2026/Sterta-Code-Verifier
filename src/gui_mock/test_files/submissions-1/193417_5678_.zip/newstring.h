#pragma once
#include <iostream>
class NewString {
private:
	char* value;
public:
	NewString();
	~NewString();
	NewString(char* source);
	NewString(const NewString& string);
	NewString& operator=(const NewString& string);
	friend NewString operator+(const NewString& left, const NewString& right);
	friend std::ostream& operator<<(std::ostream& os, const NewString& string);
	int getSize();
	bool equals(NewString string);
	int contains(char character);
	char get(int index);
	NewString divide(int start, int end);
	NewString deleteSides(NewString string);
    void trim(); 
};
