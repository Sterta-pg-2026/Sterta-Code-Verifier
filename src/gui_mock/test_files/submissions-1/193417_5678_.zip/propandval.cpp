#include "propandval.h"
NewString PropAndVal::getProperty() {
	return this->property;
}
NewString PropAndVal::getValue() {
	return this->value;
}
PropAndVal::PropAndVal() {};
PropAndVal::PropAndVal(NewString property, NewString value)
	:property{ property }, value{ value } {}
std::ostream& operator<<(std::ostream& os, const PropAndVal& propAndVal) {
	os << propAndVal.property << ":" << propAndVal.value << std::endl;
	return os;
}