#include <iostream>
#include <string>
#include "list.h"
#include "newstring.h"
#include "propandval.h"
#include "section.h"
#include "parser.h"

int main()
{
    const int blockSize = 8;
    List<Section*> list;
    Parser parser(blockSize, &list);
    NewString answer;

    int decision = 1;
    while (decision != -1) {
        switch (decision) {
        case 1:
            decision = parser.parseCSS();
            break;
        case 0:
            decision = parser.parseCommands(&answer);
        }
    }

    std::cout << answer;
    
    
}

