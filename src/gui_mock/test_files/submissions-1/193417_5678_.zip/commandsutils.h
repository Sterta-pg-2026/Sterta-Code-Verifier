#pragma once
#include "list.h"
#include "newstring.h"
#include "section.h"
class CommandsUtils {
private:
	List<Section*> list;
	int blockSize;
public:
	CommandsUtils(List<Section*>* list, int blockSize);
	int getAllSectionsCount();
	int getSelectorsForSection(int sectionNumber);
	int getAttributesForSection(int sectionNumber);
	Section getSection(int sectionNumber);
	NewString getSelector(int selectorNumber, int sectionNumber);
	NewString getSelectorFromSection(int selectorNumber, Section section);
	NewString getAttribueValue(int sectionNumber, NewString name);
	NewString getAttributeValueFromSection(Section section, NewString name);
	int getAllAttributeCount(NewString name);
	int getAllSelectorCount(NewString name);
	void changeSection(int sectionNumber, Section newSection);
	NewString getAttributeValueBySelector(NewString value, NewString selector);
};