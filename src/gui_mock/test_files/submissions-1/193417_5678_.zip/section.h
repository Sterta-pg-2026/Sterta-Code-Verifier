#pragma once
#include "newstring.h"
#include "propandval.h"
#include "list.h"
class Section {
	List<NewString> selectors;
	List<PropAndVal> properties;
	bool isUsed;
public:
	Section();
	Section(List<NewString> selectors, List<PropAndVal> properties);
	NewString getValueOf(NewString property);
	bool doesSelectorExist(NewString selector);
	bool doesAttributeExist(NewString attribute);
	int deleteAttribute(NewString attribute);
	bool getIsUsed();
	void displaySelectors();
	void displayProperties();
	void displaySection();
	int getSelectorsCount();
	int getPropertiesCount();
	List<NewString> getSelectors();
	List<PropAndVal> getProperties();
};