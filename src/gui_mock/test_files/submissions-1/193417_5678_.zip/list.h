#pragma once
template <typename T>
class List {
private:
	struct Node {
		T data;
		Node* previous;
		Node* next;
		Node(const T d, Node* prev, Node* n)
			:data{ d }, previous{ prev }, next{ n }{};
	};
	Node* head;
	Node* tail;
	int size;
public:
	List()
		:head(nullptr), tail(nullptr), size(0){}
	~List() {
		while (head != nullptr) {
			Node* temp = head;
			head = head->next;
			delete temp;
		}
		size = 0;
	}

	List(const List& list)
		:head(nullptr), tail(nullptr), size(0) {
		Node* current = list.head;
		while (current != nullptr) {
			add(current->data);
			current = current->next;
		}
	}

	int getSize() {
		return this->size;
	}
	void add(const T data) {
		Node* newNode = new Node(data, tail, nullptr);
		if (tail == nullptr) {
			head = newNode;
		}
		else {
			tail->next = newNode;
		}
		tail = newNode;
		size++;
	}

	T& get(int index) {
		Node* current = head;
		for (int i = 0; i < index; i++) {
			current = current->next;
		}
		return current->data;
	}



	List& operator=(const List& other) {
		while (head != nullptr) {
			Node* temp = head;
			head = head->next;
			delete temp;
		}
		size = 0;

		Node* current = other.head;
		while (current != nullptr) {
			add(current->data);
			current = current->next;
		}

		return *this;
	}

	void change(const T data, int index) {
		Node* current = head;
		for (int i = 0; i < index; i++) {
			current = current->next;
		}
		current->data = data;
	}

	int contains(const T& data)  {
		Node* current = head;
		int i = 0;
		while (current != nullptr) {
			if (current->data == data) {
				return i;
			}
			current = current->next;
			i++;
		}
		return -1;
	}

	void remove(int index) {
		if (index < 0 || index >= size) {
			return;
		}

		Node* current = head;
		for (int i = 0; i < index; i++) {
			current = current->next;
		}

		if (current == head) {
			head = current->next;
		}
		else {
			current->previous->next = current->next;
		}

		if (current == tail) {
			tail = current->previous;
		}
		else {
			current->next->previous = current->previous;
		}

		delete current;
		size--;
	}
};
