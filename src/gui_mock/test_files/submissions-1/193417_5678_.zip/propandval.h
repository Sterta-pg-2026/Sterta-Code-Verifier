#pragma once
#include "newstring.h"
class PropAndVal {
private:
	NewString property;
	NewString value;
public:
	PropAndVal();
	PropAndVal(NewString property, NewString value);
	friend std::ostream& operator<<(std::ostream& os, const PropAndVal& propAndVal);
	NewString getValue();
	NewString getProperty();
};
