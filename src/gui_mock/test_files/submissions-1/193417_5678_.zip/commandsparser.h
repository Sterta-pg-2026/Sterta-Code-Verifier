#pragma once
#include "commandsutils.h"
class CommandsParser {
private:
	List<Section*>* list;
	int blockSize;
	NewString* answer;
	CommandsUtils utils;
public:
	CommandsParser(List<Section*>* list, int blockSize, NewString* answer);
	void handleCommand(NewString command);
	void commandA(int sectionNumber);
	void commandA(int sectionNumber, NewString attribute);
	void commandA(NewString attribute);
	void commandS(int sectionNumber);
	void commandS(int sectionNumber, int selectorNumber);
	void commandS(NewString selectorName);
	void commandE(NewString attributeName, NewString selectorName);
	void commandD(int sectionNumber);
	void commandD(int sectionNumber, NewString attribute);
	void deleteSectionByNumber(int sectionNumber);
	int getNumberArgument(NewString command, int start, int end);
	NewString getNewStringArgument(NewString command, int start, int end);
};
