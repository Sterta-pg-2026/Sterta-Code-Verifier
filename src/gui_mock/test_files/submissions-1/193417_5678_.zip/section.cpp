#include "section.h"
Section::Section()
	:isUsed{ false } {}
Section::Section(List<NewString> selectors, List<PropAndVal> properties)
	:selectors{ selectors }, properties{ properties }, isUsed{true} {}


NewString Section::getValueOf(NewString property) {
	int propAndValSize = properties.getSize();
	NewString response;
	for (int i = 0; i < propAndValSize; i++) {
		PropAndVal propAndVal = properties.get(i);
		if (propAndVal.getProperty().equals(property)) {
			response = propAndVal.getValue();
			return response;
		}
	}
	return response;
}

bool Section::doesSelectorExist(NewString selector) {
	int selectorsSize = selectors.getSize();
	for (int i = 0; i < selectorsSize; i++) {
		NewString listSelector = selectors.get(i);
		if (selector.equals(listSelector)) return true;
	}
	return false;
}

void Section::displaySelectors() {
	int selectorsSize = selectors.getSize();
	for (int i = 0; i < selectorsSize; i++) {
		std::cout <<"SELECTOR " << i << ": " << selectors.get(i) << std::endl;
	}
}

void Section::displayProperties() {
	int propertiesSize = properties.getSize();
	for (int i = 0; i < propertiesSize; i++) {
		PropAndVal prop = properties.get(i);
		std::cout << "PROPERTY " << i << ": " << prop.getProperty() << " AND VALUE: " << prop.getValue() << std::endl;
	}
}

void Section::displaySection() {
	std::cout << "========" << std::endl;
	displaySelectors();
	displayProperties();
	std::cout << "========" << std::endl;
}

bool Section::getIsUsed() {
	return this->isUsed;
}

int Section::getSelectorsCount() {
	return selectors.getSize();
}
int Section::getPropertiesCount() {
	return properties.getSize();
}

List<NewString> Section::getSelectors() {
	return selectors;
}
List<PropAndVal> Section::getProperties() {
	return properties;
}

bool Section::doesAttributeExist(NewString attribute) {
	int attributesSize = properties.getSize();
	for (int i = 0; i < attributesSize; i++) {
		PropAndVal propAndVal = properties.get(i);
		NewString attributeArr = propAndVal.getProperty();
		if (attributeArr.equals(attribute)) return true;
	}
	return false;
}


int Section::deleteAttribute(NewString attribute) {
	for (int i = 0; i < properties.getSize(); i++) {
		NewString property = properties.get(i).getProperty();
		if (property.equals(attribute)) {
			properties.remove(i);
			return properties.getSize();
		}
	}
	return -1;
}