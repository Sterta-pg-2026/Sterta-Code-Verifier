#include "newstring.h"
#include <string.h>
NewString::NewString() {
	value = new char[1];
	value[0] = '\0';
}
NewString::~NewString() {
	delete[] value;
}

NewString::NewString(char* source) {
	if (source == nullptr) {
		this->value = new char[1];
		value[0] = '\0';
	}
	else {
		int length = strlen(source) + 1;
		this->value = new char[length];
		strcpy_s(this->value,length, source);
		value[strlen(source)] = '\0';
	}
}

NewString::NewString(const NewString& string) {
	size_t length = strlen(string.value) + 1;
	value = new char[length];
	strcpy_s(value, length, string.value);
}

NewString operator+(const NewString& left, const NewString& right) {
	int length = strlen(left.value) + strlen(right.value) + 1;

	char* buffer = new char[length];
	strcpy_s(buffer, length, left.value);
	strcat_s(buffer, length, right.value);
	buffer[length - 1] = '\0';

	NewString string(buffer);
	delete[] buffer;
	return string;
}

std::ostream& operator<<(std::ostream& os, const NewString& string) {
	os << string.value;
	return os;
}
NewString& NewString::operator=(const NewString& string) {
	delete[] this->value;
	size_t length = strlen(string.value) + 1;
	this->value = new char[length];
	strcpy_s(this->value, length, string.value);

	return *this;
}
int NewString::getSize() {
	return strlen(value);
}
bool NewString::equals(NewString string) {
	char* stringChar = string.value;
	if (strlen(value) != strlen(stringChar)) return false;
	int size = strlen(this->value);

	for (int i = 0; i < size; i++) {
		if (this->value[i] != stringChar[i]) return false;
	}
	return true;
	
}

int NewString::contains(char character) {
	int size = this->getSize();
	for (int i = 0; i < size; i++) {
		if (this->value[i] == character) return i;
	}
	return -1;
}

char NewString::get(int index) {
	return this->value[index];
}

NewString NewString::divide(int startIncluding, int endIncluding) {
	char newStringArr[1024];

	int i = 0;
	while (startIncluding <= endIncluding) {
		newStringArr[i] = this->value[startIncluding];
		startIncluding++;
		i++;
	}
	newStringArr[i] = '\0';

	NewString response(newStringArr);
	return response;
}

void NewString::trim() {
	int length = strlen(value);
	int start = 0;
	int end = length - 1;

	// Usu biae znaki z pocztku
	while (start < length && isspace(value[start])) {
		start++;
	}

	// Usu biae znaki z koca
	while (end >= start && isspace(value[end])) {
		end--;
	}

	// Skopiuj acuch z nowymi granicami
	char* buffer = new char[end - start + 2];
	strncpy_s(buffer, end - start + 2, value + start, end - start + 1);
	buffer[end - start + 1] = '\0';

	// Zaktualizuj acuch
	delete[] value;
	value = buffer;
}
