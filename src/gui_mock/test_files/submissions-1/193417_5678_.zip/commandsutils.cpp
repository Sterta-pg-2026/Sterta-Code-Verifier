#include "commandsutils.h"

CommandsUtils::CommandsUtils(List<Section*>* list, int blockSize)
	:list{ *list }, blockSize{blockSize} {}

int CommandsUtils::getAllSectionsCount() {
	
	int sectionsCount = 0;
	int size = list.getSize();
	if (size == 0) {
		return 0;
	}
		for (int i = 0; i < size; i++) {
			Section* sections = list.get(i);
			for (int j = 0; j < blockSize; j++) {
				if (sections[j].getIsUsed()) sectionsCount++;
			}
		}
	return sectionsCount;
}

Section CommandsUtils::getSection(int sectionNumber) {
	int size = list.getSize();
	Section empty;
	if (size == 0) {
		return empty;
	}
	
		int used = 0;
		for (int i = 0; i < list.getSize(); i++) {
			Section* sections = list.get(i);
			for (int j = 0; j < blockSize; j++) {
				if (sections[j].getIsUsed()) used++;
				if (used == sectionNumber) {
					return sections[j];
				}
			}
		}
	
		return empty;
}

void CommandsUtils::changeSection(int sectionNumber, Section newSection) {
	int size = list.getSize();
	int count = 0;

	for (int i = 0; i < list.getSize(); i++) {
		Section* sections = list.get(i);
		for (int j = 0; j < blockSize; j++) {
			if (sections[j].getIsUsed()) count++;
			if (count == sectionNumber) {
				sections[j] = newSection;
				return;
			}
		}
	}
}

int CommandsUtils::getAttributesForSection(int sectionNumber) {
	Section section = getSection(sectionNumber);
	if (!section.getIsUsed()) return -1;
	return section.getPropertiesCount();
}

int CommandsUtils::getSelectorsForSection(int sectionNumber) {
	Section section = getSection(sectionNumber);
	if (!section.getIsUsed()) return -1;
	return section.getSelectorsCount();
}

NewString CommandsUtils::getSelector(int selectorNumber, int sectionNumber) {
	Section section = getSection(sectionNumber);
	return getSelectorFromSection(selectorNumber, section);
	
}

NewString CommandsUtils::getAttributeValueFromSection(Section section, NewString name) {
	return section.getValueOf(name);
}

NewString CommandsUtils::getSelectorFromSection(int selectorNumber, Section section) {
	List<NewString> selectors = section.getSelectors();
	NewString emptyString;
	if (selectors.getSize() < selectorNumber) return emptyString;
	return selectors.get(selectorNumber - 1);
}

NewString CommandsUtils::getAttribueValue(int sectionNumber, NewString name) {
	Section section = getSection(sectionNumber);
	return getAttributeValueFromSection(section, name);
}

int CommandsUtils::getAllAttributeCount(NewString name) {
	int size = list.getSize();
	if (size == 0) {
		return 0;
	}
	else {
		int count = 0;
		for (int i = 0; i < list.getSize(); i++) {
			Section* sections = list.get(i);
			for (int j = 0; j < blockSize; j++) {
				if (sections[j].getIsUsed() && sections[j].doesAttributeExist(name)) count++;
			}
		}
		return count;
	}
	return 0;
}

int CommandsUtils::getAllSelectorCount(NewString name) {
	int size = list.getSize();
	if (size == 0) {
		return 0;
	}
	else {
		int count = 0;
		for (int i = 0; i < size; i++) {
			Section* sections = list.get(i);
			for (int j = 0; j < blockSize; j++) {
				if (sections[j].getIsUsed() && sections[j].doesSelectorExist(name)) count++;
			}
		}
		return count;
	}
	return 0;
}

NewString CommandsUtils::getAttributeValueBySelector(NewString attribute, NewString selector) {
	int size = list.getSize();
	if (size == 0) {
		NewString response;
		Section* sections = list.get(0);
		for (int i = 0; i < blockSize; i++) {
			if (sections[i].getIsUsed() && sections[i].doesSelectorExist(selector) && sections[i].doesAttributeExist(attribute)) {
				response = sections[i].getValueOf(attribute);
			}
		}
		return response;
	}
	else {
		NewString response;
		for (int i = 0; i < list.getSize(); i++) {
			Section* sections = list.get(i);
			for (int j = 0; j < blockSize; j++) {
				if (sections[j].getIsUsed() && sections[j].doesSelectorExist(selector) && sections[j].doesAttributeExist(attribute)) {
					response = sections[j].getValueOf(attribute);
				}
			}
		}
		return response;
	}
	NewString emptyResponse;
	return emptyResponse;
}



