#pragma once
#include "list.h"
#include "section.h"
#include "commandsparser.h"
class Parser {
private:
	int sectionSize;
	List<Section*>* list;
	
public:
	Section parseSection(NewString firstLine);
	List<NewString> parseSelectors(NewString line);
	List<PropAndVal> parseProperties(NewString line, int end, int start);
	PropAndVal parsePropertyAndValue(int* index, NewString line);
	NewString parseValue(int* index, NewString line);
	Parser(int sectionSize, List<Section*>* list);
	int parseCSS();
	int parseCommands(NewString* answer);
	void insertSectionIntoList(Section section);
	List<PropAndVal> parseProperties(NewString line);
	int isPresentInList(PropAndVal propAndVal, List<PropAndVal> list);
};