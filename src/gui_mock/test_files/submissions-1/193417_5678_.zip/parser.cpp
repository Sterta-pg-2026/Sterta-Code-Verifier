#include "parser.h"
Parser::Parser(int sectionSize, List<Section*>* list)
	:sectionSize{ sectionSize }, list{list} {}

int Parser::parseCSS() {
	NewString textLine;
	char endOfCSSSectionChar[] = "????";
	NewString endOfCSSSection(endOfCSSSectionChar);
	char buffer[1024] = { 0 };

	std::cin.getline(buffer, 1024);
	textLine = buffer;
	while (!textLine.equals(endOfCSSSection)) {
		Section section(parseSection(textLine));
		insertSectionIntoList(section);
		
		std::cin.getline(buffer, 1024);
		if (strlen(buffer) == 0) {
			do {
				std::cin.getline(buffer, 1024);
			} while (strlen(buffer) == 0);
		}
		textLine = buffer;
	}
	return 0;
}

Section Parser::parseSection(NewString firstLine) {
	char rightCurlyBrace = '}';
	char leftCurlyBrace = '{';
	int rightCBIndex = firstLine.contains(rightCurlyBrace);
	int leftCBIndex = firstLine.contains(leftCurlyBrace);
	List<NewString> selectors = parseSelectors(firstLine);
	
	if (rightCBIndex != -1) {
		List<PropAndVal> propAndVal = parseProperties(firstLine, rightCBIndex, leftCBIndex + 1);
		Section section(selectors, propAndVal);
		return section;
	}
	if (rightCBIndex == -1 && leftCBIndex != -1) {
		char buffer[1024] = { 0 };
		std::cin.getline(buffer, 1024);
		NewString textLine = buffer;
		List<PropAndVal> propAndVal = parseProperties(textLine);
		Section section(selectors, propAndVal);
		return section;
	}
	//theres nor right neither left CB in this line
	char buffer[1024] = { 0 };
	std::cin.getline(buffer, 1024);
	std::cin.getline(buffer, 1024);
	NewString textLine = buffer;
	List<PropAndVal> propAndVal = parseProperties(textLine);
	Section section(selectors, propAndVal);
	return section;
}

PropAndVal Parser::parsePropertyAndValue(int* index, NewString line) {
	char typek = ':';
	char blankSpace = ' ';
	char propertyArr[1024];
	int propertyArrIndex = 0;
	int size = line.getSize();

	while (( * index) < size) {
		char character = line.get(( * index));
		if (character == typek) {
			propertyArr[propertyArrIndex] = '\0';
			NewString property(propertyArr);
			property.trim();
			(*index)++;
			NewString value = parseValue( index, line);
			PropAndVal propAndValue(property, value);
			return propAndValue;
		}
		else if (character != blankSpace) {
			propertyArr[propertyArrIndex] = character;
			propertyArrIndex++;
		}
		(*index)++;
	}
	PropAndVal empty;
	return empty;
}

NewString Parser::parseValue(int* index, NewString line) {
	char typek = ';';
	char typek2 = '}';
	char blankSpace = ' ';
	char valueArr[1024];
	int valueArrIndex = 0;
	int size = line.getSize();

	while ((*index) < size) {
		char character = line.get((*index));
		if (character == typek || character == typek2) {
			(*index)++;
			valueArr[valueArrIndex] = '\0';
			NewString result(valueArr);
			result.trim();
			return result;
		}
		else {
			valueArr[valueArrIndex] = character;
			valueArrIndex++;
		}
		(*index)++;
	}
	NewString empty;
	return empty;

}

List<PropAndVal> Parser::parseProperties(NewString line, int end, int start) {
	List<PropAndVal> propAndValList;
	while (start < end) {
		bool flag = true;
		PropAndVal propAndVal = parsePropertyAndValue(&start, line);
		for (int i = 0; i < propAndValList.getSize(); i++) {
			if (propAndValList.get(i).getProperty().equals(propAndVal.getProperty())) {
				propAndValList.change(propAndVal, i);
				flag = false;
				break;
			}
		}

		if (flag) propAndValList.add(propAndVal);
	}
	return propAndValList;
}

List<PropAndVal> Parser::parseProperties(NewString firstLine) {
	List<PropAndVal> propAndValList;
	NewString line = firstLine;
	char buffer[1024] = { 0 };
	int curlyBrace = firstLine.contains('}');
	int colon = firstLine.contains(':');
	int semicolon = firstLine.contains(';');

	while (curlyBrace == -1) {
		NewString property = line.divide(0, colon - 1);
		property.trim();
		NewString value = line.divide(colon + 1, semicolon - 1);
		value.trim();
		PropAndVal propAndVal(property, value);
		int isPresent = isPresentInList(propAndVal, propAndValList);

		if (isPresent != -1) {
			propAndValList.change(propAndVal, isPresent);
		}
		else
		{
			propAndValList.add(propAndVal);
		}

		std::cin.getline(buffer, 1024);
		line = buffer;
		curlyBrace = line.contains('}');
		colon = line.contains(':');
		semicolon = line.contains(';');
	}
	line.trim();

	if (line.getSize() > 2) {
		NewString property = line.divide(0, colon - 1);
		property.trim();
		NewString value = line.divide(colon + 1, curlyBrace -1);
		value.trim();
		PropAndVal propAndVal(property, value);
		propAndValList.add(propAndVal);
	}


	//do {
	//	bool flag = true;
	//	PropAndVal propAndVal = parsePropertyAndValue(&startPoint, line);
	//	for (int i = 0; i < propAndValList.getSize(); i++) {
	//		NewString listPropName = propAndValList.get(i).getProperty();
	//		NewString newPropName = propAndVal.getProperty();
	//		if (listPropName.equals(newPropName)) {
	//			propAndValList.change(propAndVal, i);
	//			flag = false;
	//			break;
	//		}
	//	}

	//	if(flag) propAndValList.add(propAndVal);
	//	startPoint = 0;
	//	std::cin.getline(buffer, 1024);
	//	line = buffer;
	//	line.trim();
	//} while (line.contains('}') == -1);
	////line has more letters than only }, one more property left
	//if (line.getSize() > 1) {
	//	propAndValList.add(parsePropertyAndValue(&startPoint, line));
	//}
	return propAndValList;
}

List<NewString> Parser::parseSelectors(NewString line) {
	char curlyBrace = '{';
	char coma = ',';
	List<NewString> selectors;
	
	int comaPlace = line.contains(coma);
	int curlyBracePlace = line.contains(curlyBrace);
	if (curlyBracePlace != -1) {
		line = line.divide(0, curlyBracePlace - 1);
	}

	while (comaPlace != -1) {
		NewString selector = line.divide(0, comaPlace - 1);
		selector.trim();
		selectors.add(selector);
		line = line.divide(comaPlace + 1, line.getSize());
		comaPlace = line.contains(coma);
	}
	line.trim();
	selectors.add(line);
	
	return selectors;
}



int Parser::parseCommands(NewString* answer) {
	CommandsParser parser(list, sectionSize,answer);
	NewString textLine;
	char a[] = "****";
	NewString endOfCommandSection(a);
	char buffer[1024] = { 0 };

	while (!textLine.equals(endOfCommandSection)) {
		if (std::cin.eof()) return -1;
		std::cin.getline(buffer, 1024);
		if (strlen(buffer) == 0) std::cin.getline(buffer, 1024);
		textLine = buffer;
		textLine.trim();
		parser.handleCommand(textLine);
	}
	return 1;
}

void Parser::insertSectionIntoList(Section section) {
	int listSize = list->getSize();
	if (listSize == 0) {
		Section* sections = new Section[sectionSize];
		sections[0] = section;
		list->add(sections);
		return;
	}

	int index = listSize - 1;
	Section* sections = list->get(index);
	int i = 0;
	while (sections[i].getIsUsed() && i < sectionSize) {
		i++;
	}
	if (i == sectionSize) {
		Section* newSections = new Section[sectionSize];
		newSections[0] = section;
		list->add(newSections);
	}
	else {
		sections[i] = section;
	}
}

int Parser::isPresentInList(PropAndVal propAndVal, List<PropAndVal> list) {
	for (int i = 0; i < list.getSize(); i++) {
		PropAndVal listPropAndVal = list.get(i);
		if (listPropAndVal.getProperty().equals(propAndVal.getProperty())) {
			return i;
		}
	}
	return -1;
}