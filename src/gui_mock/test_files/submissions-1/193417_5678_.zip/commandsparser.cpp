#include "commandsparser.h"
CommandsParser::CommandsParser(List<Section*>* list, int blockSize, NewString* answer)
	:list{ list }, blockSize{ blockSize }, answer{ answer }, utils{ list, blockSize } {
}

void CommandsParser::handleCommand(NewString command) {
	//command '?'
	if (command.getSize() == 1) {
		int count = utils.getAllSectionsCount();
		char buffer[1024];
		sprintf_s(buffer, "? == %d \n", count);
		NewString string = buffer;
		*answer = *answer + buffer;
	}
	int comaPlace = command.contains(',');
	int secondComaPlace = comaPlace + 2;
	char commandLetter = command.get(comaPlace + 1);
	char thirdArgument = command.get(secondComaPlace + 1);
	NewString attribute, selector;
	
	switch (commandLetter) {
	case 'A':
		if (thirdArgument == '?') {
			if (isdigit(command.get(0))) {
				int sectionNumber = getNumberArgument(command, 0, comaPlace - 1);
				commandA(sectionNumber);
			}
			else {
				attribute = getNewStringArgument(command, 0, comaPlace - 1);
				commandA(attribute);
			}
		}
		else {
			int sectionNumber = getNumberArgument(command, 0, comaPlace - 1);
			attribute = getNewStringArgument(command, secondComaPlace + 1, command.getSize() - 1);
			commandA(sectionNumber, attribute);
		}
		break;
	case 'S':
		if (thirdArgument == '?') {
			if (isdigit(command.get(0))) {
				int sectionNumber = getNumberArgument(command, 0, comaPlace - 1);
				commandS(sectionNumber);
			}
			else {
				selector = getNewStringArgument(command, 0, comaPlace - 1);
				commandS(selector);
			}
		}
		else {
			int sectionNumber = getNumberArgument(command, 0, comaPlace - 1);
			int selectorNumber = getNumberArgument(command, secondComaPlace + 1, command.getSize() - 1);
			commandS(sectionNumber, selectorNumber);
		}
		break;
	case 'E':
		selector = getNewStringArgument(command, 0, comaPlace - 1);
		attribute = getNewStringArgument(command, secondComaPlace + 1, command.getSize() - 1);
		commandE(attribute, selector);
		break;
	case 'D': {
		if (thirdArgument == '*') {
			int sectionNumber = getNumberArgument(command, 0, comaPlace-1);
			commandD(sectionNumber);
		}
		else {
			int sectionNumber = getNumberArgument(command, 0, comaPlace - 1);
			attribute = getNewStringArgument(command, secondComaPlace + 1, command.getSize() - 1);
			commandD(sectionNumber, attribute);
		}
		break;
	}
	}

}

void CommandsParser::commandA(int sectionNumber) {
	int number = utils.getAttributesForSection(sectionNumber);
	if (number != -1) {
		char buffer[1024];
		sprintf_s(buffer, "%d,A,? == %d\n", sectionNumber, number);
		NewString result = buffer;
		*answer = *answer + result;
	}
}
void CommandsParser::commandA(int sectionNumber, NewString attribute) {
	NewString value = utils.getAttribueValue(sectionNumber, attribute);
	if (value.getSize() >= 1) {
		char buffer[1024];
		char bufferTwo[1024];
		char newLine[] = "\n";
		sprintf_s(buffer, "%d,A,", sectionNumber);
		sprintf_s(bufferTwo, " == ");
		NewString result = buffer + attribute;
		result = result + bufferTwo + value;
		result = result + newLine;
		*answer = *answer + result;
	}
}

void CommandsParser::commandA(NewString attribute) {
	int count = utils.getAllAttributeCount(attribute);
	char buffer[1024];
	sprintf_s(buffer, ",A,? == %d\n", count);
	NewString result = attribute + buffer;
	*answer = *answer + result;
}

void CommandsParser::commandS(int sectionNumber) {
	int count = utils.getSelectorsForSection(sectionNumber);
	if (count >= 0) {
		char buffer[1024];
		sprintf_s(buffer, "%d,S,? == %d\n", sectionNumber, count);
		*answer = *answer + buffer;
	}
}

void CommandsParser::commandS(int sectionNumber, int selectorNumber) {
	NewString result = utils.getSelector(selectorNumber, sectionNumber);
	if (result.getSize() > 1) {
		char buffer[1024];
		sprintf_s(buffer, "%d,S,%d == ", sectionNumber, selectorNumber);
		char endOfWord[] = "\n";
		result = result + endOfWord;
		NewString response = buffer + result;
		*answer = *answer + response;
	}
}

void CommandsParser::commandS(NewString selectorName) {
	int count = utils.getAllSelectorCount(selectorName);
	char buffer[1024];
	sprintf_s(buffer, ",S,? == %d\n", count);
	NewString result = selectorName + buffer;
	*answer = *answer + result;
}

void CommandsParser::commandE(NewString attributeName, NewString selectorName) {
	NewString value = utils.getAttributeValueBySelector(attributeName, selectorName);
	char buffer[1024];
	if (value.getSize() > 1) {
		sprintf_s(buffer, ",E,");
		char equals[] = " == ";
		char newLine[] = "\n";
		NewString result = selectorName + buffer + attributeName + equals + value + newLine;
		*answer = *answer + result;
	}
}

void CommandsParser::commandD(int sectionNumber) {
	deleteSectionByNumber(sectionNumber);
	char buffer[1024];
	sprintf_s(buffer, "%d,D,* == deleted\n", sectionNumber);
	NewString result = buffer;
	*answer = *answer + result;
}

void CommandsParser::commandD(int sectionNumber, NewString attribute) {
	Section section = utils.getSection(sectionNumber);
	int attributesLeft = section.deleteAttribute(attribute);
	if (attributesLeft == 0) {
		deleteSectionByNumber(sectionNumber);
	}
	else {
		utils.changeSection(sectionNumber, section);
	}
	char buffer[1024];
	char bufferTwo[1024];
	sprintf_s(buffer, "%d,D,", sectionNumber);
	sprintf_s(bufferTwo, " == deleted\n");
	NewString result = buffer;
	result = result + attribute + bufferTwo;
	*answer = *answer + result;
}

int CommandsParser::getNumberArgument(NewString command, int start, int end) {
	char* number = new char[end-start+1];
	int i = 0;
	while (start <= end) {
		number[i] = command.get(start);
		i++;
		start++;
	}
	return atoi(number);
}

NewString CommandsParser::getNewStringArgument(NewString command, int start, int end) {
	NewString result = command.divide(start, end);
	result.trim();
	return result;
}

void CommandsParser::deleteSectionByNumber(int sectionNumber) {
	int count = 0;
	for (int i = 0; i < list->getSize(); i++) {
		Section* sections = list->get(i);
		for (int j = 0; j < blockSize; j++) {
			if (sections[j].getIsUsed()) count++;
			if (count == sectionNumber) {
				Section empty;
				sections[j] = empty;
				return;
			}
		}
	}
}