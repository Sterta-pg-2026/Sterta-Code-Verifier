#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Attribute {
    string name;
    string value;
    Attribute* prev;
    Attribute* next;
};

struct Selector {
    string name;
    Selector* prev;
    Selector* next;
    Attribute* attributes_head;
    Attribute* attributes_tail;
};

Selector* add_selector(Selector* tail, string name) {
    Selector* node = new Selector;
    node->name = name;
    node->prev = tail;
    node->next = nullptr;
    node->attributes_head = nullptr;
    node->attributes_tail = nullptr;
    if (tail != nullptr) {
        tail->next = node;
    }
    return node;
}

Attribute* add_attribute(Attribute* tail, string name, string value) {
    Attribute* node = new Attribute;
    node->name = name;
    node->value = value;
    node->prev = tail;
    node->next = nullptr;
    if (tail != nullptr) {
        tail->next = node;
    }
    return node;
}

int main() {
    Selector* selectors_head = nullptr;
    Selector* selectors_tail = nullptr;
    string line;
    string cssCode = "";

    cout << "Enter CSS code (type ???? to stop):" << endl;

    while (line != "????") {
        getline(cin, line);
        cssCode += line + "\n";
    }

    string selector = "";
    string attribute_name = "";
    string attribute_value = "";
    int num_selectors=0;
    bool inside_selector_name = true;
    bool inside_selector = false;
    bool inside_attribute_name = false;
    bool inside_attribute_value = false;

    for (char c : cssCode) {
        if (c == '{') {

            inside_selector_name = false;
            inside_selector = true;
            selectors_tail = add_selector(selectors_tail, selector);
            if (selectors_head == nullptr) {
                selectors_head = selectors_tail;
            }
            selector = "";
        }
        else if (c == '}') {
            inside_selector = false;
            inside_selector_name = true;
            num_selectors++;
            if (attribute_name != "") {
                selectors_tail->attributes_tail = add_attribute(
                    selectors_tail->attributes_tail,
                    attribute_name,
                    attribute_value
                );
                if (selectors_tail->attributes_head == nullptr) {
                    selectors_tail->attributes_head = selectors_tail->attributes_tail;
                }
                attribute_name = "";
                attribute_value = "";
            }
        }
        else if (c == ':') {
            inside_attribute_value = true;
            inside_attribute_name = false;
        }
        else if (c == ';') {

            inside_attribute_value = false;
            selectors_tail->attributes_tail = add_attribute(
                selectors_tail->attributes_tail,
                attribute_name,
                attribute_value
            );
            if (selectors_tail->attributes_head == nullptr) {
                selectors_tail->attributes_head = selectors_tail->attributes_tail;
            }
            attribute_name = "";
            attribute_value = "";
        }
        else if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
            continue;
        }
        else {
            if (inside_selector_name) {
                selector += c;
            }
            else if (inside_attribute_name) {
                attribute_name += c;
            }
            else if (inside_attribute_value) {
                attribute_value += c;
            }
            else {
                inside_attribute_name = true;
                attribute_name += c;
            }
        }
    }
    for (Selector* selector_node = selectors_head; selector_node != nullptr; selector_node = selector_node->next) {
        cout << "Selector: " << selector_node->name << endl;
        for (Attribute* attribute_node = selector_node->attributes_head; attribute_node != nullptr; attribute_node = attribute_node->next) {
            cout << "  " << attribute_node->name << ": " << attribute_node->value << endl;
        }
        cout << endl;
    }

    string command="";
    while (true) {
        cout << "Enter a command: ";
        getline(cin, command);
        if (command == "?") {
            cout << "Number of selectors: " << num_selectors << endl;
        }
        else if (command[1] == ',' && command[2] == 'S' && command[3] == ',' && command[4] == '?') {
            int section_number = 0;
            try {
                section_number = stoi(command.substr(0));
            }
            catch (...) {
                cout << "Invalid section number." << endl;
                continue;
            }
        }
        else if (command == "exit") {
            break;
        }

        else {
            cout << "Invalid command. Type ? for help." << endl;
        }
    }

    return 0;

}