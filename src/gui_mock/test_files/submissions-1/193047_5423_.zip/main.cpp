#include <stdio.h>
#include "cssengine.h"

int main()
{
	Engine engine;

	char input;

	do
	{
		input = getchar();
		engine.manageInput(input);

	} while (input != EOF);
	

	return 0;
}
