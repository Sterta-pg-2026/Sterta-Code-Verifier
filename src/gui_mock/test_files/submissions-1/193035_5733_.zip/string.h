#include <iostream>
#include <cstring>

class String {
public:
    // Constructors
    String() : m_size(), m_buffer() {}
    String(const char* str) : m_size(std::strlen(str)), m_buffer(new char[m_size + 1]) {
        std::strcpy(m_buffer, str);
    }
    String(const String& other) : m_size(other.m_size), m_buffer(new char[m_size + 1]) {
        std::strcpy(m_buffer, other.m_buffer);
    }

    // Destructor
    ~String() {
        delete[] m_buffer;
    }

    // Assignment operator
    String& operator=(const String& other) {
        if (this != &other) {
            delete[] m_buffer;
            m_size = other.m_size;
            m_buffer = new char[m_size + 1];
            std::strcpy(m_buffer, other.m_buffer);
        }
        return *this;
    }

    // Member functions
    const char* c_str() const {
        return m_buffer;
    }

    std::size_t size() const {
        return m_size;
    }

    bool empty() const {
        return m_size == 0;
    }

    void clear() {
        delete[] m_buffer;
        m_size = 0;
        m_buffer = nullptr;
    }
    char end_of_word() {
        return m_buffer[m_size - 1];
    }

    // Function for deleting the last character of the string
    void deleteLastChar() {
        if (m_size > 0) {
            m_buffer[m_size - 1] = '\0';
            m_size--;
        }
    }

    // Function for splitting the string into three parts separated by a given delimiter
    void splitByDelimiter(char delimiter, String& part1, String& part2, String& part3) const {
        int pos1 = -1, pos2 = -1;
        for (int i = 0; i < m_size; i++) {
            if (m_buffer[i] == delimiter) {
                if (pos1 == -1) {
                    pos1 = i;
                }
                else {
                    pos2 = i;
                    break;
                }
            }
        }
    }

    char getFirstChar() const {
        return m_buffer[0];
    }

    // function to delete the first character of the string
    void deleteFirstChar() {
        if (m_size > 0) {
            char* newData = new char[m_size];
            std::strcpy(newData, m_buffer + 1);
            delete[] m_buffer;
            m_buffer = newData;
            m_size--;
        }
    }

    bool isInteger() const {
        if (m_size == 0) {
            return false;
        }
        size_t index = 0;
        if (m_buffer[0] == '+' || m_buffer[0] == '-') {
            index++;
        }
        for (; index < m_size; index++) {
            if (m_buffer[index] < '0' || m_buffer[index] > '9') {
                return false;
            }
        }
        return true;
    }

    int toInt() const {
        if (!isInteger()) {
            return 0;
        }
        return atoi(m_buffer);
    }

    // Concatenation operator
    String operator+(const String& other) const {
        String result;
        result.m_size = m_size + other.m_size;
        result.m_buffer = new char[result.m_size + 1];
        std::strcpy(result.m_buffer, m_buffer);
        std::strcat(result.m_buffer, other.m_buffer);
        return result;
    }

    bool operator!=(const String& other) const {
        return std::strcmp(m_buffer, other.m_buffer) != 0;
    }

    bool operator==(const String& other) const {
        return std::strcmp(m_buffer, other.m_buffer) == 0;
    }

    // Output stream operator
    friend std::ostream& operator<<(std::ostream& os, const String& str) {
        os << str.m_buffer;
        return os;
    }
    // Input stream operator
    friend std::istream& operator>>(std::istream& is, String& str) {
        char buffer[4096];
        is >> buffer;
        str = String(buffer);
        return is;
    }



private:
    std::size_t m_size;
    char* m_buffer;
};