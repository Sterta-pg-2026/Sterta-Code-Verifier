
#include <iostream>

#include "list.h"
#include "string.h"
#define SELECTOR 2
#define ATTRIBUTE 0
#define VALUE 1
#define COMMEND 3
#define CANCEL 4
#define YES 1
#define NO 0
#define T 8

using namespace std;

void Attributes(String input, List<String>& listOfAttributes, List<String>& listOfValues, int& mode) {
    String value, inputValue = "";
    input.deleteLastChar();
    listOfAttributes.insertBack(input);
    input.clear();
    cin >> value;
    char c = value.end_of_word();
    while (c != ';' && c != '}') {
        inputValue = inputValue + value;
        cin >> value;
        c = value.end_of_word();
    }
    if (c == '}') {
        value.deleteLastChar();
        c = value.end_of_word();
        if (c == ';') {
            value.deleteLastChar();
        }
        listOfValues.insertBack(value);
        mode = CANCEL;
    }
    else {
        value.deleteLastChar();
        listOfValues.insertBack(value);
        mode = ATTRIBUTE;
    }
}

void Selectors(String input, List<String>& listOfSelectors, int& mode) {
    if (input.end_of_word() == ',') {
        mode = SELECTOR;
        input.deleteLastChar();
        listOfSelectors.insertBack(input);
    }
    else {
        listOfSelectors.insertBack(input);
    }
}

struct Block {
    List<String> listOfAttributes[2];
    List<String> listOfSelectors;
    int create(int &number_of_blocks) {
        String bracketopen = "{", bracketclosed = "}", end = "****", start = "????", input;
        int mode = SELECTOR;
        cin >> input;
        while (input != bracketclosed) {
            if (input != start) {
                if (mode == SELECTOR) {
                    if (input == bracketopen || input.getFirstChar() == '{') {
                        if (input == bracketopen) mode = ATTRIBUTE;
                        else {
                            input.deleteFirstChar();
                            Attributes(input, listOfAttributes[0], listOfAttributes[1], mode);
                            number_of_blocks++;
                            return SELECTOR;
                        }
                    }
                    else Selectors(input, listOfSelectors, mode);
                }
                else if (mode == ATTRIBUTE) {
                    Attributes(input, listOfAttributes[0], listOfAttributes[1], mode);
                }
            }
            else {
               return COMMEND;
            }
            cin >> input;
        }
        if (input.end_of_word() == '}' && input != "}") {
            input.deleteLastChar();
            Attributes(input, listOfAttributes[0], listOfAttributes[1], mode);
        }
        number_of_blocks++;
        return SELECTOR;
    }

};

void NumberOfSelectors(String input){

}
void NumberOfAttributes(String input){

}
void WhichSelector(String input){

}
void ValueOfAttribute(String input){

}
void HowManyAttributes(String input){

}
void HowManySelectors(String input){

}
void AttributeOfSelector(String input){

}
void DeleteSection(String input){

}
void DeleteAttribute(String input){


}
void NumberOfSections(int number_of_blocks){
    cout << "? == "<<number_of_blocks;
}



void Commends(List<Block*> lista, int &mode, int number_of_blocks) {
String input, parameter1, parameter2, parameter3;
cin>>input;
while(input!="****"){
if (input!="?"){
    input.splitByDelimiter(',', parameter1, parameter2, parameter3);
    if(parameter1.isInteger()){
            if(parameter2=="S" && parameter3=="?") NumberOfSelectors(input);
            else if(parameter2=="A" && parameter3=="?") NumberOfAttributes(input);
            else if (parameter2=="S" && parameter3.isInteger()) WhichSelector(input);
            else if (parameter2=="A" && !parameter3.isInteger()) ValueOfAttribute(input);
             else if (parameter2=="D" && parameter3=="*") DeleteSection(input);
             else if (parameter2=="D" && !parameter3.isInteger()) DeleteAttribute(input);
    }
    else{
         if(parameter2=="A" && parameter3=="?") HowManyAttributes(input);
         else if(parameter2=="S" && parameter3=="?") HowManySelectors(input);
         else if (parameter2=="E") AttributeOfSelector(input);
    }
    }
else NumberOfSections(number_of_blocks);
cin>>input;
}
mode = SELECTOR;
}




void AddNewNode(List<Block*> &lista ) {
    Block* newArray = new Block[T];
    lista.insertBack(newArray);
}

int main() {
    int index = 0, number_of_blocks=0;
    List<Block*> lista;
    AddNewNode(lista);
    int mode = SELECTOR;
    while (true) {
        lista.getNodeData(index);
        for (int i = 0; i < T + 1; i++) {
            if (i == T) {
                AddNewNode(lista);
                i = 0;
            }
            else {
                if (mode == SELECTOR)  mode = lista.getNodeData(index)->create(number_of_blocks);
                else if (mode == COMMEND) Commends(lista, mode, number_of_blocks);
            }
        }
        index++;
    }
}


