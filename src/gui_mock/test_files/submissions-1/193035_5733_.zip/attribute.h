#include <iostream>
#pragma once

using namespace std;

class Attribute{

};
