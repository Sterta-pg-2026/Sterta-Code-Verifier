#pragma once
#include <iostream>

using namespace std;

template <typename T>
class List {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;
    };
    Node* head;
    Node* tail;
    int size;

public:
    List() {
        head = nullptr;
        tail = nullptr;
        size = 0;
    }


    ~List() {
        Node* current = head;
        Node* temp;

        while (current != nullptr) {
            temp = current->next;
            delete current;
            current = temp;
        }
    }
    T getNodeData(int index) const {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        Node* node = head;
        for (int i = 0; i < index; i++) {
            node = node->next;
        }
        return node->data;
    }

    T& operator[](int index) {
        // check if index is valid
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }

        // traverse list to find node at index
        Node* curr = head;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }

        // return reference to data in node at index
        return curr->data;
    }

    void insertFront(T data) {
        Node* newNode = new Node;
        newNode->data = data;
        newNode->prev = nullptr;
        newNode->next = head;

        if (head != nullptr) {
            head->prev = newNode;
        }
        else {
            tail = newNode;
        }

        head = newNode;
        size++;
    }

    void insertBack(T data) {
        Node* newNode = new Node;
        newNode->data = data;
        newNode->prev = tail;
        newNode->next = nullptr;

        if (tail != nullptr) {
            tail->next = newNode;
        }
        else {
            head = newNode;
        }

        tail = newNode;
        size++;
    }

    void remove(T data) {
        if (head == nullptr) {
            return;
        }

        Node* current = head;

        while (current != nullptr) {
            if (current->data == data) {
                if (current == head) {
                    head = current->next;

                    if (head != nullptr) {
                        head->prev = nullptr;
                    }
                    else {
                        tail = nullptr;
                    }
                }
                else if (current == tail) {
                    tail = current->prev;
                    tail->next = nullptr;
                }
                else {
                    current->prev->next = current->next;
                    current->next->prev = current->prev;
                }

                delete current;
                size--;
                return;
            }

            current = current->next;
        }
    }

    T& back() {
        return tail->data;
    }

    // Returns true if the list is empty, false otherwise.
    bool isEmpty() const {
        return size == 0;
    }

    int getSize() const {
        return size;
    }

    void print() const {
        Node* current = head;

        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }

        cout << endl;
    }
};
