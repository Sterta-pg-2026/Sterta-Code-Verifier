#pragma once
#include <iostream>

using namespace std;

class Selector{
      int number_in_block;

};
