﻿#define _CRT_SECURE_NO_WARNINGS
#include "consts.h"
#include "attribute.h"
#include "selector.h"
#include "blok.h"
#include "command.h"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	Attribute_List atList;
	Selector_List scList;
	
	int blockCounter = 0;
	int isExit = 0;
	Section testSection;
	Section_List wholeCss;

	string tmp;
	Command cmd;

	while (true)
	{
		while (true)
		{
			Block testBlock;
			if (testBlock.readBlock()) break;
			wholeCss.appendBlock(testBlock);
			blockCounter++;
		}

		do
		{
			cmd.readCmd(isExit, tmp);
			if (tmp == endCommand) break;
			if (!cmd.setCmd(tmp))
			{
				cmd.clearCmd();
				continue;
			}
			wholeCss.doCommand(cmd);
			cmd.clearCmd();
			if (isExit == -1) exit(EXIT_SUCCESS);
		} while (tmp != endCommand);
	}

	return 0;
}