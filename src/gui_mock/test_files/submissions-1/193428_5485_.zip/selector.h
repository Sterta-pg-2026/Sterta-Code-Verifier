#pragma once
#include "string.h"
class Selector
{
public:
	string name;
	Selector* next;
	Selector* prev;

	Selector();
	Selector(char*& name);
	Selector(const Selector& other);

	string GetName() const;
	void SetName(const string& name);
	~Selector();
};


class Selector_List : public Selector
{
protected:
	Selector* head;
public:
	Selector_List();
	Selector_List(const Selector_List& other);

	void pushBack(const Selector& other);
	void writeList() const;

	int readSelectors();

	Selector* getHead() const;

	void clearSc();
	void cleanList();
	~Selector_List();
};

