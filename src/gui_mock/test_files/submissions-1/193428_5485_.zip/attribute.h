#pragma once
#include "string.h"

class Attribute
{
public:
	string name;
	string value;
	Attribute* next;
	Attribute* prev;

	Attribute();
	Attribute(const string& name, const string& value);
	Attribute(const Attribute& other);

	void setName(const string& name);
	void setValue(const string& val);

	bool operator==(const Attribute& right);
	~Attribute();
};

class Attribute_List : public Attribute
{
protected:
	Attribute* head;
public:
	Attribute_List();

	void pushBack(const Attribute& other);

	void writeList() const;

	void readAttributes();
	bool checkRepetition(Attribute& att);

	Attribute* getHead() const;

	int deleteAttrByName(const string& name);

	void clearAttr();
	void cleanList();
	~Attribute_List();
};