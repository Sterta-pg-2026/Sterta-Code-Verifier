#include "blok.h"
#include "consts.h"
#include <stdio.h>
#include <stdlib.h>

Block::Block()
{

}

Block::Block(Attribute_List atList, Selector_List scList)
{
	this->atList = atList;
	this->scList = scList;
}

//returns 1 if started command reading
int Block::readBlock()
{
	if (this->scList.readSelectors()) return 1;
	this->atList.readAttributes();
	return 0;
}

void Block::write() const
{
	this->scList.writeList();
	this->atList.writeList();
	printf("\n");
}

Attribute_List& Block::getAttrList()
{
	return this->atList;
}
Selector_List& Block::getScList()
{
	return this->scList;
}

//===================================================

Section::Section()
{
	this->blocks = new Block[BLOCKS_BUFOR];
	this->takenBlocks = 0;
	this->usedBlocks = 0;
	this->next = nullptr;
	this->prev = nullptr;
}

Section::Section(const Block& other)
{
	this->blocks = new Block[BLOCKS_BUFOR];
	this->takenBlocks = 0;
	this->usedBlocks = 0;
	this->next = nullptr;
	this->prev = nullptr;

	this->appendBlock(other);
}

Section::Section(const Section& other)
{
	this->blocks = other.blocks;
	this->takenBlocks = other.takenBlocks;
	this->usedBlocks = other.usedBlocks;
	this->next = nullptr;
	this->prev = nullptr;
}

void Section::appendBlock(const Block& other)
{
	blocks[takenBlocks] = other;
	takenBlocks++;
	usedBlocks++;
}

//writes section list to stream
void Section::writeList() const
{
	for (int i = 0; i < takenBlocks; i++)
	{
		this->blocks[i].write();
	}
}

Section* Section::getNext() const
{
	return this->next;
}
Section* Section::getPrev() const
{
	return this->prev;
}
Section& Section::getRefNext()
{
	return *this->next;
}
Section& Section::getRefPrev()
{
	return *this->prev;
}



int Section::getTakenBlocks() const
{
	return takenBlocks;
}
int Section::getUsedBlocks() const
{
	return this->usedBlocks;
}
void Section::takeAwayUsedBlock()
{
	this->usedBlocks--;
}

Block& Section::getBlock(int i) const
{
	int cnt = 0;
	int cntSum = 0;
	//Selector* tmpScHd = this->blocks[i].getScList().getHead();
	Attribute* tmpAtHd = this->blocks[cnt].getAttrList().getHead();
	while (cnt <= i-1)
	{
		if (tmpAtHd != nullptr)
		{
			cnt++;
			if (cnt == i) break;
		}
		cntSum++;
		tmpAtHd = this->blocks[cntSum].getAttrList().getHead();
	}
	return this->blocks[cntSum];
}

void Section::setNext(Section* next)
{
	this->next = next;
}

void Section::setPrev(Section* prev)
{
	this->prev = prev;
}

void Section::deleteNode()
{
	if (this->next == nullptr)
	{
		this->prev->next = nullptr;
		delete this;
	}
	else
	{
		this->prev->next= this->next;
		this->next->prev = this->prev;
		delete this;
	}
}

//===================================================

Section_List::Section_List()
{
	this->head = nullptr;
}

void Section_List::pushBack(const Section& other)
{
	Section* newSection = new Section(other);

	if (head == nullptr)
	{
		head = newSection;
		return;
	}

	Section* tmp = head;

	while (tmp->getNext() != nullptr)
	{
		tmp = tmp->getNext(); 
	}

	newSection->setPrev(tmp);
	tmp->setNext(newSection);
}

void Section_List::appendBlock(const Block& block)
{
	if (head == nullptr)
	{
		head = new Section(block);
		return;
	}
	
	Section* tmp = head;
	while (tmp->getTakenBlocks() >= BLOCKS_BUFOR)
	{
		if (tmp->getNext() != nullptr)
		{
			tmp = tmp->getNext();
		}
		else
		{
			Section* newSection = new Section(block);
			//tmp->setNext(*newSection);
			pushBack(*newSection);
			return;
		}
	}
	
	tmp->appendBlock(block);
}

int Section_List::convToInt(const string& txt) const
{
	int nmb = 0;
	int tmp = txt.getSize()-2;
	int exp = 1;
	while (tmp >= 0)
	{
		nmb += (txt.getVal()[tmp] - '0') * exp;
		exp *= 10;
		tmp -= 1;
	}
	return nmb;
}

Section* Section_List::findSection(const int& i, int& retIndex) const
{
	Section* tmp = head;
	int whichBlock = 0;
	int usedBlocks;
	if (tmp == nullptr) return nullptr;

	retIndex = i;
	usedBlocks = tmp->getUsedBlocks();

	while (whichBlock + tmp->getUsedBlocks() < i)
	{
		whichBlock += tmp->getUsedBlocks();
		retIndex -= tmp->getUsedBlocks();
		tmp = tmp->getNext();
		if (tmp == nullptr) return nullptr;
	}
	//retIndex -= 1;
	return tmp;
}

int Section_List::countCSSBlocks() const
{
	if (head == nullptr) return 0;

	int cnt = 0;
	Section* tmp = head;
	while (tmp != nullptr)
	{
		cnt += tmp->getUsedBlocks();
		tmp = tmp->getNext();
	}
	return cnt;
}

int Section_List::countAttributesForI(int i) const
{
	int internalCnt;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return -1;

	Attribute* tmpAtt = tmpList->getBlock(internalCnt).getAttrList().getHead();
	if (tmpAtt == nullptr) return -1;

	internalCnt = 0;
	while (tmpAtt != nullptr)
	{
		if (tmpAtt->name != emptyString)
		{
			internalCnt++;
		}
		tmpAtt = tmpAtt->next;
	}
	return internalCnt;
}

//returns -1 if block i not found
int Section_List::countSelectorsForI(int i) const
{
	int internalCnt;
	//int whichBlock = (i - 1) / BLOCKS_BUFOR + 1;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return -1;

	Selector* tmpSc = tmpList->getBlock(internalCnt).getScList().getHead();
	if (tmpSc == nullptr) return -1;

	internalCnt = 0;
	while (tmpSc != nullptr)
	{
		if (tmpSc->name != emptyString)
		{
			internalCnt++;
		}
		tmpSc = tmpSc->next;
	}
	return internalCnt;
}

string Section_List::getSelector(const int& i,const int& j) const
{
	int tmp;
	int internalCnt;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return errString;

	Selector* tmpSc = tmpList->getBlock(internalCnt).getScList().getHead();
	if (tmpSc == nullptr) return errString;

	tmp = 1;
	while (tmp < j && tmpSc != nullptr)
	{
		tmpSc = tmpSc->next;
		tmp++;
	}
	if (tmpSc == nullptr) return errString;
	else if (tmpSc->name == emptyString) return errString;
	else
	{
		return tmpSc->GetName();
	}
}

string Section_List::getAttrValue(const int& i, const string& name) const
{
	int tmp = 1;
	int internalCnt;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return errString;

	Attribute* tmpAtt = tmpList->getBlock(internalCnt).getAttrList().getHead();
	if (tmpAtt == nullptr) return errString;

	tmp = 0;
	while (tmpAtt != nullptr && tmpAtt->name != name)
	{
		tmpAtt = tmpAtt->next;
		tmp++;
	}
	if (tmpAtt == nullptr) return errString;
	else
	{
		return tmpAtt->value;
	}
}

int Section_List::countAttributesByName(const string& name) const
{
	int tmp = 0, i = 0;
	Section* tmpList = head;
	Block a;
	if (tmpList == nullptr) return 0;

	Attribute* tmpAtt = nullptr;
	while (tmpList != nullptr)
	{
		//tmpList[i] might not exist - MUST BE CHECKED SOMEHOW ARGHH
		while (i < tmpList->getUsedBlocks())
		{
			tmpAtt = tmpList->getBlock(i+1).getAttrList().getHead();
			while (tmpAtt != nullptr)
			{
				if (tmpAtt->name == name) tmp++;
				tmpAtt = tmpAtt->next;
			}
			i++;
		}
		tmpList = tmpList->getNext();
		i = 0;
	}
	return tmp;
}

int Section_List::countSelectorsByName(const string& name) const
{
	int tmp = 0, i = 0;
	Section* tmpList = head;
	if (tmpList == nullptr) return 0;

	Selector* tmpSc = nullptr;
	while (tmpList != nullptr)
	{
		//tmpList[i] might not exist - MUST BE CHECKED SOMEHOW ARGHH
		while (i < tmpList->getUsedBlocks())
		{
			tmpSc = tmpList->getBlock(i+1).getScList().getHead();
			while (tmpSc != nullptr)
			{
				if (tmpSc->GetName() == name)
				{
					tmp++;
					break;
				}
				tmpSc = tmpSc->next;
			}
			i++;
		}
		tmpList = tmpList->getNext();
		i = 0;
	}
	return tmp;
}

string Section_List::getAttrValBySelector(const string& attrName, const string& scName) const
{
	string tmp = errString;
	int i = 0;
	bool scFound = false;
	Section* tmpList = head;
	if (tmpList == nullptr) return 0;

	Selector* tmpSc = nullptr;
	Attribute* tmpAtt = nullptr;

	while (tmpList != nullptr)
	{
		//tmpList[i] might not exist - MUST BE CHECKED SOMEHOW ARGHH
		while (i < tmpList->getUsedBlocks())
		{
			tmpSc = tmpList->getBlock(i+1).getScList().getHead();
			while (tmpSc != nullptr)
			{
				if (tmpSc->name == scName)
				{
					tmpAtt = tmpList->getBlock(i+1).getAttrList().getHead();
					while (tmpAtt != nullptr)
					{
						if (tmpAtt->name == attrName)
						{
							tmp = tmpAtt->value;
							break;
						}
						tmpAtt = tmpAtt->next;
					}

				}
				tmpSc = tmpSc->next;
			}
			i++;
		}
		tmpList = tmpList->getNext();
		i = 0;
	}
	return tmp;
}

int Section_List::deleteBlock(const int& i)
{
	int internalCnt;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return -1;

	Block* toDelete = &tmpList->getBlock(internalCnt);
	if (toDelete == nullptr) return -1;

	Attribute_List* attrToDel = &toDelete->getAttrList();
	Selector_List* scToDel = &toDelete->getScList();
	if (attrToDel != nullptr)
	{
		attrToDel->cleanList();
		scToDel->cleanList();
		tmpList->takeAwayUsedBlock();

		if (tmpList->getUsedBlocks() == 0 && head != nullptr)
		{
			if (tmpList->getPrev() == nullptr)
			{
				if (tmpList->getNext() == nullptr)
				{
					head = nullptr;
				}
				else
				{
					Section* tmp = head;
					tmp = head->getNext();
					delete head;
					head = tmp;
					head->setPrev(nullptr);
				}
			}
			else
			{
				tmpList->deleteNode();
			}
		}

		return 1;
	}
	else
	{
		return -1;
	}
}

int Section_List::deleteAttr(const int& i, const string& name)
{
	int internalCnt, tmp;
	Section* tmpList = findSection(i, internalCnt);
	if (tmpList == nullptr) return -1;

	Block* toDelete = &tmpList->getBlock(internalCnt % BLOCKS_BUFOR);
	if (toDelete == nullptr) return -1;

	Attribute_List* attrToDel = &toDelete->getAttrList();
	tmp = attrToDel->deleteAttrByName(name);
	if (tmp == -1)
	{
		return -1;
	}
	else if (tmp == 0)
	{
		Selector_List* scToDel = &toDelete->getScList();
		if (attrToDel != nullptr)
		{
			attrToDel->clearAttr();
			scToDel->clearSc();
			tmpList->takeAwayUsedBlock();
			return 1;
		}
	}
	else return 1;
	return -1;
}

void Section_List::doCommand(const Command& cmd)
{
	int tmp;
	int index, index2;
	string retValue, helper, helper2;
	if (cmd.getFirst().getVal()[0] == '?')
	{
		printf("? == %d\n", countCSSBlocks());
	}
	else if (isNumber(cmd.getFirst()))
	{
		switch (cmd.getSecond())
		{
		case 'S':
			if (cmd.getThird() == "?")
			{
				//index to which block we seek
				index = convToInt(cmd.getFirst());
				tmp = countSelectorsForI(index);
				if (tmp == -1) return;
				printf("%s,S,%s == %d\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), tmp);
			}
			else
			{
				index = convToInt(cmd.getFirst());
				index2 = convToInt(cmd.getThird());
				retValue = getSelector(index, index2);
				if (retValue == errString) return;
				printf("%s,S,%s == %s\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), retValue.getVal());
			}
			break;
		case 'A':
			if (cmd.getThird() == "?")
			{
				//index to which block we seek
				index = convToInt(cmd.getFirst());
				tmp = countAttributesForI(index);
				if (tmp == -1) return;
				printf("%s,A,%s == %d\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), tmp);
			}
			else
			{
				index = convToInt(cmd.getFirst());
				helper = cmd.getThird();
				retValue = getAttrValue(index, helper);
				if (retValue == errString) return;
				printf("%s,A,%s == %s\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), retValue.getVal());
			}
			break;
		case 'D':
			index = convToInt(cmd.getFirst());
			helper = cmd.getThird();
			if (helper == "*")
			{
				tmp = deleteBlock(index);
				if (tmp == -1) return;
			}
			else
			{
				tmp = deleteAttr(index, helper);
				if (tmp == -1) return;
			}
			printf("%s,D,%s == deleted\n", cmd.getFirst().getVal(), cmd.getThird().getVal());
			break;
		default:
			return;
			break;
		}	
	}
	else
	{
		switch (cmd.getSecond())
		{
		case 'A':
			helper = cmd.getFirst();
			tmp = countAttributesByName(helper);
			printf("%s,A,%s == %d\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), tmp);
			break;
		case 'S':
			helper = cmd.getFirst();
			tmp = countSelectorsByName(helper);
			printf("%s,S,%s == %d\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), tmp);
			break;
		case 'E':
			helper = cmd.getFirst();
			helper2 = cmd.getThird();
			retValue = getAttrValBySelector(helper2, helper);
			if (retValue == errString) return;
			printf("%s,E,%s == %s\n", cmd.getFirst().getVal(), cmd.getThird().getVal(), retValue.getVal());
			break;
		default:
			break;
		}
	}
}

Section_List::~Section_List()
{

}