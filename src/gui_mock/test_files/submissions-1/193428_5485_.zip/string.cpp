#include "string.h"
#include "consts.h"
#include <ctype.h>

string::string()
{
	this->value = new char[STRING_LENGTH];
	this->size = 0;
	this->buffers = 1;

	this->value[0] = '\0';
	this->size++;
}

string::string(const char* other)
{
	this->value = new char[STRING_LENGTH];
	this->size = 0;
	this->buffers = 1;

	while (other[size] != '\0')
	{
		if (size >= STRING_LENGTH * this->buffers)
		{
			this->addBuffer();
		}
		this->value[size] = other[size];
		this->size++;
	}

	if (this->size >= STRING_LENGTH * this->buffers)
	{
		this->addBuffer();
	}
	this->value[size] = '\0';
	this->size++;

}

string::string(const string& other)
{
	this->size = other.size;
	this->buffers = other.buffers;
	this->value = new char[STRING_LENGTH*buffers];
	
	for (int i = 0; i < other.size; i++)
	{
		this->value[i] = other.value[i];
	}
}

string& string::operator=(const string& right)
{
	//delete previous values
	delete[] value;
	this->size = right.size;
	this->buffers = right.buffers;

	//allocate new value memory
	this->value = new char[STRING_LENGTH * buffers];

	for (int i = 0; i < size; i++)
	{
		this->value[i] = right.value[i];
	}

	return *this;
}

string& string::operator+=(const char& right)
{
	if (this->size >= STRING_LENGTH * buffers)
	{
		this->addBuffer();
	}
	value[size-1] = right;
	value[size] = '\0';
	size++;

	return *this;
}

string& string::operator+=(const string& right)
{
	string tmp(*this);

	delete[] this->value;
	this->value = new char [(tmp.size + right.size) / STRING_LENGTH + 1];
	this->size = 0;
	this->buffers = (tmp.size + right.size) / STRING_LENGTH + 1;

	for (int i = 0; i < tmp.size-1; i++)
	{
		this->value[size] = tmp[size];
		size++;
	}
	for (int i = 0; i < right.size; i++)
	{
		this->value[size] = right.value[i];
		size++;
	}
	return *this;
}

bool string::operator==(const string& right) const
{
	if (this->size != right.size) return false;
	for (int i = 0; i < this->size; i++)
	{
		if (this->value[i] != right.value[i]) return false;
	}
	return true;
}
bool string::operator!=(const string& right) const
{
	if (this->size != right.size) return true;
	for (int i = 0; i < this->size; i++)
	{
		if (this->value[i] != right.value[i]) return true;
	}
	return false;
}

char& string::operator[](size_t index) const
{
	return this->value[index];
}

void string::deleteLastEmpty()
{
	int tmp = size - 2;
	while (isspace(this->value[tmp]))
	{
		this->value[tmp] = '\0';
		this->size -= 1;
		tmp--;
	}
}

void string::addBuffer()
{
	this->buffers += 1;
	char* tmp = value;
	this->value = new char[buffers * STRING_LENGTH];

	int i = 0;
	while (tmp[i] != '\0' && i < buffers*STRING_LENGTH-1)
	{
		this->value[i] = tmp[i];
		i++;
	}
	this->value[i] = '\0';

	delete[] tmp;
}

int string::getSize() const
{
	return this->size;
}

char* string::getVal() const
{
	return this->value;
}

bool string::isNumber(const string& txt) const
{
	for (int i = 0; i < txt.size-1; i++)
	{
		if (txt.value[i] < '0' || txt.value[i] > '9') return false;
	}
	return true;
}

string::~string()
{
	delete[] this->value;
	this->size = 0;
	this->buffers = 0;
}