#pragma once
#include "command.h"

#define STRING_LENGTH 8
#define BLOCKS_BUFOR 17


const static Command countBlocks("?",'\0',"");
const static string errString("-1");
const static string emptyString("");
const static string endCommand("****");