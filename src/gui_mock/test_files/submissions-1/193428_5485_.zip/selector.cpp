#define _CRT_SECURE_NO_WARNINGS
#include "selector.h"
#include "consts.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

Selector::Selector() : name(), next(nullptr), prev(nullptr)
{
	//this->name = new char[STRING_LENGTH];
	//this->next = nullptr;
	//this->prev = nullptr;
	//printf("Selector()\n");
}

Selector::Selector(char*& name) : name(name)
{
	this->next = nullptr;
	this->prev = nullptr;
	//printf("Selector(char*& name)\n");
}

Selector::Selector(const Selector& other) : name{other.name}, next{nullptr}, prev{nullptr}
{
}

string Selector::GetName() const
{
	return this->name;
}

void Selector::SetName(const string& name)
{
	this->name = name;
}

Selector::~Selector()
{
	this->next = nullptr;
	this->prev = nullptr;
}

//===================================================
Selector_List::Selector_List()
{
	head = nullptr;
}

Selector_List::Selector_List(const Selector_List& other)
{
	this->head = other.head;
}

void Selector_List::pushBack(const Selector& other)
{
	Selector* newSelector = new Selector(other);

	if (this->head == nullptr)
	{
		head = newSelector;
		return;
	}

	Selector* tmp = head;

	while (tmp->next != nullptr)
	{
		tmp = tmp->next;
	}

	newSelector->prev = tmp;
	tmp->next = newSelector;
}

void Selector_List::writeList() const
{
	int i = 0;
	Selector* tmp = head;

	while (tmp != nullptr)
	{
		i = 0;
		while (tmp->name[i] != '\0')
		{
			printf("%c", tmp->name[i]);
			i++;
		}
		printf("\n");

		tmp = tmp->next;
	}
	delete tmp;
}


//returns 1 if detected command reading
int Selector_List::readSelectors()
{
	string tmp;
	char ch;
	int i = 0;
	int scanfRetVal;

	while (scanfRetVal = scanf("%c", &ch))
	{
		if (scanfRetVal == EOF) exit(EXIT_SUCCESS);
		if (ch == '{')
		{
			if (tmp.getSize() > 1 && isspace(tmp[tmp.getSize() - 2]))
			{
				tmp.deleteLastEmpty();
			}
			break;
		}
		if (i == 0 && isspace(ch)) continue;
		i++;

		if (ch == ',')
		{
			Selector* att1 = new Selector;
			if (isspace(tmp[tmp.getSize() - 2]))
			{
				tmp.deleteLastEmpty();
			}
			att1->SetName(tmp);
			this->pushBack(*att1);
			tmp = emptyString;
			delete att1;
			i = 0;
		}
		else
		{
			tmp += ch;
			if (tmp == "????") return 1;
		}
	}
	Selector* att1 = new Selector;
	att1->SetName(tmp);
	this->pushBack(*att1);

	delete att1;
	return 0;
}

Selector* Selector_List::getHead() const
{
	return this->head;
}

void Selector_List::clearSc()
{
	delete this->head;
	head = nullptr;
}

void Selector_List::cleanList()
{
	Selector* tmp = head;

	if (head == nullptr) return;
	else if (head->next == nullptr)
	{
		delete head;
		head = nullptr;
		return;
	}
	tmp = tmp->next;

	while (tmp != nullptr)
	{
		delete tmp->prev;
		tmp = tmp->next;
	}
	head = nullptr;
}

Selector_List::~Selector_List()
{
	//this->cleanList();
}