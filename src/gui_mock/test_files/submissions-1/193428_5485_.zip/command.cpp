#define _CRT_SECURE_NO_WARNINGS
#include "command.h"
#include "consts.h"
#include "string.h"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

Command::Command() : first(), second('\0'), third()
{}

Command::Command(const char*& cmd) : first(), second('\0'), third()
{
	setCmd(cmd);
}

Command::Command(const string& first, const char second, const string& third) : first(), second('\0'), third()
{
	this->first = first;
	this->second = second;
	this->third = third;
}

string Command::getFirst() const
{
	return first;
}
char Command::getSecond() const
{
	return second;
}
string Command::getThird() const
{
	return third;
}

void Command::readCmd(int& isExit, string& fullCmd)
{
	char ch;
	fullCmd = emptyString;
	//string* kurka = new string;
	//string kurka;
	int i = 0;

	while (true)
	{
		if (scanf("%c", &ch) == EOF)
		{
			if (ch == '?')
			{
				fullCmd += ch;
				fullCmd += '\n';
				//*kurka += ch;
				//*kurka += '\n';
				isExit = EOF;
			}
			else
			{
				exit(EXIT_SUCCESS);
			}
			return;//*kurka;
		}
		if (i == 0 && isspace(ch)) continue;
		if (ch == '\n') break;

		fullCmd += ch;
		//*kurka += ch;
		i++;
	}
	//return *kurka;
}

void Command::clearCmd()
{
	this->first = emptyString;
	this->second = '\0';
	this->third = emptyString;
}
//returns 1 if command is correctly written
int Command::setCmd(const string& cmd)
{
	int i = 0;

	if (cmd[i] == '?')
	{
		first = "?";
		return 1;
	}
	while (cmd[i] != ',')
	{
		first += cmd[i];
		i++;
	}
	first[i] = '\0';

	i++;
	if (cmd[i] == 'A' || cmd[i] == 'S' || cmd[i] == 'E' || cmd[i] == 'D')
	{
		second = cmd[i];
		i+=2;
	}
	else return 0;
	while (cmd[i] != '\0')
	{
		third += cmd[i];
		i++;
	}

	return 1;
}

char* Command::writeCmd() const
{
	string output1(this->getFirst().getVal());
	output1 += ',';
	output1 += this->getSecond();
	output1 += ',';
	string output3(this->getThird().getVal());

	output1 += output3;
	char* output = output1.getVal();
	return output;
}

bool Command::operator==(const Command& right) const
{
	if (this->first != right.first) return false;
	if (this->second != right.second) return false;
	if (this->third != right.third) return false;
	return true;
}

Command::~Command()
{

}