#define _CRT_SECURE_NO_WARNINGS
#include "consts.h"
#include "attribute.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

Attribute::Attribute() : name(), value()
{
	this->next = nullptr;
	this->prev = nullptr;
	//printf("Attribute()\n");
}

Attribute::Attribute(const string& name, const string& value) : name{name}, value{value}
{
	this->next = nullptr;
	this->prev = nullptr;
	//printf("Attribute(char* name)\n");
}

Attribute::Attribute(const Attribute& other)
{
	this->name = other.name;
	this->value = other.value;
	this->next = nullptr;
	this->prev = nullptr;
}

void Attribute::setName(const string& name)
{
	this->name = name;
}

void Attribute::setValue(const string& val)
{
	this->value = val;
}

bool Attribute::operator==(const Attribute& right)
{
	if (this->name == right.name) return true;
	return false;
}

//===================================================
Attribute_List::Attribute_List()
{
	this->head = nullptr;
	//printf("Attribute_List()\n");
}

void Attribute_List::pushBack(const Attribute& other)
{
	Attribute* newAttr = new Attribute(other);
	if (head == nullptr)
	{
		this->head = newAttr;
		return;
	}

	Attribute* tmp = head;

	while (tmp->next != nullptr)
	{
		tmp = tmp->next;
	}
	newAttr->prev = tmp;
	tmp->next = newAttr;
}

void Attribute_List::writeList() const
{
	int i = 0;
	Attribute* tmp = head;
	while (tmp != nullptr)
	{
		i = 0;
		//writing attribute's name until '\0' is met
		while (tmp->name[i]!='\0')
		{
			printf("%c", tmp->name[i]);
			i++;
		}
		printf(" == ");

		i = 0;
		while (tmp->value[i] != '\0')
		{
			printf("%c", tmp->value[i]);
			i++;
		}
		printf("\n");

		tmp = tmp->next;
	}
	delete tmp;
}

//checks if attribute's name has repeated, if yes it switches its value
//function returns 0 if no repetition and 1 if repetition spotted
bool Attribute_List::checkRepetition(Attribute& att)
{
	if (head == nullptr)
	{
		return 0;
	}
	Attribute* tmp = head;
	while (tmp != nullptr)
	{
		//operator checks if names of two attributes are the same
		if (*tmp == att)
		{
			att.next = tmp->next;
			att.prev = tmp->prev;
			*tmp = att;
			return 1;
		}
		tmp = tmp->next;
	}
	return 0;
}

void Attribute_List::readAttributes()
{
	string tmp;
	char ch;
	int i = 0;
	int scanfRetVal;

	//reading attributes to list until '}' sign is reached
	while (scanfRetVal = scanf("%c", &ch))
	{
		if (scanfRetVal == EOF) exit(EXIT_SUCCESS);
		if (ch == '}') break;
		if (isspace(ch)) continue;

		if (ch != ':')
		{
			tmp += ch;
		}
		
		//reaching end of name reading, then going to read value
		if (ch == ':')
		{
			//creating new attribute and setting its name
			Attribute* att1 = new Attribute;
			att1->setName(tmp);

			tmp = emptyString;

			while (scanfRetVal = scanf("%c", &ch))
			{
				if (scanfRetVal == EOF) exit(EXIT_SUCCESS);
				//reaching the end of attribute's value
				//setting its value and placing attribute it in list
				if (ch == ';' || ch == '}')
				{
					att1->setValue(tmp);

					//here we check if attribute's name has repeated
					//if yes then we dont have to push back 
					//because function put the latest value into the list
					if (!checkRepetition(*att1))
					{
						this->pushBack(*att1);
					}
					
					tmp = emptyString;
					delete att1;
					i = 0;

					//if we reach '}' then we can close reading
					break;
				}

				//if first expression after ':' is a space then skipping it
				if (i == 0 && ch == ' ') continue;
				tmp += ch;
				i++;
			}
		}
		if (ch == '}') break;
	}
	//delete ch;
}

Attribute* Attribute_List::getHead() const
{
	return this->head;
}

//-1 didnt delete
//0 empty list
//1 correctly deleted
int Attribute_List::deleteAttrByName(const string& name)
{
	Attribute* tmp = head;

	while (tmp != nullptr)
	{
		if (tmp->name == name)
		{
			if (tmp->next == nullptr)
			{
				if (tmp->prev == nullptr) //1 last element in list
				{
					delete head;
					head = nullptr;
					return 0;
				}
				else //last element in list
				{
					tmp->prev->next = nullptr;
					tmp->prev = nullptr;
					delete tmp;
					return 1;
				}
			}
			else if (tmp->prev == nullptr) //first element in list
			{
				tmp->next->prev = nullptr;
				head = head->next;
				tmp->next = nullptr;
				delete tmp;
				return 1;
			}
			else //middle element in list
			{
				tmp->next->prev = tmp->prev;
				tmp->prev->next = tmp->next;

				tmp->next = nullptr;
				tmp->prev = nullptr;
				delete tmp;
				return 1;
			}
		}
		else
		{
			tmp = tmp->next;
		}
	}
	return -1;
}

void Attribute_List::clearAttr()
{
	delete this->head;
	head = nullptr;
}

void Attribute_List::cleanList()
{
	Attribute* tmp = head;

	if (head == nullptr) return;
	else if (head->next == nullptr)
	{
		delete head;
		head = nullptr;
		return;
	}
	tmp = tmp->next;

	while (tmp != nullptr)
	{
		delete tmp->prev;
		tmp = tmp->next;
	}
	head = nullptr;
}

Attribute::~Attribute()
{
	this->next = nullptr;
	this->prev = nullptr;
}

Attribute_List::~Attribute_List()
{
	//this->cleanList();
}