#pragma once

class string
{
	char* value;
	int size;
	int buffers;

public:
	string();
	string(const char* other);
	string(const string& other);
	
	string& operator=(const string& right);
	string& operator+=(const char& right);
	string& operator+=(const string& right);
	bool operator==(const string& right) const;
	bool operator!=(const string& right) const;
	char& operator[](size_t index) const;
	

	void deleteLastEmpty();
	void addBuffer();

	int getSize() const;
	char* getVal() const;

	bool isNumber(const string& txt) const;

	~string();
};

