#pragma once
#include "attribute.h"
#include "selector.h"
#include "command.h"
#include "string.h"
class Command
{
	string first;
	char second;
	string third;

public:
	Command();
	Command(const char*& cmd);
	Command(const string& first, const char second, const string& third);

	string getFirst() const;
	char getSecond() const;
	string getThird() const;

	void readCmd(int& isExit, string& fullCmd);

	void clearCmd();
	int setCmd(const string& cmd);
	char* writeCmd() const;

	bool operator==(const Command& right) const;

	~Command();
};

