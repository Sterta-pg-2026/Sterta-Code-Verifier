#pragma once
#include "attribute.h"
#include "selector.h"
#include "command.h"
#include "string.h"

class Block
{
	Attribute_List atList;
	Selector_List scList;

public:
	Block();
	Block(Attribute_List atList, Selector_List scList);

	int readBlock();
	void write() const;

	Attribute_List& getAttrList();
	Selector_List& getScList();
};

class Section : public Block
{
	Block* blocks;
	int takenBlocks;
	int usedBlocks;
	Section* next;
	Section* prev;

public:
	Section();
	Section(const Block& other);
	Section(const Section& other);

	void appendBlock(const Block& block);
	void writeList() const;

	Section* getNext() const;
	Section* getPrev() const;
	Section& getRefNext();
	Section& getRefPrev();


	int getTakenBlocks() const;
	int getUsedBlocks() const;
	void takeAwayUsedBlock();
	Block& getBlock(int i) const;
	
	void setNext(Section* next);
	void setPrev(Section* prev);

	void deleteNode();
};

//string inherited to use isNumber function
class Section_List : protected string
{
	Section* head;

public:
	Section_List();

	void pushBack(const Section& other);

	void appendBlock(const Block& block);


	int convToInt(const string& txt) const;

	Section* findSection(const int& i, int& retIndex) const;
	//Selector* findSelector(const int& i) const;

	int countCSSBlocks() const;
	int countAttributesForI(int i) const;
	int countSelectorsForI(int i) const;
	string getSelector(const int& i, const int& j) const;
	string getAttrValue(const int& i, const string& name) const;
	int countAttributesByName(const string& name) const;
	int countSelectorsByName(const string& name) const;
	string getAttrValBySelector(const string& attrName, const string& scName) const;

	
	int deleteBlock(const int& i);
	int deleteAttr(const int& i, const string& name);
	

	void doCommand(const Command& cmd);

	~Section_List();
};