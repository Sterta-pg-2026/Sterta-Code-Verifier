#pragma once

#include <iostream>
#include <cstring>
#include "commons.h"
#include "commands.h"
#include "structmanip.h"
#include "litestring.h"
#include "parsemethods.h"