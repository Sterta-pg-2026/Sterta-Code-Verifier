#include <iostream>
#define T 8
using namespace std;


class String {
private:
    char* character;
    size_t string_size;

public:
    String() : character(nullptr), string_size(0) {}

    String(const char* str) {
        string_size = strlen(str) + 1;
        character = new char[string_size];
        strcpy_s(character, string_size, str);
    }

    String(const String& other) {
        string_size = other.string_size;
        character = new char[string_size];
        memcpy(character, other.character, string_size);
    }

    ~String() {
        delete[] character;
    }

    String& operator=(const String& other) {
        if (this != &other) {
            delete[] character;
            string_size = other.string_size;
            character = new char[string_size];
            strcpy_s(character, string_size, other.character);
        }
        return *this;
    }

    String& operator+=(const String& other) {
        size_t new_string_size = string_size + other.string_size - 1;
        char* new_character = new char[new_string_size];
        strcpy_s(new_character, new_string_size, character);
        strcat_s(new_character, new_string_size, other.character);
        delete[] character;
        character = new_character;
        string_size = new_string_size;
        return *this;
    }

    String operator+(const String& other) const {
        String result(*this);
        result += other;
        return result;
    }

    bool operator==(const String& other) const {
        return strcmp(character, other.character) == 0;
    }

    bool operator!=(const String& other) const {
        return !(*this == other);
    }

    char& operator[](size_t index) {
        if (index >= string_size) {
            throw std::out_of_range("Index out of range");
        }
        return character[index];
    }

    const char& operator[](size_t index) const {
        if (index >= string_size) {
            throw std::out_of_range("Index out of range");
        }
        return character[index];
    }

    const char* c_str() const {
        return character;
    }

    size_t size() const {
        return string_size - 1;
    }

    void push(char str) {
        char* new_str = new char[string_size+2];
        for (size_t i = 0; i < string_size; i++) {
            new_str[i] = character[i];
        }
        new_str[string_size] = str;
        new_str[string_size+1] = '\0';
        delete[] character;
        character = new_str;
        string_size++;
    }

    void push_string(String s) {
        for (int i = 0; i <= s.size(); i++) {//wpisuje input na koniec n
            push(s[i]);
        }
    }

    char& back() {
        if (string_size <= 1) {
            throw std::out_of_range("String is empty");
        }
        return character[string_size-1]; 
    }

    const char& back() const {
        if (string_size <= 1) {
            throw std::out_of_range("String is empty");
        }
        return character[string_size-1];
    }

    void clear() {
        delete[] character;
        character = nullptr;
        string_size = 0;
    }

    void sin() {
        clear();
        char ch;
        while (cin.get(ch) && ch != '\n') {
            push(ch);
        }
    }

    void sout() {
        for (int i = 0; i < string_size; i++) {
            cout << character[i];
        }
    }

    bool are_equal(String str) {
        for (size_t i = 0; i < str.size(); i++) {
            if (character[i] != str[i]) {
                return false;
            }
        }
        return true;
    }

    friend std::ostream& operator<<(std::ostream& os, const String& str) {
        os << str.character;
        return os;
    }
};

class NodeS {
public:
    String data;
    NodeS* next;
    NodeS(String value) {
        data.push_string(value);
        next = nullptr;
    }
};

class SingleList {
private:
    NodeS* head;
    int size;

public:
    SingleList() {
        head = nullptr;
        size = 0;
    }

    bool isEmpty() {
        return size == 0;
    }

    void push_back(String value) {
        NodeS* newNode = new NodeS(value);
        if (isEmpty()) {
            head = newNode;
        }
        else {
            NodeS* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        size++;
    }

    void pop_back() {
        if (!isEmpty()) {
            NodeS* temp = head;
            NodeS* prev = nullptr;
            while (temp->next != nullptr) {
                prev = temp;
                temp = temp->next;
            }
            if (prev != nullptr) {
                prev->next = nullptr;
            }
            else {
                head = nullptr;
            }
            delete temp;
            size--;
        }
    }

    void push_front(String value) {
        NodeS* newNode = new NodeS(value);
        if (isEmpty()) {
            head = newNode;
        }
        else {
            newNode->next = head;
            head = newNode;
        }
        size++;
    }

    void pop_front() {
        if (!isEmpty()) {
            NodeS* temp = head;
            head = head->next;
            delete temp;
            size--;
        }
    }

    void print() {
        NodeS* temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    String get_data(int i) {
        NodeS* temp = head;
        if (!isEmpty()) {
            for (int j = 0; j < i; j++) {
                temp = temp->next;
            }
            return temp->data;
        }
        else {
            return "";
        }
    }

    int count() {
        if (isEmpty()) {
            return 0;
        }
        else {
            NodeS* temp = head;
            return size;
        }
    }

    int find_selector(String selektor) {
        int count = 0;
        selektor.sout();
        NodeS* temp = head;
        while (!isEmpty()) {
            if (temp->data.are_equal(selektor)) {
                count++;
            }
            temp=temp->next;
        }
        return count;
    }
};

struct section {
    SingleList attributes;
    SingleList selectors;
    section() : attributes(), selectors() {}
};

class NodeD {
public:
    int nr;
    section data[T];
    NodeD* next;
    NodeD* prev;

    NodeD(section arr[]) {
        for (int i = 0; i < T; i++) {
            data[i].attributes = arr[i].attributes;
            data[i].selectors = arr[i].selectors;
        }
        next = nullptr;
        prev = nullptr;
        nr = 0;
        for (int i = 0; i < T; i++) {
            if (arr[i].attributes.count() > 0 || arr[i].selectors.count() > 0) {
                nr++;
            }
        }
    }

    /*void nr_plus() {
        nr++;
    }

    void nr_zero() {
        nr = 0;
    }*/
};

class DoubleList {
private:
    NodeD* headD;
    NodeD* tailD;
    int sizeD;

public:
    DoubleList() {
        headD = nullptr;
        tailD = nullptr;
        sizeD = 0;
    }

    bool isEmpty() {
        return sizeD == 0;
    }
    /*bool isEmpty() {
        if (headD == nullptr) {
            return true;
        }
        else {
            return false;
        }
    }*/

    void push_back(section arr[]) {
        NodeD* newNode = new NodeD(arr);
        if (isEmpty()) {
            headD = newNode;
            tailD = newNode;
        }
        else {
            tailD->next = newNode;
            newNode->prev = tailD;
            tailD = newNode;
        }
        sizeD++;
    }

    void pop_back() {
        if (!isEmpty()) {
            NodeD* temp = tailD;
            tailD = tailD->prev;
            if (tailD != nullptr) {
                tailD->next = nullptr;
            }
            else {
                headD = nullptr;
            }
            delete temp;
            sizeD--;
        }
    }

    int get_size() {
        return sizeD;
    }

    void push_front(section arr[]) {
        NodeD* newNode = new NodeD(arr);
        if (isEmpty()) {
            headD = newNode;
            tailD = newNode;
        }
        else {
            headD->prev = newNode;
            newNode->next = headD;
            headD = newNode;
        }
        sizeD++;
    }

    void pop_front() {
        if (!isEmpty()) {
            NodeD* temp = headD;
            headD = headD->next;
            if (headD != nullptr) {
                headD->prev = nullptr;
            }
            else {
                tailD = nullptr;
            }
            delete temp;
            sizeD--;
        }
    }

    void print() {
        NodeD* temp = headD;
        while (temp != nullptr) {
            for (int i = 0; i < T; i++) {
                temp->data[i].attributes.print();
                temp->data[i].selectors.print();
            }
            cout << endl;
            temp = temp->next;
        }
    }

    int get_nr() {
        NodeD* temp = tailD;
        if (!isEmpty()) {
            return temp->nr;
        }
        else {
            return 0;
        }
    }

    section get_tab(int i, int j) {
        NodeD* temp = headD;
        for (int k = 0; k < j; k++) {
            temp = temp->next;
        }
        return temp->data[i];

    }

    String get_data(int i, int j, char sa) {
        NodeD* temp = headD;
        if (!isEmpty()) {
            for (int k = 0; k < i; k++) {
                temp = temp->next;
            }
            int count_arr = 0;
            int arr = 0;
            while (count_arr <= j) {
                if (sa == 'a') {
                    count_arr += temp->data[arr].attributes.count();
                }
                else if (sa == 's') {
                    count_arr += temp->data[arr].selectors.count();
                }
                arr++;
            }
            int element_nr = temp->data[arr-1].selectors.count() + j - count_arr;
            return temp->data[arr-1].selectors.get_data(element_nr);
        }
        else {
            return "";

        }
    }

    int section_amount() {
        NodeD* temp = headD;
        int count=0;
        while (temp != NULL) {
            count+=temp->nr;
            temp = temp->next;
        }
        return count;
    }

    int single_amount(int i, char c) {
        NodeD* temp = headD;
        for (int j = 0; j < i; j++) {
            temp = temp->next;
        }
        if (temp == NULL) {
            return -1;
        }
        int counter=0;
        for (int j = 0; j < temp->nr; j++) {
            if (c == 's') {
                counter += temp->data[i].selectors.count();
            }
            else if (c == 'a') {
                counter += temp->data[i].attributes.count();
            }
        }
        return counter;
    }

    int count_selector(String selector) {
        NodeD* temp = headD;
        int count = 0;
        while (!isEmpty()) {
            for (int i = 0; i < sizeD; i++) {
                temp->data[i].selectors.find_selector(selector);
                count++;
            }
            temp=temp->next;
        }
        return count;
    }
};

void saveSA(String input, SingleList &Lists, SingleList& Lista) { //wpisywanie w node list jednokierunkowych selektorów i atrybutów
    int i = 0;
    String word;
    while (input[i] != '{') {//selektory
        while (input[i] != ',' && input[i] != '{') {
            word.push(input[i]);
            i++;
        }
        Lists.push_back(word);
        word.clear();
        if (input[i] == ',') { 
            i++; 
        }
    }
    i++;
    while (input[i] != '}') {//atrybuty
        while (input[i] != ';' && input[i] != '}') {
            word.push(input[i]);
            i++;
        }
        Lista.push_back(word);
        word.clear();
        if (input[i] == ';') {
            i++;
        }
    }

};

bool is_int(char c) {
    return (c >= '0' && c <= '9');
}

int sint(String str) {
    int num = 0;
    for (int i = 0; i <= str.size(); i++) {
        num = num * 10 + (str[i] - '0');
    }
    return num;
}

int main() {
    DoubleList listD;                   //lista główna
    SingleList listS;                   //lista selektorów
    SingleList listA;                   //lista atrybutów
    SingleList listE;                   //pusta lista zerująca
    String input;                       //wejście
    section *tab = new section[T];      //tablica T struktur

    /*aaa, bbb, ccc{a: A; b: B}
    ddd, eee, fff{1: I; 2: II}
    ggg, hhh, iii{3: 4; 5: 6}
    jjj, kkk, lll{f: g; h: j}
    mmm, nnn, ooo{f: g; h: j}
    ppp, qqq, rrr{f: g; h: j}
    sss, ttt, uuu{f: g; h: j}
    vvv, www, xxx{f: g; h: j}*/

    do {
        input.sin();
        if (input == "????") {
            do{
                input.sin();
                if (input == "?") {
                    cout << "? == " << listD.section_amount()<<endl;
                }
                else {
                    char c=NULL;
                    int i = 0;
                    String first; //String input do przecinka
                    String second;
                    while (c != ',') {
                        c = input[i];
                        if (c != ',') {
                            first.push(c);
                        }
                        i++;
                    }
                    int k = i;
                    i += 2;
                    while (c != input.back()) {
                        c = input[i];
                        second.push(c);
                        i++;
                    }
                    i = k;
                    if (input[i] == 'A') {
                        i += 2;
                        if (input[i] == '?') {
                            if (is_int(first[0])) {
                                if (listD.single_amount(sint(first) - 1, 'a') >= 0) {
                                    cout << sint(first) << ",A,? == " << listD.single_amount(sint(first) - 1, 'a');
                                }
                            }
                        }
                        else {

                        }
                    }
                    else if (input[i] == 'S') {
                        i+=2;

                        if (input[i] == '?') {

                            if (is_int(first[0])) {
                                if (listD.single_amount(sint(first) - 1, 's') >= 0) {
                                    cout << sint(first) << ",S,? == " << listD.single_amount(sint(first) - 1, 's');
                                }
                            }
                        }
                        else {
                            cout << sint(first) << ",S," << sint(second) << " == ";
                            listD.get_data(sint(first) - 1, sint(second) - 1, 's').sout();
                        }
                    }
                    else if (input[i] == 'D') {
                        cout << 'd';
                    }
                    else if (input[i] == 'E') {
                        cout << 'e';
                    }
                }
            } while (input != "****");
        }
        else {
            String n;
            do{
                n.push_string(input);

                if (n.back() != '}') {
                    input.sin();
                }
            } while (n.back() != '}');

            saveSA(n, listS, listA);

            tab[listD.get_nr()].attributes = listA;
            tab[listD.get_nr()].selectors = listS;
            listA = listE;
            listS = listE;
            if (listD.get_nr() == T) {
                listD.push_back(tab);
                for (int i = 0; i < T; i++) {
                    tab[i].attributes = listE;
                    tab[i].selectors = listE;
                }
            }
            else {
                listD.pop_back();
                listD.push_back(tab);
            }
        }

    } while (input != "0");
    delete[] tab;

    return 0;
}