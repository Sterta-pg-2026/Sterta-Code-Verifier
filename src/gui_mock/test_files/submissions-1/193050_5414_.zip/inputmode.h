#pragma once

typedef struct {
    bool parseMode;
    int cssReadMode;
    int currentNode;
    int currentBlock;
} InputMode;