#include "programm.h"

int main() {
    Node* node = createNode();
    readCSS(&node);
    return 0;
}