#pragma once
#include "mstring.h"

struct NodeAttribute
{
	MString name;
	MString value;
};

class Attribute {
private:
	NodeAttribute* head;
	NodeAttribute* tail;
public:

};
