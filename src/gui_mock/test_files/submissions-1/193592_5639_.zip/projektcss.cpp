﻿#include <iostream>
#include "mstring.h"
#include "doublelinkedlist.h"
#include "attributelist.h"
#include "selectorlist.h"
#include "sectionlist.h"
#define ENTER '\n'
#define ROZMIAR 3
using namespace std;

bool isNumber(char number) {
    if (number >= '0' && number <= '9') {
        return true;
    }
    return false;
}

bool isNumber(MString* str, int index) {
    for (int i = 0; i < str->getSize(); i++) {
        if (str->getData()[i] < '0' || str->getData()[i]>'9') {
            return false;
        }
        return true;
    }
}

int toNumber(MString* str, int index) {
    int result = 0;
    for (int i = 0; i < str[index].getSize(); i++) {
        result = result + (str[index][i] - '0') * pow(10, str[index].getSize() - i - 1);
    }
    return result;
}

bool isNotQuestionMark(char c) {
    if (c == '?') return false;
    return true;
}

void printRequest(MString* arr) {
    for (int i = 0; i < ROZMIAR; i++) {
        cout << arr[i];
        if (i != ROZMIAR - 1) {
            cout << ',';
        }
    }
    //cout << " == "; dopiero przy znalezieniu
}

void attributeRequest(MString* arr, SectionList& list) {
    if (arr[2]=='?') {
        if (arr[0].length() == 1) {
            if (isNumber(arr, 0)) {
                list.printAttributes(toNumber(arr, 0)); //i,A,?
            }
            else {
                list.printAttributes(arr[0]); //n,A,?
            }
        }
    }
    else {
        list.printAttributes(toNumber(arr,0), arr[2]); //i,A,n
    }
}

void selectorRequest(MString* arr, SectionList list) {
    if (arr[2] == '?') {
        if (arr[0].length() == 1) {
            if (isNumber(arr, 0)) {
                list.printSelectors(toNumber(arr,0)); //i,S,?
            }
            else {
                list.printSelectors(arr[0]); //z,S,?
            }
        }
    }
    else {
        list.printSelectors(toNumber(arr, 0), toNumber(arr, 2)); //i,S,j
    }
}

void sectionRequest(MString* arr, SectionList list) {
    if (arr[2] == '*') {
        if (list.removeSection(toNumber(arr, 0))) { //i, D, *
                std::cout << "deleted" << std::endl;
        } 
    }
    else {
        if (list.removeAttribute(toNumber(arr, 0), arr[2])) { //i,D,n
            std::cout << "deleted" << std::endl;
        }
    }
}

void checkRequest(MString* arr, SectionList list) {
    if (arr[0] == 'A') {
        attributeRequest(arr, list);
    }
    else if (arr[0] == 'S') {
        selectorRequest(arr, list);
    }
    else if (arr[0] == 'D') {
        sectionRequest(arr, list);
    }
    else if (arr[0] == 'E') {
        list.printAttribute(toNumber(arr, 0)); //z,E,n
    }
    else return;
}

int main()
{
    char character, c;
    bool komendy = false, css = true, isSelectorOver = false, isProperty = false, isAtr = false, request = false;
    bool getSelectors = true, getAttributes = false;
    int pocz_komend = 0, pocz_css = 0, counter = 0, number = 0, index = 0;
    int word = 0;
    MString name, property, value, komenda[ROZMIAR];
    AttributeList atrybut;
    SelectorList selektor;
    SectionList list;

    do {
        c = getchar();
        if (c > ' ' || c != ENTER) {
            if (!name.isClear() && c == ENTER && getSelectors) {
                //name.despace(); // dodane pozniej
                getSelectors = false;
                selektor.add(name);
                name.clear();
            }
            
            if (!name.isClear() && getSelectors && c == ','){
                //name.despace();
                selektor.add(name);
                name.clear();
            }

            if (c == '{' && !name.isClear()){
                //name.despace();
                selektor.add(name);
                name.clear();
                getSelectors = false;
                getAttributes = true;
            }

            if (c == '{'){
                getSelectors = false;
                getAttributes = true;
            }

            if (c == '}'){
                //section.push_back(attrlist, selelist);
                //list.push_back(section);
                getSelectors = true;
                getAttributes = false;
                //list.clear();
                //selektor.clear();
                //atrybut.clear();
            }

            if (c == ':' && getAttributes){
                word++;
            }

            if (c == ENTER && !name.isClear() && getSelectors){
                //name.despace();
                selektor.add(name);
                name.clear();
            }

            if (!name.isClear() && !value.isClear() && (c == ENTER || c == ';') && getAttributes){
                //name.despace();
                //value.decolon();
                //value.despace();
                atrybut.add(name, value);
                //attrlist.insert(name, value);
                name.clear();
                value.clear();
                word = 0;
            }
            if (c != ENTER && word == 0)
            {
                name = name + c;
            }
            if (c != ENTER && c == 1)
            {
                value = value + c;
            }
            if (name == "????")
            {
                name.clear();
                MString tab[3];
                int i = 0, num = 0;
                
                do{
                    c = getchar();
                    if (c > ' ' || c != ENTER) { //
                        if (c == ',') {
                            tab[i] = name;
                            name.clear();
                            i++;
                            continue;
                        }
                        if (c != ENTER) {
                            name = name + c;
                        }
                        if (c == ENTER)
                        {
                            tab[i] = name;
                            name.clear();
                            if (isNumber(tab, 0))
                            {
                                //num = tab[0].toInt();
                                if (tab[1] == "S")
                                {
                                    //if (tab[2] == "?")
                                    //{
                                    //    temp_int = -1;
                                    //    temp_int = list.selectorsInSection(num);
                                    //    if (temp_int >= 0)
                                    //        cout << num << ",S,? == " << temp_int << ENTER;
                                    //}
                                    //if (tab[2].isInt())
                                    //    temp = list.selectorByIndexAndSection(tab[2].toInt(), num);
                                    //if (temp == "") {}
                                    //else
                                    //{
                                    //    cout << num << ",S," << tab[2].toInt() << " == " << temp << ENTER;
                                    //    temp.clear();
                                    //}
                                }
                                if (tab[1] == "A")
                                {
                                    if (tab[2] == "?")
                                    {
                                        //    temp_int = -1;
                                        //    temp_int = list.attributesInSection(num);
                                        //    if (temp_int >= 0)
                                        //        cout << num << ",A,? == " << temp_int << ENTER;//????
                                    }
                                    //else if (!tab[2].isInt())
                                    //{
                                    //    temp = list.valueBySectionAndName(num, tab[2]);
                                    //    if (temp == "") {}
                                    //    else
                                    //    {
                                    //        cout << num << ",A," << tab[2] << " == " << temp << ENTER;
                                    //        temp.clear();
                                    //    }
                                    //}
                                }
                                if (tab[1] == "D")
                                {
                                    if (tab[2] == "*")
                                    {
                                     //   list.deleteSectionByIndex(num);
                                      //  cout << num << ",D,* == deleted" << ENTER;
                                    }
                                    else
                                    {
                                        //    if (!list.isAttributeDeleted(num, tab[2]))
                                        //    {
                                        //        list.deleteAttributeByNameAndIndex(num, tab[2]);
                                        //        cout << num << ",D," << tab[2] << " == deleted" << ENTER;
                                        //    }
                                    }
                                }
                            }
                            else // name
                            {
                                if (tab[1] == "S")
                                {
                                    if (tab[2] == "?")
                                    {
                                        //    cout << tab[0] << ",S,? == " << list.countSelectorOccurances(tab[0]) << ENTER;
                                    }
                                }
                                else if (tab[1] == "A")
                                {
                                    if (tab[2] == "?")
                                    {
                                        //    cout << tab[0] << ",A,? == " << list.countAttributeOccurances(tab[0]) << ENTER;
                                    }
                                }
                                else if (tab[1] == "E")
                                {
                                    //temp = list.attributeValueBySelector(tab[2], tab[0]);
                                    //if (temp == "") {}
                                    //else
                                    //{
                                      //  cout << tab[0] << ",E," << tab[2] << " == " << temp << ENTER;
                                     //   temp.clear();
                                    //}

                                }
                                else if (tab[0] == "****")
                                {
                                    break;
                                }
                                else if (tab[0] == "?")
                                {
                                    // cout << "? == " << list.sectionsCount() << ENTER;
                                }
                            }
                            for (int j = 0; j < 3; j++)
                                tab[j].clear();
                            i = 0;
                        }
                    }
                }while (c != EOF);
            }
        }


    } while (c != EOF);


    /*
    do{
        character = getchar();
        if (character > ' ' || character == ENTER) { //character != ENTER && character != ' '
            if (counter % T == 0) { //czy nową listę tablicy sekcji stworzyć
                //list.addSection();
                //list.moveList(); //przechodzenie do kolejnego węzła listy
            }

            if (character == '?' && komendy==false) {
                pocz_komend++; //ile jest znaków zapytania
            }
            else if (character == '*' && css == false) {
                pocz_css++; //ile jest gwiazdek
            }

            if (character == '?' && pocz_komend > 0 && komendy == true) {
                pocz_komend = 0; //wyzerowanie znakow zapytania po tym jak już były ????
            }

            else if (character == '*' && pocz_css > 0 && css == true) {
                pocz_css = 0; //wyzerowanie gwiazdek po tym jak juz były ****
            }

            //wszystkie komendy
            if (komendy == true) {

                //if (isNumber(character) || isNotQuestionMark(character)) {
                //    request = true;
                //}

                if (request == false) {
                    if (character == '?') { //komenda ? czyli wyświetlenie liczby selektorów
                        cout << "? == " << list.countSections(); //work
                        for (int i = 0; i < list.countSections(); i++) {
                            cout << "\n-----\n" << "Selektory:\n";
                            list.printSelectors(number, i);
                            cout << "-----\n";
                            cout << "Atrybuty\n";
                            list.printAttributes(i);
                        }
                        cout << "\n-----\n" << "Selektory:\n";
                        selektor.printSelectorsList();
                        cout << "-----\n";
                        cout << "Atrybuty\n";
                        atrybut.printAttributesList();
                        cout << "-----\n";
                    }
                }
                
                else {
                    if (character != ',') {
                        komenda[index] = komenda[index] + character;
                    }
                    else if (character == ',') {
                        index++;
                    }
                    if (index == 2 && character == ENTER) {
                        index = 0;
                        request = false;
                        printRequest(komenda);
                        //cout wynik requestu
                    }
                }

            }

            if (komendy == false && css == true) { //wczytywanie cssa
                if (character != '{' && isSelectorOver==false && character !='?') { //czy jest to selektor
                    if (character != ',' && character != ENTER) { //co z \n  && character != ' ' //dodawanie znakow do nazwy selektora
                        name = name + character;
                    }
                    else { //dodawanie selektora
                        list.addSelector(number, name); //number (1-T)
                        selektor.add(name); //do usuniecia
                        name = "";
                    }
                }
                if (character == '{') { //kiedy jest koniec selektora
                    isSelectorOver = true;
                }
                if (character != '}' && isSelectorOver==true) { //czy sa to atrybuty
                    if (isProperty == true && isAtr == true) { //jezeli mamy nazwe atrybutu i wartosc dodajemy atrybut
                        atrybut.add(property, value); //do usuniecia
                        list.addAttribute(number, property, value);
                        atrybut.removeDuplicates(); //raczej nie dziala
                        property = "";
                        value = "";
                        isProperty = false;
                        isAtr = false;
                    }

                    if (character != ':' && isProperty == false && character != ENTER && character != '{') { //dodawanie znakow do nazwy atrybutow
                        property = property + character;
                        //cout <<"property:"<< property << endl;
                    }
                    if (character != ';' && isProperty==true && character != ENTER) { // dodawanie znakow do wartosci
                        value = value + character;
                        //cout <<"value: "<< value << endl;
                    }
                    else if (character == ':') { //koniec nazwy atrybutu
                        isProperty = true;
                    }
                    else if (character == ';') { //koniec wartosci atrybutu //nierozpatrzony ostatni atrybut w sekcji gdzie nie musi byc ;
                        isAtr = true;
                    }
                }
                if (character == '}') { //koniec selektorow
                    isSelectorOver = false;
                }
            }

            if (pocz_komend == 4) { //czy jest ????
                komendy = true; //komendy i css są przemienne tak naprawde
                css = false;
            }
            else if (pocz_css == 4) { //czy jest ****
                komendy = false;
                css = true;
            }
        }

    } while (character != EOF); //EOF 
    */
    return 0;
}
