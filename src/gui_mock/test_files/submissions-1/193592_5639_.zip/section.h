#pragma once
#include "selectorlist.h"
#include "attributelist.h"

class Section
{
private:
	SelectorList selectors;
	AttributeList attributes;
	friend class SectionList;
public:
	bool used = false;

	void addSelector(MString& name) {
		selectors.add(name);
	}

	void addAttribute(MString& property, MString& value) {
		attributes.add(property, value);
	}

	int howManySelectors() {
		return selectors.countSelectors();
	}

	int howManyAttributes() {
		return attributes.countAttributes();
	}

	bool isUsed() {
		if (selectors.countSelectors() > 0) return true;
		return false;
	}

	void removeAttributes() {
		attributes.remove();
	}

	void removeSelectors() {
		selectors.remove();
	}

	void removeAttribute(MString& property) {
		attributes.remove(property);
	}

	int howManyAttributes(int index) {
		return attributes.getSize();
	}

	void printSection() const {
		selectors.printSelectorsList();
		attributes.printAttributesList();
	}
};

