#pragma once
#include "mstring.h"
const int T = 8;

struct NodeSelector
{
	MString name;
	NodeSelector* next;
	NodeSelector* prev;
};

class SelectorList {
private:
	NodeSelector* head;
	NodeSelector* tail;
	int amount = 0;
public:
	SelectorList() : head(nullptr), tail(nullptr) {};

	int getSize() const {
		return amount;
	}
	//&
	void add(MString& name) {
		NodeSelector* newNode = new NodeSelector{ name, nullptr };

		if (head == nullptr) {
			head = newNode;
			tail = newNode;
			newNode->next = head;
		}
		else {
			NodeSelector* prevTail = tail;
			tail->next = newNode;
			tail = newNode;
			tail->next = head;
			tail->prev = prevTail;
		}
		amount++;
	}
	//&
	void remove(MString& name) {
		if (head == nullptr) {
			return;
		}

		NodeSelector* current = head;
		NodeSelector* prev = tail;
		do {
			if (current->name == name) {
				if (current == head) {
					current->next->prev = prev;
					head = current->next;
					prev->next = head;
				}
				else if (current == tail) {
					tail->prev->next = head;
					tail = tail->prev;
					head->prev = tail;
				}
				else {
					prev->next = current->next;
					current->next->prev = current->prev;
				}
				delete current;
				amount--;
				return;
			}
			prev = current;
			current = current->next;
		} while (current != head);
	}

	void remove() {
		if (head == nullptr) {
			return;
		}

		NodeSelector* current = head;
		do {
			NodeSelector* temp = current->next;
			delete current;
			current = temp;
		} while (current != head);
		amount = 0;
	}

	MString& getName() {
		return head->name;
	}
	//&
	MString getSelectorName(int index) {
		MString selector_name;
		NodeSelector* marker = head;

		for (int i = 0; i < T; i++) {
			if (index == i) {
				selector_name = marker->name;
				break;
			}
			marker = marker->next;
		}

		return selector_name;
	}

	//const
	void printSelector(int index) const{
		NodeSelector* marker = head;

		for (int i = 0; i < T; i++) {
			if (index == i) {
				std::cout << marker->name;
				break;
			}
			marker = marker->next;
		}

	}

	void printSelectorsList() const {
		NodeSelector* current = head;
		if (head == nullptr) {
			std::cout << " Lista jest pusta";
		}
		else {
			do {
				std::cout << current->name << std::endl;
				current = current->next;
			} while (current != head);
		}
	}

	int countSelectors() {
		int counter = 0;

		if (head == nullptr) {
			return counter;
		}

		NodeSelector* marker = head;
		do{
			counter++;
			marker = marker->next;
		}while (marker != head);

		return counter;
	}
	//const
	int countSelectors(MString& name) const {
		int counter = 0;
		NodeSelector* marker = head;

		if (head == nullptr) {
			return counter;
		}
		do {
			if (marker->name == name) {
				counter++;
			}
			marker = marker->next;
		} while (marker != head);

		return counter;
	}

	~SelectorList() {
		NodeSelector* current = head;
		while (current != nullptr && current != tail) { //
			NodeSelector* next = current->next;
			delete current;
			current = next;
		}
		delete tail;
		head = nullptr;
		tail = nullptr;
	}
};

