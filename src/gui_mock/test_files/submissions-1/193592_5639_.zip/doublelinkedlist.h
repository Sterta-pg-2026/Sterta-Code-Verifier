#pragma once
#include <iostream>
#include "mstring.h"

struct Box {
	MString data; //warto w projekcie bedzie to raczej Mstring
	Box* next; //wskanik na nastpny element
	Box* prev; //wskanik na poprzedni element
	
};

class DoubleLinkedList
{
private:
	Box* head; //wskanik na gow listy
	Box* tail; //wskanik na ogon listy
public:
	DoubleLinkedList() : head(nullptr), tail(nullptr) {}; //przyznawanie zerowych wartoci podstawowych

	void add(MString data) {
		//tworzenie nowego wza i nadanie im odpowiednich wartoci
		//data - warto ktr ma przechowywa nowy wze
		//nullptr (next --> head) - wskanik na wze, po ktrym nowy wze powinnien by dodany
		//tail (prev --> tail) - wskanik na poprzedni wze, ktry by poprzednikiem aktualnego wza
		Box* newPrep = new Box{ data, nullptr, tail };
		//Box* newPrep = new Box(data, nullptr, tail);
		

		//spradzenie czy wskanik next po ktrym nowy wze ma by dodany nie jest wskazuje na nic
		//jezeli tak ustawienie tego wskaznika next na prev

		if (head == nullptr) {
			head = newPrep;
		}
		else {
			tail->next = newPrep;
		}
		tail = newPrep;
	}

	void remove(MString data) {
		//tworzymy wskaznik ktory bedzie nam chodzil po liscie
		Box* current = head;
		//sprawdzamy czy nasz wskaznik ma nastepny element
		while (current != nullptr) {
			//jezeli tak to sprwadzamy czy dane ktore chcemy usunac sie zgadzaja z danymi w tym wskazniku
			if (current->data == data) {
				//jezeli tak to sprawdzamy czy nasz wskaznik nie jest headerem
				//bez tego warunku jest niebezpieczenstwo utracenia calej listy
				if (current == head) {
					//przypisujemy nowy header do nastpenego elementu w ten sposob "ucinajac" niepozadany pierwszy
					head = current->next;
					//sprawdzamy czy przypadkiem nowy header nie wskazuje na nic (czyli czy nasza lista miala tylko jeden wezel w sobie)
					if (head != nullptr) {
						//powracamy na stare miejsce i wskazujemy na nic
						head->prev = nullptr;
					}
				}
				//jsprawdzamy czy nasz wskaznik wskazuje na koniec listy
				else if (current == tail) {
					//przypisujemy koniec listy do poprzedniego elementu
					tail = current->prev;
					tail->next = nullptr;
				}
				//kiedy nasz wezel jest w srodku listy
				else {
					//wyrzucamy niepozadany wezel przez proste zamienianie wskaznikow
					//laczac poprzedni niepozadanego wezla z nastpenym niepozadanego wezla i odwrotnie
					current->prev->next = current->next;
					current->next->prev = current->prev;
				}
				//dla innych przypadkow czyscimy po sobie i uciekamy
				delete current;
				return;
			}
			//przechodzimy dalej szukajac niepozadanego wezla
			current = current->next;
		}
	}

	void print() {
		Box* current = head;

		while (current != nullptr) {
			std::cout << current->data << " ";
			current = current->next;
		}
		std::cout << std::endl;
	}

	~DoubleLinkedList() {
		Box* current = head;
		while (current != nullptr) {
			Box* next = current->next;
			delete current;
			current = next;
		}
	}
};

