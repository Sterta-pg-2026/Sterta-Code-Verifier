#pragma once
#include "section.h"
#include "selectorlist.h"

struct NodeSections {
	NodeSections* prev;
	NodeSections* next;
	Section section[T] = {};
};

class SectionList {
private:
	NodeSections* head;
	NodeSections* tail;
public:
	SectionList() : head(nullptr), tail(nullptr) {};

	void addSection(Section& section) {
		int j = -1;
		section.used = true;

		for (int i = T-1; i>=0 ; i--) {
			if (tail->section[i].used) {
				break;
			}
			else {
				j = i;
			}
		}

		if (j == -1) {
			NodeSections* newNode = new NodeSections;

			if (head == nullptr) {
				head = newNode;
				tail = newNode;
				newNode->next = head;
			}
			else {
				NodeSections* prevTail = tail;
				tail->next = newNode;
				tail = newNode;
				tail->next = head;
			}

			tail->section[0] = section;
		}
		else {
			tail->section[j]=section;
			
		}

	}

	void addSelector(int index, MString& name) {
		int number_of_sections = 0;
		NodeSections* current = head;

		do {
			for (int i = 0; i < T; i++) {
				if (current->section[i].isUsed()) {
					number_of_sections++;
				}
			}
			if (number_of_sections == index) {
				current->section[index].addSelector(name);
			}
			current = current->next;
		} while (current != head);

	}

	void addAttribute(int index, MString& property, MString& value) {
		int number_of_sections = 0;
		NodeSections* current = head;

		do {
			for (int i = 0; i < T; i++) {
				if (current->section[i].isUsed()) {
					number_of_sections++;
				}
			}
			if (number_of_sections == index) {
				current->section[index].addAttribute(property, value);
			}
			current = current->next;
		} while (current != head);
	}

	bool isEmpty() {
		if (head == nullptr) {
			return true;
		}
		return false;
	}

	//DO ZROBIENIA //i,D,*
	bool removeSection(int index) {

		if (isEmpty()) {
			return false;
		}

		NodeSections* marker = head;

		int counter = 0;
		do {
			for (int i = 0; i < T; i++) {
				if (marker->section[i].used) {
					if (counter == index) {
						marker->section[i].removeAttributes();
						marker->section[i].removeSelectors();

						marker->section[i].used = false;
						return true;
					}
					counter++;
				}
			}
			marker = marker->next;
		} while (marker != head);
		return false;
	}
	//DO ZROBIENIA //i,D,n
	bool removeAttribute(int index, MString& property) {

		if (isEmpty()) {
			return false;
		}

		NodeSections* marker = head;

		int counter = 0;
		do {
			for (int i = 0; i < T; i++) {
				if (marker->section[i].used) {
					if (counter == index) {
						counter++;
						marker->section[i].removeAttribute(property);
						if (marker->section[i].howManyAttributes(i)==0) {
							removeSection(i);
							return true;
						}
					}
				}
			}
			marker = marker->next;
		} while (marker != head);

		return false;
	}

	int countSections() {
		NodeSections* current = head;
		int count = 0; 

		if (head == nullptr) {
			return count;
		}

		do{
			count++;
			current = current->next;
		} while (current != head);
		return count;
	}
	//i,S,?
	void printSelectors(int index) { 
		NodeSections* marker = head;

		for (int i = 0; i < T; i++) {
			if (index-1 == i) {
				std::cout << marker->section[i].howManySelectors();
			}
			marker = marker->next;
		}
		marker = nullptr;
		delete marker;
	}
	//i,S,j
	void printSelectors(int block_index, int selector_index) { 
		NodeSections* marker = head;

		for (int i = 0; i < T; i++) {
			if (block_index-1 == i) {
				marker->section[i].selectors.printSelector(selector_index-1);
			}
			marker = marker->next;
		}
		marker = nullptr;
		delete marker;
	}
	//for all blocks
	//z,S,?
	void printSelectors(MString& name) { 
		int count = 0;
		NodeSections* marker = head;

		for (int i = 0; i < T; i++) {
			count = count + marker->section[i].selectors.countSelectors(name);
			marker = marker->next;
		}
		std::cout << count;
		marker = nullptr;
		delete marker;
	}
	//i,A,?
	void printAttributes(int index) { 
		NodeSections* marker = head;

		for (int i = 0; i < T; i++) {
			if (index-1 == i) {
				std::cout << marker->section[i].howManyAttributes();
			}
			marker = marker->next;
		}
		marker = nullptr;
		delete marker;
	}
	//i,A,n
	void printAttributes(int index, MString& property) {
		NodeSections* marker = head;

		for (int i = 0; i < T; i++) {
			if (index - 1 == i) {
				std::cout << marker->section[i].attributes.printAttribute(property);
			}
			marker = marker->next;
		}
		marker = nullptr;
		delete marker;
	}
	//for all blocks
	//n,A,?
	void printAttributes(MString& property) { 
		int count = 0;
		NodeSections* marker = head;
		
		for (int i = 0; i < T; i++) {
			count = count + marker->section[i].attributes.countAttributes(property);
			marker = marker->next;
		}
		std::cout << count;
		marker = nullptr;
		delete marker;
	}
	//z,E,n
	void printAttribute(int selector_index) { 
		NodeSections* marker = head;
		MString selector_name;

		for (int i = 0; i < T; i++) {
			selector_name = marker->section[i].selectors.getSelectorName(selector_index);
			marker->section[i].attributes.printAttribute(selector_name);
			marker = marker->next;
		}
		marker = nullptr;
		delete marker;
	}
	


	void moveList() {
		head = head->next;
	}

	~SectionList() {
		NodeSections* current = head;
		while (current != nullptr && current != tail) {
			NodeSections* next = current->next;
			delete current;
			current = next;
		}
		delete tail;
		head = nullptr;
		tail = nullptr;
	}

	/*
	void addAttribute(const AttributeList& attr) {
		if (!nextAttr) {
			nextAttr = new SectionList;
		}
		nextAttr->attribute = attr;
	}

	void addSelector(const SelectorList& selector) {
		if (!nextSel) {
			nextSel = new SectionList;
		}
		nextSel->selector = selector;
	}*/
};