#pragma once
#include "mstring.h"

struct NodeAttribute
{
	MString property;
	MString value;
	NodeAttribute* next;
	NodeAttribute* prev;
};

//template <typename type>
//type dodaj(type a, type b)
//{
//	return a + b;
//}

//cykliczna lista
class AttributeList {
private:
	NodeAttribute* head;
	NodeAttribute* tail;
	int amount = 0 ;
public:
	AttributeList() : head(nullptr), tail(nullptr) {};
	//& do obu
	void add(MString& property, MString& value) {
		NodeAttribute* newNode = new NodeAttribute{ property, value, nullptr };

		if (head == nullptr) {
			head = newNode;
			tail = newNode;
			newNode->next = head;
		}
		else {
			NodeAttribute* prevTail = tail;
			tail->next = newNode;
			tail = newNode;
			tail->next = head;
			tail->prev = prevTail;
		}
		amount++;
	}
	//&
	void remove(MString& property) {
		if (head == nullptr) {
			return;
		}

		NodeAttribute* current = head;
		NodeAttribute* prev = tail;
		do {
			if (current->property == property) {
				if (current == head) {
					current->next->prev = prev;
					head = current->next;
					prev->next = head;
				}
				else if (current == tail) {
					tail->prev->next = head;
					tail = tail->prev;
					head->prev = tail;
				}
				else {
					prev->next = current->next;
					current->next->prev = current->prev;
				}
				delete current;
				amount--;
				return;
			}
			prev = current;
			current = current->next;
		} while (current != head);
	}

	void remove() {
		if (head == nullptr) {
			return;
		}

		NodeAttribute* current = head;
		do {
			NodeAttribute* temp = current->next;
			delete current;
			current = temp;
		} while (current != head);
		amount = 0;
	}

	void removeDuplicates() {
		if (head == nullptr) {
			return;
		}
		NodeAttribute* current = head;
		do {
			NodeAttribute* temp = current->next;
			while (temp != head) {
				if (temp->property == current->property && temp != current) {
					NodeAttribute* toDelete = temp; //temp //current
					//current = temp;
					toDelete->prev->next = toDelete->next;
					toDelete->next->prev = toDelete->prev;
					//toDelete=nullptr;
					delete toDelete;
				}
				else {
					temp = temp->next;
				}
			}
			current = current->next;
		} while (current != head);
	}

	int getSize() const{
		return amount;
	}

	/*
	void removeDuplicates() {
		if (head == nullptr) {
			return;
		}
		NodeAttribute* current = head;
		do {
			NodeAttribute* temp = current->next;
			while (temp != current) {
				if (temp->property == current->property) {
					NodeAttribute* toDelete = temp;
					temp = temp->next;
					toDelete->prev->next = toDelete->next;
					toDelete->next->prev = toDelete->prev;
					delete toDelete;
				}
				else {
					temp = temp->next;
				}
			}
			current = current->next;
		} while (current != head);
	}*/


	MString& getProperty() const{
		return head->property;
	}

	MString& getValue() const {
		return head->value;
	}
	
	int countAttributes() {
		int counter = 0;

		if (head == nullptr) {
			return counter;
		}

		NodeAttribute* marker = head;
		do {
			counter++;
			marker = marker->next;
		} while (marker != head);

		return counter;
	}
	//&
	int countAttributes(MString& property) {
		int counter = 0;
		NodeAttribute* marker = head;

		if (head == nullptr) {
			return counter;
		}

		do {
			if (marker->property == property) {
				counter++;
			}
			marker = marker->next;
		} while (marker != head);

		return counter;
	}
	//& do arg
	MString& printAttribute(MString& property) {
		NodeAttribute* marker = head;

		while (marker != head && marker != nullptr) {
			if (property == marker->property) {
				return marker->value;
			}
			marker = marker->next;
		}
		static MString emptyString = "";
		return emptyString;
	}

	void printAttributesList() const {
		NodeAttribute* current = head;
		if (head == nullptr) {
			std::cout << " Lista jest pusta";
		}
		else {
			do {
				std::cout << current->property << ": ";
				std::cout << current->value << std::endl;
				current = current->next;
			} while (current != head);
		}
	}

	/*bool areDuplicates() {
		NodeAttribute* newAtr1 = head->next;
		NodeAttribute* newAtr2 = head->next;

		do {
			do {
				if (newAtr1 != newAtr2 && newAtr1->property==newAtr2->property) {
					NodeAttribute* pom = newAtr1->prev;
					newAtr1->prev->next = newAtr1->next;
					newAtr1->next->prev = pom;
					newAtr1 = nullptr;
					delete pom;
					return true;
				}
				newAtr1 = newAtr1->next;
			} while (newAtr1 != tail);
			newAtr2 = newAtr2->next;
		} while (newAtr2 != tail);
		
		newAtr1 = nullptr;
		newAtr2 = nullptr;
		delete newAtr1;
		delete newAtr2;
		return false;
	}*/
	
	~AttributeList() {
		NodeAttribute* current = head;
		while (current != nullptr && current != tail) {
			NodeAttribute* next = current->next;
			delete current;
			current = next;
		}
		delete tail;
		head = nullptr;
		tail = nullptr;
	}
};
