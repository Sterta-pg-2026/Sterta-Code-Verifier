#pragma once
#include <iostream>

inline void strcopy(char* dst, const char* src) {
	int i = 0;
	for (i; src[i] != '\0'; i++) {
		dst[i] = src[i];
	}
	dst[i] = '\0';
}

class MString
{
private:
	int size; //wraz ze znakiem \0
	char* data;

public:
	friend std::ostream& operator<<(std::ostream& os, MString str) {
		return os << str.data; //wywietlanie danych za pomoca przeciazenia operatora<<
	}

	char* getData() {
		return data;
	}

	int getSize() const {
		return size;
	}

	int length() const {
		return size;
	}

	int getIndex(int num) {
		for (int i = 0; i < length(); i++) {
			if (data[i] == num)
				return i;
		}
	}

	bool isClear() {
		if (data == NULL) return true;
		return false;
	}

	void clear() {
		data = NULL;
	}

	MString() : size(1), data(new char[1])  {
		data[0]='\0';
	} //wypelnienie pustymi wartosciami

	MString(const char* str) { //konstruktor dla nowych charow
		this->size = strlen(str) + 1; //pobieranie dlugosci chara
		this->data = new char[size]; //tworzenie nowego wiekszego chara aby pomiescil wszystki dane z przeslanego str
		//strcpy_s(data, size+1, str);
		strcopy(data, str);
	}

	MString(const MString& str) { //konstruktor dla obiektow naszej klasy
		size = str.size;
		data = new char[size + 1];//[size]
		//strcpy_s(data, size+1, str.data);
		strcopy(data, str.data);
	}

	MString operator+(const MString& str) const { //laczenie stringow za pomoca przeciazenia operatora +
		MString result;
		result.size = size + str.size;
		result.data = new char[result.size + 1];
		//strcpy_s(result.data, result.size+1, data);
		strcopy(result.data, data);
		strcopy(result.data, str.data);
		//strcpy_s(result.data, result.size+1, str.data);
		return result;
	}

	MString operator+(char str) const {
		MString result;
		result.size = size + 1;
		result.data = new char[result.size];
		strcopy(result.data, data);
		result.data[result.size - 2] = str; // static_cast<char>(str);
		result.data[result.size - 1] = '\0';
		return result;
	}

	MString operator-(char c) const {
		MString result;
		result.size = size - 1;
		result.data = new char[result.size + 1];
		int j = 0; // indeks do wstawiania znakw do wynikowego stringa
		for (int i = 0; i < size; i++) {
			if (data[i] != c) { // jeli znak nie jest rwny usuwanemu znakowi
				result.data[j] = data[i]; // dodajemy znak do wynikowego stringa
				j++;
			}
		}
		result.data[j] = '\0';
		return result;
	}


	MString& operator=(const MString& str) {
		if (this != &str) { //czy nie przypisujemy do samego siebie
			delete[] data; //usuwamy starego "stringa"
			size = str.size; 
			data = new char[size + 1];
			strcopy(data, str.data); //strcpy_s zapewnia ze nie zawalimy bufora (nie wsadzimy za duzo informacji poza zakres)
		}
		return *this; //zwracamy nasz obiekt
	}
	
	MString operator=(const char* str) {
		delete[] data;
		size = strlen(str)+1;
		data = new char[size + 1];
		strcopy(data, str); //strcpy_s zapewnia ze nie zawalimy bufora (nie wsadzimy za duzo informacji poza zakres)
		return *this; //zwracamy nasz obiekt
	}

	MString operator=(const char c) { //moze byc ciekawie
		delete[] data;
		size = 2;
		data = new char[2];
		data[0] = c;
		data[1] = '\0';
		return *this;
	}
	
	bool operator==(const MString& str) {
		int counter = 0;
		if (size == str.size) {
			for (int i = 0; i < str.size; i++) {
				if (data[i] == str.data[i])
					counter++;
			}
		}
		if (counter != size)
			return false;
		else return true;
	}

	bool operator==(const char c) {
		if (size == 2 && data[0]==c) { //znak + \n
				return true;
		}
		else return true;
	}

	char& operator[](int index) {
		if (index >= 0 && index < size) {
			return data[index];
		}
	}

	//zwalnianie pamici utworzonych nowych tablicy charow
	~MString() { 
		delete[] data;
		data = nullptr;
	}
};

