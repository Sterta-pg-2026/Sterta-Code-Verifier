#include "attribute.h"
#include <iostream>

//Constructor
attribute::attribute(): Next(nullptr){
	this->Name = new Mystring();
	this->Value = new Mystring();
};
attribute::attribute(Mystring& Name,Mystring& Value, attribute* Next) : Next(Next) {
	this->Name = new Mystring(Name);
	this->Value = new Mystring(Value);

};
attribute::attribute(attribute* Next) :Next(Next){
	this->Name = new Mystring();
	this->Value = new Mystring();
};

//Basic Operation on element
attribute* const attribute::GetNext(void) const {
	if (this->Next != nullptr) {
		return this->Next;

	}
	return nullptr;
}

void const attribute::ChangeNext(attribute* Next) {
	this->Next = Next;
}

attribute* const attribute::FindEnd(void) {
	attribute* dummy = this;
	while (dummy->Next != NULL)
	{
		dummy = dummy->Next;
	}
	return dummy;
}

Mystring* const attribute::GetName(void) const {
	return(this->Name);
}

Mystring* const	attribute::GetValue(void) const {
	return(this->Value);
}

//Adding new Element
// if head element is empty add val to head. not to next node
void const attribute::AddAttribute(Mystring& Name, Mystring& Value) {

	if (!this->Name->compareChar('\0'))
	{
		if (this->Next == nullptr) {
			attribute* dummy = new attribute(Name, Value, nullptr);
			this->Next = dummy;
		}
		else
		{
			attribute* dummy = new attribute(Name, Value, nullptr);
			(this->FindEnd())->Next = dummy;
		}
	}
	else {
		this->Name = &Name;
		this->Value = &Value;
	}


}

//Delete Element
void const attribute::DelAttribute(int Number) {
	;
}


attribute* const attribute::FindElementByNum(int Number) {
	attribute* dummy = this;
	int i = 1;
	while (dummy != NULL)
	{
		if (i < Number) {
			if (dummy->Next != NULL) {
				dummy = dummy->Next;
				}
			else
			{
				dummy = nullptr;
				std::cout << "attribute number invalid";
				break;
			}
		}
		else if (i == Number) {
			return dummy;
		}
		i++;
	}
	return nullptr;
}

//Find element by Name if not return nullptr;
attribute* const attribute::FindElementByName(Mystring& Name) {
	if (this != nullptr)
	{
		if(this->Name !=nullptr)
		{
			if (this->Name->getText() != nullptr) {
				if (this->Name->compare(Name)) return(this);
				else return nullptr;
			}
			else
				return nullptr;
		}
		else
		{
			return nullptr;
		}
	}
	else {
		return nullptr;
	}
	return nullptr;
}


// Count elements
int const attribute::CountElements(void) {
	if (Name->compareChar('\0')) {
		return NULL;
	}
	else {
		int i = 0;
		attribute* dummy = this;
		while (dummy != nullptr)
		{
			dummy = dummy->Next;
			i++;
		}
		return i;
	}

}

int const	attribute::FindNumOfAtr(Mystring& Name) {
	int i = 0;
	attribute* dummy = this;

	attribute* test = nullptr;
	while (dummy != NULL) {
		test = dummy->FindElementByName(Name);
		if (test == nullptr) {
			i++;
		}
		else {
			return i;
		}
		dummy = dummy->GetNext();

	}
	if (test == nullptr) return(-1);
	else return(i);

}

//Delete element by index number

/*
void const	attribute::DelAttributeByNumber(int Number) {
	if (Number > 0) {
		(this->FindElementByNum(Number - 1))->DelAttributeAfter();
	}
	else if(Number==0)
	{
		Value =Next->Value;
		Next = Next->Next;
		//this->Next==this
	}
}*/

/*attribute* const attribute::FindAttributeByNameGetNum(Mystring& Name) {
	attribute* dummy = this;
	while (!dummy->Name->compare(Name)) {
		;
	}
	return dummy;
}*/

//Print
void const attribute::Print(void) const{
	std::cout << "Attribute	Addres::" << this << std::endl;
	std::cout << "Name	";
	this->Name->Print();
	std::cout << std::endl << "Value	";
	this->Value->Print();
	std::cout << std::endl;

}

void const attribute::PrintAll(void) {
	attribute* dummy = this;
	while (dummy !=NULL)
	{
		dummy->Print();
		dummy = dummy->Next;
	}
}

attribute::~attribute() {
	delete this->Name;
	delete this->Value;
}