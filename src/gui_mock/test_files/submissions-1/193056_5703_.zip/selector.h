#ifndef SELECTOR_H
#define SELECTOR_H
#pragma once
#include <iostream>
#include "mystring.h"
class selector
{
private:
	Mystring* Name = nullptr;
	selector* Next = nullptr;
public:
	//constructor
	selector();
	selector(selector* Next);
	selector(Mystring& Name, selector* Next);

	//Basic Operation on element
	selector* const		GetNext(void) const;
	selector* const		FindEnd(void);
	void const			ChangeNext(selector* Next);
	//	void const			ChangeValue(Mystring* Data);
	//	void const			ChangeValue();
	Mystring* const		GetName(void) const;

	//Adding new Element
	void const			AddSelector(Mystring& Name);

	//Delete Element	NAPRAWI !! BRAK USUNICIA DANYCH Z USUWANEJ KOMRKI
	void const			DelSelectorAfter(void);

	// Find element by index Nymber
	selector* const		FindElementByNum(int Numer);

	//Find element by Name
	selector* const		FindElementByName(Mystring& Name);



	//Count elements
	int const			CountElements(void);

	//Delete element by index number NAPRAWI !! BRAK USUNICIA DANYCH Z USUWANEJ KOMRKI
	void const			DelSelectorByNumber(int Number);


	//Print
	void const			Print(void) const;
	void const			PrintAll(void);
	
	~selector();

};


#endif // !SELECTOR_H




