#ifndef STRING_H
#define STRING_H
#pragma once

#include <iostream>
class Mystring
{
private:
	char* text=nullptr;
	int size=NULL;
public:

	//Constructor
	Mystring(const char* text);
	
	Mystring(const Mystring& Mystring);

	Mystring(int size = 8);


	//Basic	operation on string
	char*		getText(void);

	int		getLength(void) const;

	int		strlen(const char* text);

	char*		copy(char* first,const char* sec,int size);

	void		setLength(int size);

	void		add(const Mystring& text2);

	void		addChar(const char text2);

	bool		compare(const Mystring& text2) const;

	bool		compareChar(const char text2) const;

	void		SetText(const char* text);

	void		SetTextString(const Mystring* name);
	
	//get element by position
	char		getByPosition(int position) const;

	//Print stuff
	void const	Print(void) const;

//	char operator[](int position);

	Mystring& operator=(const Mystring& other);

	~Mystring();

};

#endif // STRING_H



