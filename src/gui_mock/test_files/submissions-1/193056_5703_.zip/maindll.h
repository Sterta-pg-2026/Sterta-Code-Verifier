#pragma once
#ifndef MAINDLL_H
#define MAINDLL_H


#define T	8
#include <iostream>
#include "section.h"
class MainDLL
{
private:
	MainDLL* Prev=nullptr;
	MainDLL* Next=nullptr;
	Section ** MainTab=nullptr;
	int NumOfTaken;
	bool IsTaken[T];


public:
	//Constructor
	MainDLL();
	MainDLL(MainDLL* Prev,MainDLL*Next);
	MainDLL(int NumOfTaken, MainDLL* Prev, MainDLL* Next);

	//Basic Operation on element MainDLL
	MainDLL* const	MainDLLGetAddres(void);
	MainDLL* const	GetPrev(void) const;
	MainDLL* const	GetNext(void) const;
	MainDLL* const	FindEnd(void);
//	void const		ChangePrev(MainDLL* Next);
	void const		ChangeNext(MainDLL* Prev);

	//Section operation
	Section* const	GetSectionByNumber(int i);

	/*
	//Adding new Element for MainDLL
	void const		AddMainDll(void);

	//Adding new Element for MainDLL getting Addres back
	MainDLL* const	AddMainDllA(void);*/

	// Removing last Element for MainDLL
	// Usuwanie z listy dziaa do zrobienia zwalnianie pamici !
	void const		DellMainDll(void);


	// Opperation on NumTaken	
	int const		GetNumOfTaken(void) const;
//	void const		AddNumOfTaken(void);
	void const		DellNumOfTaken(void);

	
	//Is Node Free to add new Section 
//	bool const		CanAddMoreSection(void) const;
	// Find Free Node
	int const		FindFreeSection(MainDLL* dummy);
	
	//Find free Section
	MainDLL* const	FindLastNode(void);
	
	//Filling new section
	void const		FillNewNode(Mystring& NameA, Mystring& Value, Mystring& NameS);

	void const		FillNewNode(char znak);

	void const		ConsoleMode();

	char const		WriteMode();

	char const		ComendMode();

	char const		CheckIfEndOfWriteMode();

	char const		CheckIfEndOfComendMode();

//	int	const		GetNumForComend();

	char const		RecogniseComend(char Firstznak);

	int const		GetComendNum(char Firstznak);

	int const		GetComendNumSec(char Firstznak,char* oldznak=nullptr);

	Mystring* const	GetFirstPartComendString(char Firstznak);

	Mystring* const	GetSecPartComendString(char Firstznak, char* oldznak= nullptr);


	int const		NumberPart(char* const buffor);

	void const		SectionDEL(int number);

	//wypisz liczb sekcji CSS;
	int const		CountNumSectionCSS();



	Section* const	GetSectionByNum(int number, MainDLL** ptrToChange = nullptr,int *oldi=nullptr) ;

	void const		CountNumSelector(Mystring* NameS);

	void const		CountNumAttribute(Mystring* NameA);

	Section* const	GetLastSelectorByName(Mystring& NameS);

	void const		FreeSection(int number);

	//void const		FillToCurrientSection()
	

	
	//TESTING FUNCTION

	//Print stuff
	void const		Print() const;
	void const		PrintMainDLL() const;

	//Destructor
	~MainDLL();
};


#endif // !MAINDLL_H


