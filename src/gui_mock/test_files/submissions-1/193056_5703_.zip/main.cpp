#include <iostream>
#include "maindll.h"
#include "attribute.h"
#include "mystring.h"

using namespace std;
 

int main() {
	MainDLL* head = new MainDLL();


	head->ConsoleMode();


	MainDLL* dummy = head;
	while (dummy!=nullptr) {
		MainDLL* temp = dummy;
		dummy = dummy->GetNext();

		delete temp;

	}

}; 
