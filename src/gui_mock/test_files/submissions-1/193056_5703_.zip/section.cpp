#include <iostream>
#include "section.h"

//Constructor 
Section::Section() {
	headA = new attribute();
	headS = new selector();
};

		//ATTRIBUTE stuff
//acces attribute
attribute* const Section::GetHeadA(void)  const{
	if (this != nullptr && this->headA != nullptr)return headA;
	else return nullptr;
}

attribute* const Section::GetAttributeByNum(int i) const {
	return headA->FindElementByNum(i);
}

//add new attribute with value
void const	Section::AddAttribute(Mystring& Name, Mystring& Value) const{
	headA->AddAttribute(Name, Value);
}

//Finde attribute by Name 
attribute* const Section::FindAttribute(Mystring& Name) const {
	attribute* dummy = headA;
	attribute* last =nullptr;
	attribute* test = nullptr;
	while (dummy != nullptr) {
		test = dummy->FindElementByName(Name);
		if (test!=nullptr) {
			last=test;
		}
		
			dummy = dummy->GetNext();
	
	}
	return(last);
}


//Find element by Name Print all
int const	Section::FindAttributeByNameCount(Mystring& Name)  const{
	if (this != nullptr) {
		if (this->headA != nullptr) {
			if (&Name == nullptr) return 0;
			attribute* dummy = nullptr;
			dummy = headA;
			int n = 0;
			while (dummy != nullptr) {
				if (dummy->FindElementByName(Name)) {
					return 1;
				}

				if (dummy->GetNext() == nullptr) return 0;
				dummy = dummy->GetNext();

			}
			return 0;
		}

		return 0;
	}
	return 0;
	}


int const	Section::FindNumOfAtr(Mystring& Name) {
	if (this != nullptr) return(this->headA->FindNumOfAtr(Name));
	else return -1;
}

Mystring* const	Section::FindAttributeGetValue(Mystring& Name) {
	return(FindAttribute(Name)->GetValue());
}

Mystring* const Section::FindAttributeGetValuePrint(Mystring& Name) {
	attribute* dummy = FindAttribute(Name);
	if (dummy != nullptr) {
		return dummy->GetValue();
	}
	else {
		return(nullptr);
	}
}

//attribute count
int const Section::CountAttribute(void) {
	if (this != nullptr) return(headA->CountElements());
	else return -1;
	
}

//dell by num
bool const Section::DelAttributeByNum(int Number) {
		attribute* temp = headA;
		attribute* prev = NULL;

		if (temp == nullptr) {
			return false;
		}

		// If the node to be deleted is the head node
		if (Number == 0) {
			if (headA->GetNext() == nullptr) {
				headA->ChangeNext(new attribute);
			}
			headA = temp->GetNext();
			delete temp;
			return true;
		}

		int i = 0;

		while (temp != nullptr && i < Number) {
			prev = temp;
			temp = temp->GetNext();
			i++;
		}

		if (temp == nullptr) {
			return false;
		}

		prev->ChangeNext(temp->GetNext());
		delete temp;
		return true;
}



//Write MODE 



void const Section::WriteSelector(char firstznak) {
	char first = firstznak;
	char sec = NULL;

	while (first == ' ' || first == '\n' || first=='\t') {
		scanf_s("%c", &first, 1);
	}
	Mystring* nazwa = new Mystring();
	if (first == '{') {

		headS->AddSelector(*nazwa);
	

	}
	else {	
	while (sec != '{') {
		nazwa->addChar(first);
		first = sec;
		scanf_s("%c", &sec, 1);
		if (sec == '{') {
			if (first != ' ') {
				nazwa->addChar(first);
				if (this->FindSelectorInOneSection(*nazwa) == nullptr) {
					headS->AddSelector(*nazwa);

				}
				
			}
			else {
				if (this->FindSelectorInOneSection(*nazwa) == nullptr) {
					headS->AddSelector(*nazwa);

				}

			}
			
		}
		if (sec == ',') {
			if (first != ' ' && first !='\n' && first !='\t') {
				nazwa->addChar(first);
				if (this->FindSelectorInOneSection(*nazwa) == nullptr) {
					headS->AddSelector(*nazwa);

				}
				nazwa = new Mystring();
				scanf_s("%c", &sec, 1);
				while (sec == ' ' || sec == '\t' || sec == '\n') {
					scanf_s("%c", &sec, 1);
				}
				first = sec;
				scanf_s("%c", &sec, 1);
			}
			else
			{
				if (this->FindSelectorInOneSection(*nazwa) == nullptr) {
					headS->AddSelector(*nazwa);

				}
				nazwa = new Mystring();
				scanf_s("%c", &sec, 1);
				while (sec == ' ' || sec == '\t' || sec == '\n') {
					scanf_s("%c", &sec, 1);
				}
				first = sec;
				scanf_s("%c", &sec, 1);
			}
		}
		if (sec == '\n' || sec=='\t') {
			if (first != '\n' && first != '\t' && first!='{' && first!=',' && first!=' ') {
				nazwa->addChar(first);
			}
			while (sec!='{' && sec!=',' && sec!='\t')
			{
				sec=getchar();
				first = sec;
			}
			if (this->FindSelectorInOneSection(*nazwa) == nullptr) {
				headS->AddSelector(*nazwa);

			}
		}
		


	}
	}
}


void const Section::WriteAttribute() {
	char znak = NULL;
	bool test = true;
	Mystring* nazwa = new Mystring();
	znak = getchar();
	while (znak == ' ' || znak=='\n' || znak=='\t') {
		znak = getchar();
	}
	while (test) {
		if (znak == ':') {
			test = WriteValue(*nazwa);
			if (!test) break;
			if (znak == '}') break;
			nazwa = new Mystring();
			znak = getchar();
			if (znak == '}') break;

			while (znak == ' ' || znak=='\t'|| znak=='\n') {
				znak = getchar();
			}
			if (znak == '}') break;

		}
		
		nazwa->addChar(znak);
		znak = getchar();
		if (znak == '\n' || znak == '\t') {
			while (znak != '\n' && znak != '\t')
				znak = getchar();
		}
	}
}


bool const Section::WriteValue(Mystring& Name) {
	char znak = NULL;
	Mystring* value = new Mystring();
	znak = getchar();
	while (znak == ' ' || znak == '\t' || znak == '\n') {
		znak = getchar();
	}
	while (znak != '}' && znak != ';') {
		value->addChar(znak);
		znak = getchar();
		if (znak == '\n') znak = getchar();
	}

	attribute* dummy = nullptr;
	dummy = FindAttribute(Name);
	if (dummy != nullptr) {
		dummy->GetValue()->SetTextString(value);

	}
	else {
	
		headA->AddAttribute(Name, *value);


	}
	if (znak == ';') return true;
	if (znak == '}') return false;
	return true;
}

		//Selector stuff
//acces slector 
selector* const Section::GetHeadS(void) const {
	return(headS);
}

void const		Section::FreeHead(void) {
	headA = nullptr;
	headS = nullptr;
}

selector* const Section::GetSelectorByNum(int i) {
	return(headS->FindElementByNum(i));
}

//add new selector with val
void const	Section::AddSelector(Mystring& Name) const {
	headS->AddSelector(Name);
}

selector* const Section::FindSelectorInOneSection(Mystring& Name) const{
	if (this != nullptr) {
		if (this->headS != nullptr) {
			selector* dummy = nullptr;
			dummy = headS;
			while (dummy != nullptr) {
				if (dummy->GetName() != nullptr) {
					if (dummy->GetName()->compare(Name)) return dummy;
					dummy = dummy->GetNext();
				}
			}
			return nullptr;
		}
		return nullptr;


	}
	return nullptr;

}

//find selector by name
selector* const	Section::FindSelector(Mystring& Name)  const{
	selector* dummy = headS;
	selector* last = nullptr;
	selector* test = nullptr;

	while (dummy != nullptr) {
		test = dummy->FindElementByName(Name);
		if (test) {
			last = test;
		}
		dummy = dummy->GetNext();
	}
	return(last);
}

Section* const	Section::FindSelectorToSection(Mystring& Name) {
	selector* dummy = headS;
	selector* last = nullptr;
	selector* test = nullptr;
	while (dummy != nullptr) {
		test = dummy->FindElementByName(Name);
		if (test) {
			last = test;
			break;
		}
		dummy = dummy->GetNext();

	}
	if (last != nullptr) return(this);
	else return(nullptr);
}

int const Section::FindSelectorCount(Mystring& Name) const{
	if (this != nullptr) {
		if (this->headS != nullptr) {
			selector* dummy = headS;
			int n = 0;
			while (dummy != nullptr) {
				if (dummy->FindElementByName(Name)!=nullptr) {
					n++;
				}

				dummy = dummy->GetNext();


			}
			return(n);
		}
		return(0);

	}
	return(0);

}


//Selector count
int const Section::CountSelector(void) {
	if (this != nullptr) return(headS->CountElements());
	else return -1;
}

void const	Section::FindElementByNamePrintAll(Mystring& Name) const {
	selector* dummy = headS;
	int n = NULL;
	while (dummy != nullptr) {
		if (dummy->FindElementByName(Name)) {
			n++;
		}
		dummy = dummy->GetNext();
	}
	std::cout << n;
}

void const Section::DelSelectorByNum(int Number) {
	headS->DelSelectorByNumber(Number);
}


void const Section::Print(void) const {
	std::cout << "attributes of Section:	" << std::endl;
	headA->PrintAll();
	std::cout << std::endl;
	std::cout << "Selectors of Section:	" << std::endl;
	headS->PrintAll();
}

void const Section::Print(int i) const {
	std::cout << "		Section Number:" << i << std::endl;
	std::cout << "Selectors of Section:		" << std::endl;
	headS->PrintAll();
	std::cout << std::endl;
	std::cout << "attributes of Section:	" << std::endl;
	headA->PrintAll();

}

Section::~Section() {
	attribute* dummyA = nullptr;
	dummyA = this->headA;
	while (dummyA!=nullptr) {
		attribute* temA = dummyA;
		dummyA = dummyA->GetNext();
		delete temA;

	}

	selector* dummyS = nullptr;
	dummyS = this->headS;
	while (dummyS!= nullptr) {
		selector* temS = dummyS;
		dummyS = dummyS->GetNext();
		delete temS;

	}
}