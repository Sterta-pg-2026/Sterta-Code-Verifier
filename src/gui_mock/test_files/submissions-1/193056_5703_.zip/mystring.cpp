#include "mystring.h"
#include <iostream>


//Constructor
Mystring::Mystring(const char* text) {
	int size = strlen(text);
    this->text = new char[size];
    this->size = size;

    if (this->text != NULL) {  
        memcpy(this->text, text, size);
    }
}
/*
Mystring::Mystring(const Mystring& Mystring) {
    this->size = Mystring.getLength();
    this->text = new char[this->size];

    if (this->text != NULL) {
        copy(this->text, Mystring.text, this->size);
    }

}*/

Mystring::Mystring(const Mystring& other) {
    this->size = other.size;
    this->text = new char[other.size];
    memcpy(this->text, other.text, other.size);
}

Mystring::Mystring(int size) {
    this->text = new char[size];
    this->size = size;

    if (this->text != NULL) {
        this->text[0]='\0';
    }
}



char* Mystring::getText() {
    return this->text;
}

void Mystring::SetText(const char* text) {
    delete[] this->text;

    this->size = strlen(text);
    this->text = new char[this->size];

    copy(this->text, text, this->size);
}

void Mystring::SetTextString(const Mystring* Name) {
    this->size = Name->size;
    this->text = Name->text;

}

int Mystring::getLength(void) const {
    int count = 0;
    if (this == nullptr) return 0;
    while (this->text[count] != '\0') {
        count++;
        this->text[count];
    }
    return(count);
}

int Mystring::strlen(const char* text) {
    int count = 0;
    while (*text != '\0')
    {
        count++;
        text++;
    }
    return count;
}

char* Mystring::copy(char* first,const char* sec, int size) {
    int i;
    for (i = 0; i < size && sec[i] != '\0'; i++) {
        first[i] = sec[i];
    }
    first[i + 1] = '\0';
    return first;
}

void Mystring::setLength(int size) {

        int old_length = this->getLength();
        char* old_text = nullptr;
        old_text = new char[old_length]{NULL};
 //       old_text[old_length] = '\0';

        for (int i = 0; i<old_length; i++) {
            old_text[i] = this->text[i];
        }
        bool delete_old = true;

        this->size = size;
        this->text = new char[size];
        for (int i = 0; i < old_length; i++)
        {
            this->text[i] = old_text[i];
        }
        this->text[old_length] = '\0';
        if (delete_old) {
            delete[] old_text;
        }
   

    
}

void Mystring::add(const Mystring& text2) {
    int new_size = this->size + text2.size;
    setLength(new_size);
    int n = getLength();
    for (int i = n; i < new_size; i++)
    {
        this->text[i] = text2.text[i - n];
    }

}

void Mystring::addChar(const char text2) {
    if(this!=nullptr){
        int n = getLength();
        if (n < size - 1) {
            text[n] = text2;
            text[n + 1] = '\0';
        }
        else {
            int Oldsize = size;
            setLength(size + 8);
            this->addChar(text2);
        }
    }

}

char Mystring::getByPosition(int position) const {
    if (position > getLength()) {
        return '\0';
    }
    return text[position];
}

bool Mystring::compare(const Mystring& text2) const {
    if (this != nullptr) {
        int n = 0;

        while (this->text[n] == text2.text[n]) {
            if (this->text[n] == '\0' || text2.text[n] == '\0')
                break;
            n++;
        }

        if (text2.text[n] == '\0' && this->text[n] == '\0')
            return true;
        else
            return false;
    }
    return false;


}

bool Mystring::compareChar(const char text2) const {
    if (this != nullptr && this->text != nullptr) {
        if (text[0] == text2) return true;
        else return false;
    }
    else return false;

}

//Print stuff
void const Mystring::Print(void) const {
    if (this != nullptr) {
        if (this->text != nullptr) {
            std::cout << this->text;

        }

    }
}


Mystring& Mystring::operator=(const Mystring& other) {
    if (this != &other) {
        delete[] this->text;
        this->size = other.size;
        this->text = new char[other.size];
        memcpy(this->text, other.text, other.size);
    }
    return *this;
}



//Destructor
Mystring::~Mystring() {
    if (this->text != nullptr) {
        delete[] this->text;
        this->text = nullptr;

    }
}