#ifndef ATTRIBUTE_H
#define ATTRIBUTE_H

#include <iostream>
#include "mystring.h"
#pragma once
class attribute
{
private:
	Mystring* Name = nullptr;
	Mystring* Value=nullptr;
	attribute* Next=nullptr;

public:
	//Constructor
	attribute();
	attribute(attribute* Next);
	attribute(Mystring& Name, Mystring& Value,attribute* Next);

	//Basic Operation on element
	attribute* const	GetNext(void) const;
	attribute* const	FindEnd(void);
	void const			ChangeNext(attribute* Next);
//	void const			ChangeValue(Mystring* Data);
//	void const			ChangeValue();
	Mystring* const		GetName(void) const;
	Mystring* const		GetValue(void) const;

	//Adding new Element
	void const			AddAttribute(Mystring& Name, Mystring& Value);

	//Delete Element	NAPRAWI !! BRAK USUNICIA DANYCH Z USUWANEJ KOMRKI
	void const			DelAttribute(int Number);

	// Find element by index Nymber
	attribute* const	FindElementByNum(int Numer);

	//Find element by Name
	attribute* const	FindElementByName(Mystring& Name);

//	attribute* const	FindAttributeByNameGetNum(Mystring& Name);
	
	//Count elements
	int const			CountElements(void);
	
	//Delete element by index number NAPRAWI !! BRAK USUNICIA DANYCH Z USUWANEJ KOMRKI
	//void const			DelAttributeByNumber(int Number);



	int const			FindNumOfAtr(Mystring& Name);

	//Print
	void const			Print(void) const;
	void const			PrintAll(void) ;

	~attribute();

};


#endif // !ATTRIBUTE_H



