#ifndef SECTION_H
#define SECTION_H
#pragma once
#include "attribute.h"
#include "selector.h"

class Section
{
private:
	attribute* headA=nullptr;
	selector* headS = nullptr;

public:
	//Constructor 
	Section();
			//ATTRIBUTE stuff
	//acces attribute 
	attribute* const	GetHeadA(void) const;
	attribute* const	GetAttributeByNum(int i) const;

	//add new attribute with value
	void const			AddAttribute(Mystring& Name, Mystring& Value) const;
	
	//Finde attribute by Name 
	attribute* const	FindAttribute(Mystring& Name) const;

	//Finde attribute by Name get Value
	Mystring* const		FindAttributeGetValue(Mystring& Name);

	Mystring* const		FindAttributeGetValuePrint(Mystring& Name);

	//Find element by Name Print all
	int const			FindAttributeByNameCount(Mystring& Name) const;

	//attribute count
	int const			CountAttribute(void);

	bool const			DelAttributeByNum(int Number);

//	int const	getValue(void) const;
//	void const	ChangeValue(int Value);


	void const			FreeHead(void);


	//Write in CSS mode
	void const			WriteSelector(char const znak);
	void const			WriteAttribute();
	bool const			WriteValue(Mystring& Name);


			//Selector Stuff
	selector* const		GetHeadS(void) const;
	selector* const		GetSelectorByNum(int i);

	//add new selector with val
	void const			AddSelector(Mystring& Name) const;

	//find selector by name
	selector* const		FindSelector(Mystring& Name) const;

	Section* const		FindSelectorToSection(Mystring& Name) ;
	

	//Find Count of Selecor with name in Sections
	int const			FindSelectorCount(Mystring& Name)const ;

	//find selector in one se
	selector* const		FindSelectorInOneSection(Mystring& Name)const;

	//attribute count
	int const			CountSelector(void);

	int const			FindNumOfAtr(Mystring& Name);

	//Find element by Name Print all
	void const			FindElementByNamePrintAll(Mystring& Name)const;

	//Delete by index
	void const			DelSelectorByNum(int Number);
			//PRINT ALL 
	void const			Print(void) const;
	void const			Print(int i) const;

	~Section();

};



#endif // !SECTION_H


