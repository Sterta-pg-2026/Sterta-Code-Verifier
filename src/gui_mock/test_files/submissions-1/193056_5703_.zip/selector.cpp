#include "selector.h"
#include <iostream>


//Constructor
selector::selector() : Next(nullptr) {
	this->Name = new Mystring();
};
selector::selector(Mystring& Name, selector* Next) : Next(Next) {
	this->Name = new Mystring(Name);

};
selector::selector(selector* Next) :Next(Next) {
	this->Name = new Mystring();
};

//Basic Operation on element
selector* const selector::GetNext(void) const {
	if (this == nullptr) return nullptr;
	return this->Next;
}

void const selector::ChangeNext(selector* Next) {
	this->Next = Next;
}

selector* const selector::FindEnd(void) {
	selector* dummy = this;
	while (dummy->Next != NULL)
	{
		dummy = dummy->Next;
	}
	return dummy;
}

Mystring* const selector::GetName(void) const {
	if (this != nullptr) return this->Name;
	else return nullptr;
}

//Adding new Element
// if head element is empty add val to head. not to next node
void const selector::AddSelector(Mystring& Name) {

	if (!this->Name->compareChar('\0'))
	{
		if (this->Next == nullptr) {
			selector* dummy = new selector(Name, nullptr);
			this->Next = dummy;
		}
		else
		{
			selector* dummy = new selector(Name, nullptr);
			(this->FindEnd())->Next = dummy;
		}
	}
	else {
		this->Name = &Name;
	}


 }

//Delete Element
void const selector::DelSelectorAfter(void) {
	selector* dummy = this->Next;
	this->Next = (this->Next)->Next;
	//delete dummy;
}

// Find element By Number FROM 1 not 0
selector* const selector::FindElementByNum(int Number) {
	selector* dummy = this;
	int i = 1;
	while (dummy != NULL)
	{
		if (i < Number) {
			if (dummy->Next != NULL) {
				dummy = dummy->Next;
			}
			else
			{
				dummy = nullptr;
				break;
			}
		}
		else if (i == Number) {
			return dummy;
		}
		i++;
	}
	return nullptr;
}

//Find element by Name if not return nullptr;
selector* const selector::FindElementByName(Mystring& Name) {
	if (this != nullptr) {
		if (this->Name->compare(Name)) {
			return(this);
		}
		else {
			return nullptr;
		}
	}
	else return nullptr;

}


// Count elements
int const selector::CountElements(void) {
	if (Name == nullptr) {
		return 0;
	}
	if (this->Name->compareChar('\0')) {
		return 0;
	}
	else {
		int i = 0;
		selector* dummy = this;
		while (dummy != nullptr)
		{
			dummy = dummy->Next;
			i++;
		}
		return i;
	}
}

//Delete element by index number
void const	selector::DelSelectorByNumber(int Number) {
	if (Number > 0) {
		(this->FindElementByNum(Number - 1))->DelSelectorAfter();
	}
	else if (Number == 0)
	{
		this->Next = this->Next->Next;
		//this->Next==this
	}
}


//Print
void const selector::Print(void) const {
	std::cout << "selector	Addres::" << this << std::endl;
	std::cout << "Name	";
	this->Name->Print();
	std::cout << std::endl;

}

void const selector::PrintAll(void) {
	selector* dummy = this;
	while (dummy != NULL)
	{
		dummy->Print();
		dummy = dummy->Next;
	}
}

selector::~selector() {
	delete this->Name;
}