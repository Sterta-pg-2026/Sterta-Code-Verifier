#include "maindll.h"
#include "section.h"
#include <iostream>

//Constructor
MainDLL::MainDLL() : Prev(nullptr), Next(nullptr), NumOfTaken(NULL){
	MainTab = new Section*[T];
	for (int i = 0; i < T; i++) {
		MainTab[i] = new Section();
		IsTaken[i] = false;
	}
};
MainDLL::MainDLL(MainDLL* Prev, MainDLL* Next){
	this->Prev = Prev;
	this->Next = Next;
	this->NumOfTaken = NULL;
	MainTab = new Section * [T];

	for (int i = 0; i < T; i++) {
		MainTab[i] = new Section();
		IsTaken[i] = false;
	}

};
MainDLL::MainDLL(int NumOfTaken,MainDLL* Prev, MainDLL* Next){
	this->Prev = Prev;
	this->Next = Next;
	this->NumOfTaken = NumOfTaken;
	MainTab = new Section * [T];

	for (int i = 0; i < T; i++) {
		MainTab[i] = new Section();
		IsTaken[i] = false;
	}

};


//Basic Operation element MainDLL
MainDLL* const MainDLL::MainDLLGetAddres(void) {
	return this;
}
MainDLL* const	MainDLL::GetPrev(void) const {
	return this->Prev;
}
MainDLL* const MainDLL::GetNext(void) const {
	return this->Next;
}
void const MainDLL::ChangeNext(MainDLL* Next) {
	this->Next = Next;
}
/*
void const MainDLL::ChangePrev(MainDLL* Prev) {
	this->Prev = Prev;
}*/
MainDLL* const MainDLL::FindEnd(){
	MainDLL* dummy = this;
	while (dummy->Next != nullptr) {
		dummy = dummy->Next;
	}
	return dummy;
}

//Setion Opertation
Section* const MainDLL::GetSectionByNumber(int i) {
	return this->MainTab[i];
}

/*
//Adding new element
void const MainDLL::AddMainDll() {
	if (this->Next == nullptr && this->Prev == nullptr) {
		MainDLL* dummyptr = MainDLLGetAddres();
		MainDLL* dummy = new MainDLL(dummyptr, nullptr);
		this->Next = dummy;
	}
else {
		MainDLL* dummyptr = FindEnd();
		MainDLL* dummy = new MainDLL(dummyptr, nullptr);
		dummyptr->Next = dummy;
	}
}

//Adding new Element for MainDLL getting Addres back
MainDLL* const MainDLL::AddMainDllA() {
	if (this->Next == nullptr && this->Prev == nullptr) {
		MainDLL* dummyptr = MainDLLGetAddres();
		MainDLL* dummy = new MainDLL(dummyptr, nullptr);
		this->Next = dummy;
		return(dummy);
	}
	else {
		MainDLL* dummyptr = FindEnd();
		MainDLL* dummy = new MainDLL(dummyptr, nullptr);
		dummyptr->Next = dummy;
		return(dummy);

	}


}
*/
//Removign last element
void const MainDLL::DellMainDll() {
	MainDLL* dummyptr = FindEnd();
	(dummyptr->Prev)->Next = nullptr;
}


//Operation on NumTaken
int const MainDLL::GetNumOfTaken() const {
	return NumOfTaken;
}
/*
void const MainDLL::AddNumOfTaken() {
	this->NumOfTaken += 1;
}*/
void const MainDLL::DellNumOfTaken() {
	this->NumOfTaken -= 1;
}

/*
//Is Node Free to add new Section 
bool const MainDLL::CanAddMoreSection(void) const {
	if (NumOfTaken == T) return false;
	else return true;
}*/

//Find Free node
int const MainDLL::FindFreeSection(MainDLL* dummy) {
	
	if (dummy->IsTaken[T - 1]) { return T; }
	for (int i = T - 1; i > 0; i--)
	{
		if (dummy->IsTaken[i - 1]) {
			return i;
		}
	}
	return 0;

}

//Find free Section
MainDLL* const MainDLL::FindLastNode(void) {
	MainDLL* dummy = this;
	while (dummy->Next != nullptr) {
		dummy = dummy->Next;
	}
	return dummy;

}

// MODES

void const	MainDLL::ConsoleMode() {
	char znak ='c';
	
	while (znak != EOF && !(znak < 32 || znak > 126)) {
		znak=WriteMode();
		if (znak == EOF && (znak < 32 || znak > 126)) break;
		znak=ComendMode();
	}

}


char const MainDLL::WriteMode() {
	char znak = NULL;
	znak = CheckIfEndOfWriteMode();
	while (znak!='?' && znak !=EOF && !(znak < 32 || znak > 126)) {
		FillNewNode(znak);
		znak = CheckIfEndOfWriteMode();
	}


	return znak;
}

char const MainDLL::CheckIfEndOfWriteMode() {

	char znak = NULL;
	znak = getchar();
	while (znak < 32 || znak > 126) {
		znak = getchar();
	}

	if (znak == '?') {
		for (int i = 0; i < 3; i++)
		{
			znak = getchar();
			if (znak == EOF && (znak < 32 || znak > 126)) {
				return EOF;
			}
		}
		return znak;
	}
	else {
		return znak;
	}

}

char const MainDLL::ComendMode() {
	char znak = NULL;
	znak = CheckIfEndOfComendMode();
	while (znak != '*' && znak !=EOF && !(znak < 32 || znak > 126)) {
		znak=RecogniseComend(znak);
		znak = CheckIfEndOfComendMode();
	}

	return znak;
}

char const MainDLL::CheckIfEndOfComendMode() {
	char znak = NULL;
	znak = getchar();
	if (znak == EOF && (znak < 32 || znak > 126)) return EOF;
	while (znak == ' ' || znak == '\t' || znak == '\n') {
		znak = getchar();
		if (znak == EOF && (znak < 32 || znak > 126)) {
			return EOF;
		}
	}
	if (znak == '*') {
		for (int i = 0; i < 3; i++)
		{
			znak = getchar();
			if (znak == EOF && (znak < 32 || znak > 126)) {
				return EOF;
			}
		}
		return znak;
	}
	else {
		return znak;
	}

}

char const MainDLL::RecogniseComend(char Firstznak) {
	int number = NULL;
	int number2 = NULL;
	Mystring* nazwa = nullptr;
	Mystring* komenda = nullptr;
	char znak = 'a';
	//std::cout << Firstznak;

	if ((znak < 32 || znak > 126)) return EOF;

	if (Firstznak == '?') {
		std::cout << "? == " << CountNumSectionCSS()<<std::endl;
	}
	else if (Firstznak >= '0' && Firstznak <= '9') {
		number = GetComendNum(Firstznak);
	}
	else {
		nazwa = GetFirstPartComendString(Firstznak);
	}

	znak = getchar();
	if ((znak < 32 || znak > 126)) return EOF;

	if (znak == 'S') {
		znak = getchar();
		znak = getchar();
		if (number != NULL) {
			if (znak == '?') {
				int dummyint = GetSectionByNum(number)->CountSelector();
				if (dummyint != -1) {
					if (GetSectionByNum(number) != nullptr) {
						if (!GetSectionByNum(number)->GetHeadS()->GetName()->compareChar(' ')) {
							if (dummyint >= 0) {
								std::cout << number << ",S,? == " << dummyint << std::endl;
							}
						}
						else {
							std::cout << number << ",S,? == " << 0 << std::endl;
						}
					}
				}
				


			}
			else {
				number2 = GetComendNumSec(znak,&znak);
				Section* dummy = GetSectionByNum(number);
				if (dummy != nullptr) {
					selector* dummys = dummy->GetSelectorByNum(number2);
					if (dummys != nullptr) {
						if (!dummys->GetName()->compareChar(' ') && !dummys->GetName()->compareChar(NULL) ){
							std::cout << number << ",S," << number2 << " == ";
							dummys->GetName()->Print();
							std::cout << std::endl;
						}



					}

				}

			}
		}
		else {
			if ((znak < 32 || znak > 126)) return EOF;

			if (znak == '?') {
				if (nazwa != nullptr) {
					nazwa->Print();
					std::cout << ",S,? == ";
					if (this != nullptr) {
						CountNumSelector(nazwa);

					}
				}

			}

		}

	}
	else if (znak == 'A') {
		if ((znak < 32 || znak > 126)) return EOF;

		znak = getchar();
		znak = getchar();
		if (number != NULL) {
			if (znak == '?') {
				int dummyint = GetSectionByNum(number)->CountAttribute();
				if (dummyint >= 0) {
					std::cout << number << ",A,? == " << dummyint << std::endl;

				}
			}
			else {
				nazwa = GetSecPartComendString(znak,&znak);
				Mystring* n= GetSectionByNum(number)->FindAttributeGetValuePrint(*nazwa);
				if (n != nullptr) {
					std::cout << number << ",A,";
					nazwa->Print();
					std::cout << " == ";
					n->Print();
					std::cout << std::endl;
				}

			}
		}
		else {
			if ((znak < 32 || znak > 126)) return EOF;
			if(znak=='?')
			{
				if (nazwa != nullptr) {
					nazwa->Print();
					std::cout << ",A,? == ";
					if (this != nullptr) {

					CountNumAttribute(nazwa);
					}
				}
			}

		}
	}

	else if (znak == 'E') {
		if ((znak < 32 || znak > 126)) return EOF;

		znak = getchar();
		znak = getchar();
		if ((znak < 32 || znak > 126)) return EOF;

		if (nazwa != nullptr) {
			Section* text = nullptr;
			text =GetLastSelectorByName(*nazwa);
			if (text != nullptr) {
				Mystring* nazwa2 = nullptr;
				nazwa2 = GetSecPartComendString(znak,&znak);
				Mystring* test= text->FindAttributeGetValuePrint(*nazwa2);
				if (test != nullptr) {
					nazwa->Print();
					std::cout << ",E,";
					nazwa2->Print();
					std::cout << " == ";
					test->Print();
					std::cout << std::endl;
				}
				

			}
			else {
				while (znak != '\n' && znak != EOF )
				{
					znak = getchar();

				}
			}
			
		}
		
	}
	else if (znak == 'D') {
		znak = getchar();
		znak = getchar();
		if (znak == '*') {
			MainDLL* node;
			int i;
			Section* dummy = GetSectionByNum(number, &node, &i);
			if (dummy != nullptr) {
				node->IsTaken[i] = false;
				node->NumOfTaken--;
				delete dummy;
				node->MainTab[i] = new Section();
				std::cout << number << ",D,* == deleted" << std::endl;
			}

		}
		else {
			if ((znak < 32 || znak > 126)) return EOF;

			Mystring* nazwa2 = nullptr;
			nazwa2 = GetSecPartComendString(znak,&znak);
			Section* dummySEC = nullptr;
//			attribute* dummyATR = nullptr;
			int i = NULL;
			bool status=NULL;
			dummySEC = this->GetSectionByNum(number);
			i = dummySEC->FindNumOfAtr(*nazwa2);
			if (i != -1) {
				status = dummySEC->DelAttributeByNum(i);
				if (status) {
					//int i = FindNumOfAtr();
					if (dummySEC->CountAttribute() == 0) {
						MainDLL* node;
						int i;
						Section* dummy = GetSectionByNum(number, &node, &i);

						node->IsTaken[i] = false;
						node->NumOfTaken--;
						delete dummy;
						node->MainTab[i] = new Section();
					}

					std::cout << number << ",D,";
					nazwa2->Print();
					std::cout << " == deleted" << std::endl;
				}
			}



		}
	}
	else {
	if ((znak < 32 || znak > 126)) return EOF;

		while (znak !='\n' && znak!=EOF && !(znak < 32 || znak > 126))
		{
			znak = getchar();

		}
	}
	if ((znak < 32 || znak > 126)) return EOF;

	if (znak == EOF && (znak < 32 || znak > 126)) {
			return EOF;
		}
		
	if ((znak < 32 || znak > 126)) return EOF;

	return '\0';

	
}

int const MainDLL::GetComendNum(char Firstznak) {
	char znak = NULL;
	znak = Firstznak;
	char buffor[6]={NULL};
	int n = 0;
	while (znak != ',')
	{
		buffor[n] = znak;
		buffor[n + 1] = '\0';
		znak = getchar();
		while (znak == ' ' || znak == '\t' || znak == '\n') {
			znak = getchar();
		}

		n++;
	}
	return(NumberPart(buffor));
}

int const MainDLL::GetComendNumSec(char Firstznak,char* oldznak) {
	char znak = NULL;
	znak = Firstznak;
	char buffor[6] = { NULL };
	int n = 0;
	while (znak != '\n' && znak != EOF && znak != '\t' && !(znak < 32 && znak > 126))
	{
		buffor[n] = znak;
		buffor[n + 1] = '\0';
		znak = getchar();
		n++;

	}
	if (oldznak != nullptr) {
		*oldznak = znak;
	}
	return(NumberPart(buffor));
}

Mystring* const MainDLL::GetFirstPartComendString(char Firstznak) {
	char znak = NULL;
	znak = Firstznak;
	Mystring* nazwa = new Mystring();
	while (znak != ',') {
		nazwa->addChar(znak);
		znak = getchar();
		if (znak == '\n' || znak == '\t') znak = getchar();

	}
	if ((znak < 32 || znak > 126)) return nullptr;

	return nazwa;
}

Mystring* const MainDLL::GetSecPartComendString(char Firstznak,char* oldznak) {
	char znak = NULL;
	znak = Firstznak;
	Mystring* nazwa = new Mystring();
	while (znak != '\n' && znak!=EOF && znak!='\t' && !(znak < 32 || znak > 126)) {
		nazwa->addChar(znak);
		znak = getchar();

	}
	if (oldznak != nullptr) {
		*oldznak = znak;
	}
	return nazwa;
}

int const MainDLL::NumberPart(char* const buffor) {
	int num = 0;
	for (int x = 0; buffor[x] != '\0'; x++)
		num = num * 10 + buffor[x] - '0';
	return num;
}


void const MainDLL::FillNewNode(char znak) {
	MainDLL* dummy = FindLastNode();
	if (dummy == nullptr) {
		return;
	}
	int i = dummy->FindFreeSection(dummy);
	if (i >= T) {
		dummy->Next = new MainDLL;
		dummy = dummy->Next;
		i = 0;
	}
	dummy->MainTab[i]->WriteSelector(znak);
	dummy->MainTab[i]->WriteAttribute();
	dummy->IsTaken[i] = true;
	dummy->NumOfTaken++;

}


void const MainDLL::CountNumSelector(Mystring* NameS) {
//	std::cout << "CountNumSelector acces" << std::endl;
	if (this != nullptr) {
//S		std::cout << "this addres " << this << std::endl;

		int index = 0;
		int n = 0;
		MainDLL* dummy = this;
		while (dummy != nullptr) {
			for (int index = 0; index < T; index++)
			{
				if (dummy->IsTaken[index]) {
					//std::cout << "index of MainTab[index]" << index << std::endl;
					//std::cout << "MainTab[index] addres" << dummy->MainTab[index] << std::endl;
					n += dummy->MainTab[index]->FindSelectorCount(*NameS);
				}
			}

			dummy = dummy->Next;
		}
		std::cout << n << std::endl;
	}

}

void const MainDLL::CountNumAttribute(Mystring* NameA) {
//	std::cout << "CountNumAttribute acces" << std::endl;
	if (this != nullptr) {
	//	std::cout << "this addres " << this << std::endl;

		int index = 0;
		int n = 0;
		MainDLL* dummy = this;
		while (dummy != nullptr) {

			for (int index = 0; index < T; index++)
			{
				if (dummy->IsTaken[index]) {
					n += dummy->MainTab[index]->FindAttributeByNameCount(*NameA);
				}
			}
			dummy = dummy->Next;

		}
		std::cout << n << std::endl;

	}

}

int const MainDLL::CountNumSectionCSS() {
	int n = 0;
	MainDLL* dummy = this;
	while (dummy != nullptr) {
		for (int i = 0; i < T; i++)
		{
			if (dummy->IsTaken[i]) n++;
		}
		dummy = dummy->Next;
	}
	return n;

}

void const MainDLL::FreeSection(int number) {
	int num = number - 1;
	MainDLL* dummy = this;
	int n = 0;
	while (n < num)
	{
		if (n > dummy->NumOfTaken) {
			dummy->Next;
		}
		if (dummy->NumOfTaken < num) {
			dummy->Next;
			n += dummy->NumOfTaken;
		}

		if (dummy->IsTaken[n]) n++;

	}
	dummy->IsTaken[n] = false;
	dummy->NumOfTaken--;
}

Section* const MainDLL::GetSectionByNum(int number, MainDLL** ptrToChange, int* oldi) {
	if (number <= 0) return nullptr;
	MainDLL* dummy = this;
	while (dummy != nullptr)
	{
		for (int i = 0; i < T; i++)
		{
			if (dummy->IsTaken[i]) { number--; }
			if (number == 0) {
				if (ptrToChange != nullptr) *ptrToChange = dummy;
				if (oldi != nullptr) *oldi = i;
				return	dummy->MainTab[i];
			}
		}
		dummy = dummy->Next;

	}
	return nullptr;

}

void const		MainDLL::SectionDEL(int number) {
	MainDLL* node;
	int i;
	Section* dummy = GetSectionByNum(number, &node, &i);
	node->IsTaken[i] = false;
	node->NumOfTaken--;
	delete dummy;
	dummy = nullptr;
	dummy = new Section();

}

Section* const MainDLL::GetLastSelectorByName(Mystring& NameS) {
	MainDLL* dummy = this;
	Section* dummySection = nullptr;
	Section* dummySectionLast = nullptr;
	int n = 0;
	while (dummy != nullptr) {

		if (dummy->IsTaken[n]) {
			dummySection = dummy->MainTab[n]->FindSelectorToSection(NameS);
			if (dummySection != nullptr) {
				dummySectionLast = dummySection;
			}
		}
		n++;
		if (!(n < T)) {
			dummy = dummy->Next;
			n = 0;
		}


	}

	if (dummySection != nullptr) return dummySection;
	if (dummySectionLast != nullptr) return dummySectionLast;
	else return(nullptr);
}

//Testing functions 
// 
//Print stuff
void const	MainDLL::Print() const {
	std::cout <<std::endl <<"		Header for Element: " << this	<< std::endl;
	std::cout << "Number of taken in array:	" << this->NumOfTaken	<< std::endl;
	std::cout << "taken Table:	";
	for (int i = 0; i < T; i++) std::cout << IsTaken[i] << " ";
	std::cout << std::endl;
	for (int i = 0; i < T; i++) this->MainTab[i]->Print(i);
	std::cout << "Memory Addres of Prev Element:	" << this->Prev << std::endl;
	std::cout << "Memory Addres of Next Element:	" << this->Next << std::endl;

}
void const	MainDLL::PrintMainDLL() const {
	MainDLL* dummy = new MainDLL(this->NumOfTaken, this->Prev, this->Next);
	while (dummy != nullptr) {
		dummy->Print();
		dummy = dummy->Next;
	}
}

MainDLL::~MainDLL() {
	for (int i = 0; i < T; i++)
	{
		delete MainTab[i];
	}
	delete[] MainTab;
}