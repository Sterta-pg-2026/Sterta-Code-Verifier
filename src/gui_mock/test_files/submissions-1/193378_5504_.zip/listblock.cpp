#include "listblock.h"


DoublyLinkedListBlock::DoublyLinkedListBlock() : head(nullptr), tail(nullptr), count(0) {}


DoublyLinkedListBlock::~DoublyLinkedListBlock() {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}


void DoublyLinkedListBlock::push_front(const block& value) {
    Node* newNode = new Node(value);
    if (!head) {
        tail = newNode;
    }
    else {
        head->prev = newNode;
    }
    newNode->next = head;
    head = newNode;
    count++;
}


void DoublyLinkedListBlock::push_back(const block& value) {
    Node* newNode = new Node(value);
    if (!tail) {
        head = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
    }
    tail = newNode;
    count++;


    for (int i = 0; i < T; i++) {
        const section& src_section = value.sekcje[i];
        section& dest_section = newNode->value.sekcje[i];

        dest_section.selectors = src_section.selectors;

        dest_section.attributes = src_section.attributes;
    }
}





block& DoublyLinkedListBlock::operator[](int index) {
  
    Node* current = head;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }
    return current->value;
}


int DoublyLinkedListBlock::size() const {
    return count;
}

void DoublyLinkedListBlock::remove(int index) {
    if (index < 0 || index >= count) {

        return;
    }
    Node* nodeToDelete;
    if (index == 0) {

        nodeToDelete = head;
        head = head->next;
        if (head != nullptr) {
            head->prev = nullptr;
        }
        else {
            tail = nullptr;
        }
    }
    else if (index == count - 1) {

        nodeToDelete = tail;
        tail = tail->prev;
        if (tail != nullptr) {
            tail->next = nullptr;
        }
        else {
            head = nullptr;
        }
    }
    else {

        Node* nodeBefore = head;
        for (int i = 0; i < index - 1; i++) {
            nodeBefore = nodeBefore->next;
        }
        nodeToDelete = nodeBefore->next;
        nodeBefore->next = nodeToDelete->next;
        nodeToDelete->next->prev = nodeBefore;
    }
    delete nodeToDelete;
    count--;
}
void DoublyLinkedListBlock::remove_section(int blockIndex, int sectionIndex) {
    if (blockIndex < 0 || blockIndex >= count) {
        return;
    }


    Node* blockNode = head;
    for (int i = 0; i < blockIndex; i++) {
        blockNode = blockNode->next;
    }

    block& blockToRemove = blockNode->value;
    if (sectionIndex < 0 || sectionIndex >= blockToRemove.count) {
        return;
    }
    for (int i = sectionIndex; i < blockToRemove.count - 1; i++) {
        blockToRemove.sekcje[i] = blockToRemove.sekcje[i + 1];
    }
    blockToRemove.count--;


    if (blockToRemove.count == 0) {
        if (blockNode == head) {
            head = blockNode->next;
            if (head != nullptr) {
                head->prev = nullptr;
            }
        }
        else if (blockNode == tail) {
            tail = blockNode->prev;
            if (tail != nullptr) {
                tail->next = nullptr;
            }
        }
        else {
            blockNode->prev->next = blockNode->next;
            blockNode->next->prev = blockNode->prev;
        }
        delete blockNode;
        count--;
    }
}