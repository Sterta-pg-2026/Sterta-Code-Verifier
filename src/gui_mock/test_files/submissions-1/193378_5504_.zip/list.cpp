#include "list.h"
#include <stdexcept>

DoublyLinkedList::DoublyLinkedList() {
    data = nullptr;
    data_size = 0;
    capacity = 0;
    head = nullptr;
    tail = nullptr;
    count = 0;
}

DoublyLinkedList::~DoublyLinkedList() {

}
DoublyLinkedList::DoublyLinkedList(const DoublyLinkedList& other) {
    data = new String[other.capacity];
    data_size = other.data_size;
    capacity = other.capacity;
    count = 0;
    head = nullptr;
    tail = nullptr;
    Node* other_node = other.head;
    while (other_node != nullptr) {
        push_back(other.data[other_node->index]);
        other_node = other_node->next;
    }
}
void DoublyLinkedList::push_front(const String& value) {
    if (empty()) {
        data = new String[1];
        data[0] = value;
        data_size = 1;
        capacity = 1;
        head = new Node{ 0, nullptr, nullptr };
        tail = head;
        count = 1;
    }
    else {
        if (data_size == capacity) {
            String* new_data = new String[capacity * 2];
            for (int i = 0; i < data_size; i++) {
                new_data[i + 1] = data[i];
            }
            delete[] data;
            data = new_data;
            capacity *= 2;
        }
        for (Node* curr = head; curr != nullptr; curr = curr->next) {
            curr->index++;
        }
        data[0] = value;
        data_size++;
        Node* new_head = new Node{ 0, head, nullptr };
        head->prev = new_head;
        head = new_head;
        count++;
    }
}

void DoublyLinkedList::push_back(const String& value) {
    if (empty()) {
        data = new String[1];
        data[0] = value;
        data_size = 1;
        capacity = 1;
        head = new Node{ 0, nullptr, nullptr };
        tail = head;
        count = 1;
    }
    else {
        if (data_size == capacity) {
            String* new_data = new String[capacity * 2];
            for (int i = 0; i < data_size; i++) {
                new_data[i] = data[i];
            }
            delete[] data;
            data = new_data;
            capacity *= 2;
        }
        data[data_size] = value;
        data_size++;
        Node* new_tail = new Node{ data_size - 1, nullptr, tail };
        if (tail == nullptr) {
            head = new_tail;
            tail = new_tail;
        }
        else {
            tail->next = new_tail;
            tail = new_tail;
        }
        count++;
    }
}

void DoublyLinkedList::clear_element(int index) {
    Node* current = head;
    while (current != nullptr && current->index != index) {
        current = current->next;
    }
    if (current != nullptr) {

        data[index].clear();

        for (int i = index + 1; i < data_size; i++) {
            data[i - 1] = data[i];
        }

        data[data_size - 1].clear();

        if (current == head) {
            head = current->next;
        }
        else {
            current->prev->next = current->next;
        }
        if (current == tail) {
            tail = current->prev;
        }
        else {
            current->next->prev = current->prev;
        }
        Node* temp = current->next;
        while (temp != nullptr) {
            temp->index--;
            temp = temp->next;
        }
        delete current;
        data_size--;
        count--;
    }
}
String& DoublyLinkedList::operator[](int index) {
    return data[index];
}

int DoublyLinkedList::size() const {
    return data_size;
}

bool DoublyLinkedList::empty() const {
    return data_size == 0;
}


void DoublyLinkedList::clear() {
    Node* current = head;
    while (current != nullptr) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }
    head = nullptr;
    tail = nullptr;
    data_size = 0;
    capacity = 0;
    count = 0;
}