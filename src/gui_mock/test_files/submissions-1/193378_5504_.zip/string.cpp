#define _CRT_SECURE_NO_WARNINGS
#include "string.h"

String::String() {
    data = new char[1];
    data[0] = '\0';
    size = 0;
}

String::String(const char* cstring) {
    size = strlen(cstring);
    data = new char[size + 1];
    strcpy(data, cstring);
}

String::String(const String& other) {
    size = other.size;
    data = new char[size + 1];
    strcpy(data, other.data);
}

String::~String() {
    delete[] data;
}

String& String::operator=(const String& other) {
    if (this != &other) {
        delete[] data;
        size = other.size;
        data = new char[size + 1];
        strcpy(data, other.data);
    }
    return *this;
}

String String::operator+(const String& other) const {
    String newString;
    newString.size = size + other.size;
    newString.data = new char[newString.size + 1];
    strcpy(newString.data, data);
    strcat(newString.data, other.data);
    return newString;
}
std::istream& operator>>(std::istream& input, String& str) {
    char buffer[256];
    input >> buffer;
    str = buffer;
    return input;
}
std::ostream& operator<<(std::ostream& output, const String& str) {
    output << str.c_str();
    return output;
}
bool operator==(const String& str1, const String& str2) {
    if (str1.size != str2.size) {
        return false;
    }
    return std::strcmp(str1.data, str2.data) == 0;
}

int String::length() const {
    return size;
}

char String::operator[](int i) const {
    return data[i];
}

char& String::operator[](int i) {
    return data[i];
}

const char* String::c_str() const {
    return data;
}
String String::operator+(const char c) const {
    char* new_data = new char[size + 2];
    std::strcpy(new_data, data);
    new_data[size] = c;
    new_data[size + 1] = '\0';
    String result(new_data);
    delete[] new_data;
    return result;
}
void String::clear() {
    delete[] data;
    data = nullptr;
    size = 0;
}