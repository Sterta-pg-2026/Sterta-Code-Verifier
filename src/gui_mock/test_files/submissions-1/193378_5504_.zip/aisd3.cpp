#include <iostream>
#include <algorithm>
#include "string.h"
#include "list.h"
#include "listblock.h"

using namespace std;


struct Fragmenty {
    String first;
    String second;
    String third;
};

struct attr {
    String nazwa;
    String value;
};

void readInput(DoublyLinkedListBlock& blocks, int index) {
    DoublyLinkedList attribtmp, selectmp;
    String word, tmp, komenda;
    section sekcja;
    block blok;
    String duplikat, zamieniacz, zamiennytmp;
    int opcja = 0;
    int mozna = 0;
    int wczytywanie = 0;
    while (cin >> word) {
        if (wczytywanie == 0 && index != 0) {
            for (int k = 0; k < blocks[blocks.size() - 1].count; k++) {
                for (int i = 0; i < blocks[blocks.size() - 1].sekcje[k].attributes.size(); i++) {
                    blok.sekcje[k].attributes.push_back(blocks[blocks.size() - 1].sekcje[k].attributes[i]);
                }
                for (int i = 0; i < blocks[blocks.size() - 1].sekcje[k].selectors.size(); i++) {
                    blok.sekcje[k].selectors.push_back(blocks[blocks.size() - 1].sekcje[k].selectors[i]);
                }
                blok.count++;
            }
            blocks.remove(blocks.size() - 1);
            wczytywanie = 1;
        }
        if (word == "????") {
            blocks.push_back(block(blok));
            break;
        }

        for (int k = 0; k < word.length(); k++) {
            if (word[k] == '{') {
                mozna = 1;
                opcja = 1;

                selectmp.push_back(tmp);
                tmp = "";
            }
            else if (word[k] == ';') {
                mozna = 1;
                opcja = 1;
                for (int g = 0; g < tmp.length(); g++) {

                    if (tmp[g] == ':') {
                        break;
                    }
                    else {

                        zamiennytmp = zamiennytmp + tmp[g];
                    }


                }
                for (int f = 0; f < attribtmp.size(); f++) {
                    duplikat = attribtmp[f];
                    for (int g = 0; g < duplikat.length(); g++) {

                        if (duplikat[g] == ':') {
                            break;
                        }
                        else {
                            zamieniacz = zamieniacz + duplikat[g];

                        }


                    }

                    if (zamieniacz == zamiennytmp) {

                        attribtmp.clear_element(f);
                    }
                    zamieniacz = "";
                }
                zamiennytmp = "";
                attribtmp.push_back(tmp);
                tmp = "";
            }
            else if (word[k] == '}') {
                opcja = 0;
                mozna = 1;
                blok.sekcje[blok.count].attributes.clear();
                for (int i = 0; i < attribtmp.size(); i++) {
                    blok.sekcje[blok.count].attributes.push_back(attribtmp[i]);
                }

                blok.sekcje[blok.count].selectors.clear();
                for (int i = 0; i < selectmp.size(); i++) {
                    blok.sekcje[blok.count].selectors.push_back(selectmp[i]);
                }
                attribtmp.clear();
                selectmp.clear();

                blok.count++;
                if (blok.count == T) {
                    blocks.push_back(block(blok));
                    for (int z = 0; z < T; z++) {
                        blok.sekcje[z].selectors.clear();
                        blok.sekcje[z].attributes.clear();
                    }
                    blok.count = 0;
                }

                tmp = "";
            }
            else if (word[k] == ',' && opcja != 1) {
                mozna = 1;
                selectmp.push_back(tmp);
                tmp = "";
            }
            else if (word[k] == ',' && opcja == 1) {
                tmp = tmp + ",";
                mozna = 0;
            }
            else {
                mozna = 0;
                tmp = tmp + word[k];
            }
            if (mozna == 0 && k == word.length() - 1) {
                tmp = tmp + " ";
            }
        }

    }

}
Fragmenty PodzielKomende(String komenda) {
    String first, second, third;
    Fragmenty final;
    int czesc = 0;
    for (int k = 0; k < komenda.length(); k++) {
        if (komenda[k] == ',') {
            if (czesc == 0) {
                czesc = 1;
                k++;
            }
            else if (czesc == 1) {
                czesc = 2;
                k++;
            }
        }
        if (czesc == 0) {
            first = first + komenda[k];
        }
        else if (czesc == 1) {
            second = second + komenda[k];
        }
        else if (czesc == 2) {
            third = third + komenda[k];
        }
    }
    final.first = first;
    final.second = second;
    final.third = third;
    return final;
}
int Sprawdzliczbe(String fragment) {
    for (int k = 0; k < fragment.length(); k++) {
        if (isdigit(fragment[k]) == 0) {
            return 0;
        }
        else if (isdigit(fragment[k]) != 0 && k == fragment.length() - 1) {
            return 1;
        }
    }
    return 0;
}
String szukaj(DoublyLinkedListBlock& blocks, int index1, int index2, String szukana) {
    String nazwa, wartosc, tmp;
    int opcja = 0;

    for (int k = 0; k < blocks[index1].sekcje[index2 - 1].attributes.size(); k++) {

        tmp = blocks[index1].sekcje[index2 - 1].attributes[k];

        for (int g = 0; g < tmp.length(); g++) {
            if (tmp[g] != ':' && opcja == 0) {
                nazwa = nazwa + tmp[g];

            }
            else if (tmp[g] != ':' && opcja == 1) {
                wartosc = wartosc + tmp[g];

            }
            else if (tmp[g] == ':' && opcja == 0) {
                opcja = 1;
            }

        }
        opcja = 0;
        if (szukana == nazwa || szukana + " " == nazwa) {
            return wartosc;
        }
        else if (szukana[0] != nazwa[0] && k == blocks[index1].sekcje[index2 - 1].attributes.size() - 1) {
            return "";
        }

        wartosc = "";
        nazwa = "";
    }
    return "";
}
void usunsekcje(DoublyLinkedListBlock& blocks, int index1, int index2) {
    blocks.remove_section(index1, index2 - 1);
}
void usun(DoublyLinkedListBlock& blocks, int index1, int index2, String szukana,String komenda) {
    String nazwa, wartosc, tmp;
    int opcja = 0;

    for (int k = 0; k < blocks[index1].sekcje[index2 - 1].attributes.size(); k++) {
        tmp = blocks[index1].sekcje[index2 - 1].attributes[k];
        for (int g = 0; g < tmp.length(); g++) {
            if (tmp[g] != ':' && opcja == 0) {
                nazwa = nazwa + tmp[g];

            }
            else if (tmp[g] != ':' && opcja == 1) {
                wartosc = wartosc + tmp[g];

            }
            else if (tmp[g] == ':' && opcja == 0) {
                opcja = 1;
            }

        }
        opcja = 0;
        if (szukana == nazwa || szukana + " " == nazwa) {
            blocks[index1].sekcje[index2 - 1].attributes.clear_element(k);
            cout << komenda << " == " << "deleted" << endl;
            if (blocks[index1].sekcje[index2 - 1].attributes.size() == 0) {
                blocks.remove_section(index1, index2 - 1);
            }
        }

        wartosc = "";
        nazwa = "";
    }
}
int liczbawystapienatt(DoublyLinkedListBlock& blocks, String szukana) {
    String nazwa, wartosc, tmp;
    int opcja = 0;
    int ilosc = 0;
    for (int k = 0; k < blocks.size(); k++) {
        for (int i = 0; i < blocks[k].count; i++) {
            for (int z = 0; z < blocks[k].sekcje[i].attributes.size(); z++) {
                tmp = blocks[k].sekcje[i].attributes[z];
                for (int g = 0; g < tmp.length(); g++) {
                    if (tmp[g] != ':' && opcja == 0) {
                        nazwa = nazwa + tmp[g];

                    }
                    else if (tmp[g] != ':' && opcja == 1) {
                        wartosc = wartosc + tmp[g];

                    }
                    else if (tmp[g] == ':' && opcja == 0) {
                        opcja = 1;
                    }

                }
                opcja = 0;
                if (szukana == nazwa || szukana + " " == nazwa) {
                    ilosc++;
                    z = blocks[k].sekcje[i].attributes.size();

                }

                wartosc = "";
                nazwa = "";

            }

        }
    }
    return ilosc;
}

int liczbawystapiensel(DoublyLinkedListBlock& blocks, String szukana) {
    String nazwa, wartosc, tmp;
    int opcja = 0;
    int ilosc = 0;
    for (int k = 0; k < blocks.size(); k++) {
        for (int i = 0; i < blocks[k].count; i++) {
            for (int z = 0; z < blocks[k].sekcje[i].selectors.size(); z++) {
                tmp = blocks[k].sekcje[i].selectors[z];
                for (int g = 0; g < tmp.length(); g++) {
                    if (tmp[g] != ':' && opcja == 0) {
                        nazwa = nazwa + tmp[g];

                    }
                    else if (tmp[g] != ':' && opcja == 1) {
                        wartosc = wartosc + tmp[g];

                    }
                    else if (tmp[g] == ':' && opcja == 0) {
                        opcja = 1;
                    }

                }
                opcja = 0;
                if (szukana == nazwa || szukana + " " == nazwa) {
                    ilosc++;
                    z = blocks[k].sekcje[i].selectors.size();

                }

                wartosc = "";
                nazwa = "";

            }

        }
    }
    return ilosc;
}
String szukajwartosci(DoublyLinkedListBlock& blocks, String selektor, String atrybut) {
    String nazwa, nazwa2, wartosc, wartosc2, tmp, tmp2;
    int opcja = 0;
    int ilosc = 0;
    for (int k = blocks.size() - 1; k >= 0; k--) {
        for (int i = blocks[k].count - 1; i >= 0; i--) {
            for (int z = blocks[k].sekcje[i].selectors.size() - 1; z >= 0; z--) {
                tmp = blocks[k].sekcje[i].selectors[z];
                for (int g = 0; g < tmp.length(); g++) {
                    if (tmp[g] != ':' && opcja == 0) {
                        nazwa = nazwa + tmp[g];

                    }
                    else if (tmp[g] != ':' && opcja == 1) {
                        wartosc = wartosc + tmp[g];

                    }
                    else if (tmp[g] == ':' && opcja == 0) {
                        opcja = 1;
                    }

                }
                opcja = 0;
                if (selektor == nazwa || selektor + " " == nazwa) {
                    for (int p = blocks[k].sekcje[i].attributes.size() - 1; p >= 0; p--) {
                        tmp2 = blocks[k].sekcje[i].attributes[p];
                        for (int g = 0; g < tmp2.length(); g++) {
                            if (tmp2[g] != ':' && opcja == 0) {
                                nazwa2 = nazwa2 + tmp2[g];

                            }
                            else if (tmp2[g] != ':' && opcja == 1) {
                                wartosc2 = wartosc2 + tmp2[g];

                            }
                            else if (tmp2[g] == ':' && opcja == 0) {
                                opcja = 1;
                            }

                        }
                        opcja = 0;
                        if (atrybut == nazwa2 || atrybut + " " == nazwa2) {
                            return wartosc2;
                        }

                        wartosc2 = "";
                        nazwa2 = "";

                    }

                }

                wartosc = "";
                nazwa = "";

            }

        }
    }
    return "";
}

int main() {
    DoublyLinkedList attribtmp, selectmp;
    String word, tmp, komenda;
    DoublyLinkedListBlock blocks;
    section sekcja;
    block blok;
    Fragmenty PodzielKomenda;
    int index1 = 0;
    int index2 = 0;

    readInput(blocks, 0);

    while (cin >> komenda) {

        if (komenda == "****") {
            readInput(blocks, 1);
        }

        else if (komenda == "?") {
            int z = 0;
            for (int p = 0; p < blocks.size(); p++) {
                z += blocks[p].count;
            }
            cout << komenda << " == " << z << endl;
        }

        else {

            PodzielKomenda = PodzielKomende(komenda);
            //i,S,?
            if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "S" && PodzielKomenda.third == "?") {
                int z = atoi(PodzielKomenda.first.c_str());

                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }

                if (z <= (blocks.size() - 1) * T + blocks[blocks.size() - 1].count) {
                    cout << komenda << " == " << blocks[index1].sekcje[index2 - 1].selectors.size() << endl;
                }
            }
            //i,A,?
            else if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "A" && PodzielKomenda.third == "?") {
                int z = atoi(PodzielKomenda.first.c_str());

                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }

                if (z <= (blocks.size() - 1) * T + blocks[blocks.size() - 1].count) {
                    cout << komenda << " == " << blocks[index1].sekcje[index2 - 1].attributes.size() << endl;
                }
            }
            //i,S,j
            else if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "S" && Sprawdzliczbe(PodzielKomenda.third) == 1) {
                int z = atoi(PodzielKomenda.first.c_str());

                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }
                int z2 = atoi(PodzielKomenda.third.c_str());
                if (z <= (blocks.size() - 1) * T + blocks[blocks.size() - 1].count && z2 <= blocks[index1].sekcje[index2 - 1].selectors.size()) {
                    cout << komenda << " == " << blocks[index1].sekcje[index2 - 1].selectors[z2 - 1] << endl;
                }
            }
            //i,A,n
            else if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "A" && Sprawdzliczbe(PodzielKomenda.third) == 0) {
                int z = atoi(PodzielKomenda.first.c_str());

                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }
                String value = szukaj(blocks, index1, index2, PodzielKomenda.third);
                if (value.length() > 0 && z <= (blocks.size() - 1) * T + blocks[blocks.size() - 1].count) {
                    cout << komenda << " ==" << value << endl;
                }
            }
            //i,D,*
            else if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "D" && PodzielKomenda.third == "*") {
                int z = atoi(PodzielKomenda.first.c_str());
                int g = 0;
                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }
                for (int p = 0; p < blocks.size(); p++) {
                    g += blocks[p].count;
                }
                usunsekcje(blocks, index1, index2);
                if (z <= g) {
                    cout << komenda << " == " << "deleted" << endl;
                }
            }
            //i,D,n
            else if (Sprawdzliczbe(PodzielKomenda.first) == 1 && PodzielKomenda.second == "D" && Sprawdzliczbe(PodzielKomenda.third) == 0) {
                int z = atoi(PodzielKomenda.first.c_str());

                if (z % T != 0) {
                    index1 = z / T;
                    index2 = z - (index1 * T);
                }
                else {
                    index1 = z / (T + 1);
                    index2 = z - (index1 * T);
                }
                usun(blocks, index1, index2, PodzielKomenda.third,komenda);

               

            }
            //n,A,?
            else if (Sprawdzliczbe(PodzielKomenda.first) == 0 && PodzielKomenda.second == "A" && PodzielKomenda.third == "?") {

                cout << komenda << " == " << liczbawystapienatt(blocks, PodzielKomenda.first) << endl;
            }
            //z,S,?
            else if (Sprawdzliczbe(PodzielKomenda.first) == 0 && PodzielKomenda.second == "S" && PodzielKomenda.third == "?") {

                cout << komenda << " == " << liczbawystapiensel(blocks, PodzielKomenda.first) << endl;
            }
            //z,E,n
            else if (Sprawdzliczbe(PodzielKomenda.first) == 0 && PodzielKomenda.second == "E" && Sprawdzliczbe(PodzielKomenda.third) == 0) {
                String znaleziony = szukajwartosci(blocks, PodzielKomenda.first, PodzielKomenda.third);
                if (znaleziony.length() > 0) {
                    cout << komenda << " == " << znaleziony << endl;
                }
            }
        }
    }
}