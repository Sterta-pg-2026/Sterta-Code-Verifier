#pragma once

#include "string.h"

class DoublyLinkedList {
public:
    DoublyLinkedList();
    DoublyLinkedList(const DoublyLinkedList& other);
    ~DoublyLinkedList();

    void push_front(const String& value);
    void push_back(const String& value);
    void clear();
    void clear_element(int index);
    String& operator[](int index);

    int size() const;
    bool empty() const;


private:
    String* data;
    int data_size;
    int capacity;

    struct Node {
        int index;
        Node* next;
        Node* prev;
    };

    Node* head;
    Node* tail;
    int count;
};