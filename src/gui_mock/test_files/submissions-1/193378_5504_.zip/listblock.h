#pragma once
#include "list.h"

const int T = 17;

struct section {
    DoublyLinkedList attributes;
    DoublyLinkedList selectors;

    section() : attributes(), selectors() {}
};

struct block {
    section sekcje[T];
    int count;

    block() : sekcje(), count(0) {}




    block(const block& other) : count(other.count) {
        for (int i = 0; i < T; i++) {
            sekcje[i].attributes = other.sekcje[i].attributes;
            sekcje[i].selectors = other.sekcje[i].selectors;
        }
    }

};

class DoublyLinkedListBlock {
private:
    struct Node {
        block value;
        Node* next = nullptr;
        Node* prev = nullptr;

        Node(const block& value) : value(value) {}


    };
    Node* head = nullptr;
    Node* tail = nullptr;
    int count = 0;
public:
    DoublyLinkedListBlock();
    ~DoublyLinkedListBlock();
    void push_front(const block& value);
    void push_back(const block& value);
    void remove(int index);
    void remove_section(int blockIndex, int sectionIndex);
    block& operator[](int index);
    int size() const;
};