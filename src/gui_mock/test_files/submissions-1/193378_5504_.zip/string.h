#pragma once
#include <istream>
#include <cstring>

class String {
private:
    char* data;
    int size;
public:
    String();
    String(const char* cstring);
    String(const String& other);
    ~String();

    String& operator=(const String& other);
    String operator+(const String& other) const;
    String operator+(const char c) const;
    friend std::istream& operator>>(std::istream& input, String& str);
    friend bool operator==(const String& str1, const String& str2);
    friend std::ostream& operator<<(std::ostream& output, const String& str);
    void clear();
    int length() const;
    char operator[](int i) const;
    char& operator[](int i);

    const char* c_str() const;


};