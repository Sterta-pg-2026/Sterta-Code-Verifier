#include <iostream>
#define Liczba_Sekcji  8
#define Wielkosc_stringa 128
using namespace std;
class WezelAtrybutow;
class Strings
{
public:
	char strin[Wielkosc_stringa];
	Strings()
	{
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			strin[i] = 0;
		}
	}
	void usunSpacje()
	{
		for (int i = 1; i < Wielkosc_stringa; i++)
		{
			if (strin[i] == 0 && strin[i - 1] == ' ')
			{
				strin[i - 1] = 0;
			}
		}
	}
	void PrintujStringa()
	{
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (strin[i] == 0)
			{
				break;
			}
			cout << strin[i];
		}
	}
	int Zamien_stringa_na_liczbe()
	{
		int liczba = 0;
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (strin[i] == 0)
			{
				return liczba;
			}
			int cyfra = int(strin[i] - '0');
			liczba = liczba * 10;
			liczba = liczba + cyfra;
		}
		return liczba;//nigdy nie powinno wejsc
	}
};

class WezelSelector
{
public:

	Strings nazwa;
	WezelSelector* nastepny_selektor;
	WezelSelector* poprzedni_selektor;
	WezelSelector()
	{
		nastepny_selektor = nullptr;
		poprzedni_selektor = nullptr;
	}
};

class WezelAtrybutow
{
public:
	Strings nazwa;
	Strings wartosc;
	WezelAtrybutow* nastepny_atrybut;
	WezelAtrybutow* poprzedni_atrybut;

	WezelAtrybutow()
	{
		nastepny_atrybut = nullptr;
		poprzedni_atrybut = nullptr;
	}

};
class Sekcja
{
public:
	~Sekcja()
	{

		WezelAtrybutow* wezel_atrybutow = wezel_atrybutow_tail;
		while (wezel_atrybutow != nullptr)
		{
			WezelAtrybutow* tmp = wezel_atrybutow;
			wezel_atrybutow = wezel_atrybutow->poprzedni_atrybut;
			delete tmp;
		}

		WezelSelector* wezel_selektor = wezel_selektorow_tail;
		while (wezel_selektor != nullptr)
		{
			WezelSelector* tmp = wezel_selektor;
			wezel_selektor = wezel_selektor->poprzedni_selektor;
			delete tmp;

		}




	}
	WezelAtrybutow* wezel_atyrbutow_head = nullptr;
	WezelAtrybutow* wezel_atrybutow_tail = nullptr;
	WezelSelector* wezel_selektorow_head = nullptr;
	WezelSelector* wezel_selektorow_tail = nullptr;

};
class Wezel
{
public:
	~Wezel()
	{
		for (int i = 0; i < licznik; i++)
		{
			delete tab[i];
		}
	}
	Sekcja* tab[8] = { nullptr };
	Wezel* nastepny = nullptr;
	Wezel* poprzedni = nullptr;
	int licznik = 0;
	bool dodajSekcje(Sekcja* sekcja)
	{
		if (licznik == 8)
		{
			return false;
		}

		tab[licznik] = sekcja;
		licznik++;
		return true;
	}

};
class Lista
{
public:

	Wezel* sekcja_head = nullptr;
	Wezel* sekcja_tail = nullptr;
	bool czy_zakonczono_czytanie_sekcji = true;
	bool czy_zakonczono_czytanie_selektora = true;
	bool czy_zakonczono_czytanie_atrybutow = true;
	bool jestesekcja = false;
	bool czy_jestes_atrybutem = false;
	bool poczatek_sekcji_komend = false;
	int liczba_ostatnich_wezlow = 0;
	~Lista()
	{
		Wezel* wezel = sekcja_tail;
		while (wezel != nullptr)
		{
			Wezel* tmp = wezel;
			wezel = wezel->poprzedni;
			delete tmp;

		}
	}

	void Sprawdzlinie(Strings& wczytana_linia, Strings wczytana_linia2)
	{
		if (wczytana_linia.strin[0] == '?' && poczatek_sekcji_komend == false)
		{
			poczatek_sekcji_komend = true;
			return;
		}
		if (wczytana_linia.strin[0] == '*' && poczatek_sekcji_komend == true)
		{
			poczatek_sekcji_komend = false;
			return;
		}
		if (poczatek_sekcji_komend == true)
		{

			CzytajKokmende(wczytana_linia, wczytana_linia2);
		}
		else
		{
			CzytajCss(wczytana_linia, wczytana_linia2);

		}
	}
	int LiczbaSekcji()
	{
		int suma = 0;
		Wezel* wezel = sekcja_tail;
		while (wezel != nullptr)
		{
			suma += wezel->licznik;
			wezel = wezel->poprzedni;
		}
		return suma;
	}
	int PrzeczytajLiczbe(Strings& wczytana_linia)
	{
		int liczba = 0;
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (wczytana_linia.strin[i] == ',')
			{
				return liczba;
			}
			int cyfra = int(wczytana_linia.strin[i] - '0');
			liczba = liczba * 10;
			liczba = liczba + cyfra;
		}
		return liczba;//nigdy nie powinno wejsc
	}

	char Przeczytajdrugalinie(Strings& wczytana_linia)
	{
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (wczytana_linia.strin[i] == ',')
			{
				return wczytana_linia.strin[i + 1];
			}
		}
		return 'x';//nie powinno wchodzic
	}
	Strings PrzeczytajTrzeciaLinie(Strings& wczytana_linia)
	{
		int liczbaprzecinkow = 0;
		Strings wczytana_trzecia_czesc;
		int index = 0;
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (wczytana_linia.strin[i] == ',')
			{
				liczbaprzecinkow++;
				continue;
			}
			if (wczytana_linia.strin[i] == 0)
			{
				break;
			}
			if (liczbaprzecinkow == 2)
			{
				wczytana_trzecia_czesc.strin[index] = wczytana_linia.strin[i];
				index++;
			}
		}
		return wczytana_trzecia_czesc;
	}
	bool Czy_Stringi_sa_rowne(Strings& a, Strings& b)
	{
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (a.strin[i] != b.strin[i])
			{
				return false;
			}
			if (a.strin[i] == 0 && b.strin[i] == 0)
			{
				return true;
			}
		}
		return true;
	}
	bool UsunWezel(int numer_sekcji)
	{
		int licznik_sekcji = 0;
		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					licznik_sekcji++;
					if (licznik_sekcji == numer_sekcji)
					{
						delete wezel->tab[i];
						for (int j = i; j < wezel->licznik - 1; j++)
						{
							wezel->tab[j] = wezel->tab[j + 1];
						}
						wezel->tab[Liczba_Sekcji - 1] = nullptr;
						wezel->licznik--;
						return true;
					}
				}

			}


			wezel = wezel->nastepny;

		}
		return false;
	}
	bool Usun_Wezel_z_atrybutami(int numer_sekcji, Strings& szukany_atrybut)
	{
		int licznik_sekcji = 0;
		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					licznik_sekcji++;
					if (licznik_sekcji == numer_sekcji)
					{
						WezelAtrybutow* wezel_atrybuty = wezel->tab[i]->wezel_atrybutow_tail;
						while (wezel_atrybuty != nullptr)
						{
							if (Czy_Stringi_sa_rowne(wezel_atrybuty->nazwa, szukany_atrybut))
							{
								if (wezel_atrybuty == wezel->tab[i]->wezel_atyrbutow_head && wezel_atrybuty == wezel->tab[i]->wezel_atrybutow_tail)
								{
									delete wezel_atrybuty;
									wezel->tab[i]->wezel_atyrbutow_head = nullptr;
									wezel->tab[i]->wezel_atrybutow_tail = nullptr;
									delete wezel->tab[i];
									wezel->tab[i] = nullptr;
									for (int j = i; j < wezel->licznik - 1; j++)
									{
										wezel->tab[j] = wezel->tab[j + 1];
									}
									wezel->tab[Liczba_Sekcji - 1] = nullptr;
									wezel->licznik--;

								}
								else if (wezel_atrybuty == wezel->tab[i]->wezel_atyrbutow_head)
								{
									wezel->tab[i]->wezel_atyrbutow_head = wezel_atrybuty->nastepny_atrybut;
									wezel->tab[i]->wezel_atyrbutow_head->poprzedni_atrybut = nullptr;
									delete wezel_atrybuty;
								}
								else if (wezel_atrybuty == wezel->tab[i]->wezel_atrybutow_tail)
								{
									wezel->tab[i]->wezel_atrybutow_tail = wezel_atrybuty->poprzedni_atrybut;
									wezel->tab[i]->wezel_atrybutow_tail->nastepny_atrybut = nullptr;
									delete wezel_atrybuty;
								}
								else
								{
									WezelAtrybutow* poprzedniAktualny = wezel_atrybuty->poprzedni_atrybut;
									WezelAtrybutow* nastepnyAktualny = wezel_atrybuty->nastepny_atrybut;
									poprzedniAktualny->nastepny_atrybut = nastepnyAktualny;
									nastepnyAktualny->poprzedni_atrybut = poprzedniAktualny;
									delete wezel_atrybuty;
								}
								return true;
							}


							wezel_atrybuty = wezel_atrybuty->poprzedni_atrybut;
						}
					}
				}

			}


			wezel = wezel->nastepny;

		}
		return false;
	}
	int LiczbaAtrybutow(int numersekcji)
	{
		int licznik_sekcji = 0;
		int licznik_atrybutow = 0;
		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					licznik_sekcji++;
					if (licznik_sekcji == numersekcji)
					{
						WezelAtrybutow* wezel_atrybuty = wezel->tab[i]->wezel_atrybutow_tail;
						while (wezel_atrybuty != nullptr)
						{
							licznik_atrybutow++;
							wezel_atrybuty = wezel_atrybuty->poprzedni_atrybut;
						}
						return licznik_atrybutow;
					}
				}

			}


			wezel = wezel->nastepny;

		}
		return licznik_atrybutow;
	}
	int LiczbaSelektorow(int numersekcji)
	{
		int licznik_sekcji = 0;
		int licznik_selektorow = 0;
		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					licznik_sekcji++;
					if (licznik_sekcji == numersekcji)
					{
						WezelSelector* wezel_selektorow = wezel->tab[i]->wezel_selektorow_tail;
						while (wezel_selektorow != nullptr)
						{
							licznik_selektorow++;
							wezel_selektorow = wezel_selektorow->poprzedni_selektor;
						}
						return licznik_selektorow;
					}
				}

			}


			wezel = wezel->nastepny;

		}
		return -1;
	}
	void Wypisz_J_Selektor_dla_i_bloku(int numersekcji, int numerselektora)
	{
		int licznik_sekcji = 0;

		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					int licznik_selektorow = 0;
					licznik_sekcji++;
					if (licznik_sekcji == numersekcji)
					{
						WezelSelector* wezel_selektorow = wezel->tab[i]->wezel_selektorow_head;
						while (wezel_selektorow != nullptr)
						{

							licznik_selektorow++;
							if (numerselektora == licznik_selektorow)
							{
								cout << numersekcji << ",S," << numerselektora << " == ";
								wezel_selektorow->nazwa.PrintujStringa();
								cout << endl;
								return;
							}
							wezel_selektorow = wezel_selektorow->nastepny_selektor;
						}

					}
				}

			}


			wezel = wezel->nastepny;

		}
	}
	void Wypisz_Atrybut_Dla_i_Sekcji(int numer_sekcji, Strings& szukany_atrybut)
	{
		int licznik_sekcji = 0;
		Wezel* wezel = sekcja_head;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{
					licznik_sekcji++;
					if (licznik_sekcji == numer_sekcji)
					{
						WezelAtrybutow* wezel_atrybuty = wezel->tab[i]->wezel_atrybutow_tail;
						while (wezel_atrybuty != nullptr)
						{
							if (Czy_Stringi_sa_rowne(wezel_atrybuty->nazwa, szukany_atrybut))
							{
								cout << numer_sekcji << ",A,";
								szukany_atrybut.PrintujStringa();
								cout << " == ";
								wezel_atrybuty->wartosc.PrintujStringa();
								cout << endl;
								return;
							}


							wezel_atrybuty = wezel_atrybuty->poprzedni_atrybut;
						}
					}
				}

			}


			wezel = wezel->nastepny;

		}
	}
	int Wypisz_liczbe_wystapien_atrybutu(Strings& szukany_atrybut)
	{
		int licznik_atrybutow = 0;
		Wezel* wezel = sekcja_tail;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{


					WezelAtrybutow* wezel_atrybuty = wezel->tab[i]->wezel_atrybutow_tail;
					while (wezel_atrybuty != nullptr)
					{
						if (Czy_Stringi_sa_rowne(wezel_atrybuty->nazwa, szukany_atrybut))
						{
							licznik_atrybutow++;
						}


						wezel_atrybuty = wezel_atrybuty->poprzedni_atrybut;

					}
				}

			}


			wezel = wezel->poprzedni;

		}
		return licznik_atrybutow;
	}
	int Wypisz_liczbe_wystapien_selektora(Strings& szukany_selektor)
	{
		int licznik_selektora = 0;
		Wezel* wezel = sekcja_tail;
		while (wezel != nullptr)
		{
			for (int i = 0; i < wezel->licznik; i++)
			{
				if (wezel->tab[i] != nullptr)
				{


					WezelSelector* wezel_selektora = wezel->tab[i]->wezel_selektorow_tail;
					while (wezel_selektora != nullptr)
					{
						if (Czy_Stringi_sa_rowne(wezel_selektora->nazwa, szukany_selektor))
						{
							licznik_selektora++;
						}


						wezel_selektora = wezel_selektora->poprzedni_selektor;

					}
				}

			}


			wezel = wezel->poprzedni;

		}
		return licznik_selektora;
	}
	void Wypisz_wartosc_atrybuty_o_nazwie_N_dla_selektora_Z(Strings& szukany_selektor, Strings& szukany_atrybut)
	{
		Wezel* wezel = sekcja_tail;
		while (wezel != nullptr)
		{
			for (int i = wezel->licznik - 1; i >= 0; i--)
			{
				if (wezel->tab[i] != nullptr)
				{


					WezelSelector* wezel_selektora = wezel->tab[i]->wezel_selektorow_head;
					while (wezel_selektora != nullptr)
					{
						if (Czy_Stringi_sa_rowne(wezel_selektora->nazwa, szukany_selektor))
						{

							WezelAtrybutow* wezel_atrybutow = wezel->tab[i]->wezel_atyrbutow_head;
							while (wezel_atrybutow != nullptr)
							{
								if (Czy_Stringi_sa_rowne(wezel_atrybutow->nazwa, szukany_atrybut))
								{
									szukany_selektor.PrintujStringa();
									cout << ",E,";
									szukany_atrybut.PrintujStringa();
									cout << " == ";
									wezel_atrybutow->wartosc.PrintujStringa();
									cout << endl;
									return;
								}


								wezel_atrybutow = wezel_atrybutow->nastepny_atrybut;

							}
						}


						wezel_selektora = wezel_selektora->nastepny_selektor;

					}
				}

			}


			wezel = wezel->poprzedni;

		}
	}
	Strings  Wczytaj_Stringa_Do_Pierwszego_Przecinka(Strings& wczytana_linia)
	{
		Strings wczytany_string;
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (wczytana_linia.strin[i] == ',')
			{
				break;
			}
			wczytany_string.strin[i] = wczytana_linia.strin[i];
		}
		return wczytany_string;
	}
	bool Czy_ostatnia_litera_to_przecinek(Strings& wczytana_linia)
	{
		for (int i = 0; i < Wielkosc_stringa; i++)
		{
			if (wczytana_linia.strin[i] == 0)
			{
				if (i == 0)
				{
					return false;
				}
				else if (wczytana_linia.strin[i - 1] == ',')
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		return false;
	}
	void CzytajKokmende(Strings& wczytana_linia, Strings wczytana_linia2)
	{
		if (wczytana_linia.strin[0] == '?')
		{
			int suma = LiczbaSekcji();
			cout << "? == " << suma << endl;
		}
		else if (isdigit(wczytana_linia.strin[0]) && (wczytana_linia.strin[0] - '0' >= 1) && (wczytana_linia.strin[0] - '0' <= 9))
		{
			int wczytanaliczba = PrzeczytajLiczbe(wczytana_linia);
			char operacja2 = Przeczytajdrugalinie(wczytana_linia);
			if (operacja2 == 'D')
			{
				Strings trzecia_operacja = PrzeczytajTrzeciaLinie(wczytana_linia);
				if (trzecia_operacja.strin[0] == '*')
				{
					if (UsunWezel(wczytanaliczba))
					{
						cout << wczytanaliczba << ",D,* == deleted" << endl;
					}
				}
				else
				{
					if (Usun_Wezel_z_atrybutami(wczytanaliczba, trzecia_operacja))
					{
						cout << wczytanaliczba << ",D,";
						trzecia_operacja.PrintujStringa();
						cout << " == deleted" << endl;
					}
				}
			}
			else if (operacja2 == 'A')
			{
				Strings trzecia_operacja = PrzeczytajTrzeciaLinie(wczytana_linia);
				if (trzecia_operacja.strin[0] == '?')
				{
					int wynik = LiczbaAtrybutow(wczytanaliczba);
					if (wynik > 0)
					{
						cout << wczytanaliczba << ",A,? == " << wynik << endl;
					}
				}
				else
				{
					Wypisz_Atrybut_Dla_i_Sekcji(wczytanaliczba, trzecia_operacja);
				}
			}
			else if (operacja2 == 'S')
			{
				Strings trzecia_operacja = PrzeczytajTrzeciaLinie(wczytana_linia);
				if (trzecia_operacja.strin[0] == '?')
				{
					int wynik = LiczbaSelektorow(wczytanaliczba);
					if (wynik >= 0)
					{
						cout << wczytanaliczba << ",S,? == " << wynik << endl;
					}
				}
				else
				{
					int liczba = trzecia_operacja.Zamien_stringa_na_liczbe();
					Wypisz_J_Selektor_dla_i_bloku(wczytanaliczba, liczba);

				}
			}


		}
		else
		{
			//wczytaj stringa do pierwszego przecinka
			char operacja2 = Przeczytajdrugalinie(wczytana_linia);
			if (operacja2 == 'A')
			{
				Strings nazwa_atrybutu = Wczytaj_Stringa_Do_Pierwszego_Przecinka(wczytana_linia);
				int wynik = Wypisz_liczbe_wystapien_atrybutu(nazwa_atrybutu);
				nazwa_atrybutu.PrintujStringa();
				cout << ",A,? == " << wynik << endl;
			}
			else if (operacja2 == 'S')
			{
				Strings nazwa_selektora = Wczytaj_Stringa_Do_Pierwszego_Przecinka(wczytana_linia);
				int wynik = Wypisz_liczbe_wystapien_selektora(nazwa_selektora);
				nazwa_selektora.PrintujStringa();
				cout << ",S,? == " << wynik << endl;
			}
			else if (operacja2 == 'E')
			{
				Strings nazwa_atrybutu = PrzeczytajTrzeciaLinie(wczytana_linia);
				Strings nazwa_selektora = Wczytaj_Stringa_Do_Pierwszego_Przecinka(wczytana_linia);
				Wypisz_wartosc_atrybuty_o_nazwie_N_dla_selektora_Z(nazwa_selektora, nazwa_atrybutu);
			}
		}

	}
	bool Podmien_Wartosc_dla_atrybutow_o_tej_samej_nazwie(Strings& nazwa_atrybutu, Strings& wartosc_atrybutu, WezelAtrybutow* head)
	{
		WezelAtrybutow* wezel = head;
		while (wezel != nullptr)
		{
			if (Czy_Stringi_sa_rowne(nazwa_atrybutu, wezel->nazwa))
			{
				for (int i = 0; i < Wielkosc_stringa; i++)
				{
					wezel->wartosc.strin[i] = wartosc_atrybutu.strin[i];
					if (wartosc_atrybutu.strin[i] == 0)
					{
						return true;
					}
				}
			}

			wezel = wezel->nastepny_atrybut;
		}
		return false;
	}
	void CzytajCss(Strings& wczytana_linia, Strings wczytana_linia2)
	{

		char* nazwa_atrybutu2;
		char* savepoint2;
		if (czy_jestes_atrybutem)
		{
			if (wczytana_linia.strin[0] == '}')
			{
				czy_jestes_atrybutem = false;
				czy_zakonczono_czytanie_sekcji = true;
				return;
			}
			else if (wczytana_linia.strin[0] == '	' && wczytana_linia.strin[1] == '}')
			{
				czy_jestes_atrybutem = false;
				czy_zakonczono_czytanie_sekcji = true;
				return;
			}

			if (wczytana_linia.strin[0] == '{')
			{
				return;
			}
			nazwa_atrybutu2 = strtok_s(wczytana_linia.strin, "	 :", &savepoint2);//nazwa atrybutu
			if (nazwa_atrybutu2 != NULL)
			{
				//tworze nowy atrybut
				WezelAtrybutow* nowy_atrybut = new WezelAtrybutow;
				int index_Sekcji = sekcja_tail->licznik - 1;
				//w nazwa s
				char* wartosc_atrybuty;
				wartosc_atrybuty = strtok_s(NULL, ";", &savepoint2);//wartosc atrybutu
				if (wartosc_atrybuty[0] <= ' ')
				{
					wartosc_atrybuty++;
				}
				strcpy_s(nowy_atrybut->nazwa.strin, nazwa_atrybutu2);
				strcpy_s(nowy_atrybut->wartosc.strin, wartosc_atrybuty);

				if (Podmien_Wartosc_dla_atrybutow_o_tej_samej_nazwie(nowy_atrybut->nazwa, nowy_atrybut->wartosc, sekcja_tail->tab[index_Sekcji]->wezel_atyrbutow_head) == false)
				{
					if (sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail == nullptr)
					{
						sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail = nowy_atrybut;
						sekcja_tail->tab[index_Sekcji]->wezel_atyrbutow_head = nowy_atrybut;
					}
					else
					{
						sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail->nastepny_atrybut = nowy_atrybut;
						nowy_atrybut->poprzedni_atrybut = sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail;
						sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail = nowy_atrybut;

					}
				}
				else
				{
					delete nowy_atrybut;
				}
				//wczytano cala sekcje
				czy_zakonczono_czytanie_sekcji = false;
				czy_jestes_atrybutem = true;
				return;
			}
		}
		char* losowy;
		if (!jestesekcja)
		{
			if (czy_zakonczono_czytanie_sekcji == true)
			{
				Sekcja* nowa_sekcja = new Sekcja;
				if (sekcja_tail == nullptr)
				{
					Wezel* wezel_sekcji = new Wezel;
					sekcja_head = wezel_sekcji;
					sekcja_tail = wezel_sekcji;
				}
				if (sekcja_tail->dodajSekcje(nowa_sekcja) == false)
				{
					Wezel* wezel_sekcji = new Wezel;
					sekcja_tail->nastepny = wezel_sekcji;
					wezel_sekcji->poprzedni = sekcja_tail;
					sekcja_tail = wezel_sekcji;
					sekcja_tail->dodajSekcje(nowa_sekcja);

				}
				czy_zakonczono_czytanie_sekcji = false;
			}
			for (int i = 0; i < Wielkosc_stringa; i++)
			{
				if (wczytana_linia.strin[i] == '{')
				{
					wczytana_linia.strin[i] = 0;
					break;
				}
				else if (wczytana_linia.strin[i] == 0)
				{
					break;
				}
			}
			char* nazwaselektora = strtok_s(wczytana_linia.strin, ",{", &losowy);
			liczba_ostatnich_wezlow = 0;
			while (nazwaselektora != NULL)
			{
				WezelSelector* nowy_selector = new WezelSelector;
				int index_Sekcji = sekcja_tail->licznik - 1;
				if (sekcja_tail->tab[index_Sekcji]->wezel_selektorow_tail == nullptr)
				{
					sekcja_tail->tab[index_Sekcji]->wezel_selektorow_tail = nowy_selector;
					sekcja_tail->tab[index_Sekcji]->wezel_selektorow_head = nowy_selector;
				}
				else
				{
					sekcja_tail->tab[index_Sekcji]->wezel_selektorow_tail->nastepny_selektor = nowy_selector;
					nowy_selector->poprzedni_selektor = sekcja_tail->tab[index_Sekcji]->wezel_selektorow_tail;
					sekcja_tail->tab[index_Sekcji]->wezel_selektorow_tail = nowy_selector;
				}
				if (nazwaselektora[0] <= ' ')
				{
					nazwaselektora++;
				}
				strcpy_s(nowy_selector->nazwa.strin, nazwaselektora);
				nowy_selector->nazwa.usunSpacje();
				nazwaselektora = strtok_s(NULL, ",{", &losowy);
			}
		}
		char* nazwa_atrybutu = strtok_s(wczytana_linia2.strin, "{", &savepoint2);
		nazwa_atrybutu = strtok_s(NULL, ":", &savepoint2);//nazwa atrybutu
		if (nazwa_atrybutu != NULL)
		{

			char* wartosc_atrybuty;
			wartosc_atrybuty = strtok_s(NULL, ";", &savepoint2);//wartosc atrybutu
			if (wartosc_atrybuty == NULL)
			{
				czy_jestes_atrybutem = true;
				return;
			}
			if (wartosc_atrybuty[0] <= ' ')
			{
				wartosc_atrybuty++;
			}
			//wczytano cala sekcje;
			//tworze nowy atrybut
			WezelAtrybutow* nowy_atrybut = new WezelAtrybutow;
			int index_Sekcji = sekcja_tail->licznik - 1;
			sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail;
			if (sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail == nullptr)
			{
				sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail = nowy_atrybut;
				sekcja_tail->tab[index_Sekcji]->wezel_atyrbutow_head = nowy_atrybut;
			}
			else
			{
				sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail->nastepny_atrybut = nowy_atrybut;
				nowy_atrybut->poprzedni_atrybut = sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail;
				sekcja_tail->tab[index_Sekcji]->wezel_atrybutow_tail = nowy_atrybut;

			}
			strcpy_s(nowy_atrybut->nazwa.strin, nazwa_atrybutu);
			strcpy_s(nowy_atrybut->wartosc.strin, wartosc_atrybuty);
			czy_jestes_atrybutem = false;
			czy_zakonczono_czytanie_sekcji = true;
			return;
		}
		if (Czy_ostatnia_litera_to_przecinek(wczytana_linia2) == false)
		{
			czy_jestes_atrybutem = true;
		}
	}

};
bool Skipuje_pusta_linie(Strings& linia)
{
	for (int i = 0; i < Wielkosc_stringa; i++)
	{
		if (linia.strin[i] > ' ')
		{
			return false;
		}
		if (linia.strin[i] == 0)
		{
			return true;
		}
	}
	return true;
}
int main()
{
	Lista NewCss;
	while (true)
	{
		if (!cin)
		{
			return 0;
		}
		Strings inputline;
		cin.getline(inputline.strin, Wielkosc_stringa);
		if (Skipuje_pusta_linie(inputline) == true)
		{
			continue;
		}
		NewCss.Sprawdzlinie(inputline, inputline);
	}
}
