#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

// Define data structure for CSS rules
unordered_map<string, unordered_map<string, string>> css_rules;

// Define function to parse a CSS rule
void parse_css_rule(string css_rule_str) {
    size_t pos = css_rule_str.find('{');
    string selector = css_rule_str.substr(0, pos);
    unordered_map<string, string> properties;
    css_rule_str = css_rule_str.substr(pos + 1, css_rule_str.size() - pos - 2);
    pos = 0;
    while (pos < css_rule_str.size()) {
        size_t colon_pos = css_rule_str.find(':', pos);
        size_t semicolon_pos = css_rule_str.find(';', pos);
        string property = css_rule_str.substr(pos, colon_pos - pos);
        string value = css_rule_str.substr(colon_pos + 1, semicolon_pos - colon_pos - 1);
        properties[property] = value;
        pos = semicolon_pos + 1;
    }
    css_rules[selector] = properties;
}

// Define data structure for commands
unordered_map<string, vector<string>> commands;

// Define function to parse a command
void parse_command(string command_str) {
    size_t pos = command_str.find(' ');
    string command = command_str.substr(0, pos);
    vector<string> arguments;
    command_str = command_str.substr(pos + 1);
    pos = 0;
    while (pos < command_str.size()) {
        size_t space_pos = command_str.find(' ', pos);
        string argument = command_str.substr(pos, space_pos - pos);
        arguments.push_back(argument);
        pos = space_pos + 1;
    }
    commands[command] = arguments;
}

int main() {
    // Read from standard input
    while (true) {
        // Read CSS section
        string css_section;
        getline(cin, css_section);
        if (css_section == "") {
            break;
        }
        // Parse CSS rule and add to data structure
        parse_css_rule(css_section);

        // Read command section
        string command_section;
        getline(cin, command_section);
        if (command_section == "") {
            break;
        }
        // Parse command and add to data structure
        parse_command(command_section);
    }

    // Execute commands and print results
    for (auto const& [command, arguments] : commands) {
        if (command == "print") {
            for (auto const& argument : arguments) {
                cout << "== " << argument << endl;
            }
        } else if (command == "apply") {
            // TODO: implement application of CSS rules to HTML document
        } else {
            // Unknown command
        }
    }

    return 0;
}
