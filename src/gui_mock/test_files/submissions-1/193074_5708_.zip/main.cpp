#include <iostream>
using namespace std;

#define T 8
#define SIZE 150
#define LASTCONTROLCHARACTER 31
#define STARTOFBIGLETTERS 65 
#define ENDOFBIGLETTERS 91 
#define STARTOFSMALLLETTERS 96 
#define ENDOFSMALLLETTERS 123 

class Selectors
{
public:
    int lp = 0;
    char selectors[SIZE] = {0};
    Selectors *next = nullptr;

    ~Selectors(){};
};
class Atributes
{
public:
    int lp = 0;
    char atributes[2][SIZE] = {0};
    Atributes *next = nullptr;

    ~Atributes(){};
};
class Blok
{
public:
    int lp = 0;
    Selectors *heads;
    Atributes *heada;

    ~Blok()
    {
        while (heads != nullptr)
        {
            Selectors *next = heads->next;
            delete heads;
            heads = next;
        }
        while (heada != nullptr)
        {
            Atributes *next = heada->next;
            delete heada;
            heada = next;
        }
    }
};
class Node
{
public:
    int lp = 0;
    int number = 0;
    Blok *array[T];
    Node *next;
    Node *previous;

    ~Node()
    {
        for (int i = 0; i < T; i++)
        {
            if (array[i] != nullptr)
                delete array[i];
        }
    }
};

Blok *newBlok(int lp)
{
    Blok *newBlok = new Blok();
    newBlok->lp = lp;
    return newBlok;
}
Selectors *newSelector(int lp, Selectors *head)
{
    Selectors *newSelector = new Selectors();
    newSelector->lp = lp;
    newSelector->next = NULL;
    if (head == nullptr)
    {
        head = newSelector;
        return newSelector;
    }
    Selectors *last = head;
    last->next = newSelector;
    return newSelector;
}
Atributes *newAtribute(int lp, Atributes *head)
{
    Atributes *newAtribute = new Atributes();
    newAtribute->lp = lp;
    newAtribute->next = NULL;
    if (head == nullptr)
    {
        head = newAtribute;
        return newAtribute;
    }
    Atributes *last = head;
    last->next = newAtribute;
    return newAtribute;
}

void addCSS(int &mode, int &lp, Node *&head, Node *&tail);
void inputSelector(int &lps, Node *tail, int x, char input[], int &j, int &space, int lpc, int lpa, int &y);
void inputAtribute(int &lpa, Node *tail, int x, int &lpc, char input[], int z, int j, int &y);
void inputValue(char input[], int j, int &space, Node *tail, int lpc, int lpa, int x, int &y, int z);
void newNode(int lp, Node **tail);
bool checkRepeatA(char input[], Atributes *nown, int j);
bool checkRepeatS(char input[], Selectors *nown, int j);
void clearArray(char array[][SIZE]);
void clearArrayS(char array[SIZE]);
void deleteNode(Node **headRef, Node *nodeToDelete, Node **tailRef);
bool checkIfNumber(char input[], int j, int f);
int convertToNmber(int w, char input[], int f);
int howLong(char input[]);
void deleteSpaces(Node *head);
void readCommand(int &mode, int &lp, Node *&head, Node *&tail);
int fourQueCommand(char input[], int &mode, int &lp, Node *head);
int resumeCSS(char input[], int &mode);
int numberOfCSS(char input[], int lp);
int commandS(char input[], int i, Node *head, int w);
int numSQueCommand(char input[], int i, Node *head, int w);
int numSNumCommand(char input[], int i, Node *head, int w);
int nameSQueCommand(char input[], Node *head);
int commandA(char input[], int i, Node *head, int w);
int numAQueCommand(char input[], int w, Node *head);
int numANameCommand(char input[], int i, int w, Node *head);
int nameAQueCommand(char input[], Node *head);
int commandE(char input[], int i, Node *tail);
int commandD(char input[], int i, Node *&head, int &lp, int w, Node *&tail);
int numDStarCommand(char input[], int i, int l, Node *&head, int &lp, Node *nowin, int k, Node *&tail);
int numDNameCommand(char input[], Node *&nowin, int k, int i, int &lp, Node *head, int l);

int main()
{
    int lp = 1, mode = 0;
    Node *node = new Node();
    node->lp = lp;
    Node *head = node;
    Node *tail = node;
    while (mode != 2)
    {
        if (mode == 0)
        {
            addCSS(mode, lp, head, tail);
        }
        if (mode == 1)
        {
            readCommand(mode, lp, head, tail);
            lp++;
        }
    };
    return 0;
}
void addCSS(int &mode, int &lp, Node *&head, Node *&tail)
{
    int x = 0;
    while (mode == 0)
    {
        int type = 0, y = 0, z = 0, space = 0, a = 0, lpa = 0, lps = 0, lpc = 0;
        int semi = 0;

        for (int i = 0; i < T; i++)
        {
            if (tail->array[i] == nullptr)
            {
                x = i;
                break;
            }
        }
        if (tail->number == T)
        {
            newNode(lp, &tail);
            x = 0;
        }
        while (a != 2)
        {
            a = 0;
            char input[SIZE] = {0};
            cin.getline(input, SIZE);
            if (input[0] != '\n')
            {
                if (fourQueCommand(input, mode, lp, head))
                {
                    break;
                }
                else if (tail->array[x] == NULL)
                {
                    tail->array[x] = newBlok(lp);
                }
                for (int j = 0; a == 0; j++)
                {
                    if (input[j] == '}' || (input[j] == 9 && input[j + 1] == '}'))
                    {
                        a = 2, x++;
                    }
                    else
                    {
                        if (input[j] == '\000')
                            a = 1;
                        if (input[j] == '{')
                        {
                            if (input[0] == '{' && (tail->array[x])->heads == nullptr)
                            {
                                (tail->array[x])->heads = newSelector(lps, (tail->array[x])->heads);
                                ((tail->array[x])->heads)->lp = 1;
                            }
                            type = 1;
                            j++;
                            y = 0;
                            tail->number++;
                            space = 0;
                        }
                        if (input[j] == ':' && type == 1)
                            type = 2, y = 0, j++, z = 1;
                        if (input[j] == ';')
                        {
                            semi = 1, j++, a = 1;
                        }
                        else
                        {
                            if (input[j] != '}' && semi == 1)
                            {
                                type = 1, z = 0, y = 0, lpa += 1, space = 0, semi = 0, lpc = 0;
                                Atributes *now = (tail->array[x])->heada;
                                while (now->lp != (lpa - 1))
                                {
                                    now = now->next;
                                }
                                now->next = newAtribute(lpa, now);
                            }
                        }
                        if (input[j] == '}')
                        {
                            a = 2, x++;
                        }
                        else
                        {
                            if (input[j] != '\0')
                            {
                                if (type == 0 && (((input[j] != ' ' || space % 2 == 1) && (input[j] > LASTCONTROLCHARACTER))))
                                {
                                    inputSelector(lps, tail, x, input, j, space, lpc, lpa, y);
                                }
                                if ((type == 1 || type == 2) && (input[j] != ' ' || space % 2 == 1 || (input[j + 1] > STARTOFBIGLETTERS && input[j + 1] < ENDOFBIGLETTERS) || (input[j + 1] > STARTOFSMALLLETTERS && input[j + 1] < ENDOFSMALLLETTERS)) && (input[j] != '\t'))
                                {
                                    if (type == 1)
                                    {
                                        inputAtribute(lpa, tail, x, lpc, input, z, j, y);
                                    }
                                    if (type == 2)
                                    {
                                        inputValue(input, j, space, tail, lpc, lpa, x, y, z);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        lp++;
    }
}
void readCommand(int &mode, int &lp, Node *&head, Node *&tail)
{
    deleteSpaces(head);
    while (mode == 1)
    {
        int w = 0, i = 0;
        char input[SIZE] = {0};
        cin.getline(input, SIZE);
        if (resumeCSS(input, mode))
        {
            break;
        }
        else if (!numberOfCSS(input, lp))
        {
            for (i; input[i] != '\000'; i++)
            {
                if (input[i] == ',')
                {
                    if (commandS(input, i, head, w))
                    {
                        break;
                    }
                    else if (commandA(input, i, head, w))
                    {
                        break;
                    }
                    else if (commandE(input, i, tail))
                    {
                        break;
                    }
                    else if (commandD(input, i, head, lp, w, tail))
                    {
                        break;
                    }
                    break;
                }
                w++;
            }
        }
        if (!cin)
        {
            Node *current = head;
            while (current != nullptr)
            {
                Node *next = current->next;
                delete current;
                current = next;
            }
            exit(0);
        }
    }
}


void newNode(int lp, Node **tail)
{
    Node *new_node = new Node();
    Node *last = *tail;
    new_node->next = NULL;
    new_node->lp = lp;

    last->next = new_node;
    new_node->previous = last;
    *tail = new_node;
}
bool checkRepeatA(char input[], Atributes *nown, int j)
{
    int o = 0;
    for (int k = 0; (nown->atributes[0][k + o] != '\000') && (input[k] != ':'); k++)
    {
        if (j == 1)
        {
            if (nown->atributes[0][k] == ' ')
            {
                o++;
            }
        }
        if (input[k + 1 - j] != nown->atributes[0][k + o])
        {
            return false;
        }
        if ((nown->atributes[0][k + 1 + o] != '-') && (input[k + 1 - j + 1] == '-'))
        {
            return false;
        }
        if ((nown->atributes[0][k + 1 + o] == '-') && (input[k + 1 - j + 1] != '-'))
        {
            return false;
        }
    }
    return true;
}
bool checkRepeatS(char input[], Selectors *nown, int j)
{
    int k = 0;
    for (k = 0; (nown->selectors[k] != '\000') && (input[k - j] != ','); k++)
    {
        if (input[k + 1 - j] != nown->selectors[k])
        {
            return false;
        }
        if ((nown->selectors[k + 1] != '-') && (input[k + 1 - j + 1] == '-'))
        {
            return false;
        }
        if ((nown->selectors[k + 1] == '-') && (input[k + 1 - j + 1] != '-'))
        {
            return false;
        }
        if ((nown->selectors[k + 1] != ' ') && (input[k + 1 - j + 1] == ' '))
        {
            return false;
        }
        if ((nown->selectors[k + 1] == ' ') && (input[k + 1 - j + 1] != ' '))
        {
            return false;
        }
    }
    if (nown->selectors[0] == '\000')
    {
        return false;
    }
    if ((nown->selectors[k + 1] != '\000') || (input[k + 1 - j] != ','))
    {
        return false;
    }
    return true;
}
void clearArray(char array[][SIZE])
{
    for (int i = 0; array[0][i] != '\000'; i++)
    {
        array[0][i] = {0};
        array[1][i] = {0};
    }
}
void clearArrayS(char array[SIZE])
{
    for (int i = 0; array[i] != '\000'; i++)
    {
        array[i] = {0};
    }
}
void deleteNode(Node **headRef, Node *nodeToDelete, Node **tailRef)
{
    if (*headRef == NULL || nodeToDelete == NULL)
    {
        return;
    }

    if (*headRef == nodeToDelete)
    {
        return;
    }

    if (*tailRef == nodeToDelete)
    {
        return;
    }

    if (nodeToDelete->next != NULL)
    {
        nodeToDelete->next->previous = nodeToDelete->previous;
    }

    if (nodeToDelete->previous != NULL)
    {
        nodeToDelete->previous->next = nodeToDelete->next;
    }

    delete nodeToDelete;
}
void inputSelector(int &lps, Node *tail, int x, char input[], int &j, int &space, int lpc, int lpa, int &y)
{
    if (lps == 0)
    {
        lps++;
        (tail->array[x])->heads = newSelector(lps, (tail->array[x])->heads);
    }
    if (input[j] != ' ')
    {
        space = 1;
    }
    Selectors *nowns = (tail->array[x])->heads;
    while ((nowns->lp != lps) && (nowns->lp != lpc))
    {
        if (checkRepeatS(input, nowns, 0) && input[j - 1] < 33)
        {
            lps--;
            lpc = nowns->lp;
            clearArrayS(nowns->selectors);
            if (nowns->next != nullptr)
            {
                Selectors *nown1 = nowns;
                while (nown1->lp != lpa)
                {
                    nown1 = nown1->next;
                }
                nown1->next = nullptr;
            }
            break;
        }
        nowns = nowns->next;
    }
    Selectors *nown = (tail->array[x])->heads;
    while (nown->lp != lps)
    {
        nown = nown->next;
    }
    if (input[j] == ',')
    {
        j++, y = -1, lps++;
        nown->next = newSelector(lps, nown);
        space = 0;
    }
    else
        nown->selectors[y] = input[j];
    y++;
}
void inputAtribute(int &lpa, Node *tail, int x, int &lpc, char input[], int z, int j, int &y)
{
    if (lpa == 0)
    {
        lpa++;
        (tail->array[x])->heada = newAtribute(lpa, (tail->array[x])->heada);
    }
    Atributes *nown = (tail->array[x])->heada;
    while ((nown->lp != lpa) && (nown->lp != lpc))
    {
        if (checkRepeatA(input, nown, 0) && input[j - 1] < 33)
        {
            lpa--;
            lpc = nown->lp;
            clearArray(nown->atributes);
            if (nown->next != nullptr)
            {
                Atributes *nown1 = nown;
                while (nown1->lp != lpa)
                {
                    nown1 = nown1->next;
                }
                nown1->next = nullptr;
            }
            break;
        }
        nown = nown->next;
    }
    nown->atributes[z][y] = input[j];
    y++;
}
void inputValue(char input[], int j, int &space, Node *tail, int lpc, int lpa, int x, int &y, int z)
{
    if (input[j] != ' ')
    {
        space = 1;
    }
    Atributes *nown = (tail->array[x])->heada;
    while ((nown->lp != lpa) && (nown->lp != lpc))
    {
        nown = nown->next;
    }
    (nown)->atributes[z][y] = input[j];
    y++;
}
int fourQueCommand(char input[], int &mode, int &lp, Node *head)
{
    if ((input[0] == '?') && (input[1] == '?') && (input[2] == '?') && (input[3] == '?'))
    {
        mode = 1;
        lp -= 2;
        Node *nowin = head;
        while (nowin != nullptr)
        {
            for (int u = 0; u < T; u++)
            {
                if (nowin->array[u] != nullptr)
                {
                    if (nowin->array[u]->heada == nullptr)
                    {
                        nowin->array[u] = nullptr;
                    }
                }
            }
            nowin = nowin->next;
        }
        return 1;
    }
    return 0;
}

bool checkIfNumber(char input[], int j, int f)
{
    for (int k = f; k < j; k++)
    {
        for (char i = 48; i < 58; i++)
        {
            if (input[k] == i)
            {
                break;
            }
            if (i == 57)
            {
                return false;
            }
        }
    }
    return true;
}
int convertToNmber(int w, char input[], int f)
{
    int l = 0, w1 = w - f;
    for (int i = f; i < w; i++)
    {
        int l1 = 1;
        for (int j = 1; j < w1; j++)
        {
            l1 *= 10;
        }
        l += ((input[i] - 48) * l1);
        w1--;
    }
    return l;
}
int howLong(char input[])
{
    int l = 0;
    for (int i = 0; input[i] != '\000'; i++)
    {
        l++;
    }
    return l;
}
void deleteSpaces(Node *head)
{
    Node *innodes = head;
    while (innodes != nullptr)
    {
        for (int i = 0; i < T; i++)
        {
            if (innodes->array[i] != nullptr)
            {
                Selectors *insele = innodes->array[i]->heads;
                while (insele != nullptr)
                {
                    int k = 0;
                    int j = 0;
                    while (insele->selectors[k] != '\000')
                    {
                        if (insele->selectors[k] != ' ')
                        {
                            j = k;
                        }
                        k++;
                    }
                    for (j; insele->selectors[j] != '\000';)
                    {
                        insele->selectors[j + 1] = '\000';
                        j++;
                    }
                    insele = insele->next;
                }
            }
        }
        innodes = innodes->next;
    }
}
int resumeCSS(char input[], int &mode)
{
    if ((input[0] == '*') && (input[1] == '*') && (input[2] == '*') && (input[3] == '*'))
    {
        mode = 0;
        return 1;
    }
    return 0;
}
int numberOfCSS(char input[], int lp)
{
    if (input[0] == '?')
    {
        cout << "? == " << lp << endl;
        return 1;
    }
    return 0;
}
int numSQueCommand(char input[], int i, Node *head, int w)
{
    if (input[i + 3] == '?')
    {
        int l = convertToNmber(w, input, 0);
        Node *in = head;
        do
        {
            for (int j = 0; j < T; j++)
            {
                if (in->array[j] != nullptr)
                {
                    if (in->array[j]->lp == l)
                    {
                        Selectors *nows = in->array[j]->heads;
                        for (int k = 0; nows->next != nullptr; k++)
                        {
                            nows = nows->next;
                        }
                        if (nows->selectors[0] == '\000')
                        {
                            cout << l << ",S,? == 0" << endl;
                        }
                        else
                        {
                            cout << l << ",S,? == " << nows->lp << endl;
                            return 1;
                        }
                        return 0;
                    }
                }
            }
            if (in->next == nullptr)
            {
                return 0;
            }
            in = in->next;
        } while (in != nullptr);
    }
    return 0;
}
int numSNumCommand(char input[], int i, Node *head, int w)
{
    if (checkIfNumber(input, howLong(input), i + 4))
    {
        int l = convertToNmber(w, input, 0);
        int l1 = convertToNmber(howLong(input), input, i + 3);
        Node *in = head;
        int stop = 0;
        do
        {
            for (int j = 0; j < T; j++)
            {
                if (in->array[j] != nullptr)
                {
                    if (in->array[j]->lp == l)
                    {
                        Selectors *nows = in->array[j]->heads;
                        for (int k = 0; k < l1 - 1; k++)
                        {
                            if (nows->next == nullptr)
                            {
                                stop = 1;
                                break;
                            };
                            nows = nows->next;
                        }
                        if (stop == 1)
                        {
                            break;
                        }
                        if (nows->selectors[0] != '\000')
                        {
                            cout << l << ",S," << l1 << " == ";
                            for (int z = 0; nows->selectors[z] != '\000'; z++)
                            {
                                cout << nows->selectors[z];
                            }
                        }
                        cout << endl;
                        return 1;
                    }
                }
            }
            if (in->next == nullptr)
            {
                return 0;
            }
            in = in->next;
        } while (in != nullptr && stop == 0);
    }
    return 0;
}
int nameSQueCommand(char input[], Node *head)
{
    int h = 0;
    Node *nowin = head;
    while (nowin != nullptr)
    {
        for (int j = 0; j < T; j++)
        {
            if (nowin->array[j] != nullptr)
            {
                Selectors *nowins = nowin->array[j]->heads;
                while (nowins != nullptr)
                {
                    if (checkRepeatS(input, nowins, 1))
                    {
                        h++;
                        break;
                    }
                    nowins = nowins->next;
                }
            }
        }
        nowin = nowin->next;
    }
    for (int j = 0; input[j] != ','; j++)
    {
        cout << input[j];
    }
    cout << ",S,? == " << h << endl;
    return 1;
}
int commandS(char input[], int i, Node *head, int w)
{
    if (input[i + 1] == 'S')
    {
        if (checkIfNumber(input, i, 0))
        {
            if (input[i + 3] == '?')
            {
                if (numSQueCommand(input, i, head, w))
                {
                    return 1;
                }
            }
            else if (checkIfNumber(input, howLong(input), i + 4))
            {
                if (numSNumCommand(input, i, head, w))
                {
                    return 1;
                }
            }
        }
        else if (input[i + 3] == '?')
        {
            if (nameSQueCommand(input, head))
            {
                return 1;
            }
        }
    }
    return 0;
}
int numAQueCommand(char input[], int w, Node *head)
{
    int l = convertToNmber(w, input, 0);
    Node *in = head;
    while (in != nullptr)
    {
        for (int j = 0; j < T; j++)
        {
            if (in->array[j] != nullptr)
            {
                if (in->array[j]->lp == l)
                {
                    Atributes *nowa = in->array[j]->heada;
                    for (int k = 0; nowa->next != nullptr; k++)
                    {
                        nowa = nowa->next;
                    }
                    cout << l << ",A,? == " << nowa->lp << endl;
                    return 1;
                }
            }
        }
        if (in->next == nullptr)
        {
            return 0;
        }
        in = in->next;
    }
    return 0;
}
int numANameCommand(char input[], int i, int w, Node *head)
{
    char n[30] = {0};
    for (int k = 0; input[k + i + 3] != '\000'; k++)
    {
        n[k] = input[k + i + 3];
    }
    int l = convertToNmber(w, input, 0);
    Node *nowin = head;
    int stop = 0;
    while (nowin != nullptr && stop == 0)
    {
        for (int j = 0; j < T; j++)
        {
            if (nowin->array[j] != nullptr)
            {
                if (nowin->array[j]->lp == l)
                {
                    Atributes *nowina = nowin->array[j]->heada;
                    int o = 0;
                    for (int k = 0; (n[k] != '\000'); k++)
                    {
                        if (nowina->atributes[0][k] == ' ')
                        {
                            o = 1;
                        }
                        if (n[k + 1] == '\000' && nowina->atributes[0][k + 1 + o] != '\000')
                        {
                            stop = 1;
                            break;
                        }
                        if (n[k] != nowina->atributes[0][k + o])
                        {
                            if (nowina->next == nullptr)
                            {
                                stop = 1;
                                break;
                            }
                            nowina = nowina->next;
                            k = 0;
                        }
                    }
                    if (stop == 1)
                    {
                        break;
                    }
                    cout << l << ",A,";
                    for (int z = 0; n[z] != '\000'; z++)
                    {
                        cout << n[z];
                    }
                    cout << " == ";
                    for (int z = 0; nowina->atributes[1][z] != '\000'; z++)
                    {
                        cout << nowina->atributes[1][z];
                    }
                    cout << endl;
                    return 1;
                }
            }
        }
        if (nowin->next == nullptr)
        {
            return 0;
        }
        nowin = nowin->next;
    }
    return 0;
}
int nameAQueCommand(char input[], Node *head)
{
    int h = 0;
    Node *nowin = head;
    while (nowin != nullptr)
    {
        for (int j = 0; j < T; j++)
        {
            if (nowin->array[j] != nullptr)
            {
                Atributes *nowina = nowin->array[j]->heada;
                while (nowina != nullptr)
                {
                    if (checkRepeatA(input, nowina, 1))
                    {
                        h++;
                    }
                    nowina = nowina->next;
                }
            }
        }
        nowin = nowin->next;
    }
    for (int j = 0; input[j] != ','; j++)
    {
        cout << input[j];
    }
    cout << ",A,? == " << h << endl;
    return 1;
}
int commandA(char input[], int i, Node *head, int w)
{
    if (input[i + 1] == 'A')
    {
        if (checkIfNumber(input, i, 0))
        {
            if (input[i + 3] == '?')
            {
                if (numAQueCommand(input, w, head))
                {
                    return 1;
                }
            }
            else
            {
                if (numANameCommand(input, i, w, head))
                {
                    return 1;
                }
            }
        }
        else if (input[i + 3] == '?')
        {
            if (nameAQueCommand(input, head))
            {
                return 1;
            }
        }
    }
    return 0;
}
int commandE(char input[], int i, Node *tail)
{
    if (input[i + 1] == 'E')
    {
        int stop = 0;
        Node *nowin = tail;
        while (nowin != nullptr)
        {
            for (int j = T - 1; j >= 0; j--)
            {
                if (nowin->array[j] != nullptr)
                {
                    if ((nowin->array[j])->heads == nullptr || (nowin->array[j])->heada == nullptr)
                    {
                        nowin->array[j] = nullptr;
                        break;
                    }
                    Selectors *nowins = nowin->array[j]->heads;
                    if (checkRepeatS(input, nowins, 1))
                    {
                        Atributes *nowina = nowin->array[j]->heada;
                        char n[30] = {0};
                        for (int k = 0; input[k + i + 3] != '\000'; k++)
                        {
                            n[k] = input[k + i + 3];
                        }
                        while (nowina != nullptr)
                        {
                            if (checkRepeatA(n, nowina, 1))
                            {
                                stop = 1;
                                for (int k = 0; input[k] != ','; k++)
                                {
                                    cout << input[k];
                                }
                                cout << ",E,";
                                for (int z = 0; n[z] != '\000'; z++)
                                {
                                    cout << n[z];
                                }
                                cout << " == ";
                                for (int k = 0; nowina->atributes[1][k] != '\000'; k++)
                                {
                                    cout << nowina->atributes[1][k];
                                }
                                cout << endl;
                                return 1;
                            }
                            nowina = nowina->next;
                        }
                        if (stop == 1)
                        {
                            break;
                        }
                    }
                    nowins = nowins->next;
                }
            }
            if (stop == 1)
            {
                break;
            }
            nowin = nowin->previous;
        }
    }
    return 0;
}
int numDStarCommand(char input[], int i, int l, Node *&head, int &lp, Node *nowin, int k, Node *&tail)
{
    if (input[i + 3] == '*')
    {
        Node *nowin1 = head;
        for (int s = 0; s < T; s++)
        {
            if (nowin1 != nullptr)
            {
                if (nowin1->array[s] != nullptr)
                {
                    if (nowin1->array[s]->lp >= l)
                    {
                        nowin1->array[s]->lp--;
                    }
                }
                if (s == T - 1)
                {
                    nowin1 = nowin1->next;
                    s = -1;
                }
            }
        }
        nowin->array[k] = nullptr;
        nowin->number--;
        cout << l << ",D,* == deleted" << endl;
        lp--;
        if (nowin->number == 0)
        {
            deleteNode(&head, nowin, &head);
            if (head != nullptr)
            {
                Node *last = head;
                while (last->next != nullptr)
                {
                    last = last->next;
                }
                tail = last;
            }
        }
        return 1;
    }
    return 0;
}
int numDNameCommand(char input[], Node *&nowin, int k, int i, int &lp, Node *head, int l)
{
    Atributes *nowina = nowin->array[k]->heada;
    Atributes *nowina1 = nowin->array[k]->heada;
    char n[30] = {0};
    for (int h = 0; input[h + i + 3] != '\000'; h++)
    {
        n[h] = input[h + i + 3];
    }
    while (nowina != nullptr)
    {
        if (checkRepeatA(n, nowina, 1))
        {
            nowina1->next = nowina->next;
            if (nowina->lp == 1)
            {
                nowin->array[k]->heada = nowina->next;
            }
            nowina1 = nowina1->next;
            while (nowina1 != nullptr)
            {
                nowina1->lp--;
                nowina1 = nowina1->next;
            }
            if (nowina->lp == 1 && nowina->next == nullptr)
            {
                lp--;
                Node *nowin1 = head;
                for (int s = 0; s < T; s++)
                {
                    if (nowin1 != nullptr)
                    {
                        if (nowin1->array[s] != nullptr)
                        {
                            if (nowin1->array[s]->lp >= nowin->array[k]->lp)
                            {
                                nowin1->array[s]->lp--;
                            }
                        }
                        if (s == T - 1)
                        {
                            nowin1 = nowin1->next;
                            s = -1;
                        }
                    }
                }
                nowin->array[k] = nullptr;
                delete nowin->array[k];
            }
            delete nowina;
            cout << l << ",D,";
            for (int z = 0; n[z] != '\000'; z++)
            {
                cout << n[z];
            }
            cout << " == deleted" << endl;
            return 1;
        }
        nowina1 = nowina;
        nowina = nowina->next;
    }
    return 0;
}
int commandD(char input[], int i, Node *&head, int &lp, int w, Node *&tail)
{
    if (input[i + 1] == 'D')
    {
        if (checkIfNumber(input, i, 0))
        {
            int l = convertToNmber(w, input, 0);
            Node *nowin = head;
            for (int k = 0; k < T; k++)
            {
                if (nowin != nullptr)
                {
                    if (nowin->array[k] != nullptr)
                    {
                        if (nowin->array[k]->lp == l)
                        {
                            if (numDStarCommand(input, i, l, head, lp, nowin, k, tail))
                            {
                                return 1;
                            }
                            else if (numDNameCommand(input, nowin, k, i, lp, head, l))
                            {
                                return 1;
                            }
                        }
                    }
                    if (k == T - 1)
                    {
                        nowin = nowin->next;
                        k = -1;
                    }
                }
            }
        }
    }
    return 0;
}