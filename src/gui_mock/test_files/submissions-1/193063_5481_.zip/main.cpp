#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#define T 19
using namespace std;

class String {
private:
	char* data;
	size_t length;

public:
	String(const char* value = "") {
		length = std::strlen(value);
		data = new char[strlen(value) + 1];
		strcpy(data, value);
	}

	String(const String& other) {
		length = other.length;
		data = new char[strlen(other.data) + 1];
		strcpy(data, other.data);
	}

	~String() {
		delete[] data;
	}

	String& operator=(const String& other) {
		if (this != &other) {
			delete[] data;
			length = other.length;
			data = new char[strlen(other.data) + 1];
			strcpy(data, other.data);
		}
		return *this;
	}

	bool operator==(const String& other) const {
		if (data == nullptr || other.data == nullptr) {
			return false;
		}
		return (std::strcmp(data, other.data) == 0);
	}

	bool operator!=(const String& other) const {
		return std::strcmp(data, other.data) != 0;
	}

	char& operator[](size_t index) {
		return data[index];
	}

	const char& operator[](size_t index) const {
		return data[index];
	}
	size_t size() const {
		return length;
	}

	friend std::ostream& operator<<(std::ostream& os, const String& str) {
		os << str.data;
		return os;
	}
	void erase(size_t pos, size_t count) {
		if (pos >= length || count == 0) {
			return;
		}

		if (pos + count > length) {
			count = length - pos;
		}

		for (size_t i = pos; i < length - count; ++i) {
			data[i] = data[i + count];
		}

		length -= count;
		data[length] = '\0';
	}
	void append(char c) {

		int lengthx = strlen(data);
		char* newBuffer = new char[lengthx + 2];
		strcpy(newBuffer, data);
		newBuffer[lengthx] = c;
		newBuffer[lengthx + 1] = '\0';
		delete[] data;
		data = newBuffer;
		length++;
	}
	char* c_str() const {
		return data;
	}
};
int my_stoi(const String& str) {
	int result = 0;
	bool negative = false;

	// check for negative sign
	if (str[0] == '-') {
		negative = true;
	}

	// iterate over digits and accumulate result
	for (int i = (negative ? 1 : 0); i < str.size(); i++) {
		char c = str[i];
		if (c >= '0' && c <= '9') {
			result = result * 10 + (c - '0');
		}
	}

	// apply negative sign if necessary
	if (negative) {
		result *= -1;
	}

	return result;
}
bool isNumber(const String& str) {
	for (int i = 0; i < str.size(); i++) {
		char c = str[i];
		if (c < '0' || c > '9') {
			return false;
		}
	}
	return true;
}

template <typename Type>
class Node {
public:
	int size = 0;
	int actualSize = 0;
	Node* next;
	Node* prev;
	Type* tablica[T] = { nullptr };

	Node(Type* value, Node* prev, Node* next) {
		this->next = next;
		this->prev = prev;
		tablica[0] = value;
		size++;
		actualSize++;
	}
	~Node() {
		for (int i = 0; i < size; i++) {
			delete tablica[i];
		}
	}
};

template <typename Type>
class DoubleList {
public:
	Node<Type>* head;
	Node<Type>* tail;
	bool Empty;
	DoubleList() : head(nullptr), tail(nullptr), Empty(true) {}
	DoubleList(Node<Type>* head, Node<Type>* tail, bool Empty) {
		this->head = head;
		this->tail = tail;
		this->Empty = Empty;
	}
	~DoubleList() {
		Node<Type>* current = head;
		while (current != nullptr) {
			Node<Type>* next = current->next;
			delete current;
			current = next;
		}
	}
	void push_back(Type* value) {
		if (Empty == true) {
			Node<Type>* node = new Node<Type>(value, nullptr, nullptr);
			head = node;
			tail = node;
			Empty = false;
		}
		else {
			if (tail->size < T) {
				tail->tablica[tail->size] = value;
				tail->size++;
			}
			else {
				Node<Type>* node = new Node<Type>(value, nullptr, nullptr);
				tail->next = node;
				node->prev = tail;
				tail = node;
			}
		}
	}
};

struct Attribute {
	String name;
	String value;
};

struct Selector {
	String name;
};

class Section {
public:
	DoubleList<Selector>SelectorsList;
	DoubleList<Attribute>AttributesList;
	Section() :SelectorsList(nullptr, nullptr, true), AttributesList(nullptr, nullptr, true) {
	}

};

void numberOfSections(int number);
void numberOfSelectors(int sectionNumber, DoubleList<Section>& SectionsList, int number);
void numberOfAttributes(int sectionNumber, DoubleList<Section>& SectionsList, int number, int deleted);
void outNameOfSelector(int selectorNumber, int sectionNumber, int number, DoubleList<Section>& SectionsList);
void outValueOfAttribute(int sectionNumber, String attributeName, int number, DoubleList<Section>& SectionsList);
void isDuplicate(String attributeName, Section*& Section, bool& duplicate);
void changeValueDuplicate(String duplicateName, Section*& Section, String value);
void numberOfNameAttribute(DoubleList<Section>& SectionsList, String attributeName);
void numberOfNameSelector(DoubleList<Section>& SectionsList, String selectorName);
void outValueOfAttributeForSelector(DoubleList<Section>& SectionsList, String selectorName, String attributeName);
void readCSS(DoubleList<Section>& SectionsList, int& number, char& c, String& s, int& ind, int& back, bool& duplicate);
void deleteSection(DoubleList<Section>& SectionsList, int sectionNumber, int& number, int& deleted);
void deleteAttribute(DoubleList<Section>& SectionsList, int sectionNumber, String attributeName, int& number, int& deleted);
void checkIfEmpty(DoubleList<Section>& SectionsList, int sectionNumber, int nodeNumber, int actualNumber, int& number, int& deleted);

int main() {
	int deleted = 0;
	int number = 0;
	bool duplicate = false;
	DoubleList<Section>SectionsList;
	int ind = 0;
	int back = 0;
	String s, first, command, third;
	char c = (char)getchar();
	readCSS(SectionsList, number, c, s, ind, back, duplicate);



	while (c != EOF) {
		while (c != '\n' && c != EOF && c != '\t') {
			if (c != '?' && c != '*') {
				while (c != ',' && command.size() != 3) {
					first.append(c);
					c = (char)getchar();
				}
				while (command.size() != 3) {
					command.append(c);
					c = (char)getchar();
				}
				third.append(c);
				c = (char)getchar();

			}
			else {
				if (first == "") {
					c = (char)getchar();
					s.append(c);
				}
				else {
					c = (char)getchar();
					third.append(c);
				}
			}

		}
		if (s == "?") {
			numberOfSections(number);
			s = "";
		}
		if (s == "?\n") {
			numberOfSections(number);
			s = "";
		}

		if (s == "??\n") {
			s = "";
		}
		if (s == "???\n") {
			s = "";
		}
		if (s == "****\n") {
			readCSS(SectionsList, number, c, s, ind, back, duplicate);
		}
		if (command == ",S," && third != "?") {
			int num1 = my_stoi(third);
			int num2 = my_stoi(first);
			outNameOfSelector(num1, num2, number, SectionsList);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",S," && isNumber(first)) {
			int num1 = my_stoi(first);
			numberOfSelectors(num1, SectionsList, number);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",S," && !isNumber(first)) {
			numberOfNameSelector(SectionsList, first);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",A," && third != "?") {
			int num = my_stoi(first);
			outValueOfAttribute(num, third, number, SectionsList);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",A," && isNumber(first)) {
			int num = my_stoi(first);
			numberOfAttributes(num, SectionsList, number, deleted);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",A," && !isNumber(first)) {
			numberOfNameAttribute(SectionsList, first);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",E,") {
			outValueOfAttributeForSelector(SectionsList, first, third);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command != ",E," && command != ",A," && command != ",S," && command != ",D,") {
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",D," && third == "*") {
			deleteSection(SectionsList, my_stoi(first), number, deleted);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (command == ",D," && third != "*") {
			deleteAttribute(SectionsList, my_stoi(first), third, number, deleted);
			first = "";
			command = "";
			third = "";
			s = "";
		}
		if (c == EOF && number<3) {
			numberOfSections(number);
			s = "";
		}
		c = (char)getchar();
		
		s.append(c);
	}
	return 0;
}

void numberOfSections(int number) {
	std::cout << "? == " << number << endl;
}

void numberOfSelectors(int sectionNumber, DoubleList<Section>& SectionsList, int number) {
	int output = 0;
	int nodeNumber = 0;
	int sekcja = 0;
	int j = 0;
	int i = 0;



	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Selector>* curr1 = curr->tablica[i]->SelectorsList.head;
						while (curr1 != NULL) {
							j = 0;
							while (j < T) {
								if (curr1->tablica[j] != nullptr) {
									if (curr1->tablica[j]->name == "") {
										std::cout << sectionNumber << ",S,? == " << "0" << endl;
										return;
									}
									output++;
									j++;

								}
								else {
									break;
								}
							}
							curr1 = curr1->next;
						}
						std::cout << sectionNumber << ",S,? == " << output << endl;
						return;
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}
}

void numberOfAttributes(int sectionNumber, DoubleList<Section>& SectionsList, int number, int deleted) {
	int output = 0;
	int nodeNumber = 0;
	int sekcja = 0;
	int j = 0;
	int i = 0;



	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Attribute>* curr3 = curr->tablica[i]->AttributesList.head;
						while (curr3 != NULL) {
							while (j < T) {
								if (curr3->tablica[j] != nullptr) {
									if (curr3->tablica[j]->name != "usuniete") {
										output++;
									}
									j++;

								}
								else {
									break;
								}
							}
							j = 0;
							curr3 = curr3->next;
						}
						std::cout << sectionNumber << ",A,? == " << output << endl;
						return;
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}
}

void outNameOfSelector(int selectorNumber, int sectionNumber, int number, DoubleList<Section>& SectionsList) {
	String output;
	int sekcja = 0;
	int j = 0;
	int i = 0;
	int k = 0;
	int nodeSelectorNumber = selectorNumber / 7;
	if (selectorNumber % 8 == 0) {
		nodeSelectorNumber = (selectorNumber / T) - 1;
	}
	else {
		nodeSelectorNumber = selectorNumber / T;
	}
	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Selector>* curr5 = curr->tablica[i]->SelectorsList.head;
						for (int k = 0; k < nodeSelectorNumber; k++) {
							curr5 = curr5->next;
							if (curr5 == NULL) {
								//std::cout << "Error: list is too short." << endl;
								return;
							}
						}
						while (j < selectorNumber - 1) {
							if (curr5->tablica[j] != NULL) {
								j++;
							}
							if (curr5->tablica[j] == NULL) {
								return;
							}
						}
						if (curr5->tablica[j]->name == "") {
							return;
						}
						std::cout << sectionNumber << ",S," << selectorNumber << " == " << curr5->tablica[j]->name << endl;
						return;
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}

}

void outValueOfAttribute(int sectionNumber, String attributeName, int number, DoubleList<Section>& SectionsList) {

	String output;
	int sekcja = 0;
	int j = 0;
	int i = 0;
	int k = 0;

	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i] != NULL && curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Attribute>* curr3 = curr->tablica[i]->AttributesList.head;
						while (curr3 != NULL) {
							while (j < T) {
								if (curr3->tablica[j] != nullptr) {
									if (curr3->tablica[j]->name == attributeName) {
										std::cout << sectionNumber << ",A," << attributeName << " == " << curr3->tablica[j]->value << endl;
										return;
									}
									else {
										j++;
									}
								}
								else {
									break;
								}
							}
							j = 0;
							curr3 = curr3->next;
						}
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}

}

void isDuplicate(String attributeName, Section*& Section, bool& duplicate) {
	int j = 0;
	Node<Attribute>* curr = Section->AttributesList.head;
	while (curr != NULL) {
		while (j < T) {
			if (curr->tablica[j] != nullptr) {
				if (curr->tablica[j]->name == attributeName) {
					duplicate = true;
					return;
				}
			}
			else {
				j = 0;
				break;
			}
			j++;
		}
		j = 0;
		curr = curr->next;

	}
}

void changeValueDuplicate(String duplicateName, Section*& Section, String value) {
	int j = 0;
	Node<Attribute>* curr = Section->AttributesList.head;
	while (curr != NULL) {
		while (j < T) {
			if (curr->tablica[j] != nullptr) {
				if (curr->tablica[j]->name == duplicateName) {
					curr->tablica[j]->value = value;
					return;
				}
				j++;
			}
			else {
				break;
				j = 0;
			}

		}
		j = 0;
		curr = curr->next;
	}
}

void numberOfNameAttribute(DoubleList<Section>& SectionsList, String attributeName) {
	int i = 0;
	int j = 0;
	int counter = 0;
	Node<Section>* curr = SectionsList.head;
	while (curr != NULL) {
		while (i < T) {
			if (curr->tablica[i] != NULL) {
				Node<Attribute>* curr1 = curr->tablica[i]->AttributesList.head;
				while (curr1 != NULL) {
					while (j < T) {
						if (curr1->tablica[j] != NULL && curr1->tablica[j]->name == attributeName) {
							counter++;
						}
						j++;
					}
					j = 0;
					curr1 = curr1->next;
				}


			}
			i++;
		}
		i = 0;
		curr = curr->next;

	}
	std::cout << attributeName << ",A,? == " << counter << endl;
}

void numberOfNameSelector(DoubleList<Section>& SectionsList, String selectorName) {

	int i = 0;
	int j = 0;
	int counter = 0;
	Node<Section>* curr = SectionsList.head;
	while (curr != NULL) {
		while (i < T) {
			if (curr->tablica[i] != NULL) {
				Node<Selector>* curr1 = curr->tablica[i]->SelectorsList.head;
				while (curr1 != NULL) {
					while (j < T) {
						if (curr1->tablica[j] != NULL && curr1->tablica[j]->name == selectorName) {
							counter++;
						}
						j++;
					}
					j = 0;
					curr1 = curr1->next;
				}
			}
			i++;
		}
		i = 0;
		curr = curr->next;

	}
	std::cout << selectorName << ",S,? == " << counter << endl;

}

void outValueOfAttributeForSelector(DoubleList<Section>& SectionsList, String selectorName, String attributeName) {
	int i = 0;
	int j = 0;
	int k = 0;
	String output = "";
	Node<Section>* curr = SectionsList.head;
	while (curr != NULL) {
		while (i < T) {
			if (curr->tablica[i] != NULL) {
				Node<Selector>* curr1 = curr->tablica[i]->SelectorsList.head;
				while (curr1 != NULL) {
					while (j < T) {
						if (curr1->tablica[j] != NULL && curr1->tablica[j]->name == selectorName) {
							Node<Attribute>* curr2 = curr->tablica[i]->AttributesList.head;
							while (curr2 != NULL) {
								while (k < T) {
									if (curr2->tablica[k] != NULL && curr2->tablica[k]->name == attributeName) {
										output = curr2->tablica[k]->value;
									}
									k++;
								}
								k = 0;
								curr2 = curr2->next;

							}
						}
						j++;
					}
					j = 0;
					curr1 = curr1->next;
				}


			}
			i++;
		}
		i = 0;
		curr = curr->next;

	}
	if (output == "") {
		return;
	}
	else {
		std::cout << selectorName << ",E," << attributeName << " == " << output << endl;
	}

}

void readCSS(DoubleList<Section>& SectionsList, int& number, char& c, String& s, int& ind, int& back, bool& duplicate) {
	while (c != '?') {
		if (c != '\t' && c != '\n' && c != '\f' && c != '\r') {
			s = "";
			Section* section = new Section;
			number++;
			//std::cout << number << endl;
			while (c != '{') {
				if (c == ',') {
					for (int i = 0; i <= s.size() - 1; i++) {
						if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != '\t') {
							ind = i;
							break;
						}
					}
					for (int i = s.size() - 1; i >= 0; i--) {
						if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != '\t') {
							back = i;
							break;
						}
					}
					for (int i = s.size() - 1; i >= back; i--) {
						if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == '\t') {
							s.erase(i, 1);
						}
					}
					for (int i = 0; i < ind; i++) {
						if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == '\t') {
							s.erase(0, 1);
						}
					}
					for (int i = s.size() - 1; i >= 0; --i) {
						if (s[i] == '\n') {
							s.erase(i, 1);
						}
					}
					Selector* selector = new Selector;
					selector->name = s;
					section->SelectorsList.push_back(selector);
					s = "";
					c = (char)getchar();
				}
				s.append((char)c);
				c = (char)getchar();
			}
			for (int i = 0; i <= s.size() - 1; i++) {
				if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != '\t') {
					ind = i;
					break;
				}
			}
			for (int i = s.size() - 1; i >= 0; i--) {
				if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != '\t') {
					back = i;
					break;
				}
			}
			for (int i = s.size() - 1; i >= back; i--) {
				if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == '\t') {
					s.erase(i, 1);
				}
			}
			for (int i = 0; i < ind; i++) {
				if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == '\t') {
					s.erase(0, 1);
				}
			}
			for (int i = s.size() - 1; i >= 0; --i) {
				if (s[i] == '\n') {
					s.erase(i, 1);
				}
			}
			Selector* selector = new Selector;
			selector->name = s;
			section->SelectorsList.push_back(selector);

			s = "";
			c = (char)getchar();
			while (c != '}' && c != '?' && c != ';' && c != '\r' && c != '\v') {
				if (c == ':') {
					for (int i = 0; i <= s.size() - 1; i++) {
						if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != ';') {
							ind = i;
							break;
						}
					}
					for (int i = s.size() - 1; i >= 0; i--) {
						if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != '\;') {
							back = i;
							break;
						}
					}
					for (int i = s.size() - 1; i >= back; i--) {
						if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == ';') {
							s.erase(i, 1);
						}
					}
					for (int i = 0; i < ind; i++) {
						if (s[0] == ' ' || s[0] == '\n' || s[0] == '{' || s[0] == '}' || s[0] == ';') {
							s.erase(0, 1);
						}
					}
					for (int i = s.size() - 1; i >= 0; --i) {
						if (s[i] == '\n') {
							s.erase(i, 1);
						}
						for (int i = 0; i <= s.size() - 1; i++) {
							if (s[i] == '\t') {
								s.erase(i, 1);
							}
						}
					}
					isDuplicate(s, section, duplicate);
					if (duplicate == false) {
						Attribute* attribute = new Attribute;
						attribute->name = s;
						s = "";
						c = (char)getchar();
						while (c != ';' && c != '}' && c != '\t') {
							s.append((char)c);
							c = (char)getchar();
						}
						for (int i = 0; i <= s.size() - 1; i++) {
							if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != ';' && s[i] != '\t') {
								ind = i;
								break;
							}
						}
						for (int i = s.size() - 1; i >= 0; i--) {
							if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != ';' && s[i] != '\t') {
								back = i;
								break;
							}
						}
						for (int i = s.size() - 1; i >= back; i--) {
							if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == ';' || s[i] == '\t') {
								s.erase(i, 1);
							}
						}
						for (int i = 0; i < ind; i++) {
							if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == ';' || s[i] == '\t') {
								s.erase(0, 1);
							}
						}
						for (int i = 0; i <= s.size() - 1; i++) {
							if (s[i] == '\t') {
								s.erase(i, 1);
							}
						}
						attribute->value = s;
						//cout << s << endl;
						section->AttributesList.push_back(attribute);
						s = "";
					}
					else {
						String nameduplicate;
						nameduplicate = s;
						s = "";
						c = (char)getchar();
						while (c != ';' && c != '}' && c != '\t') {
							s.append((char)c);
							c = (char)getchar();
						}
						for (int i = 0; i <= s.size() - 1; i++) {
							if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != ';' && s[i] != '\t') {
								ind = i;
								break;
							}
						}
						for (int i = s.size() - 1; i >= 0; i--) {
							if (s[i] != ' ' && s[i] != '{' && s[i] != '}' && s[i] != '\n' && s[i] != ';' && s[i] != '\t') {
								back = i;
								break;
							}
						}
						for (int i = s.size() - 1; i >= back; i--) {
							if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' && s[i] == ';' || s[i] == '\t') {
								s.erase(i, 1);
							}
						}
						for (int i = 0; i < ind; i++) {
							if (s[i] == ' ' || s[i] == '\n' || s[i] == '{' || s[i] == '}' || s[i] == ';' || s[i] == '\t') {
								s.erase(0, 1);
							}
						}
						for (int i = 0; i <= s.size() - 1; i++) {
							if (s[i] == '\t') {
								s.erase(i, 1);
							}
						}
						changeValueDuplicate(nameduplicate, section, s);
						s = "";
						c = (char)getchar();
						//std::cout << c;
						duplicate = false;
					}
				}
				s.append(c);
				c = (char)getchar();
				//std::cout << c;
			}
			s = "";
			SectionsList.push_back(section);
			c = (char)getchar();
			//std::cout << c;
		}
		c = (char)getchar();
		//std::cout << c;

	}
}

void deleteSection(DoubleList<Section>& SectionsList, int sectionNumber, int& number, int& deleted) {


	int sekcja = 0;
	int j = 0;
	int i = 0;
	int k = 0;



	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Attribute>* curr3 = curr->tablica[i]->AttributesList.head;
						Node<Selector>* curr4 = curr->tablica[i]->SelectorsList.head;
						while (curr3 != NULL) {
							while (j < T) {
								if (curr3->tablica[j] != nullptr) {
									curr3->tablica[j]->name = "usuniete";
									curr3->tablica[j]->value = "usuniete";
									j++;
								}
								else {
									break;
								}
							}
							curr3 = curr3->next;
						}
						while (curr4 != NULL) {
							while (k < T) {
								if (curr4->tablica[k] != nullptr) {

									curr4->tablica[k]->name = "usuniete";
									k++;
								}
								else {
									break;
								}
							}

							curr4 = curr4->next;
						}
						deleted++;
						number--;
						std::cout << sectionNumber << ",D,* == deleted" << endl;
						return;
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}

}

void checkIfEmpty(DoubleList<Section>& SectionsList, int sectionNumber, int nodeNumber, int actualNumber, int& number, int& deleted) {



	int sekcja = 0;
	int j = 0;
	int i = 0;
	int k = 0;
	int w = 0;
	int count = 0;



	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i] != NULL && curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Attribute>* curr7 = curr->tablica[i]->AttributesList.head;
						while (curr7 != NULL) {
							while (w < T) {
								if (curr7->tablica[w] != nullptr) {
									if (curr7->tablica[w]->name == "usuniete") {
										count++;

									}
									w++;
								}
								else {
									break;
								}
							}
							curr7 = curr7->next;
						}
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}
		if (count == w) {
			int sekcja = 0;
			int j = 0;
			int i = 0;
			int k = 0;



			if (sectionNumber <= number) {
				Node<Section>* curr = SectionsList.head;
				while (curr != NULL) {
					while (i < T) {
						if (curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
							sekcja++;
							if (sekcja == sectionNumber) {
								Node<Attribute>* curr3 = curr->tablica[i]->AttributesList.head;
								Node<Selector>* curr4 = curr->tablica[i]->SelectorsList.head;
								while (curr3 != NULL) {
									while (j < T) {
										if (curr3->tablica[j] != nullptr) {
											curr3->tablica[j]->name = "usuniete";
											curr3->tablica[j]->value = "usuniete";
											j++;
										}
										else {
											break;
										}
									}
									curr3 = curr3->next;
								}
								while (curr4 != NULL) {
									while (k < T) {
										if (curr4->tablica[k] != nullptr) {

											curr4->tablica[k]->name = "usuniete";
											k++;
										}
										else {
											break;
										}
									}

									curr4 = curr4->next;
								}
								deleted++;
								number--;
								return;
							}
						}
						i++;
					}
					i = 0;
					curr = curr->next;
				}

			}
			else {
				return;
			}
		}

	}
	else {
		return;
	}
}

void deleteAttribute(DoubleList<Section>& SectionsList, int sectionNumber, String attributeName, int& number, int& deleted) {



	int actualNumber = 0;
	int nodeNumber = 0;
	int sekcja = 0;
	int j = 0;
	int i = 0;
	int k = 0;



	if (sectionNumber <= number) {
		Node<Section>* curr = SectionsList.head;
		while (curr != NULL) {
			while (i < T) {
				if (curr->tablica[i] != NULL && curr->tablica[i]->SelectorsList.head->tablica[0]->name != "usuniete") {
					sekcja++;
					if (sekcja == sectionNumber) {
						Node<Attribute>* curr3 = curr->tablica[i]->AttributesList.head;
						while (curr3 != NULL) {
							while (j < T) {
								if (curr3->tablica[j] != nullptr) {
									if (curr3->tablica[j]->name == attributeName) {
										curr3->tablica[j]->name = "usuniete";
										curr3->tablica[j]->value = "usuniete";
										std::cout << sectionNumber << ",D," << attributeName << " == deleted" << endl;
										checkIfEmpty(SectionsList, sectionNumber, nodeNumber, actualNumber, number, deleted);
										return;
									}
									else {
										j++;
									}
								}
								else {
									break;
								}
							}
							curr3 = curr3->next;
						}
					}
				}
				i++;
			}
			i = 0;
			curr = curr->next;
		}

	}
	else {
		return;
	}
}