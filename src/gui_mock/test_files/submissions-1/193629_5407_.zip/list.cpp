#include "list.h"
#include <iostream>


using namespace std;


    Node::Node(static Section d) {
        data = new Section();
        data[0] = d;
        next = nullptr;
        prev = nullptr;
    }

    Section* Node::getData() {
        return data;
    }
    void Node::setData(Section d, int i) {
        data[i] = d;
    }
    void Node::deleteData(int i) {
        
    }


    List::List() {
        head = nullptr;
        tail = nullptr;
    }

    void List::addElement(Section d) {
        if (tail == nullptr || tail->counter >= T) {
            Node* new_node = new Node(d);
                if (head == nullptr) {
                    head = new_node;
                    tail = new_node;
                }
                else {
                    tail->next = new_node;
                    new_node->prev = tail;
                    tail = new_node;
                }
                tail->counter++;
        }
        else {
            tail->setData(d, ++tail->counter);
        }
    }

    void List::removeElement(int n) {
        Node* curr_node = head;
        int i = 0;
        while (curr_node != nullptr) {
            if (i < n && (curr_node->next == nullptr || curr_node->next->counter + i >= n)) {
                for (int j = 0; j < curr_node->counter; j++, i++) {
                    if (i == n) {
                        curr_node->deleteData(j);
                        curr_node->counter--;
                        if (curr_node->counter == 0) {
                            if (curr_node == head && curr_node == tail) {
                                head = nullptr;
                                tail = nullptr;
                            }
                            else if (curr_node == head) {
                                head = curr_node->next;
                                head->prev = nullptr;
                            }
                            else if (curr_node == tail) {
                                tail = curr_node->prev;
                                tail->next = nullptr;
                            }
                            else {
                                curr_node->prev->next = curr_node->next;
                                curr_node->next->prev = curr_node->prev;
                            }
                            delete curr_node;
                        }
                        return;
                    }
                }
            }
        }          
    }