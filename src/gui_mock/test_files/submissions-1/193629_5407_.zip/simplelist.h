#pragma once
#include"attributes.h"
#include <stdio.h>
#include <string.h>
   

class SimpleNode {
public:
    char sel[32];
    Attributes atr;
    SimpleNode* next;
    SimpleNode* prev;
    SimpleNode(const char* d);
    SimpleNode(const Attributes d);
};


class SimpleList {
public:
    SimpleNode* head;
    SimpleNode* tail;
    SimpleList();

    int addNode(char* d);
    void addNode(Attributes d);

    void removeAtr(char* d);
    void removeSel(char* d);
};