#pragma once
#include"simplelist.h"

class Section
{
public:
	SimpleList attributes;
	SimpleList selectors;
};

