#include"simplelist.h"


SimpleNode::SimpleNode(const Attributes d) {
        atr = d;
        next = nullptr;
        prev = nullptr;
    }
SimpleNode::SimpleNode(const char* d) {
    strcpy_s(sel, d);
    next = nullptr;
    prev = nullptr;
}


SimpleList::SimpleList() {
        head = nullptr;
        tail = nullptr;
    }

    int SimpleList::addNode(char* d) {
        if (d[0] == 0) return 1;
        SimpleNode* new_node = new SimpleNode(d);
        if (head == nullptr) {
            head = new_node;
            tail = new_node;
        }
        else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
        return 0;
    }

    void SimpleList::addNode(Attributes d) {
        SimpleNode* new_node = new SimpleNode(d);
        if (head == nullptr) {
            head = new_node;
            tail = new_node;
        }
        else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
    }

    void SimpleList::removeAtr(char* d) {
        SimpleNode* curr_node = head;
        while (curr_node != nullptr) {
            if (curr_node->atr.name == d) {
                if (curr_node == head && curr_node == tail) {
                    head = nullptr;
                    tail = nullptr;
                }
                else if (curr_node == head) {
                    head = curr_node->next;
                    head->prev = nullptr;
                }
                else if (curr_node == tail) {
                    tail = curr_node->prev;
                    tail->next = nullptr;
                }
                else {
                    curr_node->prev->next = curr_node->next;
                    curr_node->next->prev = curr_node->prev;
                }
                delete curr_node;
                return;
            }
            curr_node = curr_node->next;
        }
    }
    void SimpleList::removeSel(char* d) {
        SimpleNode* curr_node = head;
        while (curr_node != nullptr) {
            if (curr_node->sel == d) {
                if (curr_node == head && curr_node == tail) {
                    head = nullptr;
                    tail = nullptr;
                }
                else if (curr_node == head) {
                    head = curr_node->next;
                    head->prev = nullptr;
                }
                else if (curr_node == tail) {
                    tail = curr_node->prev;
                    tail->next = nullptr;
                }
                else {
                    curr_node->prev->next = curr_node->next;
                    curr_node->next->prev = curr_node->prev;
                }
                delete curr_node;
                return;
            }
            curr_node = curr_node->next;
        }
    }