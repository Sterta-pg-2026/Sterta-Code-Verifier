#pragma once
#include <stdio.h>
#include <string.h>

class Attributes {
public:
	char name[32];
	char value[64];
	Attributes operator=(Attributes other) {
		strcpy_s(this->name, other.name);
		strcpy_s(this->value, other.value);
		return *this;
	}
};