#include<iostream>
#include"list.h"
#include"attributes.h"
#include"simplelist.h"
using namespace std;

char getWord(char* temp, List list);

int cmd_start_end(char* temp, char c) {
	for (int i = 0; i < 4; i++) {
		if (temp[i] != c) {
			return 0;
		}
	}
	return 1;
}

char cmd(char* temp, List list) {
	char A[8];
	char B[32];
	char t = 1;
	while (!cmd_start_end(temp, '*') && t != EOF) {
		do {
			t = getWord(temp, list);
		} while (temp[0] == 0 && t && t != EOF);

		if (temp[0] == '?') {
			Node* curr_node = list.head;
			int i = 0;
			while (curr_node != nullptr) {
				i += curr_node->counter;
				curr_node = curr_node->next;
			}
			cout << "? == " << i << endl;
			if (t == EOF) return t;
		}
		else {
			t = getWord(A, list);
			if (t == EOF) return t;
			t = getWord(B, list);
			if (t == EOF) return t;
		}		
	}
	return t;
}

char getWord(char* temp, List list) {
	int i = 0;
	do {
		do {
			temp[i] = getchar();
		} while (temp[0] == ' ' || temp[0] == '\n' || temp[0] == '\t' || temp[0] == '\r');
		if (!(temp[i] < '~' && temp[i] > '!' && temp[i] != '{' && temp[i] != '}' && temp[i] != ',' && temp[i] != ';' && temp[i] != ':') || temp[0] == ' ' || temp[0] == '\n' || temp[0] == '\t') break;
		i++;
	} while (1);
	char t = temp[i];
	temp[i] = 0;
	if (cmd_start_end(temp, '?')) t = cmd(temp, list);
	return t;
}

char get_attr_value(char* temp) {
	int i = 0;
	do {
		do {
			temp[i] = getchar();
		} while (temp[0] == ' ' || temp[0] == '\n' || temp[0] == '\t' || temp[0] == '\r');
		if (!(temp[i] < '~' && temp[i] > '!' && temp[i] != ';' && temp[i] != '}')) break;
		i++;
	} while (1);
	char t = temp[i];
	temp[i] = 0;
	return t;
}

void load_attributes(char* temp, List* list, char* t_ptr, Section* s) {
	char t = *t_ptr;
	Section section = *s;
	do {
		Attributes atr{};

		t = getWord(temp, *list);
		if (t == EOF || t == '}') break;
		strcpy_s(atr.name, temp);

		t = get_attr_value(temp);
		strcpy_s(atr.value, temp);
		section.attributes.addNode(atr);
	} while (t != EOF && t != '}');
}


int main()
{
	char t;
	char temp[32];
	List* list_ptr = new List();
	List list = *list_ptr;
	do {
		Section section{};
		do {
			t = getWord(temp, list);
			section.selectors.addNode(temp);
		} while (t != '{' && t != EOF);
		if (t == '{') load_attributes(temp, &list, &t, &section);
		list.addElement(section);
	} while (t != EOF);

	return 0;
}
