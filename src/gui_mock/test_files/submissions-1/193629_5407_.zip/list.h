#pragma once
#include"section.h"

class Node {
    Section* data;
public:
    Node* next;
    Node* prev;
    int counter = 0;

	Node(Section);

	Section* getData();
	void setData(Section d, int i);
    void deleteData(int i);
};

class List {
public:
    Node* head;
    Node* tail;
    const static int T = 8;
    List();

    void addElement(Section d);

    void removeElement(int n);

};

