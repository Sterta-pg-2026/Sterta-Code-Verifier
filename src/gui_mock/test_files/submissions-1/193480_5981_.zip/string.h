#pragma once
#include <iostream>

class String
{
private:
	char* data;
	size_t size;
	static char temp[10000];
public:
	String();
	String(const char* data);
	String(const char* data, size_t size);
	String(const String& other);
	void initialize(const char* data, size_t size);
	
	void initialize(const String& other, size_t fromIndex, size_t toIndex);

	String& operator=(const String& right);
	char& operator[](size_t index);
	const char& operator[](size_t index) const;
	bool operator==(const String& right) const;
	bool operator!=(const String& right) const;
	friend std::ostream& operator<<(std::ostream& ostr, const String& string);
	size_t getSize() const;
	char* getSource();
	bool tryParseInt(int& number) const;
	bool isEmptyOrWhiteSpaces() const;
	void readLine();
	void read();
	size_t find(const char* text) const;
	static bool endOfFile;
	size_t commaCount() const;
	
	~String();
};
