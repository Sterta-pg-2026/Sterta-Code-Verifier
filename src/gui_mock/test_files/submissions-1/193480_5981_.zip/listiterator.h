#pragma once
#include "listitem.h"

template <typename T> class List;

template <typename T> class ListIterator
{
private:
	ListItem<T>* item;
	int indexItem;
public:

	ListIterator(ListItem<T>* item, int index)
	{
		this->indexItem = index;
		this->item = item;
	}

	T* getValue()
	{
		return item->getData(indexItem);
	}
	void next()
	{
		indexItem++;
		if (item->getSize() == indexItem)
		{
			item = item->next;
			indexItem = 0;
		}
	}
	void prev()
	{
		indexItem--;
		if (indexItem < 0)
		{
			item = item->prev;
			if(item != nullptr)
			{
				indexItem = item->getSize() - 1;
			}
		}
		
	}
	bool hasValue() const
	{
		return item != nullptr;
	}

	friend class List<T>;

};

