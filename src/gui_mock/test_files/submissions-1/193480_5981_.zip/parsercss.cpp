﻿#include <iostream>
#include "string.h"
#include "stringbuilder.h"

using namespace std;

struct Attribute {
	String name;
	String value;
};

struct Section {
	List<String>* selectors;
	List<Attribute>* attributes;
};

void splitPair(String source, char separator, String& s1, String& s2)
{
	size_t size = source.getSize();
	char* tab = source.getSource();
	for (size_t i = 0; i < size; i++)
	{
		if (source[i] == separator)
		{
			s1.initialize(tab, i);
			tab += (i + 1);
			s2.initialize(tab, size - (i + 1));
			return;
		}
	}
}

List<String>* split(String source, char separator)
{
	List<String>* list = new List<String>();
	size_t size = source.getSize();

	char* temp = new char[size + 1];
	size_t tempSize = 0;
	for (size_t i = 0; i < size; i++)
	{
		temp[tempSize] = source[i];

		if (source[i] == separator && tempSize > 0)
		{
			temp[tempSize] = 0;
			String s = String(temp);

			if (!s.isEmptyOrWhiteSpaces())
			{
				list->addToEnd(s);
			}

			tempSize = 0;
		}
		else
		{
			tempSize++;
		}
	}
	if (tempSize > 0)
	{
		temp[tempSize] = 0;
		String s = String(temp);
		if (!s.isEmptyOrWhiteSpaces())
		{
			list->addToEnd(s);
		}

	}
	return list;
}

void commandA(List<Section>* css, int sectionNumber)
{
	Section* section = css->getElementOfIndex(sectionNumber - 1);
	
	if (section != nullptr)
	{
		cout << sectionNumber << ",A,? == " << section->attributes->getSize() << endl;
	}
}

void commandA(List<Section>* css, String attributeName)
{
	int countOfAttrubites = 0;
	for (ListIterator<Section> i = css->start(); i.hasValue(); i.next())
	{
		List<Attribute>* attributes = i.getValue()->attributes;
		for (ListIterator<Attribute> j = attributes->start(); j.hasValue(); j.next())
		{
			if (attributeName == j.getValue()->name)
			{
				countOfAttrubites++;
			}
		}
	}
	cout << attributeName << ",A,? == " << countOfAttrubites << endl;
}
void commandA(List<Section>* css, int sectionNumber, String attributeName)
{
	Section* section = css->getElementOfIndex(sectionNumber - 1);
	List<Attribute>* attributes = section->attributes;
	for (ListIterator<Attribute> j = attributes->end(); j.hasValue(); j.prev())
	{
		if (attributeName == j.getValue()->name)
		{
			cout << sectionNumber << ",A," << attributeName << " == " << j.getValue()->value << endl;
			return;
		}
	}
}


void commandS(List<Section>* css, int sectionNumber)
{
	Section* section = css->getElementOfIndex(sectionNumber - 1);
	if (section != nullptr)
	{
		cout << sectionNumber << ",S,? == " << section->selectors->getSize() << endl;
	}
}

void commandS(List<Section>* css, int sectionNumber, int selectorNumber)
{
	if (css->getSize() < sectionNumber)
	{
		return;
	}

	Section* section = css->getElementOfIndex(sectionNumber - 1);
	if (section != nullptr)
	{
		if (section->selectors->getSize() < selectorNumber)
		{
			return;
		}
		String* selector = section->selectors->getElementOfIndex(selectorNumber - 1);
		if (selector != nullptr)
		{
			cout << sectionNumber << ",S," << selectorNumber << " == " << *selector << endl;
		}

	}
}

void commandS(List<Section>* css, String& selectorName)
{
	int countOfSelectors = 0;
	for (ListIterator<Section> i = css->start(); i.hasValue(); i.next())
	{
		List<String>* selectors = i.getValue()->selectors;
		for (ListIterator<String> j = selectors->start(); j.hasValue(); j.next())
		{
			if (selectorName == *j.getValue())
			{
				countOfSelectors++;
			}
		}
	}
	cout << selectorName << ",S,? == " << countOfSelectors << endl;
}
void commandE(List<Section>* css, String& selectorName, String& attributeName)
{
	for (ListIterator<Section> i = css->end(); i.hasValue(); i.prev())
	{
		List<String>* selectors = i.getValue()->selectors;
		for (ListIterator<String> j = selectors->start(); j.hasValue(); j.next())
		{
			if (selectorName == *j.getValue())
			{
				List<Attribute>* attributes = i.getValue()->attributes;
				for (ListIterator<Attribute> k = attributes->start(); k.hasValue(); k.next())
				{
					if (attributeName == k.getValue()->name)
					{
						cout << selectorName << ",E," << attributeName << " == " << k.getValue()->value << endl;
						return;
					}
				}
			}
		}
	}
}

void commandD(List<Section>* css, int sectionNumber) {

	Section* section = css->getElementOfIndex(sectionNumber - 1);
	if (section != nullptr)
	{
		delete section->attributes;
		delete section->selectors;

		if (css->remove(sectionNumber - 1))
		{
			cout << sectionNumber << ",D,* == deleted" << endl;
		}
	}
}

void commandD(List<Section>* css, int sectionNumber, String& attributeName) {
	Section* section = css->getElementOfIndex(sectionNumber - 1);
	if (section == nullptr)
	{
		return;
	}
	List<Attribute>* attributes = section->attributes;
	for (ListIterator<Attribute> i = attributes->start(); i.hasValue(); i.next())
	{
		if (attributeName == i.getValue()->name)
		{
			attributes->remove(i);
			cout << sectionNumber << ",D," << attributeName << " == deleted " << endl;
			if (attributes->getSize() == 0)
			{
				delete section->attributes;
				delete section->selectors;
				css->remove(sectionNumber - 1);
			}
			return;
		}
	}
}

void deleteCss(List<Section>* css)
{
	for (ListIterator<Section> i = css->start(); i.hasValue(); i.next())
	{
		delete i.getValue()->attributes;
		delete i.getValue()->selectors;
	}
	css->clear();
}

Attribute* attributeExists(List<Attribute> *attributes,String& attributeName)
{
	for (ListIterator<Attribute> k = attributes->start(); k.hasValue(); k.next())
	{
		if (attributeName == k.getValue()->name)
		{
			return k.getValue();
		}
	}
	return nullptr;
}


int main() {
	String text = "";
	StringBuilder builder;

	String startCommandSection("????");
	String commandBreak("****");
	String commandSecionCount("?");

	List<Section> css;

	while (!String::endOfFile)
	{
		builder.clear();
		do {
			text.read();
			builder.append(text);
			builder.append(' ');
		} while (text != startCommandSection);
		builder.removeLastCharacters(6);
		String result = builder.toString();
		List<String>* selectorList = split(result, '}');

		for (ListIterator<String> i = selectorList->start(); i.hasValue(); i.next())
		{
			String strSelectorNames;
			String strPairs;
			splitPair(*i.getValue(), '{', strSelectorNames, strPairs);
			List<String>* selectorNames = split(strSelectorNames, ',');
			List<String>* pairs = split(strPairs, ';');

			Section section;
			section.selectors = selectorNames;
			section.attributes = new List<Attribute>();

			for (ListIterator<String> j = pairs->start(); j.hasValue(); j.next())
			{
				Attribute attribute;
				splitPair(*j.getValue(), ':', attribute.name, attribute.value);


				Attribute* exsits = attributeExists(section.attributes, attribute.name);
				if (exsits == nullptr)
				{
					section.attributes->addToEnd(attribute);
				}
				else
				{
					exsits->value = attribute.value;
				}

			}
			css.addToEnd(section);
		}


		while (!String::endOfFile)
		{
			String command;
			command.readLine();
			
			if (command == commandBreak)
			{
				break;
			}
			else if (command.getSize() == 0)
			{
				continue;
			}
			else if (command.getSize() == 1 && command[0]=='?')
			{
				cout << command << " == " << css.getSize() << endl;
			}
			else if (command.commaCount() < 2)
			{
				continue;
			}
			else
			{
				String p1, p2, p3, other;
				splitPair(command, ',', p1, other);
				splitPair(other, ',', p2, p3);
				if (p2.getSize() == 1 && (p2[0] != 'A' && p2[0] != 'S' && p2[0] != 'D' && p2[0] != 'E'))
				{
					continue;
				}
	
				if (!(p2.getSize() == 1 && (p2[0] == 'A' || p2[0] == 'S' || p2[0] == 'D' || p2[0] == 'E')))
				{
					bool ok = false;
					size_t index = command.find(",A,?");//n,A,?
					if (index != -1)
					{
						p1.initialize(command, 0, index - 1);
						p2 = "A";
						p3 = "?";
						ok = true;
					}
					index = command.find(",S,?");// z,S,?
					if (index != -1)
					{
						p1.initialize(command, 0, index - 1);
						if (p1.commaCount() > 0)
						{
							continue;
						}
						p2 = "S";
						p3 = "?";
						ok = true;
					}
					index = command.find(",A,");//i,A,n
					if (index != -1)
					{
						p1.initialize(command, 0, index - 1);
						p2 = "A";
						p3.initialize(command, index + 3, command.getSize() - 1);
						ok = true;
					}
					index = command.find(",E,");//z,E,n
					if (index != -1)
					{
						p1.initialize(command, 0, index - 1);
						p2 = "E";
						p3.initialize(command, index + 3, command.getSize() - 1);
						ok = true;
					}
					index = command.find(",D,");//i,D,n
					if (index != -1)
					{
						p1.initialize(command, 0, index - 1);
						p2 = "D";
						p3.initialize(command, index + 3, command.getSize() - 1);
					}
					if (!ok)
					{
						//cout << "bad command:[" << command << "]" << endl;
						String::endOfFile = true;
						return 1;
					}
				}

				if (p2[0] == 'A')
				{
					if (p3.getSize() == 1 && p3[0] == '?')
					{
						int number1;
						if (p1.tryParseInt(number1))
						{
							//i,A,?
							commandA(&css, number1);
						}
						else
						{
							//n, A, ?
							commandA(&css, p1);
						}
					}
					else
					{
						int sectionNumber;
						p1.tryParseInt(sectionNumber);
						//i, A, n
						commandA(&css, sectionNumber, p3);
					}
				}
				else if (p2[0] == 'S')
				{
					if (p3.getSize() == 1 && p3[0] == '?')
					{
						int number1;
						if (p1.tryParseInt(number1))
						{
							//i, S, ?
							commandS(&css, number1);
						}
						else
						{
							//z,S,?
							commandS(&css, p1);
						}
					}
					else
					{
						int sectionNumber;
						int selectorNumber;
						p1.tryParseInt(sectionNumber);
						p3.tryParseInt(selectorNumber);
						commandS(&css, sectionNumber, selectorNumber);
						//i,S,j

					}
				}
				else if (p2[0] == 'D')
				{
					int sectionNumber;
					p1.tryParseInt(sectionNumber);
					if (p3.getSize() == 1 && p3[0] == '*')
					{

						//i,D,*
						commandD(&css, sectionNumber);
					}
					else
					{
						commandD(&css, sectionNumber, p3);
						//i,D,n
					}
				}
				else
				{
					//z,E,n
					commandE(&css, p1, p3);
				}
			}

		}
	}

	deleteCss(&css);

	return 0;
}