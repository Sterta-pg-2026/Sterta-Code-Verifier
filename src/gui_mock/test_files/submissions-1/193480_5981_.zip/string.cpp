#include "string.h"
#include <iostream>
#include <cstring>
#include "list.h"

String::String() {
	this->size = 0;
	this->data = nullptr;
}

String::String(const char* data) : String(data, strlen(data)) {};

void String::initialize(const char* data, size_t size)
{
	while (*data == ' ' || *data == '\t' || *data == '\n')
	{
		data++;
		size--;
	}
	while (data[size-1] == ' ' || data[size - 1] == '\t' || data[size - 1] == '\n')
	{
		size--;
	}

	this->size = size;
	this->data = new char[size];
	memcpy(this->data, data, size);
}
void String::initialize(const String& other, size_t fromIndex, size_t toIndex)
{
	this->size = toIndex- fromIndex+1;
	this->data = new char[size+1];
	this->data[size] = 0;
	for (size_t i = 0; i < size; i++)
	{
		this->data[i] = other[i + fromIndex];
	}
}


String::String(const char* data, size_t size)
{
	initialize(data, size);
}

String::String(const String& other) {
	this->size = other.size;
	data = new char[size + 1];
	for (size_t i = 0; i < size; i++) {
		this->data[i] = other.data[i];
	}
}

String& String::operator=(const String& right) {
	if (this->size != right.size)
	{
		if (this->data != NULL)
		{
			delete[] this->data;
		}
		this->data = new char[right.size];
		this->size = right.size;
	}
	
	for (size_t i = 0; i < size; i++) {
		this->data[i] = right.data[i];
	}
	return *this;
}

size_t String::getSize() const {
	return size;
}

char& String::operator[](size_t index) {
	return data[index];
}

const char& String::operator[](size_t index) const {
	return data[index];
}

bool String::operator==(const String& right) const {
	if (this->size == right.size) {
		for (size_t i = 0; i < size; i++) {
			if (this->data[i] == right.data[i]);
			else return false;
		}
		return true;
	}
	return false;
}

bool String::operator!=(const String& right) const
{
	return !(*this == right);
}

void String::readLine()
{
	int znak;
	size_t count = 0;
	if (data != nullptr)
	{
		data = nullptr;
	}

	do {
		znak = getchar();
		String::temp[count] = znak;
		count++;
		if (znak == EOF)
		{
			String::endOfFile = true;
		}
	} while (znak != EOF && znak != '\n' && znak != '\t');

	this->size = count - 1;
	this->data = new char[count];
	this->temp[count - 1] = 0;
	memcpy(this->data, temp, count);
	this->data[count - 1] = 0;
}

void String::read()
{
	int znak;
	size_t count = 0;
	if (data != nullptr)
	{
		data = nullptr;
	}

	do {
		znak = getchar();
		String::temp[count] = znak;
		count++;
		if (znak == EOF)
		{
			String::endOfFile = true;
		}
	} while (znak != EOF && znak != ' ' && znak != '\n' && znak != '\t');
	
	this->size = count-1;
	this->data = new char[count];
	this->temp[count - 1] = 0;
	memcpy(this->data, temp, count);
	this->data[count - 1] = 0;
}

bool String::endOfFile = false;
char String::temp[10000];

std::ostream& operator<<(std::ostream& ostr, const String& string) {
	for (size_t i = 0; i < string.size; i++) {
		ostr << string.data[i];
	}
	return ostr;
}

char* String::getSource()
{
	return data;
}

bool String::tryParseInt(int &number) const
{
	number = 0;

	for (int i = 0; i < size; i++)
	{
		if ('0' <= data[i] && data[i] <= '9')
		{
			number = number*10+(data[i] - '0');
		}
		else
		{
			return false;
		}
	}
	return true;
}
bool String::isEmptyOrWhiteSpaces() const
{
	for (size_t i = 0; i < size; i++)
	{
		if (data[i] != ' ' && data[i] != '\n' && data[i] != '\t')
		{
			return false;
		}
	}
	return true;
}

size_t String::find(const char* text) const
{
	size_t sizeText = strlen(text);

	if (size < sizeText)
	{
		return -1;
	}
	
	for (size_t i = 0; i < size - sizeText+1; i++)
	{
		bool found = true;
		for (size_t j = 0; j < sizeText; j++)
		{
			if (data[i + j] != text[j])
			{
				found = false;
				break;
			}
		}
		if (found)
			return i;
	}
	return -1;
}

size_t String::commaCount() const
{
	size_t count = 0;
	for (size_t i = 0; i < size; i++)
	{
		if (data[i] == ',')
		{
			count++;
		}
	}
	return count;
}

String::~String() {
	this->size = 0;
	delete[] data;
}

