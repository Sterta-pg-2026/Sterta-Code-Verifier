#pragma once
#include "list.h"
#include "string.h"
#include <cstring>
class StringBuilder
{
private:
	char* data;
	int size;
	int maxSize;
public:
	StringBuilder()
	{
		size = 0;
		maxSize = 100;
		data = new char[maxSize];
	}
	~StringBuilder()
	{
		delete[] data;
	}
	void append(const String& text)
	{
		for (size_t i = 0; i < text.getSize(); i++)
		{
			append(text[i]);
		}
		
		
	}
	void append(char oneChar)
	{
		if (size == maxSize)
		{
			maxSize = maxSize * 2;
			char* newData = new char[maxSize];
			memcpy(newData, data, size);
			delete[] data;
			data = newData;
		}
		data[size] = oneChar;
		size++;
	}

	String toString()
	{
		return String(data, size);
	}

	void removeLastCharacters(int count)
	{
		size -= count;
		if (size < 0)
		{
			size = 0;
		}
	}
	void clear()
	{
		size = 0;
	}
};

