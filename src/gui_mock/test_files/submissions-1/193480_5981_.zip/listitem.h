#pragma once
#define TSIZE 17



template <typename T> class ListItem
{
private:
	T data[TSIZE];
public:
	ListItem* next;
	ListItem* prev;
	int size;
	ListItem(const T& dataItem)
	{
		this->data[0] = dataItem;
		size = 1;
		next = nullptr;
		prev = nullptr;
	}
	void add(const T& dataItem)
	{
		this->data[size] = dataItem;
		size++;
	}
	void remove(int index)
	{
		for (int i = index; i < size - 1; i++)
		{
			data[i] = data[i + 1];
		}
		size--;
	}
	int getSize() const
	{
		return size;
	}
	bool isEmpty() const
	{
		return size == 0;
	}
	bool isFull() const
	{
		return size == TSIZE;
	}
	T* getData(int index)
	{
		return &data[index];
	}

};

