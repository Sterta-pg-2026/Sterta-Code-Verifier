#pragma once
#include "listitem.h"
#include "listiterator.h"
#include <iostream>

template <typename T> class List
{
private:
	ListItem<T>* first;
	ListItem<T>* last;
	int size;
public:
	List()
	{
		first = nullptr;
		last = nullptr;
		size = 0;
	}

	~List()
	{
		while (first != nullptr)
		{
			ListItem<T>* toDelete = first;
			first = first->next;
			delete toDelete;
		}
	}

	void clear()
	{
		while (first != nullptr)
		{
			ListItem<T>* toDelete = first;
			first = first->next;
			delete toDelete;
		}
		first = nullptr;
		last = nullptr;
		size = 0;
	}

	void addToEnd(const T& data)
	{
		size++;
		if (first == nullptr)
		{
			ListItem<T>* newItem = new ListItem<T>(data);
			first = newItem;
			last = newItem;
			return;
		}
		if (last->isFull())
		{
			ListItem<T>* newItem = new ListItem<T>(data);
			last->next = newItem;
			newItem->prev = last;
			last = newItem;
		}
		else
		{
			last->add(data);
		}
		
	}
	friend class ListIterator<T>;
	ListIterator<T> start()
	{

		return ListIterator<T>(first,0);
	}

	ListIterator<T> end()
	{

		return ListIterator<T>(last, last->getSize() - 1);
	}

	int getSize() const
	{
		return size;
	}

	T* getElementOfIndex(int index)
	{
		ListItem<T>* temp = find(index);
		if (temp != nullptr)
		{
			return temp->getData(index);
		}
		return nullptr;
	}

	void remove(ListIterator<T> iterator)
	{
		size--;
		removeItem(iterator.item, iterator.indexItem);
		return;
	}

	bool remove(int index)
	{
		size--;
		ListItem<T>* temp = find(index);
		if (temp != 0 && index<temp->getSize())
		{
			removeItem(temp, index);
			return true;
		}
		return false;
		
	}
private:

	void removeItem(ListItem<T>* temp, int index)
	{
		if (temp->getSize() > 1)
		{
			temp->remove(index);
			return;
		}

		if (temp == first && temp == last)
		{
			delete first;
			first = nullptr;
			last = nullptr;
		}
		else if (temp == first)
		{
			first = first->next;
			first->prev = nullptr;
			delete temp;
		}
		else if (temp == last)
		{
			last = last->prev;
			last->next = nullptr;
			delete temp;
		}
		else
		{
			ListItem<T>* start = temp->prev;
			ListItem<T>* end = temp->next;
			delete temp;
			start->next = end;
			end->prev = start;
		}
		return;
	}

	ListItem<T>* find(int &index)
	{
		ListItem<T>* temp = first;
		for (int i = 0; temp != nullptr && temp->getSize() <= index  ; i++)
		{
			index -= temp->getSize();
			temp = temp->next;
		}
		return temp;
	}


};

