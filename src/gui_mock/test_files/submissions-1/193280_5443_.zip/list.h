#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include "string.h"
#define YAS 1
#define NO 0
#define EMPTY 2
#define T 8
using namespace std;

//Atrybuty
typedef struct Attribute {
    String name;
    String attributeValue;
    Attribute* next = nullptr;
    Attribute(String n, String a) {
        name = n;
        attributeValue = a;
    }
};

//Lista Atrybut�w 
typedef class ListAttribute {
public:
    Attribute* first;
    ListAttribute() {
        first = nullptr;
    };
    void printList() {

        Attribute* temp = first;
        cout << " == ";
        while (temp != nullptr) {
            cout << temp->name << " ";
            cout << temp->attributeValue << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void addFirst(String name, String value) {
        Attribute* new_node = new Attribute(name, value);

        if (first == nullptr) {
            first = new_node;
        }
        else {
            new_node->next = first;
            first = new_node;
        }
    }
    Attribute* getTail() {
        Attribute* tmp = first;
        while (tmp->next != nullptr) {
            tmp = tmp->next;
        }
        return tmp;
    }

    void AddAttrbute(String name, String attributeValue) {

        Attribute* new_node = new Attribute(name, attributeValue);
        if (first == nullptr) {  // If list is empty
            first = new_node;
        }
        else {
            Attribute* oldTail = getTail();
            oldTail->next = new_node;
        }
    }
    Attribute* getFirst() {
        return first;
    }

    int DelateOneAttribute(String remove) {
        Attribute* previous = nullptr;
        Attribute* now = first;
        if (now != NULL) {
            while (true) {
                if (now->name == remove) {
                    if (previous != nullptr) {
                        previous->next = now->next; // zmiana wska�nika poprzednika na nast�pnika usuwanego elementu
                    }
                    else {
                        first = now->next; // usuwanie pierwszego elementu w li�cie
                    }
                    delete now; // zwolnienie pami�ci zajmowanej przez usuwany element
                    return 1;
                }
                previous = now;
                if (now->next == NULL) {
                    break;
                }
                now = now->next;

            }
        }
        return 0;
    }

    void DelateAttribute() {
        while (first != nullptr) {
            Attribute* temp = first;
            first = first->next;
            delete temp;
        }
        first = nullptr;
    }
};

//Selector
typedef struct Selector {
    String name;
    Selector* next = nullptr;
    Selector(String n) {
        name = n;
    }
};

class ListSelector {
public:
    Selector* first;
    ListSelector(){
        first = nullptr;
    }

    void printList() {

        Selector* temp = first;
        cout << " == ";
        while (temp != nullptr) {
            cout << temp->name << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void addFirst(String name) {
        // make a new node
        Selector* new_node = new Selector(name);

        if (first == nullptr) {  // If list is empty
            first = new_node;
            // tail = new_node;
             //tail->next = nullptr;
        }
        else {
            new_node->next = first;
            first = new_node;
        }
    }
    Selector* getTail() {
        Selector* tmp = first;
        while (tmp->next != nullptr) {
            tmp = tmp->next;
        }
        return tmp;
    }

    void AddSelector(String name) {

        Selector* new_node = new Selector(name);
        if (first == nullptr) {  // If list is empty
            first = new_node;
        }
        else {
            Selector* oldTail = getTail();
            oldTail->next = new_node;
        }
    }

    void DelateSelector() {
        while (first != nullptr) {
            Selector* temp = first;
            first = first->next;
            delete temp;
        }
       first = nullptr;
    }
};

//stroktura bloku
typedef struct Blok {
    ListSelector Selectors;
    ListAttribute Attribute;
    int selectorNumber=0;
    int  attributesNumber = 0;
    int full = NO;

    Blok() {
    }
    Blok(ListSelector S, ListAttribute A, int sN, int aN, int value) {
        Selectors = S;
        Attribute = A;
        selectorNumber = sN;
        attributesNumber = aN;
        full = value;
    }
};

typedef struct DoubleBlok{
    Blok blok[T] = {};
    DoubleBlok* next = 0;
    DoubleBlok* previous = 0;

    DoubleBlok() {
        next = nullptr;
        previous = nullptr;
    }

    DoubleBlok(Blok help[T]) {
        for (int i = 0; i < T; i++) {
            blok[i] = help[i];
        }
    }
};

typedef class DoubleLinkedList {
    DoubleBlok* first;
public:
    DoubleLinkedList() {
        first = nullptr;
    }

    DoubleBlok* GetTail() {
        DoubleBlok* tmp = first;
        if (tmp == nullptr) {
            return nullptr;
        }
        while (tmp->next != nullptr) {
            tmp = tmp->next;
        }
        return tmp;
    }

    void AddLast(Blok help[T]) {
        DoubleBlok* newBlok = new DoubleBlok(help);
        if (first == nullptr) {
            first = newBlok;
        }
        else {
            DoubleBlok* last = GetTail();
            last->next = newBlok;
            newBlok->previous = last;
        }
    }

    void AddBlok(DoubleBlok* newBlok) {
        if (first == nullptr) {
            first = newBlok;
        }
        else {
            DoubleBlok* last = GetTail();
            last->next = newBlok;
            newBlok->previous = last;
        }
    }

    DoubleBlok* GiveFirst() {
        return first;
    }

    void DeleteNode(DoubleLinkedList& list, DoubleBlok* toBeDeleted) {
        if (toBeDeleted == nullptr) {
            return;
        }

        if (toBeDeleted == list.first) {  // usuwanie pierwszego elementu
            list.first = toBeDeleted->next;
            if (list.first != nullptr) {
                list.first->previous = nullptr;
            }
            delete toBeDeleted;
            return;
        }

        DoubleBlok* previousNode = toBeDeleted->previous;
        previousNode->next = toBeDeleted->next;

        if (toBeDeleted->next != nullptr) {
            toBeDeleted->next->previous = previousNode;
        }

        delete toBeDeleted;
    }
};
    
