﻿#define _CRT_SECURE_NO_WARNINGS
#include <cstring>
#include <iostream>
#include <list>
#include "string.h"
#include "list.h"

#define SIZE 100
#define SIZEKEEP 500
#define SIZEBLOK 20
#define CSS 1
#define COMAND 0
#define TRUE 1
#define FALSE 0
#define T 8
#define SIZE_COMAND 50
#define YAS 1
#define NO 0
#define EMPTY 2

using namespace std;

char** CreateArray(int size) {
    char** board = new char* [size];
    for (int y = 0; y < size; ++y)
    {
        board[y] = new char[size];
    }
    return board;
}



void CleaningSingleArray( char* Keep, int sizeK) {
    for (int j = 0; j < sizeK; j++) { //czyszcze tablice
        Keep[j] = '\0';
    };
}

void CleaningDoubleArray(char**& Type, int sizeT) {
    for (int i = 0; i < sizeT; i++) { //czyszcze tablice
        for (int j = 0; j < sizeT; j++) {
            Type[i][j] = '\0';
        };
    };
}

bool FindInArrayBracket(char* array, int* flag) {
    for (int i = 0; array[i] != '\0'; i++) {
        if (array[i] == '{')
            (*flag) = i;
        if (array[i] == '}') {
            return TRUE;
        }
    }
    return FALSE;
}

bool CheckArray(char* help, char** typeAttributes, int k, int *g){
    for ((*g) = 0; (*g) < k; (*g) = (*g) + 2) {
        String OldAttributes(typeAttributes[(*g)]);
        String NewAttribute(help);
        if (NewAttribute == OldAttributes) {
            return TRUE;
        }
    } 
    return FALSE;
}

ListAttribute SelectAttributes(int* attributesNumber, char* keepAttributes, char** typeAttributes, int z) {
    ListAttribute newAttributeList;
    char helparray[SIZE];
    int g = 0, flag=0;
    CleaningSingleArray(helparray, SIZE);
    int k = 0, i = 0; (*attributesNumber) = 0;
    if (keepAttributes[0] == '{') i++;
    if (keepAttributes[1] == '\n') i++;
    for (i; keepAttributes[i] != '\0'; i++) { //dziala do ostatniego elentu tablicy pomocniczej
        if (keepAttributes[i] == '\n' || keepAttributes[i] == '{') { //zamienia endline na spackje
            keepAttributes[i] = ' ';
        }
        if (keepAttributes[i] == ':') { 
            helparray[z] = '\0';
            if (CheckArray(helparray, typeAttributes, k, &g) == FALSE) {
                for (int w = 0; helparray[w] != '\0'; w++) {
                    typeAttributes[k][w] = helparray[w];
                }
                (*attributesNumber)++;
                k++;
                z = 0;
                i++;
            }
            else {
                flag = 1;
                z = 0;
                i++;
            }
            CleaningSingleArray(helparray, SIZE);
        }
        else if (keepAttributes[i] == ';') {
            helparray[z] = '\0';
            if (flag != 1) {
                for (int w = 0; helparray[w] != '\0'; w++) {
                    typeAttributes[k][w] = helparray[w];
                }
                CleaningSingleArray(helparray, SIZE);
                k++;
                z = 0;
                i++;
            }
            else {
                CleaningSingleArray(typeAttributes[g+1], SIZE);
                for (int w = 0; helparray[w] != '\0'; w++) {
                    typeAttributes[g+1][w] = helparray[w];
                }
                CleaningSingleArray(helparray, SIZE);
                z = 0;
                i++;
                flag = 0;
            }
        }
        else if (keepAttributes[i] != ';' && keepAttributes[i] != ':' && keepAttributes[i] != '\r' && keepAttributes[i] != '\t') {
            helparray[z] = keepAttributes[i];
            z++;
        }
    };


    k = 0;
    //wpisujemy atrybuty i ich wartosci do listy
    for (int i = 0; i < (*attributesNumber); i++) {
        String help = String(typeAttributes[k]); // zminna z atrybutem - nazwa
        String help2 = String(typeAttributes[k + 1]); // zmienna z wartoscia atrybutu
        newAttributeList.AddAttrbute(help, help2); // wpisujemy do listy
        k = k + 2;
    }
    return newAttributeList;
}

ListSelector SelectSelectors(int* selectorNumber, char* keepSelector, char** typeSelector, int z) {
    ListSelector newSelectorList;
    (*selectorNumber) = 0;
    int k = 0, flag =0;
    for (int i = 0; keepSelector[i] != '\0'; i++) { // przeszukuje teblice pomocnicza z selektorami i wpisuje selektory do tablicy 2 wymiarowej
        if (keepSelector[i] == '{') {
            keepSelector[i] = 'null';
            break;
        }
        if (keepSelector[i] == ',') { // jesli jest przecinek to rozdziela selektory
            if (typeSelector[k][z-1] == ' ') {
                typeSelector[k][z-1] == '\0';
            }
            if (typeSelector[k][0] == ' ') {
                for (int t = 0; typeSelector[k][t]!= '\0'; t++) {
                    typeSelector[k][t] = typeSelector[k][t + 1];
                }
            }
            (*selectorNumber)++;
            // wpisujemy slektory do listy
            String help = String(typeSelector[k]);
            newSelectorList.AddSelector(help);
            k++;
            z = 0;
        }
        else if (keepSelector[i] != ','  && keepSelector[i] != '\t' && keepSelector[i] != '\r') { // wpisuje literki do jednej lini tablicy dwuwymiarowej poto alby w jdnej lini byl jeden selektor
            if (flag == 0) {
                (*selectorNumber) = 1;
                flag = 1;
            }
            typeSelector[k][z] = keepSelector[i];
            z++;
        }
    };
    if (typeSelector[k][z-1] == ' ') {
        typeSelector[k][z-1] = '\0';
        if (typeSelector[k][z - 2] == ' ') {
            typeSelector[k][z - 2] = '\0';
        }
    }
    if (typeSelector[k][0] == ' ') {
        for (int t = 0; typeSelector[k][t] != '\0'; t++) {
            typeSelector[k][t] = typeSelector[k][t + 1];
        }
    }
    // wpisuje ostatni selektor na koniec listy
    String help = String(typeSelector[k]);
    newSelectorList.AddSelector(help);
    return newSelectorList;
}



void SeparateCommand(char* keepTask, char* keepFirst, char* keepSecound, char* keepThird) { // dzielimy komendy terminala
    int g = 0, j = 0, z = 0;
    CleaningSingleArray(keepFirst, SIZE_COMAND);
    CleaningSingleArray(keepSecound, SIZE_COMAND);
    CleaningSingleArray(keepThird, SIZE_COMAND);
    for (int i = 0; keepTask[i] != '\0'; i++) { 
        if (g == 0) {
            if (keepTask[i] != ',') {//pierwsza czesc komendy 
                keepFirst[i] = keepTask[i];
            }
            else {
                g = 1;
            }
        }
        else if (g == 1) { // jesli istnieje to druga czesc komendy
            if (keepTask[i] != ',') {
                keepSecound[z] = keepTask[i];
            }
            else {
                g = 2;
            }
            z++;
        }
        else if (g == 2) { // jesli istnieje to trzecia czesc komendy
            keepThird[j] = keepTask[i];
            j++;
        }
    }
}

int CheckNumber(char *tabCheck) { // funkcja sprawdzajaca numer 
    int z = 1,i = 0,size=0;
    while (tabCheck[i] != '\0') {
        i++;
    }
    for (int j = (i-1) ; j >= 0; j--)
    {
        size = size + ((tabCheck[j]-'0') * z);
        z = z * 10;
    }
    return size;
}

int countBlok(Blok blok[], DoubleLinkedList* doubleBlok) { 
    int i = 0, j = 0, e = 0;
    DoubleBlok* node = doubleBlok->GiveFirst();

    while (node != nullptr && node->blok[j].full != NO ) {
        if (node->blok[j].full == YAS) {
            j++;
        }
        if (node->blok[j].full == EMPTY) {
            j++;
            e++;
        }
        if (j >= T) {
            node = node->next;
            i++;
            j = 0;
        }
    } 

    return ((j-e) + (i * T));
}

DoubleBlok* FindBlokNumber(int number, DoubleLinkedList* doubleBlok, Blok blok[],int *a,int *j){
    (*j) = 0;
    DoubleBlok* node = doubleBlok->GiveFirst();
     while (number != 0) {
        if (node->blok[(*j)].full == YAS) {
            number--;
            if (number == 0) break;
            (*j)++;
        }
        else if (node->blok[(*j)].full == EMPTY) {
            (*j)++;
        }
        if ((*j) >= T ) {
            node = node->next;
            (*j) = 0;

        }
        if (node != nullptr && node->blok[(*j)].full == NO) {
            (*a) = 0;
            break;
        }
     }
     return node;
}

void FindValueOfAttribute(DoubleLinkedList* doubleBlok, char* keepThird,ListAttribute ourAttribute,int *a, int j,DoubleBlok* node, String* value,char*keepTask) {
    String attributeName(keepThird); (*a) = 0;
    Attribute* currentAttribute = node->blok[j].Attribute.first;
    while (currentAttribute != nullptr) {
        if (currentAttribute->name == attributeName) {
            *value = currentAttribute->attributeValue;
            (*a)= 1;
        }
        currentAttribute = currentAttribute->next;
    }
    
}

void FindSelectorInBlok(DoubleLinkedList* doubleBlok, char* keepThird, ListSelector ourSelector, DoubleBlok* node, String* value, int numberSelector, int j, char*keepTask) {
    Selector* currentSelector = node->blok[j].Selectors.first;
    if (node->blok[j].selectorNumber != 0) {
        while (true) {
            numberSelector--;
            if (numberSelector == 0)break;
            currentSelector = currentSelector->next;
        }
        if (currentSelector != nullptr) {
            for (int i = 0; keepTask[i] != '\0'; i++) {
                cout << keepTask[i];
            }
            cout << " == " << currentSelector->name << endl;
        }
    }
}

int FindAllAttriburesInCSS(DoubleLinkedList* doubleBlok, char* keepFirst) {
    String attributeName(keepFirst);
    DoubleBlok* node = doubleBlok->GiveFirst();
    int j = 0, attribute = 0, a=0;
    while (node != nullptr) {
        while (node->blok[j].full != NO && j<T) {
            Attribute* currentAttribute = node->blok[j].Attribute.first;
            while (currentAttribute != nullptr && a != 1) {
                if (currentAttribute->name == attributeName) {
                    attribute++;
                    a = 1;
                }
                currentAttribute = currentAttribute->next;
            }
            a = 0;
            j++;
        }
        j = 0;
        node = node->next;
    }
    return attribute;
 }

int FindAllSelectorsInCss(DoubleLinkedList* doubleBlok, char* keepFirst) {
    String selectorName(keepFirst);
    DoubleBlok* node = doubleBlok->GiveFirst();
    int j = 0, selector = 0, a = 0;
    while (node != nullptr) {
        while (node->blok[j].full != NO && j < T) {
            Selector* currentSelector = node->blok[j].Selectors.first;
            while (currentSelector != nullptr && a != 1) {
                if (currentSelector->name == selectorName) {
                    selector++;
                    a = 1;
                }
                currentSelector = currentSelector->next;
            }
            a = 0;
            j++;
        }
        j = 0;
        node = node->next;
    }
    return selector;

}

void SwitchCommandA(char* keepFirst, char* keepSecound, char* keepThird, int blokNumber, Blok *blok, DoubleLinkedList *doubleBlok, ListAttribute ourAttribute,char* keepTask){ // funckja do komendy A
    DoubleBlok* node;
    String value;
    int number = 0, a=1,j=0,n=0;
    char check = keepFirst[0];
    if (isdigit(check)) {
        number = CheckNumber(keepFirst);
        if (keepThird[0] == '?') { // print the number of attributes for section number i, if there is no such block or section, skip;
            node = FindBlokNumber(number, doubleBlok, blok,&a,&j);
            if (a != 0) {
                n = node->blok[j].attributesNumber;
                for (int i = 0; keepTask[i] != '\0'; i++) {
                    cout << keepTask[i];
                }
                cout << " == " << n<<endl;
            }
        }
        else { //print the value of the attribute with the name n for the i - th section, if there is no such attribute, skip;
            node = FindBlokNumber(number, doubleBlok, blok, &a, &j);
            if (a != 0) {
                FindValueOfAttribute(doubleBlok, keepThird, ourAttribute, &a, j, node,&value, keepTask);
                if (a != 0) {
                    for (int i = 0; keepTask[i] != '\0'; i++) {
                        cout << keepTask[i];
                    }
                    cout << " == " << value<<endl;
                }
            }
        }
    }
    else {
        if (keepThird[0] == '?') {
            number = FindAllAttriburesInCSS(doubleBlok, keepFirst);
            for (int i = 0; keepTask[i] != '\0'; i++) {
                cout << keepTask[i];
            }
            cout << " == " << number << endl;
        }
    }
}
void SwitchCommandS(char* keepFirst, char* keepSecound, char* keepThird, int blokNumber, Blok* blok, DoubleLinkedList* doubleBlok, ListSelector ourSelector, char* keepTask) { // funckja do komendy A
    DoubleBlok* node;
    String value;
    int number = 0, a = 1, j = 0, n = 0, numberSelector=0;
    char check = keepFirst[0];
    if (isdigit(check)) {
        number = CheckNumber(keepFirst);
        if (keepThird[0] == '?') { // print the number of selectors for section number i, if there is no such block or section, skip;
            node = FindBlokNumber(number, doubleBlok, blok, &a, &j);
            if (a != 0) {
                n = node->blok[j].selectorNumber;
                for (int i = 0; keepTask[i] != '\0'; i++) {
                    cout << keepTask[i];
                }
                cout << " == " << n << endl;;
            }
        }
        else {//print the j - th selector for the i - th block(section and attribute numbers start from 1), if there is no section or selector, skip;
            node = FindBlokNumber(number, doubleBlok, blok, &a, &j);
            if (a != 0) {
                numberSelector = CheckNumber(keepThird);
                FindSelectorInBlok(doubleBlok, keepThird, ourSelector, node, &value,numberSelector,j, keepTask);
            }
        }
    }
    else {
        if (keepThird[0] == '?') {
            number = FindAllSelectorsInCss(doubleBlok, keepFirst);
            for (int i = 0; keepTask[i] != '\0'; i++) {
                cout << keepTask[i];
            }
            cout << " == " << number << endl;
        }
    }
}
void SwitchCommandE(char* keepFirst, char* keepSecound, char* keepThird, int blokNumber, Blok* blok, DoubleLinkedList* doubleBlok, ListSelector ourSelector, ListAttribute ourAttribute, char* keepTask) {
    int a = 0, j = (T-1);
    DoubleBlok* current = doubleBlok->GetTail();
    String selectorName(keepFirst);
    String value;
    String attributeName(keepThird);
    while (current != nullptr&&a!=1) {
        while (j >= 0&&a!=1) {
            Blok blok = current->blok[j];
            if (current->blok[j].full != NO && current->blok[j].full != EMPTY) {
                for (int i = blok.selectorNumber - 1; i >= 0; i--) {
                    Selector* selector = blok.Selectors.first;
                    while (selector != nullptr&&a!=1) {
                        if (selector->name == selectorName) {
                            Attribute* attribute = blok.Attribute.first;
                            while (attribute != nullptr&&a!=1) {
                                if (attribute->name == attributeName) {
                                    value = attribute->attributeValue;
                                    a = 1;
                                    break;
                                }
                                attribute = attribute->next;
                            }
                        }
                        selector = selector->next;
                    }
                }
            }
            j--;
        }
        current = current->previous;
        j = (T - 1);
    }
    if (a == 1) {
        for (int i = 0; keepTask[i] != '\0'; i++) {
            cout << keepTask[i];
        }
        cout << " == " << value << endl;
    }
}
void DelateBlok(char *keepFirst, DoubleLinkedList* doubleBlok, Blok blok[], int* a, int* j, char*keepTask) {
    int number = 0, allEmpty=YAS;
    DoubleBlok *node;
    number = CheckNumber(keepFirst);
    node = FindBlokNumber(number,doubleBlok, blok, a, j);
    if (a != 0 && (node->blok[(*j)].full) != EMPTY && (node->blok[(*j)].full) != NO) {
        node->blok[(*j)].Selectors.DelateSelector();
        node->blok[(*j)].Attribute.DelateAttribute();
        node->blok[(*j)].attributesNumber = NULL;
        node->blok[(*j)].selectorNumber = NULL;
        node->blok[(*j)].full = EMPTY;
        for (int i = 0; keepTask[i] != '\0'; i++) {
            cout << keepTask[i];
        }
        cout << " == deleted" <<endl;
    }
    for (int i = 0; i < T; i++) {
        if (node->blok[i].full == YAS) {
            allEmpty = NO;
            break;
        }
    }  
    if (allEmpty == YAS) {
        doubleBlok->DeleteNode(*doubleBlok, node);
    }
}

void DeleteAttribut(char* keepFirst, char* keepThird, DoubleLinkedList* doubleBlok, Blok blok[], int* a, int* j, char* keepTask) {
    int number = 0, allEmpty = YAS, attributeValue=0,flag=1;
    DoubleBlok* node;
    number = CheckNumber(keepFirst);
    node = FindBlokNumber(number, doubleBlok, blok, a, j);
    String atributeName(keepThird);
    if (a != 0) {
        flag = node->blok[(*j)].Attribute.DelateOneAttribute(atributeName);
        if (flag != 0) {
            attributeValue = node->blok[(*j)].attributesNumber;
            attributeValue--;
            if (attributeValue == 0) {
                DelateBlok(keepFirst, doubleBlok, blok, a, j, keepTask);
            }
            else {
                node->blok[(*j)].attributesNumber = attributeValue;
                for (int i = 0; keepTask[i] != '\0'; i++) {
                    cout << keepTask[i];
                }
                cout << " == deleted" << endl;
            }
        }
    }
}



void SwitchCommandD(char* keepFirst, DoubleLinkedList* doubleBlok, Blok blok[], char*keepThird, char*keepTask) {
    int number = 0, a = 1, j = 0, n = 0, numberSelector = 0;
    char check = keepFirst[0];
    if (isdigit(check)) {
        if (keepThird[0] == '*') {
            DelateBlok(keepFirst, doubleBlok, blok, &a, &j, keepTask);
        }
        else {
            DeleteAttribut(keepFirst, keepThird, doubleBlok, blok, &a, &j, keepTask);
        }
    }
}

void DoCommand(char* keepFirst, char* keepSecound, char* keepThird, int blokNumber, Blok *blok, DoubleLinkedList* doubleBlok, ListAttribute ourAttribute, ListSelector ourSelector,char* keepTask) {
    if (keepFirst[0] == '?') { // komenda na - print the number of CSS sections
        blokNumber = countBlok(blok, doubleBlok);
        cout <<"? == "<< blokNumber<<endl;
    }
    else {
        char check = keepSecound[0];
        switch (check)
        {
        case 'A':
            SwitchCommandA(keepFirst, keepSecound, keepThird, blokNumber, blok, doubleBlok,ourAttribute,keepTask);
            break;
        case 'S':
            SwitchCommandS(keepFirst, keepSecound, keepThird, blokNumber, blok, doubleBlok, ourSelector,keepTask);
            break;
        case 'E':
            SwitchCommandE(keepFirst, keepSecound, keepThird, blokNumber, blok, doubleBlok, ourSelector, ourAttribute, keepTask);
            break;
        case 'D':
            SwitchCommandD(keepFirst, doubleBlok, blok, keepThird,keepTask);
            break;
        default:
            cout << "Wrong choice try again" << endl;
            break;
        }
    }

}

int main()
{
    ListAttribute ourAttribute;
    ListSelector ourSelector;
    DoubleLinkedList doubleBlok;
    DoubleBlok* first = nullptr;
    Blok blok[SIZEBLOK];
    DoubleBlok* currNode = new DoubleBlok(blok);
    int exchange = 1, flag = 0;
    int selectorNumber = 0, k = 0, z = 0, attributesNumber = 0, i = 0, blokNumber = 0, counter = 0, notFULL = 0;
    char keepSelector[SIZEKEEP], keepAttributes[SIZEKEEP], keepTask[SIZEKEEP]; // pomocnicza tablica do pobierania selekorow i atrybutow
    char keepFirst[SIZE_COMAND], keepSecound[SIZE_COMAND], keepThird[SIZE_COMAND];
    // dwuwymiarowa lista ktora przetrzymuje nasze strybuty i selektory
    char** typeSelector = CreateArray(SIZE);
    char** typeAttributes = CreateArray(SIZE);


    while (cin) {
        if (exchange == CSS) {
            CleaningSingleArray(keepSelector, SIZEKEEP);
            CleaningDoubleArray(typeSelector, SIZE);
            cin.getline(keepSelector, SIZEKEEP, '\n');  // pobieram pierwsza linie selektory albo beda znaki zapytania
            selectorNumber = 0; attributesNumber = 0;
            if (keepSelector[0] != '\n' && keepSelector[0] != '\0') {
                if (keepSelector[0] != '\t' || keepSelector[0] != '\t') {
                    if (keepSelector[0] != '?' && keepSelector[1] != '?') {
                        if (FindInArrayBracket(keepSelector, &flag) == 1) {
                            CleaningSingleArray(keepAttributes, SIZEKEEP);
                            CleaningDoubleArray(typeAttributes, SIZE);
                            int g = 0;
                            for (int i = 0; i < SIZEKEEP; i++) {
                                if (keepSelector[i] == '\0')break;
                                g++;
                            }
                            for (int i = 0; i < g; i++) {
                                keepAttributes[i] = keepSelector[flag + i + 1];
                                keepSelector[flag + i + 1] = '\0';
                            }
                            ourSelector = SelectSelectors(&selectorNumber, keepSelector, typeSelector, z);
                            ourAttribute = SelectAttributes(&attributesNumber, keepAttributes, typeAttributes, z);
                        }
                        else {
                            ourSelector = SelectSelectors(&selectorNumber, keepSelector, typeSelector, z);
                            CleaningSingleArray(keepAttributes, SIZEKEEP);
                            CleaningDoubleArray(typeAttributes, SIZE);
                            z = 0;
                            cin.getline(keepAttributes, SIZEKEEP, '}'); // pobieramy arybuty do pomocniczego arraya
                            ourAttribute = SelectAttributes(&attributesNumber, keepAttributes, typeAttributes, z);
                        }
                        blokNumber++;
                        currNode->blok[counter].Selectors = ourSelector;
                        currNode->blok[counter].Attribute = ourAttribute;
                        currNode->blok[counter].attributesNumber = attributesNumber;
                        currNode->blok[counter].selectorNumber = selectorNumber;
                        currNode->blok[counter].full = YAS;
                        counter++;
                        DoubleBlok* node = (&doubleBlok)->GiveFirst();
                        if (counter >= T) {
                            if (notFULL == 0) {
                                doubleBlok.AddBlok(currNode);
                                notFULL = 1;
                            }
                            currNode = new DoubleBlok(blok);
                            notFULL = 0;
                            counter = 0;
                        }
                    }
                    else {
                        exchange = COMAND;
                        if (notFULL == 0) {
                            doubleBlok.AddBlok(currNode);
                            notFULL = 1;
                        }
                    }
                }
            }
        }
        if (exchange == COMAND) {
            cin.getline(keepTask, SIZEKEEP, '\n');
            if (keepTask[0] != '\0' && keepTask[0] != '\n') {
                if (keepTask[0] != '*' && keepTask[1] != '*') {
                    SeparateCommand(keepTask, keepFirst, keepSecound, keepThird);
                    DoCommand(keepFirst, keepSecound, keepThird, blokNumber, blok, &doubleBlok, ourAttribute, ourSelector, keepTask);
                }
                else {
                    exchange = CSS;
                }
            }
        }
    };

    return 0;
};