#ifndef SECTION_H
#define SECTION_H

#include "forwardlist.h"
#include "string.h"
#include "attribute.h"

class Section
{
public:
	ForwardList<String> selectors;
	ForwardList<Attribute> attributes;
};

#endif