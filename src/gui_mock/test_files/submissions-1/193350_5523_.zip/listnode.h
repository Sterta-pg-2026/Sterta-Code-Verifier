#ifndef LIST_NODE_H
#define LIST_NODE_H

#include "forwardlist.h"
#include "attribute.h"
#include "string.h"
#include "section.h"

class ListNode
{
public:
	static constexpr int ARRAY_SIZE = 37;
	int numberOfSections;
	int cursor;
	ListNode* previous;
	ListNode* next;
	Section* sections[ARRAY_SIZE];

	ListNode();
	~ListNode();
};

#endif