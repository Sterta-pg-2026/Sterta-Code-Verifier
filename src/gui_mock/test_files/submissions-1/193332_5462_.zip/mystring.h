#pragma once

#ifndef STRING_H
#define STRING_H

#include <iostream>

class String {
public:
    // Konstruktory
    String();
    String(char c);
    String(const char* str);
    String(const String& other);
    ~String();

    // Metody
    int length() const;
    const char* c_str() const;
    String& operator=(const String& other);
    String& operator+=(const String& other);
    bool operator==(const String& other) const;
    bool operator!=(const String& other) const;
    char& operator[](int index); // nowy operator indeksowania
    const char& operator[](int index) const; // operator indeksowania tylko do odczytu
    void clear();
    String& operator-=(const String& other);
    bool isEmpty() const;
    void removeWhitespace();
    String substr(int start, int length) const;
    int countSubstring(const String& sub) const;
  
private:
    char* m_str;
    int m_length;
};

// Przeciążony operator wypisywania
std::ostream& operator<<(std::ostream& os, const String& str);










#endif