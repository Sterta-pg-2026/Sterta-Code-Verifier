#include "mystring.h"
#include <cstring>

// Konstruktory
String::String() : m_str(nullptr), m_length(0) {}

String::String(char c) : m_length(1), m_str(new char[2]) {
    m_str[0] = c;
    m_str[1] = '\0';
}

String::String(const char* str) : m_str(nullptr), m_length(0) {
    if (str != nullptr) {
        m_length = static_cast<int>(std::strlen(str));
        m_str = new char[m_length + 1];
        strcpy_s(m_str, m_length + 1, str);
    }
}

String::String(const String& other) : m_str(nullptr), m_length(0) {
    if (other.m_str != nullptr) {
        m_length = other.m_length;
        m_str = new char[m_length + 1];
        strcpy_s(m_str, m_length + 1, other.m_str);
    }
}

String::~String() {
    delete[] m_str;
}

// Metody
int String::length() const {
    return m_length;
}

const char* String::c_str() const {
    return m_str;
}

String& String::operator=(const String& other) {
    if (this != &other) {
        delete[] m_str;
        m_length = other.m_length;
        m_str = new char[m_length + 1];
        strcpy_s(m_str, m_length + 1, other.m_str);
    }
    return *this;
}

String& String::operator+=(const String& other) {
    int newLength = m_length + other.m_length;
    char* newStr = new char[newLength + other.m_length + 1]; // increase buffer size
    strcpy_s(newStr, newLength + 1, m_str);
    strcat_s(newStr, newLength + other.m_length + 1, other.m_str); // pass the new buffer size
    delete[] m_str;
    m_length = newLength;
    m_str = newStr;
    return *this;
}

bool String::operator==(const String& other) const {
    return std::strcmp(m_str, other.m_str) == 0;
}

bool String::operator!=(const String& other) const {
    return !(*this == other);
}



// Przeciążony operator wypisywania
std::ostream& operator<<(std::ostream& os, const String& str) {
    os << str.c_str();
    return os;
}

char& String::operator[](int index) {
    if (index < 0 || index >= m_length) {
        throw std::out_of_range("Index out of range");
    }
    return m_str[index];
}

const char& String::operator[](int index) const {
    if (index < 0 || index >= m_length) {
        throw std::out_of_range("Index out of range");
    }
    return m_str[index];
}
void String::clear() {
    delete[] m_str;
    m_length = 0;
    m_str = new char[1];
    m_str[0] = '\0';
}


String& String::operator-=(const String& other) {
    int foundIndex = static_cast<int>(std::strstr(m_str, other.m_str) - m_str);
    if (foundIndex >= 0 && foundIndex < m_length) {
        int removedLength = other.m_length;
        char* newStr = new char[m_length - removedLength + 1];
        strncpy_s(newStr, foundIndex + 1, m_str, foundIndex);
        strncpy_s(newStr + foundIndex, m_length - foundIndex - removedLength + 1, m_str + foundIndex + removedLength, m_length - foundIndex - removedLength);
        delete[] m_str;
        m_str = newStr;
        m_length -= removedLength;
    }
    return *this;
}

bool String::isEmpty() const {
    return m_length == 0;
}

void String::removeWhitespace() {
    int i = 0, j = 0;
    while (m_str[j]) {
        if (m_str[j] != ' ' && m_str[j] != '\t' && m_str[j] != '\n' && m_str[j] != '\r') {
            m_str[i] = m_str[j];
            i++;
        }
        j++;
    }
    m_str[i] = '\0';
    m_length = i;
}

String String::substr(int start, int length) const {
    if (start < 0 || start >= m_length || length < 0) {
        throw std::out_of_range("Invalid start index or length");
    }
    int end = start + length;
    if (end > m_length) {
        end = m_length;
    }
    char* substr = new char[length + 1];
    strncpy_s(substr, length + 1, m_str + start, end - start);
    substr[length] = '\0';
    String result(substr);
    delete[] substr;
    return result;
}
int String::countSubstring(const String& sub) const {
    int count = 0;
    const char* str = m_str;
    while ((str = std::strstr(str, sub.m_str)) != nullptr) {
        count++;
        str += sub.m_length;
    }
    return count;
}
