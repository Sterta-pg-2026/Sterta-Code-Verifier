#include "mystring.h"
#include <cstdio>
#include <iostream>

using namespace std;

#define T 8

struct AiP
{
    String Attribute;
    String Parameter;
    struct AiP* next;
};

struct Section {       //1 element listy
    String Name;
    AiP* AiPLIST;
};

struct Node {       //podwojna
    struct Node* previous;
    struct Node* next;
    Section* Table[T];
};

void printData(Node* node) {
    if (node == NULL) {
        return;
    }

    // Print the data in the current node
    for (int i = 0; i < T; i++) {
        Section* section = node->Table[i];
        if (section != NULL) {
            cout << "Section: " << section->Name << endl;
            AiP* aiP = section->AiPLIST;
            while (aiP != NULL) {
                cout << "  Attribute: " << aiP->Attribute << endl;
                cout << "  Parameter: " << aiP->Parameter << endl;
                aiP = aiP->next;
            }
        }
    }

    // Recursively print the data in the next node
    printData(node->next);
}

void printAllAttributes(Node* head) {
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                AiP* aip = section->AiPLIST;
                while (aip != NULL) {
                    std::cout << aip->Attribute << std::endl;
                    aip = aip->next;
                }
            }
        }
        tempNode = tempNode->next;
    }
}


int countAttributesInSection(Node* head, int N) {
    int count = 0;
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                if (count == N) {
                    int numAttributes = 0;
                    Section* section = tempNode->Table[i];
                    AiP* aip = section->AiPLIST;
                    while (aip != NULL) {
                        numAttributes++;
                        aip = aip->next;
                    }
                    return numAttributes;
                }
                count++;
            }
        }
        tempNode = tempNode->next;
    }
    return 0; // Indicates that N is out of bounds
}
void printSectionName(Node* head, int I, int J) {
    int count = 0;
    Node* tempNode = head;
    I -= 1;
    J -= 1;
    while (tempNode != NULL) {
        if (count == I) {
            Section* section = tempNode->Table[J];
            if (section != NULL) {
                cout << I + 1 << ",S," << J + 1 << " == " << section->Name << endl;
            }

            return;
        }
        count++;
        tempNode = tempNode->next;
    }
    return;
}


String findParameterByAttribute(Node* head, int I, String Attribute) {
    int count = 0;
    Node* tempNode = head;
    while (tempNode != NULL) {
        if (count == I) {
            Section* section = tempNode->Table[0];
            while (section != NULL) {
                AiP* AiPLIST = section->AiPLIST;
                while (AiPLIST != NULL) {
                    if (AiPLIST->Attribute == Attribute) {
                        return AiPLIST->Parameter;
                    }
                    AiPLIST = AiPLIST->next;
                }
                section = tempNode->Table[++count];
            }
            cout << "Attribute " << Attribute << " not found in section " << I << endl;
            return "";
        }
        count++;
        tempNode = tempNode->next;
    }
    cout << "Invalid node index: " << I << endl;
    return "";
}
String findParameter(int i, const String& attribute, Node* head) {          //////////////////////////////////////////
    // Traverse to the ith section
    int nodeIndex = i / T;
    int sectionIndex = i % T;
    Node* currentNode = head;
    while (nodeIndex > 0 && currentNode != nullptr) {
        currentNode = currentNode->next;
        nodeIndex--;
    }
    if (currentNode == nullptr) {
        //std::cout << "Invalid section index" << std::endl;
        return "wrong";
    }
    Section* currentSection = currentNode->Table[sectionIndex];
    if (currentSection == nullptr) {
        //std::cout << "Invalid section index" << std::endl;
        return "wrong";
    }
  /*  cout << endl << "DOSZLISMY TUTAJ" << endl;*/
    // Search for the attribute in the AiPLIST of the current section
    AiP* currentAiP = currentSection->AiPLIST;
    while (currentAiP != nullptr) {
        /*cout << currentAiP->Attribute;*/
        if (currentAiP->Attribute == attribute) {
            //std::cout << currentAiP->Parameter << std::endl;
            return currentAiP->Parameter;
        }
        currentAiP = currentAiP->next;
    }
    return "wrong";
    // std::cout << "Attribute not found" << std::endl;
}
//
//int countAttribute(const String& attribute, Node* head) {
//    int count = 0;
//    Node* currentNode = head;
//    while (currentNode != nullptr) {
//        for (int i = 0; i < T; i++) {
//            Section* currentSection = currentNode->Table[i];
//            if (currentSection != nullptr) {
//                AiP* currentAiP = currentSection->AiPLIST;
//                while (currentAiP != nullptr) {
//                    currentAiP->Attribute.removeWhitespace();
//                    if (currentAiP->Attribute == attribute) {
//                        count++;
//                    }
//                    currentAiP = currentAiP->next;
//                }
//            }
//        }
//        currentNode = currentNode->next;
//    }
//    return count;
//}
//


String getNthSectionName(Node* head, int N) {
    int current_section_index = 0;
    Node* current_node = head;

    while (current_node != nullptr) {
        for (int i = 0; i < T; i++) {
            if (current_node->Table[i] != nullptr) {
                current_section_index++;
                if (current_section_index == N) {
                    return current_node->Table[i]->Name;
                }
            }
        }
        current_node = current_node->next;
    }

    // Nth section not found
    return "";
}


const char* nthpart(const char* Selectors, int n)
{
    if (!Selectors || *Selectors == '\0' || n <= 0) {
        return "";
    }
    int commas = 0;
    for (const char* p = Selectors; *p; p++) {
        if (*p == ',') {
            commas++;
        }
    }
    if (commas == 0) {
        return n == 1 ? Selectors : "";
    }
    const char* startIndex = Selectors;
    const char* endIndex = strchr(Selectors, ',');
    for (int i = 1; i < n; i++) {
        if (!endIndex) {
            return "";
        }
        startIndex = endIndex + 1;
        endIndex = strchr(startIndex, ',');
    }
    if (startIndex >= Selectors + strlen(Selectors)) {
        return "";
    }
    if (!endIndex) {
        endIndex = Selectors + strlen(Selectors);
    }
    size_t length = endIndex - startIndex;
    char* result = new char[length + 1];
    if (strncpy_s(result, length + 1, startIndex, length) != 0) {
        // strncpy_s failed to copy the string, so return an empty string
        delete[] result;
        return "";
    }
    result[length] = '\0';
    return result;
}

int countAttribute(const String& attribute, Node* head) {
    int count = 0;
    Node* currentNode = head;
    while (currentNode != nullptr) {
        for (int i = 0; i < T; i++) {
            Section* currentSection = currentNode->Table[i];
            if (currentSection != nullptr) {
                bool seenAttributeAndParam = false; // flag to track whether attribute and parameter have been seen in the current section
                AiP* currentAiP = currentSection->AiPLIST;
                while (currentAiP != nullptr) {
                    currentAiP->Attribute.removeWhitespace();
                    if (currentAiP->Attribute == attribute) {
                        if (!seenAttributeAndParam || currentAiP->Parameter != currentSection->AiPLIST->Parameter) {
                            // if attribute and parameter have not been seen before in the current section, or if they have been seen but the parameter is different, increment count
                            count++;
                            seenAttributeAndParam = true;
                        }
                    }
                    currentAiP = currentAiP->next;
                }
            }
        }
        currentNode = currentNode->next;
    }
    return count;
}

void removeWhitespacesFromAllAttributes(Node* head) {
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                AiP* aip = section->AiPLIST;
                while (aip != NULL) {
                    aip->Attribute.removeWhitespace();
                    aip = aip->next;
                }
            }
        }
        tempNode = tempNode->next;
    }
}

void printAttributesInSection(Node* head, int N) {
    int count = 1; // start counting from 1
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                if (count == N) {
                    Section* section = tempNode->Table[i];
                    AiP* aip = section->AiPLIST;
                    while (aip != NULL) {
                        std::cout << aip->Attribute << std::endl;
                        aip = aip->next;
                    }
                    return;
                }
                count++;
            }
        }
        tempNode = tempNode->next;
    }
}

int countStringInSectionNames(Node* head, String search) {
    int count = 0;
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                String currentName = section->Name;
                int add = currentName.countSubstring(search);
                if (add> 0)
                {
                    count += add;
                }
            }
        }
        tempNode = tempNode->next;
    }
    return count;
}

String findParameterInSection(Node* head, String selector, String attribute) {
    String parameter = "";
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                String currentName = section->Name;
                int add = currentName.countSubstring(selector);
                if (add > 0) {
                    AiP* aip = section->AiPLIST;
                    while (aip != NULL) {
                        if (aip->Attribute == attribute) {
                            parameter = aip->Parameter;
                        }
                        aip = aip->next;
                    }
                }
            }
        }
        tempNode = tempNode->next;
    }
    return parameter;
}

void deleteSection(Node* head, String sectionName) {
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                if (section->Name == sectionName) {
                    // Delete the AiP list
                    AiP* aip = section->AiPLIST;
                    while (aip != NULL) {
                        AiP* temp = aip->next;
                        delete aip;
                        aip = temp;
                    }
                    // Delete the section
                    delete section;
                    tempNode->Table[i] = NULL;
                    // Move everything ahead of the deleted section back
                    Node* prevNode = tempNode->previous;
                    while (prevNode != NULL) {
                        bool isSectionDeleted = true;
                        for (int j = 0; j < T; j++) {
                            if (prevNode->Table[j] != NULL) {
                                isSectionDeleted = false;
                                break;
                            }
                        }
                        if (isSectionDeleted) {
                            prevNode->next = tempNode->next;
                            if (tempNode->next != NULL) {
                                tempNode->next->previous = prevNode;
                            }
                            delete tempNode;
                            return;
                        }
                        // Move the AiP lists
                        for (int j = 0; j < T; j++) {
                            if (prevNode->Table[j] != NULL) {
                                prevNode->Table[j]->AiPLIST->next = section->AiPLIST;
                                section->AiPLIST = prevNode->Table[j]->AiPLIST;
                                prevNode->Table[j]->AiPLIST = NULL;
                            }
                        }
                        // Move the section
                        for (int j = 0; j < T; j++) {
                            if (prevNode->Table[j] == NULL) {
                                prevNode->Table[j] = section;
                                tempNode->Table[i] = NULL;
                                delete tempNode;
                                return;
                            }
                        }
                        prevNode = prevNode->previous;
                    }
                    // If we get here, the deleted section was the first in the linked list
                    head = tempNode->next;
                    if (head != NULL) {
                        head->previous = NULL;
                    }
                    delete tempNode;
                    return;
                }
            }
        }
        tempNode = tempNode->next;
    }
}
void deleteSection(Node* head, int N) {
    int nodeIndex = 0;
    Node* tempNode = head;
    while (tempNode != nullptr) {
        int sectionIndex = 0;
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != nullptr) {
                if (++sectionIndex == N) {
                    Section* sectionToDelete = tempNode->Table[i];
                    tempNode->Table[i] = nullptr;
                    delete sectionToDelete->AiPLIST;
                    sectionToDelete->AiPLIST = nullptr;
                    delete sectionToDelete;
                    sectionToDelete = nullptr;
                    if (i < T - 1) {
                        tempNode->Table[i] = tempNode->Table[i + 1];
                        tempNode->Table[i + 1] = nullptr;
                    }
                    break;
                }
            }
        }
        nodeIndex++;
        tempNode = tempNode->next;
        if (sectionIndex == N && tempNode != nullptr) {
            tempNode->previous->next = tempNode->next;
            tempNode->next->previous = tempNode->previous;
            delete tempNode;
            tempNode = nullptr;
            break;
        }
    }
}

void deleteAiPByAttribute(Node* head, const String& attribute) {
    Node* tempNode = head;
    while (tempNode != NULL) {
        for (int i = 0; i < T; i++) {
            if (tempNode->Table[i] != NULL) {
                Section* section = tempNode->Table[i];
                AiP* currentAiP = section->AiPLIST;
                AiP* previousAiP = nullptr;
                while (currentAiP != NULL) {
                    if (currentAiP->Attribute == attribute) {
                        if (previousAiP == nullptr) {
                            section->AiPLIST = currentAiP->next;
                        }
                        else {
                            previousAiP->next = currentAiP->next;
                        }
                        delete currentAiP;
                        currentAiP = nullptr;
                        break;
                    }
                    previousAiP = currentAiP;
                    currentAiP = currentAiP->next;
                }

                // If section has no AiP blocks left, delete it
                if (section->AiPLIST == nullptr) {
                    if (tempNode->previous != nullptr) {
                        tempNode->previous->next = tempNode->next;
                    }
                    else {
                        head = tempNode->next;
                    }
                    if (tempNode->next != nullptr) {
                        tempNode->next->previous = tempNode->previous;
                    }
                    delete section;
                    section = nullptr;
                }
            }
        }
        tempNode = tempNode->next;
    }
}

void deleteAiPByAttribute(Node* head, int N, const String& attribute) {
    Node* tempNode = head;
    while (tempNode != nullptr && N > 0) {
        N -= T;
        tempNode = tempNode->next;
    }
    if (tempNode == nullptr || N < 0) {
        std::cerr << "Error: Section does not exist!" << std::endl;
        return;
    }
    Section* section = tempNode->Table[N % T];
    if (section == nullptr) {
        std::cerr << "Error: Section does not exist!" << std::endl;
        return;
    }
    AiP* prev = nullptr;
    AiP* curr = section->AiPLIST;
    while (curr != nullptr) {
        if (curr->Attribute == attribute) {
            if (prev != nullptr) {
                prev->next = curr->next;
            }
            else {
                section->AiPLIST = curr->next;
            }
            delete curr;
            if (section->AiPLIST == nullptr) {
                deleteSection(head, N);
            }
            return;
        }
        prev = curr;
        curr = curr->next;
    }
    std::cerr << "Error: Attribute does not exist!" << std::endl;
}

    void deleteAiP(Node * root, int N, String atr)
    {
        // check if N is valid
        if (N < 0 || N >= T)
            return;

        // find the Nth section
        Section* current = root->Table[N];

        // if the section is empty, return
        if (current == nullptr)
            return;

        // if the section has only one AiP and that AiP's Attribute matches atr, delete the section
        if (current->AiPLIST != nullptr && current->AiPLIST->next == nullptr && current->AiPLIST->Attribute == atr) {
            delete current->AiPLIST;
            root->Table[N] = nullptr;
            delete current;
            return;
        }

        // search for the AiP to be deleted
        AiP* prev = nullptr;
        AiP* curr = current->AiPLIST;
        while (curr != nullptr && curr->Attribute != atr) {
            prev = curr;
            curr = curr->next;
        }

        // if the AiP was not found, return
        if (curr == nullptr)
            return;

        // delete the AiP
        if (prev == nullptr)
            current->AiPLIST = curr->next;
        else
            prev->next = curr->next;
        delete curr;

        // update connections
        if (current->AiPLIST == nullptr) {
            // if the section is now empty, delete it
            delete current;
            root->Table[N] = nullptr;
        }
        else if (current->AiPLIST->next == nullptr) {
            // if the section has only one AiP left, create a new section and move the AiP there
            Section* newSection = new Section;
            newSection->Name = current->Name;
            newSection->AiPLIST = current->AiPLIST;
            root->Table[N] = newSection;
        }

        // update connections between sections
        if (N > 0 && root->Table[N - 1] == nullptr && root->Table[N]->AiPLIST == nullptr) {
            // if the previous section and the current section are both empty, delete the current node
            Node* prevNode = root->previous;
            Node* nextNode = root->next;
            if (prevNode != nullptr)
                prevNode->next = nextNode;
            if (nextNode != nullptr)
                nextNode->previous = prevNode;
            delete root;
        }
    }

int main()
{
    /*String Selectors = "1,2,3,4";
    String result;
    const char* masno = Selectors.c_str();
    result = nthpart(masno, 1);
    cout << result;*/

    String temp("");
    String tempC("");
    String previousTemp("");

    String CMtemp("");
    String CMtempC("");
    String CMpreviousTemp("");
    bool input = true;
    int SelectorCounter = 0;
    int ParameterCounter = 0;
    int AttributeCounter = 0;

    Node* head = new Node();
    Node* currentNode = head;
    head->next = NULL;
    head->previous = NULL;

    Section* headSection = new Section;
    Section* currentSection = headSection;

    AiP* headAiP = new AiP;
    AiP* currentAiP = headAiP;

    headAiP->next = NULL;
    head->Table[0] = headSection;
    currentSection->AiPLIST = currentAiP;

    bool FirstCom = true;
    bool SecondCom = false;
    bool ThirdCom = false;

    bool IsFirstNumber;
    bool IsThirdNumber;
    char SecondParameter;
    bool ThirdParQuestion = false;
    int FirstCommandNumber;
    int ThirdCommandNumber;

    const char* FirstParameter = "";

    String ThirdParameter = "";
    String Fcommand;

MASNO:
    while (input)
    {
        char c = getchar();


        if (c == '{') {
            if (temp.isEmpty() == true)
            {

                if (SelectorCounter == 0)
                {
                    currentSection->Name = previousTemp;
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
                else if (SelectorCounter % 8 == 0) {
                    Node* NextNode = new Node();    //next node tworzymy
                    currentNode->next = NextNode;   //link next w node1 = adresNextNode'a 
                    NextNode->previous = currentNode;   //previous link NextNode'a staje sie linkiem do aktualnego
                    NextNode->next = NULL;              //netxt link NextNode'a staje sie NULLEM
                    currentNode = NextNode;

                    Section* headSection = new Section; //tworzymy nową sekcje headSection
                    currentSection = headSection;  //tworzymy currentSection
                    currentSection->AiPLIST = NULL;

                    AiP* headAiP = new AiP;         //nowy 1 node AiP
                    currentAiP = headAiP;           //current node AiP

                    headAiP->next = NULL;
                    currentNode->Table[0] = currentSection;
                    currentSection->AiPLIST = currentAiP;
                    currentSection->Name = previousTemp;
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
                else
                {
                    Section* headSection = new Section;
                    currentSection = headSection;
                    AiP* headAiP = new AiP;         //nowy 1 node AiP
                    currentAiP = headAiP;           //current node AiP

                    headAiP->next = NULL;
                    currentNode->Table[SelectorCounter % 8] = currentSection;
                    currentSection->AiPLIST = currentAiP;
                    currentSection->Name = previousTemp;
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
            }

            if (temp.isEmpty() == false) {//cout << "bierzemy z linijki aktualnej";

                if (SelectorCounter == 0)
                {
                    currentSection->Name = temp;
                    temp.clear();
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
                else if (SelectorCounter % 8 == 0) {
                    Node* NextNode = new Node();    //next node tworzymy
                    currentNode->next = NextNode;   //link next w node1 = adresNextNode'a 
                    NextNode->previous = currentNode;   //previous link NextNode'a staje sie linkiem do aktualnego
                    NextNode->next = NULL;              //netxt link NextNode'a staje sie NULLEM
                    currentNode = NextNode;

                    Section* headSection = new Section; //tworzymy nową sekcje headSection
                    currentSection = headSection;  //tworzymy currentSection
                    currentSection->AiPLIST = NULL;

                    AiP* headAiP = new AiP;         //nowy 1 node AiP
                    currentAiP = headAiP;           //current node AiP

                    headAiP->next = NULL;
                    currentNode->Table[0] = currentSection;
                    currentSection->AiPLIST = currentAiP;
                    currentSection->Name = temp;
                    temp.clear();
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
                else {
                    Section* headSection = new Section;
                    currentSection = headSection;
                    AiP* headAiP = new AiP;         //nowy 1 node AiP
                    currentAiP = headAiP;           //current node AiP

                    headAiP->next = NULL;
                    currentNode->Table[SelectorCounter % 8] = currentSection;
                    currentSection->AiPLIST = currentAiP;
                    currentSection->Name = temp;
                    temp.clear();
                    ParameterCounter = 0;
                    AttributeCounter = 0;
                }
            }
        }
        else if (c == '}') {
            SelectorCounter++;
        }
        else if (c == ':') {
            if (AttributeCounter == 0) {
                temp.removeWhitespace();
                currentAiP->Attribute = temp;
                currentAiP->next = NULL;
                temp.clear();
                AttributeCounter++;
            }
            else {
                AiP* nextAiP = new AiP;
                currentAiP->next = nextAiP;
                currentAiP = nextAiP;
                currentAiP->Attribute = temp;
                currentAiP->next = NULL;
                temp.clear();
                AttributeCounter++;
            }
        }
        else if (c == ';') {
            currentAiP->Parameter = temp;
            temp.clear();
            removeWhitespacesFromAllAttributes(head);
            ParameterCounter++;
        }
        else if (c == '\n')
        {
            
            if (temp == "????") {
                input = false;
            }
            else {
                previousTemp = temp; // update previousTemp
                temp.clear();
            }
        }
        else if (c == EOF)
            return 0;

        else
        {
            tempC = String(c);
            temp += tempC;
        }

    }

    /*cout << findNthSectionName(head, 1);*/

    temp.clear();
    tempC.clear();
    previousTemp.clear();
    input = true;
    while (input == true) {           //COMMAND WHILE LOOP
        char cm = getchar();

        if (cm == ',')
        {
            if (FirstCom == true)
            {
                if (isdigit(CMtemp[0]) == 0)        //1st is not number
                {
                    Fcommand = CMtemp;
                    FirstParameter = CMtemp.c_str();
                    //cout << "1 command is: " <<FirstParameter<<endl;
                    FirstCom = false;
                    SecondCom = true;
                    IsFirstNumber = false;
                    CMtemp.clear();
                }
                else
                {
                    const char* CHARNumber = CMtemp.c_str();
                    FirstCommandNumber = atoi(CHARNumber);
                    //cout << "1 command is: " << FirstCommandNumber << endl;
                    FirstCom = false;
                    SecondCom = true;
                    IsFirstNumber = true;
                    CMtemp.clear();
                }
            }
            else if (SecondCom == true)
            {
                SecondParameter = CMtemp[0];
                //cout << "2 command is: " << SecondParameter<<endl;
                CMtemp.clear();
                SecondCom = false;
                ThirdCom = true;
            }

        }

        else if (cm == '\n')
        {
            if (ThirdCom == true)
            {
                if (isdigit(CMtemp[0]) == 0)
                {
                    if (CMtemp == '?')
                        ThirdParQuestion = true;

                    ThirdParameter = CMtemp;
                    //cout << "3 command is: " << ThirdParameter << endl;
                    FirstCom = true;
                    ThirdCom = false;
                    IsThirdNumber = false;
                    CMtemp.clear();
                }
                else
                {
                    const char* CHARNumber = CMtemp.c_str();
                    ThirdCommandNumber = atoi(CHARNumber);
                    //cout << "3 command is: " << number << endl;
                    FirstCom = true;
                    ThirdCom = false;
                    IsThirdNumber = true;
                    CMtemp.clear();
                }
                if (IsFirstNumber == true && SecondParameter == 'S' && IsThirdNumber == false && ThirdParQuestion == true)
                {
                    int N = FirstCommandNumber - 1;

                    int count = 0;
                    bool found = false;
                    Node* tempNode = head;
                    while (tempNode != NULL) {
                        for (int i = 0; i < T; i++) {
                            if (tempNode->Table[i] != NULL) {
                                if (count == N) {
                                    found = true;

                                    String FunctionSelectors = tempNode->Table[i]->Name;
                                    int currentLetter = 0;
                                    int selectorCount = 1;
                                    while (currentLetter < FunctionSelectors.length() - 1)
                                    {
                                        if (FunctionSelectors[currentLetter] == ',')
                                            selectorCount++;

                                        currentLetter++;

                                    }
                                    cout << FirstCommandNumber << ",S,? == " << selectorCount << endl;

                                }
                                count++;
                            }
                        }
                        if (found) {
                            break;
                        }
                        tempNode = tempNode->next;
                    }
                    ThirdParQuestion = false;
                }
                else if (IsFirstNumber == true && SecondParameter == 'A' && IsThirdNumber == false && ThirdParQuestion == true)
                {
                    int number = countAttributesInSection(head, FirstCommandNumber - 1);
                    if (number != 0)
                        cout << FirstCommandNumber << ",A,? == " << number << endl;
                    ThirdParQuestion = false;
                }
                else if (IsFirstNumber == true && SecondParameter == 'S' && IsThirdNumber == true && ThirdParQuestion == false)
                {

                    /*printSectionName(head, FirstCommandNumber, ThirdCommandNumber); */      //first is Node second is Section
                    String Selectors = getNthSectionName(head, FirstCommandNumber);
                    if (Selectors != "") {
                        const char* SelectorsChars = Selectors.c_str();
                        String Result = nthpart(SelectorsChars, ThirdCommandNumber);
                        if (Result != "")
                            cout << FirstCommandNumber << ",S," << ThirdCommandNumber << " == " << Result << endl;
                    }

                }
                else if (IsFirstNumber == true && SecondParameter == 'A' && IsThirdNumber == false && ThirdParQuestion == false)
                {
                    ThirdParameter.removeWhitespace();
                    if (findParameter(FirstCommandNumber - 1, ThirdParameter, head) != "wrong")
                    cout << FirstCommandNumber << ",A," << ThirdParameter << " == " << findParameter(FirstCommandNumber - 1, ThirdParameter, head) << endl;
                }
                else if (IsFirstNumber == false && SecondParameter == 'A' && IsThirdNumber == false && ThirdParQuestion == true)
                {
                    cout << Fcommand << ",A,? == " << countAttribute(Fcommand, head) << endl;
                    ThirdParQuestion = false;
                }
                else if (IsFirstNumber == false && SecondParameter == 'S' && IsThirdNumber == false && ThirdParQuestion == true)
                {
                    cout <<Fcommand <<",S,? == " << countStringInSectionNames(head, Fcommand) << endl;
                    ThirdParQuestion = false;
                }
                else if(IsFirstNumber == false && SecondParameter == 'E' && IsThirdNumber == false && ThirdParQuestion == false)
                {   
                    cout <<Fcommand<<",E,"<<ThirdParameter <<" == " << findParameterInSection(head, Fcommand, ThirdParameter)<<endl;
                }
                else if (IsFirstNumber == true && SecondParameter == 'D' && IsThirdNumber == false && ThirdParQuestion == false && ThirdParameter=='*')
                {
                    deleteSection(head, FirstCommandNumber);
                    cout << FirstCommandNumber << ",D,* == deleted" << endl;
                }
                else if (IsFirstNumber == true && SecondParameter == 'D' && IsThirdNumber == false && ThirdParQuestion == false)
                {
                    deleteAiP(head, FirstCommandNumber, ThirdParameter);
                    cout << FirstCommandNumber << ",D," << ThirdParameter << " == deleted" << endl;
                }

            }
            else if (CMtemp == '?')     //PRINT NUMBER OF SECTIONS
            {
                int count = 0;
                Node* tempNode = head;
                while (tempNode != NULL) {
                    for (int i = 0; i < T; i++) {
                        if (tempNode->Table[i] != NULL) {
                            count++;
                        }
                    }
                    tempNode = tempNode->next;
                }
                cout << "? == " << count << endl;
                CMtemp.clear();
                continue;
            }
            else if (CMtemp == "pppp") {    // WE GETTING BACK TO THE CSS 
                printAllAttributes(head);
                CMtemp.clear();
            }
            else if (CMtemp == "****") {    // WE GETTING BACK TO THE CSS 
                CMtemp.clear();
                goto MASNO;
            }
            else {

                CMpreviousTemp = CMtemp; // update previousTemp
                CMtemp.clear();
            }
        }
        else if (cm == EOF)
            return 0;
        else
        {
            CMtempC = String(cm);
            CMtemp += CMtempC;
        }

    }
    //printData(head);
    return 0;
}



//cout << head->Table[0]->Name << endl;
    //cout << head->Table[0]->AiPLIST->Attribute << endl;
    //cout << currentAiP->Attribute << endl;
    //cout << currentAiP->Parameter << endl;

