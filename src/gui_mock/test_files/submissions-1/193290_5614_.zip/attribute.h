struct Attribute {
    String name;
    String value;
    Attribute* next = nullptr;

    Attribute& getNode(int n) {
        if (n == 1) {
            return *this;
        }
        else {
            Attribute* tmp = this;
            for (int i = 1; i < n; i++) {
                if (tmp->next == nullptr) {
                    addAfter(tmp);
                }
                tmp = tmp->next;
            }
            return *tmp;
        }
    }

    void addAfter(Attribute* a) {
        Attribute* tmp = new Attribute;
        a->next = tmp;
    }

    void deleteNode() {
        if (this->getName().getText() != nullptr) {
            this->getName().deleteString();
        }
        if (this->getName().getText() != nullptr) {
            this->getValue().deleteString();
        }
    }

    String& getName() {
        return name;
    }

    String getValue() const {
        return value;
    }
};