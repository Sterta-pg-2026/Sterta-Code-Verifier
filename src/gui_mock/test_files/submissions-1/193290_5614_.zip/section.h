#include "selector.h"
#include "attribute.h"

class Section {
private:
    Selector selector_head;
    Attribute attribute_head;
    int deleted = 0;
public:

    Selector& getSelectors() {
        return selector_head;
    }

    Attribute& getAttributes() {
        return attribute_head;
    }

    void markDeleted() {
        this->deleted = 1;
    }

    int isDeleted() const {
        return deleted;
    }

    ~Section() {}

};