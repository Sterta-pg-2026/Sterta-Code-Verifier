#include <iostream>

class String {
private:
    char* text = nullptr;
    int size = 0;
public:
    String() = default;

    explicit String(const char* new_text) : text(new char[sizeof(new_text) + 1]), size(sizeof(new_text) + 1) {
        for (int i = 0; i < size - 1; i++) {
            text[i] = new_text[i];
        }
        text[size - 1] = '\0';
    }

    String(const String& other) {
        this->size = other.getSize();
        this->text = new char[size];
        for (int i = 0; i < size - 1; i++) {
            this->text[i] = other.getText()[i];
        }
        this->text[size - 1] = '\0';
    }

    char* getText() const {
        return text;
    };

    int getSize() const {
        return size;
    }

    void setTextFromRange(const char* new_text, int range) {
        this->size = range + 1;
        this->text = new char[size];
        for (int i = 0; i < size - 1; i++) {

            this->text[i] = new_text[i];
        }
        text[size - 1] = '\0';
    }

    void setSize(int new_size) {
        this->size = new_size;
    }

    char& operator[](int index) const {
        return text[index];
    }


    bool operator==(const String& other) const {
        if (size == other.size) {
            for (int i = 0; i < size; i++) {
                if ((*this)[i] != other[i]) {
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }

    String& operator=(const char* new_text) {
        size = sizeof(new_text) + 1;
        text = new char[size];
        for (int i = 0; i < size - 1; i++) {
            text[i] = new_text[i];
        }
        text[size - 1] = '\0';
        return *this;
    }

    void deleteString() {
        this->size = 0;
        delete[] this->text;
        this->text = nullptr;
    }

    ~String() {}
};
