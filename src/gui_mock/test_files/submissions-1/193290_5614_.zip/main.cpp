#include <iostream>
#include <cstdlib>
#include "string.h"
#include "block.h"

const bool CSS = true;
const bool CMD = false;
const int BUFFERSIZE = 128;
const char ATTRIBUTE = 'a';
const char SELECTOR = 's';
const char SPACEKEY = 32;
const char ENTERKEY = 10;

using namespace std;

ostream& operator<<(ostream& out, const String& str) {
    out << str.getText();
    return out;
}

int countSections(Block& block) {
    Block* tmp = nullptr;
    int count = 0;
    do {
        if (tmp == nullptr) {
            tmp = &block;
        }
        else tmp = tmp->getNext();
        count += tmp->getOccupied();
    } while (tmp->getNext() != nullptr);
    return count;
}


void stripArray(char* input_buffer, char mode) { //DO NOT TOUCH
    int size = 0;
    int k = 0;
    bool is_value = false;
    char stripped_buffer[BUFFERSIZE];
    while (input_buffer[size] != '\0') {
        size++;
    }
    if (mode == SELECTOR) is_value = true;
    for (int i = 0; i < size; i++) {
        if (mode == SELECTOR) {
            if (input_buffer[i - 1] <= SPACEKEY && input_buffer[i - 1] != ENTERKEY && input_buffer[i - 2] == ',') is_value = true;
            if (((input_buffer[i] > SPACEKEY || input_buffer[i] == ENTERKEY) && !is_value) || (is_value && input_buffer[i] >= SPACEKEY || input_buffer[i] == ENTERKEY)) {
                stripped_buffer[k] = input_buffer[i];
                k++;
            }
            if (input_buffer[i] == ',' || input_buffer[i + 2] == '{' || input_buffer[i + 2] == '\0') is_value = false;
        }
        else if (mode == ATTRIBUTE) {
            if ((input_buffer[i - 1] == ':' && (input_buffer[i] > SPACEKEY || input_buffer[i] == ENTERKEY)) || (input_buffer[i - 2] == ':' && input_buffer[i - 1] <= SPACEKEY && input_buffer[i - 1] != ENTERKEY)) is_value = true;
            if (((input_buffer[i] > SPACEKEY || input_buffer[i] == ENTERKEY) && !is_value) || is_value) {
                stripped_buffer[k] = input_buffer[i];
                k++;
            }
            if (input_buffer[i + 1] == ';') is_value = false;
        }

    }
    for (int l = 0; l < BUFFERSIZE; l++) {
        input_buffer[l] = '\0';
    }
    for (int j = 0; j < k; j++) {
        input_buffer[j] = stripped_buffer[j];
    }
}

void parseValue(Block* block, int section_node, int attribute_node, char line_buffer[]) { //no touching
    String string_buffer;
    int x = 0;
    while (line_buffer[x] != ';') {
        x++;
    }
    string_buffer.setTextFromRange(line_buffer, x);
    (*block)[section_node].getAttributes().getNode(attribute_node).value = string_buffer;
}

bool attributeDuplicateCheck(Block* block, String& name, int section_node, char line_buffer[], int current_node) {
    int attribute_node = 1;
    while (attribute_node < current_node) {
        if ((*block)[section_node].getAttributes().getNode(attribute_node).getName() == name) {
            parseValue(block, section_node, attribute_node, line_buffer);
            return true;
        }
        attribute_node++;
    }
    return false;
}

bool selectorDuplicateCheck(Block* block, String& name, int section_node, int current_node) {
    int selector_node = 1;
    while (selector_node < current_node) {
        if ((*block)[section_node].getSelectors().getNode(selector_node).getName() == name) {
            return true;
        }
        selector_node++;
    }
    return false;
}

void parseAttributes(Block* block, int& section_node, int c, char ready_buffer[]) { //no touching
    char line_buffer[BUFFERSIZE];
    String string_buffer;
    int attribute_node = 1, x = 0;

    if (c) {
        while (ready_buffer[x] != ':') {
            x++;
        }
        string_buffer.setTextFromRange(ready_buffer, x);
        (*block)[section_node].getAttributes().getNode(attribute_node).name = string_buffer;
        parseValue(block, section_node, attribute_node, ready_buffer + x + 1);
        attribute_node++;
        x = 0;
    }
    else {
        while (true) {

            cin.getline(line_buffer, BUFFERSIZE);
            stripArray(line_buffer, ATTRIBUTE);
            if (line_buffer[0] == '}') {
                break;
            }
            while (line_buffer[x] != ':') {
                x++;
            }

            string_buffer.setTextFromRange(line_buffer, x);
            if (attributeDuplicateCheck(block, string_buffer, section_node, line_buffer + x + 1, attribute_node)) {
                x = 0;
                continue;
            }
            (*block)[section_node].getAttributes().getNode(attribute_node).name = string_buffer;

            parseValue(block, section_node, attribute_node, line_buffer + x + 1);
            attribute_node++;
            x = 0;
        }
    }

    block->incrementOccupied();
    section_node++;
}

void parseSelectors(Block* block, bool& mode, int& section_node, bool& q) { //no touching
    char line_buffer[BUFFERSIZE];
    String string_buffer;
    int selector_node = 1, offset = 0, x = 0;

    if (cin.eof()) {
        q = true;
        return;
    }
    while (true) {
        cin.getline(line_buffer, BUFFERSIZE);
        stripArray(line_buffer, SELECTOR);

        if (line_buffer[0] == '{') {
            parseAttributes(block, section_node, false, line_buffer + BUFFERSIZE - 1);
            break;
        }
        if (line_buffer[0] == '\n') {
            break;
        }
        if (line_buffer[0] == '?') {
            mode = CMD;
            break;
        }

        while (*(line_buffer + offset) != '\0' && *(line_buffer + offset - 1) != '{') {
            while ((line_buffer + offset)[x] != ',' && (line_buffer + offset)[x] != '\0' && (line_buffer + offset)[x] != '{') {
                x++;
            }
            string_buffer.setTextFromRange(line_buffer + offset, x);
            if (selectorDuplicateCheck(block, string_buffer, section_node, selector_node)) {
                offset += (x);
                x = 0;
                continue;
            }
            (*block)[section_node].getSelectors().getNode(selector_node).name = string_buffer;
            selector_node++;
            offset += (x + 1);
            x = 0;
        }
        if (*(line_buffer + offset - 1) == '{' && *(line_buffer + offset) == '\0') {
            parseAttributes(block, section_node, false, line_buffer + 127);
            break;
        }
        else if (*(line_buffer + offset - 1) == '{' && *(line_buffer + offset) != '\0') {
            parseAttributes(block, section_node, true, line_buffer + offset);
            break;
        }
        offset = 0;
    }
}



void countSelectors(Block& block, int i, char command_buffer[128]) {
    int selector_node = 0, count = 0;

    if (i > countSections(block)) {
        return;
    }

    do {
        selector_node++;
        if (block.getSection(i).getSelectors().getNode(selector_node).name.getText() != nullptr) {
            count++;
        }
    } while (block.getSection(i).getSelectors().getNode(selector_node).next != nullptr);
    cout << command_buffer << " == " << count << endl;
}

void countSelectorsByName(Block& block, String& z, char command_buffer[128]) {
    int selector_node = 0, count = 0, section_q = countSections(block);
    for (int i = 1; i <= section_q; i++) {
        do {
            selector_node++;
            if (block.getSection(i).getSelectors().getNode(selector_node).getName() == z) {
                count++;
            }
        } while (block.getSection(i).getSelectors().getNode(selector_node).next != nullptr);
        selector_node = 0;
    }
    cout << command_buffer << " == " << count << endl;
}

void getSelectorBySection(Block& block, int i, int j, char command_buffer[128]) {

    if (i > countSections(block)) return;

    if ((j > 1 && block.getSection(i).getSelectors().getNode(j - 1).next == nullptr) || block.getSection(i).getSelectors().getNode(j).getName().getSize() == 0) {
        return;
    }

    cout << command_buffer << " == " << block.getSection(i).getSelectors().getNode(j).getName() << endl;
}

void getAttributeValue(Block& block, int i, String& n, char command_buffer[128]) {
    int attribute_node = 0;

    do {
        attribute_node++;
        if (block.getSection(i).getAttributes().getNode(attribute_node).getName() == n) {
            cout << command_buffer << " == " << block.getSection(i).getAttributes().getNode(attribute_node).getValue() << endl;
            return;
        }
    } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
}

void countAttributes(Block& block, int i, char command_buffer[128]) {
    int attribute_node = 0, count = 0;

    if (i > countSections(block)) {
        return;
    }

    do {
        attribute_node++;
        if (block.getSection(i).getAttributes().getNode(attribute_node).name.getSize() != 0) {
            count++;
        }
    } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
    cout << command_buffer << " == " << count << endl;
}

void countAttributesByName(Block& block, String& z, char command_buffer[128]) {
    int attribute_node = 0, count = 0, section_q = countSections(block);
    for (int i = 1; i <= section_q; i++) {
        do {
            attribute_node++;
            if (block.getSection(i).getAttributes().getNode(attribute_node).getName() == z) {
                count++;
            }
        } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
        attribute_node = 0;
    }
    
    cout << command_buffer << " == " << count << endl;
}

void getAttributeValueByName(Block& block, String& z, String& n, char command_buffer[128]) {
    int  selector_node = 0, attribute_node = 0, i = countSections(block);

    while (i > 0) {
        do {
            selector_node++;
            if (block.getSection(i).getSelectors().getNode(selector_node).getName() == z) {
                do {
                    attribute_node++;
                    if (block.getSection(i).getAttributes().getNode(attribute_node).getName() == n) {
                        cout << command_buffer << " == " << block.getSection(i).getAttributes().getNode(attribute_node).getValue() << endl;
                        return;
                    }
                } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
                attribute_node = 0;
            }
        } while (block.getSection(i).getSelectors().getNode(selector_node).next != nullptr);
        selector_node = 0;
        i--;
    }
}

void deleteSection(Block& block, int i, char command_buffer[128]) {
    int block_node = 1, section_node = i, selector_node = 1, attribute_node = 1;

    if (i > countSections(block)) return;

    while (section_node > T) {
        section_node -= T;
        block_node++;
    }
    while (block.getSection(i).getSelectors().getNode(selector_node).next != nullptr) {
        selector_node++;
    }
    while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr) {
        attribute_node++;
    }
    while (selector_node > 0) {
        block.getSection(i).getSelectors().getNode(selector_node).deleteNode();
        selector_node--;
    }
    while (attribute_node > 0) {
        block.getSection(i).getAttributes().getNode(attribute_node).deleteNode();
        attribute_node--;
    }

    block.getSection(i).markDeleted();
    block.getNode(block_node).decrementOccupied();
    cout << command_buffer << " == deleted" << endl;
}

void deleteAttribute(Block& block, int i, String& n, char command_buffer[128]) {
    int attribute_node = 0, attribute_q = 0;
    do {
        attribute_node++;
        if (block.getSection(i).getAttributes().getNode(attribute_node).getName().getSize() != 0) {
            attribute_q++;
        }
    } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
    attribute_node = 0;
    do {
        attribute_node++;
        if (block.getSection(i).getAttributes().getNode(attribute_node).getName() == n) {

            if (attribute_q == 1) {
                deleteSection(block, i, command_buffer);
            }
            else {
                block.getSection(i).getAttributes().getNode(attribute_node).deleteNode();
                cout << command_buffer << " == deleted" << endl;
            }
            return;
        }
    } while (block.getSection(i).getAttributes().getNode(attribute_node).next != nullptr);
}

void dispatchCommands(Block& block, int i, int j, char C, String& z, String& n, char command_buffer[128]) {
    if (C == 'S' && i != 0 && n.getText() != nullptr && n[0] == '?') { // i,S,?
        countSelectors(block, i, command_buffer);
    }
    else if (C == 'S' && i != 0 && j != 0) { //i,S,j
        getSelectorBySection(block, i, j, command_buffer);
    }
    else if (C == 'S' && z.getText() != nullptr && n.getText() != nullptr && n[0] == '?') { // z,S,?
        countSelectorsByName(block, z, command_buffer);
    }
    else if (C == 'A' && i != 0 && n.getText() != nullptr && n[0] == '?') { //i,A,?
        countAttributes(block, i, command_buffer);
    }
    else if (C == 'A' && i != 0 && n.getText() != nullptr) { //i,A,n
        getAttributeValue(block, i, n, command_buffer);
    }
    else if (C == 'A' && z.getText() != nullptr && n.getText() != nullptr && n[0] == '?') { //z,A,?
        countAttributesByName(block, z, command_buffer);
    }
    else if (z.getText() != nullptr && z[0] == '?') { //?
        cout << command_buffer << " == " << countSections(block) << endl;
    }
    else if (C == 'E') {
        getAttributeValueByName(block, z, n, command_buffer);
    }
    else if (C == 'D' && i != 0 && n.getText() != nullptr && n[0] != '*') {
        deleteAttribute(block, i, n, command_buffer);
    }
    else if (C == 'D' && i != 0 && n.getText() != nullptr && n[0] == '*') {
        deleteSection(block, i, command_buffer);
    }
}

void parseCommands(Block* block, bool& mode, bool& q) {
    char command_buffer[BUFFERSIZE], C = '\0';
    int x = 0, offset = 0, pos = 1, i = 0, j = 0;
    String z, n, buffer;

    if (cin.eof()) {
        q = true;
        return;
    }
    cin.getline(command_buffer, BUFFERSIZE);
    stripArray(command_buffer, SELECTOR);
    if (command_buffer[0] == '*' && command_buffer[1] == '*') {
        mode = CSS;
        return;
    }
    while (pos < 4) {
        while ((command_buffer + offset)[x] != ',' && (command_buffer + offset)[x] != '\0') {
            x++;
        }
        if (pos == 1 && isdigit(*(command_buffer + offset))) {
            buffer.setTextFromRange(command_buffer + offset, x);
            i = atoi(buffer.getText());
        }
        else if (pos == 1 && !isdigit(*(command_buffer + offset))) {
            z.setTextFromRange(command_buffer + offset, x);
        }
        else if (pos == 2) {
            C = *(command_buffer + offset);
        }
        else if (pos == 3 && isdigit(*(command_buffer + offset))) {
            buffer.setTextFromRange(command_buffer + offset, x);
            j = atoi(buffer.getText());
        }
        else if (pos == 3 && !isdigit(*(command_buffer + offset))) {
            n.setTextFromRange(command_buffer + offset, x);
        }
        pos++;
        offset += (x + 1);
        x = 0;
    }
    dispatchCommands(*block, i, j, C, z, n, command_buffer); //c
}

int main() {
    int block_node = 1, section_node = 0;
    bool mode = CSS;
    bool q = false;
    Block block, * current_block = &block;

    while (!q) {

        if (mode == CSS) {
            if (current_block->getOccupied() == T || section_node == T) {
                current_block->appendBlock();
                current_block = current_block->getNext();
                section_node = 0;
            }
            parseSelectors(current_block, mode, section_node, q);
        }
        else if (mode == CMD) {
            parseCommands(&block, mode, q);
        }
    }
    return 0;
}