struct Selector {
    String name;
    Selector* next = nullptr;

    Selector& getNode(int n) {
        if (n == 1) {
            return *this;
        }
        else {
            Selector* tmp = this;
            for (int i = 1; i < n; i++) {
                if (tmp->next == nullptr) {
                    addAfter(tmp);
                }
                tmp = tmp->next;
            }
            return *tmp;
        }
    }

    void addAfter(Selector* s) {
        Selector* tmp = new Selector;
        s->next = tmp;
    }

    void deleteNode() {
        if (this->getName().getText() != nullptr) {
            this->getName().deleteString();
        }
    }

    String getName() const {
        return name;
    }

};



