#include "section.h"

const int T = 17;

class Block {
private:
    Block* next = nullptr;
    Block* prev = nullptr;
    Section section_array[T];
    int occupied = 0;
public:
    Block& getNode(int n) {
        Block* tmp = this;
        for (int i = 1; i < n; i++) {
            tmp = tmp->next;
        }
        return *tmp;
    }

    void appendBlock() {
        Block* new_node = new Block;
        this->next = new_node;
        new_node->prev = this;
    }

    void incrementOccupied() {
        this->occupied++;
    }

    void decrementOccupied() {
        this->occupied--;
    }

    Section& getSection(int index) { //for executing commands
        Block* tmp_block = nullptr;
        Section* d = new Section;
        int x = 0, section_node = 0;
        do {
            if (tmp_block == nullptr) tmp_block = this;
            else tmp_block = tmp_block->next;
            while (section_node < T) {
                if (!(*tmp_block)[section_node].isDeleted()) {
                    x++;
                }
                if (x == index) return (*tmp_block)[section_node];
                section_node++;
            }
            section_node = 0;
        } while (tmp_block->getNext() != nullptr);
        return *d;
    }

    Section& operator[](int index) { //for parsing CSS
        return section_array[index];
    }

    Block* getNext() {
        return next;
    }

    Block* getPrev() {
        return prev;
    }

    int getOccupied() {
        return occupied;
    }

    ~Block(){}
};



