#include <iostream>
#include <stdio.h>
#include "mystring.h"
#include "para.h"
#include "mainlist.h"
#include "linkedlist.h"

using namespace std;


void clear_tempstring(char tempstring[], int& size) {
	for (int i = 0; i < size; ++i)
		tempstring[i] = '\0';
	size = 0;
}

bool is_number(const char* arr)
{
	int i;
	const int len = strlen(arr);

	for (i = 0; i < len; i++)
	{
		if (!isdigit(arr[i])) {
			return 0;
		}
	}
	return 1;
}

int get_position_of_name(const LinkedList<Para<MyString, MyString>>& lista, const MyString& name) {
	int pos = -1;
	Node<Para<MyString, MyString>>* temp = lista.head;
	
	int i = 0;
	while (temp != NULL) {
		if (temp->data.first == name) {
			pos = i;
		}
		i++;
		temp = temp->next;
	}
	return pos;
}


int main()
{
	MainList mainlist = MainList();

	while (1) {

		//loading separate section
		int loading_mode = 0;//0 - loading sections=selectors
		char znak;
		char tempstring[500];
		int tempstringSize = 500;

		clear_tempstring(tempstring, tempstringSize);

		Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data;

		MyString currentAttributeName = MyString();
		MyString currentAttributeValue = MyString();

		while (1) {
			znak = getchar();

			if (znak == EOF) {
				return 0;
			}
			if (znak == '}')
			{
				mainlist.insert_at_end(data);
				break;
			}

			if (loading_mode == 0) {//reading selectors
				if (znak == ',') {
					MyString selector = MyString(tempstring);
					selector.delete_white_chars();
					data.first.insert_at_end(selector); //add to selectors list
					clear_tempstring(tempstring, tempstringSize);
				}
				else if (znak == '{') {
					MyString selector = MyString(tempstring);
					selector.delete_white_chars();
					data.first.insert_at_end(selector);  //add to selectors list             
					clear_tempstring(tempstring, tempstringSize);
					loading_mode = 1;
				}
				else {
					tempstring[tempstringSize++] = znak;
				}


				//transition to reading command questions
				if (tempstringSize >= 4 && tempstring[tempstringSize - 1] == '?' && tempstring[tempstringSize - 2] == '?'
					&& tempstring[tempstringSize - 3] == '?' && tempstring[tempstringSize - 4] == '?') {
					loading_mode = 3;
					clear_tempstring(tempstring, tempstringSize);
				}
				//
			}
			else if (loading_mode == 1) {//loadig attributes-key
				if (znak == ':') {
					currentAttributeName = MyString(tempstring);
					currentAttributeName.delete_white_chars();

					clear_tempstring(tempstring, tempstringSize);

					loading_mode = 2;
				}
				else {
					tempstring[tempstringSize++] = znak;
				}
			}
			else if (loading_mode == 2) {//reading value
				if (znak == ';') {
					currentAttributeValue = MyString(tempstring);
					currentAttributeValue.delete_white_chars();

					int existing_pos = get_position_of_name(data.second, currentAttributeName);
					if (existing_pos != -1) {
						data.second.delete_at_position(existing_pos+1);
					}
					data.second.insert_at_end(Para<MyString, MyString>(currentAttributeName, currentAttributeValue));

					clear_tempstring(tempstring, tempstringSize);
					loading_mode = 1;
				}
				else {
					tempstring[tempstringSize++] = znak;
				}
			}
			else if (loading_mode == 3) {//reading commands to mainlist
				
				if (znak == '\n') //start interpretating command questions, each after an enter
				{
					MyString command = MyString(tempstring);
					if (command.size == 0)
						// we catched the first enter after previous command
						continue;
					if (command == "?")
						cout << "? == " << mainlist.count_occupied_nodes() << endl;
					else if (command == "****") {
						break;
					}
					else {//zawiera przecinki
						MyString command1 = command.split_by_comma(0);
						MyString command2 = command.split_by_comma(1);
						MyString command3 = command.split_by_comma(2);
						if (command2 == "S") {
							if (!(command3 == "?")) {
								// i, S, j wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybut�w zaczynaj� si� od 1) je�li nie
								//ma sekcji lub selektora pomi�;
								int i = atoi(command1.str);
								int j = atoi(command3.str);
								LinkedList<MyString> section = mainlist.find_section_by_position(i).first;
								if (section.size > 0) {
									MyString selector = section.find_element_at_position(j);
									if (selector.size > 0) {
										cout << command << " == " << selector << endl;
									}
								}
							}
							else {
								if (is_number(command1.str)) {
									//  wypisz liczb� selektor�w dla sekcji nr i , je�li nie ma takiego bloku pomi�
									int i = atoi(command1.str);
									int size = mainlist.find_section_by_position(i).first.size;
									if (size != 0)
										cout << command << " == " << size << endl;
								}
								else {
									// wypisz ��czn�(dla wszystkich blok�w) liczb� wyst�pie� selektora z. Mo�liwe jest 0
									int occurances = mainlist.get_num_occurances_of_selector(command1);
									cout << command << " == " << occurances << endl;
								}

							}
						}
						else if (command2 == "A") {
							if (!(command3 == "?")) {
								// i,A,n � wypisz dla i-tej sekcji warto�� atrybutu o nazwie n, je�li nie ma takiego pomi�;
								int i = atoi(command1.str);
								MyString result = mainlist.get_val_of_section_attr(command3, i);
								if (result.size != 0)
									cout << command << " == " << result << endl;
							}
							else {
								if (is_number(command1.str)) {
									//  i,A,? - wypisz liczb� atrybut�w dla sekcji nr i, je�li nie ma takiego bloku lub sekcji pomi�
									int i = atoi(command1.str);
									int result = mainlist.find_section_by_position(i).second.size;
									if (result != 0)
										cout << command << " == " << result << endl;
								}
								else {
									//n, A, ? � wypisz ��czn�(dla wszystkich blok�w) liczb� wyst�pie� atrybutu nazwie n
									int occurances = mainlist.get_num_occurances_of_attribute(command1);
									cout << command << " == " << occurances << endl;
								}
							}

						}
						else if (command2 == "E") {
							// z, E, n � wypisz warto�� atrybutu o nazwie n dla selektora z, w przypadku wielu wyst�pie� selektora z
							// bierzemy ostatnie.W przypadku braku pomi�
							MyString res = mainlist.get_attr_val_per_selector_and_name(command1, command3);
							if (res.size > 0) {
								cout << command << " == " << res << endl;
							}
						}
						else if (command2 == "D") {
							if (command3 == "*") {
								//i,D,* - usu� ca�� sekcj� nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted
								int i = atoi(command1.str);
								mainlist.delete_at_position(i);
								cout << command << " == deleted" << endl;
							}
							else {
								//i,D,n � usu� z i-tej sekcji atrybut o nazwie n, je�li w wyniku operacji pozostaje pusta sekcja powinna
								int i = atoi(command1.str);
								mainlist.remove_section_arrtibute(command3, i);
								cout << command << " == deleted" << endl;
							}
						}
					}
					clear_tempstring(tempstring, tempstringSize);
				}
				else
					tempstring[tempstringSize++] = znak;
			}
		}
	}

	return 0;
}


