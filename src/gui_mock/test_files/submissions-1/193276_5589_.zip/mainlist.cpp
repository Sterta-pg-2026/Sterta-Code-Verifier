#include <iostream>
#include "mystring.h"
#include "para.h"
#include "mainlist.h"

using namespace std;

int _get_position_of_name(const LinkedList<Para<MyString, MyString>>& lista, const MyString& name) {
	Node<Para<MyString, MyString>>* temp = lista.head;
	if (temp == NULL) {
		return -1;
	}
	int i = 0;
	while (temp != NULL) {
		if (temp->data.first == name) {
			return i;
		}
		i++;
		temp = temp->next;
	}
	return -1;
}

MainList::MainList() {
	head = NULL;
	tail = NULL;
}

MainList::~MainList() {
	/*
	MainNode* current = new MainNode();
	MainNode* next = new MainNode();
	current = this->head;
	if(head!= NULL)
		next = head->next;

	while (next != NULL) {
		delete current;
		current = next;
		next = next -> next;
	}
	delete next;
	delete current;*/
}



void MainList::insert_at_end(Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data) {

	if (tail == NULL) {
		MainNode* newNode = new MainNode();
		tail = newNode;
		head = newNode;
	}
	else if (tail->occupied == SIZE_T-1) {
		MainNode* newNode = new MainNode();
		newNode->prev = tail;
		tail->next = newNode;
		tail = newNode;
	}
	
	tail->array[tail->occupied] = data;
	tail->occupied++;
}

void MainList::delete_at_position(int position) {

	if (position < 1 || head==NULL) {
		return;
	}
	
	MainNode* temp = head;
	int i = 0;
	while (temp != NULL) {
		if (temp->occupied >= position)
		{			
			temp->delete_from_array(position - 1);
			//tylko tu occupied moze byc 0
			if (temp->occupied == 0)
				this->delete_node(temp);

			break;
		}
		i++;
		position -= temp->occupied;
		temp = temp->next;
	}
}

void MainList::delete_node(MainNode* node) {//deleting section
	if (node == this->head && node == this->tail)
	{
		this->head = NULL;
		this->tail = NULL;
	}
	else if (node == head) {
		head = node->next;
		head->prev = NULL;
	}
	else if (node == tail) {
		tail = node->prev;
		tail->next = NULL;
	}
	else {
		node->prev->next = node->next;
		node->next->prev = node->prev;
	}

	delete(node);
}


Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> MainList::find_section_by_position(int position) {
	
	Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> result;
	MainNode* temp = head;

	while (temp != NULL) {
		if (temp->occupied >= position) {
			result = temp->array[position - 1];
			break;
		}			
		position -= temp->occupied;
		temp = temp->next;
	}
	
	return result;

}


/*void MainList::print_list() {       for debugging only
	MainNode* main_node = this->head;

	while (main_node != NULL) {

		for (int i = 0; i < main_node->occupied; ++i) {
			Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data = main_node->array[i];
			
			LinkedList<MyString> selectors = data.first;
			LinkedList<Para<MyString, MyString>> attr_to_values = data.second;
		}
		main_node = main_node->next;
	}
}*/

int MainList::count_occupied_nodes() {
	int wynik=0;

	MainNode* main_node = this->head;

	while (main_node != NULL) {

		wynik += main_node->occupied;
		main_node = main_node->next;
	}

	return wynik;
}

int MainList::get_num_occurances_of_selector(MyString selector) {
	MainNode* main_node = this->head;
	int occurances = 0;

	while (main_node != NULL) {

		for (int i = 0; i < main_node->occupied; ++i) {
			Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data = main_node->array[i];

			LinkedList<MyString> selectors = data.first;
			occurances += selectors.get_num_occurances(selector);
		}
		main_node = main_node->next;
	}
	return occurances;
}


int MainList::get_num_occurances_of_attribute(MyString name) {

	MainNode* main_node = this->head;
	int occurances = 0;

	while (main_node != NULL) {

		for (int i = 0; i < main_node->occupied; ++i) {
			Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data = main_node->array[i];

			LinkedList<Para<MyString, MyString>> attrs = data.second;
			
			//chodzenie po liscie
			Node<Para<MyString, MyString>>* temp = attrs.head;
			MyString result;

			while (temp != NULL) {
				if (temp->data.first == name) {
					++occurances;
				}
				temp = temp->next;
			}
		}
		main_node = main_node->next;
	}
	return occurances;
}


MyString MainList::get_val_of_section_attr(MyString name, int section) {
	LinkedList<Para<MyString, MyString>> lista = this->find_section_by_position(section).second;
	MyString result;

	if (lista.size == 0) {
		return result;
	}
	Node<Para<MyString, MyString>>* temp = lista.head;
	

	while (temp != NULL) {
		if (temp->data.first == name) {
			return temp->data.second;
		}
		temp = temp->next;
	}
	return result;

}

bool MainList::remove_section_arrtibute(MyString name, int section) {
	LinkedList<Para<MyString, MyString>> lista = this->find_section_by_position(section).second;
	
	if (lista.size == 0) {
		return false;
	}
	
	int pos = _get_position_of_name(lista, name);

	if (pos == -1) {
		return false;
	}

	lista.delete_at_position(pos+1);

	if (lista.size == 0) {
		this->delete_at_position(section);
	}
	return true;
}

MyString MainList::get_attr_val_per_selector_and_name(MyString selector, MyString name) {
	MainNode* main_node = this->tail;
	MyString result;
	while (main_node != NULL) {

		for (int i = main_node->occupied -1; i >= 0 ; --i) {
			Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data = main_node->array[i];

			LinkedList<MyString> selectors = data.first;
			int occurances = selectors.get_num_occurances(selector);
			if (occurances > 0) {
				LinkedList<Para<MyString, MyString>> attrs = data.second;

				Node<Para<MyString, MyString>>* temp = attrs.head;
				

				while (temp != NULL) {
					if (temp->data.first == name) {
						result = temp->data.second;
					}
					temp = temp->next;
				}
				if (result.size != 0)
					return result;
			}

		}
		main_node = main_node->prev;
	}
	return result;
}