#include <iostream>
#include "mystring.h"
#include "para.h"
#include "linkedlist.h"

using namespace std;


template <typename T>
LinkedList<T>::LinkedList() {
	head = NULL;
	size = 0;
}

template <typename T>
LinkedList<T>::~LinkedList() {
	/*
	Node<T>* current = new Node<T>();
	Node<T>* next = new Node<T>();
	current = this->head;
	if (head != NULL)
		next = head->next;

	while (next != NULL) {
		delete current;
		current = next;
		next = next->next;
	}
	delete next;
	delete current;*/
}



// function to insert a new Node with given data in the front of the list
template <typename T>
void LinkedList<T>::insert_at_end(T data) {
	this->size++;
	
	Node<T>* newNode = new Node<T>();

	newNode->data = data;

	newNode->next = NULL;
	newNode->prev = NULL;
 
	if (head == NULL) {
		head = newNode;
	}
	else {

		Node<T>* temp = head;
		while (temp->next != NULL)
			temp = temp->next;

		temp->next = newNode;
		newNode->prev = temp;
	}
}

template <typename T>
void LinkedList<T>::delete_at_position(int position) {

	 if (position == 1 && head != NULL) {
		Node<T>* nodeToDelete = head;
		head = head->next;
		free(nodeToDelete);
		if (head != NULL)
			head->prev = NULL;
		this->size--;
	}
	else {
		Node<T>* temp = head;
		for (int i = 1; i < position - 1; i++) {
			if (temp != NULL) {
				temp = temp->next;
			}
		}
 
		if (temp != NULL && temp->next != NULL) {
			Node<T>* nodeToDelete = temp->next;
			temp->next = temp->next->next;
			if (temp->next->next != NULL)
				temp->next->next->prev = temp->next;
			free(nodeToDelete);
		}
		this->size--;
	}
}

/*used only for debuggiing
template <typename T>
void LinkedList<T>::print_list() {
	Node<T>* temp = this->head;

	while (temp != NULL) {
		std::cout << temp->data << endl;
		temp = temp->next;
	}
}*/


template <typename T>
T LinkedList<T>::find_element_at_position(int position) {

	Node<T>* temp = this->head;

	for (int i = 1; i < position; i++) {
		if (temp != NULL) {
			temp = temp->next;
		}
	}
	if (temp == NULL) {
		return T();
	}
	return temp->data;

}

template <typename T>
int LinkedList<T>::get_num_occurances(T data) {
	Node<T>* temp = this->head;
	int result = 0;
	while (temp != NULL) {
		if (temp->data == data) {
			result++;
		}
		temp = temp->next;
	}
	return result;
}

template class LinkedList<MyString>;
template class LinkedList<Para<MyString, MyString>>;
