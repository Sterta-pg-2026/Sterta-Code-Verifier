#pragma once
#include <ostream>
#include "para.h"
#include "mystring.h"
#include "linkedlist.h"

using namespace std;

template <typename T1, typename T2>
Para<T1, T2>::Para() {
    this->first = T1();
    this->second = T2();
}

template <typename T1, typename T2>
Para<T1, T2>::Para(T1 first, T2 second) {
    this->first = first;
    this->second = second;
}

template <typename T1, typename T2>
Para<T1,T2>:: ~Para<T1, T2>() {
   // delete first;
    //delete second;
}

std::ostream& operator<<(std::ostream& ostream, const Para<MyString, MyString>& obj)
{
    ostream << obj.first << " -> " << obj.second;
    return ostream;
}



template class Para<MyString, MyString>;
template class Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>>;