#include <iostream>
#include "para.h"
#include "linkedlist.h"
#include "mystring.h"

#define SIZE_T 17

using namespace std;

int _get_position_of_name(const LinkedList<Para<MyString, MyString>>& lista, const MyString& name);

struct MainNode {
public:
    Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> array[SIZE_T]; //data
    MainNode* prev;
    MainNode* next;
    int occupied;


    // default constructor
    MainNode()
    {
        prev = NULL;
        next = NULL;
        occupied = 0;
    } 

    void delete_from_array(int position) {
        Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> temp[SIZE_T];

        int tempi = 0, arrayi = 0;

        while (arrayi < this->occupied) {
            if (arrayi == position) {
                arrayi++;
                continue;
            }

            temp[tempi] = array[arrayi];
            arrayi++;
            tempi++;
        }
        this->occupied--;
        for (int i = 0; i < this->occupied; i++) {
            this->array[i] = temp[i];
        }
    }

    ~MainNode() {
       // for (int i = 0; i < SIZE_T; ++i)
         //   delete array[i];
        delete prev;
        delete next;
   
    }

};


class MainList
{
public:
    MainNode* head;
    MainNode* tail;

    MainList();

    void insert_at_end(Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> data);
    void delete_at_position(int position);
   // void print_list();
    int count_occupied_nodes();
    int get_num_occurances_of_selector(MyString selector);
    int get_num_occurances_of_attribute(MyString name);
    bool remove_section_arrtibute(MyString name, int section);
    MyString get_val_of_section_attr(MyString name, int section);
    Para<LinkedList<MyString>, LinkedList<Para<MyString, MyString>>> find_section_by_position(int position);
    MyString get_attr_val_per_selector_and_name(MyString selector, MyString name);
    void delete_node(MainNode* node);

    ~MainList();
    
};

