#pragma once
#include <iostream>

class MyString
{
public:
	char* str;
	unsigned int size;

public:
	MyString();// default constructor
	~MyString();
	MyString(const char* buffer); // constructor  
    MyString(const MyString& obj); // copy constructor

	void delete_white_chars();
	MyString split_by_comma(int position);

	friend bool operator== (const MyString& a, const MyString& b);
	friend std::ostream& operator<<(std::ostream& os, const MyString& str);
	MyString& operator=(const MyString& other);
};
