#include <cstring>
#include <iostream>
#include "mystring.h"
using namespace std;


MyString::MyString() : str(nullptr), size(0) // default constructor
{
}

MyString::~MyString()
{
    delete[] this->str;
}

MyString::MyString(const char* buffer) // constructor
{
    size = strlen(buffer);
    str = new char[size + 1]; // + 1 for the keeping the null character
    strncpy_s(str, size + 1, buffer, size); // copy from the incoming buffer to character buffer of the new object   
}


MyString::MyString(const MyString& obj) // copy constructor
{
    size = obj.size;
    str = new char[size + 1]; // + 1 for the keeping the null character
    strncpy_s(str, size + 1, obj.str, size); // copy from the incoming buffer to character buffer of the new object
}

void MyString::delete_white_chars() {
    unsigned int start = 0;
    unsigned int end = this->size - 1;

    // Find the first non-whitespace character
    while (start < this->size && isspace(this->str[start])) {
        start++;
    }

    // Find the last non-whitespace character
    while (end > start && isspace(this->str[end])) {
        end--;
    }

    // If the string is all whitespace, set the size to 0
    if (start == this->size || end == start - 1) {
        this->size = 0;
    }
    else {
        // Shift the string to remove leading whitespace
        for (unsigned int i = start; i <= end; i++) {
            this->str[i - start] = this->str[i];
        }

        // Update the size of the string
        this->size = end - start + 1;

        // Add null terminator at the end
        this->str[this->size] = '\0';
    }

}

bool operator==(const MyString& a, const MyString& b) {
    if (a.size != b.size) {
        return false;
    }

    for (unsigned int i = 0; i < a.size; i++) {
        if (a.str[i] != b.str[i]) {
            return false;
        }
    }

    return true;
}


MyString MyString::split_by_comma(int position) {
    int iterator = 0;

    char tempstring[100];
    for (int i = 0; i < 100; ++i)
        tempstring[i] = '\0';
    int tempstringSize = 0;

    for (int i = 0; i < this->size; ++i) {
        if (this->str[i] != ',')
            tempstring[tempstringSize++] = this->str[i];
        else {
            tempstring[tempstringSize++] = '\0';
            if (position == iterator) {
                tempstring[tempstringSize] = '\0';
                return MyString(tempstring);
            }
            ++iterator;

            for (int j = 0; j < tempstringSize; ++j)
                tempstring[j] = '\0';
            tempstringSize = 0;
        }
        if (tempstringSize >= 99)
            break;
    }
    tempstring[tempstringSize] = '\0';
    return MyString(tempstring);
}

MyString& MyString::operator=(const MyString& other)
{
    if (this != &other) {  // check for self-assignment
        // Free the old memory
        delete[] str;

        // Allocate new memory for the new string
        size = other.size;
        str = new char[size + 1];

        // Copy the characters from the other string
        std::copy(other.str, other.str + size, str);
        str[size] = '\0';
    }
    return *this;
}

std::ostream& operator<<(std::ostream& os, const MyString& str)
{
    os << str.str;
    return os;
}

