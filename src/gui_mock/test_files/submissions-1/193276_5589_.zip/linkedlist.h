#pragma once
#include <iostream>

template <typename T> 
struct Node {
public:

    T data;
    Node* prev;
    Node* next;

    // default constructor
    Node()
    {
        prev = NULL;
        next = NULL;
    }

    // custom constructor
    Node(const T& val)
    {
        prev = NULL;
        data = val;
        next = NULL;
    } 

    ~Node() {
        //delete data;
        delete prev;
        delete next;
    }
};

template <typename T>
class LinkedList
{
public:
    Node<T>* head;
    int size;

    LinkedList();

    void insert_at_end(T data);
    T find_element_at_position(int position);
    void delete_at_position(int position);
    //void print_list();//for debugging
    int get_num_occurances(T data);
    

    ~LinkedList();
};

