#pragma once
using namespace std;

template<typename T1, typename T2>
class Para {
public:
    T1 first;
    T2 second;

    Para();
    Para(T1 first,  T2 second);


    friend std::ostream& operator<<(std::ostream& ostream, const Para<T1, T2>& obj);
    friend bool operator== (const Para<T1, T2>& a, const Para<T1, T2>& b) { return false; }

    ~Para();
};

