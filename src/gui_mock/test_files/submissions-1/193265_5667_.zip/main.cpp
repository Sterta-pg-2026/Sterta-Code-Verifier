#include <iostream>
#include "mystring.h"
#include "css.h"
#include"list.h"
#include <cstdlib> 
using namespace std;

void removeLastEmptyChar(MyString &str) {
	for (int i = str.length() - 1; i >= 0; i--) {
		if (str.getChar(i)<33) {
			str.str[i] = '\0';
		} else {
			return;
		}
	}
}
void checkIsSekcjaEmpty(Css& object) {
	int counter = 0;
	NodeZTablica* tmp = object.head;
	while (tmp != nullptr) {
		counter = 0;
		for (int i = 0; i < tmp->size; i++) {
			if (tmp->sekcje[i].atrybuty->head == nullptr) {
				counter++;
				if (counter == Wielkosci::SIZE_T) {
					object.deleteNode();
					return;
				}
			}
		}
		tmp = tmp->next;
	}
	return;
}

void separateSelector1(Css &object, MyString& str) {
	MyString temp;
	// object.addSekcja();
	bool isChar = false;

	for (int i = 0; i < str.length(); ++i) {
		if (str.getChar(i) >32 && isChar == false) {
			isChar = true;
		}
		if (str.getChar(i) == ',') {
			isChar = false;
			removeLastEmptyChar(temp);
			if (object.current->sekcje[object.current->size].selektory->nodeExists(temp) == false) {
				object.current->sekcje[object.current->size].selektory->addNodeTail(temp);
			}
			temp.clear();
			continue;
		}
		if (str.getChar(i) < 31) {
			continue;
		}
		else if(isChar == true){
				temp.push_back(str.getChar(i));
		}
	}
		if (temp.cmp("") != 0) {
			removeLastEmptyChar(temp);
			object.current->sekcje[object.current->size].selektory->addNodeTail(temp);
			temp.clear();
		}
}


struct Comand1 {
	MyString first;
	MyString second;
	MyString third;
};

void check(Css& object, Comand1& cmd) {
	bool stIsNumber = cmd.first.isNumber();
	bool thIsNumber = cmd.third.isNumber();
	if ((cmd.second.cmp("D")==0|| cmd.second.cmp("A")==0 || cmd.second.cmp("S")==0|| cmd.second.cmp("E")==0)) {
		if (stIsNumber == true && cmd.second.cmp("D") == 0 && cmd.third.cmp("*") == 0) {
			NodeZTablica* tmp = object.head;
			int nrSekcji;
			int counter = 0;
			nrSekcji = cmd.first.numberConvert();
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != NULL) {
						counter++;
						if (nrSekcji == counter) {
							//if (tmp->sekcje[i].selektory->head != nullptr) {
							//	tmp->sekcje[i].selektory->deleteAll();
							//}
							if (tmp->sekcje[i].atrybuty->head != nullptr) {
								tmp->sekcje[i].atrybuty->deleteAll();
								tmp->sekcje[i].selektory->deleteAll();
								if (tmp->sekcje[i].atrybuty->head == nullptr) {
									tmp->numberSekcji--;
									cmd.first.print();
									cout << ",";
									cmd.second.print();
									cout << ",";
									cmd.third.print();
									cout << " == ";
									cout << "deleted" << endl;
									return;
								}
							}
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}

		if (stIsNumber == true && cmd.second.cmp("S") == 0 && cmd.third.cmp("?") == 0) {
			NodeZTablica* tmp = object.head;
			int nrSekcji;
			int counter = 0;
			nrSekcji = cmd.first.numberConvert();
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						counter++;
						if (nrSekcji == counter) {
								cmd.first.print();
								cout << ",";
								cmd.second.print();
								cout << ",";
								cmd.third.print();
								cout << " == ";
								cout << tmp->sekcje[i].selektory->countData() << endl;
								return;
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}
		if (stIsNumber == false && cmd.second.cmp("S") == 0 && cmd.third.cmp("?") == 0) {
			NodeZTablica* tmp = object.head;
			int counter = 0;
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						node* sel = tmp->sekcje[i].selektory->head;
						while (sel != nullptr) {
							if (sel->data.cmp(cmd.first) == 0) {
								counter++;
							}
							sel = sel->next;
						}
					}
				}
				tmp = tmp->next;
			}
			cmd.first.print();
			std::cout << ",";
			cmd.second.print();
			std::cout << ",";
			cmd.third.print();
			std::cout << " == " << counter << endl;
			return;
		}

		if (cmd.second.cmp("D") == 0) {
			int nrSekcji;
			int counterSekcji = 0;
			nrSekcji = cmd.first.numberConvert();
			NodeZTablica* tmp = object.head;
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						counterSekcji++;
						if (nrSekcji == counterSekcji) {
							if (tmp->sekcje[i].atrybuty->nodeExists(cmd.third) == true) {
								tmp->sekcje[i].atrybuty->deleteNode(cmd.third);
								if (tmp->sekcje[i].atrybuty->nodeExists(cmd.third) == false) {
									cmd.first.print();
									cout << ",";
									cmd.second.print();
									cout << ",";
									cmd.third.print();
									cout << " == deleted";
									cout << endl;
									if (tmp->sekcje[i].atrybuty->countData() == 0) {
										if (tmp->sekcje[i].selektory->head != nullptr) {
											tmp->sekcje[i].selektory->deleteAll();
										}
										if (tmp->sekcje[i].atrybuty->head != nullptr) {
											tmp->sekcje[i].atrybuty->deleteAll();
										}
									}
								}
							}
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}

		if (stIsNumber == true && cmd.second.cmp("A") == 0 && cmd.third.cmp("?") == 0) {
			NodeZTablica* tmp = object.head;
			int nrSekcji;
			int counter = 0;
			nrSekcji = cmd.first.numberConvert();
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						counter++;
						if (counter == nrSekcji) {
							cmd.first.print();
							cout << ",";
							cmd.second.print();
							cout << ",";
							cmd.third.print();
							cout << " == ";
							cout << tmp->sekcje[i].atrybuty->countData() << endl;
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}
		if (stIsNumber == false && cmd.second.cmp("A") == 0 && cmd.third.cmp("?") == 0) {
			NodeZTablica* tmp = object.head;
			int counter = 0;
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					node* atr = tmp->sekcje[i].atrybuty->head;
					while (atr != nullptr) {
						if (atr->data.cmp(cmd.first) == 0) {
							counter++;
						}
						atr = atr->next;
					}
				}
				tmp = tmp->next;
			}
			cmd.first.print();
			std::cout << ",";
			cmd.second.print();
			std::cout << ",";
			cmd.third.print();
			std::cout << " == " << counter << endl;
			return;
		}

		if (stIsNumber == true && cmd.second.cmp("S") == 0 && thIsNumber == true) {
			int nrSekcji, nrSelektora;
			int counterSekcji = 0;
			int counterSel = 0;
			nrSekcji = cmd.first.numberConvert();
			nrSelektora = cmd.third.numberConvert();
			NodeZTablica* tmp = object.head;
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						counterSekcji++;
						if (nrSekcji == counterSekcji) {
							node* temp = tmp->sekcje[i].selektory->head;
							while (temp != nullptr) {
								counterSel++;
								if (nrSelektora == counterSel) {
									cmd.first.print();
									cout << ",";
									cmd.second.print();
									cout << ",";
									cmd.third.print();
									cout << " == ";
									temp->data.print();
									cout << endl;
									return;
								}
								temp = temp->next;
							}
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}
		if (stIsNumber == true && cmd.second.cmp("A") == 0 && thIsNumber == false) {
			int nrSekcji;
			int counter = 0;
			nrSekcji = cmd.first.numberConvert();
			NodeZTablica* tmp = object.head;
			while (tmp != nullptr) {
				for (int i = 0; i < tmp->size; i++) {
					if (tmp->sekcje[i].atrybuty->head != nullptr) {
						counter++;
						if (nrSekcji == counter) {
							node* temp = tmp->sekcje[i].atrybuty->head;
							while (temp != nullptr) {
								if (temp->data.cmp(cmd.third) == 0) {
									cmd.first.print();
									cout << ",";
									cmd.second.print();
									cout << ",";
									cmd.third.print();
									cout << " == ";
									temp->value.print();
									cout << endl;
									return;
								}
								else {
									temp = temp->next;
								}
							}
						}
					}
				}
				tmp = tmp->next;
			}
			return;
		}
		if (cmd.second.cmp("E") == 0) {
			MyString nazwaSel;
			MyString nazwaAtr;
			MyString value;
			NodeZTablica* tmp = object.head;
			while (tmp != nullptr) {
				for (int i = 0; i <tmp->size; i++) {
						node* sel = tmp->sekcje[i].selektory->head;
						while (sel != nullptr) {
							if (sel->data.cmp(cmd.first) == 0) {
								if (tmp->sekcje[i].atrybuty->head != nullptr) {
									node* atr = tmp->sekcje[i].atrybuty->head;
									while (atr != nullptr) {
										if (atr->data.cmp(cmd.third) == 0) {
											nazwaAtr = atr->data;
											value = atr->value;
										}
										atr = atr->next;
									}
								}
							}
							sel = sel->next;
						}
				}
				tmp = tmp->next;
			}
			if(nazwaAtr.cmp("")!=0)
			{
				cmd.first.print();
				cout << ",";
				cmd.second.print();
				cout << ",";
				cmd.third.print();
				cout << " == ";
				value.print();
				cout << endl;
				return;
			}
		}
		//checkIsSekcjaEmpty(object);
		cmd.first.clear();
		cmd.second.clear();
		cmd.third.clear();
	}
else {
	cmd.first.clear();
	cmd.second.clear();
	cmd.third.clear();
	return;
	}
}
void parseCommand(Css& object, MyString& lhs) {
	if (lhs.cmp("?")==0) {
		int counter = 0;
		NodeZTablica* temporary = object.head;
		while (temporary != nullptr) {
			for (int i = 0; i < temporary->size; i++) {
				if (temporary->sekcje[i].atrybuty->head != nullptr) {
					counter++;
				}
			}
			temporary = temporary->next;
		}
		cout << "? == " << counter << endl;
		return;
	}
	MyString rhs;
	int idx = 0;
	Comand1 cmd;
	for (int i = 0; i < lhs.length(); ++i) {
		if (lhs.getChar(i) != ',') {
			rhs.push_back(lhs.getChar(i));
		}
		else {
			if (idx == 0) {
				cmd.first = rhs;
			}
			else if (idx == 1) {
				cmd.second = rhs;
			}
			else {
				cmd.third = rhs;
			}
			idx++;
			//rhs.print();
			rhs.clear();
		}
	}
	if (rhs.cmp("")!=0) {
		//rhs.print();
		cmd.third = rhs;
		rhs.clear();
	}
	check(object, cmd);
	checkIsSekcjaEmpty(object);
}
void komendy1(Css& object) {
	char c;
	int zn = 0;
	MyString temp;
	while (cin.get(c)) {
		if (c == '\n') {
			parseCommand(object, temp);
			zn = 0;
			temp.clear();
			continue;
		}
		if (c == '*') {
			zn++;
			if (zn == 4) {
				zn = 0;
				return;
			}
		}
		if (c >31 ) {
			temp.push_back(c);
		}
	}
	if (temp.length() != 0) {
		parseCommand(object, temp);
	}
}
void parse1(Css &object) {
	char s;
	bool isChar1 = false;
	MyString str;
	int zn = 0;
	MyString t;
	while (cin.get(s)) {
		if (s > 32 && isChar1 == false) {
			isChar1 = true;
		}
		if (s == '?') {
			zn++;
			if (zn == 4) {
				komendy1(object);
				zn = 0;
				continue;
			}
			str.clear();
			continue;
		}
		if (s == '{') {
			zn = 0;
			removeLastEmptyChar(str);
			object.addSekcja();
			separateSelector1(object, str);
			isChar1 = false;

			char c;
			MyString atr;
			MyString attr_name;
			atr.clear();
			attr_name.clear();
			bool isChar = false;
			bool is_attribute_name = true; 
			while (cin.get(c)&& c != '}') {
				if (c >32 && isChar == false) {
            		isChar = true;
        		}
				if (c == ';') {
					is_attribute_name = true;
					node* tmp = object.current->sekcje[object.current->size].atrybuty->head;
					isChar = false;
					removeLastEmptyChar(atr);
					while (tmp != nullptr) {
						if(attr_name.cmp(tmp->data) == 0) {
							tmp->value = atr;
							break;
						}
						tmp = tmp->next;
					}
					atr.clear();
					attr_name.clear();
					continue;
				}
				if (c == ':') {
					is_attribute_name = false;
					isChar = false;
					removeLastEmptyChar(attr_name);
					if (object.current->sekcje[object.current->size].atrybuty->nodeExists(attr_name) == false) {
						object.current->sekcje[object.current->size].atrybuty->addNodeTail(attr_name);
					}
					continue;
				}
				if(isChar != false) {
					if(is_attribute_name == true) {
						attr_name.push_back(c);
					} else {
						atr.push_back(c);
					}
        		}
			}
			if (atr.cmp("") !=0 ) {
				removeLastEmptyChar(atr);
				object.current->sekcje[object.current->size].atrybuty->tail->value = atr;
			}
			str.clear();
			object.addSize();
			continue;
		}
		if (isChar1==true) {
			str.push_back(s);
		}
		continue;
	}

}

int main() {

	Css object;
	parse1(object);
	return 0;
}