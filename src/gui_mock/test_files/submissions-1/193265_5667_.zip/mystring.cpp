#include "mystring.h"
#include <iostream>
using namespace std;

char* Mystrcpy(char* dest, const char* src) {
    char* tmp = dest;
    while ((*dest++ = *src++) != '\0')
        ;//do nothing
    return tmp;
}

MyString::MyString() : str{ nullptr } {
    str = new char[1];
    str[0] = '\0';
}

MyString::MyString(const char* rhs) {
    if (rhs == nullptr) {
        str = new char[1];
        str[0] = '\0';
    }
    else {
        str = new char[strlen(rhs) + 1];

        Mystrcpy(str, rhs);
        str[strlen(rhs)] = '\0';
    }
}
MyString::MyString(const MyString& other) {
    if (other.str == nullptr) {
        str = new char[1];
        str[0] = '\0';
    }
    else {
        str = new char[strlen(other.str) + 1];
        Mystrcpy(str, other.str);
    }
}
char MyString::getChar(int index) {
    return *(str + index);
}

bool MyString::checkNumber(const char* c) {
	int nr = (int)(*c);
	if (nr >= 48 && nr <= 57) {
		return true;
	}
	return false;
}

bool MyString::isNumber() {
	for (int i = 0; i < this->length(); ++i) {
		const char c = getChar(i);
		if (checkNumber(&c) == false) {
			return false;
		}
	}
	return true;
}



int MyString::cmp(const MyString& rhs) const{
    const char* str = this->str;
    const char* rhsStr = rhs.str;
    while (*str != '\0' && *rhsStr != '\0' && *str == *rhsStr) {
        str++;
        rhsStr++;
    }
    if (*str == '\0' && *rhsStr == '\0') { // stringi sa te same 
        return 0;
    }
    return (*str < *rhsStr) ? -1 : 1;;
}


void MyString::push_back(char c) {
    int length = strlen(this->str);
    char* buffer = new char[length + 2];
    Mystrcpy(buffer, this->str);
    buffer[length] = c;
    buffer[length + 1] = '\0';
    *this = MyString(buffer);
    delete[] buffer;
}

int MyString::length() {
    return strlen(this->str);
}
int MyString::numberConvert() {
    int num = 0;
    for (int i = 0; i < length(); i++) {
        int digit = getChar(i) - '0';
        num = num * 10 + digit;
    }
    return num;
}



void MyString::print() { cout << str; }

void MyString::clear() {
    str = nullptr;
    str = new char[1];
    str[0] = '\0';
}

