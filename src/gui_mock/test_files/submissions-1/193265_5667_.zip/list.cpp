#include <iostream>
#include"mystring.h"
#include "list.h"
using namespace std;

List::List() {
	head = nullptr;
	tail = nullptr;
}


int List::countData() {
	node* tmp = head;
	int counter = 0;
	while (tmp != nullptr){
		if(tmp->data.cmp("")!=0)
		{
			counter++;
		}
		tmp = tmp->next;
	}
	return counter;
}
void List::deleteAll() {
	node* tmp = head;
	while (tmp != nullptr) {
		node* delNode = tmp;
		tmp = tmp->next;
		if (delNode == head) {
			head = tmp;
		}
		if (delNode == tail) {
			tail = delNode->prev;
		}
		if (delNode->prev != nullptr) {
			delNode->prev->next = tmp;
		}
		if (tmp != nullptr) {
			tmp->prev = delNode->prev;
		}
		delete delNode;
	}
	delete tmp;
	head = nullptr;
	tail = nullptr;
}


void List::addNodeTail(MyString data) {
	if (head == nullptr) {
		addNodeHead(data);
	} else {
		tail->next = new node(tail, nullptr, data); 
		tail = tail->next;
	}
}
void List::addNodeHead(MyString data) {
	head = new node(nullptr, head, data);
	if(head->next) {
		head->next->prev = head;
	} else {
		tail = head;
	}
}

bool List::nodeExists(MyString value) {
	node* tmp = head;
	while (tmp != nullptr) {
		if (tmp->data.cmp(value) == 0) {
			return true;
		}
		tmp = tmp->next;
	}
	return false;
}

void List::deleteNode(MyString delData) {
	node* tmp = head;
	while (tmp != nullptr) {
		node* delNode = tmp;
		if (tmp->data.cmp(delData) == 0) {
			if (tmp == head) {
				head = tmp->next;
			}
			if (tmp == tail) {
				tail = tmp->prev;
			}
			if (tmp->prev != nullptr) {
				tmp->prev->next = tmp->next;
			}
			if (tmp->next != nullptr) {
				tmp->next->prev = tmp->prev;
			}
			tmp = tmp->next;
			delete delNode;
		}
		else {
			tmp = tmp->next;
		}
	}
}

List::~List() {
    delete head; 
	delete tail;
}


