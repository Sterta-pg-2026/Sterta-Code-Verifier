#include "css.h"
#include "mystring.h"
#include <iostream>
using namespace std;

Css::Css() {
	head = nullptr;
	tail = nullptr;
	current = nullptr;
	numberOfNodes = 0;
	numberOfSections = 0;
	nrSekcji = 0;
}
void Css::addSekcja() {
	if (current == nullptr) {
		head = new NodeZTablica();
		tail = head;
		current = head;
		numberOfNodes++;
	}
	if (current->size == Wielkosci::SIZE_T) {
		numberOfNodes++;
		current->next = new NodeZTablica(nullptr, current);
		current = current->next;
		tail = current;
		current->size = 0;
		current->numberSekcji = 0;
	}
	//current->size++;
}
void Css::addSize() {
	if (current->sekcje[current->size].atrybuty->head != nullptr) {
		numberOfSections++;
		nrSekcji++;
	}
	current->size++;
	current->numberSekcji++;
}




            
void Css::deleteNode() {
	NodeZTablica* tmp = head;
	while (tmp != nullptr) {
		tmp = tmp->next;
	}
	if (tmp == nullptr) {
		return;
	}

	if (tmp == head) {
		head = tmp->next;
	}
	if (tmp == tail) {
		tail = tmp->prev;
	}
	if (tmp->prev != nullptr) {
		tmp->prev->next = tmp->next;
	}
	if (tmp->next != nullptr) {
		tmp->next->prev = tmp->prev;
	}
	delete tmp;
	numberOfNodes--;
}




