#pragma once
#include<iostream>
using namespace std;
class MyString {

public:
	char* str;
	MyString();
	MyString(const char* str);
	MyString(const MyString& other);

	int length();
	int numberConvert();
	bool checkNumber(const char* c);
	bool isNumber();

	void push_back(const char c);
	void print();
	void clear();
	char getChar(int index);
	int cmp(const MyString& rhs)const;
	
};