#pragma once
#include"mystring.h"
#include <iostream>
using namespace std;

class node {
public:
	MyString data;
	MyString value;
	node* next=nullptr;
	node* prev=nullptr;
	node(MyString &data) {
		node(nullptr, nullptr, data); 
	}

	node(node *prev, node*next, MyString &data) {
		this->prev = prev; 
		this->next = next; 
		this->data = data;
	}
};

class List {
public:
	node* head;
	node* tail;
public:
	List();
	void addNodeHead(MyString data);
	void addNodeTail(MyString data);
	void deleteNode(MyString delData);
	void deleteAll();
	bool nodeExists(MyString value);
	int countData();
	~List();
};