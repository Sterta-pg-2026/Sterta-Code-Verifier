#pragma once
#include "list.h"
#include "mystring.h"
#include<iostream>
using namespace std;

enum Wielkosci {
	SIZE_T =17
};

class Sekcja {
public:
	List* selektory;
	List* atrybuty;
	int numer = 0;
	
	Sekcja() {
		selektory = new List();
		atrybuty = new List();
	}

	~Sekcja() {
		delete selektory; 
		delete atrybuty;
	}
};

class NodeZTablica {
public:
	Sekcja sekcje[Wielkosci::SIZE_T];
	int size;
	int numberSekcji;
	NodeZTablica* next;
	NodeZTablica* prev;
	NodeZTablica(NodeZTablica* nextNode = nullptr, NodeZTablica* prevNode = nullptr) {
		size = 0;
		numberSekcji = 0;
		next = nextNode;
		prev = prevNode;
	}
	~NodeZTablica() {
		delete next;
		delete prev;
	}

};

class Css {
public:
	NodeZTablica* head;
	NodeZTablica* tail;
	NodeZTablica* current;
	int numberOfNodes;
	int numberOfSections;
	int nrSekcji;

public:

	Css();
	~Css() { };
	void addSekcja();
	void addSize();
	void deleteNode();
};
