#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <stdlib.h>

#define LIST_SIZE 19


class string {
public:

    string() {
        str = new char[1];
        str[0] = NULL;
    }

    string(const string& s) {
        size_t len = strlen(s.str);
        str = new char[len + 1];
        for (int i = 0; i < len; i++)
            str[i] = s.str[i];
        str[len] = NULL;
    }

    string& operator=(const string& s) {
        delete[] str;
        size_t len = strlen(s.str);
        str = new char[len + 1];
        for (int i = 0; i < len; i++)
            str[i] = s.str[i];
        str[len] = NULL;

        return *this;
    }

    ~string() {
        delete[] str;
    }

    void operator+=(char c) {
        size_t len = strlen(str);
        char* new_str = new char[len + 2];
        for (int i = 0; i < len; i++)
            new_str[i] = str[i];
        new_str[len] = c;
        new_str[len + 1] = NULL;

        delete[] str;
        str = new_str;
    }

    bool operator==(const string& s) {
        return strcmp(str, s.str) == 0;
    }

    bool operator==(const char* s) {
        return strcmp(str, s) == 0;
    }

    bool operator!=(const string& s) {
        return strcmp(str, s.str) != 0;
    }

    bool operator!=(const char* s) {
        return strcmp(str, s) != 0;
    }

    const char* data() {
        return str;
    }

private:
    char* str;
};


template<typename Type>
class List {
public:

    struct Node {
        Type* value[LIST_SIZE] = {};
        Node* next;
        Node* previous;
        int occupied = 0;
        int last_occupied = 0;
    };

public:

    List() {
        Node* n = new Node();
        first = n;
        last = n;
        n->previous = nullptr;
        n->next = nullptr;
    }

    List(List&& l) {
        first = l.first;
        last = l.last;
        l.first = nullptr;
        l.last = nullptr;
    }

    List& operator=(List&& l) {

        clear();

        first = l.first;
        last = l.last;
        l.first = nullptr;
        l.last = nullptr;
        return *this;
    }

    ~List() {
        clear();
    }

    List(const List&) = delete;


    void push_back(Type&& t) {
        if (last->last_occupied < LIST_SIZE) {
            last->value[last->last_occupied] = new Type(std::move(t));
            last->occupied++;
            last->last_occupied++;
        }
        else {
            Node* n = new Node();
            n->value[0] = new Type(std::move(t));
            n->occupied = 1;
            n->last_occupied = 1;
            last->next = n;
            n->next = nullptr;
            n->previous = last;
            last = n;
        }
    }

    int size() {

        if (first == nullptr) {
            return 0;
        }

        int size = 0;

        Node* current_node = first;
        while (current_node != nullptr) {
            size += current_node->occupied;
            current_node = current_node->next;
        }

        return size;

    }

    Type& get_value_at_index(int index) {

        int list_index = 0;

        Node* current_node = first;
        while (current_node != nullptr) {
            for (int i = 0; i < LIST_SIZE; i++) {
                if (current_node->value[i] != nullptr) {
                    list_index++;
                    if (list_index == index + 1) {
                        return *(current_node->value[i]);
                    }
                }
            }
            current_node = current_node->next;
        }

        exit(1);
    }


    void erase_at_index(int index) {

        int list_index = 0;

        Node* current_node = first;
        while (current_node != nullptr) {
            for (int i = 0; i < LIST_SIZE; i++) {
                if (current_node->value[i] != nullptr) {
                    list_index++;
                    if (list_index == index + 1) {
                        delete current_node->value[i];
                        current_node->value[i] = nullptr;
                        current_node->occupied--;
                        return;
                    }
                }
            }
            current_node = current_node->next;
        }

        exit(1);
    }


    Node* get_first() {
        return first;
    }

    Node* get_last() {
        return last;
    }

    void clear() {

        Node* current_node = first;
        while (current_node != nullptr) {
            Node* next = current_node->next;
            for (int i = 0; i < LIST_SIZE; i++) {
                if (current_node->value[i] != nullptr) {
                    delete current_node->value[i];
                }
            }
            delete current_node;
            current_node = next;
        }

        Node* n = new Node();
        first = n;
        last = n;
        n->previous = nullptr;
        n->next = nullptr;
    }

private:
    Node* first;
    Node* last;
};

string trim_spaces(const char* str) {

    int lenght = strlen(str);
    int i = 0;

    while (i < lenght && str[i] == ' ') {
        i++;
    }

    int j = lenght - 1;
    while (j >= 0 && str[j] == ' ') {
        j--;
    }

    string new_string;
    for (int k = i; k <= j; k++) {
        new_string += str[k];
    }

    return new_string;

}


bool is_digit(const char* string) {
    for (int i = 0; i < strlen(string); i++) {
        if (string[i] != '0'
            && string[i] != '1'
            && string[i] != '2'
            && string[i] != '3'
            && string[i] != '4'
            && string[i] != '5'
            && string[i] != '6'
            && string[i] != '7'
            && string[i] != '8'
            && string[i] != '9') {
            return false;
        }
    }
    return true;
}


struct Command {

    string leading;
    string content;
    string trailing;

    void reset() {
        leading = string();
        content = string();
        trailing = string();
    }

};


struct State {

    bool is_reading_css;
    bool is_reading_selector;
    bool is_reading_attr_name;

    int command_state;

    State() {
        is_reading_css = true;
        is_reading_selector = true;
        is_reading_attr_name = true;

        command_state = 0;
    }

};


struct Attribute {

    string name;
    string value;

    bool is_empty() {
        if (name == string() || value == string()) {
            return true;
        }
        return false;
    }

    void reset() {
        name = string();
        value = string();
    }

};


struct DataSection {

    List<string> selectors;
    List<Attribute> attributes;

};


struct Section {

    List<string> selectors;
    List<Attribute> attributes;

    string current_selector;
    Attribute current_attribute;

    Section() {
        current_selector = string();
        current_attribute = Attribute();
    }

    void add_current_selector() {
        string selector = trim_spaces(current_selector.data());
        if (selector != string()) {
            selectors.push_back(std::move(selector));
        }
        else {
            selectors.push_back(string());
        }
        current_selector = string();
    }

    void add_current_attribute() {
        string name = trim_spaces(current_attribute.name.data());
        string value = trim_spaces(current_attribute.value.data());
        if (name != string() && value != string()) {
            bool same_attribute_already_exists = false;
            for (int i = 0; i < attributes.size(); i++) {
                if (attributes.get_value_at_index(i).name == name) {
                    attributes.get_value_at_index(i).value = value;
                    same_attribute_already_exists = true;
                    break;
                }
            }
            if (!same_attribute_already_exists) {
                Attribute attr = Attribute();
                attr.name = name;
                attr.value = value;
                attributes.push_back(std::move(attr));
            }
        }
        current_attribute.reset();
    }

    void add_section(List<struct DataSection>& sections) {
        struct DataSection section = DataSection();
        section.selectors = std::move(selectors);
        section.attributes = std::move(attributes);
        sections.push_back(std::move(section));
        reset();
    }

    void reset() {
        selectors.clear();
        attributes.clear();
        current_selector = string();
        current_attribute.reset();
    }

};


void execute_a_command(struct Command command, List<struct DataSection>& sections) {

    if (command.trailing == "?") {
        if (is_digit(command.leading.data())) {
            int index = atoi(command.leading.data()) - 1;
            if (index < sections.size()) {
                std::cout << command.leading.data() << ",A,? == " << sections.get_value_at_index(index).attributes.size() << std::endl;
            }
        }
        else
        {
            int counter = 0;
            int section_length = sections.size();

            for (int i = 0; i < section_length; i++) {

                int attributes_length = sections.get_value_at_index(i).attributes.size();

                for (int j = 0; j < attributes_length; j++) {
                    if (sections.get_value_at_index(i).attributes.get_value_at_index(j).name == command.leading) {
                        counter++;
                    }
                }
            }
            std::cout << command.leading.data() << ",A,? == " << counter << std::endl;
        }
    }
    else {
        int index = atoi(command.leading.data()) - 1;
        if (index < sections.size()) {
            string value = string();

            int attributes_length = sections.get_value_at_index(index).attributes.size();

            for (int i = 0; i < attributes_length; i++) {
                if (sections.get_value_at_index(index).attributes.get_value_at_index(i).name == command.trailing) {
                    value = sections.get_value_at_index(index).attributes.get_value_at_index(i).value;
                }
            }
            if (value != string()) {
                std::cout << command.leading.data() << ",A," << command.trailing.data() << " == " << value.data() << std::endl;
            }
        }
    }

}

void execute_d_command(struct Command command, List<struct DataSection>& sections) {

    if (command.trailing == "*") {
        int index = atoi(command.leading.data()) - 1;
        if (index < sections.size()) {
            sections.erase_at_index(index);
            std::cout << command.leading.data() << ",D,* == deleted" << std::endl;
        }
    }
    else
    {
        int index = atoi(command.leading.data()) - 1;
        if (index < sections.size()) {

            int attributes_length = sections.get_value_at_index(index).attributes.size();

            for (int i = 0; i < attributes_length; i++) {
                if (sections.get_value_at_index(index).attributes.get_value_at_index(i).name == command.trailing) {
                    sections.get_value_at_index(index).attributes.erase_at_index(i);
                    if (sections.get_value_at_index(index).attributes.size() < 1) {
                        sections.erase_at_index(index);
                    }
                    std::cout << command.leading.data() << ",D," << command.trailing.data() << " == deleted" << std::endl;
                    break;
                }
            }
        }
    }

}


void execute_e_command(struct Command command, List<struct DataSection>& sections) {

    int section_length = sections.size();

    for (int i = section_length - 1; i >= 0; i--) {
        
        struct DataSection& section = sections.get_value_at_index(i);
        int selectors_length = section.selectors.size();
        int attributes_length = section.attributes.size();

        for (int j = 0; j < selectors_length; j++) {
            if (section.selectors.get_value_at_index(j) == command.leading) {
                for (int k = 0; k < attributes_length; k++) {
                    if (section.attributes.get_value_at_index(k).name == command.trailing) {
                        std::cout << command.leading.data() 
                            << ",E," 
                            << command.trailing.data()
                            << " == " 
                            << section.attributes.get_value_at_index(k).value.data() 
                            << std::endl;
                        return;
                    }
                }
            }
        }
    }

}


void execute_s_command(struct Command command, List<struct DataSection>& sections) {

    if (command.trailing == "?") {
        if (is_digit(command.leading.data())) {
            int index = atoi(command.leading.data()) - 1;
            if (index < sections.size()) {
                std::cout << command.leading.data() << ",S,? == " << sections.get_value_at_index(index).selectors.size() << std::endl;
            }
        }
        else
        {
            int counter = 0;
            int section_length = sections.size();

            for (int i = 0; i < section_length; i++) {

                int selectors_length = sections.get_value_at_index(i).selectors.size();

                for (int j = 0; j < selectors_length; j++) {
                    if (sections.get_value_at_index(i).selectors.get_value_at_index(j) == command.leading) {
                        counter++;
                        break;
                    }
                }
            }
            std::cout << command.leading.data() << ",S,? == " << counter << std::endl;
        }
    }
    else
    {
        int section_index = atoi(command.leading.data()) - 1;
        int selector_index = atoi(command.trailing.data()) - 1;

        if (section_index < sections.size() && selector_index < sections.get_value_at_index(section_index).selectors.size()) {
            std::cout 
                << command.leading.data() 
                << ",S," 
                << command.trailing.data() 
                << " == " 
                << sections.get_value_at_index(section_index).selectors.get_value_at_index(selector_index).data() 
                << std::endl;
        }
    }
}


void execute_command(struct Command* command, List<struct DataSection>& sections) {

    if (command->leading == "?") {
        std::cout << "? == " << sections.size() << std::endl;
        return;
    }

    if (command->content == "A") {
        execute_a_command(*command, sections);
    }

    if (command->content == "D") {
        execute_d_command(*command, sections);
    }

    if (command->content == "E") {
        execute_e_command(*command, sections);
    }

    if (command->content == "S") {
        execute_s_command(*command, sections);
    }

}


void read_css(char ch, struct State* state, struct Section* section, List<struct DataSection>& sections) {

    if (state->is_reading_selector) {
        if (ch == ',' || ch == '{' || ch == '\n') {
            if (section->current_selector != string()) {
                section->add_current_selector();
            }
        }
        else if (ch != '\t') {
            section->current_selector += ch;
        }
    }

    if (!state->is_reading_selector) {
        if (ch == ':') {
            state->is_reading_attr_name = false;
            return;
        }
        if (ch == ';' || ch == '}') {
            state->is_reading_attr_name = true;
            if (!section->current_attribute.is_empty()) {
                section->add_current_attribute();
            }
        }
        else if (ch != '\n' && ch != '\t') {
            if (state->is_reading_attr_name) {
                section->current_attribute.name += ch;
            }
            else {
                section->current_attribute.value += ch;
            }
        }
    }

    if (ch == '{') {
        state->is_reading_selector = false;
    }

    if (ch == '}') {
        state->is_reading_selector = true;
        section->add_section(sections);
    }

}


void read_commands(char ch, struct State* state, struct Command* command, List<struct DataSection>& sections) {

    if (ch == ',' && state->command_state == 0) {
        state->command_state = 1;
        return;
    }
    if (ch == ',' && state->command_state == 1) {
        state->command_state = 2;
        return;
    }
    if (ch == '\n') {
        state->command_state = 0;
        if (command->leading != string()) {
            execute_command(command, sections);
            command->reset();
        }
        return;
    }

    if (state->command_state == 0) { 
        command->leading += ch;
    }
    if (state->command_state == 1) {
        command->content += ch;
    }
    if (state->command_state == 2) {
        command->trailing += ch;
    }

}


int main() {

    struct State state = State();
    struct Section section = Section();
    struct Command command = Command();
    List<struct DataSection> sections;

    char buf[1024];
    char* line;
    while ((line = fgets(buf, sizeof buf, stdin)) != NULL) {

        if (strcmp(line, "????\n") == 0) {
            state.is_reading_css = false;
            continue;
        }
        if (strcmp(line, "****\n") == 0) {
            state.is_reading_css = true;
            continue;
        }
        if (strcmp(line, "\n") == 0) {
            continue;
        }

        int len = strlen(line);
        if (len != 0)
            if (line[len - 1] != '\n') {
                line[len] = '\n';
                len += 1;
                line[len] = NULL;
            }

        for (int i = 0; i < len; i++) {
            char ch = line[i];
            if (state.is_reading_css) {
                read_css(ch, &state, &section, sections);
            }
            else
            {
                read_commands(ch, &state, &command, sections);
            }
        }

    }
    

}
