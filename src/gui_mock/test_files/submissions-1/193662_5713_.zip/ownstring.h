#include <iostream>

using namespace std;

class String {
private:
    char* str;
    int size;
public:
    String();
    String(const char* string);
    String(const String& other);
    String& operator=(const String& other);
    bool operator==(const String& other) const;
    bool operator!=(const String& other) const;
    bool isInteger();
    ~String();
    friend istream& operator>>(istream& input, String& string);
    friend ostream& operator<<(ostream& output, String& string);
    char operator[](int index) const {
        return str[index];
    }
    int findPos(char letter) const;
    int getLen();
    String substring(int start, int end) const;
    int countOccurences(char letter) const;
    int findNthPos(char letter, int which) const;
    String removeTabs() const;
    int convertToInt() const;
    String removeSpecial() const;
    String trim(String& string);
};

