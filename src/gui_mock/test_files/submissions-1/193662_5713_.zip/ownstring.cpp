#include <iostream>
#include <stdio.h>
#include "ownstring.h"
#include <cmath>

using namespace std;

// default constructor
String::String() : str(new char[1]), size(0) {
    str[0] = '\0';
}

String::String(const char* string) : str(new char[strlen(string) + 1]), size(strlen(string)) {
    strcpy(str, string);
}

String::String(const String& other) : str(new char[other.size + 1]), size(other.size) {
    strcpy(str, other.str);
}

String& String::operator=(const String& other) {
    String other2 = other;
    if (this == NULL || this == nullptr) {
        return *this;
    } else if (this != &other) {
        char* temp = new char[other.size + 1];
        strcpy(temp, other.str);
        delete[] str;
        str = temp;
        size = other.size;
   }
   return *this;
}

bool String::operator==(const String& other) const {
    if (this == NULL) {
        return false;
    }
    if (size != other.size) {
            return false;
        }
    return (strcmp(str, other.str) == 0);
}

bool String::operator!=(const String& other) const {
    if (this == NULL) {
        return true;
    }
    if (size != other.size) {
        return true;
    }
    for (int i = 0; i < size; i++) {
        if (str[i] != other.str[i]) {
            return true;
        }
    }
    return false;
}

bool String::isInteger() {
    for (int i = 0; i < size; i++) {
        if (str[i] < '0' || str[i] > '9') {
            return false;
        }
    }
    return true;
}

String::~String() {
    size = 1;
    str = new char[size];
    str[0] = '\0';
    delete[] str;
}

std::istream& operator>>(std::istream& input, String& str) {
    char* buffer = new char[1025600];
    input.getline(buffer, 1025600);
    str = String(buffer);
    delete[] buffer;
    return input;
}

ostream& operator<<(ostream& output, String& string) {
    output << string.str;
    return output;
}

int String::getLen() {
    return size;
}

int String::findPos(char letter) const {
    for (int i = 0; i < size; i++) {
        if (str[i] == letter) {
            return i;
        }
    }
    return -1;
}

// return substring from start to end pos of givens string
String String::substring(int start, int end) const {
    // check if the start index is within the string
    if (start < 0 || start >= size || end < start || end > size) {
        return String();
    }
    char* buffer = new char[end - start + 1];
    for (int i = start; i < end; i++) {
        buffer[i - start] = str[i];
    }
    buffer[end - start] = '\0';
    String result(buffer);
    delete[] buffer;
    return result;
}

// count occurences of given letter in the string
int String::countOccurences(char letter) const {
    int occurences = 0;
    for (int i = 0; i < size; i++) {
        if (str[i] == letter) {
            occurences++;
        }
    }
    return occurences;
}

int String::findNthPos(char letter, int which) const {
    int count = 0;
    for (int i = 0; i < size; i++) {
        if (str[i] == letter && count == which) {
            return i;
        } else if (str[i] == letter) {
            count++;
        }
    }
    return -1;
}

String String::removeTabs() const {
    char* result = new char[size + 1];
    int j = 0;
    for (int i = 0; i < size; i++) {
        if (str[i] != '\t') {
            result[j++] = str[i];
        }
    }
    result[j] = '\0';
    String newString(result);
    delete[] result;
    return newString;
}

int String::convertToInt() const {
    int result = 0;
    for (int i = 0; i < size; i++) {
        result = result * 10 + (str[i]- '0');
    }
    return result;
}

String String::removeSpecial() const {
    char* result = new char[size + 1];
    int j = 0;
    for (int i = 0; i < size; i++) {
        if (str[i] != '\\') {
            result[j++] = str[i];
        }
    }
    result[j] = '\0';
    String newString(result);
    delete[] result;
    return newString;
}

String String::trim(String& string) {
    int start = 0;
    int end = string.size;
    
    while (start <= end && string[start] == ' ') {
        start++;
    }
    while (end >= start && string[end] == ' ') {
        end--;
    }
    return string.substring(start, end);
}
