#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include "ownstring.h"

#define BLOCK_SIZE 8

using namespace std;

struct SingleNode {
    String selector;
    String attribute;
    struct SingleNode* next;
};

struct DoubleNode {
    SingleNode* block[BLOCK_SIZE];
    struct DoubleNode* next;
    struct DoubleNode* prev;
};

struct SelectorNode {
    String name;
    struct SelectorNode* next;
    
};

void insertSelectorNode(struct SelectorNode** head, String name) {
    struct SelectorNode* newNode = new SelectorNode;
    newNode->name = "";
    
    if (newNode == NULL) {
        newNode->name = name;
        *head = newNode;
        return;
    }
    
    newNode->name = name;
    newNode->next = NULL;
    
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    struct SelectorNode* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

void deleteSelectorsList(SelectorNode* head) {
    SelectorNode* current = head;
    while (current != NULL) {
        SelectorNode* temp = current;
        current = current->next;
        delete temp;
    }
}

void insertEndSingle(struct SingleNode** head, String selector ,String attribute) {
    struct SingleNode* newNode = new SingleNode;
    newNode->selector = selector;
    newNode->attribute = attribute;
    newNode->next = NULL;
    
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    struct SingleNode* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->next = NULL;
}

void insertEndDouble(struct DoubleNode** head, SingleNode** listHead) {
    SingleNode *singleList = new SingleNode[1000];
    struct DoubleNode* newNode = new DoubleNode;
    
    for (int i = 0; i < BLOCK_SIZE; i++) {
        newNode->block[i] = &singleList[i];
    }
    newNode->next = NULL;
    if (*head == NULL) {
        newNode->prev = NULL;
        *head = newNode;
        return;
    }
    struct DoubleNode* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = new DoubleNode;
    for (int i = 0; i < BLOCK_SIZE; i++) {
        temp->next->block[i] = newNode->block[i];
    }
    temp->next->prev = temp;
    temp->next->next = NULL;
    delete[] singleList;
}

void deleteNode(struct DoubleNode** head, struct DoubleNode* delNode) {
    if (*head == NULL || delNode == NULL) {
        return;
    }
    if (*head == delNode) {
        *head = delNode->next;
    }
    if (delNode->next != NULL) {
        delNode->next->prev = delNode->prev;
    }
    if (delNode->prev != NULL) {
        delNode->prev->next = delNode->next;
    }
    delete[] delNode;
}

bool oneLineDeclaration(String input) {
    if (input.findPos('{') != -1 && input.findPos('}') != -1) {
        return true;
    }
    return false;
}

int numberOfSelectors(String input) {
    int occurs = input.countOccurences(',') + 1;
    return occurs;
}

int numberOfAttributes(String input) {
    int start = input.findPos('{');
    int len = input.getLen();
    int occurs = 0;
    String substring = input.substring(start, len - 1);
    occurs = substring.countOccurences(';');
    return occurs;
}

void addToSelector(SingleNode** singleListHead, String selector, String attribute) {
    insertEndSingle(singleListHead, selector, attribute);
}

String findAttribute(String input, int j) {
    String substr = "";
    int start, end;
    int bracketOpen = input.findPos('{');
    int bracketEnd = input.findPos('}');
    input = input.substring(bracketOpen + 1, bracketEnd - 1);
    if (j == 0) {
        start = 0;
        end = input.getLen();
    } else if (j == input.countOccurences(';')) {
        start = input.findNthPos(';', input.countOccurences(';'));
        end = input.getLen() - 1;
    } else {
        start = input.findNthPos(';', j);
        end = input.findNthPos(';', j + 1);
    }
    substr = input.substring(start, end - 1);
    return substr;
}

String findSelector(String input, int j) {
    int start = 0, end = 0, commaPos = 0, commaPos1 = 0, commaPos2 = 0;
    int commaCount = input.countOccurences(',');
    int inputLen = input.getLen();
    
    if (commaCount > 0 && commaCount < 2) {
        commaPos = input.findPos(',');
    } else if (commaCount > 1 || j == commaCount) {
        commaPos1 = input.findNthPos(',', j - 1) + 1;
        commaPos2 = input.findNthPos(',', j);
    }
    if (j == 0) {
        start = 0;
        if (commaCount == 0) {
            end = inputLen;
        } else {
            end = input.findPos(',');
            }
        } else if (j == commaCount) {
            commaPos = input.findNthPos(',', j);
            start = commaPos + 1;
            end = inputLen - 1;
        } else {
        commaPos1 = input.findNthPos(',', j - 1) + 1;
        commaPos2 = input.findNthPos(',', j);
        start = commaPos1;
        end = commaPos2;
    }
    return input.substring(start, end);
}

int selectorsForSection(struct DoubleNode* head, int sectionNumber) {
    int maxSelectors = 20;
    int occupied = 0;
    String *checkedSelectors = new String[maxSelectors];
    int count = 0;
    struct SingleNode* singleHead = head->block[sectionNumber - 1];
    if (singleHead == nullptr) {
        return 0;
    }
    while (singleHead != nullptr) {
        bool found = false;
        //if (singleHead->selector == nullptr || singleHead->attribute == nullptr) {
          //  singleHead = singleHead->next;
        //}
        for (int i = 0; i < maxSelectors; i++) {
            if (singleHead->selector == checkedSelectors[i]) {
                found = true;
                i = maxSelectors;
            }
        }
        if (found == false) {
            checkedSelectors[occupied] = singleHead->selector;
            occupied++;
            count++;
        }
        
        singleHead = singleHead->next;
    }
    delete[] checkedSelectors;
    delete[] singleHead;
    
    return count;
}

int attributesForSection(struct DoubleNode* head, int sectionNumber) {
    int count = 0;
    int numbOfSelectors = selectorsForSection(head, sectionNumber);
    struct SingleNode* singleHead = head->block[sectionNumber - 1];
    if (singleHead == nullptr) {
        return 0;
    }
    while (singleHead != nullptr) {
        if (singleHead->attribute != "") {
            count++;
        }
        singleHead = singleHead->next;
    }
    
    count = count / numbOfSelectors;
    
    delete[] singleHead;
    return count;
}

String specifiedAttribute(struct DoubleNode* head, String wantedAttribute, int blockNumber) {
    String result = "";
    struct SingleNode* singleHead = head->block[blockNumber - 1];
    while (singleHead != NULL) {
        String attribute = singleHead->attribute;
        attribute = attribute.removeSpecial();
        int start = attribute.findPos(':') + 1;
        int end = attribute.getLen();
        String attributeVal = attribute.substring(start, end);
        String attributeName = attribute.substring(0, start - 1);
        if (attributeName == wantedAttribute) {
            result = attributeVal;
            break;
        }
        singleHead = singleHead->next;
    }
    return result;
}

String jthSelector(struct DoubleNode* head, int wantedSelector, int sectionNumber) {
    int count = 1;
    String result = "";
    struct SingleNode* singleHead = head->block[sectionNumber - 1];
    int numbOfSelectors = selectorsForSection(head, sectionNumber);
    
    if (singleHead == nullptr) {
        return "";
    }
    if (numbOfSelectors < wantedSelector) {
        return "";
    }
    while (singleHead != nullptr) {
        if (count == wantedSelector) {
            result = singleHead->selector;
            break;
        } else {
            singleHead = singleHead->next;
        }
    }
    return result;
}


int countNumberOfSections(struct DoubleNode* head) {
    int count = 0;
    while (head != NULL) {
        for (int i = 0; i < BLOCK_SIZE; i++) {
            struct SingleNode* singleHead = head->block[i];
            if (singleHead->selector != "" && singleHead != NULL) {
                count++;
            }
        }
        head = head->next;
    }
    return count;
}

void deleteSection(struct DoubleNode* head, int sectionNumber) {
    if (sectionNumber == BLOCK_SIZE) {
        int nodesToProceed = sectionNumber / BLOCK_SIZE;
        for (int i = 0; i < nodesToProceed; i++) {
            head = head->next;
        }
    }
    delete head->block[sectionNumber - 1];
    head->block[sectionNumber - 1] = NULL;
}

int totalOfSelector(struct DoubleNode* head, String selectorName) {
    int count = 0;
    int i = 0;
    while (head->block[i] != NULL) {
        struct SingleNode* singleHead = head->block[i];
        while (singleHead != NULL || singleHead->selector == "") {
            if (singleHead->selector == selectorName) {
                count++;
                break;
            } else {
                singleHead = singleHead->next;
            }
        }
        i++;
    }
    return count;
}

String valueOfAttributeforSelector(struct DoubleNode* head, String searchedAttribute, String searchedSelector) {
    String result = "";
    int i = 0;
    while (head->block[i] != NULL) {
        struct SingleNode* singleHead = head->block[i];
        while (singleHead != NULL) {
            String attribute = singleHead->attribute;
            attribute = attribute.removeSpecial();
            int start = attribute.findPos(':') + 1;
            int end = attribute.getLen();
            String attributeVal = attribute.substring(start, end);
            String attributeName = attribute.substring(0, start - 1);
            if (attributeName == searchedAttribute && searchedSelector == singleHead->selector) {
                result = attributeVal;
                break;
            } else {
                singleHead = singleHead->next;
            }
        }
        i++;
    }
    return result;
}

int totalOfAttribute(struct DoubleNode* head, String searchedAttribute) {
    int count = 0;
    int i = 0;
    while (head->block[i] != NULL) {
        struct SingleNode* singleHead = head->block[i];
        while (singleHead != NULL) {
            String attribute = singleHead->attribute;
            attribute = attribute.removeSpecial();
            int end = attribute.findPos(':') + 1;
            String attributeName = attribute.substring(0, end - 1);
            if (attributeName == searchedAttribute) {
                count++;
                break;
            } else {
                singleHead = singleHead->next;
            }
        }
        i++;
    }
    return count;
}

void deleteAttribute(struct DoubleNode* head, String attributeToDelete, int sectionNumber) {
    if (sectionNumber == BLOCK_SIZE) {
        int nodesToProceed = sectionNumber / BLOCK_SIZE;
        for (int i = 0; i < nodesToProceed; i++) {
            head = head->next;
        }
    }
    struct SingleNode* singleHead = head->block[sectionNumber];
    while (singleHead != NULL) {
        String attribute = singleHead->attribute;
        attribute = attribute.removeSpecial();
        int end = attribute.findPos(':') + 1;
        String attributeName = attribute.substring(0, end - 1);
        if (attributeToDelete == attributeName) {
            singleHead->attribute = "";
            singleHead->selector = "";
        }
        singleHead = singleHead->next;
    }
    if (attributesForSection(head, sectionNumber) == 0) {
        deleteSection(head, sectionNumber);
    }
    
    delete[] singleHead;
}

void detectCommand(String input, struct DoubleNode* head) {
    int firstColon = input.findPos(',');
    int secondColon = input.findNthPos(',', 1);
    int end = input.getLen();
    String name = input.substring(0, firstColon);
    String commandType = input.substring(firstColon + 1, secondColon);
    String commandWhere = input.substring(secondColon + 1, end);
    if (input == "?") {
        cout << "? == " << countNumberOfSections(head) << endl;
    } else if (commandType == "S") {
        if (commandWhere == "?") {
            if (name.isInteger() && name.convertToInt() > countNumberOfSections(head)) {
                return;
            } else {
                if (name.isInteger()) {
                    int convertedNumber = name.convertToInt();
                    cout << input << " == " << selectorsForSection(head, convertedNumber) << endl;
                } else {
                    int resultNumb = totalOfSelector(head, name);
                    cout << input << " == " << resultNumb << endl;
                }
            }
        } else {
            if (name.isInteger()) {
                if (name.convertToInt() > countNumberOfSections(head)) {
                    return;
                } else {
                    int comWhere = commandWhere.convertToInt();
                    int jthNumb = name.convertToInt();
                    String result = jthSelector(head, comWhere, jthNumb);
                    result = result.trim(result);
                    if (result == "") {
                        return;
                    } else {
                        cout << input << " == " << result << endl;
                    }
                }
            } else {
                int resultNumb = totalOfSelector(head, name);
                cout << input << " == " << resultNumb << endl;
            }
        }
    } else if (commandType == "A") {
        if (commandWhere == "?") {
            if (name.isInteger()) {
                int convertedNumber = name.convertToInt();
                if (name.convertToInt() > countNumberOfSections(head)) {
                    return;
                } else {
                    cout << input << " == " << attributesForSection(head, convertedNumber) << endl;
                }
            } else {
                int totalAttributes = totalOfAttribute(head, name);
                cout << input << " == " << totalAttributes << endl;
            }
        } else {
            int convertedNumber = name.convertToInt();
            String result = specifiedAttribute(head, commandWhere, convertedNumber);
            result = result.trim(result);
            cout << input << " == " << result << endl;
        }
    } else if (commandType == "E") {
        String result = valueOfAttributeforSelector(head, commandWhere, name);
        result = result.trim(result);
        cout << input << " == " << result << endl;
    } else if (commandType == "D") {
        if (commandWhere == "*") {
            int convertedNumber = name.convertToInt();
            deleteSection(head, convertedNumber);
            cout << input << " == deleted" << endl;
        } else {
            int convertedNumber = name.convertToInt();
            deleteAttribute(head, commandWhere, convertedNumber);
            cout << input << " == deleted" << endl;
        }
    }
}


int main() {
    String input;
    
    int numberOfSections = 0;
    int blockCount = 0;
    int whereStartCurly = 0;
    int whereEndCurly = 0;
    int numbOfSelectors = 0;
    int numbOfAttributes = 0;
    
    bool running = true;
    bool reading_css = true;
    bool reading_commands = false;
    bool adding_to_selectors = false;
    bool isOneLine = false;
    
    DoubleNode* doubleListHead = NULL;
    SingleNode* singleListHead = NULL;
    SelectorNode* selectorsList = NULL;
    selectorsList->name = "";
    insertEndDouble(&doubleListHead, &singleListHead);

    
    while (running) {
        cin >> input;
        input = input.removeTabs();
        whereStartCurly = input.findPos('{');
        whereEndCurly = input.findPos('}');
        isOneLine = oneLineDeclaration(input);
        numbOfSelectors = numberOfSelectors(input);
        numbOfAttributes = numberOfAttributes(input);
        
        if (!cin) {
            exit(0);
        }
        if (blockCount == 8) {
            insertEndDouble(&doubleListHead, &singleListHead);
            singleListHead = NULL;
            selectorsList->name = "";
            blockCount = 0;
        }
        if (adding_to_selectors) {
            if (whereEndCurly != -1) {
                adding_to_selectors = false;
                doubleListHead->block[blockCount] = singleListHead;
                singleListHead = NULL;
                deleteSelectorsList(selectorsList);
                selectorsList = NULL;
                selectorsList->name = "";
                blockCount++;
            } else {
                struct SelectorNode* temp = selectorsList;
                while (temp != NULL) {
                    String selectorName = temp->name;
                    input = input.substring(0, input.getLen() - 1);
                    addToSelector(&singleListHead, selectorName, input);
                    temp = temp->next;
                }
                delete[] temp;
            }
        } else {
            if (input == "????") {
                reading_css = false;
                reading_commands = true;
            } else if (input == "****") {
                reading_css = true;
                reading_commands = false;
            } else if (isOneLine) {
                for (int j = 0; j < numbOfSelectors; j++) {
                    String currentSelector = findSelector(input, j);
                    for (int k = 0; k < numbOfAttributes; k++) {
                        String currentAttribute = findAttribute(input, k);
                        addToSelector(&singleListHead, currentSelector, currentAttribute);
                    }
                }
                doubleListHead->block[blockCount] = singleListHead;
                singleListHead = NULL;
                numberOfSections++;
            } else if (reading_css && whereStartCurly != -1) {
                if (selectorsList == NULL && input.getLen() > 1) {
                    deleteSelectorsList(selectorsList);
                    selectorsList = NULL;
                    selectorsList->name = "";
                    for (int i = 0; i < numbOfSelectors; i++) {
                        String selector = findSelector(input, i);
                        insertSelectorNode(&selectorsList, selector);
                    }
                }
                adding_to_selectors = true;
            } else if (reading_css && input.getLen() > 0 && !adding_to_selectors) {
                deleteSelectorsList(selectorsList);
                for (int i = 0; i < numbOfSelectors; i++) {
                    insertSelectorNode(&selectorsList, findSelector(input, i));
                }
            } else if (reading_commands) {
                detectCommand(input, doubleListHead);
            }
        }
    }
    return 0;
}
