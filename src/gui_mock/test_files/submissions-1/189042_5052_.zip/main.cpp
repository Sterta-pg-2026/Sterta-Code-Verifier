#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define T 8
using namespace std;


struct Node {
	Node* next;
	char name[100];
	char value[100];
};

struct AttributeNode {
	AttributeNode* next;
	char name[100];
	char value[100];
};
struct SelectorNode {
	SelectorNode* next;
	char name[100];
};
struct Attribute {
	//Node* next;
	AttributeNode* next;
};

struct Selector {
	SelectorNode* next;
	//Node* next;
};

struct Section{
	Selector selectors;
	Attribute attributes;
	bool used = false;
	int blockNumber;
};

struct DoubleNode {
	DoubleNode* next;
	DoubleNode* prev;
	Section sections[T];
};

void push(Node** head)
{
	Node* node = *head;
	while(node->next != NULL) {
		node = node->next;
	}
	Node* tmp = (Node*)malloc(sizeof(Node));
	tmp->next = NULL;
	node->next = tmp;
	*head = node;
}
void pushAttribute(AttributeNode** head)
{
	AttributeNode* node = *head;
	while (node->next != NULL) {
		node = node->next;
	}
	AttributeNode* tmp = (AttributeNode*)malloc(sizeof(AttributeNode));
	tmp->next = NULL;
	node->next = tmp;
	*head = node;
}
void pushSelectors(SelectorNode** head)
{
	SelectorNode* node = *head;
	while (node->next != NULL) {
		node = node->next;
	}
	SelectorNode* tmp = (SelectorNode*)malloc(sizeof(SelectorNode));
	tmp->next = NULL;
	node->next = tmp;
	*head = node;
}



void pushDouble(DoubleNode** head)
{
	DoubleNode* doubleNode = *head;
	while (doubleNode->next != NULL)
	{
		doubleNode = doubleNode->next;
	}
	//Node* node = (Node*)malloc(sizeof(Node));
	AttributeNode* attNode = (AttributeNode*)malloc(sizeof(AttributeNode)); attNode->next = NULL;
	SelectorNode* selNode = (SelectorNode*)malloc(sizeof(SelectorNode)); selNode->next = NULL;
	//node->next = NULL;
	Section init; init.attributes.next = attNode; init.selectors.next = selNode;
	DoubleNode* tmp = (DoubleNode*)malloc(sizeof(DoubleNode));
	tmp->next = NULL; tmp->prev = doubleNode;
	for (int i = 0; i < T - 1; i++)
	{
		tmp->sections[i] = init;
	}
	doubleNode->next = tmp;
	*head = doubleNode;
}

void removeNode(Node* head, int position)
{
	Node* node = head;
	if (position == 1)
	{
		head = head->next;
	}
	for (int i = 1; i < position; i++)
	{
		node = node->next;
	}
	node->next = node->next->next;
}

void commandInterpreter(DoubleNode* css)
{
	int flag = 1;
	char command[100];
	char name[100];
	char sign[4];
	char secondName[100];
	int i = 0;
	int j = 0;
	do
	{
		cin >> command;
		if (!strcmp("****", command))
		{
			return;
		}
		do {
			if (flag == 1)
			{
				if (command[i] == ',')
				{
					flag = 2;
					i++;
					name[j] = '\0';
					j = 0;
					continue;
				}
				else
				{
					name[j] = command[i];
				}
			}
			else if (flag == 2)
			{
				if (command[i] == ',')
				{
					flag = 3;
					i++;
					sign[j] = '\0';
					j = 0;
					continue;
				}
				else
				{
					sign[j] = command[i];
				}
			}
			else if (i != strlen(command))
			{
				secondName[j] = command[i];
			}
			else if (i == strlen(command))
			{
				secondName[j] = '\0';
				i = 0;
				j = 0;
				flag = 1;
				break;
			}
			i++;
			j++;
		} while (1);
		cout << strlen(name) << " " << strlen(sign) << " " << strlen(secondName) << endl;
	} while (1);
}

void attributeInterpreter(DoubleNode* css)
{

}

void cssInterpreter(DoubleNode** css, int& blockNumber)
{
	DoubleNode* temp = (DoubleNode*)malloc(sizeof(DoubleNode));
	DoubleNode* temp2 = (DoubleNode*)malloc(sizeof(DoubleNode));
	temp = *css;
	int flag = 0;
	char input[1000];
	int i = 0;
	int k = 0;
	while(temp->sections[i].used == true) {
		if (i == T - 1)
		{
			pushDouble(&temp);
			i = 0;
			temp = temp->next;
			break;
		}
		i++;
	}
	temp->sections[i].blockNumber = blockNumber;
	blockNumber++;
	do {
		do {
			cin >> input;
			if (flag == 0)
			{
				if (k > 0 && input[0] != ',' && input[0] != '{')
				{
					temp->sections[i].selectors.next->name[k] = ' ';
					k++;
				}
				for (int j = 0; j < strlen(input); j++)
				{
					if (input[j] == ',')
					{
						temp->sections[i].selectors.next->name[k] = '\0';
						pushSelectors(&temp->sections[i].selectors.next);
						temp->sections[i].selectors.next = temp->sections[i].selectors.next->next;
						k = 0;
						continue;
					}
					else if (input[j] == '{')
					{
						temp->sections[i].selectors.next->name[k] = '\0';
						flag = 1;
						k = 0;
						break;
					}
					temp->sections[i].selectors.next->name[k] = input[j];					//assd s ,
					k++;
				}
			}
			if (flag == 1)
			{
				for (int j = 0; j < strlen(input); j++)
				{
					if (input[j] == '{')
					{
						continue;
					}
					else if (input[j] == ':')
					{
						temp->sections[i].attributes.next->name[k] = '\0';
						flag = 2;
						//k = 0;
						break;
					}
					temp->sections[i].attributes.next->name[k] = input[j];
					k++;
				}
				if (input[k] == ':' && k + 1 == strlen(input))
				{
					k = 0;
					continue;
				}
			}
			if (flag == 2)
			{
				if (k > 0 && input[0] != ';'  && input[0] != '}')
				{
					temp->sections[i].attributes.next->value[k] = ' ';
				}
				for (int j = k; j < strlen(input); j++)
				{
					if (input[j] == ';')
					{
						temp->sections[i].attributes.next->value[k] = '\0';
						flag = 1;
						k = 0; 
						pushAttribute(&temp->sections[i].attributes.next);
						temp->sections[i].attributes.next = temp->sections[i].attributes.next->next;
						continue;
					}
					else if (input[j] == '}')
					{
						temp->sections[i].attributes.next->value[k] = '\0';
						flag = 0;
						k = 0;
						temp->sections[i].used == true;
					}
					temp->sections[i].attributes.next->value[k] = input[j];
					k++;
				}
			}
		} while (temp->sections[i].used == false);
	} while (1);
	/*/do {
		cin >> input;
		if (input[0] == '{' && flag == 0)
		{
			flag = 1;
			do {
				if (strlen(input) > 1)
				{
					for (int j = 1; j < strlen(input); j++)
					{
						if (input[j] == ':')
						{
							flag = 2;
							k = j;
							continue;
						}
						else if (input[j] == ';')
						{
							flag = 1;
							continue;
						}
						if (flag == 1)
						{
							temp->sections[i].attributes.next->name[j - 1] = input[j];
						}
						else if (flag == 2)
						{
							temp->sections[i].attributes.next->value[j] = input[j];
						}
					}
				}
			} while (temp->sections[0].used == true);
		}
	} while (1);*/
	*css = temp;
}

int main()
{
	ios_base::sync_with_stdio(0);
	DoubleNode* css = (DoubleNode*)malloc(sizeof(DoubleNode));
	//Node* node = (Node*)malloc(sizeof(Node)); node->next = NULL;
	AttributeNode* attNode = (AttributeNode*)malloc(sizeof(AttributeNode)); attNode->next = NULL;
	SelectorNode* selNode = (SelectorNode*)malloc(sizeof(SelectorNode)); selNode->next = NULL;
	css->prev = NULL; css->next = NULL;
	Section init; init.attributes.next = attNode; init.selectors.next = selNode;
	int blockNumber = 1;
	for (int i = 0; i < T; i++)
	{
		css->sections[i] = init;
	}
	while (cin)
	{
		cssInterpreter(&css, blockNumber);
		char command[100];
		cin >> command;
		if (!strcmp("????", command))
		{
			commandInterpreter(css);
		}
	}
	return 0;
}