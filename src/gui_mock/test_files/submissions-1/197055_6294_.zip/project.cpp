#include <iostream>
#include <cmath>

using namespace std;

template <typename T>
struct Node {
    T value;
    Node* next;
    Node* prev;
};

template <typename T>
class Constant {
    public:
    T* array;
    int size;

    Constant(T* array, int size) {
        this->array = array;
        this->size = size;
    }
};

template <typename T>
class List {
    Node<T>* head;
    Node<T>* last;
    int count;

    public:
    List<T>() {
        head = NULL;
        last = NULL;
        count = 0;
    }

    List<T>(T value) {
        Node<T>* node = new Node<T>;
        node->next = NULL;
        node->prev = NULL;
        node->value = value;
        head = node;
        last = node;
        count = 1;
    }
    List<T>(Node<T>* head) {
        int counter = 0;

        Node<T>* temp = head;
        while (head->next != NULL) {
            counter++;
            temp = temp->head;
        }

        count = counter;
        this->head = head;
        this->last = temp;
    }

    void append(T value) {
        Node<T>* node = new Node<T>;
        node->value = value;
        node->next = NULL;
        node->prev = NULL;

        if (count == 0) {
            count++;
            head = node;
            last = node;
            return;
        }

        node->prev = last;
        last->next = node;
        last = node;
        count++;
    }

    void append(T* array, int size) {
        for (int i = 0; i < size; i++) {
            append(array[i]);
        }
    }

    void append(List<T>* list) {
        if (count == 0) {
            head = list->head;
            last = list->last;
            count = list->count;
            return;
        }

        for (int i = 0; i < list->getCount(); i++) {
            append(list->get(i));
        }

        delete list;
    }

    void pushForward(T element) {
        Node<T>* node = new Node<T>;
        node->value = element;
        node->next = NULL;
        node->prev = NULL;

        if (count == 0) {
            head = node;
            last = node;
            count++;
            return;
        }

        node->next = head;
        head->prev = node;
        head = node;
        count++;
    }

    void pushForward(T* array, int size) {
        for (int i = 0; i < size; i++) {
            pushForward(array[size - 1 - i]);
        }
    }

    void pushForward(List<T>* list) {
        for (int i = 0; i < list->getCount(); i++) {
            pushForward(list->get(list->getCount() - 1 - i));
        }
    }

    void pop() {
        if (count == 0) {
            return;
        }

        if (count == 1) {
            delete last;
            delete head;
            count = 0;
        }

        Node<T>* preLast = last->prev;
        preLast->next = NULL;
        delete last;
        last = preLast;
        count--;
    }

    void removeFirst() {
        if (count == 0) {
            return;
        }

        if (count == 1) {
            head = NULL;
            last = NULL;
            count--;
            return;
        }

        Node<T>* second = head->next;
        second->prev = NULL;
        delete head;
        head = second;
        count--;
    }

    void removeAt(int index) {
        if (index >= count) {
            return;
        }

        if (index == 0) {
            removeFirst();
            return;
        }

        if (index == count - 1) {
            Node<T>* prelast = last->prev;
            prelast->next = NULL;
            last = prelast;
            count--;
            return;
        }

        Node<T>* current = head;

        for (int i = 0; i < index; i++) {
            current = current->next;
        }

        current->prev->next = current->next;
        current->next->prev = current->prev;
        delete current;
        count--;
    }

    bool compare(Constant<T> constant) {
        if (count == 0) return false;

        return compare(constant.array, constant.size);
    }

    bool compare(T element) {
        if (count != 1) {
            return false;
        }

        return head->value == element;
    }

    bool compare(List<T>* list) {
        if (list->getCount() != getCount()) {
            return false;
        }

        for (int i = 0; i < getCount(); i++) {
            if (get(i) != list->get(i)) {
                return false;
            }
        }

        return true;
    }

    bool compare(T* array, int size) {
        if (size != count) {
            return false;
        }

        for (int i = 0; i < count; i++) {
            if (array[i] != get(i)) {
                return false;
            }
        }

        return true;
    }

    T get(int index) {
        Node<T>* cur = head;
        for (int i = 0; i < count; i++) {
            if (i == index) {
                return cur->value;
            }

            cur = cur->next;
        }

        int counter = 0;
        if (count / 2 < index) {
            counter = 0;
            Node<T>* temp = head;
            for (int i = 0; i < index; i++) {
                temp = temp->next;
            }

            return temp->value;
        } else {
            counter = count;
            Node<T>* temp = last;
            for (int i = count - 1; i > index; i--) {
                temp = temp->prev;
            }

            return temp->value;
        }
    }

    int getCount() {
        return count;
    }

    bool endsWith(T element) {
        return last->value == element;
    }

    bool endsWith(T* array, int size) {
        if (size > count) return false;

        for (int i = 0; i < size; i++) {
            if (array[size - 1 - i] != get(count - 1 - i)) {
                return false;
            }
        }

        return true;
    }

    bool endsWith(Constant<T> constant) {
        return endsWith(constant.array, constant.size);
    }

    bool beginsWith(T element) {
        return element == head->value;
    }

    bool beginsWith(T* array, int size) {
        if (size > count) return false;
        for (int i = 0; i < size; i++) {
            if (array[i] != get(i)) {
                return false;
            }
        }

        return true;
    }

    bool beginsWith(Constant<T> constant) {
        return beginsWith(constant.array, constant.size);
    }

    bool contains(char element) {
        for (int i = 0; i < count; i++) {
            if (get(i) == element) {
                return true;
            }
        }

        return false;
    }
};

using String = List<char>;

List<String*> split(String* string, char delimeter) {
    List<String*> newList = List<String*>();
    String* currentString = new String;
    for (int i = 0; i < string->getCount(); i++) {
        if (string->get(i) == delimeter) {
            if (currentString->getCount() != 0) {
                newList.append(currentString);
                currentString = new String;
            }
        } else {
            currentString->append(string->get(i));
        }
    }

    if (currentString->getCount() > 0) {
        newList.append(currentString);
    }

    return newList;
}

bool isNumber(String* string) {
    for (int i = 0; i < string->getCount(); i++) {
        if (string->get(i) > '9' || string->get(i) < '0') {
            return false;
        }
    }

    return true;
}

int toInt(String* string) {
    int result = 0;
    for (int i = 0; i < string->getCount(); i++) {
        int number = string->get(i) - '0';
        result += pow(10, string->getCount() - 1 - i) * number;
    }

    return result;
}

void trim(String* string) {
    if (string == NULL || string == nullptr) {
        return;
    }

    if (string->getCount() == 0) {
        return;
    }

    while(string->get(string->getCount() - 1) == ' ' || string->get(string->getCount() - 1) == 9) {
        string->removeAt(string->getCount() - 1);
        if (string->getCount() == 0) {
            return;
        }
    }

    while(string->get(0) == ' ' || string->get(0) == 9) {
        string->removeFirst();
        if (string->getCount() == 0) {
            return;
        }
    }
}

using String = List<char>;

template <typename T>
struct Chunk {
    Chunk<T>* next;
    Chunk<T>* prev;
    T array[8];
};

template <typename T>
class Array {
    int count;
    Chunk<T>* head;
    Chunk<T>* last;

    public:
    Array<T>() {
        head = NULL;
        last = NULL;
        count = 0;
    }

    Array<T>(T* array, int size) {
        count = size;
        int chunksCount = size / 8;

        if (chunksCount == 0) {
            Chunk<T>* newChunk = new Chunk<T>;
            for (int j = 0; j < size; j++) {
                newChunk->array[j] = array[j];
            }

            head = newChunk;
            last = newChunk;
            newChunk->next = NULL;
            newChunk->prev = NULL;
            return;
        }

        for (int i = 0; i < chunksCount; i++) {
            Chunk<T>* newChunk = new Chunk<T>;
            newChunk->next = NULL;
            newChunk->prev = NULL;

            Chunk<T>* chunks = new Chunk<T>[chunksCount + 1];

            for (int j = 0; j < 8; j++) {
                newChunk->array[j] = array[i * 8 + j];
            }

            if (i == 0) {
                head = newChunk;
                last = newChunk;
                newChunk->prev = NULL;
                newChunk->next = NULL;
                continue;
            }

            last->next = newChunk;
            newChunk->prev = last;
            last = newChunk;
        }

        if (size % 8 == 0) return;

        Chunk<T>* newChunk = new Chunk<T>;
        newChunk->prev = last;
        last->next = newChunk;
        last = newChunk;
        for (int i = 0; i < chunksCount % 8; i++) {
            newChunk[i] = array[chunksCount * 8 + i];
        }
    }

    Array<T>(T element) {
        Chunk<T>* newChunk = new Chunk<T>;
        newChunk->array[0] = element;
        head = newChunk;
        last = newChunk;
        count = 1;
    }

    void removeLast() {
        count--;
    }

    void append(T element) {
        if (count == 0) {
            Chunk<T>* chunk = new Chunk<T>;
            chunk->array[0] = element;
            head = chunk;
            last = chunk;
            count++;
            return;
        }

        if (count % 8 == 0) {
            Chunk<T>* newChunk = new Chunk<T>;
            newChunk->array[0] = element;
            newChunk->prev = last;
            newChunk->next = nullptr;
            last->next = newChunk;
            count++;
            return;
        }

        last->array[count % 8] = element;
        count++;
    }

    T get(int index) {
        Chunk<T>* currentChunk = head;

        int counter = 0;
        while (counter != index / 8) {
            currentChunk = currentChunk->next;
        }

        T returnObject = currentChunk->array[index % 8];

        return returnObject;
    }

    int getCount() {
        return count;
    }

    bool removeAt(int number) {
        if (number >= count || count == 0) {
            return false;
        }

        if (count == 1) {
            head = NULL;
            last = NULL;
            count = 0;
            return true;
        }

        Chunk<T>* current = head;

        int chunkNumber = number / 8;
        int elementNumber = number % 8;

        int chunkCount = count / 8 + (count % 8 == 0 ? 0 : 1);

        for (int i = chunkNumber; i < chunkCount; i++) {
            for (int j = 0; j < 8; j++) {
                if (i * 8 + j >= count) break;
                if (i == chunkNumber && j < elementNumber) {
                    continue;
                }

                if (j == 7) {
                    if (current != NULL) {
                        if (current->next != NULL) {
                            current->array[j] = next->array[0];
                        }
                    }

                    continue;
                }

                if (current != NULL) {
                    current->array[j] = current->next->array[j+1];
                }
            }

            current = next;
            if (next != NULL) {
                next = next->next;
            }
        }

        count--;

        if (count % 8 == 0) {
            Chunk<T>* temp = last;
            last->prev->next = NULL;
            last = last->prev;
            last->next = NULL;
            delete temp;
        }

        return true;
    }
};

char startCommandsArray[4] = {'?', '?', '?', '?'};
Constant<char> startCommands = Constant<char>(startCommandsArray, 4);

char startFileArray[4] = {'*', '*', '*', '*'};
Constant<char> startFile = Constant<char>(startFileArray, 4);

struct Parameter {
    String* name;
    String* value;
};

struct Block {
    List<String*> head = List<String*>();
    List<Parameter> params = List<Parameter>();
};
class CommandManager {

    Array<Block>* array;

    public:
    CommandManager() {
        array = NULL;
    }

    CommandManager(Array<Block>* array) {
        this->array = array;
    }

    // ?
    String* getCount() {
        String* newString = new String;

        char charArray[5] = {'?', ' ', '=', '=', ' '};

        int count = array->getCount();

        if (count == 0) {
            newString->append('0');
            return newString;;
        }

        while (count != 0) {
            newString->pushForward('0' + count % 10);
            count = count / 10;
        }

        newString->pushForward(charArray, 5);

        return newString;
    }

    String* getSelectorCount(int num) {
        if (array == NULL) {
            return NULL;
        }

        if (num >= array->getCount()) {
            return NULL;
        }

        int result = (array->get(num)).head.getCount();

        String* newString = new String;

        int temp = num + 1;

        if (result == 0) {
            newString->pushForward('0');
        } else {
            while(result != 0) {
                newString->pushForward('0' + result % 10);
                result = result / 10;
            }
        }

        char charArray[8] = {',', 'S', ',', '?', ' ', '=', '=', ' '};
        newString->pushForward(charArray, 8);

        while (temp != 0) {
            newString->pushForward('0' + (temp % 10));
            temp = temp / 10;
        }

        return newString;
    }

    String* getParameterCount(int num) {
        if (num >= array->getCount()) {
            return NULL;
        }

        int result = (array->get(num)).params.getCount();

        String* newString = new String;

        int temp = num + 1;

        if (result == 0) {
            newString->pushForward('0');
        } else {
            while(result != 0) {
                newString->pushForward('0' + result % 10);
                result = result / 10;
            }
        }

        char charArray[8] = {',', 'A', ',', '?', ' ', '=', '=', ' '};
        newString->pushForward(charArray, 8);

        while (temp != 0) {
            newString->pushForward('0' + (temp % 10));
            temp = temp / 10;
        }

        return newString;
    }

    String* getParametersCount(String* name) {
        int result = 0;

        for(int i = 0; i < array->getCount(); i++) {
            Block currentBlock = array->get(i);
            
            for (int j = 0; j < currentBlock.params.getCount(); j++) {
                if (currentBlock.params.get(j).name->compare(name)) result++;
            }
        }

        String* newString = new String;

        if (result == 0) {
            newString->pushForward('0');
        } else {
            while(result != 0) {
                newString->pushForward('0' + result % 10);
                result = result / 10;
            }
        }

        char charArray[8] = {',', 'A', ',', '?', ' ', '=', '=', ' '};
        newString->pushForward(charArray, 8);

        newString->pushForward(name);

        return newString;
    }

    String* getSelectorCount(String* name) {
        int result = 0;

        if (array->getCount() == 0) {
            String* newString = new String;

            newString->pushForward('0');
            char charArray[8] = {',', 'S', ',', '?', ' ', '=', '=', ' '};
            newString->pushForward(charArray, 8);

            newString->pushForward(name);

            return newString;
        }

        for(int i = 0; i < array->getCount(); i++) {
            Block currentBlock = array->get(i);
            
            for (int j = 0; j < currentBlock.head.getCount(); j++) {
                if (currentBlock.head.get(j)->compare(name)) result++;
            }
        }

        String* newString = new String;

        if (result == 0) {
            newString->pushForward('0');
        } else {
            while(result != 0) {
                newString->pushForward('0' + result % 10);
                result = result / 10;
            }
        }

        char charArray[8] = {',', 'S', ',', '?', ' ', '=', '=', ' '};
        newString->pushForward(charArray, 8);

        newString->pushForward(name);

        return newString;
    }

    String* getSelector(int sectionNumber, int number) {
        if (sectionNumber >= array->getCount()) return NULL;
        if (number >= array->get(sectionNumber).head.getCount()) return NULL;
        Block section = array->get(sectionNumber);
        if (section.head.getCount() < number - 1) {
            return NULL;
        }

        String* result = section.head.get(number);

        String* newString = new String;

        newString->pushForward(result);

        sectionNumber++;
        number++;

        char charArray1[4] = {' ', '=', '=', ' '};
        newString->pushForward(charArray1, 4);

        while(number != 0) {
            newString->pushForward('0' + number % 10);
            number = number / 10;
        }

        char charArray2[3] = {',', 'S', ','};
        newString->pushForward(charArray2, 3);

        while(sectionNumber != 0) {
            newString->pushForward('0' + sectionNumber % 10);
            sectionNumber = sectionNumber / 10;
        }

        return newString;
    }

    String* deleteSection(int number) {
        if (number > array->getCount()) {
            return NULL;
        }

        String* newString = new String;

        if (array->removeAt(number - 1)) {
            char charArray[15] = {',', 'D', ',', '*', ' ', '=', '=', ' ', 'd', 'e', 'l', 'e', 't', 'e', 'd'};
            newString->pushForward(charArray, 15);

            while (number != 0) {
                newString->pushForward('0' + number % 10);
                number = number / 10;
            }
        }

        return newString;
    }

    String* deleteAttribute(int number, String* name) {
        number--;
        Block block = array->get(number);

        bool result = false;
        bool attributeExists = false;

        for (int i = 0; i < block.params.getCount(); i++) {
            if (block.params.get(i).name->compare(name)) {
                attributeExists = true;
            }
        }

        if (attributeExists && block.params.getCount() == 1) {
            deleteSection(number);
            result = true;
        }

        if (attributeExists && block.params.getCount() > 1) {
            int index = 0;
            for (int i = 0; i < block.head.getCount(); i++) {
                if (block.params.get(i).name->compare(name)) {
                    index = i;
                    break;
                }
            }

            block.params.removeAt(index);
            result = true;
        }

        String* newString  = new String;

        if (result) {
            char charArray[11] = {' ', '=', '=', ' ', 'd', 'e', 'l', 'e', 't', 'e', 'd'};
            newString->pushForward(charArray, 11);

            newString->pushForward(name);

            char charArray1[3] = {',', 'D', ','};
            newString->pushForward(charArray1, 3);

            number++;

            while (number != 0) {
                newString->pushForward('0' + number % 10);
                number = number / 10;
            }
        }

        return newString;
    }

    String* getAttribute(int number, String* name) {
        number--;
        if (number >= array->getCount()) {
            return NULL;
        }

        Block block = array->get(number);
        String* result = new String;
        for (int i = 0; i < block.params.getCount(); i++) {
            if (block.params.get(i).name != NULL && block.params.get(i).name->compare(name)) {
                result = block.params.get(i).value;
                break;
            }
        }

        if (result->getCount() == 0) {
            delete result;
            return NULL;
        }

        String* newString = new String;
        newString->pushForward(result);

        char charArray[4] = {' ', '=', '=', ' '};
        newString->pushForward(charArray, 4);

        number++;

        newString->pushForward(name);

        char charArray1[3] = {',', 'A', ','};
        newString->pushForward(charArray1, 3);

        while (number != 0) {
            newString->pushForward('0' + number % 10);
            number = number / 10;
        }

        return newString;
    }

    String* getValue(String* selector, String* parameter) {
        String* result = new String;

        if (array == NULL || array == nullptr) {
            return NULL;
        }

        if (array->getCount() == 0) {
            return NULL;
        }

        Block currentBlock = array->get(0);

        for (int i = 0; i < array->getCount(); i++) {
            currentBlock = array->get(i);

            bool hasSelector = false;
            for (int j = 0; j < currentBlock.head.getCount(); j++) {
                if (currentBlock.head.get(j)->compare(selector)) {
                    hasSelector = true;
                }
            }

            if (hasSelector) {
                for (int j = 0; j < currentBlock.params.getCount(); j++) {
                    if (currentBlock.params.get(j).name->compare(parameter)) {
                        result = currentBlock.params.get(j).value;
                    }
                }
            }
        }

        if (result->getCount() == 0) {
            return NULL;
        }

        String* newString = new String;
        newString->pushForward(result);

        char charArray[4] = {' ', '=', '=', ' '};
        newString->pushForward(charArray, 4);

        newString->pushForward(parameter);

        char charArray1[3] = {',', 'E', ','};
        newString->pushForward(charArray1, 3);

        newString->pushForward(selector);

        return newString;
    }
};

enum ReadingMode {
    file = 0,
    command = 1
};

enum ParsingMode {
    selector = 0,
    atrName = 1,
    atrValue = 2
};

class Reader {
    Array<Block> blocks;
    Block currentBlock;
    
    ReadingMode readingMode;
    ParsingMode parsingMode;

    List<String*> output;

    String* parameterName = NULL;
    String* parameterValue = nullptr;
    int currentParametersCount = 0;
    CommandManager manager;

    private:
    void saveBlock() {
        blocks.append(currentBlock);
        parsingMode = selector;
        currentBlock = Block();
    }

    void parseToBlock(String* string) {
        trim(string);
        
        if (string->getCount() == 0) {
            return;
        }

        switch (parsingMode) {
            case selector: {
                currentBlock.head.append(string);
                break;
            }

            case atrName: {
                parameterName = string;
                break;
            }

            case atrValue: {
                struct Parameter param = Parameter();
                param.name = parameterName;
                param.value = string;
                currentBlock.params.append(param);
                break;
            }

            default: break;
        }
    }

    void parseToCommands(String* string) {
        String* result;
        if (string->compare('?')) {
            result = manager.getCount();
            output.append(result);
        }

        List<String*> listString = split(string, ',');

        if (listString.getCount() < 3) {
            return;
        } 

        if (listString.get(2)->compare('?')) {
            if (isNumber(listString.get(0))) {
                int number = toInt(listString.get(0)) - 1;

                if (listString.get(1)->compare('S')) {
                    result = manager.getSelectorCount(number);
                } else if (listString.get(1)->compare('A')) {
                    result = manager.getParameterCount(number);
                }
            } else {
                if (listString.get(1)->compare('A')) {
                    result = manager.getParametersCount(listString.get(0));
                } else {
                    result = manager.getSelectorCount(listString.get(0));
                }
            }
        } else if (isNumber(listString.get(2))) {
            int number = toInt(listString.get(2)) - 1;
            int section = toInt(listString.get(0)) - 1;

            result = manager.getSelector(section, number);
        } else if (listString.get(1)->compare('D')) {
            int number = toInt(listString.get(0));

            if (listString.get(2)->compare('*')) {
                result = manager.deleteSection(number);
            } else {
                result = manager.deleteAttribute(number, listString.get(2));
            }
        } else if (listString.get(1)->compare('A')) {
            if (isNumber(listString.get(0))) {
                result = manager.getAttribute(toInt(listString.get(0)), listString.get(2));
            }
        } else if (listString.get(1)->compare('E')) {
            result = manager.getValue(listString.get(0), listString.get(2));
        }

        //print(result);
        output.append(result);
    }

    public:
    Reader() {
        readingMode = file;
        parsingMode = selector;
        output = List<String*>();
        blocks = Array<Block>();
        currentBlock = Block();
        manager = CommandManager(&blocks);
    }

    bool read() {
        String* newString = new String;

        char c;
        while (cin.get(c)) {
            if (c == '\n') {
                prepareToParse(newString);
                newString = new String;
                continue;
            }

            if (c == EOF) return false;

            if (readingMode == file) {
                if (c == ',' && parsingMode == selector) {
                    prepareToParse(newString);
                    newString = new String;
                    continue;
              }

               if (c == '{') {
                    prepareToParse(newString);
                    parsingMode = atrName;
                    newString = new String;
                    continue;
                }

                if (c == ':') {
                    prepareToParse(newString);
                    parsingMode = atrValue;
                    newString = new String;
                    continue;
                }

                if (c == ';') {
                    prepareToParse(newString);
                    parsingMode = atrName;
                    newString = new String;
                    continue;
                }

                if (c == '}') {
                    saveBlock();
                    parsingMode = selector;
                    newString = new String;
                    continue;
                }
            }
            
            newString->append(c);
        }

        return true;
    }

    void prepareToParse(String* string) {
        if (string->getCount() == 0) {
            return;
        }

        if (string->compare(startCommands)) {
            readingMode = command;
            return;
        }

        if (string->compare(startFile)) {
            readingMode = file;
            return;
        }

        switch (readingMode)
        {
        case file:
            {
                parseToBlock(string);
                break;
            }
            
        case command:
            {
                parseToCommands(string);
                break;
            }


        default:
            break;
        }
    }

    void print(String* list) {
        if (list == NULL) {
            return;
        }

        if (list->getCount() == 0) {
            return;
        }

        for (int i = 0; i < list->getCount(); i++) {
            cout << list->get(i);
        }

        cout << endl;
    }

    void printOutput() {
        for (int i = 0; i < output.getCount(); i++) {
            print(output.get(i));
        }
    }
};

int main() {
    Reader reader = Reader();
    reader.read();
    reader.printOutput();
}