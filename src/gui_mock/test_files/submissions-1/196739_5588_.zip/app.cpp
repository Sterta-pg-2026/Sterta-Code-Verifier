#include <cstring>
#include <cctype>
#include "list.h"
#include "block.h"
#include "css.h"
#include "block_list.h"

using namespace std;

enum status { parsing_selectors, parsing_attrs, parsing_commands };

void parseSelectors(char* buffer, Section* section)
{

    int i = 0, j = 0;
    while (buffer[j] != '\0')
    {
        if (buffer[j] == ','){
            buffer[j] = '\0';
            section->addSelector(&buffer[i]);
            i = j + 1;
        }
        j++;
    }
    if (buffer[i] != '\0')
        section->addSelector(&buffer[i]);
}

void parseAttr(char* buffer, Section* section)
{
    int i = 0;
    while (buffer[i] != ':') i++;
    buffer[i] = '\0';
    section->addAttr(buffer, &buffer[i + 1]);
}

char* getCommandLetter(char* str)
{
    while (*str != '\0')
    {
        if (*str == ',')
        {
            return ++str;
        }
        str++;
    }
    return nullptr;
}

int getNumberFromString(char* str)
{
    int num = 0;
    while (isdigit(*str))
    {
        num = num * 10;
        num += *str - '0';
        str++;
    }
    return num;
}

bool strContains(char* str, char search)
{
    while (*str != '\0')
    {
        if (*str == search) return true;
        str++;
    }
    return false;
}

istream& getLine(istream& is, char* buffer)
{

    while (*buffer != '\n')
    {
        is.get(*buffer);
        buffer++;
    }
    (*buffer) = '\0';
    return is;
}

int main()
{
    BlockList sections;
    Section* section;

    char buffer[128];
    status parsingStatus = parsing_selectors;
    bool isAllowedSpacesInAttr = false;
    int i = 0;

    while (cin.get(buffer[i]))
    {
        switch (parsingStatus)
        {
            case parsing_selectors:
                if (buffer[i] <= 32)
                {
                    // white element
                    if (i != 0 && buffer[i-1] != ',' && buffer[i] == ' ')
                    {
                        i++;
                    }
                }
                else if (buffer[i] == '{')
                {
                    if (i > 0 && buffer[i-1] <= 32)
                    {
                        i--;
                    }
                    section = new Section;
                    sections.addSection(section);
                    buffer[i] = '\0';
                    parseSelectors(buffer, section);
                    parsingStatus = parsing_attrs;
                    i = 0;
                } else if (buffer[i] == '?')
                {
                    cin.get(buffer, 3);
                    i = 0;
                    parsingStatus = parsing_commands;
                } else i++;
                break;
         
            case parsing_attrs:

                if (buffer[i - 1] == ':' && buffer[i] > 32)
                    isAllowedSpacesInAttr = true;
                if (buffer[i] <= 32)
                {
                    // white element
                    if (buffer[i] == ' ' && isAllowedSpacesInAttr)
                    {
                        i++;
                    }
                } else if (buffer[i] == '}')
                {
                    if (i != 0)
                    {
                        buffer[i] = '\0';
                        parseAttr(buffer, section);
                    }
                    parsingStatus = parsing_selectors;
                    i = 0;
                } else if (buffer[i] == ';')
                {
                    if (buffer[i-1] == ' ')
                    {
                        i--;
                    }
                    buffer[i] = '\0';
                    parseAttr(buffer, section);
                    i = 0;
                    isAllowedSpacesInAttr = false;
                } else i++;
                break;
         
            case parsing_commands:
                i = 0; 
                bool endWithBreak = false;
                while (cin >> &buffer[i])
                {
                    if (strcmp(buffer, "?") == 0)
                    {
                        cout << "? == " << sections.getSize() << endl;
                        continue;
                    } else if (strcmp(buffer, "****") == 0)
                    {
                        parsingStatus = parsing_selectors;
                        endWithBreak = true;
                        break;
                    }

                    char* command = getCommandLetter(buffer);
                    if (command == nullptr || *command == '\0'){
                         i = strlen(buffer);
                         buffer[i] = ' ';
                         i++;
                         continue;
                    }
                    i = 0;

                    *(command-1) = '\0';
                    if (strContains(buffer, ','))
                    {
                        continue;
                    }
                    *(command-1) = ',';

                    int sectionIndex, selectorIndex;
                    attr a;
                    switch (*command)
                    {
                        case 'S':
                            if (*(command+2) == '?' && isdigit(*buffer))
                            {
                                sectionIndex = getNumberFromString(buffer) - 1;
                                section = sections.get(sectionIndex);
                                if (section != nullptr){
                                    cout << buffer << " == " << section->selectorsSize() << endl;
                                }
                            } else if (isdigit(*buffer) && isdigit(*(command+2))){
                                sectionIndex = getNumberFromString(buffer) - 1;
                                selectorIndex = getNumberFromString(command+2) - 1;
                                section = sections.get(sectionIndex);
                                if (section != nullptr){
                                    selector s = section->getSelector(selectorIndex);
                                    if (s.name[0] != '\0')
                                    {
                                        cout << buffer << " == " << s.name << endl;                                        
                                    }
                                }
                            } else {
                                *(command - 1) = '\0';
                                int count = sections.countSelector(buffer);
                                *(command - 1) = ',';
                                cout << buffer << " == " << count << endl;
                            }
                            break;
                        case 'D':
                            sectionIndex = getNumberFromString(buffer) - 1;
                            if (*(command+2) == '*')
                            {
                                if (sections.deleteSection(sectionIndex))
                                    cout << buffer << " == deleted" << endl;
                            } else
                            {
                                if (sections.deleteAttr(sectionIndex, command+2))
                                    cout << buffer << " == deleted" << endl;
                            }
                            break;
                        case 'A':
                            if (isdigit(*buffer) && *(command+2) == '?')
                            {
                                sectionIndex = getNumberFromString(buffer) - 1;
                                section = sections.get(sectionIndex);
                                if (section != nullptr)
                                    cout << buffer << " == " << section->attrSize() << endl;
                            } else if (isdigit(*buffer) )
                            {
                                sectionIndex = getNumberFromString(buffer) - 1;
                                section = sections.get(sectionIndex);
                                if (section != nullptr)
                                {
                                    a = section->getAttrByProperty(command + 2);
                                    if (a.value[0] != '\0')
                                        cout << buffer << " == " << a.value << endl;    
                                }
                                
                            } else {
                                *(command - 1) = '\0';
                                int count = sections.countAttr(buffer);
                                *(command - 1) = ',';
                                cout << buffer << " == " << count << endl;
                            }
                            break;
                        case 'E':
                            *(command-1) = '\0';
                            a = sections.lastAttrForSelector(buffer, command+2);
                            if (a.property[0] != '\0')
                            {
                                *(command - 1) = ',';
                                cout << buffer << " == " << a.value << endl;
                            }
                    }
                }
                if (!endWithBreak)
                {
                    return 0;
                }
                i = 0;
                break;
        }
    }

    return 0;
}