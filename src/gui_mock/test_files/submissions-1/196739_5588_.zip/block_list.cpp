#include "block_list.h"

void BlockList::addSection(Section* section){
	if (blocks.getSize() > 0 )
	{
		if (!blocks.getTail()->data.addSection(section))
		{
			blocks.append(Block());
			addSection(section);
		}
	} else {
		blocks.append(Block());
		addSection(section);
	}
}

Node<Block>* BlockList::getBlock(std::size_t& index)
{
	Node<Block>* curr = blocks.getHead();
	while (curr != nullptr && index > curr->data.getTaken() - 1)
	{
		index -= curr->data.getTaken();
		curr = curr->next;
	}
	return curr;
}

Section* BlockList::get(std::size_t index)
{
	Node<Block>* block = getBlock(index);
	if (block != nullptr)
		return block->data[index];
	return nullptr;
}

std::size_t BlockList::getSize()
{
	std::size_t size = 0;
	for (Node<Block>* curr = blocks.getHead(); curr != nullptr; curr = curr->next)
	{
		size += curr->data.getTaken();
	}
	return size;
}

int BlockList::countSelector(char* selector)
{
	int count = 0;
	for (Node<Block>* curr = blocks.getHead(); curr != nullptr; curr = curr->next)
	{
		for (int i = 0; i < curr->data.getTaken(); i++)
		{
			if (curr->data[i]->hasSelector(selector))
			{
				count++;
			}
		}
	}

	return count;
}

int BlockList::countAttr(char* property)
{
	int count = 0;
	for (Node<Block>* curr = blocks.getHead(); curr != nullptr; curr = curr->next)
	{
		for (int i = 0; i < curr->data.getTaken(); i++)
		{
			if (curr->data[i]->hasAttr(property))
			{
				count++;
			}
		}
	}

	return count;
}

bool BlockList::deleteSection(std::size_t index)
{
	Node<Block>* block = getBlock(index);
	if (block == nullptr)
		return false;
	if (!block->data.deleteSection(index)) return false;
	if (block->data.getTaken() == 0)
	{
		blocks.removeNode(block);
	}
	return true;
}

bool BlockList::deleteAttr(std::size_t index, char* property)
{
	Node<Block>* block = getBlock(index);
	if (block == nullptr)
		return false;
	if(!block->data.deleteAttr(index, property)) return false;
	if (block->data.getTaken() == 0)
	{
		blocks.removeNode(block);
	}
	return true;
}

attr BlockList::lastAttrForSelector(char* selector, char* property)
{
	for (Node<Block>* curr = blocks.getTail(); curr != nullptr; curr = curr->previous)
	{
		for (int i = curr->data.getTaken() - 1; i >= 0; i--)
		{
			Section* s = curr->data[i];
			if (s->hasAttr(property) && s->hasSelector(selector))
			{
				return s->getAttrByProperty(property);
			}
		}
	}
	return {"\0", "\0"};
}
