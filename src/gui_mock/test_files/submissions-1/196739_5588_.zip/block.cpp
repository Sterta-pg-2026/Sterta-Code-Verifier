#include "block.h"

Block::Block()
: taken(0){
	for (std::size_t i = 0; i < BLOCK_SIZE; i++)
	{
		sections[i] = nullptr;
	}
}

bool Block::addSection(Section* section)
{
	if (taken < BLOCK_SIZE)
	{
		sections[taken] = section;
		taken++;
		return true;
	}
	return false;
}

std::size_t Block::getTaken()
{
	return taken;
}

Section* Block::operator[](std::size_t index)
{
	if (index < BLOCK_SIZE)
	{
		return sections[index];	
	}
	return nullptr;
}

bool Block::deleteSection(std::size_t index)
{
	if (sections[index] == nullptr) return false;
	delete sections[index];
	taken--;

	while (sections[index] != nullptr && index < BLOCK_SIZE)
	{
		if (index < BLOCK_SIZE - 1)
			sections[index] = sections[index + 1];
		else
			sections[index] = nullptr;
		index++;
	}
	return true;

}

bool Block::deleteAttr(std::size_t index, char* property)
{

	if (sections[index] == nullptr) return false;
	if (!sections[index]->hasAttr(property)) return false;
	sections[index]->removeAttr(property);
	
	if (sections[index]->attrSize() == 0)
	{
		deleteSection(index);
	}

	return true;
}


Block::~Block()
{
	for (std::size_t i = 0; i < BLOCK_SIZE; i++)
	{
		if (sections[i] != nullptr)
		{
			delete sections[i];
		}
	}
}