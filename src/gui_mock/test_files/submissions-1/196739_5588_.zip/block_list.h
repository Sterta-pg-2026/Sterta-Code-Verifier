#pragma once

#include "block.h"
#include "list.h"

class BlockList {
	List<Block> blocks;
	Node<Block>* getBlock(std::size_t& index);
public:
	void addSection(Section* section);
	Section* get(std::size_t index);
	std::size_t getSize();
	int countSelector(char* selector);
	int countAttr(char* property);
	bool deleteSection(std::size_t index);
	bool deleteAttr(std::size_t index, char* property);
	attr lastAttrForSelector(char* selector, char* property);
};