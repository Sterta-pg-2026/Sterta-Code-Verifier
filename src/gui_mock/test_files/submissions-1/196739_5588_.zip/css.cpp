#include "css.h"
#include <cstring>


void Section::addSelector(char* name)
{
    selector newSelector;
    strcpy(newSelector.name, name);
    selectors.append(newSelector);
}

void Section::addAttr(char* property, char* value)
{
    for (Node<attr>* tmp = attrs.getHead(); tmp != nullptr; tmp = tmp->next)
    {
        if (strcmp(tmp->data.property, property) == 0){
            attrs.removeNode(tmp);
            break;
        }
    }
    attr newAttr;
    strcpy(newAttr.property, property);
    strcpy(newAttr.value, value);
    attrs.append(newAttr);
}

std::size_t Section::attrSize()
{
    return attrs.getSize();
}

bool Section::hasAttr(const char* property)
{
    for (Node<attr>* tmp = attrs.getHead(); tmp != nullptr; tmp = tmp->next)
    {
        if (strcmp(tmp->data.property, property) == 0){
            return true;
        }
    }
    return false;
}

void Section::removeAttr(char* property)
{
    for(Node<attr>* curr = attrs.getHead(); curr != nullptr; curr = curr->next)
    {
        if (strcmp(property, curr->data.property) == 0)
        {
            attrs.removeNode(curr);
            break;
        }
    }
}

std::size_t Section::selectorsSize()
{
    return selectors.getSize();
}

bool Section::hasSelector(const char* name)
{
    for (Node<selector>* tmp = selectors.getHead(); tmp != nullptr; tmp = tmp->next)
    {
        if (strcmp(tmp->data.name, name) == 0)
        {
            return true;
        }
    }
    return false;
}

selector Section::getSelector(std::size_t index)
{
    Node<selector>* s = selectors.getNode(index);
    if (s != nullptr)
    {
        return s->data;
    }
    return {"\0"};
}

attr Section::getAttr(std::size_t index)
{
    return attrs.get(index);
}

attr Section::getAttrByProperty(char* property)
{
    for (Node<attr>* curr = attrs.getHead(); curr != nullptr; curr = curr->next)
    {
        if (strcmp(property, curr->data.property) == 0)
        {
            return curr->data;
        }
    }

    return {"\0", "\0"};

}