#pragma once
#define STRING_SIZE 128
#include "list.h"

struct attr {
    char property[STRING_SIZE];
    char value[STRING_SIZE];
};

struct selector {
    char name[STRING_SIZE];
};

class Section {
    List<attr> attrs;
    List<selector> selectors;
public:
    void addSelector(char* name);
    void addAttr(char* property, char* value);
    std::size_t attrSize();
    void removeAttr(char* property);

    bool hasAttr(const char* property);

    std::size_t selectorsSize();
    bool hasSelector(const char* name);

    selector getSelector(std::size_t index);
    attr getAttr(std::size_t index);
    attr getAttrByProperty(char* property);
};