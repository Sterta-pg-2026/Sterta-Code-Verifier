#pragma once

#include <iostream>
#include "list.h"
#include "css.h"

#define BLOCK_SIZE 19


class Block {
	Section* sections[BLOCK_SIZE];
	std::size_t taken;
public:
	Block();
	bool addSection(Section* section);
	std::size_t getTaken();
	Section* operator[](std::size_t index);
	bool deleteSection(std::size_t index);
	bool deleteAttr(std::size_t index, char* property);
	~Block();
};
