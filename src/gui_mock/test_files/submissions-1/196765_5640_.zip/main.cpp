#include <iostream>
class MyString {
private:
    char* data;
    size_t length;
public:
    MyString() : data(nullptr), length(0) {}
    MyString(const char* str) : data(nullptr), length(0) {
        if (str != nullptr) {
            length = strlen(str);
            data = new char[length + 1];
            for (size_t i = 0; i < length; ++i) {
                data[i] = str[i];
            }
            data[length] = '\0';
        }
    }
    MyString(const MyString& other) : data(nullptr), length(other.length) {
        if (other.data != nullptr) {
            data = new char[length + 1];
            for (size_t i = 0; i < length; ++i) {
                data[i] = other.data[i];
            }
            data[length] = '\0';
        }
    }
    ~MyString() {
        delete[] data;
    }
    MyString& operator=(const MyString& other) {
        if (this != &other) {
            delete[] data;
            length = other.length;
            if (other.data != nullptr) {
                data = new char[length + 1];
                for (size_t i = 0; i < length; ++i) {
                    data[i] = other.data[i];
                }
                data[length] = '\0';
            }
        }
        return *this;
    }
    MyString& operator+=(char c) {
        // создаем новый массив данных на 1 элемент больше
        char* newData = new char[length + 2];
        // копируем старые данные в новый массив
        for (size_t i = 0; i < length; ++i) {
            newData[i] = data[i];
        }
        // добавляем новый символ в конец нового массива
        newData[length] = c;
        newData[length + 1] = '\0';
        // удаляем старые данные и заменяем их новыми
        delete[] data;
        data = newData;
        length++;
        // возвращаем ссылку на объект MyString
        return *this;
    }
    bool operator==(const MyString& other) const {
        if (length != other.length) {
            return false;
        }
        for (int i = 0; i <= length; i++) {
            if (data[i] != other.data[i]) {
                return false;
            }
        }
        return true;
    }
    bool operator!=(int n) const {
        int numLength = 0;
        int temp = n;
        while(temp != 0) {
            temp /= 10;
            numLength++;
        }
        if (length != numLength) {
            return true;
        }
        for (int i = 0; i < length; i++) {
            if (data[i] != ((n / (int)pow(10, length - i - 1)) % 10) + '0') {
                return true;
            }
        }
        return false;
    }
    char operator[](size_t index) const {
        if (index >= length) {
            throw std::out_of_range("Index out of range");
        }
        return data[index];
    }
    char& operator[](size_t index) {
        if (index >= length) {
            throw std::out_of_range("Index out of range");
        }
        return data[index];
    }
    void push_back(char c) {
        *this += c;
    }
    void clear() {
        delete[] data;
        data = nullptr;
        length = 0;
    }
    size_t size() const {
        return length;
    }
    const char* c_str() const {
        return data;
    }
    friend std::istream& operator>>(std::istream& is, MyString& str) {
        char c;
        str = MyString();
        while (is.get(c) && c != '\n') {
            str += c;
        }
        return is;
    }
    friend std::ostream& operator<<(std::ostream& os, const MyString& str) {
        return os << str.data;
    }
};
class Attribute {
private:
    MyString property;
    MyString value;
    Attribute* next;
public:
    static int count_a;
    Attribute() { property = nullptr; value = nullptr; }
    Attribute(MyString property, MyString value) {
        this->property = property;
        this->value = value;
        this->next = nullptr;
        count_a++; 
    }
    MyString getProperty() { return property; }
    MyString getValue() { return value; }
    Attribute* getNext() { return next; }
    void setNext(Attribute* next) { this->next = next; }
    void addAttribute(MyString property, MyString value) {
        Attribute* newNode = new Attribute(property, value);
        newNode->setNext(next);
        next = newNode;
    }
    void removeAttribute(MyString property) {
        Attribute* currentNode = this;
        Attribute* prevNode = nullptr;
        while (currentNode != nullptr) {
            if (currentNode->getProperty() == property) {
                if (prevNode == nullptr) {
                    this->property = currentNode->getNext()->getProperty();
                    this->value = currentNode->getNext()->getValue();
                    this->next = currentNode->getNext()->getNext();
                }
                else {
                    prevNode->setNext(currentNode->getNext());
                }
                count_a--;
                delete currentNode;
                break;
            }
            prevNode = currentNode;
            currentNode = currentNode->getNext();
        }
    }
};
int Attribute::count_a = 0;
class SelectorList {
private:
    MyString name;
    Attribute* attributes;
    SelectorList* next_s;
public:
    static int count_s;
    SelectorList() { next_s = nullptr;}
    SelectorList(MyString name, Attribute* attributes) {
        this->name = name;
        this->attributes = attributes;
        this->next_s = nullptr;
        count_s++;
    }
    MyString getName() { return name; }
    Attribute* getAttributes() { return attributes; }
    SelectorList* getNext() { return next_s; }
    void setNext(SelectorList* next_s) { this->next_s = next_s; }

    void addAttribute(MyString property, MyString value) {
        Attribute* newNode = new Attribute(property, value);
        newNode->setNext(attributes);
        attributes = newNode;
    }
    void addSelector(MyString name, Attribute* attributes) {
        SelectorList* newNode = new SelectorList(name, attributes);
        newNode->setNext(nullptr);
        if (next_s == nullptr) {
            next_s = newNode;
        }
        else {
            SelectorList* currentNode = next_s;
            while (currentNode->getNext() != nullptr) {
                currentNode = currentNode->getNext();
            }
            currentNode->setNext(newNode);
        }
    }
    void removeAttribute(MyString property) {
        Attribute* currentNode = attributes;
        Attribute* prevNode = nullptr;
        while (currentNode != nullptr) {
            if (currentNode->getProperty() == property) {
                if (prevNode == nullptr) {
                    attributes = currentNode->getNext();
                }
                else {
                    prevNode->setNext(currentNode->getNext());
                }
                delete currentNode;
                break;
            }
            prevNode = currentNode;
            currentNode = currentNode->getNext();
        }
    }
};
int SelectorList::count_s = 0;
class Block {
private:
    static const int T = 8;
    SelectorList* head_s;
    SelectorList* tail_s;
    SelectorList* findSelector(MyString name) {
        SelectorList* currentNode = head_s;
        while (currentNode != nullptr) {
            if (currentNode->getName() == name) {
                return currentNode;
            }
            currentNode = currentNode->getNext();
        }
        return nullptr;
    }
    Block* next_b;
public:
    Block() {
        head_s = nullptr;
        tail_s = nullptr;
    }
    Block* getNext() { return next_b; }
    void setNext(Block* next_b) { this->next_b = next_b; }
    void addAttribute(MyString selectorName, MyString property, MyString value) {
        SelectorList* selector = findSelector(selectorName);
        if (selector == nullptr) {
            return;
        }
        selector->addAttribute(property, value);
    }
    void addSelector(MyString name, Attribute* attributes) {
        if (tail_s != nullptr) {
            Block* newBlock = new Block();
            newBlock->addSelector(name, attributes);
            newBlock->setNext(this->getNext());
            this->setNext(newBlock);
            return;
        }

        SelectorList* newNode = new SelectorList(name, attributes);
        newNode->setNext(nullptr);
        if (tail_s == nullptr) {
            head_s = newNode;
            tail_s = newNode;
        }
        else {
            tail_s->setNext(newNode);
            tail_s = newNode;
        }
    }
    void removeAttribute(MyString selectorName, MyString property) {
        SelectorList* selector = findSelector(selectorName);
        if (selector == nullptr) {
            return;
        }
        selector->removeAttribute(property);
    }
    void removeSelector(MyString name) {
        SelectorList* currentNode = head_s;
        SelectorList* prevNode = nullptr;
        while (currentNode != nullptr) {
            if (currentNode->getName() == name) {
                if (prevNode == nullptr) {
                    head_s = currentNode->getNext();
                }
                else {
                    prevNode->setNext(currentNode->getNext());
                }
                if (currentNode == tail_s) {
                    tail_s = prevNode;
                }
                delete currentNode;
                break;
            }
            prevNode = currentNode;
            currentNode = currentNode->getNext();
        }
    }
};
class Parser {
private:
    MyString input;
    size_t pos;
    SelectorList* currentSelector = nullptr;
    Attribute* currentAttribute = nullptr;
    enum State {
        NAME,
        PROPERTY,
        VALUE,
        IGNORE
    };
public:
    Parser(MyString input) {
        this->input = input;
        this->pos = 0;
        this->currentSelector = nullptr;
        this->currentAttribute = nullptr;
    }
    Block parse() {
        Block block;
        State state = NAME;
        MyString currentName = nullptr;
        MyString currentProperty = nullptr;
        MyString currentValue = nullptr;
        while (pos < input.size()) {
            char c = input[pos];
            pos++;
            switch (state) {
            case NAME:
                if (c == '{') {
                        currentSelector = new SelectorList(currentName, currentAttribute);
                        block.addSelector(currentSelector->getName(), currentSelector->getAttributes());
                        currentName.clear();
                        state = PROPERTY;
                }
                else if (c == '}') {
                    state = IGNORE;
                }
                else if (c == ', ') {
                    state = NAME;
                }
                else if (c != ' ') {
                    currentName.push_back(c);
                }
                break;
            case PROPERTY:
                if (c == ':') {
                    state = VALUE;
                }
                else if (c == '}') {
                    state = IGNORE;
                }
                else if (c != '\t') {
                    currentProperty.push_back(c);
                }
                break;
            case VALUE:
                if (c == ';') {
                    if (currentAttribute == nullptr) {
                        block.addAttribute(currentSelector->getName(), currentProperty, currentValue);
                    }
                    else {
                        currentAttribute->setNext(currentAttribute);
                        block.addAttribute(currentSelector->getName(), currentProperty, currentValue);
                    }
                    currentValue.clear();
                    currentProperty.clear();
                    state = PROPERTY;
                }
                else if (c == '}') {
                    state = IGNORE;
                }
                else if (c != '\t') {
                    currentValue.push_back(c);
                }
                break;
            case IGNORE:
                if (c == '}') {
                    currentSelector = nullptr;
                    currentAttribute = nullptr;
                    state = NAME;
                }
            }
        }
        return block;
    }
};
int main() {
    MyString input;
    int blockCount = 0;
    bool isReading = false;
    char c;
    while (std::cin.get(c)) {
        input += c;
            bool isFinished = false;
            int k = 0;
            while (!isFinished && k < input.size()) {
                MyString token;
                for (int l = k; l < k + 4 && l < input.size(); l++) {
                    token += input[l];
                }
                k++;
                if (token == "}") {
                    isFinished = true;
                }
                if (token == "?" && !isReading) {
                    isReading = true;
                }
                if (token == "*" && isReading) {
                    isReading = false;
                    std::cout << "? == " << blockCount << std::endl;
                }
            }
            if (isFinished) {
                Parser parser(input);
                Block block = parser.parse();
                blockCount++;
                input.clear();
            }
    }
    return 0;
}