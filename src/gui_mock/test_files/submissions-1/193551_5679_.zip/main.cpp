#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cstring>
const int defaultStringSize = 8;
const int ListArraySize = 17;

class CustomString {
    int strContentSize = 0;
    int strSize = 0;
    char* tab = nullptr;
public:
    CustomString()
    {
        this->tab = new char[defaultStringSize];
        this->strSize = defaultStringSize;
        tab[0] = '\0';
        strContentSize = 1;
    }
    CustomString(int initSize)
    {
        this->tab = new char[initSize];
        this->strSize = initSize;
        tab[0] = '\0';
        strContentSize = 1;
    }
    CustomString(const CustomString& inputString)
    {
        this->strContentSize = inputString.strContentSize;
        this->strSize = inputString.strSize;
        this->tab = new char[inputString.strSize];
        for (int i = 0; i < strContentSize; i++)
        {
            this->tab[i] = inputString.tab[i];
        }
    }
    CustomString(const char* stringChar)
    {
        this->tab = new char[defaultStringSize];
        this->strSize = defaultStringSize;
        tab[0] = '\0';
        strContentSize = 1;

        (*this) += stringChar;
    }
    void strResize(int newSize)
    {
        char* tmptab = new char[newSize];
        int smallerSize = 0;

        if (newSize > strSize)
        {
            smallerSize = strSize;
        }
        else
        {
            smallerSize = newSize;
        }

        for (int i = 0; i < smallerSize; i++)
        {
            tmptab[i] = tab[i];
        }

        if (strContentSize > newSize)
        {
            tmptab[newSize - 1] = '\0';
            this->strContentSize = newSize;
        }
        delete[] tab;
        this->tab = tmptab;
        tmptab = nullptr;
        this->strSize = newSize;
    }
    void operator+= (char z)
    {
        if (strSize <= strContentSize)
        {
            strResize(strSize * 2);
        }
        tab[strContentSize - 1] = z;
        tab[strContentSize] = '\0';
        strContentSize += 1;
    }
    void operator+= (const char* z)
    {
        int i = 0;
        while (z[i] != '\0')
        {
            (*this) += z[i];
            i++;
        }
    }
    bool operator== (CustomString& strR)
    {
        if (strcmp((*this).getString(), strR.getString()) == 0)
        {
            return true;
        }
        return false;
    }
    bool operator== (const char* strR)
    {
        if (strcmp((*this).getString(), strR) == 0)
        {
            return true;
        }
        return false;
    }
    bool isDigit()
    {
        for (int i = 0; i < (strContentSize - 1); i++)
        {
            if (!(tab[i] >= '0' && tab[i] <= '9'))
            {
                return false;
            }
        }
        return true;
    }
    void operator=(const CustomString& strR)
    {
        CustomString tmp = strR;
        if (this->tab != nullptr)
        {
            delete[] this->tab;
        }
        this->tab = tmp.tab;
        this->strContentSize = tmp.strContentSize;
        this->strSize = tmp.strSize;
        tmp.tab = nullptr;
        tmp.strSize = 0;
    }
    char* getString()
    {
        return tab;
    }
    ~CustomString()
    {
        if (tab != nullptr)
        {
            delete[] tab;
        }
    }
};


class AttributeData
{
public:
    CustomString Name;
    CustomString Value;
};

class AttributeListNode {
public:
    int dataSize = 0;
    AttributeData dataArray[ListArraySize];
    AttributeListNode* next = nullptr;
    void print()
    {
        for (int i = 0; i < dataSize; i++)
        {
            std::cout << dataArray[i].Name.getString() << ":" << dataArray[i].Value.getString() << "->";
        }
    }
};

class SelectorData
{
public:
    CustomString Name;
};

class SelectorListNode {
public:
    int dataSize = 0;
    SelectorData dataArray[ListArraySize];
    SelectorListNode* next = nullptr;
    void print()
    {
        for (int i = 0; i < dataSize; i++)
        {
            std::cout << dataArray[i].Name.getString() << "->";
        }
    }
};
template <typename ListNodeT, typename DataClassT>
class List {
    ListNodeT* HEAD = nullptr;
public:
    List()
    {

    }
    List(const List& inputList)
    {
        ListNodeT* tmpinput = inputList.HEAD;
        ListNodeT* tmpheadinside = nullptr;
        while (tmpinput != nullptr)
        {
            ListNodeT* tmp = new ListNodeT;
            tmp->dataSize = tmpinput->dataSize;
            for (int i = 0; i < tmp->dataSize; i++)
            {
                tmp->dataArray[i] = tmpinput->dataArray[i];
            }
            if (tmpheadinside == nullptr)
            {
                HEAD = tmp;
            }
            else
            {
                tmpheadinside->next = tmp;
            }
            tmpheadinside = tmp;
            tmpinput = tmpinput->next;
        }
    }

    void operator=(const List& listR)
    {
        List tmp = listR;

        ListNodeT* tmphead = HEAD;
        while (tmphead != nullptr)
        {
            ListNodeT* toBeDeleted = tmphead;
            tmphead = tmphead->next;
            delete toBeDeleted;
        }

        this->HEAD = tmp.HEAD;
        tmp.HEAD = nullptr;
    }

    void printList()
    {
        ListNodeT* tmp = HEAD;
        while (tmp != nullptr)
        {
            tmp->print();
            tmp = tmp->next;
        }
        std::cout << "NULLPTR\n";
    }
    int getListLen()
    {
        int length = 0;
        ListNodeT* tmp = HEAD;
        while (tmp != nullptr)
        {
            length += tmp->dataSize;
            tmp = tmp->next;
        }
        return length;
    }
    void deleteNthElement(int n) //numbered from 1
    {
        ListNodeT* beforeTmp = nullptr;
        ListNodeT* tmp = HEAD;
        int roughPosition = 0;
        while ((roughPosition + tmp->dataSize) < n)
        {
            roughPosition += tmp->dataSize;
            beforeTmp = tmp;
            tmp = tmp->next;
        }
        tmp->dataSize -= 1;
        if (tmp->dataSize == 0)
        {
            if (beforeTmp == nullptr)
            {
                HEAD = tmp->next;
                delete tmp;
            }
            else
            {
                beforeTmp->next = tmp->next;
                delete tmp;
            }
        }
        else
        {
            for (int i = n - roughPosition - 1; i < tmp->dataSize; i++)
            {
                tmp->dataArray[i] = tmp->dataArray[i + 1];
            }
        }

    }
    int findIndexByName(CustomString name)
    {
        int roughposition = 0;
        ListNodeT* currentNode = HEAD;
        while (currentNode != nullptr)
        {
            for (int i = 0; i < currentNode->dataSize; i++)
            {
                if (currentNode->dataArray[i].Name == name)
                {
                    return roughposition + i + 1;
                }
            }
            roughposition += currentNode->dataSize;
            currentNode = currentNode->next;
        }
        return -1;
    }
    DataClassT& getNthElement(int n) //numbered from 1
    {
        ListNodeT* tmp = HEAD;
        int roughPosition = 0;
        while ((roughPosition + tmp->dataSize) < n)
        {
            roughPosition += tmp->dataSize;
            tmp = tmp->next;
        }
        return tmp->dataArray[n - roughPosition - 1];
    }
    void addNewDataEnd(DataClassT data)
    {
        if (HEAD == nullptr)
        {
            HEAD = new ListNodeT;
        }

        ListNodeT* tmp = HEAD;
        while (tmp->next != nullptr)
        {
            tmp = tmp->next;
        }

        if (tmp->dataSize >= ListArraySize)
        {
            tmp->next = new ListNodeT;
            tmp = tmp->next;
        }
        tmp->dataArray[tmp->dataSize] = data;
        tmp->dataSize += 1;
    }
    ~List()
    {
        ListNodeT* tmp = HEAD;
        while (tmp != nullptr)
        {
            ListNodeT* toBeDeleted = tmp;
            tmp = tmp->next;
            delete toBeDeleted;
        }
    }
};

class SectionData
{
public:
    List<AttributeListNode, AttributeData> attributes;
    List<SelectorListNode, SelectorData> selectors;
};

class SectionListNode {
public:
    int dataSize = 0;
    SectionData dataArray[ListArraySize];
    SectionListNode* next = nullptr;
    SectionListNode* prev = nullptr;
    void print()
    {
        for (int i = 0; i < dataSize; i++)
        {
            std::cout << "[\n";
            dataArray[i].attributes.printList();
            dataArray[i].selectors.printList();
            std::cout << "]\n";
            std::cout << "|\nV\n";
        }
    }
};
//template <typename ListNodeT, typename DataClassT>
// Sekcja list to doubly linked list
class SekcjaList {
    SectionListNode* HEAD = nullptr;
    SectionListNode* TAIL = nullptr;
public:
    void printList()
    {
        SectionListNode* tmp = HEAD;
        while (tmp != nullptr)
        {
            tmp->print();
            tmp = tmp->next;
        }
        std::cout << "NULLPTR\n";
    }
    int getListLen()
    {
        int length = 0;
        SectionListNode* tmp = HEAD;
        while (tmp != nullptr)
        {
            length += tmp->dataSize;
            tmp = tmp->next;
        }
        return length;
    }
    void deleteNthElement(int n) //numbered from 1
    {
        SectionListNode* tmp = HEAD;
        int roughPosition = 0;
        while ((roughPosition + tmp->dataSize) < n)
        {
            roughPosition += tmp->dataSize;
            tmp = tmp->next;
        }
        tmp->dataSize -= 1;
        if (tmp->dataSize == 0)
        {
            if ((tmp->prev == nullptr) && (tmp->next == nullptr))
            {
                HEAD = nullptr;
                TAIL = nullptr;
                delete tmp;
            }
            else if (tmp->prev == nullptr)
            {
                HEAD = tmp->next;
                HEAD->prev = nullptr;
                delete tmp;
            }
            else if (tmp->next == nullptr)
            {
                TAIL = tmp->prev;
                TAIL->next = nullptr;
                delete tmp;
            }
            else
            {
                tmp->prev->next = tmp->next;
                tmp->next->prev = tmp->prev;
                delete tmp;
            }
        }
        else
        {
            for (int i = n - roughPosition - 1; i < tmp->dataSize; i++)
            {
                tmp->dataArray[i] = tmp->dataArray[i + 1];
            }
        }

    }
    SectionData& getNthElement(int n) //numbered from 1
    {
        SectionListNode* tmp = HEAD;
        int roughPosition = 0;
        while ((roughPosition + tmp->dataSize) < n)
        {
            roughPosition += tmp->dataSize;
            tmp = tmp->next;
        }
        return tmp->dataArray[n - roughPosition - 1];
    }

    void addNewDataEnd(SectionData data)
    {
        if (HEAD == nullptr)
        {
            HEAD = new SectionListNode;
            TAIL = HEAD;
        }

        SectionListNode* tmp = TAIL;
        if (tmp->dataSize >= ListArraySize)
        {
            tmp->next = new SectionListNode;
            tmp->next->prev = tmp;
            tmp = tmp->next;
            TAIL = tmp;
        }
        tmp->dataArray[tmp->dataSize] = data;
        tmp->dataSize += 1;
    }
    int returnAttributeCountByName(CustomString name)
    {
        int roughposition = 0;
        int count = 0;
        SectionListNode* currentNode = HEAD;
        while (currentNode != nullptr)
        {
            for (int i = 0; i < currentNode->dataSize; i++)
            {
                if (currentNode->dataArray[i].attributes.findIndexByName(name) != -1)
                {
                    count += 1;
                }
            }
            roughposition += currentNode->dataSize;
            currentNode = currentNode->next;
        }
        return count;
    }
    int returnSelectorCountByName(CustomString name)
    {
        int roughposition = 0;
        int count = 0;
        SectionListNode* currentNode = HEAD;
        while (currentNode != nullptr)
        {
            for (int i = 0; i < currentNode->dataSize; i++)
            {
                if (currentNode->dataArray[i].selectors.findIndexByName(name) != -1)
                {
                    count += 1;
                }
            }
            roughposition += currentNode->dataSize;
            currentNode = currentNode->next;
        }
        return count;
    }
    CustomString returnValueOfAttributeForSelector(CustomString nameOfSelector, CustomString nameOfAttribute)
    {
        SectionListNode* currentNode = TAIL;
        while (currentNode != nullptr)
        {
            for (int i = (currentNode->dataSize - 1); i >= 0; i--)
            {
                if (currentNode->dataArray[i].selectors.findIndexByName(nameOfSelector) != -1)
                {
                    int indexOfAttribute = currentNode->dataArray[i].attributes.findIndexByName(nameOfAttribute);
                    if (indexOfAttribute != -1)
                    {
                        return currentNode->dataArray[i].attributes.getNthElement(indexOfAttribute).Value;
                    }
                }
            }
            currentNode = currentNode->prev;
        }
        return "";
    }
    ~SekcjaList()
    {
        SectionListNode* tmp = HEAD;
        while (tmp != nullptr)
        {
            SectionListNode* toBeDeleted = tmp;
            tmp = tmp->next;
            delete toBeDeleted;
        }
    }
};

bool isWhitespace(char z)
{
    return std::isspace(z);
}

enum stanSzukania
{
    trybSelektory,
    trybAtrybuty,
    trybAtrybutyNazwa,
    trybAtrybutyWartosc
};

int main()
{
    SekcjaList listaSekcji;


    CustomString string;
    int inputchar = 0;
    do
    {
        inputchar = getchar();
        if (inputchar != '?' && !isWhitespace(inputchar))
        {
            List<SelectorListNode, SelectorData> listaSelektorow;
            List<AttributeListNode, AttributeData> listaAtrybutow;
            stanSzukania stan = trybSelektory;
            do
            {
                if (stan == trybSelektory)
                {

                    while (inputchar != '{')
                    {
                        while (isWhitespace(inputchar) || inputchar == ',')
                        {
                            inputchar = getchar();
                        }
                        CustomString string;
                        CustomString stringWithWhitespace;
                        while (inputchar != ',' && inputchar != '{')
                        {
                            stringWithWhitespace += (char)inputchar;
                            if (!isWhitespace(inputchar))
                            {
                                string = stringWithWhitespace;
                            }
                            inputchar = getchar();
                        }

                        SelectorData tmpData;
                        tmpData.Name = string;
                        listaSelektorow.addNewDataEnd(tmpData);
                    }
                    stan = trybAtrybuty;

                }
                inputchar = getchar();
                if (stan == trybAtrybuty)
                {
                    CustomString name;
                    CustomString value;
                    AttributeData tmpData;
                    if (inputchar == '}')
                    {
                        stan = trybSelektory;
                        SectionData tmp;
                        tmp.attributes = listaAtrybutow;
                        tmp.selectors = listaSelektorow;
                        listaSekcji.addNewDataEnd(tmp);
                    }
                    else if (!isWhitespace(inputchar) && inputchar != '{')
                    {
                        while (inputchar != ':')
                        {
                            name += (char)inputchar;
                            inputchar = getchar();
                        }

                        tmpData.Name = name;
                        int attributeNumber = listaAtrybutow.findIndexByName(name);
                        if (attributeNumber != -1)
                        {
                            listaAtrybutow.deleteNthElement(attributeNumber);
                        }
                        while (isWhitespace(inputchar) || inputchar == ':')
                        {
                            inputchar = getchar();
                        }
                        while (inputchar != ';')
                        {
                            value += (char)inputchar;
                            inputchar = getchar();
                        }

                        tmpData.Value = value;
                        listaAtrybutow.addNewDataEnd(tmpData);
                    }
                }

            } while (inputchar != '}');
        }
        else if (inputchar == '?')
        {
            while (inputchar == '?')
            {
                inputchar = getchar();
            }
            bool detectedEnd = false;
            while (!detectedEnd && inputchar != EOF)
            {

                int commandSize = 0;
                bool commandDetected = false;
                CustomString tmpCommand[3];

                while (isWhitespace(inputchar))
                {
                    inputchar = getchar();
                }
                while (inputchar != '\n' && inputchar != EOF)
                {
                    if (commandSize > 2)
                    {
                        inputchar = getchar();
                    }
                    else if (inputchar == ',')
                    {
                        inputchar = getchar();
                        commandSize += 1;
                    }
                    else
                    {
                        tmpCommand[commandSize] += (char)inputchar;
                        inputchar = getchar();
                        commandDetected = true;
                    }

                }
                if (tmpCommand[0] == "****")
                {
                    detectedEnd = true;
                }
                if (commandDetected == true && detectedEnd == false)
                {
                    if (commandSize == 0)
                    {
                        if (tmpCommand[0] == "?")
                        {
                            std::cout << "? == " << listaSekcji.getListLen() << '\n';
                        }
                    }
                    else if (commandSize == 1)
                    {

                    }
                    else if (commandSize == 2)
                    {
                        if (tmpCommand[0].isDigit())
                        {
                            if (tmpCommand[1] == "S")
                            {
                                if (tmpCommand[2] == "?")
                                {
                                    int searchNumber = atoi(tmpCommand[0].getString());
                                    if (searchNumber <= listaSekcji.getListLen())
                                    {
                                        std::cout << tmpCommand[0].getString() << ",S,? == " << listaSekcji.getNthElement(searchNumber).selectors.getListLen() << '\n';

                                    }
                                }
                            }
                            if (tmpCommand[1] == "S")
                            {
                                if (tmpCommand[2].isDigit())
                                {
                                    int searchNumber = atoi(tmpCommand[0].getString());
                                    int searchNumberSelector = atoi(tmpCommand[2].getString());
                                    if (searchNumber <= listaSekcji.getListLen())
                                    {
                                        SectionData& reference = listaSekcji.getNthElement(searchNumber);
                                        int selectorLen = reference.selectors.getListLen();
                                        if (searchNumberSelector <= selectorLen)
                                        {
                                            std::cout << tmpCommand[0].getString() << ",S," << tmpCommand[2].getString() << " == " << reference.selectors.getNthElement(searchNumberSelector).Name.getString() << '\n';
                                        }


                                    }
                                }
                            }
                            if (tmpCommand[1] == "A")
                            {
                                if (tmpCommand[2] == "?")
                                {
                                    int searchNumber = atoi(tmpCommand[0].getString());
                                    if (searchNumber <= listaSekcji.getListLen())
                                    {
                                        std::cout << tmpCommand[0].getString() << ",A,? == " << listaSekcji.getNthElement(searchNumber).attributes.getListLen() << '\n';

                                    }
                                }
                                else
                                {
                                    int searchNumber = atoi(tmpCommand[0].getString());
                                    if (searchNumber <= listaSekcji.getListLen())
                                    {
                                        SectionData& reference = listaSekcji.getNthElement(searchNumber);
                                        int index = reference.attributes.findIndexByName(tmpCommand[2]);
                                        if (index != -1)
                                        {
                                            std::cout << tmpCommand[0].getString() << ",A," << tmpCommand[2].getString() << " == " << reference.attributes.getNthElement(index).Value.getString() << '\n';
                                        }


                                    }
                                }
                            }
                            if (tmpCommand[1] == "D")
                            {
                                if (tmpCommand[2] == "*")
                                {
                                    int deleteNumber = atoi(tmpCommand[0].getString());
                                    if (deleteNumber <= listaSekcji.getListLen())
                                    {
                                        listaSekcji.deleteNthElement(atoi(tmpCommand[0].getString()));
                                        std::cout << tmpCommand[0].getString() << "," << tmpCommand[1].getString() << "," << tmpCommand[2].getString() << " == " << "deleted" << '\n';
                                    }

                                }
                                else
                                {
                                    int deleteSectionNumber = atoi(tmpCommand[0].getString());
                                    if (deleteSectionNumber <= listaSekcji.getListLen())
                                    {
                                        SectionData& tmpSectionReference = listaSekcji.getNthElement(deleteSectionNumber);
                                        int toBeDeleted = tmpSectionReference.attributes.findIndexByName(tmpCommand[2]);
                                        if (toBeDeleted != -1)
                                        {
                                            tmpSectionReference.attributes.deleteNthElement(toBeDeleted);
                                            if (tmpSectionReference.attributes.getListLen() == 0)
                                            {
                                                listaSekcji.deleteNthElement(deleteSectionNumber);
                                            }
                                            std::cout << tmpCommand[0].getString() << "," << tmpCommand[1].getString() << "," << tmpCommand[2].getString() << " == " << "deleted" << '\n';
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (tmpCommand[1] == "A")
                            {
                                if (tmpCommand[2] == "?")
                                {
                                    std::cout << tmpCommand[0].getString() << "," << tmpCommand[1].getString() << "," << tmpCommand[2].getString() << " == " << listaSekcji.returnAttributeCountByName(tmpCommand[0]) << '\n';
                                }
                            }
                            if (tmpCommand[1] == "S")
                            {
                                if (tmpCommand[2] == "?")
                                {
                                    std::cout << tmpCommand[0].getString() << "," << tmpCommand[1].getString() << "," << tmpCommand[2].getString() << " == " << listaSekcji.returnSelectorCountByName(tmpCommand[0]) << '\n';
                                }
                            }
                            if (tmpCommand[1] == "E")
                            {
                                CustomString tmp = listaSekcji.returnValueOfAttributeForSelector(tmpCommand[0], tmpCommand[2]);
                                if (!(tmp == ""))
                                {
                                    std::cout << tmpCommand[0].getString() << "," << tmpCommand[1].getString() << "," << tmpCommand[2].getString() << " == " << tmp.getString() << '\n';
                                }
                            }
                        }
                    }
                }

            }

        }
    } while (inputchar != EOF);
    return 0;
}
