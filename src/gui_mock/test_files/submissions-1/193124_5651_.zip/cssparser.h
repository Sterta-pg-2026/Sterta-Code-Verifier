#ifndef CSSPARSER_H
#define CSSPARSER_H

class String;
class Section;
class Sections;

class CSSParser {
private:
    Sections* sections;
    int dummy;
public:
    CSSParser(Sections* sections);
    virtual ~CSSParser();
    Section* parse(const String s);
    void echo(const String s);
};

#endif // CSSPARSER_H
