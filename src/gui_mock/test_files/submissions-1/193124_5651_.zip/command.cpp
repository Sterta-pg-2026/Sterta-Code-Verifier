#include <iostream>
#include <string.h>
#include "command.h"
#include "css.h"

/**
TODO: tokenizeCommand should use regex like below:
#include <regex.h>
            regex_t regex;
            regmatch_t groups[3];
            int result;
            #pragma diag_suppress 233
            result = regcomp(&regex, "\(.*\)\,\(.*\)\,\(.*\)", REG_EXTENDED);
            result = regexec (&regex, buff, 3, groups, 0);
            cout << buff << " -----reg: " << result << endl;
            for (int i = 0; i < 3; i++) {
                cout << "group " << groups[i].rm_so << " " << groups[i].rm_eo << endl;
            }
*/

bool tokenizeCommand(char* buff, char*& arg1, char*& arg2, char*& arg3) {
    buff[MAX_ARG_LEN] = 0;
    char empty[] = "";
    arg1 = arg2 = arg3 = buff;
    arg2 = strstr(arg1, ","); /// it should be strnstr with MAX_ARG_LEN
    if (arg2) {
        *arg2 = 0;
        arg2++;
        if (*arg2 != 'A' && *arg2 != 'D' && *arg2 != 'E' && *arg2 != 'S') {
            return false;
        }
        arg3 = strstr(arg2, ",");
        if (arg3) {
            *arg3 = 0;
            arg3++;
            return true;
        } else {
            arg3 = empty;
        }
    } else {
        arg2 = empty;
    }
    return false;
}

void tokenizeCommandTest() {
    char buff[0x100];
    strcpy(buff, "1,D,?");
    char *arg1, *arg2, *arg3;
    tokenizeCommand(buff, arg1, arg2, arg3);
    cout << arg1 << " / " << arg2 << " / " << arg3 << endl;
}

int isNaturalNonzeroInt(char argument[MAX_ARG_LEN]) {
    int len = strlen(argument);
    for (int i = 0; i < len; i++) {
        if ((char)argument[i] < 48 || (char)argument[i] > 57)
        return 0;
    }
    return atoi(argument);
}

int numberOfSectionAttributes(Sections *sections, int sectionNr) {
    Section* node = sections->get(--sectionNr);
    //cout << "check: " << sectionNr << " " << (node ? "ok" : "null") << endl;
    if (nullptr == node) {
        return -1;
    }
    return node->declarations.count();
}

bool valueOfPropertyInSection(Sections *sections, int sectionNr, char *property, char answer[MAX_ARG_LEN]) {
    answer[0] = 0;
    Section* node = sections->get(--sectionNr);
    if (node == nullptr) {
        return false;
    }
    for (int i = 0, cnt = node->declarations.count(); i < cnt; i++) {
        if (! strcmp(property, (node->declarations.get(i).getProperty()).getData())) {
            strncpy(answer, (node->declarations.get(i).getValue()).getData(), MAX_ARG_LEN);
            return true;
        }
    }
    return false;
}

int attributeOccurences(Sections *sections, char* property) {
    Sections::Forward iterator = sections->forward();
    int occurences = 0;
    for (Section* node = iterator.next(); node; node = iterator.next()) {
        for (int i = 0, cnt = node->declarations.count(); i < cnt; i++) {
            if (! strcmp(property, (node->declarations.get(i).getProperty()).getData())) {
                occurences++;
                break;
            }
        }
    }
    return occurences;
}

int numberOfSectionSelectors(Sections *sections, int sectionNr) {
    Section* node = sections->get(--sectionNr);
    if (node == nullptr) {
        return -1;
    }
    return node->selectors.count();
}

bool selectorOfSection(Sections *sections, int sectionNr, int selectorNr, char answer[MAX_ARG_LEN]) {
    answer[0] = 0;
    Section* node = sections->get(--sectionNr);
    if (node == nullptr) {
        return false;
    }
    String selector = node->selectors.get(--selectorNr);
    if (selector.getLength() == 0) {
        return false;
    }
    strncpy(answer, selector.getData(), MAX_ARG_LEN);
    return true;
}

int selectorOccurences(Sections *sections, char* selector) {
    Sections::Forward iterator = sections->forward();
    int occurences = 0;
    for (Section* node = iterator.next(); node; node = iterator.next()) {
        for (int i = 0, cnt = node->selectors.count(); i < cnt; i++) {
            //printf("%s\n", (node->selectors.get(j)).getData());
            if (! strcmp(selector, (node->selectors.get(i)).getData())) {
                occurences++;
                break;
            }
        }
    }
    return occurences;
}

bool removeSection(Sections *sections, int sectionNr) {
    //cout << "count: " << sections->count() << endl;
    return sections->remove(--sectionNr);
}

bool removeDeclarationBySectionAndName(Sections *sections, int sectionNr, char* property) {
    Section* node = sections->get(--sectionNr);
    if (node == nullptr) {
        return false;
    }
    if (node->declarations.erase(property)) {
        if (node->declarations.count() == 0) {
            sections->remove(sectionNr);
        }
        return true;
    }
    return false;
}

bool lastDeclarationBySectorAndName(Sections *sections, char *arg1, char* arg3, char answer[MAX_ARG_LEN]) {
    Sections::Backward iterator = sections->backward();
    Section* node = sections->tail();
    for (Section* node = iterator.prev(); node; node = iterator.prev()) {
        for (int i = 0, scnt = node->selectors.count(); i < scnt; i++) {
            //cout << "Data:" << node->selectors.getSelector(j) << endl;
            //printf("Data = %s\n", (node->selectors.getSelector(j)).getData());
            if (! strcmp(arg1, (node->selectors.get(i)).getData())) {
                //cout << "BINGO!!!"<<endl;
                for (int j = 0, dcnt = node->declarations.count(); j < dcnt; j++) {
                    if (! strcmp(arg3, (node->declarations.get(j).getProperty()).getData())) {
                        //cout << "SECOND BINGO!!!"<<endl;
                        strncpy(answer, (node->declarations.get(j).getValue()).getData(), MAX_ARG_LEN);
                        return true;
                    }

                }
            }
        }
    }
    return false;
}

/// ================================================================================

Command::Command(Sections *sections)
        : sections(sections) {
}

Command::~Command() {
}

void Command::dispatch(char *buff) {
    if (buff[0] == 0) {
        //cout << "command: empty!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        return;
    }
    //cout << "buffer: " << buff << endl;
    if (buff[0] == '?' && buff[1] == 0) {
        /// ? - count
        printf("? == %d\n", sections->count());
        return;
    }
    char *arg1, *arg2, *arg3;
    if (! tokenizeCommand(buff, arg1, arg2, arg3)) {
        //cout << "command: [[" << buff << "]] unrecognized!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        return;
    }
    int arg1Int = isNaturalNonzeroInt(arg1);
    int arg3Int = isNaturalNonzeroInt(arg3);
    //printf("command: %s=>%d,%c,%s=>%d\n", arg1, arg1Int, arg2[0], arg3, arg3Int);
    switch (arg2[0]) {
        case 'A':{
            if (arg1Int && arg3[0] == '?') {
                /// i,A,? - wypisz liczbę atrybutów dla sekcji nr i, jeśli nie ma takiego bloku lub sekcji pomiń;
                int attributesCount = numberOfSectionAttributes(sections, arg1Int);
                if (-1 != attributesCount) {
                    printf("%s,A,? == %d\n", arg1, attributesCount);
                }
                //numberOfIthSectionAttributes(arg1Int);
            } else if (arg3[0] == '?') {
                /// n,A,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n. (W ramach pojedynczego bloku duplikaty powinny zostać usunięte na etapie wczytywania). Możliwe jest 0;
                //printf("n,A,?\n");
                printf("%s,A,? == %d\n", arg1, attributeOccurences(sections, arg1));
            } else {
                /// i,A,n – wypisz dla i-tej sekcji wartość atrybutu o nazwie n, jeśli nie ma takiego pomiń;
                char answer[MAX_ARG_LEN];
                if (valueOfPropertyInSection(sections, arg1Int, arg3, answer)) {
                    printf("%d,A,%s == %s\n", arg1Int, arg3, answer);
                }
            }
            break;
        }
        case 'S':{
            if (arg1Int && arg3[0] == '?') {
                /// i,S,? – wypisz liczbę selektorów dla sekcji nr i (numery zaczynają się od 1), jeśli nie ma takiego bloku pomiń;
                int selectorsCount = numberOfSectionSelectors(sections, arg1Int);
                if (-1 != selectorsCount) {
                    printf("%d,S,? == %d\n", arg1Int, selectorsCount);
                }
            } else if (arg1Int && arg3Int) {
                /// i,S,j – wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutów zaczynają się od 1) jeśli nie ma sekcji lub selektora pomiń;
                char answer[MAX_ARG_LEN];
                if (selectorOfSection(sections, arg1Int, arg3Int, answer)) {
                    printf("%d,S,%d == %s\n", arg1Int, arg3Int, answer);
                }
            } else if (arg3[0] == '?') {
                /// z,S,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień selektora z. Możliwe jest 0; WORKS IN ALL CASES
                printf("%s,S,? == %d\n", arg1, selectorOccurences(sections, arg1));
            }
            break;
        }
        case 'D':{
            if (arg3[0] == '*') {
                /// i,D,* - usuń całą sekcję nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted;
                if (removeSection(sections, arg1Int)) {
                    printf("%d,D,* == deleted\n", arg1Int);
                }
            } else {
                /// i,D,n – usuń z i-tej sekcji atrybut o nazwie n, jeśli w wyniku operacji pozostaje pusta sekcja powinna zostać również usunięta (wraz z ew. selektorami), po poprawnym wykonaniu wypisz deleted.
                if (removeDeclarationBySectionAndName(sections, arg1Int, arg3)) {
                    printf("%d,D,%s == deleted\n", arg1Int, arg3);
                }
            }
            break;
        }
        case 'E':{
            /// z,E,n – wypisz wartość atrybutu o nazwie n dla selektora z, w przypadku wielu wystąpień selektora z bierzemy ostatnie. W przypadku braku pomiń;
            char answer[MAX_ARG_LEN];
            if (lastDeclarationBySectorAndName(sections, arg1, arg3, answer)) {
                printf("%s,E,%s == %s\n", arg1, arg3, answer);
            }
            break;
        }
        default:{
            break;
        }
    }
}

