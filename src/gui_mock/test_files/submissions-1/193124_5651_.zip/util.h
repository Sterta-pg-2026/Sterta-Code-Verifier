#ifndef UTIL_H
#define UTIL_H

bool endsWith(const char* text, const int textlen, const char* ending);
int rtrim(char* buff, int last);
void endsWithTest();

#endif
