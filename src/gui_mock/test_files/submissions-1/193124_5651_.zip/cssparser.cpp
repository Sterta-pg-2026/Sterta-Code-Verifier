#include "cssparser.h"
#include "css.h"
#include "string.h"

CSSParser::CSSParser(Sections* sections)
        : sections(sections) {
    dummy = 0;
}

CSSParser::~CSSParser() {
}

Section* CSSParser::parse(const String css) {
    Section* node = nullptr;
    int len = css.getLength();
    int last = 0;
    bool inComment = false;
    bool inDeclaration = false;
    String selector;
    String property;
    String value;
    //cout << len << endl;
    for (int curr = 0; curr < len; curr++) {
        char c = css[curr];
        switch (c) {
            case '/': {
                if (!inComment) {
                    if (curr < (len-1) && '*' == css[curr+1]) {
                        inComment = true;
                        last = curr + 1;
                    }
                } else {
                    if(curr > 0 && '*' == css[curr-1]) {
                        inComment = false;
                        last = curr + 1;
                    }
                }
                break;
            }
            case ',': {
                if (!inComment && !inDeclaration) {
                    if (! node) {
                        //cout << "append!" << endl;
                        node = sections->append();
                    }
                    selector = String(css, last, curr-last).trim();
                    //cout << selector << endl;
                    node->selectors.add(selector);
                    last = curr + 1;
                }
                break;
            }
            case '{': {
                if (!inComment) {
                    if (! node) {
                        node = sections->append();
                        //cout << "append!" << endl;
                    }
                    selector = String(css, last, curr-last).trim();
                    //cout << selector << endl;
                    node->selectors.add(selector);
                    //cout << selector << " {" << endl;
                    last = curr + 1;
                }
                inDeclaration = true;
                break;
            }
            case ':': {
                if (inDeclaration) {
                    property = String(css, last, curr-last).trim();
                    last = curr + 1;
                }
                break;
            }
            case ';': {
                if (inDeclaration) {
                    value = String(css, last, curr - last).trim();
                    node->declarations.add(property, value);
                    //cout << "\t" << property << " : " << value << ";" << endl;
                }
                last = curr + 1;
                break;
            }
            case '}': {
                //dummy++;
                //cout << "}" << endl;
                last = curr + 1;
                inDeclaration = false;
                node = nullptr;
                break;
            }
            default: ;
        }
    }
    //cout << "dummy-p: " << dummy << endl;
    return node;
}


void CSSParser::echo(const String css) {
    int len = css.getLength();
    int last = 0;
    bool inComment = false;
    bool inDeclaration = false;
    String selector;
    String property;
    String value;
    for (int curr = 0; curr < len; curr++) {
        char c = css[curr];
        switch (c) {
        /*
            case '/': {
                if (!inComment) {
                    if (curr < (len-1) && '*' == s[curr+1]) {
                        inComment = true;
                        last = curr + 1;
                    }
                } else {
                    if(curr > 0 && '*' == s[curr-1]) {
                        inComment = false;
                        last = curr + 1;
                    }
                }
                break;
            }
        */
            /*)
            case ',': {
                //last = curr;
                break;
            }*/
            case '{': {
                if (!inComment) {
                    selector = String(css, last, curr-last);
                    cout << selector << " {" << endl;
                    last = curr + 1;
                }
                inDeclaration = true;
                break;
            }
            case ':': {
                if (inDeclaration) {
                    property = String(css, last, curr-last);
                    last = curr + 1;
                }
                break;
            }
            case ';': {
                if (inDeclaration) {
                    value = String(css, last, curr - last);
                    cout << "\t" << property << " : " << value << ";" << endl;
                    last = curr + 1;
                }
                break;
            }
            case '}': {
                cout << "}" << endl;
                last = curr + 1;
                inDeclaration = false;
                break;
            }
            default: ;
        }
    }
}
