#include "string.h"

// https://stackoverflow.com/questions/5368258/the-copy-constructor-and-assignment-operator

String::String() {
    this->data = nullptr;
    this->length = 0;
}

String::String(const int len, const char fil) {
    this->data = (char *) malloc ((len + 1) * sizeof(char));
    this->length = len;
    for (int i = 0; i < len; i++) {
        data[i] = fil;
    }
    data[len] = 0;
}

String::String(const int val)
        : String(0x16, 0) {
    sprintf(data, "%d", val);
}

String::String(const char *val)
        : String(strnlen(val, MAX_STRING_LENGTH +1), 0) {
    strncpy(this->data, val, this->length);
    this->data[this->length] = 0;
}

String::String(const char *val, int pos, int len)
        : String(len +1, 0) {
    strncpy(this->data, val+pos, len);
    this->data[len] = 0;
    this->length = strnlen(this->data, MAX_STRING_LENGTH);
}

String::~String() {
    free(this->data);
}

String::String(const String& other)
        : String(other.getLength(), 0) {
//        : data{new char[other.getLength() + 1]}, length{other.getLength()} {
//    cout << "copy constructor" << endl;
    for (int i = 0; i < length; i++) {
        data[i] = other.data[i];
    }
}

String::String(const String& other, const String& added)
        : String(other.getLength() + added.getLength(), 0) {
        //: data{new char[other.getLength() + added.getLength() + 1]} , length{other.getLength() + other.getLength()} {
    int i = 0;
//    cout << "String(String, String): ";
    for (int len = other.getLength(); i < len; i++) {
        data[i] = other.data[i];
//        cout << other.data[i];
    }
    for (int j = 0, len = added.getLength(); j < len; i++, j++) {
        data[i] = added.data[j];
//        cout <<  added.data[j];
    }
//    cout << endl;
    data[length] = 0;
}


String::String(const String& other, int pos, int len)
        : String(other.getData(), pos, len) {
}

String& String::operator=(const String& right) {
    String tmp = right;
    std::swap(data, tmp.data);
    std::swap(length, tmp.length);
    return *this;
}

String& String::operator+(const String& right) {
    String tmp(*this, right);
    std::swap(data, tmp.data);
    std::swap(length, tmp.length);
    return *this;
}

String& String::operator+=(const String& right) {
    String tmp(*this, right);
    std::swap(data, tmp.data);
    std::swap(length, tmp.length);
    return *this;
}

String& String::strip() {
    String tmp(length, 0);
    int j = 0;
    for (int i = 0; i < length; i++) {
        if (isprint(data[i]) && data[i] != ' ' && data[i] != '\t') {
            tmp.data[j++] = data[i];
        }
    }
    tmp.data[j] = 0;
    std::swap(data, tmp.data);
    std::swap(length, tmp.length);
    return *this;
}

String& String::trim() {
    String tmp(length, 0);
    int b = -1;
    int e = -1;
    for (int i = 0; i < length; i++) {
        if (isprint(data[i]) && data[i] != ' ' && data[i] != '\t' && b == -1) {
            b = i;
            break;
        }
    }
    for (int i = length -1; i >= 0; i--) {
        if (isprint(data[i]) && data[i] != ' ' && data[i] != '\t' && e == -1) {
            e = i + 1;
            break;
        }
    }
    if (b == -1) b = 0;
    if (e == -1) e = length;
    int j = 0;
    for (int i = b; i < e; i++) {
        tmp.data[j++] = data[i];
    }
    tmp.data[j] = 0;
    std::swap(data, tmp.data);
    std::swap(length, tmp.length);
    return *this;
}

int String::isBlank() const {
    for (int i = 0; i < length; i++) {
        if (isprint(data[i]) && data[i] != ' ' && data[i] != '\t') {
            return false;
        }
    }
    return true;
}

int String::compare(const String& other) const {
    return strcmp(this->getData(), other.getData());
}

ostream& operator<<(ostream& os, String const& str) {
    return os << str.data;
}

char* String::getData() const {
    return this->data;
}

int String::getLength() const {
    return this->length;
}

char String::operator[](const int pos) const {
    return this->data[pos];
}

void String::dump() {
    cout << "String:: data: \"" << data << "\", length: " << length << endl;
}
