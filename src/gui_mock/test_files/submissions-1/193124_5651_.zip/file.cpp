#include "file.h"
#include "string.h"
#include <stdio.h>

File::File() {
}

File::~File() {
}

String File::readAsString(const String file) {
        #define MAX_FILE_SIZE 0x100000
        char buff[MAX_FILE_SIZE];
        buff[0] = 0;
        size_t read = 0;
        FILE *f = fopen(file.getData(), "r");
        if (f) {
            read = fread(buff, 1, MAX_FILE_SIZE, f);
            fclose(f);
        }
        return String(buff, 0, read);
}
