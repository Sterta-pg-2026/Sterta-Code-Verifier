#ifndef FILE_H
#define FILE_H

class String;

class File {
public:
    File();
    virtual ~File();
    static String readAsString(const String file);
protected:
private:
};

#endif // FILE_H
