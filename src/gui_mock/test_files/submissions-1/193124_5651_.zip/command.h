#ifndef COMMAND_H
#define COMMAND_H

#define MAX_ARG_LEN 100

class Sections;

class Command {
    Sections *sections;
public:
    Command(Sections *sections);
    virtual ~Command();
    void dispatch(char *buff);
protected:

private:
};

#endif
