#include "util.h"
#include "string.h"
#include <assert.h>

bool endsWith(const char* text, const int textlen, const char* ending) {
    int endinglen = strlen(ending);
    if (textlen <= 1 || endinglen > textlen) {
        return false;
    }
    //return ! strcmp(text + textlen - endinglen, ending); /// strcmp do not work well with "\n"
    for (int i=textlen-1, j=strlen(ending)-1; i >=0 && j>=0; i--, j--) {
        if (text[i] != ending[j]) {
            return false;
        }
    }
    return true;
}

bool isWhite(char c) {
    return (c == '\r' || c == '\n' || c == ' ' || c == '\t' || c == -1);
}

int rtrim(char* buff, int last) {
    for (; last >=0 && isWhite(buff[last-1]) ; last--) {
        buff[last-1] = 0;
    }
    return last;
}

void endsWithTest() {
    //assert(endsWith("1234567890", 0, "90"));
    assert(endsWith("1234567890", 10, "90"));
    assert(endsWith("????", 4, "????"));
    assert(! endsWith("?", 1, "????"));
    assert(endsWith("\n?\n", 3, "\n?\n"));
    assert(! endsWith("????", 4, "\n?\n"));
    assert(! endsWith("1234567890", 10, "9"));
    assert(! endsWith("1234567890", 11, "90"));
}
