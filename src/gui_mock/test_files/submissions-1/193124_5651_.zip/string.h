#ifndef STRING_H
#define STRING_H
#include <cstring>
#include <iostream>
using namespace std;

#define MAX_STRING_LENGTH 0x1000

class String {
private:
    char* data;
    int length;
    String(const int len, const char fil);
public:
    String();
    String(const int val);
    String(const char *val);
    String(const char *val, int pos, int len);
    String(const String& other, int pos, int len);
    String(const String& other);
    String(const String& other, const String& added);
    String& operator=(const String& right);
    String& operator+(const String& right);
    String& operator+=(const String& right);
    char operator[](const int pos) const;
    virtual ~String();
    char* getData() const;
    int getLength() const;
    int isBlank() const;
    int compare(const String& other) const;
    String& strip();
    String& trim();
    void dump();
    friend ostream& operator<<(ostream& os, String const& str);
};



#endif // STRING_H
