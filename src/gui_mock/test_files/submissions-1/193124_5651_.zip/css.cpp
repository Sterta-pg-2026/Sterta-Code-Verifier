#include "css.h"

/// ================================================================================

Selectors::Selectors()
        : head(nullptr) {
}
Selectors::~Selectors() {
    delete head;
}

Selectors& Selectors::add(const String &selector) {
    Node* node;
    if (head == nullptr) {
        node = head = new Node();
    } else {
        node = head;
        for (; node->next; node = node->next) {
        }
        node = node->next = new Node();
    }
    node->item = selector;
    return *this;
}

int Selectors::count() {
    int count = 0;
    for (Node* node = head; node; node = node->next) {
        count += node->count();
    }
    return count;
}

String Selectors::get(int n) {
    String empty("");
    //cout<<"Selector::getSelector: " <<n<<endl;
    for (Node* node = head; node && n >=0; node = node->next) {
        if (node->count()) {
            if (n == 0) {
                return node->item;
            }
            n--;
        }
    }
    return empty;
}

String Selectors::toString() {
    String buff = "";
    String sep = "";
    for (int i = 0, cnt = count(); i < cnt; i++) {
        String s = sep + get(i);
        buff += s;
        sep = ", ";
    }
    return buff;
}

Selectors::Node::Node()
        : next(nullptr) {
}

Selectors::Node::~Node() {
    if (next) {
        delete next;
        next = nullptr;
    }
}

int Selectors::Node::count() {
    return item.isBlank() ? 0 : 1;
}

/// ================================================================================

Declaration::Declaration() {
}

Declaration::Declaration(const String &property, const String &value) : Declaration() {
    this->property = property;
    this->value = value;
}

Declaration::Declaration(const Declaration& other)
        : value(other.value), property(other.property) {
}

Declaration& Declaration::operator=(const Declaration& right) {
    Declaration tmp = right;
    std::swap(property, tmp.property);
    std::swap(value, tmp.value);
    return *this;
}

ostream& operator<<(ostream& os, Declaration const& declaration) {
    return os << declaration.property << ": "<< declaration.value << ";" ;
}

String& Declaration::getProperty() {
    return this->property;
}

String& Declaration::getValue() {
    return this->value;
}

Declaration& Declaration::setValue(const String& value) {
    this->value = value;
    return *this;
}

String Declaration::toString() {
    return property + " : " + value;
}

void Declaration::erase() {
    property = "";
    value = "";
}

bool Declaration::isBlank() const {
    return property.isBlank();
}

/// ================================================================================

Declarations::Declarations()
        : head(nullptr), empty(Declaration("", "")) {
}

Declarations::~Declarations() {
    delete head;
}

Declarations& Declarations::add(const String& property, const String& value) {
    Declaration& declaration = find(property);
    if (! declaration.isBlank()) {
        declaration.setValue(value);
    } else {
        Node* node;
        if (head == nullptr) {
            node = head = new Node();
        } else {
            node = head;
            for (; node->next; node = node->next) {
            }
            node = node->next = new Node();
        }
        node->item = Declaration(property, value);
    }
    return *this;
}

int Declarations::count() {
    int count = 0;
    for (Node* node = head; node; node = node->next) {
        count += node->count();
    }
    return count;
}

Declaration Declarations::get(int n) {
    for (Node* node = head; node && n >=0; node = node->next) {
        if (node->count()) {
            if (n == 0) {
                return node->item;
            }
            n--;
        }
    }
    return empty;
}

Declaration& Declarations::find(const String &property) {
    for (Node* node = head; node; node = node->next) {
        if (! node->item.getProperty().isBlank() && ! node->item.getProperty().compare(property)) {
           return node->item;
        }
    }
    return empty;
}

bool Declarations::erase(const String &property) {
    Declaration& declaration = find(property);
    if (! declaration.isBlank()) {
        declaration.erase();
        return true;
    }
    return false;
}

String Declarations::toString() {
    String buff = "{\n";
    String sep = "";
    for (int i = 0, cnt = count(); i < cnt; i++) {
        String s = sep + "\t" + get(i).toString();
        buff += s;
        sep = ";\n";
    }
    buff += "\n}";
    return buff;
}

Declarations::Node::Node()
        : next(nullptr) {
}

Declarations::Node::~Node() {
    if (next) {
        delete next;
        next = nullptr;
    }
}

int Declarations::Node::count() {
    return item.isBlank() ? 0 : 1;
}

/// ================================================================================

Section::Section() {
    pprev = nullptr;
    pnext = nullptr;
}

Section* Section::create() {
    return new Section();
}

void Section::destroy() {
    Section* last = this;
    while (last->pnext) {
        last = last->pnext;
    }
    while (last) {
        Section* curr = last;
        last = last->pprev;
        delete curr;
    }
}
/*
Section* Section::append() {
    Section* curr = new Section();
    this->pnext = curr;
    curr->pprev = this;
    return curr;
}

void Section::remove() {
    if (pprev && pnext) {
        pnext->pprev = pprev;
        pprev->pnext = pnext;
    } else if (pprev) {
        pprev->pnext = nullptr;
        // head = !!!!!!
    } else if (pnext) {
        pnext->pprev = nullptr;
    }
    delete this;
}
*/

Section* Section::next() {
    return pnext;
}

Section* Section::prev() {
    return pprev;
}

String Section::toString() {
    return selectors.toString() + " " + declarations.toString();
}

/// ================================================================================

Block::Block() {
    pprev = nullptr;
    pnext = nullptr;
    //list[8] = new Section();
    //cout << "AAAAAAAAAAAAAAAAAAAAAAAAAAAaaa" << endl;
}

Block* Block::create() {
    return new Block();
}

void Block::destroy() {
    Block* last = this;
    while (last->pnext) {
        last = last->pnext;
    }
    while (last) {
        Block* curr = last;
        last = last->pprev;
        delete curr;
    }
}

Block* Block::next() {
    return pnext;
}

Block* Block::prev() {
    return pprev;
}

/// ================================================================================

Sections::Sections() {
    phead = nullptr;
    ptail = nullptr;
    //Block block;
    //block.next();

}

Sections::~Sections() {
    Section* prev = tail();
    while(prev) {
        Section* curr = prev;
        prev = prev->prev();
        delete curr;
    }
}

Section* Sections::head() {
    return phead;
}

Section* Sections::tail() {
    return ptail;
}

Section* Sections::append() {
    Section* curr = Section::create();
    if (nullptr == phead) {
        phead = curr;
        ptail = curr;
    } else {
        curr->pprev = ptail;
        ptail->pnext = curr;
        ptail = curr;
    }
    return curr;
}

int Sections::count() {
    Section* curr = head();
    int cnt = 0;
    for (;curr; cnt++) {
        curr = curr->next();
    }
    return cnt;
}

Section* Sections::get(int n) {
    Section* curr = head();
    for (int i = 0; curr && i < n; i++) {
        curr = curr->next();
    }
    return curr;
}

bool Sections::remove(int n) {
    Section* curr = get(n);
    if (curr) {
        if (phead == curr && ptail == curr) {
            phead = nullptr;
            ptail = nullptr;
        } else if (phead == curr) {
            phead = curr->next();
        } else if (ptail == curr) {
            ptail = curr->prev();
        }
        if (curr->pprev) {
            curr->pprev->pnext = curr->next();
        }
        if (curr->pnext) {
            curr->pnext->pprev = curr->prev();
        }
        delete curr;
        return true;
    }
    return false;
}

Sections::Forward Sections::forward() {
    Forward forward;
    forward.node = phead;
    return forward;
}

Sections::Backward Sections::backward() {
    Backward backward;
    backward.node = ptail;
    return backward;
}

Section* Sections::Forward::next() {
    Section* curr = node;
    node = (node) ? node->next() : nullptr;
    return curr;
}

Section* Sections::Backward::prev() {
    Section* curr = node;
    node = (node) ? node->prev() : nullptr;
    return curr;
}
