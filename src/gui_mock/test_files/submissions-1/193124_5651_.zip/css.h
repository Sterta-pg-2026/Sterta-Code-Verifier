#ifndef CSS_H
#define CSS_H
#include "string.h"

#define MAX_SECTION_ARRAY 13

class String;
class Section;

//  ================================================================================

class Selectors {
protected:
    struct Node {
        String item;
        Node* next;
        Node();
        ~Node();
        int count();
    };
    Node* head;
public:
    Selectors();
    virtual ~Selectors();
    Selectors& add(const String &selector);
    friend Section;
    String toString();
    int count();
    String get(int n);
};

//  ================================================================================

class Declaration {
private:
    String property;
    String value;
    bool blank;
public:
    Declaration();
    Declaration(const String &property, const String &value);
    Declaration(const Declaration& other);
    Declaration& operator=(const Declaration& right);
    friend ostream& operator<<(ostream& os, Declaration const& declaration);
    String& getProperty();
    String& getValue();
    Declaration& setValue(const String& value);
    void erase();
    bool isBlank() const;
    String toString();
};

//  ================================================================================

class Declarations {
friend Section;
protected:
    struct Node {
        Declaration item;
        Node* next;
        Node();
        ~Node();
        int count();
    };
    Node* head;
    Declaration empty;
public:
    Declarations();
    virtual ~Declarations();
    int count();
    Declarations& add(const String &property, const String &value);
    Declaration get(int n);
    Declaration& find(const String &property);
    bool erase(const String &property);
    String toString();
};

//  ================================================================================
class Sections;

class Section {
friend Sections;
private:
    Section* pprev;
    Section* pnext;
//    Section* append();
    struct Item {
        Selectors selectors;
        Declarations declarations;
    };
    Item item[MAX_SECTION_ARRAY];
public:
    Selectors selectors;
    Declarations declarations;
private:
public:
    Section();
//    Selectors& getSelectors() const;
    static Section* create();
    void destroy();
    //void remove();
    Section* next();
    Section* prev();
//    Section& append(Section& added);
    String toString();

};

//  ================================================================================

class Block {
friend Sections;
private:
    Block* pprev;
    Block* pnext;
    Section* list[MAX_SECTION_ARRAY];
private:
    Block();
public:
    static Block* create();
    void destroy();
    Block* next();
    Block* prev();
};

//  ================================================================================

class Sections {
private:
    Section* phead;
    Section* ptail;
    Block* bhead;
    Block* btail;
public:
    struct Forward {
        Section* node;
        Section* next();
    };
    struct Backward {
        Section* node;
        Section* prev();
    };
public:
    Sections();
    virtual ~Sections();
    Section* head();
    Section* tail();
    Section* append();
    int count();
    Section* get(int n);
    bool remove(int n);
    Forward forward();
    Backward backward();
};

#endif // CSS_H
