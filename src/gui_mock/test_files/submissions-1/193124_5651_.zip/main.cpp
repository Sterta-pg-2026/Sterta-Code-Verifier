#include <iostream>
#include "css.h"
#include "cssparser.h"
#include "command.h"
#include "util.h"


using namespace std;

#define READ_BUFFER_SIZE 0x1000

/// ================================================================================

int main() {

    Sections sections;
    CSSParser parser(&sections);
    Command command(&sections);
    char buff[READ_BUFFER_SIZE];
    int last = 0;
    bool inCommand = false;
    int lineNr = 0;
    int c = ' ';
    while(-1 != c) {
        buff[last++] = c = fgetc(stdin);
        if (buff[last-1] == '\n') {
            lineNr++;
        }
        if (c != '\n' && c != '\r' && c != '}' && c != -1) {
            continue; // accumulate line
        }
        //cout << "parsing ####[[" << buff << "]]####" << endl << endl;
        if (last) buff[last] = 0;
        last = rtrim(buff, last);
        if (endsWith(buff, last, "}")) {
            //cout << "line: " << lineNr << endl;
            //cout << "parsing ####[[" << buff << "]]####" << endl << endl;
            /// if there is not section parsed, parse() should signalize it somehow to avoid having empty node
            parser.parse(String(buff));
        } else if (endsWith(buff, last, "????")) {
            inCommand = true;
            //cout << "command: on !!!" << endl;
        } else if (endsWith(buff, last, "****")) {
            inCommand = false;
            //cout << "command: off !!!" << endl;
        } else if (inCommand) {
            //if (buff[0] != 0) cout << "line: " << lineNr << endl;
            //cout << "dispatch: [[" << buff << "]]    ####[[" << endl;
            command.dispatch(buff);
            //cout << buff << "]]#### :dispatch" << endl;
        } else {
            continue; /// more to acumulate in the buff
        }
        last = 0;
        buff[last] = 0;
    }
    return 0;
}
