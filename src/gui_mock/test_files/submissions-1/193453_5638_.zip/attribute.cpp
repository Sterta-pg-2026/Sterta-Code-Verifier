#include<iostream>
#include "attribute.h"
using namespace std;

Attribute::Attribute()
	:key{ "wartownik" }, value{ "wartownik" }, next{ this }, previous{ this }
{

}
Attribute::Attribute(Attribute& copy)
	:key{ copy.key }, value{ copy.value }, next{ copy.next }, previous{ copy.previous }
{

}

Attribute::Attribute(ownString key, ownString value)
	:key{ key }, value{ value }, next{ this }, previous{ this }
{

}
Attribute::Attribute(const char* key, const char* value)
	:key{ key }, value{ value }, next{ this }, previous{ this }
{

}



