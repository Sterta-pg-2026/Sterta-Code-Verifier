#pragma once
#pragma once
#pragma once
#include <iostream>
#include "selector.h"

class SelectorList
{
	Selector* element;
	Selector* sentry;
	friend class ownString;
	friend class sectionNode;
	friend class blockList;
	friend class blockNode;
	int counter;
public:
	SelectorList();
	SelectorList(const SelectorList&);
	~SelectorList();
	void pushBack(const char*);
	void pushBack(Selector*);
	void pushBack(ownString&);
	void showElements();
	int countSelectors();
	bool find(Selector*);
	bool find(ownString&);
	void removeWhiteSpaces();
	Selector* getElement(int);
	bool deleteSelector(int);
};

