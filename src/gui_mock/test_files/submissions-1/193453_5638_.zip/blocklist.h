#pragma once
#include "blocknode.h"
class BlockList {

	blockNode* sentry;

public:

	BlockList();
	~BlockList();
	void addNewBlock();
	bool deleteBlock(blockNode*);
	void pushBack(sectionNode*);
	sectionNode* getSection(int index);
	int countElements();
	ownString chooseSelector(int, int);
	int countSelectorForSection(int sectionIndex);
	int countTag(ownString);
	bool isEmpty();
	int countAttributesForSection(int index);
	ownString findAndTakeValueFromSection(int sectionIndex, ownString key);
	int countAllKeys(ownString key);
	ownString findAtribbuteInSelectorFromEnd(ownString selectorName, ownString attributeKey);
	bool deleteSection(int);
	bool deleteAttributeFromSection(int sectionIndex, ownString attributeName);
	void showElements();
};