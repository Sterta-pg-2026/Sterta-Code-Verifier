#include "selectorlist.h"
#include <iostream>
using namespace std;
SelectorList::SelectorList():element { nullptr }, sentry(element),counter(0)
{
    
}

SelectorList::SelectorList(const SelectorList& attributesList)
{
    this->element = attributesList.element;
    this->sentry = attributesList.sentry;
    this->counter = attributesList.counter;
}

SelectorList::~SelectorList()
{
  
    while (deleteSelector(1));
    
   
}

void SelectorList::pushBack(const char* selector)
{
    Selector* newElement = new  Selector(selector);
    newElement->next = element;
    newElement->previous = element->previous;
    element->previous->next = newElement;
    element->previous = newElement;
    counter++;
    if (element->next == element)
    {
        element->next = newElement;
    }
}
void SelectorList::pushBack(Selector* newSelector)
{
    Selector* newElement = newSelector;
    newElement->next = element;
    newElement->previous = element->previous;
    element->previous->next = newElement;
    element->previous = newElement;
    counter++;
    if (element->next == element)
    {
        element->next = newElement;
    }
}

void SelectorList::pushBack(ownString& selector)
{
    Selector* newElement = new  Selector(selector);

    if (element == nullptr)
    {

        element = newElement;
        element->next = element;
        element->previous = element;
        sentry = element;
        counter++;
    }
    else {
        newElement->next = element;
        newElement->previous = element->previous;
        element->previous->next = newElement;
        element->previous = newElement;
        counter++;
        if (element->next == element)
        {
            element->next = newElement;
        }
    }
}

void SelectorList::showElements()
{

    Selector* temp = element;
        do
        {
            cout << "{" << temp->selectorValue << "} ";
            temp = temp->next;
        } while (temp != sentry);
        cout << endl;

}

int SelectorList::countSelectors()
{
    return counter;
    /*if (element == nullptr)
        return 0;
    Selector* temp = element;
 
    int numOfElements = 0;
    do
    {
        numOfElements++;
        temp = temp->next;
    } while (temp != sentry);

    temp = nullptr;
    delete temp;
    return numOfElements;*/
}

bool SelectorList::find(Selector* looking)
{
    Selector* temp = element;

    do
    {
        if (temp->selectorValue == looking->selectorValue)
        {
            return true;
        }
        temp = temp->next;
    } while (temp != sentry);

    return false;
}

bool SelectorList::find(ownString& looking)
{
    if (element == nullptr)
    {
        return false;
    }
    Selector* temp = element;
    if (temp == nullptr)
    {
        return -1;
    }

    do
    {
        if (temp->selectorValue == looking)
        {
            return true;
        }
        temp = temp->next;
    } while (temp != sentry);

    return false;
}

void SelectorList::removeWhiteSpaces()
{

    Selector* temp = element;
    do
    {
        while (temp->selectorValue[0] <= ' ') {
            temp->selectorValue.erase(0, 1);
        }

        while (temp->selectorValue[temp->selectorValue.length()-1] <= ' ' or 
            temp->selectorValue[temp->selectorValue.length() - 1] == '}') {
            temp->selectorValue.erase(temp->selectorValue.length() - 1, 1);
        }
       
        temp = temp->next;
    }
    while (temp != sentry);
    temp = nullptr;
    delete temp;
}

Selector* SelectorList::getElement(int index)
{

    Selector* temp = element;
    if (element == nullptr)
        return nullptr;


    for (int i = 0; i < index; i++)
    {
        temp = temp->next;
        if (temp == sentry)
            return nullptr;

    }
    return temp;
}

bool SelectorList::deleteSelector(int index)
{
    index--;
    Selector* temp = getElement(index);
    if (temp == nullptr)
        return false;
   

     if (temp == sentry and temp->next != temp)
    {
        sentry = sentry->next;
        temp->previous->next = temp->next;
        temp->next->previous = temp->previous;
        delete temp;
        return true;
    }
     else
     delete sentry;
    return false;
}


