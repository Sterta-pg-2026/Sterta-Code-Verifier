#include "sectionnode.h"

constexpr int ARRAY_LENGTH = 8;
class blockNode {
	int numberOfElements;
	int numberOfDeletedElements;
	sectionNode *nodeArray[ARRAY_LENGTH]{};
	blockNode* previous;
	blockNode* next;
	friend class BlockList;
public:

	blockNode() :numberOfElements{ 0 },numberOfDeletedElements{ 0 }, previous{ this }, next{ this }
		
	{}
	void addNewElement(sectionNode* newElement)
	{
		nodeArray[numberOfElements] = newElement;
		numberOfElements++;
	}
	~blockNode()
	{
		for (int i = 0; i < ARRAY_LENGTH; i++)
		{
			if (nodeArray[i] != nullptr)
				delete nodeArray[i];
		}
	}
	bool isFull()
	{
		return numberOfElements == ARRAY_LENGTH ? true : false;
	}

	int countSelectorInBlock(ownString element)
	{
		int counter = 0;
		for (int i = 0; i < numberOfElements;i++)
		{
			if (nodeArray[i]->isSectionDeleted() == false)
			{
				for (int j = 0; j < nodeArray[i]->getSelectorList()->countSelectors(); j++)
				{
					if (nodeArray[i]->getSelectorList()->getElement(j)->getValue() == element)
					{
						counter++;
					}
				}

			}
		}
		return counter;
	}

	int countKeyInBlock(ownString key)
	{
		int counter = 0;
		for (int i = 0; i < numberOfElements; i++)
		{
			if (nodeArray[i]->isSectionDeleted() == false)
			{
				counter += nodeArray[i]->getAttributesList()->countByKey(key);
			}
		}
		return counter;
	}

};
