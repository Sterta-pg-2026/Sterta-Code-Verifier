#pragma once
#include "blocklist.h"
#include <iostream>
using namespace std;
BlockList::BlockList():sentry{nullptr}
{

}

BlockList::~BlockList() {

	while (deleteBlock(sentry));
}

void BlockList::addNewBlock()
{
	blockNode *newContainer = new blockNode();
	if (sentry == nullptr)
	{

		sentry = newContainer;
		sentry->next = sentry;
		sentry->previous = sentry;
	}
	else {


		newContainer->next = sentry;
		newContainer->previous = sentry->previous;
		sentry->previous->next = newContainer;
		sentry->previous = newContainer;

		if (sentry->next == sentry)
		{
			sentry->next = newContainer;
		}
	}

}

bool BlockList::deleteBlock(blockNode* deletingBlock)
{
	if (deletingBlock == nullptr)
	{
		return false;
	}
	if ( deletingBlock == deletingBlock->next)
	{
		sentry = nullptr;
		delete deletingBlock;
		return true;
	}
	else
	{
		if (deletingBlock == sentry)
		{
			sentry = sentry->next;
		}

		deletingBlock->next->previous = deletingBlock->previous;
		deletingBlock->previous->next = deletingBlock->next;
		delete deletingBlock;
		return true;
	}
}

void BlockList::pushBack(sectionNode* newElement)
{
	if (sentry == nullptr)
	{
		addNewBlock();
	}

	blockNode *temp = sentry;

	do
	{
		if (temp->isFull() == false)
		{
			temp->addNewElement(newElement);
			return;
		}
		temp = temp->next;
	} while(temp != sentry);

	addNewBlock();
	sentry->previous->addNewElement(newElement);
}

sectionNode* BlockList::getSection(int index)
{
	blockNode* temp = sentry;
	int  counterOfSection = 0;
	
	do {
		for (int i = 0; i < temp->numberOfElements; i++)
		{
			if (counterOfSection == index
				and temp->nodeArray[i]->isSectionDeleted() == false)
			{
				sectionNode* looking = temp->nodeArray[i];
				return looking;
			}
			if(temp->nodeArray[i]->isSectionDeleted() == false)
				counterOfSection++;
		}
		temp = temp->next;
	} while (temp != sentry);

	return nullptr;

}

int BlockList::countElements()
{
	blockNode *temp = sentry;
	if (sentry == nullptr)
		return 0;
	int counter{};
	do {
		counter += temp->numberOfElements - temp->numberOfDeletedElements;
		temp= temp->next;
	} while (temp != sentry);

	return counter;
}

ownString BlockList::chooseSelector(int numOfSelector, int numOfSection)
{
	numOfSection--;
	numOfSelector--;
	sectionNode* temp = getSection(numOfSection);
	if (temp == nullptr)
	{
		return "-1";
	}
	if (temp->getSelectorList()->countSelectors() < numOfSelector)
	{
		return "-1";
	}

	if (numOfSelector < temp->getSelectorList()->countSelectors()) 
	{
		Selector *temp2 = temp->getSelectorList()->getElement(numOfSelector);
		ownString returned = temp2->getValue();
		temp = nullptr;
		delete temp;
		return returned;
	}
	
	return "-1";
}

int BlockList::countSelectorForSection(int sectionIndex)
{
	sectionIndex--;
	sectionNode* temp = getSection(sectionIndex);
	if (temp == nullptr)
	{
		return -1;
	}
	return temp->getSelectorList()->countSelectors();
}

int BlockList::countTag(ownString tag)
{
	int counter = 0;
	blockNode* temp = sentry;
	if (temp == nullptr)
	{
		return 0;
	}

	do {
		counter += temp->countSelectorInBlock(tag);
		temp = temp->next;
	} while(temp != sentry);
	return counter;
}

bool BlockList::isEmpty()
{
	if (sentry == nullptr)
		return true;

	return false;
}

int BlockList::countAttributesForSection(int index)
{
	index--;
	sectionNode* temp = getSection(index);
	if (temp == nullptr)
	{
		return -1;
	}
	int num = temp->getAttributesList()->countAttributes();
	temp = nullptr;
	delete temp;
	return num;
}

ownString BlockList::findAndTakeValueFromSection(int sectionIndex, ownString key)
{
	sectionIndex--;
	sectionNode* temp = getSection(sectionIndex);
	if (temp == nullptr)
	{
		return "-1";
	}
	else {
		ownString resultString = temp->getAttributesList()->giveValue(key);

		temp = nullptr;
		delete temp;
		return resultString;
	}

}

int BlockList::countAllKeys(ownString key)
{
	int counter = 0;
	blockNode* temp = sentry;
	if (sentry == nullptr)
	{
		return -1;
	}

	do {
		counter += temp->countKeyInBlock(key);
		temp = temp->next;
	} while (temp != sentry);

	temp = nullptr;
	delete temp;
	return counter;
}

ownString BlockList::findAtribbuteInSelectorFromEnd(ownString selectorName, ownString attributeKey)
{
	blockNode* temp = sentry->previous;
	if (temp == nullptr)
	{
		return "-1";
	}
	do {
		for (int i = temp->numberOfElements-1; i >=0 ; i--)
		{
			if (temp->nodeArray[i]->doesComponentIsHere(selectorName) and temp->nodeArray[i]->isSectionDeleted() == false)
			{
				ownString element = temp->nodeArray[i]->getAttributesList()->giveValue(attributeKey);
				if (element != "-1") {
					temp = nullptr;
					delete temp;
					return element;
				}
				return element;
			}
		}
			temp = temp->previous;
	} while (temp != sentry->previous);

	temp = nullptr;
	delete temp;
	return "-1";

}

bool BlockList::deleteSection(int index)
{

	index--;

	if (sentry == nullptr or index < 0)
		return false;
	
	blockNode* temp = sentry;
	if (temp == nullptr or temp->numberOfElements < 0)
		return false;
	int counterElement = 0;
	do {
		for (int i = 0; i < temp->numberOfElements; i++)
		{
			if (index == counterElement and temp->nodeArray[i]->isSectionDeleted() == false)
			{
				temp->nodeArray[i]->deleteSection();
				temp->numberOfDeletedElements++;
				if (temp->numberOfDeletedElements == 8 or temp->numberOfDeletedElements == temp->numberOfElements)
				{
					deleteBlock(temp);
					
				}
				return true;

			}
			if (temp->nodeArray[i]->isSectionDeleted() == false)
			{
				counterElement++;
			}
		}

		temp = temp->next;
	} while (temp!=sentry);

	return false;
}

bool BlockList::deleteAttributeFromSection(int sectionIndex, ownString attributeName)
{
	sectionIndex--;
	sectionNode* temp = getSection(sectionIndex);
	if (temp == nullptr)
	{
		return false;
	}

	if (temp->getAttributesList()->deleteAttribute(attributeName))
	{
		if (temp->getAttributesList()->countAttributes() == 0)
		{
			deleteSection(sectionIndex + 1);
		}
		return true;
		}
	else
		return false;


	return false;
}

void BlockList::showElements()
{ 
	/*int iterator = 0;
	blockNode* temp = sentry;
	do {
		cout << "BLOK NR:" << iterator++ << endl;
		for (int i = 0; i < temp->numberOfElements; i++)
		{
			if (temp->nodeArray[i]->isSectionDeleted( == false)
			{
				cout << "ELEMENT NR " << i << ":" << endl;
				temp->nodeArray[i]->getSelectorList().showElements();
				temp->nodeArray[i]->getAttributesList().showElements();
			}
		}
		temp->next;
	} while (temp != sentry);*/
}



