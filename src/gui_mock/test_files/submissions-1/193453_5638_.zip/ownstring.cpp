#include "ownstring.h"
#include <iostream>
#include <string.h>
using namespace std;

const int sizeOfCharArray(const char* element)
{
	if (element == "" or element == nullptr)
	{
		return 0;
	}
	int sizeElement = 0;
	while (element[sizeElement] != '\0')
	{
		sizeElement++;
	}
	return sizeElement;
}

ownString::ownString() :word{ nullptr }, size{ 0 }
{

}

ownString::ownString(const char* element) :word{ new char[sizeOfCharArray(element) + 1] },
size{ sizeOfCharArray(element) }
{
	strcpy_s(word, size + 1, element);
}
ownString::ownString(const ownString& element)
{
	size = element.length();
	word = new char[size + 1];
	strcpy_s(word, size + 1, element.word);
}


int ownString::length() const
{
	return size;
}
void ownString::substring(int startIndex, int numToCut, ownString* destination)
{


	char* temp = new char[numToCut + 1];
	for (int i = startIndex; i < startIndex + numToCut; i++)
	{
		temp[i - startIndex] = word[i];
	}
	temp[numToCut] = '\0';
	*destination = temp;
	delete[] temp;
}


char& ownString::operator[](int index)
{

	return word[index];
}

ownString ownString::operator=(const ownString& compared)
{

	if (compared.word == nullptr or compared.word == "")
	{
		delete[]word;
		word = nullptr;
		return *this;
	}

	if (this != NULL and word != nullptr)
		delete[] word;
	word = new char[compared.size + 1];
	size = compared.size;
	strcpy_s(word, size + 1, compared.word);
	return *this;
}



void ownString::operator=(const char* compared)
{

	if (compared == nullptr or compared == "")
	{
		delete[]word;
		word = nullptr;
		return;
	}



	if (word != nullptr)
		delete[] word;

	int newSize = sizeOfCharArray(compared);
	word = new char[newSize + 1];
	size = newSize;
	strcpy_s(word, size + 1, compared);
	return;
}


bool ownString::operator==(ownString& compared) const
{

	if (this == NULL)
	{
		return false;
	}
	if (!this)
	{
		return false;
	}
	if (size != compared.size)
	{
		return false;
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			if (word[i] != compared[i])
			{
				return false;
			}
		}
	}
	return true;
}

bool ownString::operator==(const char* compared) const
{
	if (size != sizeOfCharArray(compared) or compared == "")
	{

		return false;
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			if (word[i] != compared[i])
			{
				return false;
			}
		}
	}

	return true;
}

bool ownString::operator!=(const char* compared) const
{



	if (size != sizeOfCharArray(compared))
	{

		return true;
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			if (word[i] != compared[i])
			{
				return true;
			}
		}
	}

	return false;
}


std::ostream& operator<< (std::ostream& stream, const ownString& element) {
	stream << element.word;
	return stream;
}




ownString::~ownString() {
	if(word!=nullptr)
		delete[] word;
}

int ownString::find(char letter) {


	for (int i = 0; i < size; i++)
	{
		if (word[i] == letter)
			return i;
	}
	return -1;
}

void ownString::erase(int firstIndex, int numOfElements)
{

	if (word == nullptr)
		return;


	char* newWord = new char[size] {};
	int newWordIndex = 0;
	for (int i = 0; i < size; i++)
	{

		if (i < firstIndex or i >= firstIndex + numOfElements)
		{

			newWord[newWordIndex++] = word[i];
		}
	}
	newWord[newWordIndex] = '\0';
	strcpy_s(word, newWordIndex + 1, newWord);
	size = sizeOfCharArray(word);
	delete[] newWord;
}


int ownString::toInt()
{
	// return 0 when there is a letter or sth
	int number = 0;
	int power = 0;
	for (int i = size - 1; i >= 0; i--)
	{
		int digit = word[i] - '0';

		if (digit > 9)
			return 0;
		number += digit * pow(10, power++);

	}
	return number;
}


char ownString::getChar(int index)
{
	if (index < length())
		return word[index];
	else
		return -1;
}

ownString ownString::cut(int beginIndex, int endIndex)
{
	ownString newElement;
	substring(beginIndex, endIndex, &newElement);
	erase(beginIndex, endIndex + 1);
	return newElement;
}