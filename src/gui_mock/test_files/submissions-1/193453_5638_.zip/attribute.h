#pragma once
#include "ownstring.h"

class Attribute
{
	ownString key;
	ownString value;
	Attribute* next;
	Attribute* previous;
	friend class attributesList;
public:
	Attribute();
	Attribute(Attribute&);
	Attribute(const char* key, const char* value);
	Attribute(ownString key, ownString value);

};

