// cssEngineV2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "ownstring.h"
#include "attributeslist.h"
#include "selectorlist.h"
#include "blocklist.h"
constexpr int BUFFER_SIZE = 500;
constexpr int COMMAND_MODE = 1;
constexpr int INPUT_MODE = 0;

using namespace std;


void takeTags(ownString tagsInString, SelectorList* destination)
{
    while (tagsInString.find(',') != -1)
    {
        while (tagsInString[0] == ' ')
        {
            tagsInString.erase(0, 1);
        }

        int indexOfComma = tagsInString.find(',');
        if (tagsInString[indexOfComma] == tagsInString[tagsInString.length() - 1])
        {
            tagsInString.erase(tagsInString.length() - 1, 1);

        }
        while (indexOfComma > 0 and tagsInString[indexOfComma - 1] == ' ')
        {
            tagsInString.erase(indexOfComma - 1, 1);
            indexOfComma--;
        }
        ownString* newSelector = new ownString("t");
        tagsInString.substring(0, indexOfComma, newSelector);

        if (destination->find(*newSelector) == false)
            destination->pushBack(*newSelector);

        delete newSelector;
        tagsInString.erase(0, indexOfComma + 1);
    }

    while (tagsInString[0] == ' ')
        tagsInString.erase(0, 1);

    if (tagsInString.find('{') == -1 and tagsInString.length() > 0)
    {

        ownString* newSelector = new ownString("t");
        tagsInString.substring(0, tagsInString.length(), newSelector);

        if (destination->find(*newSelector) == false)
            destination->pushBack(*newSelector);
        delete newSelector;
    }
    else if (tagsInString.length() > 0) {
        while (tagsInString[tagsInString.find('{') - 1] == ' ')
            tagsInString.erase(tagsInString.find('{') - 1, 1);

        ownString* newSelector = new ownString("t");
        tagsInString.substring(0, tagsInString.find('{'), newSelector);

        while (newSelector->length() > 0 and newSelector->getChar(newSelector->length() - 1) <= ' '
            and newSelector->getChar(newSelector->length() - 1) != -1)
        {
            newSelector->erase(newSelector->length() - 1, 1);
        }

        if (destination->find(*newSelector) == false)
            destination->pushBack(*newSelector);

        delete newSelector;
    }
    destination->removeWhiteSpaces();

}

void executeSelectorCommand(BlockList& mainCss, ownString partsOfcommand[3], ownString loadedLine)
{
    int firstIntNumber = partsOfcommand[0].toInt();
    int secondIntNumber = partsOfcommand[2].toInt();

    if (partsOfcommand[2] == "?" and firstIntNumber)
    {
        int answerValue = mainCss.countSelectorForSection(firstIntNumber);
        if (answerValue > -1)
            cout << loadedLine << " == " << answerValue << endl;
    }
    else if (firstIntNumber and secondIntNumber)
    {
        ownString anwserValue = mainCss.chooseSelector(secondIntNumber, firstIntNumber);
        if (anwserValue != "-1")
            cout << loadedLine << " == " << anwserValue << endl;

    }
    else if (firstIntNumber == false and partsOfcommand[2] == "?")
    {
        int answerValue = mainCss.countTag(partsOfcommand[0]);
        if (answerValue > -1)
            cout << loadedLine << " == " << answerValue << endl;
    }
}

void executeAttributeCommand(BlockList& mainCss, ownString partsOfcommand[3], ownString loadedLine)
{
    int firstIntNumber = partsOfcommand[0].toInt();
    int secondIntNumber = partsOfcommand[2].toInt();
    if (partsOfcommand[2] == "?" and firstIntNumber)
    {
        int answerValue = mainCss.countAttributesForSection(firstIntNumber);
        if (answerValue > -1)
            cout << loadedLine << " == " << answerValue << endl;
    }
    else if (firstIntNumber and secondIntNumber == 0) {

        ownString anwserValue = mainCss.findAndTakeValueFromSection(firstIntNumber, partsOfcommand[2]);
        if (anwserValue != "-1")
            cout << loadedLine << " == " << anwserValue << endl;    
    }
    else if (firstIntNumber == 0 and secondIntNumber == 0)
    {
        int answerValue = mainCss.countAllKeys(partsOfcommand[0]);
        if (answerValue != -1)
            cout << loadedLine << " == " << answerValue << endl;
    }
}

void executeECommand(BlockList& mainCss, ownString partsOfcommand[3], ownString loadedLine)
{
   
    ownString anwserValue = mainCss.findAtribbuteInSelectorFromEnd(partsOfcommand[0], partsOfcommand[2]);
    if (anwserValue != "-1")
    {
        cout << loadedLine << " == " << anwserValue << endl;
    }

}

void executeDeleteCommand(BlockList& mainCss, ownString partsOfcommand[3], ownString loadedLine)
{
    mainCss.showElements();
    int firstIntNumber = partsOfcommand[0].toInt();
    int secondIntNumber = partsOfcommand[2].toInt();

    if (partsOfcommand[2] == "*")
    {
        if (mainCss.deleteSection(firstIntNumber))
        {
            cout << loadedLine << " == " << "deleted" << endl;
        }
    }
    else if (firstIntNumber and secondIntNumber == false)
    {
        if (mainCss.deleteAttributeFromSection(firstIntNumber, partsOfcommand[2]))
        {
            cout << loadedLine << " == " << "deleted" << endl;
        }
    }

}

void readCommand(ownString partsOfCommand[3], ownString command)
{
    for (int i = 0; i < 3; i++)
    {
        int indexOfComma = command.find(',');
        if (indexOfComma == -1)
        {
            command.substring(0, command.length(), &partsOfCommand[i]);
        }
        else
        {
            command.substring(0, indexOfComma, &partsOfCommand[i]);
            command.erase(0, indexOfComma + 1);
        }
    }
}

void selectingCorrectLetter(BlockList& mainCss, ownString partsOfcommand[3]
    , ownString loadedLine)
{
    if (partsOfcommand[1] == "S")
    {
        executeSelectorCommand(mainCss, partsOfcommand, loadedLine);
    }
    else if (partsOfcommand[1] == "A")
    {
        executeAttributeCommand(mainCss, partsOfcommand, loadedLine);
    }
    else if (partsOfcommand[1] == "E")
    {
        executeECommand(mainCss, partsOfcommand, loadedLine);
    }
    else if (partsOfcommand[1] == "D")
    {
        executeDeleteCommand(mainCss, partsOfcommand, loadedLine);
    }
}

void readingCommands(BlockList& mainCss, ownString& loadedLine, int& input_type)
{
    if (loadedLine == "\n" or loadedLine == "")
        return;
    else if (loadedLine == "?")
    {
        cout << loadedLine << " == " << mainCss.countElements() << endl;
    }
    else if (loadedLine == "****")
    {
        input_type = 0;
    }
    else {
        if (mainCss.isEmpty())
            return;
        ownString partsOfcommand[3];
        readCommand(partsOfcommand, loadedLine);
        selectingCorrectLetter(mainCss, partsOfcommand, loadedLine);
    }
}
bool strangeInputLoaded(const char* buffer)
{
    if (buffer[0] < ' ' and strlen(buffer) == 1 or strlen(buffer) == 0)
    {
        return true;
    }
    else
        return false;
}


bool doesItGlobalAttributeWithBrackets(ownString& loadedLine, SelectorList* selectors)
{ 
    if (loadedLine[0] == '{' and selectors->countSelectors() == 0)
        return true;

    else
        return false;
}


int main()
{
    std::ios::sync_with_stdio(false);
    cin.tie(NULL);
    BlockList mainCss;
    int inputType = 0;
    char buffer[BUFFER_SIZE]{};
    SelectorList* selectors = new  SelectorList;
    attributesList* attributes = new attributesList;
    ownString loadedLine;
    bool wasLeftBracket = false;
    while (cin.getline(buffer, BUFFER_SIZE))
    {
        loadedLine = buffer;

        if (inputType == INPUT_MODE)
        {
            if (strangeInputLoaded(buffer) or loadedLine == "\n" or loadedLine == "")
                continue;

            if (loadedLine == "????")
            {
                inputType = 1;
                continue;
            }

            if (wasLeftBracket == false)
            {
                if (doesItGlobalAttributeWithBrackets(loadedLine, selectors))
                {
                    attributes->addFormattedElementsToList(loadedLine, wasLeftBracket);
                    wasLeftBracket = true;
                    if (loadedLine.find('}') != -1)
                    {
                        sectionNode* secNode = new sectionNode(attributes, selectors);
                        mainCss.pushBack(secNode);
                        attributes = new attributesList;
                        selectors = new SelectorList;
                        wasLeftBracket = false;
                        continue;
                    }
                }

                if (loadedLine[0] == '{')
                {
                    wasLeftBracket = true;
                    continue;
                }

                takeTags(loadedLine, selectors);


                attributes->addFormattedElementsToList(loadedLine, wasLeftBracket);

                if (loadedLine.find('{') != -1)
                    wasLeftBracket = true;
            }
            else {
                attributes->addFormattedElementsToList(loadedLine, wasLeftBracket);
            }

            if (attributes->countAttributes() > 0 and loadedLine.find('}') != -1)
            {
                sectionNode* secNode = new sectionNode(attributes, selectors);
                mainCss.pushBack(secNode);
                attributes = new attributesList;
                selectors = new SelectorList;
                wasLeftBracket = false;
            
            }

        }
        else {
            readingCommands(mainCss, loadedLine, inputType);
        }

    }

    return 0;
}
