#pragma once
#include <iostream>

class ownString {

	char* word = nullptr;
	int size = 0;
public:
	ownString();
	ownString(const char*);
	ownString(const ownString&);

	char& operator[](int index);
	ownString operator=(const ownString&);
	void operator=(const char*);
	bool operator==(ownString&) const;
	bool operator==(const char*) const;
	bool operator!=(const char*) const;
	int length() const;
	void substring(int, int, ownString*);
	int  find(char);
	char getChar(int);
	void erase(int, int);
	int toInt();
	ownString cut(int, int);
	friend class attributesList;

	friend const int sizeOfCharArray(const char*);
	friend std::ostream& operator<< (std::ostream& stream, const ownString&);


	~ownString();


};