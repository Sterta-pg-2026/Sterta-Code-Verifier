#pragma once


#include "attributeslist.h"
#include "selectorlist.h"
#include "ownstring.h"
class sectionNode {

	attributesList attributes;
	SelectorList selectors;
	bool isDeleted = false;

	friend class sectionList;
	friend class blockNode;
	friend class blockList;
public:
	sectionNode(attributesList*,SelectorList*);
	sectionNode();
	//void showSection();
	bool doesComponentIsHere(ownString lookingComp);
	bool isSectionDeleted();
	SelectorList* getSelectorList();
	attributesList* getAttributesList();
	void deleteSection();
	~sectionNode();
};