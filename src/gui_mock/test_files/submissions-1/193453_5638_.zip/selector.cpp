#include "selector.h"

Selector::Selector()
	:selectorValue{ "e" },next{this}, previous{ this }
{
}

Selector::Selector(Selector& element)
	:selectorValue{element.selectorValue}
	,next{element.next}, previous{ element.previous }
{

}

Selector::Selector(const char* selectorVal)
	:selectorValue{ selectorVal}, next{ this }, previous{ this }
{
}

Selector::Selector(ownString& key)
	:selectorValue{ key }, next{ this }, previous{ this }
{
}

ownString Selector::getValue()
{
	return selectorValue;
}
