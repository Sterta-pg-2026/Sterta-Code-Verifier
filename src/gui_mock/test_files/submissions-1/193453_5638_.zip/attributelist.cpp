#include "attributeslist.h"
#include <iostream>
using namespace std;

void deleteStrangeSignsOnEdges(ownString& element)
{
    while (element[0] == '\t' or element[0] <= ' ')
    {
        element.erase(0, 1);
    }
    while (element[element.length() - 1] == '\n' or element[element.length() - 1] <= ' ')
    {
        element.erase(element.length() - 1, 1);
    }

}
void deleteWhitespaceOnLeft(ownString& element)
{
    while (element[0] == ' ')
        element.erase(0, 1);
}




attributesList::attributesList() :element{ new Attribute{} }, sentry(element),counter(0)
{

}

attributesList::attributesList(const attributesList& attributesList)
{
    this->element = attributesList.element;
    this->sentry = attributesList.sentry;
    this->counter = attributesList.counter;
}



attributesList::~attributesList()
{
    int len = countAttributes();
    for (int i = 0; i < len; i++)
    {
        deleteAttribute(element->next->key);
    }
    delete(element);
}




void attributesList::pushBack(const char* key, const char* value)
{
    Attribute* newElement = new Attribute(key, value);
    newElement->next = element;
    newElement->previous = element->previous;
    element->previous->next = newElement;
    element->previous = newElement;
    counter++;
    if (element->next == element)
    {
        element->next = newElement;
    }

}

void attributesList::pushBack(Attribute* newCopyElement)
{
    Attribute* newElement = newCopyElement;

    newElement->next = element;
    newElement->previous = element->previous;
    element->previous->next = newElement;
    element->previous = newElement;
    counter++;
    if (element->next == element)
    {
        element->next = newElement;
    }
}


void attributesList::showElements() {

    Attribute* temp = element->next;
    cout << "{" << endl;
    while (temp != sentry)
    {
        cout << "k:" << temp->key << "| v:" << temp->value << " " << endl;;
        temp = temp->next;
    }
    cout << "}" << endl;
    cout << "{liczba:" << countAttributes() << "}";
}


void attributesList::addFormattedElementsToList(ownString text, bool wasLeftBracket)
{
    int twoDotsIndex = -1,
        comaIndex = -1,
        leftBracketIndex = -1,
        rightBracketIndex = -1;

    if (wasLeftBracket == false and text.find(';') == -1)
        return;


    if (text.find('{') != -1 and text.find(':') != -1
        and text.find('{') > text.find(':'))
    {
        text.erase(0, text.find(':') + 1);
    }


    leftBracketIndex = text.find('{');
    if (leftBracketIndex != -1)
        text.erase(0, leftBracketIndex + 1);

    rightBracketIndex = text.find('}');
    if (rightBracketIndex != -1)
        text.erase(rightBracketIndex, 1);

    while (text.find(':') != -1)
    {
        ownString key;
        ownString value;

        deleteWhitespaceOnLeft(text);

        twoDotsIndex = text.find(':');
        text.substring(0, twoDotsIndex, &key);
        text.erase(0, twoDotsIndex + 1);

        deleteWhitespaceOnLeft(text);

        comaIndex = text.find(';');
        if (comaIndex == -1 and twoDotsIndex != -1)
        {
            value = text.cut(0, text.size);
        }
        else
        {
            value = text.cut(0, comaIndex);
        }

        deleteStrangeSignsOnEdges(key);
        deleteStrangeSignsOnEdges(value);

        Attribute* newElement = new Attribute(key, value);
        if (!findDupilicateAndReplace(newElement))
            pushBack(newElement);

       
    }
}

bool attributesList::findDupilicateAndReplace(Attribute* looking)
{
    Attribute* temp = element->next;
    if (temp == sentry) {
        return false;
    }

    while (temp != sentry)
    {
        if (temp->key == looking->key)
        {

            temp->previous->next = looking;
            temp->next->previous = looking;
            looking->next = temp->next;
            looking->previous = temp->previous;
            delete temp;
            return true;
        }
        temp = temp->next;
    }

    return false;
}

int attributesList::countAttributes()
{
    return counter;
    /*Attribute* temp = element->next;
    if (temp == sentry) {
        return 0;
    }
    int numOfElements = 0;
    while (temp != sentry)
    {
        numOfElements++;
        temp = temp->next;
    }

    temp = nullptr;
    delete temp;
    return numOfElements; */
}

int attributesList::countByKey(ownString key) {

    Attribute* temp = element->next;

    if (temp == sentry) {
        return 0;
    }
    int numOfElements = 0;
    while (temp != sentry)
    {
        if (temp->key == key)
            numOfElements++;
        temp = temp->next;
    }
    temp = nullptr;
    delete temp;

    return numOfElements;
}


ownString attributesList::giveValue(ownString key)
{
    Attribute* temp = element->next;

    if (temp == nullptr)
    {
        return "-1";
    }
    else if (temp->key == key)
    {
        temp->value;
    }

    do
    {
        if (temp->key == key)
        {
            return temp->value;
        }
        temp = temp->next;
    } while (temp != sentry);


    temp = nullptr;
    delete temp;

    return "-1";
}

bool attributesList::deleteAttribute(ownString& key)
{
    Attribute* temp = element;

    do
    {
        if (temp->key == key)
        {
            temp->next->previous = temp->previous;
            temp->previous->next = temp->next;
            delete temp;
            counter--;
            return true;

        }
        temp = temp->next;


    } while (temp != sentry);

    temp = nullptr;
    delete temp;
    return false;
}
