#pragma once
#pragma once
#include "ownstring.h"

class Selector
{
	ownString selectorValue;
	Selector* next;
	Selector* previous;
	friend class SelectorList;
	friend class sectionList;
	friend class blockNode;
public:
	Selector();
	Selector(Selector&);
	Selector(const char* key);
	Selector(ownString& key);
	ownString getValue();
};

