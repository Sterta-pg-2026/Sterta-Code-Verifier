#include "sectionnode.h"
#include <iostream>
using namespace std;


sectionNode::sectionNode(attributesList* attributes, SelectorList* selectors)
{
	this->attributes = *attributes;
	this->selectors = *selectors;
}
sectionNode::sectionNode()
{

}

//void sectionNode::showSection()
//{
//	cout<<"Czy usuniety:" << isDeleted << endl;
//	selectors.showElements();
//	cout << endl;
//	attributes.showElements();
//}
bool sectionNode::doesComponentIsHere(ownString lookingComponent) {
	
	return selectors.find(lookingComponent);
}


bool sectionNode::isSectionDeleted()
{
	return isDeleted;
}

SelectorList* sectionNode::getSelectorList()
{
	return &selectors;
}

attributesList* sectionNode::getAttributesList()
{
	return &attributes;
}

void sectionNode::deleteSection()
{
	isDeleted = true;
}

sectionNode::~sectionNode()
{

}
