#pragma once
#pragma once
#include <iostream>
#include "attribute.h"

class attributesList
{
	Attribute* element;
	Attribute* sentry;
	friend class ownString;
	int counter;
public:
	attributesList();
	attributesList(const attributesList&);

	~attributesList();
	void pushBack(const char*, const char*);
	void pushBack(Attribute*);
	void showElements();
	int countAttributes();
	int countByKey(ownString);
	ownString giveValue(ownString key);
	bool findDupilicateAndReplace(Attribute*);
	void addFormattedElementsToList(ownString,bool);
	bool deleteAttribute(ownString &key);

private:

};

