#pragma once
#include <iostream>
using namespace std;
template <typename T>
class DL_Node
{
	T data = T();
	DL_Node<T>* next = nullptr;
	DL_Node<T>* prev = nullptr;

public:
	DL_Node<T>(): data(T()), next(nullptr), prev(nullptr) {}
	DL_Node<T>(T _data) : data(_data), next(nullptr), prev(nullptr) {}

	void setNext(DL_Node<T>* _next)
	{
		this->next = _next;
	}

	void setPrev(DL_Node<T>* _prev)
	{
		this->prev = _prev;
	}

	DL_Node<T>* getNext()
	{
		return next;
	}

	DL_Node<T>* getPrev()
	{
		return prev;
	}

	T& getData()
	{
		return data;
	}

	~DL_Node()
	{
		next = nullptr;
		prev = nullptr;
	}
};

