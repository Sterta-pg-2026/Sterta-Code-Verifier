#include <iostream>
#include "stringclass.h"
#include "dl_node.h"
#include "dl_list.h"
using namespace std;

const int T = 8;


struct AttributeEntry
{
	StringClass key = "";
	StringClass value = "";

	void operator=(const AttributeEntry &secondEntry)
	{
		key = secondEntry.key;
		value = secondEntry.value;
	}
};

struct Section
{
	DL_List<AttributeEntry> attributes = DL_List<AttributeEntry>();
	DL_List<StringClass> selectors = DL_List<StringClass>();

	bool isUsed = false;

	Section()
	{
		attributes = DL_List<AttributeEntry>();
		selectors = DL_List<StringClass>();
		isUsed = false;
	}
};

struct Block
{
	Section tab[T] = {};
	int takenSpaces = 0;
};

StringClass eradicateWhitespaces(StringClass current)
{
	while (current.getLength() >0 && current[current.getLength() - 1] <= ' ')
	{
		current.substr(0, current.getLength() - 1);
	}

	while (current.getLength() > 0 && current[0] <= ' ')
	{
		current.substr(1, current.getLength());
	}

	return current;
}
Section& getSection(DL_List<Block>& allBlocks, int indeks)
{
	int sectionsFound = 0;
	for (int i = 0;i < allBlocks.getSize();i++)
	{
		if (sectionsFound + allBlocks[i]->getData().takenSpaces >= indeks)
		{
			//we here boys
			for (int j = 0;j < T;j++)
			{
				if (allBlocks[i]->getData().tab[j].isUsed)
				{
					if (sectionsFound == indeks)
					{
						return allBlocks[i]->getData().tab[j];
					}

					sectionsFound++;
				}
			}
		}
		else
		{
			sectionsFound += allBlocks[i]->getData().takenSpaces;
		}
	}
	Section * noSection = new Section();
	return (*noSection);
}

void addNewSection(DL_List<Block>& allBlocks, Section& currentSection, int& sectionCounter)
{
	currentSection.isUsed = true;

	if (allBlocks.getSize() <= 0)
	{
		allBlocks.addNode(Block());
		allBlocks[0]->getData().tab[0] = currentSection;

	}
	else
	{
		int emptySpace = -1;
		for (int i = T - 1;i >= 0;i--)
		{
			if (allBlocks[allBlocks.getSize() - 1]->getData().tab[i].isUsed)
			{
				i = -1;
			}
			else
			{
				emptySpace = i;
			}

		}

		if (emptySpace != -1)
		{
			allBlocks[allBlocks.getSize() - 1]->getData().tab[emptySpace] = currentSection;
		}
		else
		{
			allBlocks.addNode(Block());
			allBlocks[allBlocks.getSize() - 1]->getData().tab[0] = currentSection;
		}

	}
	allBlocks[allBlocks.getSize() - 1]->getData().takenSpaces++;
	sectionCounter++;
}
bool deleteSection(DL_List<Block>& allBlocks, int indeks, int& sectionCounter)
{
	int sectionsFound = 0;
	for (int i = 0;i < allBlocks.getSize();i++)
	{
		if (sectionsFound + allBlocks[i]->getData().takenSpaces >= indeks)
		{
			//we here boys
			for (int j = 0;j < T;j++)
			{
				if (allBlocks[i]->getData().tab[j].isUsed)
				{
					if (sectionsFound == indeks)
					{
						allBlocks[i]->getData().tab[j].isUsed = false;
						allBlocks[i]->getData().takenSpaces--;
						sectionCounter--;
						return true;
					}

					sectionsFound++;
				}
			}
		}
		else
		{
			sectionsFound += allBlocks[i]->getData().takenSpaces;
		}
	}
	return false;
}


void handleSCommand(DL_List<Block>& allBlocks, StringClass &firstHalf, StringClass&secondHalf, int &sectionCounter)
{
	if (firstHalf.toInt() > 0 && secondHalf.toInt()>0)
	{
		//i, S, j
		int firstHalfInt = firstHalf.toInt() - 1;
		int secondHalfInt = secondHalf.toInt() - 1;

		if (firstHalfInt+1 == 14 && secondHalfInt+1 == 1)
		{
			int stop = 0;
		}

		if (firstHalfInt >= 0 && firstHalfInt < sectionCounter)
		{
			Section thisSection = getSection(allBlocks, firstHalfInt);

			if (thisSection.isUsed&&secondHalfInt >= 0 && secondHalfInt < thisSection.selectors.getSize())
			{
				cout << firstHalfInt+1 << ",S," << secondHalfInt+1 << " == " << thisSection.selectors[secondHalfInt]->getData()<<endl;
			}

		}
	}
	else if(firstHalf.toInt()>0)
	{
		//i, S, ?
		int firstHalfInt = firstHalf.toInt() - 1;
		if (firstHalfInt >= 0 && firstHalfInt < sectionCounter)
		{

			if (getSection(allBlocks, firstHalfInt).isUsed)
			{
				cout << firstHalfInt+1 << ",S,?" << " == " << getSection(allBlocks, firstHalfInt).selectors.getSize()<<endl;
			}
			
	

		}

	}
	else
	{
		//z, S, ?
		int occurences = 0;
		for (int i = 0;i < allBlocks.getSize();i++)
		{
			for (int j = 0;j < T;j++)
			{
				if (allBlocks[i]->getData().tab[j].isUsed)
				{
					for (int k = 0;k < allBlocks[i]->getData().tab[j].selectors.getSize();k++)
					{
						if (allBlocks[i]->getData().tab[j].selectors[k]->getData() == firstHalf)
						{
							occurences++;
							k = allBlocks[i]->getData().tab[j].selectors.getSize();
						}
					}
				}
			}
		}

		cout << firstHalf << ",S,? == " << occurences << endl;

	}





}
void handleACommand(DL_List<Block>& allBlocks, StringClass& firstHalf, StringClass& secondHalf, int& sectionCounter)
{
	if (firstHalf.toInt() > 0)
	{
		int firstHalfInt = firstHalf.toInt() - 1;
		if (firstHalfInt >= 0 && firstHalfInt < sectionCounter)
		{
			Section thisSection = getSection(allBlocks, firstHalfInt);

			if (secondHalf == "?")
			{
				//i, A, ?
				cout << firstHalf << ",A,? == " << thisSection.attributes.getSize() << endl;

			}
			else
			{
				//i, A, n
				for (int i = 0;i < thisSection.attributes.getSize();i++)
				{
					if (thisSection.attributes[i]->getData().key == secondHalf)
					{
						cout << firstHalf << ",A,"<<secondHalf<<" == "<< thisSection.attributes[i]->getData().value<< endl;
						i = thisSection.attributes.getSize();
					}
				}
				
			}
		}
	}
	else
	{
		//n, A, ?
		int occurences = 0;
		for (int i = 0;i < allBlocks.getSize();i++)
		{
			for (int j = 0;j < T;j++)
			{
				if (allBlocks[i]->getData().tab[j].isUsed)
				{
					for (int k = 0;k <allBlocks[i]->getData().tab[j].attributes.getSize();k++)
					{
						if (allBlocks[i]->getData().tab[j].attributes[k]->getData().key == firstHalf)
						{
							occurences++;
							k = allBlocks[i]->getData().tab[j].attributes.getSize();
						}
					}
				}
			}
		}

		cout << firstHalf << ",A,? == " << occurences << endl;
	}


}

bool handleECommand(DL_List<Block>& allBlocks, StringClass& firstHalf, StringClass& secondHalf, int& sectionCounter)
{
	//z, E, n
	for (int i = allBlocks.getSize() - 1;i >= 0;i--)
	{
		for (int j = T - 1;j >= 0;j--)
		{
			if (allBlocks[i]->getData().tab[j].isUsed)
			{
				bool selectorHere = false;
				for (int k = 0;k < allBlocks[i]->getData().tab[j].selectors.getSize();k++)
				{
					if (allBlocks[i]->getData().tab[j].selectors[k]->getData() == firstHalf)
					{
						selectorHere = true;
					}
				}

				if (selectorHere)
				{
					for (int k = 0;k < allBlocks[i]->getData().tab[j].attributes.getSize();k++)
					{
						if (allBlocks[i]->getData().tab[j].attributes[k]->getData().key == secondHalf)
						{
							cout << firstHalf << ",E," << secondHalf << " == " << allBlocks[i]->getData().tab[j].attributes[k]->getData().value << endl;
							return true;
						}
					}
				}
			}
		}
	}
	return false;

}
bool handleDCommand(DL_List<Block>& allBlocks, StringClass& firstHalf, StringClass& secondHalf, int& sectionCounter)
{
	if (firstHalf.toInt() > 0)
	{
		int firstHalfInt = firstHalf.toInt()-1;

		if (secondHalf=="*")
		{
			//i, D, *
			if (deleteSection(allBlocks, firstHalfInt, sectionCounter))
			{
				cout << firstHalf << ",D,* == deleted" << endl;
				return true;
			}

		
		}
		else
		{
			//i, D, n

			for (int f = 0;f < getSection(allBlocks, firstHalfInt).attributes.getSize();f++)
			{
		
				if (getSection(allBlocks, firstHalfInt).attributes[f]->getData().key == secondHalf)
				{
					getSection(allBlocks, firstHalfInt).attributes.deleteNode(f);

					if (getSection(allBlocks, firstHalfInt).attributes.getSize()<=0)
					{
						deleteSection(allBlocks, firstHalfInt, sectionCounter);
					}
					cout << firstHalf << ",D," << secondHalf << " == deleted"<<endl;
					return true;
				}
			}
			return false;
			

			

		}

	


	}
	return false;

}


void handleCommaCommand(DL_List<Block> &allBlocks, StringClass &currentLine, int &sectionCounter)
{
	int commaCounter = 0;
	for (int i = 0;i < currentLine.getLength();i++)
	{
		if (currentLine[i] == ',')
		{
			commaCounter++;
		}
	}

	if (commaCounter == 2)
	{
		StringClass firstHalf = currentLine;
		StringClass middle = currentLine;
		StringClass secondHalf = currentLine;

		int firstCommaIndex = -1;
		for (int i = 0;i < currentLine.getLength();i++)
		{
			if (currentLine[i] == ',')
			{
				firstCommaIndex = i;
				i = currentLine.getLength();
			}
		}

		firstHalf.substr(0, firstCommaIndex);

		int secondCommaIndex = -1;

		for (int i = firstCommaIndex+1;i < currentLine.getLength();i++)
		{
			if (currentLine[i] == ',')
			{
				secondCommaIndex = i;
				i = currentLine.getLength();
			}
		}

		middle.substr(firstCommaIndex + 1, secondCommaIndex);
		secondHalf.substr(secondCommaIndex + 1, currentLine.getLength());

		firstHalf = eradicateWhitespaces(firstHalf);
		middle = eradicateWhitespaces(middle);
		secondHalf = eradicateWhitespaces(secondHalf);

		if (middle.getLength() == 1)
		{
			switch (middle[0])
			{
				case 'S':
					handleSCommand(allBlocks, firstHalf, secondHalf, sectionCounter);
					break;
				case 'A':
					handleACommand(allBlocks, firstHalf, secondHalf, sectionCounter);
					break;
				case 'E':
					handleECommand(allBlocks, firstHalf, secondHalf, sectionCounter);
					break;
				case 'D':
					handleDCommand(allBlocks, firstHalf, secondHalf, sectionCounter);
					break;
				default:
					break;
			}
		}
	}
}


int main()
{

	StringClass currentLine = StringClass("");
	StringClass current = StringClass("");

	bool endOfFile = false;
	bool insideSection = false;
	bool commandMode = false;

	DL_List<Block> allBlocks = DL_List<Block>();
	Section currentSection = Section();
	AttributeEntry currentAttribute = AttributeEntry();


	int sectionCounter = 0;


	while (!endOfFile)
	{
		endOfFile = !currentLine.readNext();
		
		if (currentLine.getLength() == -1)
		{
			//cout << "oh no";
		}
		else if (!commandMode)
		{
			if (currentLine == "????")
			{
				commandMode = true;
			}
			else
			{
				for (int i = 0;i < currentLine.getLength();i++)
				{
					char znak = currentLine[i];

					if (znak < ' ')
					{

					}
					else
					{
						if (insideSection)
						{
							if (znak == '}')
							{
								if (currentAttribute.key != "")
								{
									current = eradicateWhitespaces(current);
									currentAttribute.value = current;

									bool wasBefore = false;
									for (int z = 0;z < currentSection.attributes.getSize();z++)
									{
										if (currentSection.attributes[z]->getData().key == currentAttribute.key)
										{
											currentSection.attributes[z]->getData() = currentAttribute;
											wasBefore = true;
											z = currentSection.attributes.getSize();
										}
									}
									if (!wasBefore)
									{
										currentSection.attributes.addNode(currentAttribute);
									}
									
									
									current = "";
								}
								currentAttribute = AttributeEntry();

								addNewSection(allBlocks, currentSection, sectionCounter);
								currentSection = Section();
								insideSection = false;
								current = "";
							}
							else if (znak == ';')
							{
								if (currentAttribute.key != "")
								{
									current = eradicateWhitespaces(current);
									currentAttribute.value = current;
									bool wasBefore = false;
									for (int z = 0;z < currentSection.attributes.getSize();z++)
									{
										if (currentSection.attributes[z]->getData().key == currentAttribute.key)
										{
											currentSection.attributes[z]->getData() = currentAttribute;
											wasBefore = true;
											z = currentSection.attributes.getSize();
										}
									}
									if (!wasBefore)
									{
										currentSection.attributes.addNode(currentAttribute);
									}
									currentAttribute = AttributeEntry();
									current = "";
								}
							}
							else if (znak == ':')
							{
								current = eradicateWhitespaces(current);
								currentAttribute.key = current;
								current = "";
							}
							else
							{
								current += znak;
							}
						}
						else if(znak == '{')
						{
							insideSection = true;
							//handle selectors here
							current = eradicateWhitespaces(current);

							bool wasBefore = false;
							for (int z = 0;z < currentSection.selectors.getSize();z++)
							{
								if (currentSection.selectors[z]->getData() == current)
								{
									wasBefore = true;
								}
							}
							
							if (!wasBefore && current!="")
							{
								currentSection.selectors.addNode(current);
							}
							currentAttribute = AttributeEntry();
							current = "";
						}
						else if (znak == ',')
						{
							current = eradicateWhitespaces(current);

							bool wasBefore = false;
							for (int z = 0;z < currentSection.selectors.getSize();z++)
							{
								if (currentSection.selectors[z]->getData() == current)
								{
									wasBefore = true;
								}
							}

							if (!wasBefore&&current!="")
							{
								currentSection.selectors.addNode(current);
							}
							current = "";
						}
						else
						{
							current += znak;
						}
						
					}

				}
			}
		}
		else if(commandMode)
		{
			currentLine = eradicateWhitespaces(currentLine);

			if (currentLine == "****")
			{
				commandMode = false;
			}
			else if(currentLine=="?")
			{
				cout << "? == " << sectionCounter<<endl;
			}
			else
			{
				handleCommaCommand(allBlocks, currentLine, sectionCounter);

			}

		}


	}
	return 0;
}