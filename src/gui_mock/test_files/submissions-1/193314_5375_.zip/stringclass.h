#pragma once
#include <iostream>
using namespace std;
class StringClass
{
	char* tab = nullptr;
	size_t size = 0;

public:
	StringClass();
	StringClass(const char* initial);
	StringClass(char* initial);
	StringClass(const StringClass &second);


	void operator+=(char chr)
	{
		int newSize = size+1;
		char* newTab = new char[newSize + 1];

		int it = 0;

		for (int i = 0;i < size;i++)
		{
			newTab[it] = tab[i];
			it++;
		}

		newTab[newSize - 1] = chr;
		newTab[newSize] = '\0';
		delete[] tab;
		tab = newTab;
		size = newSize;
	}


	char& operator[](int indeks);

	friend ostream& operator<<(ostream& os, const StringClass& stringClass)
	{
		os << stringClass.tab;
		return os;
	}

	int toInt();

	void substr(int begin, int end)
	{
		int newSize = end-begin;
		char* newTab = new char[newSize + 1];

		int it = 0;

		for (int i = begin;i < end;i++)
		{
			newTab[it] = tab[i];
			it++;
		}

			newTab[newSize] = '\0';
			delete[] tab;
			tab = newTab;
			size = newSize;
	}
		


	int getLength()
	{
		return size;
	}

	int find(char a)
	{
		for (int i = 0;i < size;i++)
		{
			if (tab[i] == a)
			{
				return i;
			}
		}
		return -1;
	}

	bool readNext();

	void operator=(const StringClass secondString);


	bool operator==(const char* other);
	bool operator==(const StringClass secondString);

	bool operator!=(const char* other);
	~StringClass();
};

