#pragma once
#include <iostream>
#include "dl_node.h"
using namespace std;

template <typename T>
class DL_List
{
	DL_Node<T>* head = nullptr;
	DL_Node<T>* iterator = nullptr;
	int iteratorIndeks = 0;

	size_t size = 0;

public:
	DL_List<T>():head(nullptr),iterator(nullptr), iteratorIndeks(0), size(0) {}
	DL_List<T>(DL_Node<T>* _head):head(_head), iteratorIndeks(0), size(1)
	{
		iterator = head;
	}

	size_t getSize()
	{
		return size;
	}

	DL_Node<T>* getNode(int indeks)
	{
		if (indeks >= size || size < 0)
		{
			return nullptr;
		}

		while (indeks < iteratorIndeks)
		{
			iterator = iterator->getPrev();
			iteratorIndeks--;
		}

		while (indeks > iteratorIndeks)
		{
			iterator = iterator->getNext();
			iteratorIndeks++;
		}
		return iterator;
	}
	
	void addNode(T nodeData)
	{
		T* data = new T(nodeData);
		DL_Node<T>* newNode = new DL_Node<T>((*data));

		if (size<=0)
		{
			head = newNode;
			iterator = head;
			iteratorIndeks = 0;
			head->setNext(nullptr);
		}
		else
		{
			DL_Node<T>* last = getNode(size - 1);
			last->setNext(newNode);
			newNode->setPrev(last);
		}

		size++;

	}

	bool deleteNode(int indeks)
	{
		if (indeks > size || indeks < 0)
		{
			return false;
		}

		DL_Node<T>* nodeToDelete = getNode(indeks);
	

		if (indeks==0&&size == 1)
		{
			head = nullptr;
			iterator = nullptr;
			iteratorIndeks = 0;
			delete nodeToDelete;
		}
		else if (indeks == 0&&size>1)
		{
			head = nodeToDelete->getNext();
			head->setPrev(nullptr);

			delete nodeToDelete;
		}
		else if (indeks == size&&size>1)
		{
			getNode(indeks - 1)->setNext(nullptr);

			delete nodeToDelete;
		}
		else if(size>1)
		{
			DL_Node<T>* next = getNode(indeks + 1);
			DL_Node<T>* prev = getNode(indeks - 1);
			next->setPrev(prev);
			prev->setNext(next);
			
			delete nodeToDelete;
		}

		if (indeks <= iteratorIndeks)
		{
			iterator = head;
			iteratorIndeks = 0;
		}
		size--;
		if (size < 0)
		{
			size = 0;
		}
		return true;
	}


	DL_Node<T>* operator[](int indeks)
	{
		return getNode(indeks);
	}
};

