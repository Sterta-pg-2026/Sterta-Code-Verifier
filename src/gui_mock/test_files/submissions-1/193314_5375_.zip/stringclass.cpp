#include "stringclass.h"
#include <string.h>

#include <iostream>

void StringClass::operator=(const StringClass secondString)
{
	size = secondString.size;
	tab = new char[size + 1];
	strcpy_s(tab, size+1, secondString.tab);
}

int StringClass::toInt()
{
	int result = 0;
	int multiplier = 1;
	for (int i = size-1;i>=0;i--)
	{
		if (tab[i] < '0' || tab[i]>'9')
		{
			return -1;
		}
		result += (tab[i] - '0') * multiplier;
		multiplier *= 10;
	}
	return result;
}

StringClass::StringClass(): tab(nullptr), size(0) {}

StringClass::StringClass(char* initial)
{
	size = strlen(initial);
	tab = new char[size + 1];
	strcpy_s(tab, size+1, initial);
}

StringClass::StringClass(const char* initial)
{
	size = strlen(initial);
	tab = new char[size + 1];
	strcpy_s(tab, size + 1, initial);
}

StringClass::~StringClass()
{
	if (tab != nullptr && size>0)
	{
		delete[] tab;
		size = 0;
	}

}

bool StringClass::operator==(const StringClass secondString)
{



	if (secondString.size != size)
	{
		return false;
	}

	for (int j = 0;j < size;j++)
	{
		if (tab[j] != secondString.tab[j])
		{
			return false;
		}
	}

	return true;
}

StringClass::StringClass(const StringClass& second)
{
		size = second.size;
		tab = new char[size + 1];
		strcpy_s(tab, size + 1, second.tab);
}

bool StringClass::readNext()
{
	char buffer[3000];
	if (cin.getline(buffer, 3000))
	{
		size = strlen(buffer);
		if (tab != nullptr)
		{
			delete[] tab;
		}
		tab = new char[size+1];
		for (int i = 0;i < size;i++)
		{
			tab[i] = buffer[i];
		}
		tab[size] = '\0';

		return true;
	}
	else
	{
		if (tab != nullptr)
		{
			delete[] tab;
		}
		tab = nullptr;
		size = -1;
		return false;
	}

}

char& StringClass::operator[](int indeks)
{
	return tab[indeks];
}

bool StringClass::operator==(const char* other)
{

	if (size != strlen(other))
	{
		return false;
	}

	for (int i = 0;i < strlen(other);i++)
	{
		if (tab[i] != other[i])
		{
			return false;
		}
	}

	return true;
}
bool StringClass::operator!=(const char* other)
{
	return !((*this) == other);
}
