#pragma once
#include "move.h"
#include "nodeatr.h"
#include <iostream>

NodeAtr::NodeAtr() {
	this->next = nullptr;
}
NodeAtr::NodeAtr(const NodeAtr& right) {
	valV = right.valV;
	valA = right.valA;
	next = right.next;
}
NodeAtr::NodeAtr(NodeAtr&& right) {
	valV = Move<String>(right.valV);
	valA = Move<String>(right.valA);
	next = right.next;
}
const String NodeAtr::getValV() const {
	return this->valV;
}
const String NodeAtr::getValA() const {
	return this->valA;
}
void NodeAtr::setValV(const String& newV) {
	this->valV = newV;
}
void NodeAtr::setValA(const String& newV) {
	this->valA = newV;
}
NodeAtr* NodeAtr::getNext() {
	return this->next;
}
void NodeAtr::setNext(NodeAtr* newN) {
	this->next = newN;
}
bool NodeAtr::isEmpty() {
	if (valA.getSize() <= 0)
		return 1;
	return 0;
}
String& NodeAtr::getValAref() {
	return this->valA;
}
NodeAtr::~NodeAtr() {
	if (this != nullptr && next != nullptr)
		delete next;
}