#pragma once
#include <iostream>
#include "blok.h"
#include "nodeatr.h"

ostream& operator<<(ostream& out, Blok& b) {
	out << "selektory:\n";
	for (int i = 0; i < b.selektory.getSize(); i++)
		out << b.selektory[i] << ", ";
	out << "\natrybuty:\n";
	out << endl;
	return out;
}
ostream& operator<<(std::ostream& out, const String& s) {
	if (s.getVal() != nullptr)
		out << s.getVal();
	return out;
}
ostream& operator<<(ostream& out, const Node& n) {
	if(n.val != nullptr)
		out << n.val;
	return out;
}
ostream& operator<<(ostream& out, const NodeAtr& n) {
	out << n.valA.getSize();
	out << n.valA.getSize();
	if (n.valV != nullptr && n.valA != nullptr)
		out << n.valA << " : " << n.valV;;
	return out;
}
String operator+(const char c, const String& s) {
	String result;
	result.val = new char[s.size + 1];
	result.val[0] = c;
	result.size = s.size + 1;

	for (int i = 1; i < result.size; i++)
		result.val[i] = s.val[i - 1];
	return result;
}