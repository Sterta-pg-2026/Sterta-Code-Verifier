#include "tablelist.h"

tableList::tableList() {
	head = nullptr;
	tail = nullptr;
	size = 0;
}
int tableList::getSize()const 
{
	return size;
}


int tableList::numberOfSections()const
{
	int counter = 0;
	if (head == nullptr) {

		return counter;
	}
	tableNode* curr = head;
	while (curr != nullptr) {
		counter += curr->singleSize;
		curr = curr->next;
	}
	return counter;
}

void tableList::appendData(selectorsAndBlocks data)
{
	if (tail == nullptr) {
		tableNode* tmp = new tableNode;
		tmp->appendData(data);
		tail = tmp;
		head = tmp;
		size++;
	}
	else {
		if (tail->appendData(data)) {

		}
		else {
			tableNode* tmp = new tableNode;
			tmp->appendData(data);
			tmp->prev = tail;
			tail->next = tmp;
			tail = tmp;
			size++;
		}
	}

};

void tableList::numberOfSelectors(int helpNumber)const {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
			
				std::cout << pamietaj << ",S,? == " << curr->tab[helpNumber - 1].selectors.getSize() << std::endl;
			return;
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}

}

void tableList::selectorFromBLock(int helpNumber, int helpSelector)const {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
				if (curr->tab[helpNumber - 1].selectors.getValueAtPosition(helpSelector - 1) != "") {
					std::cout << pamietaj << ",S," << helpSelector << " == " << curr->tab[helpNumber - 1].selectors.getValueAtPosition(helpSelector - 1) << std::endl;
				}
				return;
			
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}
}

void tableList::deleteFromBlock(int helpNumber, CustomString nameToRemove) {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
				if (curr->deleteFromBlock(helpNumber, nameToRemove)) {
					std::cout << pamietaj << ",D," << nameToRemove << " == deleted" << std::endl;
				}
				if (curr->singleSize == 0) {
					size--;
					curr = nullptr;
				}
				return;
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}
}

void tableList::deleteSection(int helpNumber) {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
			
				if (curr->deleteSec(helpNumber)) 
				{
					std::cout << pamietaj << ",D,* == deleted" << std::endl;
				}
				if (curr->singleSize == 0) {
					size--;
					curr = nullptr;
				}
				return;
			
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}
}

void tableList::Efunction(CustomString selName, CustomString attrname)const {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	tableNode* curr = tail;
	while (curr != nullptr) {
		if (curr->lookFromBehind(selName, attrname)) {
			break;
		}
		curr = curr->prev;
	}
}

int tableList::counSelectorByName(CustomString name)const {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return 0;
	}
	int counter = 0;
	tableNode* curr = head;
	while (curr != nullptr) {
		counter += curr->countSelctorByName(name);
		curr = curr->next;
	}
	return counter;
}

void tableList:: attributeFromBlock(int helpNumber, CustomString nameHelp)const
{
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
				if (curr->tab[helpNumber - 1].blocks.getDataByName(nameHelp) != "")
				{
					std::cout << pamietaj << ",A," << nameHelp << " == " << curr->tab[helpNumber - 1].blocks.getDataByName(nameHelp) << std::endl;
				}
				return;
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}
}

void tableList::numberOfAttrinutes(int helpNumber)const
{
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return;
	}
	int pamietaj = helpNumber;
	tableNode* curr = head;
	while (curr != nullptr) {
		if (helpNumber <= curr->singleSize) {
			std::cout << pamietaj << ",A,? == " << curr->tab[helpNumber - 1].blocks.getSize() << std::endl;
			return;
		}
		helpNumber -= curr->singleSize;
		curr = curr->next;
	}
}

int tableList::countAtrrByName(CustomString name)const {
	if (head == nullptr) {
		std::cout << "List is empty\n";
		return 0;
	}
	int counter = 0;
	tableNode* curr = head;
	while (curr != nullptr) {
		counter += curr->countAtrrByName(name);
		curr = curr->next;
	}
	return counter;
}

void tableList::clearList() 
{
		tableNode* current = head;
		while (current != nullptr) {
			tableNode* temp = current;
			current = current->next;
			delete temp;
		}
		head = nullptr;
		tail = nullptr;
		size = 0;
	
}