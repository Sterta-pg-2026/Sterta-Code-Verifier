#pragma once
#include "customstrin.h"
#include "blocklist.h"
#include "selectorslist.h"
#include <iostream>
#define T 13



struct selectorsAndBlocks 
{
	selectorList selectors;
	BlockList blocks;
};

struct tableNode 
{

	selectorsAndBlocks tab[T];
	tableNode* next;
	tableNode* prev;
	int singleSize = 0;

	tableNode() 
	{
		next = nullptr;
		prev = nullptr;
	}
	bool appendData(const selectorsAndBlocks &data) 
	{
		if (singleSize < T) 
		{
			tab[singleSize] = data;
			singleSize++;
			return true;
		}
		else 
		{
			return false;
		}
	}
	int countAtrrByName(CustomString name)const 
	{
		int counter = 0;
		for (int i = 0; i < singleSize; i++) 
		{
			counter += tab[i].blocks.countByName(name);
		}
		return counter;
	}
	int countSelctorByName(CustomString name)const {
		int counter = 0;
		for (int i = 0; i < singleSize; i++) {
			counter += tab[i].selectors.countByName(name);
		}
		return counter;
	}
	bool lookFromBehind(CustomString name, CustomString attrName)const {
		for (int i = singleSize - 1; i >= 0; i--) {
			if (tab[i].selectors.lookForNameBehind(name)) 
			{
				if (tab[i].blocks.getDataByName(attrName) != "")
				{
					std::cout << name << ",E," << attrName << " == " << tab[i].blocks.getDataByName(attrName) << std::endl;
					return true;
				}

			}
		}
		return false;
	}
	bool deleteSec(int helpNumber) 
	{
		if (helpNumber > singleSize) 
		{
			return false;
		}
		else if (helpNumber == singleSize) 
		{
			tab[helpNumber - 1].selectors.removeList();
			tab[helpNumber - 1].blocks.removeList();
			singleSize--;
			return true;
		}
		else 
		{
			tab[helpNumber - 1].selectors.removeList();
			tab[helpNumber - 1].blocks.removeList();
			for (int i = helpNumber - 1; i < singleSize - 1; i++) 
			{
				tab[i] = tab[i + 1];
			}
			singleSize--;
			return true;
		}
	}
	bool deleteFromBlock(int helpNumber, CustomString nameToRemove)
	{
		if (tab[helpNumber - 1].blocks.removeByName(nameToRemove)) {
			if (tab[helpNumber - 1].blocks.getSize() == 0) {
				if (helpNumber == singleSize) {
					tab[helpNumber - 1].selectors.removeList();
					tab[helpNumber - 1].blocks.removeList();
					singleSize--;
					return true;
				}
				else {
					tab[helpNumber - 1].selectors.removeList();
					tab[helpNumber - 1].blocks.removeList();
					for (int i = helpNumber - 1; i < singleSize - 1; i++) {
						tab[i] = tab[i + 1];
					}
					singleSize--;
				}
			}
			return true;
		}
		else
		{
			return false;
		}
	}
};

class tableList {
private:
	tableNode* head;
	tableNode* tail;
	int size;
public:
	tableList();
	int getSize() const;
	
	void appendData(selectorsAndBlocks data);

	int numberOfSections() const;

	void numberOfSelectors(int helpNumber)const;
	void numberOfAttrinutes(int helpNumber)const;

	void selectorFromBLock(int helpNumber, int helpSelector)const;
	void attributeFromBlock(int helpNumber, CustomString nameHelp)const;

	int countAtrrByName(CustomString name)const;
	int counSelectorByName(CustomString name)const;

	void Efunction(CustomString selName, CustomString attrname)const;

	void deleteSection(int helpNumber);
	void deleteFromBlock(int helpNumber, CustomString nameToRemove);

	void clearList();
	
};