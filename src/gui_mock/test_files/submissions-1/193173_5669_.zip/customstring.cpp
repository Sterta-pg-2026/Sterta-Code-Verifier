#define _CRT_SECURE_NO_WARNINGS
#include "customstrin.h"
#include <cstring>

CustomString::CustomString() : data(nullptr), length(0) {}

CustomString::CustomString(const char* str) : length(strlen(str)) {
    data = new char[length + 1];
    strcpy(data, str);
}

CustomString::CustomString(const CustomString& other) : length(other.length) {
    data = new char[length + 1];
    strcpy(data, other.data);
}

CustomString::~CustomString() {
    delete[] data;
}

CustomString& CustomString::operator=(const CustomString& other) {
    if (this != &other) {
        delete[] data;
        length = other.length;
        data = new char[length + 1];
        strcpy(data, other.data);
    }
    return *this;
}

CustomString CustomString::operator+(const CustomString& other) const {
    char* new_data = new char[length + other.length + 1];
    strcpy(new_data, data);
    strcat(new_data, other.data);
    CustomString result(new_data);
    delete[] new_data;
    return result;
}

bool CustomString::operator==(const CustomString& other) const {
    return strcmp(data, other.data) == 0;
}

bool CustomString::operator!=(const CustomString& other) const {
    return strcmp(data, other.data) != 0;
}

char& CustomString::operator[](int index) {
    if (index < 0 || index >= length) {
        return data[0];
    }
    return data[index];
}

const char& CustomString::operator[](int index) const {
    if (index < 0 || index >= length) {
        return data[0];
    }
    return data[index];
}

std::ostream& operator<<(std::ostream& os, const CustomString& str) {
    os << str.data;
   return os;
}

std::istream& operator>>(std::istream& is, CustomString& str) {
    const int BUFFER_SIZE = 1024;
    char buffer[BUFFER_SIZE];
    is.getline(buffer, BUFFER_SIZE);
    CustomString temp(buffer);
    str = temp;
    return is;
}

void CustomString::append(int c) {
    char* new_data = new char[length + 2];
    std::strcpy(new_data, data);
    new_data[length] = static_cast<char>(c);
    new_data[length + 1] = '\0';
    delete[] data;
    data = new_data;
    length++;
}

void CustomString::trim() {
    int start = 0;
    int end = length - 1;

    while (start <= end && (data[start] == ' ' || data[start] == '\t' || data[start] == '\n')) {
        start++;
    }

    while (end >= start && (data[end] == ' ' || data[end] == '\t' || data[end] == '\n')) {
        end--;
    }

    for (int i = start; i <= end; i++) {
        data[i - start] = data[i];
    }

    data[end - start + 1] = '\0';

    length = end - start + 1;
}
int CustomString::toInt() const {
    int result = 0;
    int sign = 1;
    int i = 0;

    if (data[0] == '-') {
        sign = -1;
        i++;
    }

    for (; i < length; i++) {
        if (data[i] < '0' || data[i] > '9') {
            return 0;
        }
        result = result * 10 + (data[i] - '0');
    }

    return result * sign;
}