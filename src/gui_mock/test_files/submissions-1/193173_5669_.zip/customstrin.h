#define _CRT_SECURE_NO_WARNINGS
#pragma once
#ifndef CUSTOMSTRING_H
#define CUSTOMSTRING_H

#include <iostream>

class CustomString 
{
    char* data;
    int length;
public:
    CustomString();
    CustomString(const char* str);
    CustomString(const CustomString& other);
    void append(int c);
    ~CustomString();

    CustomString& operator=(const CustomString& other);
    CustomString operator+(const CustomString& other) const;
    bool operator==(const CustomString& other) const;
    bool operator!=(const CustomString& other) const;

    char& operator[](int index);
    const char& operator[](int index) const;

    friend std::ostream& operator<<(std::ostream& os, const CustomString& str);
    friend std::istream& operator>>(std::istream& is, CustomString& str);
    void trim();
    int toInt() const;
    
};

#endif