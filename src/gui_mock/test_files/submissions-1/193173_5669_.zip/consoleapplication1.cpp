#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "customstrin.h"
#include "selectorslist.h"
#include "tablelist.h"

using namespace std;
#define CSS 0
#define KOMENDY 1
#define Selektory 0
#define Atrybuty 1


int main() {
    tableList main;
    bool inMode=CSS;
    bool decision = Selektory;
    int singleCharacter='s';
    while (singleCharacter!=EOF)
    {
        selectorList selectors;
        BlockList blocks;
        CustomString input = "";
        CustomString nameToRemember = "";
        while (singleCharacter != EOF)
        {
            singleCharacter = getchar();
            if (singleCharacter == '\t'|| singleCharacter == '\n' || singleCharacter == '\v' ||singleCharacter == '\f'|| singleCharacter == '\r') {
                continue;
            }
            if (inMode == CSS) {
                if (decision == Selektory) {
                    if (singleCharacter == ',') {
                        input.trim();
                        selectors.insertFront(input);
                        input = "";
                        continue;
                    }
                    else if (singleCharacter == '{') {
                        input.trim();
                        selectors.insertFront(input);
                        input = "";
                        decision = Atrybuty;
                        continue;
                    }
                    else {
                        input.append(singleCharacter);
                    }
                }
                else if (decision == Atrybuty) {
                    if (singleCharacter == ':') {
                        nameToRemember = input;
                        input = "";
                    }
                    else if (singleCharacter == ';') {
                        input.trim();
                        nameToRemember.trim();
                        blocks.insertFront(nameToRemember, input);
                        input = "";
                        nameToRemember = "";
                        continue;
                    }
                    else if (singleCharacter == '}') 
                    {
                        if (nameToRemember != "") 
                        {
                            input.trim();
                            blocks.insertFront(nameToRemember, input);
                            input = "";
                            nameToRemember = "";
                        }
                        decision = Selektory;
                        if (blocks.getSize() != 0) 
                        {
                            selectorsAndBlocks help{selectors,blocks};
                            main.appendData(help);
                        }
                        break;
                    }
                    else 
                    {
                        input.append(singleCharacter);
                    }
                }
                if (input == "????") {
                    inMode = KOMENDY;
                    input = "";
                    continue;
                }
            }
            else if (inMode == KOMENDY) 
            {
                if (singleCharacter == '*') {
                    if (input == "***") {
                        inMode = CSS;
                        input = "";
                    }
                    else {
                        input.append(singleCharacter);
                    }
                }
                else if (singleCharacter == '?') {
                    if (input == "") {
                        std::cout <<"? == "<< main.numberOfSections() << std::endl;
                        input = "";
                    }
                }
                else if (singleCharacter == ',') {
                    singleCharacter = getchar();
                    if(singleCharacter=='S')
                    {
                        singleCharacter = getchar();
                        if (singleCharacter == '\n')break;
                        singleCharacter = getchar();
                        if (singleCharacter == '?') {
                            int helpNumber = input.toInt();
                            if (helpNumber != 0) {
                                input = "";
                                main.numberOfSelectors(helpNumber);
                            }
                            else 
                            {
                                std::cout<<input<<",S,? == " << main.counSelectorByName(input) << std::endl;
                                input = "";
                            }
                        }
                        else {
                            CustomString temp="";
                            temp.append(singleCharacter);
                            CustomString abc;
                            std::cin >> abc;
                            temp = temp + abc;
                            int selectoHelp = temp.toInt();
                            int blockHelp = input.toInt();
                            main.selectorFromBLock(blockHelp, selectoHelp);
                            input = "";
                        }
                    }
                    else if (singleCharacter == 'A') {
                        singleCharacter = getchar();
                        if (singleCharacter == '\n')break;
                        singleCharacter = getchar();
                        if (singleCharacter == '?') {
                            int helpNumber = input.toInt();
                            if (helpNumber != 0)
                            {
                                input = "";
                                main.numberOfAttrinutes(helpNumber);
                            }
                            else {
                                std::cout<<input<<",A,? == " << main.countAtrrByName(input) << std::endl;
                                input = "";
                            }
                        }
                        else {
                            CustomString temp = "";
                            temp.append(singleCharacter);
                            CustomString abc;
                            std::cin >> abc;
                            temp = temp + abc;  
                            int blockHelp = input.toInt();
                            main.attributeFromBlock(blockHelp, temp);
                            input = "";
                        }
                    }
                    else if (singleCharacter == 'E') {
                        singleCharacter = getchar();
                        CustomString abc;
                        std::cin >> abc;
                        main.Efunction(input, abc);
                        input = "";
                    }
                    else if (singleCharacter == 'D') {
                        int helpNumber = input.toInt();
                        CustomString abc;
                        singleCharacter = getchar();
                        cin >> abc;
                        if (abc == "*") {
                            main.deleteSection(helpNumber);
                            input = "";
                        }
                        else {
                            main.deleteFromBlock(helpNumber, abc);
                            input = "";
                        }
                    }
                    else {
                        CustomString abc; 
                        cin >> abc;
                        input = "";
                    }
                }
                else {
                    input.append(singleCharacter);
                }
            }
        }
    }
    main.clearList();
    return 0;
}
