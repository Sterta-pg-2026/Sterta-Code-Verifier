#include "blocklist.h"

BlockList::BlockList()
{
    head = nullptr;
    tail = nullptr;
    size = 0;
}


void BlockList::insertFront(CustomString name, CustomString data)
{
    blockNode* current = head;
    while (current != nullptr) {
        if (current->name == name) {
            current->data = data;
            return;
        }
        current = current->next;
    }

    blockNode* newNode = new blockNode;
    newNode->data = data;
    newNode->name = name;
    newNode->prev = tail;
    newNode->next = nullptr;
    if (tail == nullptr) {
        head = newNode;
    }
    else {
        tail->next = newNode;
    }
    tail = newNode;
    size++;
}


int BlockList::getSize()const {
    return size;
}

CustomString BlockList::getDataByName(CustomString name)const
{
    blockNode* currNode = head;
    while (currNode != nullptr)
    {
        if (currNode->name == name)
        {
            return currNode->data;
        }
        currNode = currNode->next;
    }
    return CustomString("");
}

int BlockList::countByName(CustomString name)const
{
    int count = 0;
    blockNode* curr = head;
    while (curr != nullptr) {
        if (curr->name == name) {
            count++;
        }
        curr = curr->next;
    }
    return count;
}

bool BlockList::removeByName(CustomString name)
{
    blockNode* curr = head;

    while (curr != nullptr) {

        if (curr->name == name) {

            if (curr == head) {
                head = curr->next;
                if (head != nullptr) {
                    head->prev = nullptr;
                }
            }

            else if (curr == tail) {
                tail = curr->prev;
                tail->next = nullptr;
            }

            else {
                curr->prev->next = curr->next;
                curr->next->prev = curr->prev;
            }

            delete curr;
            size--;

            return true;
        }

        curr = curr->next;
    }
    return false;
}

void BlockList::removeList() {
    blockNode* current = head;
    while (current != nullptr) {
        blockNode* temp = current;
        current = current->next;
        delete temp;
    }
    head = nullptr;
    tail = nullptr;
    size = 0;
}
