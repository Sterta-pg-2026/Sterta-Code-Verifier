#include "selectorslist.h"

selectorList::selectorList() {
    head = nullptr;
    tail = nullptr;
    size = 0;
}

int selectorList::getSize()const {
    return size;
}


void selectorList::insertFront(const CustomString& data) {
    selectorNode* curr = head;
    while (curr != nullptr) {
        if (curr->data == data) {
            return;
        }
        curr = curr->next;
    }
    selectorNode* newNode = new selectorNode;
    newNode->data = data;
    newNode->prev = tail;
    newNode->next = nullptr;
    if (tail == nullptr) {
        head = newNode;
    }
    else {
        tail->next = newNode;
    }
    tail = newNode;
    if (data != "") {

    size++;
    }
}

CustomString selectorList::getValueAtPosition(int position) const {
    if (position < 0 || position >= size) {
        return CustomString("");
    }
    
    selectorNode* curr = head;
    for (int i = 0; i < position; i++) {
        curr = curr->next;
    }

    return curr->data;
}


int selectorList::countByName(CustomString name)const
{
    int count = 0;
    selectorNode* curr = head;
    while (curr != nullptr) {
        if (curr->data == name) {
            count++;
        }
        curr = curr->next;
    }

    return count;
}

bool selectorList::lookForNameBehind(CustomString name)const {
    selectorNode* curr = tail;
    while (curr != nullptr) {
        if (curr->data == name || curr->data == "") {
            return true;
        }
        curr = curr->prev;
    }
    return false;
}

void selectorList::removeList() {
    selectorNode* current = head;
    while (current != nullptr) {
        selectorNode* temp = current;
        current = current->next;
        delete temp;
    }
    head = nullptr;
    tail = nullptr;
    size = 0;
}