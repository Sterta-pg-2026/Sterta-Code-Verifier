#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

#include <iostream>
#include "customstrin.h"

struct selectorNode {
    CustomString data;
    selectorNode* next;
    selectorNode* prev;
};

class selectorList {
private:
    selectorNode* head;
    selectorNode* tail;
    int size = 0;

public:
    selectorList();

    void insertFront(const CustomString& data);
    int getSize()const;

    CustomString getValueAtPosition(int position) const;
    int countByName(CustomString name)const;
    bool lookForNameBehind(CustomString name)const;
    void removeList();
};

#endif