#ifndef BLOCKLIST_H
#define BLOCKLIST_H

#include "customstrin.h"

struct blockNode
{
    CustomString name;
    CustomString data;
    blockNode* next;
    blockNode* prev;
};

class BlockList
{
private:
    blockNode* head;
    blockNode* tail;
    int size;
public:
    BlockList();

    void insertFront(CustomString name, CustomString data);
    int getSize()const;

    CustomString getDataByName(CustomString name)const;
    int countByName(CustomString name)const;
    bool removeByName(CustomString name);
    void removeList();

};

#endif 