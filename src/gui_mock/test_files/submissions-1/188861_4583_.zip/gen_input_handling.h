#pragma once

#include<iostream>
#include "funkcje_bez_kategorii.h"
#include "obsluga_komend.h"
#include "obsluga_wejscia_css.h"
#include "struktury.h"

//CSS--------------------------------------------------------------------------------------------------------------
void CssInputHandling(Lista_Sekcji& Ogolna_lista)
{
    char input_css[256] = {};
    bool czyCzytamySel = true;
    while (std::cin >> input_css)
    {
        if (strcmp(input_css, "????") == 0)
        {
            return;
        }
        else
        {
            if (czyCzytamySel == true)
            {
                if (strcmp(input_css, "{") == 0) //poczatek bloku atrybutow
                {
                    czyCzytamySel = false;
                }
                else if (input_css[0] == '{')
                {
                    parsowanie_atr_bez_spacji(input_css, Ogolna_lista);
                    czyCzytamySel = false;
                }
                else 
                {
                    Czytanie_selektorow(input_css, Ogolna_lista);
                }
            }
            else
            {
                if (strcmp(input_css, "}") == 0 || input_css[ile_znakow_aka_sizeof(input_css)-1] == '}')
                {
                    czyCzytamySel = true;
                }
                else 
                {
                    Czytanie_atrybutow(input_css, Ogolna_lista);
                }
            }

        }
    }
}

//KOMENDY----------------------------------------------------------------------------------------------------------
void Comm_handling_numbers_first(char* input, Lista_Sekcji& Ogolna_lista)
{
    char actuall_command = get_command(input);

    if (actuall_command == 'S')
    {
        S_handling_num_first(input);
    }
    else if (actuall_command == 'A')
    {
        A_handling_num_first(input);
    }
    else if (actuall_command == 'D')
    {
        D_handling(input);
    }
}
void Comm_handling_words_first(char* input, Lista_Sekcji& Ogolna_lista)
{
    if (strcmp(input, "?") == 0)
    {
        int liczba_sekcji_css = 0;

        std::cout << "? == " << liczba_sekcji_css << "\n";
    }
}

void CommandHandling(Lista_Sekcji& Ogolna_lista)
{
    char input_comm[256] = {};
    while (std::cin >> input_comm)
    {
        if (strcmp(input_comm, "****") == 0)
        {
            return;
        }
        else if (input_comm[0] >= '0' && input_comm[0] <= '9')
        {
            Comm_handling_numbers_first(input_comm, Ogolna_lista);
        }
        else
        {
            Comm_handling_words_first(input_comm, Ogolna_lista);
        }
    }
}

//OGOLNY--------------------------------------------------------------------------------------------------------------
void MainInput(Lista_Sekcji& Ogolna_lista)
{
    bool areWeInputingCommands = false;
    while (!std::cin.fail())   //it starts with css
    {
        if (areWeInputingCommands == true)
        {
            CommandHandling(Ogolna_lista);
            areWeInputingCommands = false;
        }
        else {
            CssInputHandling(Ogolna_lista);
            areWeInputingCommands = true;
        }
    }
}