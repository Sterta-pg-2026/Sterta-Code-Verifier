#pragma once

#include <iostream>
#include "struktury.h"

int ile_znakow_aka_sizeof(char* input)
{
    int ilosc = 0;
    do
    {
        ilosc++;
    } while (input[ilosc] != '\0');

    return ilosc;
}

int znajdz_znak(char* input, int ktory_znak, char szuk_znak)
{
    int i = 0;
    int dlugosc_inputu = ile_znakow_aka_sizeof(input);
    int znalezione_znaki = 0;
    while (i < dlugosc_inputu)
    {
        if (input[i] == szuk_znak)
        {
            znalezione_znaki++;
            if (znalezione_znaki == ktory_znak)
                return i;
        }
        i++;
    }

    return -1;
}

//could these two be condensed into one? probably - alas i do not have the mental energy to do the math necessary rn
int get_first_number(char* input)
{
    int liczba1 = 0;
    if (input[1] == ',')  //liczba jednocyfrowa
    {
        char liczb1_char_ver = input[0];
        liczba1 = liczb1_char_ver - '0';
    }
    else
    {
        int ilosc_cyfr = znajdz_znak(input, 1, ',');
        char* liczba1_char_arr = new char[ilosc_cyfr + 1];

        for (int j = 0; j < ilosc_cyfr; j++)
        {
            liczba1_char_arr[j] = input[j];
        }
        liczba1_char_arr[ilosc_cyfr] = '\0';

        liczba1 = atoi(liczba1_char_arr);

        delete[] liczba1_char_arr;
    }

    return liczba1;
}

int get_2nd_number(char* input)
{
    int input_length = ile_znakow_aka_sizeof(input);
    int liczba1 = 0;
    if (input[input_length - 2] == ',')  //liczba jednocyfrowa
    {
        char liczb1_char_ver = input[input_length - 1];
        liczba1 = liczb1_char_ver - '0';
    }
    else
    {
        int miejsce_dr_przec = znajdz_znak(input, 2, ',');
        int ilosc_cyfr = input_length - 1 - miejsce_dr_przec;
        char* liczba1_char_arr = new char[ilosc_cyfr + 1];
        int i = 0;
        for (int j = miejsce_dr_przec + 1; j < input_length; j++) {
            liczba1_char_arr[i] = input[j];
            i++;
        }
        liczba1_char_arr[ilosc_cyfr] = '\0';
        liczba1 = atoi(liczba1_char_arr);

        delete[] liczba1_char_arr;
    }

    return liczba1;
}

char get_command(char* input)
{
    int miejsce_przecinka = znajdz_znak(input, 1, ',');
    return input[miejsce_przecinka + 1];
}

char get_name_for_comm()
{
    return 'b';
}