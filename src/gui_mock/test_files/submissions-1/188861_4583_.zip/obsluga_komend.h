#pragma once
#include<iostream>
#include "funkcje_bez_kategorii.h"
#include "struktury.h"

void S_handling_num_first(char *input)
{
	int number1 = get_first_number(input);
	int liczba_selektorow = 0;

	if (input[znajdz_znak(input, 2, ',') + 1] == '?')
	{
		//jeseli istnieje
		std::cout << number1 << ",S,? == " << liczba_selektorow<<"\n";
		//jesli nie to return ?
	}
	else
	{
		int number2 = get_2nd_number(input);
		

		std::cout << number1 << ",S," << number2 << " == " /* << znal_selektor */<< "\n";
	}
}

void A_handling_num_first(char* input)
{
	int number1 = get_first_number(input);
	int liczba_atrybutow = 0;

	if (input[znajdz_znak(input, 2, ',') + 1] == '?')
	{
		//jeseli istnieje
		std::cout << number1 << ",S,? == " << liczba_atrybutow << "\n";
		//jesli nie to return ?
	}
	else
	{
		int number2 = get_2nd_number(input);


		std::cout << number1 << ",S," << number2 << " == " /* << znal_atrybut */ << "\n";
	}
}

void D_handling(char* input)
{
	int number1 = get_first_number(input);

	if (input[znajdz_znak(input, 2, ',') + 1] == '*')
	{
		std::cout << "deleted\n";
	}
	else
	{
		std::cout << "deleted\n";
	}
}