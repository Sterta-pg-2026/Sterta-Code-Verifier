#pragma once

#include<iostream>
#include "funkcje_bez_kategorii.h"

#define T 8

struct Atrybut
{
	char* nazwa;
	char* wartosc;
	Atrybut* next;
	Atrybut* prev;
};

struct Lista_Atrybutow
{
	Atrybut* root = nullptr;
	Atrybut* tail = nullptr;
};

struct Selektor
{
	char* nazwa;
	Selektor* next;
	Selektor* prev;
};

struct Lista_Selektorow
{
	Selektor* root = nullptr;
	Selektor* tail = nullptr;
};

struct Sekcja
{
	Sekcja* next = nullptr;
	Sekcja* prev = nullptr;
	Sekcja* previous = nullptr;
	Lista_Atrybutow lista_a;
	Lista_Selektorow lista_s;
	int nr_sekcji = 0;
};

/*
struct Tablica_sekcji
{
	Sekcja tablica_sekcji[T];
	int zajete_struktury;
};*/

//i have no idea whether this is how this is supposed to work. most likely not tbh cause this is so bloody confusing
// for now it's without the block cause the block is just confusing me
struct Lista_Sekcji	
{
	//Tablica_sekcji blok;
	Sekcja* root;
	Sekcja* tail;
	int ilosc_istniejacych_sekcji = 0;
};
