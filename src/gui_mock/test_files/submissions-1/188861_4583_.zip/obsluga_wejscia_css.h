#pragma once

#include <iostream>
#include "funkcje_bez_kategorii.h"
#include "funkcje_listy.h"
#include "struktury.h"


void Czytanie_selektorow(char *nazwa, Lista_Sekcji& Ogolna_lista)
{
    
}

void Czytanie_atrybutow(char* nazwa,struct Lista_Sekcji& Ogolna_lista)
{
    char wartosc[256]={ };
    std::cin >> wartosc;    //problemy jesli wartosc ma w sobie spacje (tj. chyba tylko wtedy gdy jest w ""
 }

//gdy atrybut wyglada np tak -> {color: #0066CB;}
void parsowanie_atr_bez_spacji(char* input, Lista_Sekcji& Ogolna_lista)
{
    char* tmp_input_css = new char[ile_znakow_aka_sizeof(input) - 1];
    for (int i = 0; i < ile_znakow_aka_sizeof(input) - 1; i++)
    {
        tmp_input_css[i] = input[i + 1];
    }
    Czytanie_atrybutow(tmp_input_css, Ogolna_lista);
    delete[] tmp_input_css; //will this even work in this place?
}
