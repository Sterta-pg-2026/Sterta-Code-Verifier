#pragma once

#include<iostream>
#include "struktury.h"

void inicjalizacja_listy_glownej(struct Lista_Sekcji& Lista)
{
	Lista.root = nullptr;
	Lista.tail = nullptr;
	Lista.ilosc_istniejacych_sekcji = 0;
}


//ATRYBUTY

void dodaj_atrybut(struct Lista_Atrybutow& lista, char* nazwa_at, char* wartosc_at)
{
	Atrybut* pom = new Atrybut;
	pom->nazwa = nazwa_at;
	pom->wartosc = wartosc_at;
	pom->next = nullptr;
	pom->prev = nullptr;

	Atrybut* tmp_tail = lista.tail;

	if (lista.root == nullptr && lista.tail == nullptr)	//pusta lista
	{
		lista.root = pom;
		lista.tail = pom;
	}
	else if (lista.root == lista.tail)	//tylko jeden atrybut
	{
		lista.root->next = pom;
		pom->prev = lista.root;
		lista.tail = pom;
	}
	else	// >2 atrybuty jus na liscie, dodajemy na koniec 
	{
		pom->prev = tmp_tail;
		tmp_tail->next = pom;
		lista.tail = pom;
	}
}

void usun_atrybut()
{

}

//SELEKTORY--------------------------------------
void dodaj_selektor(struct Lista_Selektorow& lista, char* nazwa_sel)
{
	Selektor* pom = new Selektor;
	pom->nazwa = nazwa_sel;
	pom->next = nullptr;
	pom->prev = nullptr;

	Selektor* tmp_tail = lista.tail;

	//it kinda needs to be redundant since these are two different types of lists are passed as arguments
	if (lista.root == nullptr && lista.tail == nullptr)	//pusta lista
	{
		lista.root = pom;
		lista.tail = pom;
	}
	else if (lista.root == lista.tail)	//tylko jeden atrybut
	{
		lista.root->next = pom;
		pom->prev = lista.root;
		lista.tail = pom;
	}
	else	// >2 atrybuty jus na liscie, dodajemy na koniec 
	{
		pom->prev = tmp_tail;
		tmp_tail->next = pom;
		lista.tail = pom;
	}
}

void usun_selektor()
{

}

//TABLICA
/*
void dodaj_do_tablicy()
{

}

void usun_z_tablicy()
{

}
*/
//CALA LISTA
void dodaj_sekcje(struct Lista_Sekcji& lista, struct Lista_Atrybutow & lista_aa, struct Lista_Selektorow& lista_ss)
{
	Sekcja* pom = new Sekcja;
	pom->next = nullptr;
	pom->prev = nullptr;
	pom->lista_a = lista_aa;
	pom->lista_s = lista_ss;
	pom->nr_sekcji = 0;

	Sekcja* tmp_tail = lista.tail;

	//it kinda needs to be redundant since these are two different types of lists are passed as arguments
	if (lista.root == nullptr && lista.tail == nullptr)	//pusta lista
	{
		pom->nr_sekcji = 1;
		lista.root = pom;
		lista.tail = pom;
	}
	else if (lista.root == lista.tail)	//tylko jeden atrybut
	{
		pom->nr_sekcji = 2;
		lista.root->next = pom;
		pom->prev = lista.root;
		lista.tail = pom;
	}
	else	// >2 atrybuty jus na liscie, dodajemy na koniec 
	{
		pom->nr_sekcji = tmp_tail->nr_sekcji + 1;
		pom->prev = tmp_tail;
		tmp_tail->next = pom;
		lista.tail = pom;
	}
}

void usun_sekcje()
{

}