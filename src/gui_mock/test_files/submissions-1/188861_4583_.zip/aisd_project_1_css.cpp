﻿//Alicja Sobiech; AiSD project #1
#include <iostream>
#include "funkcje_bez_kategorii.h"
#include "gen_input_handling.h"
#include "funkcje_listy.h"
#include "struktury.h"

int main()
{
    struct Lista_Sekcji Ogolna_lista;
    inicjalizacja_listy_glownej(Ogolna_lista);


    MainInput(Ogolna_lista);
    return 0;
}
