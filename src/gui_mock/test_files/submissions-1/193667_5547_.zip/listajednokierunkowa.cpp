#include <iostream>
#include "listajednokierunkowa.h"


using namespace std;

void AddSelectorFront(List** head, char string[BUFFERSIZE]) {
	List* current = new List;
	for (int i = 0; i < BUFFERSIZE; i++) {
		current->data[i] = string[i];
	}
	current->next = (*head);
	*head = current;
}

void ShowSelectorByIndex(List* head, int position, char s[BUFFERSIZE]) {
	if (head == NULL) {
		return;
	}
	else {
		List* current = new List;
		current = head;
		if (position > 0) {
			for (int i = 0; i < position; i++) {
				current = current->next;
			}
		}
		if (current != NULL) {
			cout << s << " == " << current->data << endl;
		}
	}
}


void DeleteFirstSelector(List** head) {
	List* tmp = NULL;
	if (*head != NULL) {
		tmp = (*head)->next;
		delete* head;
		*head = tmp;
	}
}

void DeleteLastSelector(List** head) {
	if ((*head)->next == NULL) {
		*head = NULL;
	}
	else {
		List* current = *head;
		while (current->next->next != NULL) {
			current = current->next;
		}
		delete current->next;
		current->next = NULL;
	}
}

void DeleteSelectorByIndex(List** head, int position) {
	if (position == 0) {
		DeleteFirstSelector(head);
	}
	else {
		List* current = *head;
		List* tmp;
		for (int i = 0; i < position; i++) {
			current = current->next;
		}
		tmp = current->next;
		current->next = tmp->next;
		delete tmp;
	}
}


void AddAttributeNameFront(Attributes** head, char string[BUFFERSIZE]) {
	Attributes* current = new Attributes;
	for (int i = 0; i < BUFFERSIZE; i++) {
		current->attributename[i] = string[i];
	}
	current->next = (*head);
	*head = current;
}

int HowManyAttributes(Attributes* head) {
	int counter = 0;
	if (head == NULL) return counter;
	else {
		Attributes* current = head;
		while (current != NULL) {
			counter++;
			current = current->next;
		}
	}
	return counter;
}

void DeleteFirstSelector(Attributes** head) {
	Attributes* tmp = NULL;
	if (*head != NULL) {
		tmp = (*head)->next;
		delete* head;
		*head = tmp;
	}
}

void DeleteLastSelector(Attributes** head) {
	if ((*head)->next == NULL) {
		*head = NULL;
	}
	else {
		Attributes* current = *head;
		while (current->next->next != NULL) {
			current = current->next;
		}
		delete current->next;
		current->next = NULL;
	}
}

void DeleteSelectorByIndex(Attributes** head, int position) {
	if (position == 0) {
		DeleteFirstSelector(head);
	}
	else {
		Attributes* current = *head;
		Attributes* tmp;
		for (int i = 0; i < position; i++) {
			current = current->next;
		}
		tmp = current->next;
		current->next = tmp->next;
		delete tmp;
	}
}

void ShowAttributeNameByIndex(Attributes* head, int position) {
	Attributes* current = new Attributes;
	current = head;
	if (position > 0) {
		for (int i = 0; i < position; i++) {
			current = current->next;
		}
	}
	cout << current->attributename;
}

void ShowAttributeValueByIndex(Attributes* head, int position) {
	Attributes* current = new Attributes;
	current = head;
	if (position > 0) {
		for (int i = 0; i < position; i++) {
			current = current->next;
		}
	}
	cout << current->attributevalue;
}

void ShowAttributeByValue(Attributes* head, char s[BUFFERSIZE], char buffer[BUFFERSIZE]) {
	if (head == NULL) {
		return;
	}
	else {
		int n = 0;
		int m = 0;
		while (s[n] != '\0') {
			n++;
		}
		
		bool isThere = false;
		
		Attributes* current = head;
		while (current != NULL && m != n) {
			m = 0;
			for (int i = 0; i < n; i++) {
				
				if (s[i] == current->attributename[i]) {
					m++;
				}
			}
			if (m != n) {
				current = current->next;
			}
			else {
				isThere = true;
			}
		}
		if (current != NULL) {
			cout << buffer << " == " << current->attributevalue << endl;
		}
		
	}
}



