#pragma once
#define T 8
#define TAB 8
#define ENTER 13
#define ARRAYSIZE 1000
#define BUFFERSIZE 200
#define SPACE 32

struct List { //selektory
	List* next;
	char data[BUFFERSIZE];
};

struct Attributes {
	Attributes* next;
	char attributevalue[BUFFERSIZE];
	char attributename[BUFFERSIZE];
};

struct section {
	bool isUsed;
	List* selectors;
	Attributes* attributes;
};

void AddSelectorFront(List** head, char* string);

void DeleteFirstSelector(List** head);
void DeleteLastSelector(List** head);
void DeleteSelectorByIndex(List** head, int position);
void ShowSelectorByIndex(List* head, int position, char s[BUFFERSIZE]);


void AddAttributeNameFront(Attributes** head, char* string);

int HowManyAttributes(Attributes* head);
void DeleteFirstAttribute(Attributes** head);
void DeleteLastAttribute(Attributes** head);
void DeleteAttributeByIndex(Attributes** head, int position);

void AddAttributeValueBack(Attributes** head, char* string);

void ShowAttributeNameByIndex(Attributes* head, int position);
void ShowAttributeValueByIndex(Attributes* head, int position);


void ShowAttributeByValue(Attributes* head, char s[BUFFERSIZE], char buffer[BUFFERSIZE]);

