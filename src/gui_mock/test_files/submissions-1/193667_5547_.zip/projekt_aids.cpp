#include <iostream>
#include <stdio.h>
#include <ctype.h>
#include "listajednokierunkowa.h"

using namespace std;

struct Node {
	struct Node* next;
	struct Node* previous;
	section sections[T];
	int howManyUsed = 0;
};

void AddBack(Node** head) {
	if (head == NULL) {
		*head = new Node;
		(*head)->next = NULL;
		(*head)->previous = NULL;
	}
	else {
		Node* current = *head;
		while (current->next != NULL) {
			current = current->next;
		}
		current->next = new Node;
		current->next->next = NULL;
		current->next->previous = current;
	}
}

int ListSize(Node* head) {
	int counter = 0;
	if (head == NULL) return counter;
	else {
		Node* current = head;
		while (current != NULL) {
			counter++;
		}
	}
	return counter;
}

void DeleteFront(Node** head) {

	if (head != NULL) {
		if ((*head)->next == NULL) {
			head = NULL;
		}
	}
	else {
		Node* tmp;
		tmp = (*head)->next;
		delete head;
		(*head) = tmp;
		(*head)->previous = NULL;
	}
}

void DeleteBack(Node** head) {
	if ((*head)->next == NULL) {
		*head = NULL;
		return;
	}
	else {
		Node* current = *head;
		while (current->next != NULL) {
			current = current->next;
		}
		current->previous->next = NULL; //sprawdzic
		current->next = NULL; //chyba nie jest potrzebne
		delete current;
	}
}

void ClearBuffer(char buffer[], int& count) {
	count = -1;
	for (int i = 0; i < BUFFERSIZE; i++) {
		buffer[i] = '\0';
	}
}

void ClearInput(char input[], int& index) {
	for (int i = 0; i < ARRAYSIZE; i++) {
		input[i] = '\0';
	}
	index = -1;
}

int CountSelector(char s[BUFFERSIZE], Node* start) {
	int count = 0;
	int n = 0;
	int length = 0;
	int index = 0;
	int breakingPoint = 0;
	if (start == NULL) return count;
	else {
		while (start->previous != NULL) {
			start = start->previous;
		}
		while (s[length] != '\0') {
			length++;
		}
		length++;
		List* current = start->sections[index].selectors;
		while (breakingPoint != 2) {

			if (current == NULL) {
				index++;
				if (index == T) {
					start = start->next;
					index = 0;
				}
				current = start->sections[index].selectors;

				breakingPoint++;
			}
			else {

				breakingPoint = 0;
				for (int i = 0; i < length; i++) {
					if (current->data[i] == s[i]) {
						n++;
					}
					if (n == length) {
						count++;
					}
				}

				n = 0;
				current = current->next;
			}
		}
	}
	return count;
}

int countAttribute(char s[BUFFERSIZE], Node* start) {
	int count = 0;
	int n = 0;
	int length = 0;
	int index = 0;
	int breakingPoint = 0;
	if (start == NULL) return count;
	else {
		while (start->previous != NULL) {
			start = start->previous;
		}
		while (s[length] != '\0') {
			length++;
		}
		length++;
		Attributes* current = start->sections[index].attributes;
 		while (breakingPoint != 2) {

			if (current == NULL) {
				index++;
				if (index == T) {
					start = start->next;
					index = 0;
				}
				current = start->sections[index].attributes;
				breakingPoint++;
			}
			else {
				breakingPoint = 0;
				for (int i = 0; i < length; i++) {
					if (current->attributename[i] == s[i]) {
						n++;
					}
					if (n == length) count++;
				}
				n = 0;
				current = current->next;
			}
		}
	}
	return count;
}

void findElement(char selec[BUFFERSIZE], char name[BUFFERSIZE], Node* start, char buffer[BUFFERSIZE]) {
	int namelen = 0;
	int seleclen = 0;
	int sec = 0;
	int BreakingPoint = 0;
	int index = 0;
	int rightIndex = 0;;
	int count = 0;
	int a = 0;
	int rightSection = 0;
	int whichNode = 0;
	int rightNode = 0;
	bool isThere = false;
	Node* help = start;
	if (start == NULL) return;
	else {
		while (name[namelen] != '\0') {
			namelen++;
		}
		namelen++;
		while (selec[seleclen] != '\0') {
			seleclen++;
		}
		seleclen++;
		//zapamietaj ostatni element

		List* current = help->sections[index].selectors;

		while (BreakingPoint != 2) {
			if (current == NULL) {
				index++;
				if (index == T) {
					help = help->next;
					index = 0;
					whichNode++;
				}
				current = help->sections[index].selectors;
				BreakingPoint++;
				sec = 0;
			}
			else {
				BreakingPoint = 0;
				for (int k = 0; k < seleclen; k++) {
					if (current->data[k] == selec[k]) a++;
				}
				if (a == seleclen) {
					rightIndex = index;
					rightSection = sec;
					rightNode = whichNode;
					isThere = true;
				} a = 0;
				current = current->next;
				sec++;
			}
		}
	}
	while (help->previous != NULL) {
		help = help->previous;
	}
	for (int k = 0; k < rightNode; k++) {
		help = help->next;
	}

	Attributes* tmp = help->sections[rightIndex].attributes;
	/*for (int k = 0; k < rightSection; k++) {
		tmp = tmp->next;
	}*/

	if (isThere == true) {
		ShowAttributeByValue(help->sections[rightIndex].attributes, name, buffer);
	}
}

int sectionsAmount(Node* start) {
	int counter = 0;
	int index = 0;
	Node* current = start;
	while (current != NULL) {
		counter += current->howManyUsed;
		current = current->next;
	}
	return counter;
}

void DeleteAttribute(Node* start, char name[BUFFERSIZE], int& counter, int number, int& Sections) {
	int whichSection = 0;
	Attributes* current = start->sections[number - 1].attributes;
	int count = 0;
	int i = 0;
	int index = 0;
	bool isDup = false;
	bool find = false;
	int chechIfheOnlyOne = 0;
	int howManyAtrr = 0;
	while (name[i] != '\0') {
		i++;
	}
	while (isDup == false) {
		if (current == NULL) {
			break;
		}
		if (current != NULL) {
			for (int j = 0; j < i; j++) {
				if (current->attributename[j] == name[j]) count++;
			}
		}
		if (count == i) {
			isDup = true;
		}
		count = 0;
		if (current != NULL) {
			current = current->next;
			howManyAtrr++;
		}
		index++;
	}
	current = start->sections[number - 1].attributes;
	if (howManyAtrr == 1) {
		delete start->sections[number - 1].selectors;
		delete start->sections[number - 1].attributes;
		counter--;
		Sections--;
		for (int k = number - 1; k < T; k++) {
			start->sections[k] = start->sections[k + 1];
		}
	}
	else {
		for (int k = 0; k < index - 1; k++) {
			current = current->next;
		}
	}

}

bool isThere(Attributes* head, char s[BUFFERSIZE]) {
	if (head == NULL) {
		return false;
	}
	else {
		int n = 0;
		int m = 0;
		while (s[n] != '\0') {
			n++;
		}

		Attributes* current = head;
		while (current->next != NULL && m != n) {
			m = 0;
			for (int i = 0; i < n; i++) {
				if (s[i] == current->attributename[i]) {
					m++;
				}
			}
			if (m != n) {
				current = current->next;
			}
			else {
				return true;
			}

		}
	}
	return false;
}

int SelectorsAmount(List* head) {
	int counter = 0;
	if (head == NULL) return counter;
	else {
		List* current = head;
		while (current != NULL) {
			current = current->next;
			counter++;
		}
	}
	return counter;
}

bool isDuplicate(Attributes* atrr, char buffer[BUFFERSIZE]) {
	int length = 0;
	int index = 0;
	while (buffer[index] != ':' && buffer[index] != '\0') {
		length++;
		index++;
	}
	char dup[BUFFERSIZE];
	for (int k = 0; k < BUFFERSIZE; k++) {
		dup[k] = buffer[k];
	}
	
	dup[length] = '\0';
	dup[++length] = '\0';
	Attributes* current = atrr;
	int a = 0;
	while (current != NULL) {
		for (int k = 0; k < length; k++) {
			if (current->attributename[k] == dup[k]) {
				a++;
			}
		}
		if (a == length) return true;
		a = 0;
		current = current->next;
	}
	return false;
}

bool isSelecDup(List* selec, char buffer[BUFFERSIZE]) {
	int length = 0;
	int index = 0;
	while (buffer[index] != '\0') {
		length++;
		index++;
	}
	char dup[BUFFERSIZE];
	for (int k = 0; k < BUFFERSIZE; k++) {
		dup[k] = buffer[k];
	}

	dup[length] = '\0';
	dup[++length] = '\0';
	List* current = selec;
	int a = 0;
	while (current != NULL) {
		for (int k = 0; k < length; k++) {
			if (current->data[k] == dup[k]) {
				a++;
			}
		}
		if (a == length) return true;
		a = 0;
		current = current->next;
	}
	return false;
}

void AddSelectorBack(List** head, char string[]) {
	if (isSelecDup(*head, string) == false) {
		if (*head == NULL) {
			*head = new List;
			for (int i = 0; i < BUFFERSIZE; i++) {
				(*head)->data[i] = string[i];
			}
			(*head)->next = NULL;
		}
		else {
			List* current = (*head);


			while (current->next != NULL) {
				current = current->next;
			}
			current->next = new List;
			for (int i = 0; i < BUFFERSIZE; i++) {
				current->next->data[i] = string[i];
			}
			current->next->next = NULL;
		}
	}
}

void AddAttribute(Attributes** head, char string[BUFFERSIZE]) {
	int index = 0;
	int ind = 0;
	int a = 0;
	int b = 0;
	if (isDuplicate((*head), string) == false) {
		if (*head == NULL) {
			*head = new Attributes;
			while (string[index] != ':' && string[index] != '\0') {
				(*head)->attributename[index] = string[index];
				index++;
			}
			a = index;
			for (int i = a; i < BUFFERSIZE; i++) {
				(*head)->attributename[a] = '\0';
			}
			index++;
			
			while (string[index] != ';' && string[index] != '\0') {
				(*head)->attributevalue[ind] = string[index];
				ind++;
				index++;
			}

			b = ind;
			for (int i = b; i < BUFFERSIZE; i++) {
				(*head)->attributevalue[b] = '\0';
			}
			(*head)->next = NULL;
		}
		else {
			Attributes* current = (*head);
			while (current->next != NULL) {
				current = current->next;
			}
			current->next = new Attributes;
			index = 0;
			while (string[index] != ':' && string[index] != '\0') {

				current->next->attributename[index] = string[index];
				index++;

			}
			a = index;
			for (int i = a; i < BUFFERSIZE; i++) {
				current->next->attributename[a] = '\0';
			}
			index++;
			
			while (string[index] != ';' && string[index] != '\0') {
				current->next->attributevalue[ind] = string[index];

				ind++;
				index++;
			}

			b = ind;
			for (int i = b; i < BUFFERSIZE; i++) {
				current->next->attributevalue[b] = '\0';
			}
			current->next->next = NULL;
		}
	}
	else {
		int length = 0;
		int index = 0;
		int b = 0;
		char help[BUFFERSIZE];
		while (string[index] != ':' && string[index] != '\0') {
			length++;
			index++;
		} index++;

		while (string[index] != ':' && string[index] != '\0') {
			help[b] = string[index];
			index++;
			b++;
		} index++;
		for (int k = b; k < BUFFERSIZE; k++) {
			help[k] = '\0';
		}
		Attributes* current = *head;
		int a = 0;
		while (current != NULL) {
			for (int k = 0; k < length; k++) {
				if (current->attributename[k] == string[k]) {
					a++;
				}
			}
			if (a == length) break;
			a = 0;
			current = current->next;
		}
		for (int k = 0; k < BUFFERSIZE; k++) {
			current->attributevalue[k] = '\0';
		}
		for (int k = 0; k < length; k++) {
			current->attributevalue[k] = help[k];
		}
	}
}


int main()
{
	Node* head = new Node;
	head->next = NULL;
	head->previous = NULL;
	Node* tmp = head;
	int counter = 0; //counter jest po to aby kontrolowac w ktorej sekcji dodaje
	char buffer[BUFFERSIZE];
	char firstCommand[BUFFERSIZE];
	char secondCommand[BUFFERSIZE];
	char thirdCommand[BUFFERSIZE];
	for (int i = 0; i < BUFFERSIZE; i++) {
		buffer[i] = '\0';
	}
	List* selec = tmp->sections->selectors = NULL;
	Attributes* atrr = tmp->sections->attributes = NULL;
	int WhichSign = 0;
	bool isCommand = false; //true gdy sa komendy
	int i = 0;
	int whichSection = 0;
	int number = 0;
	char input[ARRAYSIZE];
	int HowManySections = 0;
	int whichPosition = 0;
	int HowManySelectors = 0;
	int whichCommand = 0;
	bool isAttribute = false; //jesli false to wpisuje selektory a jesli true to atrybuty
	bool valueOrName = false; //jesli jest false to nazwy a jesli true to wartosci
	while ((input[i] = getchar()) != EOF) {
		if (input[i] >= 32 && input[i] < 126) {
			buffer[whichPosition] = input[i];
			if (isCommand == false) {
				if (input[i] == '?') {
					WhichSign++;
					ClearBuffer(buffer, whichPosition);
				}
				else {
					WhichSign = 0;
				}
				if (WhichSign == 4) {
					isCommand = true;
					WhichSign = 0;
					ClearBuffer(buffer, whichPosition);
					whichCommand = 0;
					while (tmp->previous != NULL) {
						tmp = tmp->previous;
					}
				}
			}
			else {
				gets_s(buffer, BUFFERSIZE - 1);
				for (int i = 0; i < 4; i++) {
					if (buffer[i] == '*') {
						WhichSign++;
					}
				}
				if (input[i] == '*') WhichSign++;
				if (WhichSign == 4) {
					isCommand = false;
					ClearBuffer(buffer, whichPosition);
					while (tmp->next != NULL) {
						tmp = tmp->next;
					}
				}
				WhichSign = 0;
			}
			if (isCommand == false) { //nie wiem czy ten if ma racje bytu
				switch (input[i]) {
				case '\n': input[i] = '\0';
					whichPosition--;
					break;
				case '{':
					if (HowManySelectors > 0) {
						HowManySelectors++;
					}
					buffer[whichPosition] = '\0';
					if (buffer[whichPosition - 1] == SPACE) buffer[whichPosition - 1] = '\0';
					AddSelectorBack(&tmp->sections[counter].selectors, buffer);
					ClearBuffer(buffer, whichPosition);
					isAttribute = true;
					valueOrName = false;
					//zacznij wpisywac nazwy
					break;
				case '}':
					buffer[whichPosition] = '\0';
					tmp->sections[counter].isUsed = true;
					tmp->howManyUsed++;
					counter++;
					tmp->sections[counter].selectors = NULL;
					tmp->sections[counter].attributes = NULL;
					if (counter == T) {
						AddBack(&head);
						counter = 0;
						tmp = tmp->next;
						tmp->sections->attributes = NULL;
						tmp->sections->selectors = NULL;
					}
					ClearBuffer(buffer, whichPosition);
					ClearInput(input, i);
					isAttribute = false;
					valueOrName = false;
					HowManySelectors = 0;
					HowManySections++;
					break;
				case ';':
					if (buffer[whichPosition] == ';') buffer[whichPosition] = '\0';
					if (buffer[0] == '\n' || buffer[0] == SPACE) {
						for (int j = 0; j < BUFFERSIZE - 2; j++) {
							buffer[j] = buffer[j + 1];
						}
					}
					AddAttribute(&tmp->sections[counter].attributes, buffer);
					ClearBuffer(buffer, whichPosition);
					valueOrName = false;
					break;
				case SPACE:
					if (valueOrName == false && isAttribute == true) {
						whichPosition--;
					}
					break;
				case ':':
					valueOrName = true;
					break;
				case ',':
					if (isAttribute == false) {
						HowManySelectors++;
						buffer[whichPosition] = '\0';
						AddSelectorBack(&tmp->sections[counter].selectors, buffer);
						ClearBuffer(buffer, whichPosition);
					}
					break;
				}
			}
			else {
				whichPosition = 0;
				int position = 0;
				for (int k = 0; k < BUFFERSIZE; k++) {
					firstCommand[k] = '\0';
					secondCommand[k] = '\0';
					thirdCommand[k] = '\0';
				}

				if (input[i] != '?') {
					for (int j = BUFFERSIZE - 1; j > 0; j--) {
						buffer[j] = buffer[j - 1];
					}
				}
				if (input[i] != '\n' && input[i] != '?') {
					buffer[0] = input[i];
				}
				else if (input[i] == '?' && whichCommand != 0) {

					buffer[0] = '?';
					for (int k = 1; k < BUFFERSIZE; k++) {
						buffer[k] = '\0';
					}
				}
				else {
					for (int k = 0; k < BUFFERSIZE - 2; k++) {
						buffer[k] = buffer[k + 1];
					}
				}
				whichCommand++;
				while (buffer[whichPosition] != ',' && buffer[whichPosition] != '\0') {
					firstCommand[position] = buffer[whichPosition];
					whichPosition++;
					position++;
				}
				whichPosition++;
				position = 0;
				while (buffer[whichPosition] != ',' && buffer[whichPosition] != '\0') {
					secondCommand[position] = buffer[whichPosition];
					whichPosition++;
					position++;
				}
				position = 0;
				whichPosition++;
				while (buffer[whichPosition] != ',' && buffer[whichPosition] != '\0') {
					thirdCommand[position] = buffer[whichPosition];
					whichPosition++;
					position++;
				}
				
				if (firstCommand[0] == '?') {
					cout << buffer << " == " << HowManySections << endl;
					ClearBuffer(buffer, whichPosition);
				}
				else if (thirdCommand[0] == '?') {
					if (isdigit(firstCommand[0])) {
						whichSection = atoi(firstCommand);
						if (secondCommand[0] == 'A') {
							while (tmp->previous != NULL) {
								tmp = tmp->previous;
							}
							if (whichSection > T) {
								for (int k = 0; k < (whichSection - 1) / T; k++) {
									tmp = tmp->next;
								}
							}
							whichSection -= 1;
							whichSection = whichSection % 8;
							if (HowManyAttributes(tmp->sections[whichSection].attributes) != 0) {
								cout << buffer << " == " << HowManyAttributes(tmp->sections[whichSection].attributes) << endl;
							}

						}
						else if (secondCommand[0] == 'S') {
							while (tmp->previous != NULL) {
								tmp = tmp->previous;
							}
							if (whichSection > T) {
								for (int k = 0; k < (whichSection - 1) / T; k++) {
									tmp = tmp->next;
								}

							}
							whichSection -= 1;
							whichSection = whichSection % 8;
							if (SelectorsAmount(tmp->sections[whichSection].selectors) != 0) {
								cout << buffer << " == " << SelectorsAmount(tmp->sections[whichSection].selectors) << endl;
							}
						}
					}
					else {
						if (secondCommand[0] == 'A') {
							
							if (countAttribute(firstCommand, tmp) != 0) {
								cout << buffer << " == " << countAttribute(firstCommand, tmp) << endl;
							}
							else if (tmp->sections[whichSection - 1].attributes != NULL) {
								cout << buffer << " == 0" << endl;
							}
						}
						else if (secondCommand[0] == 'S') {
							cout << buffer << " == " << CountSelector(firstCommand, tmp) << endl;
						}
					}
					ClearBuffer(buffer, whichPosition);
					ClearInput(input, i);
				}
				else if (thirdCommand[0] > 48 && thirdCommand[0] < 58 && firstCommand[0] > 48 && firstCommand[0] < 58) {
					whichSection = atoi(firstCommand);
					number = atoi(thirdCommand);
					if (secondCommand[0] == 'A') {
						ShowAttributeValueByIndex(tmp->sections[whichSection - 1].attributes, number - 1);
					}
					else if (secondCommand[0] == 'S') {
						while (tmp->previous != NULL) tmp = tmp->previous;
						if (whichSection > T) {
							for (int k = 0; k < (whichSection - 1) / T; k++) {
								tmp = tmp->next;
							}
						}
						whichSection -= 1;
						whichSection = whichSection % 8;
						ShowSelectorByIndex(tmp->sections[whichSection].selectors, number - 1, buffer);

					}
					else if (secondCommand[0] == 'D') {

					}
				}
				else if (firstCommand[0] > 48 && firstCommand[0] < 58 && thirdCommand[0] != '*') {
					whichSection = atoi(firstCommand);
					if (secondCommand[0] == 'A') {
						while (tmp->previous != NULL) {
							tmp = tmp->previous;
						}
						if (whichSection > T) {
							for (int k = 0; k < (whichSection - 1) / T; k++) {
								tmp = tmp->next;
							}

						}
						whichSection -= 1;
						whichSection = whichSection % 8;
						ShowAttributeByValue(tmp->sections[whichSection].attributes, thirdCommand, buffer);
					}
					else if (secondCommand[0] == 'S') {

					}
					else if (secondCommand[0] == 'D') {
						number = (int)firstCommand[0] - 48;

						DeleteAttribute(tmp, thirdCommand, counter, number, HowManySections);
						cout << buffer << " == " << "deleted" << endl;
						ClearBuffer(buffer, whichPosition);
					}
				}
				else if (isdigit(firstCommand[0]) == false && isdigit(thirdCommand[0]) == false) {
					if (secondCommand[0] == 'E') {
						while (tmp->previous != NULL) tmp = tmp->previous;
						findElement(firstCommand, thirdCommand, tmp, buffer);

					}
				}
				else if (thirdCommand[0] = '*') {
					bool isDeleted = false;
					number = atoi(firstCommand);
					while (tmp->previous != NULL) {
						tmp = tmp->previous;
					}
					if (number > T) {
						for (int k = 0; k < (number - 1) / T; k++) {
							tmp = tmp->next;
						}
					}
					number -= 1;
					number = number % 8;
					delete tmp->sections[number].attributes;
					delete tmp->sections[number].selectors;
					for (int k = number; k < T - 1; k++) {
						tmp->sections[k] = tmp->sections[k + 1];
					}
					tmp->sections[7].attributes = NULL;
					tmp->sections[7].selectors = NULL;
					if (tmp->sections[0].attributes == NULL) {
						isDeleted = true;
						HowManySections--;
						if (tmp->previous != NULL && tmp->next != NULL) {
							tmp->previous->next = tmp->next;
						}
						else if (tmp->next == NULL && tmp->previous != NULL) {
							tmp = tmp->previous;
							tmp->next = NULL;
						}
						else if (tmp->next != NULL && tmp->previous == NULL) {
							tmp = tmp->next;
							tmp->previous = NULL;
						}
						else if (tmp->next == NULL && tmp->previous == NULL) {
							tmp == NULL;
						}
					}
					if (tmp->next == NULL) {
						counter--;
					}
					if (tmp->previous != NULL) {
						while (tmp->previous != NULL) {
							tmp = tmp->previous;
						}
					}
					cout << buffer << " == " << "deleted" << endl;
					if (isDeleted == false) {
						HowManySections--;
					}
					if (counter < 0) {
						//counter = 0;
						
						if (tmp->previous != NULL) {
							tmp = tmp->previous;
							counter = 7;
						}
						else {
							counter = 0;
						}
					}
					ClearBuffer(buffer, whichPosition);
				}
			}
			i++;
			whichPosition++;
		}
	}
	return 0;
}
