#include <iostream>
#include "string.h"
#include "cssreader.h"
#include "command.h"

using namespace std;


int main() {

    List* list = new List;

    int opperation = CSS;

    while (opperation != LEAVE) {

        switch (opperation) {

        case CSS:

            CSSWriter(list, &opperation);
            break;

        case COMMANDWRITER:

            commandReader(list, &opperation);
            break;

        default:
            break;
        }
    }

	return 0;
}