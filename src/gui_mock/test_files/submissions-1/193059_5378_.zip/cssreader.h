#pragma once
#include "string.h"
#include <iostream>
#include "list.h"

#ifndef CSSREADER
#define CSSREADER

void CSSWriter(List* list, int* opperation);

void CSSBlockCreator(String text, List* list);

#endif