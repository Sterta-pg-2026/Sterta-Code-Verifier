#include "cssreader.h"

void CSSWriter(List* list, int* opperation) {

    String text;

    while (true) {

        String input;

        std::cin >> input;

        if (input[0] == EOF) { *opperation = LEAVE; break; }

        if (input == "????") { *opperation = COMMANDWRITER; break; }

        text = text + input;
    }

    CSSBlockCreator(text, list);
}

void divideSelector(Section* block, List* list, String temp_text) {

    int start = 0;

    int size = temp_text.lenght();
    for (int end = 0; end < size + 1; end++) {

        if (temp_text[end] == ',' || temp_text[end] == '{') {

            String element(temp_text.c_str() + start, end - start);
            element.trim();

            if (element != "") {
                list->addSelector(block, element);
                start = end + 1;
                block->selectValue++;
            }
        }
    }
}

void divideAttribute(Section* block, List* list, String temp_text) {

    String att, value;
    int start = 0;

    int size = temp_text.lenght();
    for (int end = 0; end < size + 1; end++) {

        if (temp_text[end] == ':') {

            String element(temp_text.c_str() + start, end - start);
            att = element;
            att.trim();

            start = end + 1;
            block->attValue++;
        }
        else if (temp_text[end] == ';' || temp_text[end] == '}') {

            String element(temp_text.c_str() + start, end - start);
            value = element;
            value.trim();

            start = end + 1;
        }
    }
    list->addAttribute(block, att, value);
}

void CSSBlockCreator(String text, List* list) {

    Node* current = list->findFreeBlock();
    Section* block = list->findFreeSection(current);
    current->index++;
    current->max++;
    current->inBlock++;
    block->indexValue = 1;

    int start = 0;
    text.trim();
    int size = text.lenght();
    for (int end = 0; end < size; end++) {

        if (text[end] == '{') {

            String temp_text(text.c_str() + start, end - start + 1);
            temp_text.trim();
            divideSelector(block, list, temp_text);
            start = end + 1;
        }
        else if (text[end] == ';' || (text[end] == '}' && text[end - 1] != ';')) {

            String temp_text(text.c_str() + start, end - start + 1);
            temp_text.trim();
            divideAttribute(block, list, temp_text);
            start = end + 1;

        }

        if (text[end] == '}' && end != text.lenght() - 1) {
            if (current->index >= T) { current = list->findFreeBlock(); }
            block = list->findFreeSection(current);
            current->index++;
            current->max++;
            current->inBlock++;
            block->indexValue = 1;
            start = end + 1;
        }
    }
}