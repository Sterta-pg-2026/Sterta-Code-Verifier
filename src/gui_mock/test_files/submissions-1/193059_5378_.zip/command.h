#pragma once
#include <iostream>
#include "string.h"
#include "list.h"


#ifndef COMMAND
#define COMMAND


void commandReader(List* list, int* opperation);


#endif
