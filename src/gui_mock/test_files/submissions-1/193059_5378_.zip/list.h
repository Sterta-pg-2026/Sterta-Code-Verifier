#pragma once

#include <iostream>
#include "string.h"

#define T 37

enum OPPERATION {
    CSS,
    COMMANDWRITER,
    LEAVE
};

struct Selector {

    String name;

    Selector* next;
    Selector* prev;
};

struct Attribute {

    String name;
    String value;

    Attribute* next;
    Attribute* prev;
};

struct Section {

    int indexValue = 0;

    int selectValue = 0;
    int attValue = 0;

    Selector* firstSelect = nullptr;
    Selector* lastSelect = nullptr;

    Attribute* firstAtt = nullptr;
    Attribute* lastAtt = nullptr;
};

struct Node {
    
    int index;

    Node* next;
    Node* prev;

    Section block[T];

    int possition = 1;
    int max;
    int inBlock = 0;
};

class List {

public:

    Node* firstBlock;
    Node* lastBlock;

    List();

    ~List();

    void addNode();

    Node* findFreeBlock();

    Section* findFreeSection(Node* current);

    Node* goToBlock(int number);

    Section* goToSection(Node* current, int number);

    String findAttValue(Section* block, String thirdPart);

    String findSelector(Section* block, int number);

    String findAttValueBySelector(String firstPart, String thirdPart);

    int findAttributes(String firstPart);
    int findSelector(String firstPart);

    void addSelector(Section* block, String text);

    void addAttribute(Section* block, String att, String value);

    int elementsValue();

    void lowerIndexNumbers(Node* current);

    void deleteNode(int position);

    void deleteSection(Node* current, Section* block);

    bool deleteAttribute(Node* current, Section* block, String thirdPart);
};