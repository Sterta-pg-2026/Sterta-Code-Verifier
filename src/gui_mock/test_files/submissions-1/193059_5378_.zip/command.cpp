#include "command.h"

void numberCommand(List* list, String firstPart, String secondPart, String thirdPart) {

    int sectionNumber = firstPart.toInt();
    Node* current = list->goToBlock(sectionNumber);
    if (current == nullptr) return;
    Section* block = list->goToSection(current, sectionNumber);
    if (block == nullptr) return;

    if (secondPart == "A") {
        if (thirdPart == "?") {
            std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << block->attValue << std::endl;
        }
        else {
            String element = list->findAttValue(block, thirdPart);
            if (element == "\0") return;
            std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << element << std::endl;
        }
    }
    else if (secondPart == "S") {
        if (thirdPart[0] == '?') {
            std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << block->selectValue << std::endl;
        }
        else if (thirdPart.isNumber()) {
            int num = thirdPart.toInt();
            String element = list->findSelector(block, num);
            if (element == "\0") return;
            std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << element << std::endl;
        }
    }
    else if (secondPart == "D") {
        if (thirdPart == "*") {
            list->deleteSection(current, block);
            std::cout << firstPart << "," << secondPart << "," << thirdPart << " == deleted" << std::endl;
        }
        else {
            if (list->deleteAttribute(current, block, thirdPart)) {
                std::cout << firstPart << "," << secondPart << "," << thirdPart << " == deleted" << std::endl;
            }
        }
    }
}

void textCommand(List* list, String firstPart, String secondPart, String thirdPart) {

    if (secondPart == "A" && thirdPart == "?") {

        int result = list->findAttributes(firstPart);
        std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << result << std::endl;
    }
    else if (secondPart == "S" && thirdPart == "?") {
        int result = list->findSelector(firstPart);
        std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << result << std::endl;
    }
    else if (secondPart == "E") {
        String element = list->findAttValueBySelector(firstPart, thirdPart);
        if (element == "\0") return;
        std::cout << firstPart << "," << secondPart << "," << thirdPart << " == " << element << std::endl;
    }
}

void commandCaller(List* list, String firstPart, String secondPart, String thirdPart) {

    if (firstPart.isNumber()) {

        numberCommand(list, firstPart, secondPart, thirdPart);
    }
    else {

        textCommand(list, firstPart, secondPart, thirdPart);
    }
}

void divideToThreeStrings(String text, String* firstPart, String* secondPart, String* thirdPart, char sign) {

    int k = 0, start = 0;

    for (int i = 0; i < text.lenght(); i++) {

        if (k == 0) {
            if (text[i] == sign) {
                String element(text.c_str(), i);
                *firstPart = element;
                start = i + 1; k++;
            }
        }
        else if (k == 1) {
            if (text[i] == sign) {
                String element(text.c_str() + start, i - start);
                *secondPart = element;
                start = i + 1; k++;
            }
        }
        else if (k == 2) {
            String element(text.c_str() + start, text.lenght() - start);
            *thirdPart = element;
            return;
        }
    }
}


void commandReader(List* list, int* opperation) {

    while (true) {

        String input;
        std::cin >> input;

        if (input[0] == EOF) { *opperation = LEAVE; break; }

        if (input == "****") { *opperation = CSS; break; }
        else if (input == "?") {
            int number = list->elementsValue();
            std::cout << "? == " << number << std::endl;
        }
        else {
            String firstPart, secondPart, thirdPart;
            divideToThreeStrings(input, &firstPart, &secondPart, &thirdPart, ',');

            if (secondPart[0] == 'A' || secondPart[0] == 'E' || secondPart[0] == 'S' || secondPart[0] == 'D')commandCaller(list, firstPart, secondPart, thirdPart);
        }
    }
}