#pragma once
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cctype>


class String {

private:

    char* content;
    int size;

public:

    String();
    String(const char* str);
    String(const String& other);
    String(String&& other) noexcept;
    String(const char* str, int size);

    ~String();

    String& operator=(const String& other);
    String& operator=(String&& other) noexcept;
    String operator+(const String& other) const;
    String& operator+=(const char* s);
    String& operator+=(const String& other);
    
    bool operator==(const String& other) const;
    bool operator!=(const String& other) const;
    
    char& operator[](int index);
    const char& operator[](int index) const;

    int lenght() const;
    void clear();
    const char* c_str() const;
    bool isNumber() const;

    int toInt() const;
    void trim();

    friend std::ostream& operator<<(std::ostream& os, const String& str);
    friend std::istream& operator>>(std::istream& is, String& str);

};