#define _CRT_SECURE_NO_WARNINGS
#include "string.h"

#define TEXTLENGHT 1024


String::String() {

    content = new char[1];
    content[0] = '\0';
    size = 0;
}

String::String(const char* str) {

    size = strlen(str);
    content = new char[size + 1];
    strcpy(content, str);
}

String::String(const String& other) {

    size = other.size;
    content = new char[size + 1];
    strcpy(content, other.content);
}

String::String(String&& other) noexcept {

    content = other.content;
    size = other.size;
    other.content = nullptr;
    other.size = 0;
}

String::String(const char* str, int size) {

    this->size = size;
    content = new char[this->size + 1];

    strncpy(content, str, this->size);
    content[this->size] = '\0';
}


String::~String() {
    delete[] content;
}


String& String::operator=(const String& other) {

    if( this != &other ) {
        delete[] content;
        size = other.size;
        content = new char[size + 1];
        memcpy(content, other.content, size + 1);
    } 
    return *this;
}

String& String::operator=(String&& other) noexcept {

    if (this != &other) {
        delete[] content;
        content = other.content;
        size = other.size;
        other.content = nullptr;
        other.size = 0;
    }
    return *this;
}

String String::operator+(const String& other) const {

    String result;
    
    result.size = size + other.size;
    result.content = new char[result.size + 1];
    
    strcpy(result.content, content);
    strcat(result.content, other.content);

    return result;
}

String& String::operator+=(const char* s) {

    int len = strlen(s);

    char* temp = new char[size + len + 1];

    strcpy(temp, content);
    strcat(temp, s);

    delete[] content;

    content = temp;
    size += len;

    return *this;
}

String& String::operator+=(const String& other) {

    return (*this += other.content);
}

bool String::operator==(const String& other) const {

    return (strcmp(content, other.content) == 0);
}

bool String::operator!=(const String& other) const {

    return (strcmp(content, other.content) != 0);
}

char& String::operator[](int index) {
    return content[index];
}

const char& String::operator[](int index) const {
    return content[index];
}


int String::lenght() const {
    
    return size;
}

const char* String::c_str() const {

    return content;
}

void String::clear() {

    delete content;
    content = new char[1];
    content[0] = '\0';
    size = 0;
}

bool String::isNumber() const{

    for (int i = 0; i < size; i++) {

        if (content[i] >= '0' && content[i] <= '9') continue;
        else return false;
    }

    return true;
}

int String::toInt() const {

    int i = 0;
    int result = 0;

    while (i < size) {

        result = result * 10 + (content[i] - '0');
        i++;
    }

    return result;
}

void String::trim() {
    char* str = content;
    int len = lenght();

    int start = 0;
    while (str[start] == ' ' || str[start] == '\t' || str[start] == '\n' || str[start] == '\r' || str[start] == '\f' || str[start] == '\v') {
        start++;
    }

    if (start > 0) {
        for (int j = start; j <= len; j++) {
            str[j - start] = str[j];
        }
        len -= start;
        size -= start;
    }

    while (str[len - 1] == ' ' || str[len - 1] == '\t' || str[len - 1] == '\n' || str[len - 1] == '\r' || str[len - 1] == '\f' || str[len - 1] == '\v') {
        len--;
        size--;
    }
    str[len] = '\0';
    
}


std::ostream& operator<<(std::ostream& os, const String& str) {

    os << str.content;
    return os;
} 

std::istream& operator>>(std::istream& is, String& str) {

    char c;
    char text[TEXTLENGHT];

    int i = 0;
    c = getchar();

    while (c != '\0' && c != '\n' && c != EOF) {

        text[i++] = c;
        c = getchar();
    }

    if (c == EOF) text[i++] = EOF;
    text[i] = '\n';
    text[i+1] = '\0';
    String string(text, i);
    str = string;

    return is;
}