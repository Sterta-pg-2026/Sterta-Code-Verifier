#include "list.h"

List::List() {

    firstBlock = nullptr;
    lastBlock = nullptr;
}

List::~List() {

    Node* current = firstBlock;
    
    while (current != nullptr) {
        
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
}

void List::addNode() {

    Node* newList = new Node{0};

    if (firstBlock == nullptr) {
        
        firstBlock = newList;
        lastBlock = newList;
    }
    else {
        
        lastBlock->next = newList;
        newList->prev = lastBlock;
        lastBlock = newList;
        newList->possition += newList->prev->possition;
        newList->max = newList->prev->max;
    }
}

Node* List::findFreeBlock() {

    Node* current = lastBlock;

    if (current == nullptr) { addNode(); current = lastBlock; }
    if (current->index >= T) { addNode(); current = lastBlock; }

    return current;
}

Section* List::findFreeSection(Node* current) {

    return &current->block[current->index];
}

Node* List::goToBlock(int number) {

    Node* current = firstBlock;

    if (number <= current->max) return current;
    current = current->next;

    while (current != nullptr) {
        
        if (number <= current->max && number > current->prev->max) { return current; }
        current = current->next;
    }
    return nullptr;
}

Section* List::goToSection(Node* current, int number) {

    int index = (number+current->inBlock) - current->max;
    int help_index = 0;

    for (int i = 0; i < T; i++) {
        if (current->block[i].indexValue != 0) {
            help_index++;

            if (help_index == index) return &current->block[i];
        }
    }
    
    return nullptr;
}

String List::findAttValue(Section* block, String thirdPart) {

    Attribute* att = block->firstAtt;

    while (att != nullptr) {
        if (att->name == thirdPart) return att->value;
        att = att->next;
    }

    return "\0";
}

String List::findSelector(Section* block, int number) {

    Selector* select = block->firstSelect;
    int i = 1;

    while (select != nullptr) {
        if (i == number) return select->name;
        i++;
        select = select->next;
    }

    return "\0";
}

String List::findAttValueBySelector(String firstPart, String thirdPart) {

    Node* current = lastBlock;

    while (current != nullptr) {
        for (int i = T; i > 0; i--) {
            if (current->block[i-1].indexValue == 0) continue;
            Section block = current->block[i-1];
            Selector* select = block.firstSelect;

            while (select != nullptr) {
                    if (select->name == firstPart) {
                        Attribute* att = block.firstAtt;

                        while (att != nullptr) {
                            if (att->name == thirdPart) { return att->value; }
                            att = att->next;
                        }
                        break;
                    }
                    select = select->next;
            }
        }
        current = current->prev;
    }
    return "\0";
}

int List::findAttributes(String firstPart) {

    int result = 0;
    Node* current = firstBlock;

    while (current != nullptr) {

        for (int i = 0; i < T; i++) {

            if (current->block[i].indexValue == 0) continue;
            Attribute* att = current->block[i].firstAtt;

            while (att != nullptr) {
                if (att->name == firstPart) { result++; break; }
                att = att->next;
            }
        }
        current = current->next;
    }
    return result;
}

int List::findSelector(String firstPart) {

    int result = 0;
    Node* current = firstBlock;

    while (current != nullptr) {
        for (int i = 0; i < T; i++) {

            if (current->block[i].indexValue == 0) continue;
            Selector* select = current->block[i].firstSelect;

            while (select != nullptr) {
                if (select->name == firstPart) { result++; break; }
                select = select->next;
            }
        }
        current = current->next;
    }
    return result;
}

void List::addSelector(Section* block, String text) {

    Selector* newSelect = new Selector{ text, nullptr, nullptr };

    if (block->firstSelect == nullptr) {

        block->firstSelect = newSelect;
        block->lastSelect = newSelect;
    }
    else {

        Selector* select = block->firstSelect;
        while (select != nullptr) {

            if (select->name == text) {
                block->selectValue--;
                return;
            }
            select = select->next;
        }

        block->lastSelect->next = newSelect;
        newSelect->prev = block->lastSelect;
        block->lastSelect = newSelect;
    }
}

void List::addAttribute(Section* block, String att, String value) {
    
    Attribute* newAtt = new Attribute{ att, value, nullptr, nullptr };

    if (block->firstAtt == nullptr) {
        
        block->firstAtt = newAtt;
        block->lastAtt = newAtt;
    }
    else {
        
        Attribute* attribute = block->firstAtt;
        while (attribute != nullptr) {

            if (attribute->name == att) {
                attribute->value = value;
                block->attValue--;
                return;
            }
            attribute = attribute->next;
        }

        block->lastAtt->next = newAtt;
        newAtt->prev = block->lastAtt;
        block->lastAtt = newAtt;
    }
}

int List::elementsValue() {

    Node* current = lastBlock;
    
    int number = 0;

    if (current != nullptr) number = current->max;
    return number;
}

void List::lowerIndexNumbers(Node* current) {

    while (current != nullptr) {

        current->max--;
        current = current->next;
    }
}

void List::deleteNode(int position) {

    Node* temp_list = firstBlock;

    if (temp_list == nullptr) return;

    if (position == firstBlock->possition) {

        firstBlock = temp_list->next;

        if (firstBlock != nullptr) firstBlock->prev = nullptr;
        if (firstBlock == nullptr) lastBlock = nullptr;

        delete temp_list;
        return;
    }

    int listIndex = 1;
    while (temp_list != nullptr && listIndex != position) {

        temp_list = temp_list->next;
        listIndex++;
    }

    if(temp_list == nullptr) return;

    if(temp_list == lastBlock) {
        
        lastBlock = lastBlock->prev;
        if (lastBlock != nullptr) {
           
            lastBlock->next = nullptr;
        }

        delete temp_list;
        return;
    }

    temp_list->prev->next = temp_list->next;
    temp_list->next->prev = temp_list->prev;

    delete temp_list;
    return;
}

void List::deleteSection(Node* current, Section* block) {

    int blockPossition = current->possition;
    lowerIndexNumbers(current);

    delete block->firstAtt;
    delete block->firstSelect;
    current->inBlock--;

    block->attValue = 0;
    block->indexValue = 0;
    block->selectValue = 0;
    block->firstAtt = nullptr;
    block->firstSelect = nullptr;
    block->lastAtt = nullptr;
    block->lastSelect = nullptr;

    if (current->inBlock == 0) deleteNode(blockPossition);

}

bool List::deleteAttribute(Node* current, Section* block, String thirdPart) {

    Attribute* att = block->firstAtt;

    while (att != nullptr) {

        if (att->name == thirdPart) {

            block->attValue--;

            if (att->prev == nullptr) {

                block->firstAtt = att->next;

                if (block->firstAtt != nullptr) block->firstAtt->prev = nullptr;

                delete att;
                if (block->attValue == 0) {
                    block->firstAtt = nullptr;
                    block->lastAtt = nullptr;
                    deleteSection(current, block);
                }
                return true;
            }

            if (att == block->lastAtt) {

                block->lastAtt = block->lastAtt->prev;
                if (block->lastAtt != nullptr) {

                    block->lastAtt->next = nullptr;
                }

                delete att;
                return true;
            }

            att->prev->next = att->next;
            att->next->prev = att->prev;

            delete att;
            return true;
        }

        att = att->next;
    }
    return false;
}