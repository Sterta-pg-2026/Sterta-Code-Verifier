#pragma once
#include <iostream>
#include "constans.h"
#include "buffertools.h"

using namespace std;

class AtrNode {
public:
    AtrNode* next;
    char key[BUFFER/LIMITER];
    char value[BUFFER/LIMITER];

    void prepare(char key[], char value[]);
    AtrNode();
    ~AtrNode();
};

class AtrList {
public:
    AtrNode* head = nullptr;
    AtrNode* tail = nullptr;
    int length;

    AtrNode* get(int index);
    AtrNode* getByName(char name[]);
    int removeByName(char name[]);
    void append(char key[], char value[]);
    void removeLast();
    void removeFirst();
    void remove(int index);
    void print();
    void parser(char data[]);
    int getLength();
    void prepare(char data[]);
    void removeList();
    void setValue(AtrNode* node, char value[]);

    AtrList();
    ~AtrList();
};