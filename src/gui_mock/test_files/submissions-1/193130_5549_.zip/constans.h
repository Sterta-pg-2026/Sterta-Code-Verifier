#pragma once

using namespace std;

const int PARSE_OFF = 0;
const int PARSE_KEY = 1;
const int PARSE_VALUE = 2;
const int INPUT_CSS = 0;
const int INPUT_COMMAND = 1;
const int T = 17;
const int SPACE = 32;
const int DOUBLE_QUOTES = 34;
const int NUMBER_SIGN = 35;
const int PER_CENT = 37;
const int SINGLE_QUOTE = 39;
const int ASTERISK = 42;
const int PLUS = 43;
const int COMMA = 44;
const int MINUS = 45;
const int DOT = 46;
const int ZERO = 48;
const int NINE = 57;
const int COLON = 58;
const int SEMICOLON = 59;
const int QUESTION_MARK = 63;
const int UPPERCASE_A = 65;
const int UPPERCASE_Z = 90;
const int UNDERSCORE = 95;
const int LOWERCASE_A = 97;
const int LOWERCASE_Z = 122;
const int OPENING_BRACE = 123;
const int CLOSING_BRACE = 125;
const int BUFFER = 850;
const int LIMITER = 8;