#pragma once
#include <iostream>
#include "list.h"
#include "atrlist.h"

using namespace std;

class Section {
public:
    AtrList* attributes;
    List* selectors;

    void prepare(char sectionCode[]);
    void removeSection(); 
    Section();
    ~Section();
};