#include "list.h"
#include <iostream>

using namespace std;

Node* List::get(int index) {
    if (index < 0 || index >= length) return nullptr;
    Node* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    return current;
}

Node* List::getByName(char name[]) {
    Node* current = head;
    int size1 = getArrLength(name,BUFFER/LIMITER);
    int success = 0;
    for (int i = 0; i < length; ++i) {
        success = 0;
        int size2 = getArrLength(current->data, BUFFER / LIMITER);
        if (abs(size1 - size2) <= 1) {
            for (int j = 0;j < (size1 > size2 ? size2 : size1);++j) {
                if (current->data[j] == name[j]) success++;
                else break;
            }
            if (success == (size1 > size2 ? size2 : size1))  return current;
        }
        current = current->next;
    }
    return 0;
}

void List::append(char data[]) {
    Node* newNode = new Node();
    newNode->prepare(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        tail = newNode;
    }
    length++;
}

void List::removeLast() {
    if (length == 0) return;
    Node* current = head;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        Node* prev = head;
        while (current->next) {
            prev = current;
            current = current->next;
        }
        tail = prev;
        tail->next = nullptr;
    }
    delete current;
    length--;
}

void List::removeFirst() {
    if (length == 0) return;
    Node* current = head;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        head = head->next;
    }

    current = nullptr;
    delete current;
    length--;
}

void List::remove(int index) {
    if (index < 0 || index >= length) return;
    if (index == 0) return removeFirst();
    if (index == length - 1) return removeLast();
    Node* prev = get(index - 1);
    Node* current = prev->next;
    prev->next = current->next;
    current = nullptr;
    delete current;
    length--;
}

void List::removeList() {
    Node* current = head;
    Node* next = nullptr;

    while (current != nullptr) {
        next = current->next;
        delete current;
        current = next;
    }

    head = nullptr;
}

void List::print() {
    Node* current = head;
    cout << "Selectors: ";
    while (current) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

void List::parser(char data[]) {
    char* newSelector = new char[BUFFER / LIMITER];
    clearBuffer(newSelector, BUFFER / LIMITER);
    int i = 0, newI = 0;

    while (data[i]) {
        if (data[i] != OPENING_BRACE) {
            if ((data[i] >= ZERO && data[i] <= NINE) || (data[i] >= UPPERCASE_A && data[i] <= UPPERCASE_Z) || (data[i] >= LOWERCASE_A && data[i] <= LOWERCASE_Z) || data[i] == NUMBER_SIGN || data[i] == DOT || data[i] == MINUS || data[i] == COLON || data[i] == UNDERSCORE || data[i] == SPACE || data[i] == PLUS) {
                newSelector[newI] = data[i];
                newI++;
            }
            else if (data[i] == COMMA) {
                int size = getArrLength(newSelector, BUFFER / LIMITER);
                int spaceCount = 0;
                for (int i = 0;i < size;i++) {
                    if (newSelector[i] == SPACE) spaceCount++;
                }
                if (newI > 0 && spaceCount < size) append(newSelector);
                clearBuffer(newSelector, BUFFER / LIMITER);
                newI = 0;
            }
        }
        else {
            int size = getArrLength(newSelector, BUFFER / LIMITER);
            int spaceCount = 0;
            for (int i = 0;i < size;i++) {
                if (newSelector[i] == SPACE) spaceCount++;
            }
            if (newI > 0 && spaceCount < size) append(newSelector);
            clearBuffer(newSelector, BUFFER / LIMITER);
            newI = 0;
            break;
        }
        i++;
    }
    delete[] newSelector;
}

int List::getLength() {
    return length;
}

void List::prepare(char data[]) {
    parser(data);
}

Node::Node() {
    next = nullptr;
    for (int i = 0;i < BUFFER / LIMITER;++i) data[i] = NULL;
}

Node::~Node() {
   // delete[] data;
    next = nullptr;
}

void Node::prepare(char data[]) {
    for (int i = 0;i < BUFFER / LIMITER;++i) this->data[i] = data[i];
    next = nullptr;
}

List::List() {
    head = nullptr;
    tail = nullptr;
    length = 0;
}

List::~List() {
    removeList();
}