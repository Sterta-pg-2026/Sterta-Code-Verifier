#pragma once
#include <iostream>
#include "constans.h"
#include "buffertools.h"

using namespace std;

class Node {
public:
    Node* next;
    char data[BUFFER/LIMITER];

    void prepare(char data[]);

    Node();
    ~Node();
};

class List {
public:
    Node* head;
    Node* tail;
    int length;

    Node* get(int index);
    Node* getByName(char name[]);
    void append(char data[]);
    void removeLast();
    void removeFirst();
    void remove(int index);
    void print();
    void parser(char data[]);
    int getLength();
    void prepare(char data[]);
    void removeList();

    List();
    ~List();
};
