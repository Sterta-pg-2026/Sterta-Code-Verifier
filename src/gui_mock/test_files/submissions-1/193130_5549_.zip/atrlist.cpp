#include "atrlist.h"
#include <iostream>

using namespace std;

AtrNode* AtrList::get(int index) {
    if (index < 0 || index >= length) return nullptr;
    AtrNode* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    return current;
}

AtrNode* AtrList::getByName(char name[]) {
    AtrNode* current = head;
    int size1 = getArrLength(name, BUFFER / LIMITER);
    int success = 0;
    for (int i = 0; i < length; ++i) {
        success = 0;
        int size2 = getArrLength(current->key, BUFFER / LIMITER);
        if (abs(size1 - size2) <= 1) {
            for (int j = 0;j < (size1 > size2 ? size2 : size1);++j) {
                if (current->key[j] == name[j]) {
                    success++;
                }
                else break;
            }
            if (success == (size1 > size2 ? size2 : size1)) return current;
        }
        current = current->next;
    }
    return 0;
}

void AtrList::setValue(AtrNode* node, char value[]) {
    int size = getArrLength(value, BUFFER / LIMITER);
    for (int i = 0;i < size;i++) node->value[i] = value[i];
}

void AtrList::append(char key[], char value[]) {
    AtrNode* newNode = new AtrNode();
    AtrNode* current = head;
    bool duplicate = true;
    bool duplicateFinal = false;
    int size1 = getArrLength(key,BUFFER / LIMITER);
    while (current) {
        duplicate = true;
        int size2 = getArrLength(current->key, BUFFER / LIMITER);
        if (size1 == size2) {
            for (int i = 0;i < size1;++i) {
                if (current->key[i] != key[i]) {
                    duplicate = false;
                    break;
                }
            }
        }
        else duplicate = false;
        if (duplicate) duplicateFinal = true;
        current = current->next;
    }
    if (!duplicateFinal) {
        newNode->prepare(key, value);
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            tail->next = newNode;
            tail = newNode;
        }
        length++;
    }
    else {
        setValue(getByName(key), value);
    }
}

void AtrList::removeLast() {
    if (length == 0) return;
    AtrNode* current = head;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        AtrNode* prev = head;
        while (current->next) {
            prev = current;
            current = current->next;
        }
        tail = prev;
        tail->next = nullptr;
    }
    delete current;
    length--;
}

void AtrList::removeFirst() {
    if (length == 0) return;
    AtrNode* current = head;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        head = head->next;
    }

    current = nullptr;
    delete current;
    length--;
}

void AtrList::remove(int index) {
    if (index < 0 || index >= length) return;
    if (index == 0) return removeFirst();
    if (index == length - 1) return removeLast();
    AtrNode* prev = get(index - 1);
    AtrNode* current = prev->next;
    prev->next = current->next;
    current = nullptr;
    delete current;
    length--;
}

void AtrList::print() {
    AtrNode* current = head;
    while (current) {
        cout << "Atr: " << current->key << " Val: " << current->value << endl;
        current = current->next;
    }
}

void AtrList::parser(char data[]) {
    char* newKey = new char[BUFFER/LIMITER];
    char* newValue = new char[BUFFER/LIMITER];
    clearBuffer(newKey, BUFFER / LIMITER);
    clearBuffer(newValue, BUFFER / LIMITER);
    int openingBrace = 0;
    int parseMode = 0, i = 0, newKeyI = 0, newValueI = 0;
    while (data[i]) {
        switch (data[i]) {
        case CLOSING_BRACE:
            parseMode = PARSE_OFF;
            break;
        case SEMICOLON:
            parseMode = PARSE_KEY;
            append(newKey, newValue);
            clearBuffer(newKey, BUFFER / LIMITER);
            newKeyI = 0;
            clearBuffer(newValue, BUFFER / LIMITER);
            newValueI = 0;
            break;
        case OPENING_BRACE:
            parseMode = PARSE_KEY;
            openingBrace = 1;
            break;
        case COLON:
            if (openingBrace) {
                parseMode = PARSE_VALUE;
            }
            break;
        }
        if (data[i] == '\n' && getArrLength(newKey, BUFFER / LIMITER) && getArrLength(newValue, BUFFER / LIMITER)) {
            append(newKey, newValue);
            clearBuffer(newKey, BUFFER / LIMITER);
            newKeyI = 0;
            clearBuffer(newValue, BUFFER / LIMITER);
            newValueI = 0;
        }
        if ((data[i] >= ZERO && data[i] <= NINE) || (data[i] >= UPPERCASE_A && data[i] <= UPPERCASE_Z) || (data[i] >= LOWERCASE_A && data[i] <= LOWERCASE_Z) || data[i] == SPACE || data[i] == DOUBLE_QUOTES || data[i] == NUMBER_SIGN || data[i] == PER_CENT || data[i] == COMMA || data[i] == MINUS || data[i] == SINGLE_QUOTE || data[i] == ASTERISK) {
            switch (parseMode) {
            case 1:
                if (data[i] != SPACE && data[i] != COMMA) {
                    newKey[newKeyI] = data[i];
                    newKey[newKeyI] = data[i];
                    newKeyI++;
                }
                break;
            case 2:
                if (newValueI >= 1 || data[i] != SPACE) {
                    newValue[newValueI] = data[i];
                    newValueI++;
                }
                break;

            }
        }

        i++;
    }
    delete[] newKey;
    delete[] newValue;
}

int AtrList::getLength() {
    return length;
}

AtrNode::AtrNode() {
    next = nullptr;
    for (int i = 0;i < BUFFER/LIMITER;++i) {
        key[i] = NULL;
        value[i] = NULL;
    }
}


AtrNode::~AtrNode() {
   //delete key;
   //delete value;
    next = nullptr;
}

void AtrNode::prepare(char key[], char value[]) {
    for (int i = 0;i < BUFFER/LIMITER;++i) {
        this->key[i] = key[i];
        this->value[i] = value[i];
    }
}

void AtrList::prepare(char data[]) {
    parser(data);
}

int AtrList::removeByName(char name[]) {
    AtrNode* temp = getByName(name);
    AtrNode* current = head;
    int index = 0;
    if (temp) {
        while (current) {
            if (current == temp) {
                remove(index);
                return 1;
            }
            else {
                index++;
                current = current->next;
            }
        }
    }
    return 0;
}

void AtrList::removeList() {
    AtrNode* current = head;
    AtrNode* next = nullptr;

    while (current != nullptr) {
        next = current->next;
        delete current;
        current = next;
    }

    head = nullptr;
}

AtrList::AtrList() {
    head = nullptr;
    tail = nullptr;
    length = 0;
}

AtrList::~AtrList() {
    removeList();
}