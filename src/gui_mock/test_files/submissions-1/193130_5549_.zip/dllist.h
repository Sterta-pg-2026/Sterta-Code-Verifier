#pragma once
#include <iostream>
#include "section.h"
#include "constans.h"

using namespace std;

class DLNode {
public:
    DLNode* prev;
    DLNode* next;
    Section* sections[T];
    int section_elements = 1;

    void prepare(char section_part[]);
    DLNode();
};

class DLList {
public:
    DLNode* head;
    DLNode* tail;
    int length;
    int counter;

    void append(char block[]);
    void nodeHandle(char block[]);
    int getLength();
    int getSectionCount();
    int getSelectors(int i);
    Node* getSelectors(int i, int j);;
    int getAttributes(int i);
    int getAllSelectors(char name[]);
    int getAttributes(char name[]);
    AtrNode* getAttributes(int i, char name[]);
    AtrNode* getAttributeBySelector(char selector[], char attribute[]);
    void print();
    void fixSection(DLNode* current);
    void deleteLast();
    void deleteFirst();
    void deleteNode(DLNode* current);
    int deleteSection(int i);
    int deleteAttribute(int i, char name[]);
    DLList();
    ~DLList();
};