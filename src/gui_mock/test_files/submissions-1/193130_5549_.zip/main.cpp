#include <iostream>
#include "constans.h"
#include "list.h"
#include "atrlist.h"
#include "section.h"
#include "dllist.h"
#include "buffertools.h"

using namespace std;

void commandHandle(char command[][50], DLList* List) {
    if (command[1][0] == 'S') {
        if (command[2][0] == QUESTION_MARK && command[0][0] <= NINE && command[0][0] >= ZERO) {
            if (List->getSelectors(atoi(command[0])) >= 0) {
                cout << command[0] << "," << command[1] << ",";
                for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                    cout << command[2][i];
                }
                cout << " == " << List->getSelectors(atoi(command[0])) << endl;
            }

        }
        else if (command[2][0] == QUESTION_MARK && (command[0][0] >= UPPERCASE_A || command[0][0] == NUMBER_SIGN || command[0][0] == DOT)) {
            cout << command[0] << "," << command[1] << ",";
            for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                cout << command[2][i];
            }
            if (List->getAllSelectors(command[0])) {
                cout << " == " << List->getAllSelectors(command[0]) << endl;
            }
            else cout << " == 0" << endl;
        }
        else {
            Node* newNode = List->getSelectors(atoi(command[0]), atoi(command[2]));
            if (newNode) {
                cout << command[0] << "," << command[1] << ",";
                for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                    cout << command[2][i];
                }
                cout << " == " << newNode->data << endl;
            }
        }
    }
    else if (command[1][0] == 'A') {
        if (command[2][0] == QUESTION_MARK && command[0][0] <= NINE && command[0][0] >= ZERO) {
            if (List->getAttributes(atoi(command[0]))) {
                cout << command[0] << "," << command[1] << ",";
                for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                    cout << command[2][i];
                }
                cout << " == " << List->getAttributes(atoi(command[0])) << endl;
            }
        }
        else if (command[2][0] == QUESTION_MARK && (command[0][0] >= UPPERCASE_A || command[0][0] == NUMBER_SIGN || command[0][0] == DOT || command[0][0] == MINUS)) {
            cout << command[0] << "," << command[1] << ",";
            for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                cout << command[2][i];
            }
            if (List->getAttributes(command[0])) {
                cout << " == " << List->getAttributes(command[0]) << endl;
            }
            else cout << " == 0" << endl;
        }
        else {
            AtrNode* newNode = List->getAttributes(atoi(command[0]), command[2]);
            if (newNode) {
                cout << command[0] << "," << command[1] << ",";
                for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                    cout << command[2][i];
                }
                cout << " == " << newNode->value << endl;
            }
        }
    }
    else if (command[1][0] == 'E') {
        AtrNode* newNode = List->getAttributeBySelector(command[0], command[2]);
        if (newNode) {
            cout << command[0] << "," << command[1] << ",";
            for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                cout << command[2][i];
            }
            cout << " == " << newNode->value << endl;
        }
    }
    else if (command[1][0] == 'D' && command[2][0] == ASTERISK) {
        if (List->deleteSection(atoi(command[0]))) {
            cout << command[0] << "," << command[1] << ",";
            for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                cout << command[2][i];
            }
            cout << " == deleted" << endl;
        }
    }
    else if (command[1][0] == 'D' && command[0][0] <= NINE && command[2][0] >= UPPERCASE_A) {
        if (List->deleteAttribute(atoi(command[0]), command[2])) {
            cout << command[0] << "," << command[1] << ",";
            for (int i = 0;i < getArrLength(command[2], 50) - 1;++i) {
                cout << command[2][i];
            }
            cout << " == deleted" << endl;
        }
    }
}


int main() {
    DLList* newList = new DLList();
    char* section = new char[BUFFER];
    char* command = new char[BUFFER];
    clearBuffer(section, BUFFER);
    clearBuffer(command, BUFFER);
    char commandExecute[3][50];
  
    for (int i = 0;i < 3;i++) {
        for (int j = 0;j < 50;j++) {
            commandExecute[i][j] = NULL;
        }
    }

    int commandI = 0, commandJ = 0;
    int index = 0, indexCommand = 0;
    int inputMode = INPUT_CSS;
    int questionMark = 0, asterisk = 0;
    clearBuffer(section,BUFFER);
    int ch = 1;

    do {
        ch = getchar();
        switch (inputMode) {
        case INPUT_CSS:
            if (ch == QUESTION_MARK) questionMark++;
            if (questionMark == 4) {
                inputMode = INPUT_COMMAND;
                indexCommand = 0;
            }

            if (ch == CLOSING_BRACE) {
                newList->nodeHandle(section);
                index = 0;
                clearBuffer(section, BUFFER);
            }

            if (ch == '\n') {
                questionMark = 0;
                asterisk = 0;
            }
            section[index] = ch;
            index++;

            break;

        case INPUT_COMMAND:

            command[indexCommand] = ch;
            indexCommand++;

            if (ch == ASTERISK) asterisk++;
            if (asterisk == 4) inputMode = INPUT_CSS;

            if (ch == '\n' || ch == EOF) {
                if (command[0] == QUESTION_MARK && indexCommand == 2) {
                    cout << "? == " << newList->getSectionCount() << endl;
                }
                else if (command[0] == 'P') newList->print();
                if (indexCommand > 2) {
                    for (int i = 0;i < indexCommand;++i) {
                        if (command[i] != COMMA) {
                            commandExecute[commandI][commandJ] = command[i];
                            commandJ++;
                        }
                        else {
                            commandI++;
                            commandJ = 0;
                        }
                    }

                    for (int i = 0;i < 3;++i) {
                        commandJ = 0;
                        while (commandExecute[i][commandJ]) {
                            commandJ++;
                        }
                    }

                    commandHandle(commandExecute, newList);
                }

                for (int i = 0;i < 3;++i) {
                    for (int j = 0;j < 50;++j) {
                        commandExecute[i][j] = NULL;
                    }
                }
                clearBuffer(command, BUFFER);
                commandI = 0;
                commandJ = 0;
                indexCommand = 0;
                questionMark = 0;
                asterisk = 0;
            }
            break;
        }
    } while (ch != EOF);
    delete[] section;
    delete[] command;
}