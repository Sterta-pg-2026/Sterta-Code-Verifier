#pragma once
#include <iostream>
#include "constans.h"

using namespace std;

inline void clearBuffer(char arr[],int size) {
    for (int i = 0;i < size;i++) arr[i] = NULL;
}

inline void printBuffer(char arr[]) {
    for (int i = 0;i < BUFFER;i++) cout << arr[i];
    cout << endl;
}

inline int getArrLength(char arr[], int size) {
    int count = 0;
    for (int i = 0;i < size;i++) {
        if (arr[i] != NULL) count++;
        else break;
    }
    return count;
}