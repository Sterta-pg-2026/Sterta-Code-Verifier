#include "dllist.h"
#include <iostream>

using namespace std;

void DLList::append(char section[]) {
    if (tail->section_elements < T) {
        for (int i = 0;i < T;++i) {
            if (tail->sections[i] == nullptr) {
                Section* newSection = new Section;
                newSection->prepare(section);
                tail->sections[i] = newSection;
                tail->section_elements++;
                break;
            }
        }
    }
    else {
        DLNode* newNode = new DLNode();
        newNode->prepare(section);
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
        length++;
        counter = 1;
    }
}

int DLList::getLength() {
    return length;
}

int DLList::getSectionCount() {
    int count = 0;
    DLNode* current = head;
    while (current) {
        count += current->section_elements;
        current = current->next;
    }
    return count;
}

int DLList::getSelectors(int i) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int j = 0;j < T;++j) {
            if (current->sections[j] != nullptr) {
                if (i == index) {
                    return current->sections[j]->selectors->getLength();
                }
                index++;
            }
        }
        current = current->next;
    }
    return -1;
}

int DLList::getAttributes(int i) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int j = 0;j < T;++j) {
            if (current->sections[j] != nullptr) {
                if (i == index) {
                    return current->sections[j]->attributes->getLength();
                }
                index++;
            }
        }
        current = current->next;
    }
    return 0;
}

Node* DLList::getSelectors(int i, int j) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                if (i == index) {
                    Node* newNode = current->sections[k]->selectors->get(j - 1);
                    return newNode;
                }
                index++;
            }
        }
        current = current->next;
    }
    return 0;
}

int DLList::getAllSelectors(char name[]) {
    DLNode* current = head;
    int count = 0;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                Node* newNode = current->sections[k]->selectors->getByName(name);
                if (newNode) count++;
            }
        }
        current = current->next;
    }
    return count;
}

AtrNode* DLList::getAttributes(int i, char name[]) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                if (i == index) {
                    AtrNode* currentAtr = current->sections[k]->attributes->getByName(name);
                    if (currentAtr) return currentAtr;
                }
                index++;
            }
        }
        current = current->next;
    }
    return 0;
}


AtrNode* DLList::getAttributeBySelector(char selector[], char attribute[]) {
    DLNode* current = head;
    AtrNode* final = nullptr;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                Node* currentSelector = current->sections[k]->selectors->getByName(selector);
                if (currentSelector) {
                    AtrNode* currentAtr = current->sections[k]->attributes->getByName(attribute);
                    if (currentAtr) final = currentAtr;
                }
            }
        }
        current = current->next;
    }
    return final;
}


int DLList::getAttributes(char name[]) {
    DLNode* current = head;
    int count = 0;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                AtrNode* currentAtr = current->sections[k]->attributes->getByName(name);
                if (currentAtr) count++;
            }
        }
        current = current->next;
    }
    return count;
}

void DLList::print() {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int i = 0;i < T;++i) {
            if (current->sections[i] != nullptr) {
                cout << index << endl;
                current->sections[i]->selectors->print();
                current->sections[i]->attributes->print();
            }
        }
        cout << endl;
        current = current->next;
        index++;
    }
}

void DLList::fixSection(DLNode* current) {
    for (int i = 0; i < T - 1; ++i) {
        if (current->sections[i] == nullptr) {
            current->sections[i] = current->sections[i + 1];
            current->sections[i + 1] = nullptr;
        }
    }
}

void DLList::deleteLast() {
    if (length == 0) return;
    DLNode* current = tail;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        tail = tail->prev;
        tail->next = nullptr;
    }
    delete current;
    length--;
}

void DLList::deleteFirst() {
    if (length == 0) return;
    DLNode* current = head;
    if (length == 1) {
        head = nullptr;
        tail = nullptr;
    }
    else {
        head = head->next;
        head->prev = nullptr;
    }
    delete current;
    length--;
}

void DLList::deleteNode(DLNode* current) {
    if (current->prev == nullptr) return deleteFirst();
    else if (current->next == nullptr) return deleteLast();
    DLNode* temp = current;
    temp->next->prev = temp->prev;
    temp->prev->next = temp->next;
    delete temp;
    length--;
}

int DLList::deleteSection(int i) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                if (i == index) {
                    current->sections[k]->removeSection();
                    current->sections[k] = nullptr;
                    if (current->section_elements == 0) deleteNode(current);
                    else {
                        fixSection(current);
                        current->section_elements--;
                        counter--;
                    }
                    return 1;
                }
                index++;
            }
        }
        current = current->next;
    }
    return 0;
}

int DLList::deleteAttribute(int i, char name[]) {
    DLNode* current = head;
    int index = 1;
    while (current) {
        for (int k = 0;k < T;++k) {
            if (current->sections[k] != nullptr) {
                if (i == index) {
                    if (current->sections[k]->attributes->removeByName(name)) {
                        if (current->sections[k]->attributes->getLength() == 0) deleteSection(i);
                        return 1;
                    }
                }
                index++;
            }
        }
        current = current->next;
    }
    return 0;
}

DLNode::DLNode() {
    prev = nullptr;
    next = nullptr;
    for (int i = 0;i < T;i++) sections[i] = nullptr;
    section_elements = 1;
}

DLList::~DLList() {
    DLNode* current = head;
    while (head) {
        head = head->next;
        deleteNode(current);
        current = head;
    }
}

void DLNode::prepare(char section[]) {
    Section* newSection = new Section();
    newSection->prepare(section);
    this->sections[0] = newSection;
}

DLList::DLList() {
    head = nullptr;
    tail = nullptr;
    length = 0;
    counter = 0;
}

void DLList::nodeHandle(char section[]) {
    if (head == nullptr) {
        DLNode* newNode = new DLNode();
        newNode->prepare(section);
        head = newNode;
        tail = newNode;
        length = 1;
        counter = 1;
    }
    else {
        append(section);
    }
}
