#include "section.h"
#include <iostream>

using namespace std;

Section::Section() {
    attributes = nullptr;
    selectors = nullptr;
}

Section::~Section() {
    removeSection();
}

void Section::prepare(char sectionCode[]) {
    List* newList = new List();
    newList->prepare(sectionCode);
    this->selectors = newList;
    AtrList* newAtrList = new AtrList();
    newAtrList->prepare(sectionCode);
    this->attributes = newAtrList;
}

void Section::removeSection() {
    attributes->removeList();
    selectors->removeList();
}