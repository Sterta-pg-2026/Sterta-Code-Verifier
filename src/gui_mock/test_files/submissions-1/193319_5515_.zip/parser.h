#pragma once
#include "buffer.h"
#include "string.h"
#include "css.h"

class Parser {
  CSS css;
  static inline Buffer commands_start_token = Buffer("????");
  static inline Buffer commands_end_token = Buffer("****");
  static Buffer read_token(const char *termination_chars);
  static int parse_num(const Buffer &token);
  void parse_css();
  void parse_command();
public:
  explicit Parser(CSS &&css);
  void parse_all();
};