#pragma once
#include "block_linked_list.hpp"
#include <cstddef>

class String {
  char *_data;
  size_t _size;
  friend std::ostream& operator<<(std::ostream &out, const String &str);
  template<size_t BLOCK_SIZE>
  friend bool operator==(const String &str, const BlockLinkedList<char, BLOCK_SIZE> &list);
  friend bool operator==(const String &str1, const String &str2);
public:
  String();
  explicit String(size_t size);
  explicit String(const char* src);
  template<size_t BLOCK_SIZE>
  explicit String(const BlockLinkedList<char, BLOCK_SIZE> &list);

  String(const String &other);
  String& operator=(const String &other);
  String(String &&other) noexcept;
  String& operator=(String &&other) noexcept;
  ~String();

  size_t size() const;
};

template<size_t BLOCK_SIZE>
bool operator==(const String &str, const BlockLinkedList<char, BLOCK_SIZE> &list) {
  if(str.size() != list.size()) {
    return false;
  }
  size_t it1 = 0;
  auto it2 = list.cbegin();
  while(it2 != list.cend()) {
    if(str._data[it1] != *it2) {
      return false;
    }
    ++it1;
    ++it2;
  }
  return true;
}

template<size_t BLOCK_SIZE>
String::String(const BlockLinkedList<char, BLOCK_SIZE> &list)
  : String(list.size()) {
  size_t i=0;
  for(auto it=list.cbegin(); it!=list.cend(); ++it, ++i) {
    _data[i] = *it;
  }
}