#pragma once
#include <cstddef>
#include <stdexcept>
#include <iostream>

template<typename T, size_t BLOCK_SIZE>
struct BlockListNode {
  T vals[BLOCK_SIZE];
  size_t fill = 0;
  BlockListNode *prev = nullptr;
  BlockListNode *next = nullptr;
};

template<typename T, size_t BLOCK_SIZE>
struct ValueLocation {
  BlockListNode<T, BLOCK_SIZE>* node;
  size_t value_position;
};

template<typename T, size_t BLOCK_SIZE>
class BlockLinkedList {
protected:
  BlockListNode<T, BLOCK_SIZE> *first;
  BlockListNode<T, BLOCK_SIZE> *last;
  size_t count;

  template<class V, size_t BLOCK_SIZE2>
  friend bool operator==(const BlockLinkedList<V, BLOCK_SIZE2> &first, const BlockLinkedList<V, BLOCK_SIZE2> &second);

  ValueLocation<T, BLOCK_SIZE> get_ptr(long long index) const;
public:
  BlockLinkedList<T, BLOCK_SIZE>();
  BlockLinkedList(const BlockLinkedList<T, BLOCK_SIZE> &other);
  BlockLinkedList<T, BLOCK_SIZE>& operator=(const BlockLinkedList<T, BLOCK_SIZE> &other);
  BlockLinkedList(BlockLinkedList<T, BLOCK_SIZE> &&other) noexcept;
  BlockLinkedList<T, BLOCK_SIZE>& operator=(BlockLinkedList<T, BLOCK_SIZE> &&other) noexcept;
  ~BlockLinkedList<T, BLOCK_SIZE>();

  T& operator[](long long index);
  const T& operator[](long long index) const;
  size_t size() const;

  void push_back(const T &val);
  void push_back(T &&val);
  bool remove(long long index);
  void erase();

  class Iterator {
  protected:
    BlockListNode<T, BLOCK_SIZE> *node;
    size_t in_node_position;
  public:
    Iterator(BlockListNode<T, BLOCK_SIZE> *node, size_t in_node_position) { 
      this->node = node;
      this->in_node_position = in_node_position;
    }
    T& operator*() const {
      return node->vals[in_node_position];
    }
    T* operator->() {
      return &(node->vals[in_node_position]);
    }
    Iterator& operator++() {
      in_node_position++;
      if(in_node_position >= node->fill) {
        node = node->next;
        in_node_position = 0;
      }
      return *this;
    }
    Iterator operator++(int) const { 
      Iterator tmp = *this; ++(*this);
      return tmp;
    }
    friend bool operator==(const Iterator& a, const Iterator& b) {
      return (a.node == b.node) && (a.in_node_position == b.in_node_position);
    };
    friend bool operator!=(const Iterator& a, const Iterator& b) {
      return !(a == b);
    }
  };

  class ReverseIterator : public Iterator {
  public:
    ReverseIterator(BlockListNode<T, BLOCK_SIZE> *node, size_t in_node_position) 
      : Iterator(node, in_node_position) {};

    Iterator& operator++() {
      if(this->in_node_position <= 0) {
        this->node = this->node->prev;
        if(this->node != nullptr) {
          this->in_node_position = this->node->fill;
        } else {
          this->in_node_position = 1;
        }
      }
      this->in_node_position--;
      return *this;
    }
  };

  class ConstantIterator : public Iterator {
  public:
    ConstantIterator(BlockListNode<T, BLOCK_SIZE> *node, size_t in_node_position) 
      : Iterator(node, in_node_position) {};

    const T& operator*() const {
      return this->node->vals[this->in_node_position];
    }
    const T* operator->() const {
      return &(this->node->vals[this->in_node_position]);
    }
  };

  Iterator begin() { return Iterator(first, 0); }
  static Iterator end() { return Iterator(nullptr, 0); }
  ReverseIterator rbegin() { return ReverseIterator(last, last->fill-1); }
  static ReverseIterator rend() { return ReverseIterator(nullptr, 0); }
  ConstantIterator cbegin() const { return ConstantIterator(first, 0); }
  static ConstantIterator cend() { return ConstantIterator(nullptr, 0); }
};

template<typename T, size_t BLOCK_SIZE>
ValueLocation<T, BLOCK_SIZE> BlockLinkedList<T, BLOCK_SIZE>::get_ptr(long long index) const {
  if(index < 0) {
    index += size();
  }
  if(index >= count || index < 0) {
    return {nullptr, 0};
  }

  if(index < count - index - 1) {
    // iterate from beginning
    BlockListNode<T, BLOCK_SIZE> *now = first;
    while(index >= now->fill) {
      index -= now->fill;
      now = now->next;
    }
    return {now, (size_t)index};
  } else {
    // iterate from end
    index = count - index - 1;
    BlockListNode<T, BLOCK_SIZE> *now = last;
    while(index >= now->fill) {
      index -= now->fill;
      now = now->prev;
    }
    index = now->fill - index - 1;
    return {now, (size_t)index};
  }
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>::BlockLinkedList() {
  first = nullptr;
  last = nullptr;
  count = 0;
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>::BlockLinkedList(const BlockLinkedList<T, BLOCK_SIZE> &other) 
  : BlockLinkedList<T, BLOCK_SIZE>() {
  for(auto it=other.cbegin(); it != other.cend(); ++it) {
    push_back(*it);
  }
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>& BlockLinkedList<T, BLOCK_SIZE>::operator=(const BlockLinkedList<T, BLOCK_SIZE> &other) {
  BlockLinkedList<T, BLOCK_SIZE> temp(other);
  std::swap(*this, temp);
  return *this;
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>::BlockLinkedList(BlockLinkedList<T, BLOCK_SIZE> &&other) noexcept
  : BlockLinkedList<T, BLOCK_SIZE>() {
  std::swap(other.count, this->count);
  std::swap(other.first, this->first);
  std::swap(other.last, this->last);
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>& BlockLinkedList<T, BLOCK_SIZE>::operator=(BlockLinkedList<T, BLOCK_SIZE> &&other) noexcept {
  std::swap(other.count, this->count);
  std::swap(other.first, this->first);
  std::swap(other.last, this->last);
  return *this;
}

template<typename T, size_t BLOCK_SIZE>
BlockLinkedList<T, BLOCK_SIZE>::~BlockLinkedList<T, BLOCK_SIZE>() {
  erase();
}

template<typename T, size_t BLOCK_SIZE>
T& BlockLinkedList<T, BLOCK_SIZE>::operator[](long long index) {
  ValueLocation<T, BLOCK_SIZE> target = get_ptr(index);
  if(target.node == nullptr) {
    throw std::out_of_range("index too large");
  }
  return target.node->vals[target.value_position];
}

template<typename T, size_t BLOCK_SIZE>
const T& BlockLinkedList<T, BLOCK_SIZE>::operator[](long long index) const {
  ValueLocation<T, BLOCK_SIZE> target = get_ptr(index);
  if(target.node == nullptr) {
    throw std::out_of_range("index too large");
  }
  return target.node->vals[target.value_position];
}

template<typename T, size_t BLOCK_SIZE>
size_t BlockLinkedList<T, BLOCK_SIZE>::size() const {
  return count;
}

template<typename T, size_t BLOCK_SIZE>
bool operator==(const BlockLinkedList<T, BLOCK_SIZE> &first, const BlockLinkedList<T, BLOCK_SIZE> &second) {
  if(first.size() != second.size()) {
    return false;
  }
  auto it1 = first.cbegin();
  auto it2 = second.cbegin();

  while(it1 != first.cend()) {
    if(*it1 != *it2) {
      return false;
    }
    ++it1;
    ++it2;
  }

  return true;
}

template<typename T, size_t BLOCK_SIZE>
void BlockLinkedList<T, BLOCK_SIZE>::push_back(const T &val) {
  T temp = val;
  push_back(std::move(temp));
}

template<typename T, size_t BLOCK_SIZE>
void BlockLinkedList<T, BLOCK_SIZE>::push_back(T &&val) {
  if(last == nullptr || last->fill >= BLOCK_SIZE) {
    BlockListNode<T, BLOCK_SIZE> *new_node = new BlockListNode<T, BLOCK_SIZE>;
    if(first == nullptr) {
      first = new_node;
    }
    if(last != nullptr) {
      last->next = new_node;
    }
    new_node->prev = last;
    last = new_node;
  }
  last->vals[last->fill] = std::move(val);
  last->fill++;
  count++;
}

template<typename T, size_t BLOCK_SIZE>
bool BlockLinkedList<T, BLOCK_SIZE>::remove(long long index) {
  ValueLocation<T, BLOCK_SIZE> to_remove = get_ptr(index);
  if(to_remove.node == nullptr) {
    return false;
  }

  to_remove.node->vals[to_remove.value_position] = T();
  for(size_t i=to_remove.value_position+1; i<to_remove.node->fill; ++i) {
    to_remove.node->vals[i-1] = std::move(to_remove.node->vals[i]);
  }
  to_remove.node->fill--;
  count--;

  if(to_remove.node->fill > 0) {
    return true;
  }
  // node is empty - removing whole node
  if(to_remove.node == first) {
    first = to_remove.node->next;
  }
  if(to_remove.node == last) {
    last = to_remove.node->prev;
  }
  if(to_remove.node->prev != nullptr) {
    to_remove.node->prev->next = to_remove.node->next;
  }
  if(to_remove.node->next != nullptr) {
    to_remove.node->next->prev = to_remove.node->prev;
  }
  delete to_remove.node;
  return true;
}

template<typename T, size_t BLOCK_SIZE>
void BlockLinkedList<T, BLOCK_SIZE>::erase() {
  while(size() > 0) {
    remove(0);
  }
}