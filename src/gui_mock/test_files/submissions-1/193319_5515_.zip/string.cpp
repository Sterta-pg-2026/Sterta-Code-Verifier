#include "string.h"

std::ostream& operator<<(std::ostream &out, const String &str) {
  for(size_t i=0; i<str.size(); ++i) {
    out << str._data[i];
  }
  return out;
}

bool operator==(const String &str1, const String &str2) {
  if(str1.size() != str2.size()) {
    return false;
  }

  for(int i=0; i<str1.size(); ++i) {
    if(str1._data[i] != str2._data[i]) {
      return false;
    }
  }
  return true;
}

String::String()
  : String((size_t)0) {
}

String::String(size_t size) {
  _size = size;
  _data = new char[size];
}

String::String(const char* src) {
  _size = 0;
  while(src[_size] != '\0') {
    _size++;
  }
  _data = new char[_size];
  for(size_t i=0; i<_size; ++i) {
    _data[i] = src[i];
  }
}

String::String(const String &other)
  : String(other.size()) {
  for(int i=0; i<other.size(); ++i) {
    _data[i] = other._data[i];
  }
}

String& String::operator=(const String &other) {
  String temp(other);
  std::swap(*this, temp);
  return *this;
}

String::String(String &&other) noexcept {
  _data = other._data;
  other._data = nullptr;
  _size = other._size;
  other._size = 0;
}

String& String::operator=(String &&other) noexcept {
  std::swap(_data, other._data);
  std::swap(_size, other._size);
  return *this;
}

String::~String() {
  delete[] _data;
}

size_t String::size() const {
  return _size;
}