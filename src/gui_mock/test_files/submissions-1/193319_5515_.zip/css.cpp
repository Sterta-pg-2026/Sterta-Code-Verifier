#include "css.h"
#include "block_linked_list.hpp"
#include "string.h"
#include <cstddef>
#include <ostream>

LinkedList<String> CSS::split(const Buffer &token, const char delimiter) {
  LinkedList<String> result;
  bool skipped_whitespace = false;
  Buffer newfound;
  for(auto it=token.cbegin(); it != token.cend(); ++it) {
    if(!skipped_whitespace && Buffer::is_whitespace(*it)) {
      continue;
    }
    skipped_whitespace = true;
    if(*it == delimiter) {
      if(newfound.size() > 1) {
        newfound.rstrip();
        result.push_back(String(newfound));
        newfound = Buffer();
      }
      skipped_whitespace = false;
      continue;
    }
    newfound.push_back(*it);
  }
  newfound.rstrip();
  if(newfound.size() > 0) {
    result.push_back(String(newfound));
  }
  return result;
}

Attribute* Section::get_attribute(const Buffer &name) {
  for(auto it=attributes.begin(); it!=attributes.end(); ++it) {
    if(it->name == name) {
      return &(*it);
    }
  }
  return nullptr;
}

Attribute* Section::get_attribute(const String &name) {
  for(auto it=attributes.begin(); it!=attributes.end(); ++it) {
    if(it->name == name) {
      return &(*it);
    }
  }
  return nullptr;
}

bool Section::has_selector(const Buffer &selector) const {
  for(auto it=selectors.cbegin(); it!=selectors.cend(); ++it) {
    if(*it == selector) {
      return true;
    }
  }
  return false;
}

bool Section::has_attribute(const Buffer &name) const {
  for(auto it=attributes.cbegin(); it!=attributes.cend(); ++it) {
    if(it->name == name) {
      return true;
    }
  }
  return false;
}

bool Section::remove_attribute(const Buffer &name) {
  size_t index = 0;
  for(auto it=attributes.begin(); it!=attributes.end(); ++it, ++index) {
    if(it->name == name) {
      attributes.remove(index);
      return true;
    }
  }
  return false;
}

CSS::CSS() {
  sections_count = 0;
  active_section = nullptr;
}

void CSS::create_section(Buffer &selectors) {
  selectors.remove(-1);
  LinkedList<String> new_selectors = split(selectors, ',');

  if(new_selectors.size() == 1 && new_selectors[0].size() == 0) {
    active_section = &global_section;
    sections_count++;
    return;
  }

  sections.push_back(Section());
  Section &last = sections[-1];
  std::swap(last.selectors, new_selectors);
  active_section = &last;
  sections_count++;
}

void CSS::close_section() {
  active_section = nullptr;
}

void CSS::add_attribute(Buffer &attribute) {
  if(active_section == nullptr) {
    return;
  }

  attribute.remove(-1);
  LinkedList<String> splitted = split(attribute, ':');

  Attribute *found_attribute = active_section->get_attribute(splitted[0]);
  if(found_attribute != nullptr) {
    found_attribute->value = std::move(splitted[1]);
    return;
  }

  Attribute new_attribute{std::move(splitted[0]), std::move(splitted[1])};
  active_section->attributes.push_back(std::move(new_attribute));
}

Section* CSS::get_section(size_t index) {
  if(index >= sections.size()) {
    return nullptr;
  }
  return &sections[index];
}

Section* CSS::get_section(const Buffer &selector) {
  for(auto section=sections.rbegin(); section!=sections.rend(); ++section) {
    for(const auto &s: section->selectors) {
      if(s == selector) {
        return &(*section);
      }
    }
  }
  return nullptr;
}

size_t CSS::count_sections(const Buffer &selector) {
  size_t count = 0;
  for(auto section=sections.rbegin(); section!=sections.rend(); ++section) {
    if(section->has_selector(selector)) {
      count++;
    }
  }
  return count;
}

size_t CSS::count_attributes(const Buffer &name) {
  size_t count = 0;
  for(auto section=sections.rbegin(); section!=sections.rend(); ++section) {
    if(section->has_attribute(name)) {
      count++;
    }
  }
  return count;
}

size_t CSS::get_sections_count() const {
  return sections_count;
}

bool CSS::remove_section(size_t index) {
  if(sections.remove(index)) {
    sections_count--;
    return true;
  } else {
    return false; 
  }
}