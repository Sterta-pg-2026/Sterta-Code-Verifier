#pragma once
#include "block_linked_list.hpp"
#include <ostream>

const size_t BUFFER_BLOCK_SIZE = 10;

class Buffer : public BlockLinkedList<char, BUFFER_BLOCK_SIZE> {
  friend std::ostream& operator<<(std::ostream &out, const Buffer &str);
public:
  Buffer();
  explicit Buffer(const char *s);
  static bool is_whitespace(const char c);
  void rstrip();  // remove whitespace from beginning and end
};