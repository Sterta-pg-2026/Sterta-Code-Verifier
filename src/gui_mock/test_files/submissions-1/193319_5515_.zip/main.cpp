#include "css.h"
#include "parser.h"

int main() {
  CSS css;
  Parser(std::move(css)).parse_all();

  return 0;
}