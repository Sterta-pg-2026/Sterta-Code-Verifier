#include "buffer.h"
#include <cstddef>

std::ostream& operator<<(std::ostream &out, const Buffer &str) {
  for(auto it=str.cbegin(); it != str.cend(); ++it) {
    out << *it;
  }
  return out;
}

Buffer::Buffer() : BlockLinkedList<char, BUFFER_BLOCK_SIZE>() {};

Buffer::Buffer(const char* s) {
  for(size_t i=0; s[i] != '\0'; ++i) {
    push_back(s[i]);
  }
}

bool Buffer::is_whitespace(const char c) {
  switch(c) {
    case ' ':
    case '\t':
    case '\n':
      return true;
    default:
      return false;
  }
}

void Buffer::rstrip() {
  while(size() > 0 && is_whitespace(last->vals[last->fill-1])) {
    remove(size() - 1);
  }
}