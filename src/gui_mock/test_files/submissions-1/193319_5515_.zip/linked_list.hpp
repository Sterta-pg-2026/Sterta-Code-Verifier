#pragma once
#include <cstddef>
#include <stdexcept>
#include <iostream>

template<typename T>
struct ListNode {
  T val;
  ListNode *next = nullptr;
};

template<typename T>
class LinkedList {
protected:
  ListNode<T> *first;
  ListNode<T> *last;
  size_t count;

  template<class V2>
  friend bool operator==(const LinkedList<V2> &first, const LinkedList<V2> &second);

  ListNode<T>* get_ptr(long long index) const;
public:
  LinkedList<T>();
  LinkedList(const LinkedList<T> &other);
  LinkedList<T>& operator=(const LinkedList<T> &other);
  LinkedList(LinkedList<T> &&other) noexcept;
  LinkedList<T>& operator=(LinkedList<T> &&other) noexcept;
  ~LinkedList<T>();

  T& operator[](long long index);
  const T& operator[](long long index) const;
  size_t size() const;

  void push_back(const T &val);
  void push_back(T &&val);
  bool remove(long long index);
  void erase();

  class Iterator {
  protected:
    ListNode<T> *node;
  public:
    explicit Iterator(ListNode<T> *node) { 
      this->node = node;
    }
    T& operator*() const {
      return node->val;
    }
    T* operator->() {
      return &(node->val);
    }
    Iterator& operator++() {
      node = node->next;
      return *this;
    }
    Iterator operator++(int) const { 
      Iterator tmp = *this; ++(*this);
      return tmp;
    }
    friend bool operator==(const Iterator& a, const Iterator& b) {
      return a.node == b.node;
    };
    friend bool operator!=(const Iterator& a, const Iterator& b) {
      return !(a == b);
    }
  };

  class ConstantIterator : public Iterator {
  public:
    explicit ConstantIterator(ListNode<T> *node) 
      : Iterator(node) {};

    const T& operator*() const {
      return this->node->val;
    }
    const T* operator->() const {
      return &(this->node->val);
    }
  };

  Iterator begin() { return Iterator(first); }
  static Iterator end() { return Iterator(nullptr); }
  ConstantIterator cbegin() const { return ConstantIterator(first); }
  static ConstantIterator cend() { return ConstantIterator(nullptr); }
};

template<typename T>
ListNode<T>* LinkedList<T>::get_ptr(long long index) const {
  if(index < 0) {
    index += size();
  }
  if(index >= count || index < 0) {
    return nullptr;
  }

  if(index == size() - 1) {
    return last;
  }

  ListNode<T> *now = first;
  while(index--) {
    now = now->next;
  }
  return now;
}

template<typename T>
LinkedList<T>::LinkedList() {
  first = nullptr;
  last = nullptr;
  count = 0;
}

template<typename T>
LinkedList<T>::LinkedList(const LinkedList<T> &other) 
  : LinkedList<T>() {
  for(auto it=other.cbegin(); it != other.cend(); ++it) {
    push_back(*it);
  }
}

template<typename T>
LinkedList<T>& LinkedList<T>::operator=(const LinkedList<T> &other) {
  LinkedList<T> temp(other);
  std::swap(*this, temp);
  return *this;
}

template<typename T>
LinkedList<T>::LinkedList(LinkedList<T> &&other) noexcept
  : LinkedList<T>() {
  std::swap(other.count, this->count);
  std::swap(other.first, this->first);
  std::swap(other.last, this->last);
}

template<typename T>
LinkedList<T>& LinkedList<T>::operator=(LinkedList<T> &&other) noexcept {
  std::swap(other.count, this->count);
  std::swap(other.first, this->first);
  std::swap(other.last, this->last);
  return *this;
}

template<typename T>
LinkedList<T>::~LinkedList<T>() {
  erase();
}

template<typename T>
T& LinkedList<T>::operator[](long long index) {
  ListNode<T> *target = get_ptr(index);
  if(target == nullptr) {
    throw std::out_of_range("index too large");
  }
  return target->val;
}

template<typename T>
const T& LinkedList<T>::operator[](long long index) const {
  ListNode<T> *target = get_ptr(index);
  if(target == nullptr) {
    throw std::out_of_range("index too large");
  }
  return target->val;
}

template<typename T>
size_t LinkedList<T>::size() const {
  return count;
}

template<typename T>
bool operator==(const LinkedList<T> &first, const LinkedList<T> &second) {
  if(first.size() != second.size()) {
    return false;
  }
  auto it1 = first.cbegin();
  auto it2 = second.cbegin();

  while(it1 != first.cend()) {
    if(*it1 != *it2) {
      return false;
    }
    ++it1;
    ++it2;
  }

  return true;
}

template<typename T>
void LinkedList<T>::push_back(const T &val) {
  T temp = val;
  push_back(std::move(temp));
}

template<typename T>
void LinkedList<T>::push_back(T &&val) {
  ListNode<T> *new_node = new ListNode<T>;
  new_node->val = std::move(val);
  if(first == nullptr) {
    first = new_node;
  }
  if(last != nullptr) {
    last->next = new_node;
  }
  last = new_node;
  count++;
}

template<typename T>
bool LinkedList<T>::remove(long long index) {
  if(index == 0 && size() > 0) {
    ListNode<T> *to_remove = first;
    first = first->next;
    delete to_remove;
    count--;
    return true;
  }
  ListNode<T> *prev_to_remove = get_ptr(index-1);
  if(prev_to_remove == nullptr || prev_to_remove->next == nullptr) {
    return false;
  }
  ListNode<T> *to_remove = prev_to_remove->next;
  prev_to_remove->next = prev_to_remove->next->next;
  delete to_remove;
  count--;
  return true;
}

template<typename T>
void LinkedList<T>::erase() {
  while(size() > 0) {
    remove(0);
  }
}