#pragma once
#include "block_linked_list.hpp"
#include "linked_list.hpp"
#include "buffer.h"
#include "string.h"
#include <cstddef>

const size_t T = 23;

struct Attribute {
  String name;
  String value;
};

struct Section {
  LinkedList<String> selectors;
  LinkedList<Attribute> attributes;

  Attribute* get_attribute(const Buffer &name);
  Attribute* get_attribute(const String &name);
  bool has_selector(const Buffer &selector) const;
  bool has_attribute(const Buffer &name) const;

  bool remove_attribute(const Buffer &name);
};

class CSS {
  Section global_section;
  BlockLinkedList<Section, T> sections;
  size_t sections_count;
  Section *active_section;
  static LinkedList<String> split(const Buffer &token, const char delimiter);
public:
  CSS();
  void create_section(Buffer &selectors); // selectors separated with commas, ending with {
  void close_section();
  void add_attribute(Buffer &attribute);  // attribute in the form of "name: value;"

  Section* get_section(size_t index);   // if section not found, return global_session
  Section* get_section(const Buffer &selector);
  size_t count_sections(const Buffer &selector);
  size_t count_attributes(const Buffer &name);
  size_t get_sections_count() const;

  bool remove_section(size_t index);
};