#include "parser.h"
#include <cstdio>
#include <iostream>

Buffer Parser::read_token(const char *termination_chars) {
  Buffer token;
  bool skipped_whitespace = false;
  int c;
  while((c = getchar()) != EOF) {
    if(c < ' ' && c != '\n') {
      continue;
    }
    if(!skipped_whitespace && Buffer::is_whitespace(c)) {
      continue;
    }
    skipped_whitespace = true;
    token.push_back(c);
    for(size_t i=0; termination_chars[i] != '\0'; ++i) {
      if(c == termination_chars[i]) {
        return token;
      }
    }
    if(token == commands_start_token || token == commands_end_token) {
      break;
    }
  }
  return token;
}

int Parser::parse_num(const Buffer &token) {
  int num = 0;
  for(auto it=token.cbegin(); it!=token.cend(); ++it) {
    if(*it < '0' || '9' < *it) {
      return num;
    }
    num *= 10;
    num += *it - '0';
  }
  return num;
}

void Parser::parse_css() {
  Buffer token;
  while(true) {
    token = read_token(";{}");
    if(token.size() == 0) {
      break;
    }
    if(token == commands_start_token) {
      break;
    }
    token.rstrip();
    switch(token[-1]) {
      case ';':
        css.add_attribute(token);
      break;
      case '{':
        css.create_section(token);
      break;
      case '}':
        if(token.size() > 1) {
          css.add_attribute(token);
        }
        css.close_section();
      break;
    }
  }
}

void Parser::parse_command() {
  while(true) {
    Buffer part1 = read_token(",\n");
    if(part1.size() <= 0) {
      break;
    }
    if(part1[0] == '?') {
      std::cout << "? == " << css.get_sections_count() << std::endl;
      continue;
    }
    if(part1 == commands_end_token) {
      break;
    }
    Buffer part2 = read_token(",");
    Buffer part3 = read_token("\n");
    part1.remove(-1);
    part2.remove(-1);
    part3.rstrip();
    int val1 = parse_num(part1);
    int val3 = parse_num(part3);

    Section *found_section = nullptr;
    if(val1 > 0 && part3[0] != '*') {
      found_section = css.get_section(val1-1);
      if(found_section == nullptr) {
        continue;
      }
    }
    if(val1 > 0 && part2[0] == 'S' && part3[0] == '?') {
      std::cout << val1 << "," << part2 << "," << part3 << " == " << found_section->selectors.size() << std::endl;
    } else
    if(val1 > 0 && part2[0] == 'A' && part3[0] == '?') {
      std::cout << val1 << "," << part2 << "," << part3 << " == " << found_section->attributes.size() << std::endl;
    } else
    if(val1 > 0 && part2[0] == 'S' && val3 > 0) {
      if(found_section->selectors.size() <= val3-1) {
        continue;
      }
      std::cout << val1 << "," << part2 << "," << val3 << " == " << found_section->selectors[val3-1] << std::endl;
    } else
    if(val1 > 0 && part2[0] == 'A' && val3 == 0) {
      const Attribute *found = found_section->get_attribute(part3);
      if(found == nullptr) {
        continue;
      }
      std::cout << val1 << "," << part2 << "," << part3 << " == " << found->value << std::endl;
    } else
    if(val1 == 0 && part2[0] == 'A' && part3[0] == '?') {
      std::cout << part1 << "," << part2 << "," << part3 << " == " << css.count_attributes(part1) << std::endl;
    } else
    if(val1 == 0 && part2[0] == 'S' && part3[0] == '?') {
      std::cout << part1 << "," << part2 << "," << part3 << " == " << css.count_sections(part1) << std::endl;
    } else
    if(val1 == 0 && part2[0] == 'E' && val3 == 0) {
      found_section = css.get_section(part1);
      if(found_section == nullptr) {
        continue;
      }
      Attribute *found_attribute = found_section->get_attribute(part3);
      if(found_attribute == nullptr) {
        continue;
      }
      std::cout << part1 << "," << part2 << "," << part3 << " == " << found_attribute->value << std::endl;
    } else
    if(val1 > 0 && part2[0] == 'D' && part3[0] == '*') {
      if(css.remove_section(val1-1)) {
        std::cout << part1 << "," << part2 << "," << part3 << " == " << "deleted" << std::endl;
      }
    } else
    if(val1 > 0 && part2[0] == 'D' && val3 == 0) {
      bool result = found_section->remove_attribute(part3);
      if(found_section->attributes.size() <= 0) {
        css.remove_section(val1-1);
      }
      if(result) {
        std::cout << part1 << "," << part2 << "," << part3 << " == " << "deleted" << std::endl;
      }
    } else {
      // std::cerr << "UNIMPL: " << part1 << "," << part2 << "," << part3 << std::endl;
    }
  }
}

Parser::Parser(CSS &&css) {
  this->css = std::move(css);
}

void Parser::parse_all() {
  while(!feof(stdin)) {
    parse_css();
    parse_command();
  }
}