#include <iostream>
#include <regex>

const int T = 29;
const int BUFOR = 256;

bool compare(const char *a, const char *b)
{
    int i = 0;
    while (true)
    {
        if (a[i] != b[i]) return false;
        else if(a[i]=='\0') return true;
        i++;
    }
    return true;
}


struct Selector {
    Selector* p = nullptr;
    Selector* n = nullptr;
    char name[BUFOR];
};
class SelectorList {
public:
    Selector* f = nullptr;
    Selector* l = nullptr;
    void add(Selector* newS) {
        if (l == nullptr) {
            f = newS;
            l = newS;
        } else {
            l->n = newS;
            newS->p = l;
            l = newS;
        }
    }
};
struct Attribute {
    Attribute* p = nullptr;
    Attribute* n = nullptr;
    char name[BUFOR];
    char value[BUFOR];
};
class AttributeList {
public:
    Attribute* f = nullptr;
    Attribute* l = nullptr;
    void add(Attribute* newA) {
        if (l == nullptr) {
            f = newA;
            l = newA;
        } else {
            l->n = newA;
            newA->p = l;
            l = newA;
        }
    }
};



struct Block
{
    Selector* FSelector = nullptr;
    Selector* LSelector = nullptr;
    Attribute* FAttribute = nullptr;
    Attribute* LAttribute = nullptr;
    int Snum = 0;
    int Anum = 0;
    Block* p = nullptr;
    Block* n = nullptr;
};
struct BlockList
{
    Block blocks[T];
    BlockList* p = nullptr;
    BlockList* n = nullptr;
    int Tnum = 0;
};
class LIST
{
public:
    BlockList* f = nullptr;
    BlockList* l = nullptr;
    int Bnum = 0;

    void add(Block* newB)
    {
        Bnum++;
        if (f == nullptr) {
            f = new BlockList;
            f->Tnum++;
            f->blocks[0] = *newB;
            l = f;
        } else {
            BlockList* n = f;
            while (true)
            {
                if (n->Tnum < T) {
                    n->blocks[n->Tnum] = *newB;
                    n->blocks[n->Tnum].p = &(n->blocks[n->Tnum-1]);
                    n->blocks[n->Tnum-1].n = &(n->blocks[n->Tnum]);
                    n->Tnum++;
                    break;
                } else {
                    if (n->n == nullptr) {
                        n->n = new BlockList;
                        n->n->blocks[0] = *newB;
                        n->n->Tnum++;
                        n->n->p = n;
                        n->n->blocks[0].p = &(n->blocks[T-1]);
                        n->blocks[T-1].n = &(n->n->blocks[0]);
                        l = n->n;
                        break;
                    } else n = n->n;
                }
            }
        }
    }

    void clean()
    {
        if (f != nullptr) {
            BlockList* BL = f;
            while (true)
            {
                bool remove = true;
                for (int i = 0; i < BL->Tnum; i++)
                    if (BL->blocks[i].Anum != 0)
                    {
                        remove = false;
                        break;
                    }
                
                if (remove) {
                    if (BL->p == nullptr && BL->n == nullptr) {
                        delete BL;
                        f = nullptr;
                        l = nullptr;
                        break;
                    } else if (BL->p == nullptr) {
                        BL->n->p = nullptr;
                        f = BL->n;
                        delete BL;
                        BL = f;
                    } else if(BL->n == nullptr) {
                        BL->p->n = nullptr;
                        l = BL->p;
                        delete BL;
                        break;
                    } else {
                        BlockList* BL1 = BL->n;
                        BL->p->n = BL->n;
                        BL->n->p = BL->p;
                        delete BL;
                        BL = BL1;
                    }
                } else {
                    if (BL == l) break;
                    BL = BL->n;
                }
            }
        }
    }


    void NumOfB()
    {
        std::cout<<"? == "<<Bnum<<'\n';
    }

    void NumOfS(int a)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            int i = 0;
            while (i!=a)
            {
                block = block->n;
                if(block->Anum != 0) i++;
            }
            std::cout<<++a<<",S,? == "<<block->Snum<<'\n';
        }
    }
    void AllOfS(char* a)
    {
        int found = 0;
        if (Bnum != 0)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            while (true)
            {
                if (block->Anum != 0 && block->Snum != 0)
                {
                    Selector* s = block->FSelector;
                    while (true)
                    {
                        if (compare(a, s->name))
                        {
                            found++;
                            break;
                        }
                        if (s == block->LSelector) break;
                        s = s->n;
                    }
                }
                if (block->n == nullptr) break;
                block = block->n;
            }
        }
        std::cout<<a<<",S,? == "<<found<<'\n';
    }
    void OneS(int a, int b)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            int i = 0;
            while (i != a)
            {
                block = block->n;
                if (block->Anum != 0) i++;
            }
            if (b < block->Snum)
            {
                Selector* s = block->FSelector;
                i = 0;
                while (i != b)
                {
                    s = s->n;
                    i++;
                }
                std::cout<<++a<<",S,"<<++b <<" == "<<s->name<<'\n';
            }
        }
    }


    void NumOfA(int a)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            int i = 0;
            while (i != a)
            {
                block = block->n;
                if (block->Anum != 0) i++;
            }
            std::cout<<++a<<",A,? == "<<block->Anum <<'\n';
        }
    }
    void AllOfA(char* a)
    {
        int found = 0;
        if (Bnum != 0)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            while (true)
            {
                if (block->Anum != 0)
                {
                    Attribute* at = block->FAttribute;
                    while (true)
                    {
                        if (compare(a, at->name))
                        {
                            found++;
                            break;
                        }
                        if (at == block->LAttribute) break;
                        at = at->n;
                    }
                }
                if (block->n == nullptr) break;
                block = block->n;
            }
        }
        std::cout<<a<<",A,? == "<<found<<'\n';
    }
    void OneA(int a, char* b)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            int i = 0;
            while (i != a)
            {
                block = block->n;
                if (block->Anum != 0) i++;
            }
            Attribute* at = block->FAttribute;
            while (true)
            {
                if (compare(b, at->name))
                {
                    std::cout<<++a<<",A,"<<b<<" == "<< at->value<<'\n';
                    break;
                }
                if (at == block->LAttribute) break;
                at = at->n;
            }
        }
    }


    void ValOfA(char* a, char* b)
    {
        if (Bnum != 0)
        {
            bool isselector = false, notfound = true;
            Block* block = &l->blocks[0];
            while (block->n != nullptr) block = block->n;
            while (block->Anum == 0) block = block->p;
            while (notfound)
            {
                if (block->Anum != 0 && block->Snum != 0)
                {
                    Selector* s = block->FSelector;
                    while (true)
                    {
                        if (compare(a, s->name))
                        {
                            isselector = true;
                            break;
                        }
                        if (s == block->LSelector) break;
                        s = s->n;
                    }
                    if (isselector)
                    {
                        Attribute* at = block->FAttribute;
                        while (true)
                        {
                            if (compare(b, at->name))
                            {
                                std::cout<<a<<",E,"<<b<<" == "<< at->value<<'\n';
                                notfound = false;
                                break;
                            }
                            if (at == block->LAttribute) break;
                            at = at->n;
                        }
                    }
                }
                isselector = false;
                if (block == &f->blocks[0]) break;
                block = block->p;
            }
        }
    }


    void DeleteB(int a)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->Anum == 0) block = block->n;
            int i = 0;
            while (i != a)
            {
                block = block->n;
                if (block->Anum != 0) i++;
            }
            
            Attribute* at = block->FAttribute;
            while (at != nullptr) {
                Attribute* at2 = at->n;
                delete at;
                at = at2;
            }
            Selector* s = block->FSelector;
            while (s != nullptr) {
                Selector* s2 = s->n;
                delete s;
                s = s2;
            }
            block->FAttribute = nullptr;
            block->LAttribute = nullptr;
            block->LSelector = nullptr;
            block->FSelector = nullptr;
            block->Anum = 0;
            block->Snum = 0;
            Bnum--;
            clean();
            std::cout<<++a<<",D,* == deleted"<<'\n';
        }
    }
    void DeleteA(int a, char* b)
    {
        if (a < Bnum)
        {
            Block* block = &f->blocks[0];
            while (block->FAttribute == nullptr) block = block->n;
            int i = 0;
            while (i != a)
            {
                block = block->n;
                if (block->FAttribute != nullptr) i++;
            }

            Attribute* at = block->FAttribute;
            while (true)
            {
                if (compare(b, at->name))
                {
                    at->name[0] = '\0';
                    at->value[0] = '\0';
                    block->Anum--;
                    if (block->Anum == 0)
                    {
                        Attribute* at1 = block->FAttribute;
                        while (at1 != nullptr) {
                            Attribute* at2 = at1->n;
                            delete at1;
                            at1 = at2;
                        }
                        Selector* s = block->FSelector;
                        while (s != nullptr) {
                            Selector* s2 = s->n;
                            delete s;
                            s = s2;
                        }
                        block->FAttribute = nullptr;
                        block->LAttribute = nullptr;
                        block->LSelector = nullptr;
                        block->FSelector = nullptr;
                        block->Anum = 0;
                        block->Snum = 0;
                        Bnum--;
                        clean();
                    }
                    std::cout<<++a<<",D,"<<b<<" == deleted"<<'\n';
                    break;
                }
                if (at == block->LAttribute) break;
                at = at->n;
            }
        }
    }
};



struct K
{
    char txt[3][BUFOR];
    int num = 0;
    bool selector = true, value = false, css = true, empty = true;
};
struct O
{
    Block* B = new Block;
    Selector* s = new Selector;
    Attribute* a = new Attribute;
    SelectorList* sl = new SelectorList;
    AttributeList* al = new AttributeList;
};

int main()
{
    K k;
    O o;
    LIST L;
    char c;
    int i = 0;
    
    while ((c = std::cin.get()))
    {
        if(k.css)
        {
            if(c==EOF) break;
            if (k.selector)
            {
                if (c == ',' || c == '{') {
                    while (i > 0 && isspace(o.s->name[i-1])) i--;
                    o.s->name[i] = '\0';
                    i = 0;
                    if (!k.empty)
                    {
                        o.sl->add(o.s);
                        if (o.B->FSelector == nullptr) o.B->FSelector = o.sl->f;
                        o.B->LSelector = o.sl->l;
                        o.B->Snum++;
                    }
                    o.s = new Selector;
                    k.empty = true;
                    if (c == '{') k.selector = false;
                } else if (k.empty) {
                    if (!isspace(c))
                    {
                        o.s->name[i++] = c;
                        k.empty = false;
                    }
                } else o.s->name[i++] = c;

                if (c=='\n' && i==5 && o.s->name[0]=='?' && o.s->name[1]=='?' && o.s->name[2]=='?' && o.s->name[3]=='?')
                {
                    k.css = false;
                    i = 0;
                    k.empty = true;
                }
            }
            else
            {
                if (!k.value)
                {
                    if (c == ':') {
                        while (i > 0 && isspace(o.a->name[i-1])) i--;
                        o.a->name[i] = '\0';
                        i = 0;
                        k.value = true;
                        k.empty = true;
                    } else if (c == '}') {
                        L.add(o.B);
                        o.B = new Block;
                        o.sl = new SelectorList;
                        o.al = new AttributeList;
                        k.selector = true;
                        k.empty = true;
                    } else if (k.empty) {
                        if (!isspace(c))
                        {
                            o.a->name[i++] = c;
                            k.empty = false;
                        }
                    } else o.a->name[i++] = c;
                }
                else
                {
                    if (c == ';' || c == '}') {
                        while (i > 0 && isspace(o.a->value[i-1])) i--;
                        o.a->value[i] = '\0';
                        i = 0;
                        bool before = false;
                        if (o.B->Anum != 0)
                        {
                            Attribute* at = o.B->FAttribute;
                            while (!before)
                            {
                                if (compare(at->name, o.a->name))
                                {
                                    for (int j = 0; j < BUFOR; j++) at->value[j] = o.a->value[j];
                                    before = true;
                                }
                                if (at == o.B->LAttribute) break;
                                at = at->n;
                            }
                        }
                        if (!before) {
                            o.al->add(o.a);
                            if (o.B->FAttribute == nullptr) o.B->FAttribute = o.al->f;
                            o.B->LAttribute = o.al->l;
                            o.B->Anum++;
                        }

                        o.a = new Attribute;
                        k.value = false;
                        k.empty = true;
                        if (c == '}') {
                            L.add(o.B);
                            o.B = new Block;
                            o.sl = new SelectorList;
                            o.al = new AttributeList;
                            k.selector = true;
                        }
                    } else if (k.empty) {
                        if (!isspace(c))
                        {
                            o.a->value[i++] = c;
                            k.empty = false;
                        }
                    } else o.a->value[i++] = c;
                }
            }
        }
        else
        {
            if (c == '\n' || c==EOF) {
                if (k.num == 0) {
                    while (i>0 && isspace(k.txt[k.num][i-1])) i--;
                    k.txt[k.num][i] = '\0';

                    if (compare(k.txt[k.num], "?")) L.NumOfB();
                    if (compare(k.txt[k.num], "****")) k.css = true;
                } else {
                    while (i > 0 && isspace(k.txt[k.num][i - 1])) i--;
                    k.txt[k.num][i] = '\0';
                    k.num = 0;

                    if (k.txt[1][0] == 'S') {
                        if (k.txt[2][0] == '?') {
                            if (std::regex_search(k.txt[0],std::regex("^(\\d)"))) L.NumOfS(std::stoi(k.txt[0])-1);
                            else L.AllOfS(k.txt[0]);
                        } else L.OneS(std::stoi(k.txt[0])-1, std::stoi(k.txt[2])-1);
                    } else if (k.txt[1][0] == 'A') {
                        if (k.txt[2][0] == '?') {
                            if (std::regex_search(k.txt[0],std::regex("^(\\d)"))) L.NumOfA(std::stoi(k.txt[0])-1);
                            else L.AllOfA(k.txt[0]);
                        } else L.OneA(std::stoi(k.txt[0])-1, k.txt[2]);
                    } else if (k.txt[1][0] == 'D') {
                        if (k.txt[2][0] == '*') L.DeleteB(std::stoi(k.txt[0])-1);
                        else L.DeleteA(std::stoi(k.txt[0])-1, k.txt[2]);
                    } else L.ValOfA(k.txt[0], k.txt[2]);
                }
                i = 0;
                k.empty = true;
                if (c == EOF) break;
            } else {
                if (c == ',') {
                    while (i > 0 && isspace(k.txt[k.num][i - 1])) i--;
                    k.txt[k.num][i] = '\0';
                    i = 0;
                    k.empty = true;
                    k.num++;
                } else if (k.empty) {
                    if (!isspace(c))
                    {
                        k.txt[k.num][i++] = c;
                        k.empty = false;
                    }
                } else k.txt[k.num][i++] = c;
            }
        }
    }
    delete o.B;
    delete o.s;
    delete o.a;
    delete o.sl;
    delete o.al;
}