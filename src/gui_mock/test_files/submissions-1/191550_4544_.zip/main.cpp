#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define T 11
#define MAX_INPUT 1000

struct Attribute {
    char* name = NULL;
    char* value = NULL;
};

struct Section {
    int selector = 0;
    int attribute = 0;
    char** selectors = NULL;
    Attribute* attributes = NULL;
};

struct Block {
    Section sections[T];
    int n = 0;
};

struct Node {
    Block* block = NULL;
    Node* next = NULL;
    Node* prev = NULL;
};

struct List {
    Node* first = NULL;
    Node* last = NULL;
};

Block* NewBlock(List* list) {

    Node* new_node = new Node();
    Block* new_block = new Block();
    new_node->block = new_block;

    if (list->last != NULL) {
        list->last->next = new_node;
        new_node->prev = list->last;
    }
    list->last = new_node;

    if (list->first == NULL) {
        list->first = new_node;
    }

    return new_block;
}

Section* NewSection(List* list) {
    Section* new_section = new Section();

    Block* current_block = NULL;
    Node* last_node = list->last;
    if (last_node == NULL || last_node->block->n == T) {
        current_block = new Block();
        Node* new_node = new Node();
        new_node->block = current_block;

        if (last_node != NULL) {
            last_node->next = new_node;
            new_node->prev = last_node;
        }
        list->last = new_node;

        if (list->first == NULL) {
            list->first = new_node;
        }
    }
    else {
        current_block = last_node->block;
    }

    current_block->sections[current_block->n] = *new_section;
    current_block->n++;

    return &(current_block->sections[current_block->n - 1]);
}

void NewSelector(Section* section, char* selector) {
    section->selector++;
    char** new_selectors = new char* [section->selector];

    for (int i = 0; i < section->selector - 1; i++) {
        new_selectors[i] = section->selectors[i];
    }
    new_selectors[section->selector - 1] = selector;

    delete[] section->selectors;
    section->selectors = new_selectors;
}

void NewAttribute(Section* section, char* name, char* value) {
    section->attribute++;
    Attribute* new_attributes = new Attribute[section->attribute];
    for (int i = 0; i < section->attribute - 1; i++) {
        new_attributes[i].name = section->attributes[i].name;
        new_attributes[i].value = section->attributes[i].value;
    }
    new_attributes[section->attribute - 1].name = name;
    new_attributes[section->attribute - 1].value = value;
    delete[] section->attributes;
    section->attributes = new_attributes;
}

Block* BlockFromsection_number(List* list, int section_n, int* block_sec_n) {
    Node* curr_node = list->first;
    int total_sections = 0;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        total_sections += curr_block->n;
        if (total_sections > section_n) {
            *block_sec_n = section_n - (total_sections - curr_block->n);
            return curr_block;
        }
        curr_node = curr_node->next;
    }
    return NULL;
}

Section* SectionWithNumber(List* list, int section_n) {
    Node* curr_node = list->first;
    int total_sections = 0;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        if (total_sections + curr_block->n > section_n) {
            int section_inblock_n = section_n - total_sections;
            return &(curr_block->sections[section_inblock_n]);
        }
        total_sections += curr_block->n;
        curr_node = curr_node->next;
    }
    return NULL;
}




bool RemoveSectionByIndex(List* list, int section_n) {

    Node* current_block_node = list->first;
    int counter = 0;
    while (current_block_node) {
        Block* current_block = current_block_node->block;
        for (int i = 0; i < current_block->n; i++) {
            Section* current_section = &current_block->sections[i];
            if (current_section->selector > 0 && current_section->selectors[0][0] == ',') {
                continue;
            }
            if (counter == section_n) {

                free(current_section->selectors[0]);
                for (int j = 0; j < current_section->attribute; j++) {
                    Attribute* current_attribute = &current_section->attributes[j];
                    free(current_attribute->name);
                    free(current_attribute->value);
                }
                free(current_section->attributes);
                for (int j = i; j < current_block->n - 1; j++) {
                    current_block->sections[j] = current_block->sections[j + 1];
                }
                current_block->n--;
                return true;
            }
            else {
                counter++;
            }
        }
        current_block_node = current_block_node->next;
    }
    return false;
}
bool RemoveAttributeByName(List* list, int section_n, const char* attribute) {
    if (!list) {
        return false;
    }

    Node* current_block_node = list->first;
    while (current_block_node) {
        Block* current_block = current_block_node->block;
        for (int i = 0; i < current_block->n; i++) {
            Section* current_section = &current_block->sections[i];
            if (current_section->selector > 0 && current_section->selectors[0][0] == ',') {
                continue;
            }
            if (section_n == 0) {
                for (int j = 0; j < current_section->attribute; j++) {
                    Attribute* current_attribute = &current_section->attributes[j];
                    if (strcmp(current_attribute->name, attribute) == 0) {
                        free(current_attribute->name);
                        free(current_attribute->value);
                        for (int k = j; k < current_section->attribute - 1; k++) {
                            current_section->attributes[k] = current_section->attributes[k + 1];
                        }
                        current_section->attribute--;
                        current_block->n--;
                        return true;
                    }
                }
                return false;
            }
            else {
                section_n--;
            }
        }
        current_block_node = current_block_node->next;
    }
    return false;
}


//?
void PrintNumberOfSections(List* list) {
    Node* current_node = list->first;
    int counter = 0;
    while (current_node != NULL) {
        counter += current_node->block->n;
        current_node = current_node->next;
    }
    printf("? == %d\n", counter);
}

// i,S,?
void SelectorNum(List* list, int section_n) {
    Section* section = SectionWithNumber(list, section_n);
    if (section) {
        printf("%d,S,? == %d\n", section_n + 1, section->selector);
    }
}

// i,A,?
void AttributeNum(List* list, int section_n) {
    Section* section = SectionWithNumber(list, section_n);
    if (section != NULL || section->attribute != 0) {
        printf("%d,A,? == %d\n", section_n + 1, section->attribute);
    }
}

// i,S,j
void PrintSelector(List* list, int section_n, int selectorn) {
    Section* section = SectionWithNumber(list, section_n);
    if (section != NULL && selectorn < section->selector) {
        printf("%d,S,%d == %s\n", section_n + 1, selectorn + 1, section->selectors[selectorn]);
    }
}

// i,A,n
void AttrValue_Section(List* list, int section_n, const char* attribute_name) {
    Section* section = SectionWithNumber(list, section_n);

    if (section == NULL) {
        return;
    }

    for (int i = 0; i < section->attribute; ++i) {
        if (strcmp(attribute_name, section->attributes[i].name) == 0) {
            printf("%d,A,%s == %s\n", section_n + 1, attribute_name, section->attributes[i].value);
            break;
        }
    }
}

// n,A,?
void AllAttributeNum(List* list, const char* attribute) {
    int count = 0;
    Node* curr_node = list->first;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        for (int i = 0; i < curr_block->n; i++) {
            Section* curr_section = &curr_block->sections[i];
            for (int j = 0; j < curr_section->attribute; j++) {
                Attribute* curr_attribute = &curr_section->attributes[j];
                if (strcmp(curr_attribute->name, attribute) == 0) {
                    count++;
                }
            }
        }
        curr_node = curr_node->next;
    }
    printf("%s,A,? == %d\n", attribute, count);
}

// z,S,? 
void SelectorNum(List* list, const char* selector) {
    Node* curr_node = list->first;
    int total_selectors = 0;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        for (int i = 0; i < curr_block->n; i++) {
            Section* curr_section = &(curr_block->sections[i]);
            if (curr_section->selectors) {
                for (int j = 0; j < curr_section->selector; j++) {
                    if (strcmp(curr_section->selectors[j], selector) == 0) {
                        total_selectors++;
                    }
                }
            }
        }
        curr_node = curr_node->next;
    }
    printf("%s,S,? == %d\n", selector, total_selectors);

}

// z,E,n 
void AttrValue_Selector(List* list, const char* selector_name, const char* attribute) {
    Node* curr_node = list->first;
    char* last_value = NULL;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        for (int i = 0; i < curr_block->n; i++) {
            Section* curr_section = &curr_block->sections[i];
            for (int j = 0; j < curr_section->selector; j++) {
                if (strcmp(selector_name, curr_section->selectors[j]) == 0) {
                    for (int k = 0; k < curr_section->attribute; k++) {
                        if (strcmp(attribute, curr_section->attributes[k].name) == 0) {
                            last_value = curr_section->attributes[k].value;
                        }
                    }
                }
            }
        }
        curr_node = curr_node->next;
    }
    if (last_value) {
        printf("%s,E,%s == %s\n", selector_name, attribute, last_value);
    }
}
// i,D,* 
void DeleteSection(List* list, int section_n) {
    if (RemoveSectionByIndex(list, section_n)) {
        printf("%d,D,* == deleted\n", section_n + 1);
    }

}

// i,D,n 
void DeleteAttribute(List* list, int section_n, char* attribute) {
    if (RemoveAttributeByName(list, section_n, attribute)) {
        printf("%d,D,%s == deleted\n", section_n + 1, attribute);
    }
}

char* AllocStr(const char* s, int n) {
    if (n == -1) {
        n = strlen(s);
    }

    char* allocated_s = (char*)malloc((n + 1) * sizeof(char));
    strncpy(allocated_s, s, n);
    allocated_s[n] = '\0';
    return allocated_s;
}

char* StripStr(const char* s, int n) {
    int l = n - 1;
    int r = 0;

    for (int i = 0; i < n; ++i) {
        if (!isspace(s[i])) {
            l = i;
            break;
        }
    }

    for (int i = n - 1; i >= 0; --i) {
        if (!isspace(s[i])) {
            r = i;
            break;
        }
    }

    if (l > r) {
        return AllocStr("", -1);
    }

    return AllocStr(s + l, r - l + 1);
}

int CompareStr(char* str1, const char* str2, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (str1[i] != str2[i]) {
            if (i < 4) {
                return (str1[i] > str2[i]) - (str1[i] < str2[i]);
            }
            else {
                return 0;
            }
        }
    }
    return 0;
}
char* ParseInputLine(char symbol_1, char symbol_2, bool* first) {
    static char buf[MAX_INPUT];
    int c = 0;
    int count = 0;
    int new_line_last_counter = -1;
    while ((c = getchar()) != EOF) {
        if (c == '\n') {
            new_line_last_counter = count;
        }
        buf[count++] = c;
        if (count - new_line_last_counter - 1 == 4) {
            if (CompareStr(buf + new_line_last_counter + 1, "****", 4) == 0) {
                return AllocStr("****", -1);
            }
            if (CompareStr(buf + new_line_last_counter + 1, "????", 4) == 0) {
                return AllocStr("????", -1);
            }
        }
        if (c == symbol_1 || c == symbol_2) {
            break;
        }
    }
    if (c == EOF) {
        return NULL;
    }
    if (first) {
        *first = (c == symbol_1);
    }
    count = count - 1;
    return StripStr(buf, count);
}

bool Css(List* list) {
    while (true) {
        bool first = false;
        Section* section = NULL;
        char* input = NULL;

        while ((input = ParseInputLine(',', '{', &first)) != NULL) {
            if (strcmp(input, "????") == 0) {
                free(input);
                return true;
            }

            if (section == NULL) {
                section = NewSection(list);
            }
            NewSelector(section, input);

            if (!first) {
                break;
            }
        }

        if (input == NULL) {
            return false;
        }

        while (true) {
            char* attribute_name = ParseInputLine(':', '}', &first);

            if (!first) {
                free(attribute_name);
                break;
            }

            char* attribute_value = ParseInputLine(';', '}', &first);

            NewAttribute(section, attribute_name, attribute_value);

            if (!first) {
                break;
            }
        }
    }

    return true;
}

bool Num(const char* str) {
    while (*str != '\0') {
        if (*str < '0' || *str > '9') {
            return false;
        }
        str++;
    }
    return true;
}

bool Commands(List* list) {
    while (true) {
        bool first = false;
        char* input = NULL;
        char* inputs[3];
        int n = 0;

        while ((input = ParseInputLine(',', '\n', &first)) != NULL) {
            if (strcmp(input, "****") == 0) {
                return true;
            }

            inputs[n++] = input;

            if (!first) {
                break;
            }
        }

        if (!input) {
            return false;
        }

        if (n == 1 && strcmp(inputs[0], "?") == 0) {
            PrintNumberOfSections(list);
        }
        else if (n == 3) {
            if (Num(inputs[0]) && strcmp(inputs[1], "S") == 0 && strcmp(inputs[2], "?") == 0) {
                SelectorNum(list, atoi(inputs[0]) - 1);
            }
            else if (Num(inputs[0]) && strcmp(inputs[1], "A") == 0 && strcmp(inputs[2], "?") == 0) {
                AttributeNum(list, atoi(inputs[0]) - 1);
            }
            else if (strcmp(inputs[1], "S") == 0 && strcmp(inputs[2], "?") == 0) {
                SelectorNum(list, inputs[0]);
            }
            else if (strcmp(inputs[1], "S") == 0) {
                PrintSelector(list, atoi(inputs[0]) - 1, atoi(inputs[2]) - 1);
            }
            else if (strcmp(inputs[1], "A") == 0 && strcmp(inputs[2], "?") == 0) {
                AllAttributeNum(list, inputs[0]);
            }
            else if (strcmp(inputs[1], "A") == 0) {
                AttrValue_Section(list, atoi(inputs[0]) - 1, inputs[2]);
            }
            else if (strcmp(inputs[1], "E") == 0) {
                AttrValue_Selector(list, inputs[0], inputs[2]);
            }
            else if (strcmp(inputs[1], "D") == 0 && strcmp(inputs[2], "*") == 0) {
                DeleteSection(list, atoi(inputs[0]) - 1);
            }
            else if (strcmp(inputs[1], "D") == 0) {
                DeleteAttribute(list, atoi(inputs[0]) - 1, inputs[2]);
            }
        }
    }

    return true;
}

int main() {
    List list;

    while (true) {
        if (!Css(&list) || !Commands(&list)) {
            return 0;
        }
    }
}