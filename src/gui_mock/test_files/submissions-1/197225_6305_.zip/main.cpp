#include <iostream>
#include <vector>
#include <string>
#include <numeric>
#include <algorithm>
#include <unordered_set>
#include <sstream>
#include <regex>
#include <cctype> 

std::vector<std::pair<std::string, std::string>> extraire_blocs_css(std::string texte)
{
    std::vector<std::pair<std::string, std::string>> blocs;
    std::regex bloc_regex("#?[^{]+\\s*\\{[^{}]+\\}");
    std::smatch match;

    while (!texte.empty() && std::regex_search(texte, match, bloc_regex)) {
        std::string bloc = match[0];
        texte = match.suffix().str();

        std::regex selecteur_regex("#?[^{]+");
        std::smatch selecteur_match;
        std::regex_search(bloc, selecteur_match, selecteur_regex);

        if (!selecteur_match.empty()) {
            std::string selecteur = selecteur_match[0];
            selecteur.erase(std::remove_if(selecteur.begin(), selecteur.end(), ::isspace), selecteur.end());

            std::size_t debut_bloc = bloc.find("{");
            std::string attributs = bloc.substr(debut_bloc+1, bloc.size()-debut_bloc-2);
            attributs = "{" + attributs + "}";

            blocs.push_back(std::make_pair(attributs, selecteur));
        }
    }

    return blocs;
}





using namespace std;

// affiche la valeur de l'attribut nommé n pour la ième section
string get_attribut_by_index(const vector<pair<string, string>> &blocs, int i, string n)
{
    string bloc = blocs[i].first;
    size_t pos = bloc.find(n);
    if (pos == string::npos)
    {
        return "";
    }
    size_t debut_valeur = bloc.find(":", pos) + 1;
    size_t fin_valeur = bloc.find(";", debut_valeur);
    string valeur = bloc.substr(debut_valeur, fin_valeur - debut_valeur);
    return valeur;
}

// affiche le nombre total (pour tous les blocs) d'occurrences de l'attribut nommé n (dans un même bloc, les doublons doivent être supprimés lors de l'étape de chargement). 0 est possible

int nombre_total_attribut(const std::vector<std::pair<std::string, std::string>>& blocs, const std::string& n)
{
    int count = 0;
    std::unordered_set<std::string> values;
    std::regex r(n + "\\s*:\\s*([^;\\s]*)");
    for (const auto& bloc : blocs)
    {
        std::smatch match;
        std::string attributs = bloc.first;
        while (std::regex_search(attributs, match, r))
        {
            std::string value = match[1];
            if (values.find(value) == values.end())
            {
                values.insert(value);
                count++;
            }
            attributs = match.suffix().str();
        }
    }
    return count;
}


// affiche le nombre total (pour tous les blocs) d'occurrences du seleceteur nommé z (dans un même bloc, les doublons doivent être supprimés lors de l'étape de chargement)
int nombre_total_selecteur(vector<pair<string, string>> blocs, const string& z)
{
    int count = 0;
    unordered_set<string> values;
    for (auto bloc : blocs)
    {
        string ligne_precedente = bloc.second;
        size_t pos = ligne_precedente.find(z);
        while (pos != string::npos)
        {
            if (values.find(ligne_precedente) == values.end())
            {
                values.insert(ligne_precedente);
                count++;
            }
            pos = ligne_precedente.find(z, pos + 1);
        }
    }
    return count;
}

int CompteBlocCSS(vector<pair<string, string>> blocs)
{
    int count = 0;
    for (auto bloc : blocs)
    {
        count++;
    }
    return count;
}

// Fonction qui prend en parametre la liste de bloc et une variable i , elle retourne le nombre de selecteur css dans le bloc css i grace au virgule dans le bloc[].second
int CompteSelecteurCSS(vector<pair<string, string>> blocs, int i)
{
    if (blocs.empty() || i < 0 || i >= static_cast<int>(blocs.size()))
    {
        // handle error: blocs is empty or i is out of range
        return 0;
    }

    int nbAttribut = 0;
    for (size_t j = 0; j < blocs[i].second.length(); j++)
    {
        if (blocs[i].second[j] == ',')
        {
            nbAttribut++;
        }
    }
    return nbAttribut + 1;
}

// Fonction qui prend en parametre la liste de bloc et une variable i , elle retourne le nombre d'attribut css dans le bloc css i
int CompteAttributCSS(const vector<pair<string, string>>& blocs, size_t i)
{
    if (i >= blocs.size()) {
        return 0;
    }

    int nbAttribut = 0;
    for (size_t j = 0; j < blocs[i].first.length(); j++)
    {
        if (blocs[i].first[j] == ';')
        {
            nbAttribut++;
        }
    }
    return nbAttribut;
}


// Fonction qui prend en parametre la liste de bloc et une variable i et une variable j , et retourne le nom du jieme selecteur dans le bloc i
string selecteurCSS(vector<pair<string, string>> blocs, unsigned int i, unsigned int j)
{
    if (blocs.empty() || i >= blocs.size() || j >= blocs[i].second.length())
    {
        // handle error: blocs is empty or i or j is out of range
        return "";
    }

    string selecteur;
    unsigned int nbVirgule = 0;
    for (unsigned int k = 0; k < blocs[i].second.length(); k++)
    {
        if (blocs[i].second[k] == ',')
        {
            nbVirgule++;
        }
        else if (nbVirgule == j)
        {
            selecteur += blocs[i].second[k];
        }
    }
    return selecteur;
}



// Fonction qui prend en parametre la liste de bloc , une string z et un string n puis retourne la valeur de l'attribut nommé n pour le sélecteur z si il y a occurrences multiples du sélecteur z, on prend la dernière.
string valeurAttributCSS(vector<pair<string, string>> blocs, const string& z, string n)
{
    string valeur;
    bool selecteurTrouve = false;
    string derniereValeur; // stocke la dernière valeur trouvée
    for (size_t i = 0; i < blocs.size(); i++)
    {
        for (int j = 0; j < CompteSelecteurCSS(blocs, i); j++)
        {
            if (selecteurCSS(blocs, i, j) == z)
            {
                selecteurTrouve = true;
            }
        }
        if (selecteurTrouve)
        {
            for (size_t k = 0; k < blocs[i].first.length(); k++)
            {
                if (blocs[i].first[k] == n[0])
                {
                    bool attributTrouve = true;
                    for (size_t  l = 1; l < n.length(); l++)
                    {
                        if (blocs[i].first[k + l] != n[l])
                        {
                            attributTrouve = false;
                        }
                    }
                    if (attributTrouve)
                    {
                        valeur = "";
                        for (size_t m = k + n.length(); m < blocs[i].first.length(); m++)
                        {
                            if (blocs[i].first[m] == ':')
                            {
                                m++;                          // sauter le caractère ':'
                                if (blocs[i].first[m] == '#') // ajouter le caractère '#' à la valeur
                                {
                                    valeur += "#";
                                }
                                valeur = "";
                            }

                            else if (blocs[i].first[m] == ';')
                            {
                                derniereValeur = valeur; // mettre à jour la dernière valeur trouvée
                                break;                   // sortir de la boucle
                            }
                            else
                            {
                                valeur += blocs[i].first[m];
                            }
                        }
                    }
                }
            }
        }
    }
    return derniereValeur; // retourner la dernière valeur trouvée
}

// Fonction qui prend en parametre la liste de bloc et une variable i , puis supprime le bloc i et retourne la liste de bloc
vector<pair<string, string>> supprimer_bloc_css(vector<pair<string, string>> blocs, int i)
{
    blocs.erase(blocs.begin() + i);
    return blocs;
}

// Fonction qui prend en parametre la liste de bloc et une variable i et un string j , puis supprime l'attribut j du bloc i, si il n'y a plus d'attribut dans le bloc i, on supprime le bloc i
vector<pair<string, string>> supprimer_attribut_css(vector<pair<string, string>>& blocs, int i, string j)
{
    for (size_t k = 0; k < blocs[i].first.length(); k++)
    {
        if (blocs[i].first[k] == j[0])
        {
            bool attributTrouve = true;
            for (size_t l = 1; l < j.length(); l++)
            {
                if (blocs[i].first[k + l] != j[l])
                {
                    attributTrouve = false;
                }
            }
            if (attributTrouve)
            {
                blocs[i].first.erase(k, j.length());
                size_t m = k;
                for (m = k; m < blocs[i].first.length() && blocs[i].first[m] != ';' ;)
                {
                    blocs[i].first.erase(m, 1);
                }
                if (m < blocs[i].first.length() && blocs[i].first[m] == ';')
                {
                    blocs[i].first.erase(m, 1);
                }
                if (m < blocs[i].first.length() && blocs[i].first[m] == '\n')
                {
                    blocs[i].first.erase(m, 1);
                }
            }
        }
    }
    if (blocs[i].first == "{}")
    {
        blocs = supprimer_bloc_css(blocs, i);
    }
    return blocs;
}



// Fonction qui prend le texte en parametre et renvoie un nouveau texte contenant la partie du fichier suivant "????"
string select_text(const string &input)
{
    string start = "????";
    size_t start_pos = input.find(start);
    if (start_pos != string::npos)
    {
        return input.substr(start_pos + start.length());
    }
    return "";
}

// Fonction qui rajoute un element dans la liste de bloc et retourne la liste de bloc
vector<pair<string, string>> ajouter_bloc_css(vector<pair<string, string>> blocs, const string &bloc)
{
    // Divise la chaîne de caractères en séparant le sélecteur et les attributs
    size_t brace_pos = bloc.find('{');
    if (brace_pos == string::npos)
    {
        return blocs; // Si l'accolade ouvrante n'est pas trouvée, renvoie le vecteur tel quel
    }

    string selector = bloc.substr(0, brace_pos);
    string attributes = bloc.substr(brace_pos + 1);

    // Supprime l'accolade fermante des attributs
    size_t last_brace_pos = attributes.rfind('}');
    if (last_brace_pos != string::npos)
    {
        attributes = attributes.substr(0, last_brace_pos);
    }

    // Ajoute les accolades manquantes aux attributs avec un espace avant l'accolade ouvrante
    attributes = "{" + attributes + "}";

    // Supprime les espaces en début et fin de chaîne pour chaque attribut
    stringstream ss(attributes);
    string attribute;
    vector<string> attribute_list;
    while (getline(ss, attribute, ','))
    {
        size_t start_pos = attribute.find_first_not_of(" \t\r\n");
        size_t end_pos = attribute.find_last_not_of(" \t\r\n");
        if (start_pos != string::npos && end_pos != string::npos)
        {
            attribute = attribute.substr(start_pos, end_pos - start_pos + 1);
            attribute_list.push_back(attribute);
        }
    }

    // Supprime les espaces en début et fin de chaîne pour le sélecteur
    size_t start_pos = selector.find_first_not_of(" \t\r\n");
    size_t end_pos = selector.find_last_not_of(" \t\r\n");
    if (start_pos != string::npos && end_pos != string::npos)
    {
        selector = selector.substr(start_pos, end_pos - start_pos + 1);
    }

    // Ajoute chaque attribut et le sélecteur au vecteur de blocs CSS
    for (const auto &attr : attribute_list)
    {
        blocs.push_back(make_pair(attr, selector));
    }

    return blocs;
}

// fonction qui prend en paramètre le text, la liste de bloc, et le text extracted et execute les fonction une par une
void executeFonction(vector<pair<string, string>> blocs, const string& extracted)
{
    string ligne;
    istringstream iss(extracted);
    while (getline(iss, ligne))
    {
        if (ligne == "?")
        {
            cout << "? == " << CompteBlocCSS(blocs) << endl;
        }
        // si la première lettre de la ligne c'est un nombre
        else if (ligne[0] >= '0' && ligne[0] <= '9')
        {
            // verifier si la lettre suivante est une virgule
            if (ligne[1] == ',')
            {
                // Verifier si la lettre suivante est un D ou un A ou un S
                if (ligne[2] == 'D')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[3] == ',')
                    {
                        // Verifier si la suite est * ou un mot
                        if (ligne[4] == '*')
                        {
                            int i = ligne[0] - 49;
                            blocs = supprimer_bloc_css(blocs, i);
                            cout << ligne[0] << ",D,* == deleted" << endl;
                        }
                        else
                        {
                            // affiche le mot
                            string mot = "";
                            for (size_t i = 4; i < ligne.length(); i++)
                            {
                                mot += ligne[i];
                            }
                            int i = ligne[0] - 49;
                            blocs = supprimer_attribut_css(blocs, i, mot);
                            cout << ligne[0] << ",D," << mot << " == deleted" << endl;
                        }
                    }
                }
                else if (ligne[2] == 'A')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[3] == ',')
                    {
                        // Verifier si la suite est ? ou un mot
                        if (ligne[4] == '?')
                        {
                            // si la fonction CompteAttributCSS retourne un 0 on n'affiche rien
                            if (CompteAttributCSS(blocs, ligne[0] - 49) != 0)
                            {
                                cout << ligne[0] << ",A,? == " << CompteAttributCSS(blocs, ligne[0] - 49) << endl;
                            }
                        }
                        else
                        {
                            // affiche le mot
                            string mot = "";
                            for (size_t i = 4; i < ligne.length(); i++)
                            {
                                mot += ligne[i];
                            }
                            // si la fonction get_attribut_by_index retourne un string vide, on n'affiche rien
                            if (get_attribut_by_index(blocs, ligne[0] - 49, mot) != "")
                            {
                                cout << ligne[0] << ",A," << mot << " == " << get_attribut_by_index(blocs, ligne[0] - 49, mot) << endl;
                            }
                        }
                    }
                }
                else if (ligne[2] == 'S')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[3] == ',')
                    {
                        // Verifier si la suite est ? ou un nombre
                        if (ligne[4] == '?')
                        {
                            if (CompteSelecteurCSS(blocs, ligne[0] - 49) != 0)
                            {
                                cout << ligne[0] << ",S,? == " << CompteSelecteurCSS(blocs, ligne[0] - 49) << endl;
                            }
                        }
                        else
                        {
                            // affiche le jieme selecteur pour le ieme bloc
                            // si la fonction selecteurCSS retourne un string vide, on n'affiche rien
                            if (selecteurCSS(blocs, ligne[0] - 49, ligne[4] - 49) != "")
                            {
                                cout << ligne[0] << ",S," << ligne[4] << " == " << selecteurCSS(blocs, ligne[0] - 49, ligne[4] - 49) << endl;
                            }
                        }
                    }
                }
            }
        }
        // Si il y a ** seul sur sa ligne
        else if (ligne == "**")
        {
            // affiche la ligne suivante
            getline(iss, ligne);
            blocs = ajouter_bloc_css(blocs, ligne);
        }
        // Si il y a **** seul sur sa ligne
        else if (ligne == "****")
        {
            // affiche la ligne suivante
            getline(iss, ligne);
            blocs = ajouter_bloc_css(blocs, ligne);
        }
        // Sinon cela signifie que c'est un mot
        else
        {
            // recupère le mot jusqu'à la virgule
            string mot = "";
            for (size_t i = 0; i < ligne.length(); i++)
            {
                if (ligne[i] == ',')
                {
                    break;
                }
                else
                {
                    mot += ligne[i];
                }
            }
            // Verifier si la lettre suivante le mot est une virgule
            if (ligne[mot.length()] == ',')
            {
                // Verifier si la lettre suivante est un S ou un E ou un A
                if (ligne[mot.length() + 1] == 'S')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[mot.length() + 2] == ',')
                    {
                        // Verifier si la suite est ?
                        if (ligne[mot.length() + 3] == '?')
                        {
                            cout << mot << ",S,? == " << nombre_total_selecteur(blocs, mot) << endl;
                        }
                    }
                }
                else if (ligne[mot.length() + 1] == 'E')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[mot.length() + 2] == ',')
                    {
                        // Verifier si la suite est un mot
                        if (ligne[mot.length() + 3] != ' ')
                        {
                            // affiche le mot
                            string mot2 = "";
                            for (size_t i = mot.length() + 3; i < ligne.length(); i++)
                            {
                                mot2 += ligne[i];
                            }
                            // si la fonction valeurAttributCSS retourne un string vide, on n'affiche rien
                                cout << mot << ",E," << mot2 << " == " << valeurAttributCSS(blocs, mot, mot2) << endl;
                            
                        }
                    }
                }
                else if (ligne[mot.length() + 1] == 'A')
                {
                    // Verifier si la lettre suivante est une virgule
                    if (ligne[mot.length() + 2] == ',')
                    {
                        // Verifier si la suite est ?
                        if (ligne[mot.length() + 3] == '?')
                        {
                            cout << mot << ",A,? == " << nombre_total_attribut(blocs, mot) << endl;
                        }
                    }
                }
            }
        }
    }
}

string extraire_texte_avant(string texte)
{
    std::size_t position = texte.find("????");

    if (position != string::npos) {
        return texte.substr(0, position);
    }
    return texte;
}


int main()
{
    string line;
    string text;
    while (getline(cin, line))
    {
        text += line + "\n";
    }
    string texteExtrait = extraire_texte_avant(text);
    vector<pair<string, string>> blocs = extraire_blocs_css(texteExtrait);
    string extracted_text = select_text(text);
    executeFonction(blocs, extracted_text);
    return 0;
}
