#include <iostream>

using namespace std;

class sTring {

public:

	template <typename T >
	T Min(T a, T b) const {
		return a < b ? a : b;
	}
	template <typename T>
	bool Check(const sTring& s, int size, T a) const {
		bool z = true;
		int b = strlen(s);
		for (int i = 0; i < strlen(a) && i < b - size && z == true; i++) {
			if (s[size + i] != a[i])
				z = false;
		}
		return z;
	}

	sTring() {
		arr = nullptr;
		length = 0;
	}
	~sTring() {
		erase();
	}
	sTring(const sTring& a) {
		int len = a.length;
		length = len;
		arr = new char[len + 1];
		for (int i = 0; i < len; i++)
			arr[i] = a[i];
		arr[len] = '\0';
	}
	sTring(const char* a) {
		int len = strlen(a);
		arr = new char[len + 1];
		for (int i = 0; i < len; i++)
			arr[i] = a[i];
		arr[len] = '\0';
		length = len;
	}
	sTring(char a) {
		arr = new char[2];
		arr[0] = a;
		arr[1] = '\0';
		length = 1;
	}
	sTring(sTring&& a) {
		length = a.length;
		arr = a.arr;
	}

	void operator=(const sTring& a) {
		length = a.length;
		erase();
		arr = new char[length + 1];
		for (int i = 0; i < length; i++)
			arr[i] = a[i];
		arr[length] = '\0';
	}
	void operator=(sTring&& a) {
		length = a.length;
		arr = a.arr;
		a.length = NULL;
	}
	void operator=(const char* a) {
		int len = strlen(a);
		erase();
		arr = new char[len + 1];
		length = len;
		for (int i = 0; i < len; i++)
			arr[i] = a[i];
		arr[len] = '\0';

	}
	void operator+=(const sTring& a) {
		int len = length;
		rebuild(length + a.length);
		for (int i = 0; i < a.length; i++)
			arr[len + i] = a[i];
	}
	void operator+=(const char* a) {
		int len = length;
		rebuild(length + strlen(a));
		for (int i = 0; i < strlen(a); i++)
			arr[len + i] = a[i];
	}
	void operator+=(char a) {
		rebuild(length + 1);
		arr[length - 1] = a;
	}
	bool operator==(const char* a) const {
		bool t = true;
		if (strlen(a) != length)
			t = false;
		if (t)
			for (int i = 0; i < length; i++)
				if (arr[i] != a[i])
					t = false;
		return t;
	}
	bool operator!=(const char* a) const {
		return !(*this == a);
	}
	bool operator==(const sTring& s) const {
		bool t = true;
		if (s.length != length)
			t = false;
		if (t)
			for (int i = 0; i < length; i++)
				if (arr[i] != s[i])
					t = false;
		return t;
	}
	bool operator!=(const sTring& s) const {
		return !(*this == s);
	}


	char& operator[](int a) {
		return arr[a];
	}
	char& operator[](int a) const {
		return arr[a];
	}

	sTring operator+(char a) const {
		sTring s2((*this).arr);
		s2 += a;
		return s2;
	}
	bool includes(const char* a) const {
		int len = strlen(a);
		if (len > length)
			return false;

		int size = 0;
		bool t2 = false;
		while (length - size >= len && !t2) {
			t2 = Check(*this, size, a);
			size++;
		}
		return t2;
	}
	bool includes(const sTring& s) const {
		int len = s.length;
		if (len > length)
			return false;

		int size = 0;
		bool t2 = false;
		while (length - size >= len && !t2) {
			t2 = Check(*this, size, s);
			size++;
		}
		return t2;
	}
	sTring GetSubstring(const char* symbol1, const char* symbol2) const {
		int i = 0, size1 = strlen(symbol1), size2 = strlen(symbol2);
		sTring s2 = "";
		bool t = true;
		if (symbol1 != "\n") {
			while (i < length && t) {
				for (int j = 0; j < size1; j++)
					if (arr[i] == symbol1[j]) {
						t = false;
						break;
					}
				i++;
			}
		}
		t = true;
		while (t && i < length) {
			for (int j = 0; j < size2; j++)
				if (arr[i] == symbol2[j]) {
					t = false;
					break;
				}
			if (t) {
				s2 += arr[i];
				i++;
			}
		}
		return s2;
	}

	int GetNumber() const {
		int p = 0;
		for (int i = 0; i < length; i++)
			p = p * 10 + (arr[i] - '0');
		return p;
	}

	bool IsNumber() const {
		bool t = true;
		for (int i = 0; i < length && t; i++)
			if (arr[i] - '0' > 9 || arr[i] - '0' < 0)
				t = false;
		return t;
	}

	void Less() {
		rebuild(length - 1);
	}




protected:
	int length;
	char* arr;

	void erase() {
		if(strlen(*this) != 0)
			delete[] arr;
		length = 0;
	}

	void rebuild(int a) {
		char* arr2 = new char[a + 1];
		for (int i = 0; i < Min(a, length); i++)
			arr2[i] = arr[i];
		arr2[a] = '\0';
		erase();
		arr = arr2;
		length = a;

	}

	friend std::ostream& operator<<(std::ostream& os, const sTring& a) {
		os << a.arr;
		return os;
	}
	friend std::istream& operator>>(std::istream& is, sTring& a) {
		char* buff = new char[1000];
		memset(&buff[0], 0, sizeof(buff));
		is >> buff;
		a = buff;
		delete[] buff;
		return is;
	}

	friend int strlen(const sTring& s) {
		return s.length;
	}
};

#define OC 8

struct deque {
	deque* previous = NULL;
	sTring* array = new sTring[OC];
	int occupied = 0;
	deque* next = NULL;
};

struct sl {
	sl* previous = NULL;
	deque* selectors = NULL;
	deque* attributes = NULL;
	sl* next = NULL;
};

class list {

public:
	list() {
		block = NULL;
		number_of_sections = 0;
	};
	~list() {

	};

	void NewSection() {
		if (block == NULL) {
			block = new sl;
		}
		else {
			sl* new_block = new sl;
			block->previous = new_block;
			new_block->next = block;
			block = new_block;
		}
		block->selectors = new deque;
		block->attributes = new deque;

		number_of_sections++;
	}

	int GetAmountOfSections() const {
		return number_of_sections;
	}
	sTring EraseSection(int section_number) {
		sTring ans = "";
		sl* btbe = GetSection(section_number);
		ans = TrueEraseSection(btbe);
		return ans;
	}

	void AddToCell(deque* d, const sTring& s) {
		if (d != NULL) {
			while (d->next != NULL)
				d = d->next;
			if (d->occupied == 8)
			{
				deque* d2 = new deque;
				d2->previous = d;
				d->next = d2;
				d = d2;
			}
			d->array[d->occupied] = s.GetSubstring("\n", "\n");
			d->occupied++;
		}
	}

	void AddToSelectors(const sTring& s) {
		sTring s2 = s.GetSubstring("\n", ",{");
		deque* d = block->selectors;
		while (d != NULL && d->next != NULL)
			d = d->next;
		AddToCell(d, s);
	}

	void AddToAttributes(const sTring& s) {
		deque* d = block->attributes;
		sTring s2 = s.GetSubstring("\n", ":");
		while (s2[0] == ' ')
			s2 = s2.GetSubstring(" ", "\n");
		while (s2[strlen(s2) - 1] == ' ')
			s2.Less();
		deque* z = TryToFind(block, true, s2);
		if (z != NULL)
			EraseCell(z, s2, true, NULL);
		AddToCell(d, s);
	}

	sTring EraseAttribute(int section_number, const sTring& s) {
		sl* b = GetSection(section_number);
		sTring ans = "";
		if (b != NULL) {
			deque* d = TryToFind(b, true, s);
			if (d != NULL)
				ans = EraseCell(d, s, true, b);
			if (b->attributes == NULL)
				TrueEraseSection(b);
		}
		return ans;
	}

	int GetOccupied(deque* d) const {
		int p = 0;
		while (d != NULL) {
			p += d->occupied;
			d = d->next;
		}
		return p;
	}

	int GetAmountOfSelectors(int section_number) const {
		sl* d = GetSection(section_number);
		if (d == NULL)
			return -1;
		if (section_number <= number_of_sections)
			return GetOccupied(d->selectors);
		else
			return 0;
	}
	int GetAmountOfAttributes(int section_number) const {
		sl* d = GetSection(section_number);
		if (d == NULL)
			return -1;
		if (section_number <= number_of_sections)
			return GetOccupied(d->attributes);
		else
			return 0;

	}
	int GeneralNumberOfAttribute(sTring& attribute) const {
		sl* a = block;
		sTring s3;
		int p = 0;
		deque* d = NULL;
		while (a != NULL) {
			d = a->attributes;
			while (d != NULL) {
				for (int i = 0; i < d->occupied; i++) {
					s3 = d->array[i].GetSubstring("\n", ":");
					while (s3[0] == ' ' || s3[0] == '\t')
						s3 = s3.GetSubstring(" \t", "\n");
					while (s3[strlen(s3) - 1] == ' ')
						s3.Less();
					if (s3 == attribute) {
						p++;
						break;
					}
				}
				d = d->next;
			}
			a = a->next;
		}
		return p;
	}
	int GeneralNumberOfSelector(sTring& selector) const {
		sl* a = block;
		int p = 0;
		deque* d;
		while (a != NULL) {
			d = a->selectors;
			for (int i = 0; i < d->occupied; i++)
				if (d->array[i].GetSubstring("\n", ",}") == selector) {
					p++;
					break;
				}
			a = a->next;
		}
		return p;
	}


	sTring GetSelectorFromSection(int section_number, int selector_number) const {
		sl* btbe = GetSection(section_number);
		if (btbe != NULL) {
			sTring s2;
			selector_number--;
			deque* d = btbe->selectors;
			while (selector_number > 8 && d != NULL) {
				selector_number -= 8;
				d = d->next;
			}
			if (d != NULL)
				return d->array[selector_number].GetSubstring("\n", ",{");
		}
		return "";
	}
	sTring GetValueOfAttribute(int section_number, sTring& attribute) const {
		sl* b = GetSection(section_number);
		sTring s2 = "";
		deque* d = TryToFind(b, true, attribute);
		if (d != NULL) {
			int i = 0;
			while (d != NULL && d->array[i] != "" && d->array[i].GetSubstring("\n", ": ") != attribute && i < d->occupied)
				i++;
			if (i < d->occupied)
				s2 = d->array[i].GetSubstring(":", ";}");
			if (s2 != "" && s2[0] == ' ')
				s2 = s2.GetSubstring(" ", ";}");
		}
		return s2;
	};

	void EraseDeques(deque* d) {
		while (d != NULL && d->next != NULL)
			d = d->next;
		if (d != NULL) {
			while (d->previous != NULL) {
				delete[] d->array;
				d = d->previous;
				delete d->next;
			}
			delete d;
		}
	}

	sTring FindInDeque(const sTring& s, deque* d, bool t) const {
		bool z = false;
		sTring answer = "";
		while (d != NULL && !z) {
			for (int i = 0; i < d->occupied && !z; i++)
				if (!t && d->array[i].GetSubstring("\n", ",") == s) {
					answer = d->array[i].GetSubstring("\n", ",");
					z = true;
				}
				else if (t && d->array[i].GetSubstring("\n", ":") == s) {
					answer = d->array[i].GetSubstring(":", ";}");
					while (answer[0] == ' ')
						answer = answer.GetSubstring(" ", "\n");
					z = true;
				}
			d = d->next;
		}
		return answer;
	}

	sTring GetAttributeForSelector(const sTring& selector, const sTring& attribute) const {
		sl* s = block;
		sTring ans, ans2 = "";
		bool t;
		if (block != NULL) {
			while (s != NULL && ans2 == "") {
				ans = "";
				ans2 = "";
				ans = FindInDeque(selector, s->selectors, false);
				if (ans != "" || s->selectors->occupied == 0) {
					ans2 = FindInDeque(attribute, s->attributes, true);
				}
				s = s->next;
			}
		}
		return ans2;
	}

protected:
	sTring TrueEraseSection(sl* btbe) {
		sTring ans = "";

		if (btbe != NULL) {

			if (btbe->next != NULL)
				btbe->next->previous = btbe->previous;
			if (btbe->previous != NULL)
				btbe->previous->next = btbe->next;
			else
				block = btbe->next;

			EraseDeques(btbe->selectors);
			EraseDeques(btbe->attributes);

			delete btbe;

			number_of_sections--;

			ans = "deleted";
		}
		return ans;
	}
	sTring EraseCell(deque* d, const sTring& s, bool t, sl* b) {
		const char* symb1 = "\n", * symb2 = ":";
		bool t2 = t;
		sTring ans = "";
		if (!t) {
			symb1 = "\n";
			symb2 = ",{";
		}
		t = false;
		sTring s2;
		for (int i = 0; d != NULL && i < d->occupied && !t; i++) {
			s2 = d->array[i].GetSubstring(symb1, symb2);
			if (s2 != "" && s2[0] == ' ')
				s2 = s2.GetSubstring(" ", ";}");
			if (s2 == s) {
				for (int j = i + 1; j < d->occupied; j++)
					d->array[j - 1] = d->array[j].GetSubstring("\n", "\n");
				d->occupied--;
				t = true;
				ans = "deleted";
				if (d->occupied == 0 && b != NULL) {
					TrueEraseSection(b);
				}
			}
		}
		return ans;
	}
	sl* GetSection(int section_number) const {
		int p = 1;

		sl* a = block;
		if (a != NULL) {
			while (a->next != NULL)
				a = a->next;
			while (a != NULL && p < section_number) {
				a = a->previous;
				p++;
			}
			if (a != NULL && p <= number_of_sections)
				return a;
		}
		return NULL;
	}
	deque* TryToFind(sl* b, bool t, const sTring& s) const {
		if (b != NULL) {
			deque* tmp;
			sTring tmp2;
			const char* symb1 = "\n", * symb2 = ":";
			if (!t) {
				tmp = b->selectors;
				symb1 = "\n";
				symb2 = ",{";
			}
			else
				tmp = b->attributes;
			t = false;
			while (!t && tmp != NULL) {
				for (int i = 0; i < tmp->occupied; i++) {
					tmp2 = tmp->array[i].GetSubstring(symb1, symb2);
					if (tmp2 != "" && tmp2[0] == ' ')
						tmp2 = tmp2.GetSubstring(" ", ";}");
					if (tmp2 == s)
						return tmp;
				}
				tmp = tmp->next;
			}
		}
		return NULL;
	}

private:
	sl* block;
	int number_of_sections;

};




struct st {
	bool read = true;
	bool sel = true;
};

int main()
{
	iostream::sync_with_stdio(false);
	int p1, p2;
	sTring s = "", s2 = "", s3 = "", s4 = "";
	st state;
	list a;
	while (cin >> s) {
		if (s == "????")
			state.read = false;
		else if (s == "****")
			state.read = true;
		else {
			if (s2 != "" && s2[strlen(s2) - 1] != ' ')
				s2 += ' ';
			s2 += s;
		}
		if (state.read) {
			if (state.sel) {
				if (s2.includes('{')) {
					a.NewSection();
					while (s2.includes('{')) {
						s3 = s2.GetSubstring("\n", ",{");
						while (s3[0] == ' ')
							s3 = s3.GetSubstring(" ", "\n");
						while (s3[strlen(s3) - 1] == ' ')
							s3.Less();
						if (s3 != " " && s3 != "")
							a.AddToSelectors(s3);
						s2 = s2.GetSubstring(",{", "\n");
					}
					state.sel = false;
				}
			}
			else
				if (s2.includes('}')) {
					while (s2.includes('}')) {
						s3 = s2.GetSubstring("\n", ";}");
						while (s3[0] == ' ')
							s3 = s3.GetSubstring(" ", "\n");
						while (s3[strlen(s3) - 1] == ' ')
							s3.Less();
						if (s3 != " " && s3 != "")
							a.AddToAttributes(s3);
						s2 = s2.GetSubstring(";}", "\n");
					}
					state.sel = true;
				}
		}
		else {
			if (s == "?") {
				cout << s << " == " << a.GetAmountOfSections() << '\n';
				s2 = "";
			}
			else if (s2.GetSubstring(",", "\n").GetSubstring(",", "\n") != "") {
				s3 = s2.GetSubstring("\n", ",");
				s4 = s2.GetSubstring(",", "\n").GetSubstring(",", "\n");
				while (s4[0] == ' ')
					s4 = s4.GetSubstring(" ", "\n");
				if (s2.includes(",S,") || s2.includes(", S,")) {
					if (s4 == "?") {
						if (s3.IsNumber()) {
							p1 = s3.GetNumber();
							p2 = a.GetAmountOfSelectors(p1);
							if (p2 != -1)
								cout << s2 << " == " << p2 << '\n';
						}
						else {
							cout << s2 << " == " << a.GeneralNumberOfSelector(s3) << '\n';
						}
					}
					else {
						p1 = s3.GetNumber();
						p2 = s4.GetNumber();
						s3 = a.GetSelectorFromSection(p1, p2);
						if (s3 != "")
							cout << s2 << " == " << s3 << '\n';
					}
				}
				else if (s2.includes(", A,") || s2.includes(",A,")) {
					if (s4 == "?") {
						if (s3.IsNumber()) {
							p1 = s3.GetNumber();
							p2 = a.GetAmountOfAttributes(p1);
							if (p2 != -1)
								cout << s2 << " == " << p2 << '\n';
						}
						else {
							cout << s2 << " == " << a.GeneralNumberOfAttribute(s3) << '\n';
						}
					}
					else {
						p1 = s3.GetNumber();
						s3 = a.GetValueOfAttribute(p1, s4);
						if (s3 != "")
							cout << s2 << " == " << s3 << '\n';
					}
				}
				else if (s2.includes(", E,") || s2.includes(",E,")) {
					s3 = a.GetAttributeForSelector(s3, s4);
					if (s3 != "")
						cout << s2 << " == " << s3 << '\n';
				}
				else if (s2.includes(",D,") || s2.includes(", D,")) {
					p1 = s3.GetNumber();
					if (s4 == "*")
						s3 = a.EraseSection(p1);
					else
						s3 = a.EraseAttribute(p1, s4);
					if (s3 != "")
						cout << s2 << " == " << s3 << '\n';
				}
				s2 = "";
			}
		}
	}
	return 0;
}
