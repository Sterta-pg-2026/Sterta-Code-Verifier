#include <iostream>
#include <stdio.h>
using namespace std;
#define size 125
#define little_size 50
#define DEFAULT_CAPACITY 20


typedef struct element {
    char data[size];
    struct element* previous = NULL;
    struct element* next = NULL;
} element;

typedef struct selector {
    char name[little_size];
    struct element* head_index = NULL;
    struct element* head_values = NULL;
} selector;


class Vector {
private:
    selector** data;
    long int Size;
    long int capacity;

public:
    Vector(int initialCapacity = DEFAULT_CAPACITY) {
        data = new selector * [initialCapacity];
        Size = 0;
        capacity = initialCapacity;
    }

    ~Vector() {
        delete[] data;
    }

    void add(selector* sel) {
        if (Size == capacity) {
            capacity *= 2;
            selector** newData = new selector * [capacity];

            for (long int i = 0; i < Size; i++) {
                newData[i] = data[i];
            }
            //memcpy(newData, data, sizeof(selector) * Size);

            delete[] data;
            data = newData;
        }

        data[Size] = sel;
        Size++;
    }

    void remove(long int index) {
        if (index >= 0 && index < Size) {
            for (long int i = index; i < Size - 1; i++) {
                data[i] = data[i + 1];
            }
            Size--;
        }
    }

    long int getSize() const {
        return Size;
    }

    selector* getElement(long int index) {
        if (index >= 0 && index < Size) {
            return data[index];
        }
        else {
            cout << index << ": out of index" << endl;
        }
        return NULL;
    }
};


void push_back(element** head, char data[size])
{
    if (*head == NULL)
    {
        *head = (element*)malloc(sizeof(element));
        for (int i = 0; i < size; i++) {
            (*head)->data[i] = data[i];

        }
        (*head)->previous = NULL;
        (*head)->next = NULL;
    }
    else
    {
        element* current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = (element*)malloc(sizeof(element));
        for (int i = 0; i < size; i++) {
            current->next->data[i] = data[i];

        }
        current->next->previous = current;
        current->next->next = NULL;
    }
}

int arry_sele(char arr_selectors[], char first) {
    char arr;
    int i = 0;
    int name_counter = 1;
    if (first != 0 && first != '\t') {
        arr_selectors[0] = first;
        i = 1;
    }
    while ((arr = getchar()) != '{') {
        if (char(arr) != '\t') {
            arr_selectors[i] = arr;
            i++;
        }
        if (arr == ',') {
            name_counter++;
        }
    }
    arr_selectors[i] = '~';
    return name_counter;
}

void reset_l(char table[]) {
    for (int i = 0; i < little_size * 3; i++) {
        table[i] = ' ';
    }
}

void reset(char table[]) {
    for (int i = 0; i < size; i++) {
        table[i] = ' ';
    }
}

void push_name(selector* element, char name[]) {
    int k = 0;
    for (int j = 0; j < little_size; j++) {
        if (name[j] == ' ') {

        }
        else if (name[j] > 30 && name[j] <= 126) {
            element->name[k] = name[j];
            k++;
        }
        else {
            element->name[k] = ' ';
            k++;
        }
    }
    for (int j = k; j < little_size; j++) {
        element->name[j] = ' ';
    }
}

void print_name(char name[]) {
    for (int i = 0; i < little_size; i++) {
        if (name[i] == '~') {
            return;
        }
        cout << name[i];
    }
}

void print_data(char name[]) {
    for (int i = 0; i < size; i++) {
        if (name[i] == '~') {
            cout << endl;
            return;
        }
        cout << name[i];
    }
}


int arry_(Vector* selectors, char arr_selectors[], long int counter) {
    int couter = 0;
    char names[10][little_size];
    int c = 0;
    for (int i = 0; i < little_size * 3; i++) {
        if (arr_selectors[i] == ',') {
            names[couter][c] = '~';
            couter++;
            c = 0;
        }
        else {
            if (arr_selectors[i] != '\n' && arr_selectors[i] != '\t') {
                names[couter][c] = arr_selectors[i];
                c++;
            }
        }
    }
    couter++;
    char arr;
    int j = 0;
    selector* tmp = new selector;
    char table[size];
    while ((arr = getchar()) != '}') {
        if (arr != '\n' && arr != '\t') {
            if (arr == ':') {
                table[j] = '~';
                j = 0;
                push_back(&tmp->head_index, table);
                reset(table);
                while ((arr = getchar()) != ';') {
                    table[j] = arr;
                    j++;
                }
                table[j] = '~';
                push_back(&tmp->head_values, table);
                j = 0;
                reset(table);
            }
            else {
                table[j] = arr;
                j++;
            }
        }
    }
    for (int i = 0; i < couter; i++) {
        //TODO kopia głęboka tmp
        selector* deepCopyTmp = new selector(*tmp);
        selectors->add(deepCopyTmp);
        push_name(selectors->getElement(i + counter), names[i]);
    }
    reset_l(arr_selectors);
    delete tmp;

    return couter;
}

void ilosc_atrybutow(Vector* selectors, int number_of_selectors[], int number) {
    int sum = 0;
    for (int i = 0; i < number; i++) {
        sum += number_of_selectors[i];
    }
    int sumA = 0;
    if (selectors->getSize() > sum && selectors->getElement(sum)->head_index != NULL) {
        element* current = selectors->getElement(sum)->head_index;
        sumA++;
        while (current->next != NULL) {
            current = current->next;
            sumA++;
        }
    }
    if (sumA == 18) {
        cout << number + 1 << ",A,? == " << 9 << endl;
    }
    else if (sumA != 0) {
        cout << number + 1 << ",A,? == " << sumA << endl;
    }
}

void docelowy_printS(Vector* selectors, int number_of_selectors[], int number, int jaki_numer) {
    int sum = 0;
    int ilosc = number_of_selectors[number];
    if (ilosc <= jaki_numer) { return; }
    for (int i = 0; i < number; i++) {
        sum += number_of_selectors[i];
    }
    sum += jaki_numer;
    cout << number + 1 << ",S," << jaki_numer + 1 << " == ";
    print_name(selectors->getElement(sum)->name);
    cout << endl;
}

bool compare(char a[], char b[]) {
    if (a == NULL) {
        return false;
    }
    for (int i = 0; i < little_size; i++) {
        if (a[i] == '~' && b[i] == '~') return true;
        if (a[i] == ' ' && b[i] == ' ') return true;
        if (a[i] == ' ' && b[i] == '~') return true;
        if (a[i] == '~' && b[i] == ' ') return true;
        if (b[i] == '\0')return true;
        if (a[i] != b[i])return false;
    }
    return true;
}

void szukanie_head(Vector* selectors, int number_of_selectors[], int number, char table[]) {
    int sum = 0;
    for (int i = 0; i < number; i++) {
        sum += number_of_selectors[i];
    }
    element* current = selectors->getElement(sum)->head_index;
    element* value = selectors->getElement(sum)->head_values;
    char* tmp = NULL;
    if (compare(current->data, table)) {
        tmp = value->data;
    }
    while (current->next != NULL) {
        current = current->next;
        value = value->next;
        if (compare(current->data, table)) {
            tmp = value->data;
        }
    }
    if (tmp != NULL) {
        cout << number + 1 << ",A," << table << " ==";
        print_data(tmp);
    }
}

int szukanie_ilosci_nazwy(Vector* selectors, char table[], int  counter) {
    int ile = 0;
    for (int i = 0; i < counter; i++) {
        if (compare(selectors->getElement(i)->name, table)) {
            ile++;
        }
    }
    return ile;
}

int ktory_blok(int x, int number_of_selectors[], int bloks) {
    int sum = 0;
    for (int i = 0; i < bloks; i++) {
        if (sum > x) {
            return sum;
        }
        sum += number_of_selectors[i];
    }
    return 100;
}

int szukanie_ilosci_selektora(Vector* selectors, int number_of_selectors[], char table[], int  counter, int bloks) {
    int ile = 0;
    int sum = 0;
    for (int i = 0; i < counter; i++) {
        sum += number_of_selectors[i];
    }
    for (int i = 0; i < counter; i++) {
        element* current = selectors->getElement(i)->head_index;
        if (compare(current->data, table)) {
            ile++;
            i = ktory_blok(i, number_of_selectors, bloks) - 1;
        }
        if (current == NULL) {
            break;
        }
        while (current->next != NULL) {
            current = current->next;
            if (compare(current->data, table)) {
                ile++;
                i = ktory_blok(i, number_of_selectors, bloks) - 1;
                break;
            }
        }
    }
    return ile;
}

int ilosc_blokow(int number_of_selectors[]) {
    int ilosc = 0;
    for (int i = 0; i < size; i++) {
        if (number_of_selectors[i] < 0 || number_of_selectors[i] > 30) {
            return ilosc;
        }
        ilosc++;
    }
    return ilosc;
}

void rewrite(char a[], char b[]) {
    for (int i = 0; i < size; i++) {
        a[i] = b[i];
    }
}

void szukanie_wartosci(Vector* selectors, char table[], int  counter, char find[], char tmp[]) {
    tmp[0] = 0;
    for (int i = 0; i < counter; i++) {
        if (compare(selectors->getElement(i)->name, table)) {
            element* current = selectors->getElement(i)->head_index;
            element* values = selectors->getElement(i)->head_values;
            if (compare(current->data, find)) {
                rewrite(tmp, values->data);
            }
            while (current->next != NULL) {
                current = current->next;
                values = values->next;
                if (compare(current->data, find)) {
                    rewrite(tmp, values->data);
                }
            }
        }
    }

    if (!(tmp[0] > 30 && tmp[0] <= 126)) {
        return;
    }
    print_name(table);
    cout << ",E," << find << " == ";
    print_data(tmp);
}

void deleting_blok(Vector* selectors, int number_of_selectors[], int number, bool wypisanie, int& ilosc_blokow) {
    int sum = 0;
    for (int i = 0; i < number; i++) {
        sum += number_of_selectors[i];
    }
    for (int j = 0; j < number_of_selectors[number]; j++) {
        selectors->remove(sum + j);
    }
    if (number < ilosc_blokow) {
        for (int i = number; i < little_size - 1; i++) {
            number_of_selectors[i] = number_of_selectors[i + 1];
        }
        if (wypisanie) {
            cout << number + 1 << ",D,* == ";
            cout << "deleted" << endl;
        }
        ilosc_blokow--;
    }
    //print(selectors);
}


int deleteNode(Vector* selectors, char table[], int number_of_selectors[], int number, int& ilosc_blokow){
    int sum = 0;
    for (int i = 0; i < number; i++) {
        sum += number_of_selectors[i];
    }
    for (int j = 0; j < number_of_selectors[number]; j++) {
        element* temp1 = selectors->getElement(sum + j)->head_index, * temp2 = NULL;
        element* temp3 = selectors->getElement(sum + j)->head_values, * temp4 = NULL;
        
        while (temp1 != NULL) {
            temp1 = temp1->next;
        }

        temp1 = selectors->getElement(sum + j)->head_index;

        int nodeOffset = 0;
        while (!compare(temp1->data, table)) {
            if (temp1 == NULL) { return 0; }
            temp1 = temp1->next;
            nodeOffset++;
        }

        temp1 = selectors->getElement(sum + j)->head_index;

        if (nodeOffset == 0) {
            selectors->getElement(sum + j)->head_index = selectors->getElement(sum + j)->head_index->next;
            selectors->getElement(sum + j)->head_values = selectors->getElement(sum + j)->head_values->next;
            if (selectors->getElement(sum + j)->head_index == NULL) {
                deleting_blok(selectors, number_of_selectors, number, false, ilosc_blokow);
                delete temp1;
                cout << number + 1 << ",D," << table << " == ";
                cout << "deleted" << endl;
                return 1;
            }
            delete temp1;
            cout << number + 1 << ",D," << table << " == ";
            cout << "deleted" << endl;
            return 0;
        }

        while (nodeOffset-- > 0) {
            temp2 = temp1;
            temp1 = temp1->next;
            temp4 = temp3;
            temp3 = temp3->next;
        }
        temp2->next = temp1->next;
        temp4->next = temp3->next;

        delete temp1;
        delete temp3;
    }
    if(number_of_selectors[number] > 0){
    cout << number + 1 << ",D," << table << " == ";
    cout << "deleted" << endl;
    }
    return 0;
}

char organizer(Vector* selectors, int number_of_selectors[], bool css, int x, int bloks, int& ilosc_blok) {
    char input;
    input = getchar();
    char number = input;
    number = number - 1;
    if (input == '?') {
        input = getchar();
        if (input == '?') {
            input = getchar();
            input = getchar();
            return '1';
        }
        else {
            cout << "? ==  " << ilosc_blok << endl;
            return '2'; //dziala
        }
    }
    else if (input == '*') {
        input = getchar();
        input = getchar();
        input = getchar();
        return '0';
    }
    else if (input == '\n' || input == '\t') {
        return organizer(selectors, number_of_selectors, css, x, bloks, ilosc_blok);
    }
    else if (!css) {
        if (input >= '0' && input <= '9') {
            char n[2];
            int nu = 0;
            n[0] = number;
            input = getchar();
            if (input != ',') {
                n[1] = input;
                input = getchar();
                nu = 10 * (n[0] - 47) + (n[1] - 48);
            }
            input = getchar();
            if (input == 'S') {
                input = getchar();
                char table[little_size];
                cin >> table;
                if (table[0] == '?') {
                    if (nu != 0) {
                        cout << nu << ",S,? == " << number_of_selectors[nu - 1] << endl;//dziala
                    }
                    else if ((number - 48) < bloks) {
                        cout << char(number + 1) << ",S,? == " << number_of_selectors[number - 48] << endl;
                        //wypisanie(number_of_selectors, number - 48);//dziala
                    }
                    return '2';
                }
                else {
                    if (nu != 0) {
                        docelowy_printS(selectors, number_of_selectors, nu - 1, table[0] - 49);
                    }
                    else if (int(number - 48) < bloks) {
                        docelowy_printS(selectors, number_of_selectors, int(number - 48), table[0] - 49);
                    }
                    return '2';
                }
            }
            else if (input == 'A') {
                input = getchar();
                char table[little_size];
                cin >> table;
                if (table[0] == '?') {
                    if (nu != 0) {
                        ilosc_atrybutow(selectors, number_of_selectors, nu - 1);//dziala
                    }
                    else {
                        ilosc_atrybutow(selectors, number_of_selectors, number - 48); //dziala
                    }
                    return '2';
                }
                else {
                    if (nu != 0) {
                        szukanie_head(selectors, number_of_selectors, nu - 1, table);//dziala
                    }
                    else {
                        szukanie_head(selectors, number_of_selectors, number - 48, table);
                    }
                    return '2';
                }
            }
            else if (input == 'D') {
                input = getchar();
                char sele_table[little_size];
                cin >> sele_table;
                if (sele_table[0] == '*') {
                    if (nu != 0) {
                        deleting_blok(selectors, number_of_selectors, nu - 1, true, ilosc_blok);//dziala
                    }
                    else {
                        deleting_blok(selectors, number_of_selectors, number - 48, true, ilosc_blok);
                    }
                    return '3';
                }
                else {
                    if (nu != 0) {
                        int test = deleteNode(selectors, sele_table, number_of_selectors, nu - 1, ilosc_blok);
                        if (test == 1) {
                            return '3';
                        }
                    }
                    else {
                        int test = deleteNode(selectors, sele_table, number_of_selectors, number - 48, ilosc_blok);
                        if (test == 1) {
                            return '3';
                        }
                    }
                    return '4';
                }
            }
        }
        else if ((input >= 'a' && input <= 'z') || (input >= 'A' && input <= 'Z') || input == '#') {
            char name_table[little_size];
            int a = 0;
            while (input != ',') {
                name_table[a] = input;
                input = getchar();
                a++;
            }
            name_table[a] = '~';
            input = getchar();
            if (input == 'S') {
                input = getchar();
                input = getchar();
                if (input == '?') {
                    print_name(name_table);
                    cout << ",S,? == " << szukanie_ilosci_nazwy(selectors, name_table, x) << endl;
                    return '2';
                }
            }
            if (input == 'A') {
                input = getchar();
                input = getchar();
                if (input == '?') {
                    print_name(name_table);
                    cout << ",A,? == " << szukanie_ilosci_selektora(selectors, number_of_selectors, name_table, x, bloks) << endl;
                    return '2';
                }
            }
            if (input == 'E') {
                input = getchar();
                char sele_table[little_size];
                cin >> sele_table;
                char tmp[size];
                szukanie_wartosci(selectors, name_table, x, sele_table, tmp);
                return '2';
            }
        }
    }
    else {
        return input;
    }
    return input;
}
int main()
{
    Vector* selectors = new Vector();
    char arr_selectors[little_size * 3];
    int number_of_selectors[size];
    int index = 0;
    long int counter = 0;
    char input = 0;
    int ilosc_blokow = 0;
    bool css = true;
    while (true) {
        if (input == 49) {
            css = false;
        }
        else if (input == '0') {
            css = true;
        }
        if (css) {
            int n_c = arry_sele(arr_selectors, input);
            number_of_selectors[index] = arry_(selectors, arr_selectors, counter);
            if (number_of_selectors[index] == 0) {
                break;
            }
            counter += number_of_selectors[index];
            ilosc_blokow++;
            index++;
        }
        input = organizer(selectors, number_of_selectors, css, counter, index, ilosc_blokow);
        if (input == '3') {
            counter = 0;
            for (int i = 0; i < size; i++) {
                if (number_of_selectors[i] < 0) {
                    break;
                }
                counter += number_of_selectors[i];
            }
            index--;
        }
        if (input == '7') {
            break;
        }
        if (feof(stdin) != 0) {
            break;
        }
        if (input == EOF) {
            break;
        }
    }
    delete selectors;
    return 0;
}
