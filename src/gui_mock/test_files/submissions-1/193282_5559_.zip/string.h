#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>

using namespace std;
class String
{
	
	friend ostream& operator<<(ostream& ostr, const String& str);

	//friend istream& operator>>(istream& istr, const String& string2);


	char* string;
	
public:

	String();
	String(const char* wartosc);
	String(const String& zrodlo);
	String(String&& zrodlo);

	String operator+(const String& rightStr);
	String operator+=(char znak);
	String operator+=(const char* znak);
	String operator+=(const String& rightStr);
	String& operator=(const String& rightStr);
	String operator=(const char* znaki);

	char operator[](int i);
	bool operator==(const String& rightStr);
	bool operator==(const char* znak);

	bool operator!=(const String& rightStr);
	bool operator!=(const char* znak);

	void wytnij(String& kopia,int poz,int dlu);

	void usunOstatnieBialeSpacje();

	bool jestLiczba();
	int naLiczbe();
	int znajdz(char znak);

	void wyczysc();

	int StrLength();

	~String();
};




