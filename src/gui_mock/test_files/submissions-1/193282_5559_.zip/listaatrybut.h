#pragma once

#pragma once
#include <iostream>
#include "string.h"
using namespace std;


struct ListA {
	String atrybut;
	String wartosc;
	ListA* next;

	ListA() :
		atrybut(NULL), next(nullptr) {};

	ListA(String nazwa) :
		atrybut(nazwa), next(nullptr) {};

	ListA(String nazwa, ListA* tmpNext) :
		atrybut(nazwa), next(tmpNext) {};
};

class ListaAtrybut
{
	ListA* head;

public:
	ListaAtrybut() :
		head(nullptr) {};



	void dodajAtrybut(String nazwa);

	void dodajWartosc(String atrybut, String wartosc);

	void usunAtrybut(String nazwa);

	void displayAtrybut();

	int ileAtrybutow();

	bool znajdzNazwe(String nazwa);

	String wartoscAtrybutu(String atrybut);
	~ListaAtrybut();

};

