#define _CRT_SECURE_NO_WARNINGS
#include "string.h"
#include <cstring>
#include <iostream>

String::String()
	:string{nullptr}
{
	string = new char[1];
	string[0] = '\0';
}

String::String(const char* wartosc)
{
	if (wartosc == nullptr) //jesli przypisujemy pustego stringa
	{
		string = new char[1];
		string[0] = '\0';
	}
	else
	{

		string = new char[strlen(wartosc) + 1];
		strcpy(string, wartosc);
		string[strlen(wartosc)] = '\0';
	}
}

String::String(const String& zrodlo)
{
	//cout << "&" << endl;
	string = new char[strlen(zrodlo.string) + 1];
	strcpy(string, zrodlo.string);
}

String::String(String&& zrodlo)
{
	string = zrodlo.string;
	zrodlo.string = nullptr;
}


ostream& operator<<(ostream& ostr, const String& str)
{
	return ostr << str.string;
}

String String::operator+(const String& rightStr)
{
	int dS = strlen(string);
	int dluWspolna = dS + strlen(rightStr.string);
	
	char* tmp = new char[dluWspolna + 1];

	
	for (int i = 0;i < dluWspolna;i++)
	{
		if (i < dS)
		{
			tmp[i] = string[i];
		}
		else
		{
			tmp[i] = rightStr.string[i - dS];
		}
	}
	tmp[dluWspolna] = '\0';
	
	return tmp;
}

String String::operator+=(const String& rightStr)
{
	int dS = strlen(string);
	int dluWspolna = dS + strlen(rightStr.string);
	char* tmp = new char[dluWspolna + 1];

	for (int i = 0;i < dluWspolna;i++)
	{
		if (i < dS)
		{
			tmp[i] = string[i];
		}
		else
		{
			tmp[i] = rightStr.string[i - dS];
		}
	}
	delete[] string;
	string = new char[dluWspolna + 1];
	string = tmp;
	string[dluWspolna] = '\0';

	return *this;
}

String String::operator+=(const char* znak)
{
	int dS = strlen(string);
	int dluWspolna = dS + strlen(znak);
	char* tmp = new char[dluWspolna + 1];

	for (int i = 0;i < dluWspolna;i++)
	{
		if (i < dS)
		{
			tmp[i] = string[i];
		}
		else
		{
			tmp[i] = znak[i - dS];
		}
	}
	delete[] string;
	string = new char[dluWspolna + 1];
	string = tmp;
	string[dluWspolna] = '\0';

	return *this;
}

String String::operator+=(char znak)
{
	int dS = strlen(string);
	int dluWspolna = dS + 1;
	char* tmp = new char[dluWspolna + 1];

	for (int i = 0;i < dluWspolna;i++)
	{
		if (i < dS)
		{
			tmp[i] = string[i];
		}
		else
		{
			tmp[i] = znak;
		}
	}
	delete[] string;
	string = new char[dluWspolna + 1];
	string = tmp;
	string[dluWspolna] = '\0';

	return *this;
}

String& String::operator=(const String& rightStr)
{
	if (this == &rightStr)
	{
		return *this;
	}
	delete[] string;

	string = new char[strlen(rightStr.string) + 1];
	strcpy(string, rightStr.string);
	return *this;
}

String String::operator=(const char* znaki)
{
	if (znaki == nullptr)
	{
		string = new char[1];
		string[0] = '\0';
		return *this;
	}
	delete[] string;

	string = new char[strlen(znaki) + 1];
	strcpy(string, znaki);
	string[strlen(znaki)] = '\0';

	return *this;
}

bool porownanie(char* p, const char* l)
{
	int dl = strlen(p);
	for (int i = 0;i < dl;i++)
	{
		if (p[i] != l[i])
			return false;
	}
	return true;
}
bool String::operator==(const String& rightStr)
{
	if (this == &rightStr)
		return true;
	
	if(strlen(string)!=strlen(rightStr.string))
		return false;

	return porownanie(string, rightStr.string);
}

bool String::operator==(const char* c)
{
	if (strlen(string) != strlen(c))
		return false;

	return porownanie(string, c);

}

bool String::operator!=(const String& rightStr)
{
	if (this == &rightStr)
		return false;

	if (strlen(string) != strlen(rightStr.string))
		return true;

	return !porownanie(string, rightStr.string);
}

bool String::operator!=(const char* c)
{
	if (strlen(string) != strlen(c))
		return true;

	return !porownanie(string, c);

}

void String::wytnij(String& org,int poz,int dlu)
{
	char* tmp = new char[dlu+1];
	for (int i = poz;i < (dlu+poz);i++)
	{
		tmp[i-poz]=org[i];
	}
	delete[] string;
	string = new char[dlu + 1];
	strcpy(string, tmp);
	string[dlu] = '\0';
}

char String::operator[](int i)
{
	return string[i];
}

int String::StrLength()
{
	return strlen(string);
}

int String::znajdz(char c)
{
	int dl = strlen(string);
	for (int i = 0;i < dl;i++)
	{
		if (string[i] == c)
			return i;
	}
	return NULL;
}

void String::usunOstatnieBialeSpacje()
{
	int d = strlen(string);

	for(int i = d-1;i >= 0;i--)
	{
		if (!isspace(string[i]))
		{
			string[i+1] = '\0';
			break;
		}
	}
}


bool String::jestLiczba()
{
	int d = strlen(string);
	int l;
	
	for (int i = 0;i < d;i++)
	{
		l = string[i];
		if (l < 48 || l>57)
			return false;
	}
	return true;
}

int String::naLiczbe()
{
	return atoi(string);
}
void String::wyczysc()
{
	delete[] string;
	string = new char[1];
	string[0] = '\0';
}
String::~String()
{
	delete string;
}
