#include "listaatrybut.h"


void ListaAtrybut::dodajAtrybut(String nazwa)
{
	ListA* nowyWezel = new ListA(nazwa);

	if (head == nullptr)
	{
		head = nowyWezel;
	}
	else
	{
		nowyWezel->next = head;
		head = nowyWezel;
	}
}

void ListaAtrybut::dodajWartosc(String atrybut, String nazwa)
{
	ListA* tmp = head;
	while (tmp != nullptr)
	{
		if (tmp->atrybut == atrybut)
			tmp->wartosc = nazwa;
		tmp = tmp->next;
	}
}
void ListaAtrybut::usunAtrybut(String nazwa)
{
	ListA* tmp;
	if (head->atrybut == nazwa)
	{
		tmp = head;
		head = head->next;
		delete tmp;
	}
	else
	{
		ListA* current = head;
		while (current->next != nullptr)
		{
			if (current->next->atrybut == nazwa)
			{
				tmp = current->next;
				current->next = current->next->next;
				delete tmp;
				break;
			}
			current = current->next;
		}
	}
}

void ListaAtrybut::displayAtrybut()
{
	ListA* tmp = head;
	while (tmp != nullptr)
	{
		cout << tmp->atrybut << " " << tmp->wartosc << endl;
		tmp = tmp->next;
	}
	delete tmp;
}

int ListaAtrybut::ileAtrybutow()
{
	int ile = 0;
	ListA* tmp = head;
	while (tmp != nullptr)
	{
		ile++;
		tmp = tmp->next;
	}
	delete tmp;
	return ile;
}
bool ListaAtrybut::znajdzNazwe(String nazwa)
{
	ListA* tmp = head;
	while (tmp != nullptr)
	{
		if (tmp->atrybut == nazwa)
			return true;
		tmp = tmp->next;
	}
	return false;
}

String ListaAtrybut::wartoscAtrybutu(String atrybut)
{
	ListA* tmp = head;
	while (tmp != nullptr)
	{
		if (tmp->atrybut == atrybut)
			return tmp->wartosc;
		tmp = tmp->next;
	}
	return "\0";
}
ListaAtrybut::~ListaAtrybut()
{
	ListA* tmp = head;
	ListA* next;
	while (tmp != nullptr)
	{
		next = tmp->next;
		delete tmp;
		tmp = next;
	}
	head = nullptr;
}