#include "list.h"

void List::dodajSelektor(String nazwa, int nrSekcji)
{
	ListaGlowna* tmp = new ListaGlowna();


	if (head == nullptr)
	{
		tmp->ileZajeto = 1;
		tmp->nrNajSekcji = nrSekcji;
		tmp->sekcja[0].nrSekcji = nrSekcji;
		tmp->sekcja[0].selektor.dodajElement(nazwa);
		tmp->next = head;
		tmp->prev = nullptr;
		head = tmp;

	}
	else if (head != nullptr)
	{

		bool dodalo = false;
		for (int i = 0;i < T;i++)
		{
			if (head->sekcja[i].nrSekcji == nrSekcji)
			{
				if(!head->sekcja[i].selektor.znajdzNazwe(nazwa))
					head->sekcja[i].selektor.dodajElement(nazwa);
				dodalo = true;
				break;
			}
		}

		if (dodalo == false)
		{
			for (int i = 0;i < T;i++)
			{
				if (head->sekcja[i].nrSekcji == NULL)
				{
					head->nrNajSekcji = nrSekcji;
					head->sekcja[i].nrSekcji = nrSekcji;
					head->sekcja[i].selektor.dodajElement(nazwa);
					head->ileZajeto = head->ileZajeto + 1;
					dodalo = true;
					break;
				}
			}
		}

		if (dodalo == false)
		{
			tmp->ileZajeto = 1;
			tmp->nrNajSekcji = nrSekcji;
			tmp->sekcja[0].nrSekcji = nrSekcji;
			tmp->sekcja[0].selektor.dodajElement(nazwa);
			tmp->next = head;
			head->prev = tmp;
			head = tmp;
		}
	}
}


void List::dodajAtrybut(String atrybut, String wartosc, int nrSekcji)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					if (!tmp->sekcja[i].atrybut.znajdzNazwe(atrybut))
						tmp->sekcja[i].atrybut.dodajAtrybut(atrybut);
					tmp->sekcja[i].atrybut.dodajWartosc(atrybut, wartosc);
				}
			}
		}
		tmp = tmp->next;
	}
}

bool List::znajdzNrSekcji(int nrSekcji)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					return true;
				}
			}
		}
		tmp = tmp->next;
	}

	return false;		//  (nie znaleziono)

}

int List::ileSelektorowWSekcji(int nrSekcji)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					return tmp->sekcja[i].selektor.ileSelektorow();
				}
			}
		}
		tmp = tmp->next;
	}

	return 0;
}

int List::ileAtrybutowWSekcji(int nrSekcji)
{
	ListaGlowna* tmp = head;


	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					return tmp->sekcja[i].atrybut.ileAtrybutow();
				}
			}
		}
		tmp = tmp->next;
	}

	return 0;
}

String List::nazwaJSelektoraWISekcji(int nrSekcji, int nrSelektora)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					return tmp->sekcja[i].selektor.jSelektor(nrSelektora);
				}
			}
		}
		tmp = tmp->next;
	}

	return "\0";
}

String List::wartoscAtrybutuWISekcji(int nrSekcji, String atrybut)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					return tmp->sekcja[i].atrybut.wartoscAtrybutu(atrybut);
				}
			}
		}
		tmp = tmp->next;
	}

	return "\0";
}

void List::displayList()
{
	ListaGlowna* tmp = head;
	while (tmp != nullptr)
	{
		cout << "TABLICA ZAJETA PRZEZ: " << tmp->ileZajeto << endl;
		cout << "NR NAJWIEKSZEJ SESJI: " << tmp->nrNajSekcji << endl;
		for (int i = 0;i < T;i++)
		{
			cout << i << endl << endl;
			if (tmp->sekcja[i].nrSekcji != NULL)
			{
				cout << tmp->sekcja[i].nrSekcji << endl;
				cout << "Selektor:" << endl;
				tmp->sekcja[i].selektor.displayList();
				cout << "Atrybut i wartosc:" << endl;
				tmp->sekcja[i].atrybut.displayAtrybut();
				cout << endl;
			}
		}
		cout << "DO NOWEJ" << endl;
		tmp = tmp->next;
	}

}

void usunSekcje(ListaGlowna* tmp, int i)
{

	tmp->ileZajeto--;
	int usuwanaSekcja = tmp->sekcja[i].nrSekcji;
	tmp->sekcja[i].selektor.~ListaSelektor();
	tmp->sekcja[i].atrybut.~ListaAtrybut();
	tmp->sekcja[i].nrSekcji = NULL;
	tmp->nrNajSekcji--;

	for (int j = 0;j < T;j++)
	{
		if (tmp->sekcja[j].nrSekcji != NULL)
		{
			if(tmp->sekcja[j].nrSekcji>=usuwanaSekcja)
				tmp->sekcja[j].nrSekcji--;
		}
	}


	tmp = tmp->prev;
	while (tmp != nullptr)
	{
		tmp->nrNajSekcji--;
		for (int j = 0;j < T;j++)
		{
			if (tmp->sekcja[j].nrSekcji != NULL)
			{
				tmp->sekcja[j].nrSekcji--;
			}

		}
		tmp = tmp->prev;
	}

}

void usuwanieBloku(ListaGlowna** head, ListaGlowna* usunNode)
{
	if (*head == nullptr || usunNode == nullptr)
		return;

	if (*head == usunNode)
		*head = usunNode->next;

	if (usunNode->next != nullptr)
		usunNode->next->prev = usunNode->prev;

	if (usunNode->prev != nullptr)
		usunNode->prev->next = usunNode->next;

	delete usunNode;
}

bool List::usuwanieAtrybutu(int nrSekcji, String atrybut)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					if (tmp->sekcja[i].atrybut.znajdzNazwe(atrybut))
					{
						tmp->sekcja[i].atrybut.usunAtrybut(atrybut);

						if (tmp->sekcja[i].atrybut.ileAtrybutow() == 0)
						{
							usunSekcje(tmp, i);
							if (tmp->ileZajeto == 0)
							{
								usuwanieBloku(&head, tmp);
							}
						}
						return true;
					}
					else
						return false;
				}
			}
		}
		tmp = tmp->next;
	}
	return false;
}

bool List::usuwanieSekcji(int nrSekcji)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		if(tmp->nrNajSekcji>=nrSekcji)
		{
			for (int i = 0;i < T;i++)
			{
				if (tmp->sekcja[i].nrSekcji == nrSekcji)
				{
					usunSekcje(tmp, i);
					if (tmp->ileZajeto == 0)
					{
						usuwanieBloku(&head, tmp);
					}
					return true;
				}
			}
		}
		tmp = tmp->next;
	}
	return false;
}

int List::ileSekcji()
{
	if (head != nullptr)
		return head->nrNajSekcji;

	return 0;
}

int List::ileSelektorow(String selektor)
{
	ListaGlowna* tmp = head;

	int ile = 0;

	while (tmp != nullptr)
	{
		for (int i = 0;i < T;i++)
		{
			if (tmp->sekcja[i].selektor.znajdzNazwe(selektor))
				ile++;
		}
		tmp = tmp->next;
	}
	return ile;
}

int List::ileAtrybutow(String atrybut)
{
	ListaGlowna* tmp = head;

	int ile = 0;

	while (tmp != nullptr)
	{
		for (int i = 0;i < T;i++)
		{
			if (tmp->sekcja[i].atrybut.znajdzNazwe(atrybut))
				ile++;
		}
		tmp = tmp->next;
	}
	return ile;
}

String List::ostatniaWartoscAtrybutuSelektora(String selektor, String atrybut)
{
	ListaGlowna* tmp = head;

	while (tmp != nullptr)
	{
		for (int i = T-1;i >=0 ;i--)
		{
			if(tmp->sekcja[i].nrSekcji!=NULL)
			{
				if (tmp->sekcja[i].selektor.znajdzNazwe(selektor))
				{
					if (tmp->sekcja[i].atrybut.znajdzNazwe(atrybut))
						return tmp->sekcja[i].atrybut.wartoscAtrybutu(atrybut);
				}
			}
		}
		tmp = tmp->next;
	}
	return "\0";
}
List::~List()
{
	ListaGlowna* tmp = nullptr;
	while (head)
	{
		tmp = head;
		head = head->next;
		delete tmp;
	}
	head = nullptr;
}
