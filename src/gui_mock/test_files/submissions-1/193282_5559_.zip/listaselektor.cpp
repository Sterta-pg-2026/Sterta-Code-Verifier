#include "listaselektor.h"

void ListaSelektor::dodajElement(String nazwa)
{
	ListS* nowyWezel = new ListS(nazwa);

	if (head == nullptr)
	{
		head = nowyWezel;
	}
	else
	{
		nowyWezel->next = head;
		head = nowyWezel;
	}
}

void ListaSelektor::usunElement(String nazwa)
{
	ListS* tmp = head;
	if (head == nullptr && head->nazwa == nazwa)
	{
		head = tmp->next;
		delete tmp;
		return;
	}

	ListS* curr = head;

	while (tmp != nullptr && tmp->nazwa != nazwa)
	{
		curr = tmp;
		tmp = tmp->next;
	}

	if (!tmp)
		return;

	curr->next = tmp->next;
	delete tmp;
}

void ListaSelektor::displayList()
{
	ListS* tmp = head;
	while (tmp != nullptr)
	{
		cout << tmp->nazwa << endl;
		tmp = tmp->next;
	}
	delete tmp;
}

bool ListaSelektor::znajdzNazwe(String nazwa)
{
	ListS* tmp = head;
	while (tmp != nullptr)
	{
		if (tmp->nazwa == nazwa)
			return true;
		tmp = tmp->next;
	}
	return false;
}

int ListaSelektor::ileSelektorow()
{
	ListS* tmp = head;
	int i = 0;
	while (tmp != nullptr)
	{
		if(tmp->nazwa!="\0")
			i++;
		tmp = tmp->next;
	}
	return i;
}

String ListaSelektor::jSelektor(int j)
{
	ListS* tmp = head;
	int i = 1;
	while (tmp != nullptr)
	{
		if (i == j)
			return tmp->nazwa;
		i++;
		tmp = tmp->next;
	}
	return "\0";

}
ListaSelektor::~ListaSelektor()
{
	ListS* tmp = head;
	ListS* next;
	while (tmp != nullptr)
	{
		next = tmp->next;
		delete tmp;
		tmp = next;
	}
	head = nullptr;
}