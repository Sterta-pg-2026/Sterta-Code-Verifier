
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include "string.h"
#include "list.h"

using namespace std;

void wlaczFlSelektor(bool &flS,bool &flA,bool &flW)
{
	flS = true;
	flA = false;
	flW = false;
}
void wlaczFlAtrybut(bool& flS, bool& flA, bool& flW)
{
	flS = false;
	flA = true;
	flW = false;
}
void wlaczFlWartosc(bool& flS, bool& flA, bool& flW)
{
	flS = false;
	flA = false;
	flW=true;
}
void zrealizujKomende(String pierwszy, String komenda, String ostatni, int i, int j,List& CSS,int& nrSekcji)
{
	if (komenda == "S")
	{
		if (i > 0)
		{

			if (CSS.znajdzNrSekcji(i) == true)
			{
				int ileS = CSS.ileSelektorowWSekcji(i);
				if (ostatni == "?")
				{
					cout << i << ",S,? == " << ileS << endl;
				}
				else
				{
					String selektor = CSS.nazwaJSelektoraWISekcji(i, ileS - j + 1);
					
					if (selektor != "\0")
						cout << i << ",S," << j << " == " << CSS.nazwaJSelektoraWISekcji(i, ileS - j+1) << endl;
				}
			}
		}
		else
		{
			cout << pierwszy << ",S,? == " << CSS.ileSelektorow(pierwszy) << endl;
		}
	}
	else if (komenda == "A")
	{
		if (i > 0)
		{
			if (CSS.znajdzNrSekcji(i) == true)
			{
				if (ostatni == "?")
				{
					cout << i << ",A,? == " << CSS.ileAtrybutowWSekcji(i) << endl;
				}
				else
				{
					String wartosc = CSS.wartoscAtrybutuWISekcji(i, ostatni);
					if(wartosc!="\0")
						cout << i << ",A," << ostatni << " == " << wartosc << endl;
				}
			}
			
		}
		else
		{
			cout << pierwszy << ",A,? == " << CSS.ileAtrybutow(pierwszy) << endl;
		}
	}
	else if (komenda == "E")
	{
		String ostatniaWartosc = CSS.ostatniaWartoscAtrybutuSelektora(pierwszy,ostatni);
		if(ostatniaWartosc!="\0")
			cout << pierwszy << ",E," << ostatni << " == " << ostatniaWartosc << endl;
	}
	else if (komenda == "D")
	{
		if (ostatni == "*")
		{
			if (CSS.usuwanieSekcji(i))
			{
				cout << i << ",D,* == deleted" << endl;
				nrSekcji = CSS.ileSekcji()+1;
			}
		}
		else
		{
			if (CSS.usuwanieAtrybutu(i, ostatni))
			{
				cout << i << ",D," << ostatni << " == deleted" << endl;
				nrSekcji = CSS.ileSekcji()+1;
			}
		}
	}

}
void komenda(List &CSS,int &nrSekcji)
{
	char c;
	String tekst;

	bool flPoczatek = true;
	bool flPierwszyAr = true;
	bool flDrugiAr = false;
	bool flTrzeciAr = false;
	bool flBlad = false;

	unsigned int jakaSekcja = 0;
	unsigned int ktory=0;
	String pierwszy;
	String ostatni;
	String komenda;

	while ((c=getchar())!=EOF)
	{
		//cin.get(c);

		if (flBlad == true)
		{
			if (c == '\n' || c == '\0')
			{
				flBlad = false;
				flPierwszyAr = true;
			}

		}
		else if (flPoczatek == true && isspace(c))		//jesli zaczynamy wczytywac slowo, tzn tekst jest pusty i wykryty znak to bialy znak - pomin
			continue;
		else if (flPoczatek == true && !isspace(c))
		{
			flPoczatek = false;
			tekst += c;
		}
		else if (c<32 || c == ',')
		{
				flPoczatek = true;

			tekst.usunOstatnieBialeSpacje();

			if (tekst == "****")
			{
				return;
			}
			else if (tekst == "?" && flPierwszyAr == true)
			{
				cout << "? == " << CSS.ileSekcji() << endl;
				tekst.wyczysc();
				continue;
			}
			else if (flPierwszyAr==true)
			{
				if (tekst.jestLiczba())
					jakaSekcja = tekst.naLiczbe();
				else
					pierwszy = tekst;

				flPierwszyAr = false;
				flDrugiAr = true;
			}
			else if (flDrugiAr == true)
			{
				if (tekst == "S" || tekst == "A" || tekst == "E" || tekst == "D")
				{
					komenda = tekst;
					flDrugiAr = false;
					flTrzeciAr = true;
				}
				else
				{
					flDrugiAr = false;
					flPierwszyAr = false;
					flTrzeciAr = false;
					jakaSekcja = 0;
					ktory = 0;
					ostatni.wyczysc();
					komenda.wyczysc();
					pierwszy.wyczysc();
					flBlad = true;
				}

			}
			else if (flTrzeciAr == true)
			{
				if (tekst.jestLiczba())
					ktory = tekst.naLiczbe();
				else
					ostatni = tekst;

				
				zrealizujKomende(pierwszy, komenda, ostatni, jakaSekcja, ktory, CSS,nrSekcji);
				jakaSekcja = 0;
				ktory = 0;
				ostatni.wyczysc();
				komenda.wyczysc();
				pierwszy.wyczysc();
				flTrzeciAr = false;
				flPierwszyAr = true;
			}

			
			tekst.wyczysc();
		}
		else if (flPoczatek == false)
		{
			if (isspace(c) && c != ' ')
				continue;
			else
				tekst += c;
		}
	}

	if (c == EOF)
	{
		if (tekst == "?"&&flTrzeciAr==false)
		{
			cout << "? == " << CSS.ileSekcji() << endl;
		}
		else if (flTrzeciAr == true)
		{
			if (tekst.jestLiczba())
				ktory = tekst.naLiczbe();
			else
				ostatni = tekst;

			zrealizujKomende(pierwszy, komenda, ostatni, jakaSekcja, ktory, CSS, nrSekcji);
		}
		
	}
}
int main()
{
	List CSS;

	char c;
	String tekst;
	String tmpAtr;

	int nrSekcji = 1;
	bool flWyraz = true;		//jesli false to wczytujemy wyraz, jesli true to konczymy wyraz i odsylamy dalej
	bool flPoczatek = true;

	bool flSelektor = true;
	bool flAtrybut = false;
	bool flWartosc = false;

	bool wpisanoSelektor = false;
	
	while ((c = getchar()) != EOF)
	{
		//cin.get(c);
		
		if (flPoczatek == true && isspace(c))		//jesli zaczynamy wczytywac slowo, tzn tekst jest pusty i wykryty znak to bialy znak - pomin
			continue;
		else if (flPoczatek == true && !isspace(c)) //jesli zaczynamy wczytywac slowo i wykryty znak nie jest bialym znakiem wczytaj i zmien flagi
		{
			
			
			if (c == '{')
			{
				if (wpisanoSelektor == false)
					CSS.dodajSelektor("\0", nrSekcji);
				wlaczFlAtrybut(flSelektor, flAtrybut, flWartosc);
			}
			else if (c == '}')
			{
				wlaczFlSelektor(flSelektor, flAtrybut, flWartosc);
				nrSekcji++;
				wpisanoSelektor = false;
			}
			else
			{
				flPoczatek = false;		//nie trzeba juz sprawdzac i pomijac bialego znaku
				flWyraz = true;			//wczytujemy wyraz, nie pomijamy spacji itp,
				tekst += c;
			}
		}
		else if (c == ',' || c == '\0' || c == '\n' || c==';' || c==':' || c=='{' || c=='}')	//jesli napotkamy znak zakonczenia slowa lub linii zmien flagi zakoncz wczytywac slowo
		{
			//zmianaFlagSAW(flWartosc,flAtrybut,flSelektor,c);
			flWyraz = false;
			flPoczatek = true;


			if ((c == ':' && flAtrybut == false) || (c == ',' && flWartosc == true))
			{
				flWyraz = true;
				flPoczatek = false;
				tekst += c;
				continue;
			}

			
			tekst.usunOstatnieBialeSpacje();		//usuwamy biale znaki znajdujace sie na koncu wyrazu

			if (tekst == "????")
			{
				
				tekst.wyczysc();
				komenda(CSS,nrSekcji);
				continue;
			}
			else if (tekst == "++++")
			{
				tekst.wyczysc();
				CSS.displayList();
				continue;
			}
			

			if (c == '{')
			{
				
				CSS.dodajSelektor(tekst, nrSekcji);
				wpisanoSelektor = true;
				wlaczFlAtrybut(flSelektor, flAtrybut, flWartosc);
			}
			else if (c == '}' && flAtrybut == true)
			{
				wlaczFlSelektor(flSelektor, flAtrybut, flWartosc);
				nrSekcji++;
			}
			else if ((c == '}'||c=='\n'||c=='\0') && flWartosc == true)
			{
				CSS.dodajAtrybut(tmpAtr, tekst, nrSekcji);
				wlaczFlSelektor(flSelektor, flAtrybut, flWartosc);
				nrSekcji++;
			}
			else if (c == ';')
			{
				CSS.dodajAtrybut(tmpAtr, tekst, nrSekcji);
				wlaczFlAtrybut(flSelektor, flAtrybut, flWartosc);
			}
			else if (c == ':' && flAtrybut == true)
			{
				tmpAtr = tekst;
				wlaczFlWartosc(flSelektor, flAtrybut, flWartosc);
			}
			else if (flSelektor)
			{
				CSS.dodajSelektor(tekst, nrSekcji);
				wpisanoSelektor = true;
			}
			
			//cout << tekst << " " << tekst.StrLength() << endl;
			tekst.wyczysc();						//czyscimy obiekt tekst
			
		}
		else if (flWyraz)							//jesli wyraz i nic powyzsze wczytuj 
		{
			tekst += c;
		}
	}
};
