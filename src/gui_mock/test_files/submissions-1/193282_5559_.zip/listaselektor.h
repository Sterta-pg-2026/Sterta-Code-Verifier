#pragma once
#include <iostream>
#include "string.h"
using namespace std;


struct ListS {
	String nazwa;
	ListS* next;

	ListS() :
		nazwa(NULL), next(nullptr) {};

	ListS(String nazwa) :
		nazwa(nazwa), next(nullptr) {};

	ListS(String nazwa, ListS* tmpNext) :
		nazwa(nazwa), next(tmpNext) {};
};

class ListaSelektor
{
	ListS* head;

public:
	ListaSelektor() :
		head(nullptr) {};

	void dodajElement(String nazwa);

	void usunElement(String nazwa);

	void displayList();

	bool znajdzNazwe(String nazwa);

	int ileSelektorow();

	String jSelektor(int j);

	~ListaSelektor();

};

