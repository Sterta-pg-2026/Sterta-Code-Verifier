#pragma once
#include "listaselektor.h"
#include "listaatrybut.h"

const int T = 11;

struct Blok {
	int nrSekcji = NULL;
	ListaAtrybut atrybut;
	ListaSelektor selektor;
};

struct ListaGlowna {
	int nrNajSekcji = NULL;
	int ileZajeto = NULL;
	Blok sekcja[T];
	ListaGlowna* prev;
	ListaGlowna* next;

	ListaGlowna() :
		ileZajeto(NULL), nrNajSekcji(NULL), prev(nullptr), next(nullptr) {};
};

class List
{
	ListaGlowna* head;
	ListaGlowna* tail;

public:

	List() :
		head(nullptr), tail(nullptr) {};

	bool znajdzNrSekcji(int nrSekcji);

	void dodajSelektor(String data, int nrSekcji);
	void dodajAtrybut(String atrybut, String wartosc, int nrSekcji);

	bool usuwanieAtrybutu(int nrSekcji, String atrybut);
	bool usuwanieSekcji(int nrSekcji);
	void displayList();

	int ileSekcji();
	int ileSelektorow(String selektor);
	int ileAtrybutow(String atrybut);
	int ileSelektorowWSekcji(int nrSekcji);
	int ileAtrybutowWSekcji(int nrSekcji);

	String wartoscAtrybutuWISekcji(int nrSekcji, String atrybut);
	String nazwaJSelektoraWISekcji(int nrSekcji, int nrSelektora);
	String ostatniaWartoscAtrybutuSelektora(String selektor, String atrybut);

	~List();
};

