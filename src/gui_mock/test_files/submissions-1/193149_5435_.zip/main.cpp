#include <iostream>

#define SIZE 100
using namespace std;

struct Attrib {
	int size = SIZE * 2;
	struct Attrib* next = NULL;
	//char name[SIZE * 2] = {};
	//char value[SIZE * 2] = {};
	char* name = new char[size];// nameof attribute in block
	char* value = new char[size];// value of attribute
};

struct Selec {
	int size = SIZE * 2;
	struct Selec* next = NULL;
	//char name[SIZE * 2] = {};
	char* name = new char[size];
};

struct Block {
	int size = SIZE * 2, aCount = 0, sCount = 0;
	Selec* selectors = new Selec[size];// selsectors correlated to this block of css
	Attrib* attributes = new Attrib[size];// attributes and their values
};

struct Node {
	int first = 0;
	// array for blocks of css
	Block blocks[8];
	// index of next place in arr
	int b = 0, attr = 0, val = 0, selec = 0, size = 1;
	// b = place in block, attr = index of attribute, val = index of value, selec = index of selector
	// pointers to nex and prev node
	struct Node* next = NULL;
	struct Node* prev = NULL;
};

bool compareC(char one[], char two[]) {
	int i = 0, k = 0;
	while (two[i] == ' ' || two[i] == '\t') {
		i++;
	}
	if (one == NULL || two == NULL) {
		return false;
	}
	if (two[0] == '\0' && one[0] != '\0' || two[0] != '\0' && one[0] == '\0') {
		return false;
	}
	while (two[i] != '\0' && one[k] != '\0') {
		if (i == 0 && one[i] == ' ') {
			i++;
		}
		if (one[k] == ' ' && two[i] == '\0') {
			k++;
		}
		if (one[k] != two[i]) {
			return false;
		}
		i++;
		k++;
	}
	if (two[i] == '\0' && one[k] != '\0' || two[i] != '\0' && one[k] == '\0') {
		return false;
	}
	return true;
}

void putSelec(char selector[], char line[]) {// copies name of selector
	int i = 0, k = 0;
	while (line[i] != '\0') {
		if (k == 0 && line[k] == ' ') {
			k++;
		}
		if (line[k] == ' ' && line[k + 1] == '\0') {
			break;
		}
		selector[i] = line[k];
		i++;
		k++;
	}
	selector[i] = '\0';
}

void putAttrName(char name[], char line[]) {// copies name of attribute
	int i = 0, k = 0;
	while (line[i] != '\0') {
		if (k == 0 && line[k] == ' ') {
			k++;
		}
		if (line[k] == ' ' && line[k + 1] == '\0') {
			break;
		}
		name[i] = line[k];
		i++;
		k++;
	}
	name[i] = '\0';
}

void putAttrValue(char value[], char line[]) {
	int i = 0, k = 0;
	while (line[i] != '\0') {
		if (k == 0 && line[k] == ' ') {
			k++;
		}
		if (line[k] == ' ' && line[k + 1] == '\0') {
			break;
		}
		value[i] = line[k];
		i++;
		k++;
	}
	value[i] = '\0';
}

void reset(char c[], int size) {
	for (int i = size; i >= 0; i--) {
		c[i] = '\0';
	}
}

int selsecLC(Block* block, char line[]) {
	int i = 0;
	while (i < block->sCount) {
		if (compareC(block->selectors[i].name, line)) {
			return i;
		}
		i++;
	}
	return -1;
}

int attrLc(Block* block, char line[]) {
	int i = 0;
	while (i < block->aCount) {
		if (compareC(block->attributes[i].name, line)) {
			return i;
		}
		i++;
	}
	return -1;
}

char chooseDestination(char line[], Node* list, bool* blockStart, int* b, int* selec, int* attr, int* val) {
	int i = 0, index = 0, LC;
	// i = size of word, index = place in buffer, 
	// b = place in block, attr = index of attribute, val = index of value, selec = index of selector
	char buff[SIZE * 2] = {};
	if (line[0] == '*' || line[0] == '\0') {
		return ' ';
	}
	while (line[index] != '\0') {
		while (line[index] == '\t' || line[index] == '\r') {
			index++;
		}
		buff[i] = line[index];
		if (line[index + 1] == ',' && *blockStart && line[index] != '\0' || line[index + 1] == '{' && *blockStart && line[index] != '\0' || line[index + 1] == '\0' && *blockStart && line[index] != '\0' || line[index] == ' ' && line[index + 1] == '{' && *blockStart && line[index] != '\0') {
			if (selsecLC(list->blocks + *b, buff) == -1) {
				putSelec(list->blocks[*b].selectors[*selec].name, buff);
				if (*selec > 0) {
					list->blocks[*b].selectors[*selec - 1].next = &list->blocks[*b].selectors[*selec];
				}
				*selec += 1;
				list->blocks[*b].sCount += 1;
			}
			else {

			}
			reset(buff, SIZE * 2 - 1);
			
			
			index++;
			i = -1;
			if (line[index + 1] == '\0' || line[index] == '{') {
				*blockStart = false;
				if (line[index + 2] == '\0' || line[index] == '{' && line[index + 1] == '\0' || line[index] == '{' && line[index + 1] == '\t') {
					return line[index];
				}
				//index++;
			}
		}
		else if (line[index + 1] == ':' && *blockStart == false) {
			LC = attrLc(list->blocks + *b, buff);
			if (LC == -1) {
				putAttrName(list->blocks[*b].attributes[*attr].name, buff);
				if (*attr > 0) {
					(list)->blocks[*b].attributes[*attr - 1].next = &list->blocks[*b].attributes[*attr];
				}
				*attr += 1;
				list->blocks[*b].aCount += 1;
			}
			else {
				putAttrName(list->blocks[*b].attributes[LC].name, buff);
			}
			reset(buff, SIZE * 2 - 1);
			
			index++;
			i = -1;
		}
		else if (line[index + 1] == ';' && line[index] != '}' && line[index] != '{' && *blockStart == false || line[index + 1] == '\0' && line[index] != '}' && line[index] != '{' && *blockStart == false) {
			if (LC >= 0) {
				putAttrValue(list->blocks[*b].attributes[LC].value, buff);
			}
			else {
				putAttrValue(list->blocks[*b].attributes[*val].value, buff);
				*val += 1;
			}
			reset(buff, SIZE * 2 - 1);
			
			index++;
			i = -1;
		}
		else if (line[index] == '}' || line[index + 1] == '}') {
			return line[index];
		}
		index++;
		i++;
	}
	return ' ';
}

void selNum(Node* list) {
	int number = 0, j = 0;
	Node* tmp1 = list;
	while (tmp1->blocks[j].aCount > 0) {
		number += 1;
		j++;
		if (j == 8) {
			j = 0;
			tmp1 = tmp1->next;
		}
	}
	/*while (tmp1->blocks[j].attributes[0].name[0] != '\0') {
		j++;
		number++;
		if (j == 8) {
			j = 0;
			tmp1 = tmp1->next;
		}
	}*/
	cout << "? == " << number << endl;;
	//tmp1 = nullptr;
	//tmp2 = nullptr;
}

bool ifNumber(char tab[], int length) {
	for (int i = 0; i < length; i++) {
		if (tab[i] < '0' || tab[i] > '9') {
			return false;
		}
	}
	return true;
}

int chToBin(char tmp[], int size) {
	int i = 1, x = 0, j = size;
	while (j >= 0) {
		x += ((int)tmp[j] - '0') * i;
		i *= 10;
		j--;
	}
	return x;
}

void amountS(Selec* sel, int x) {
	int i = 1;
	Selec* tmp;
	if (sel->name[0] != '\0' && sel->next == NULL) {
		cout << x << ",S,? == " << 1 << endl;
		return;
	}
	tmp = sel;
	while (tmp->next != NULL) {
		tmp = tmp->next;
		i++;
	}
	cout << x << ",S,? == " << i << endl;
}

void amountA(Attrib* attr, int x) {
	int i = 1;
	Attrib* tmp;
	if (attr->name[0] != '\0' && attr->next == NULL) {
		cout << x << ",A,? == " << 1 << endl;
		return;
	}
	else if (attr->name[0] == '\0') {
		return;
	}
	tmp = attr;
	while (tmp->next != NULL) {
		tmp = tmp->next;
		i++;
	}
	cout << x << ",A,? == " << i << endl;
}

void write(char line[]) {
	int i = 0;
	while (line[i] != '\0') {
		cout << line[i];
		i++;
	}

}

void attribValue(Attrib* attr, char comp[], int i) {
	while (compareC(attr->name, comp) != true) {
		attr = attr->next;
		if (attr == NULL) {
			return;
		}
	}
	cout << i << ",A,";
	write(comp);
	cout << " == ";
	write(attr->value);
	cout << endl;
}

void selecAppear(Node* list, char line[]) {
	int count = 0, b = 0, i = 0, j = 0;
	Selec* tmp = list->blocks[b].selectors;
	while ((list + j)->blocks[b].sCount > 0) {
		while (i < (list + j)->blocks[b].sCount) {
			if (compareC(tmp->name, line)) {
				count++;
				break;
			}
			tmp = tmp->next;
			i++;
		}
		i = 0;
		b++;
		//tmp = list->blocks[b].selectors;
		//i = 0;
		//b++;
		if (b == 8) {
			b = 0;
			j++;
			tmp = (list + j)->blocks[b].selectors;
		}
		else {
			tmp = (list + j)->blocks[b].selectors;

		}
	}
	write(line);
	cout << ",S,? == " << count << endl;
}

void attribAppear(Node* list, char line[]) {
	int count = 0, b = 0, i = 0, j = 0;
	Attrib* tmp = list->blocks[b].attributes;
	while ((list + j)->blocks[b].sCount > 0 && (list + j)->size == j) {

		while (i < (list + j)->blocks[b].aCount) {
			if (compareC(tmp->name, line)) {
				count++;
				break;
			}
			tmp = tmp->next;
			i++;
		}
		i = 0;
		b++;
		if (b == 8) {
			b = 0;
			j++;
			tmp = (list + j)->blocks[b].attributes;
		}
		else {
			tmp = (list + j)->blocks[b].attributes;

		}
	}
	write(line);
	cout << ",A,? == " << count << endl;
}

void selecName(Selec* sel, int j, int k) {
	Selec* pom = sel;
	int i = 0;
	if (sel->name[0] == '\0') {
		return;
	}
	while (i < j) {
		if (i == j - 1) {
			cout << k << ",S," << j << " == ";
			write(pom->name);
			cout << endl;
			return;
		}
		if (pom->next == NULL && i < j - 1) {
			return;
		}
		if (pom->next != NULL) {
			pom = pom->next;
			i++;

		}
		else if (pom->next == NULL) {
			i++;
		}
	}
}

void getSelec(Node* list, char selec[], char attr[]) {
	int b, s, a = 0;
	char* tmp = nullptr;
	do {
		b = list->b - 1;
		s = list->blocks[b].sCount - 1;
		while (b >= 0) {
			if (compareC(list->blocks[b].selectors[s].name, selec)) {
				tmp = list->blocks[b].selectors[s].name;
			}
			s--;
			if (s == -1) {
				if (tmp != nullptr) {
					if (tmp[0] != '\0') {
						break;
					}
				}
				b--;
				s = list->blocks[b].sCount - 1;
			}
		}
		if (tmp != nullptr) {
			if (tmp[0] != '\0') {
				for (int i = 0; i < list->blocks[b].aCount; i++) {

					if (compareC(list->blocks[b].attributes[a].name, attr)) {
						break;
					}
					a++;
				}
				if (a == list->blocks[b].aCount) {
					return;
				}
				write(selec);
				cout << ",E,";
				write(attr);
				cout << " == ";
				write(list->blocks[b].attributes[a].value);
				cout << endl;
				return;
			}
		}
		list = list->prev;

	} while (list != NULL);
}

bool delAttr(Block* block, char attr[], int x, Node* list) {
	int i = 0, del = 0;
	Attrib tmp1;
	while (i < block->aCount) {
		if (compareC(block->attributes[i].name, attr)) {
			reset(block->attributes[i].name, SIZE);
			reset(block->attributes[i].value, SIZE);
			del++;
			block->aCount -= 1;
			//block->aCount -= 1;
			break;
		}
		i++;
	}
	i = 0;
	int y = x - 1;
	if (del > 0) {
		while (1) {
			if (block->attributes[i].name[0] != '\0') {
				while (block->aCount - 2 > y){
				//for (int y = 0; y < SIZE - 2; y++) {
					tmp1 = block->attributes[y + 1];
					block->attributes[y+ 1] = block->attributes[y + 2];
					block->attributes[y] = tmp1;
					y++;
				}
				reset(block->attributes[y + 1].name, SIZE);
				reset(block->attributes[y + 1].value, SIZE);
				//block->attributes[y + 2];
				if (block->attributes->name[0] == '\0') {
					Block tmp2;
					for (int j = x - 1; j < 8 - 2; j++) {
						tmp2 = list->blocks[j + 1];
						list->blocks[j + 1] = list->blocks[j + 2];
						list->blocks[j] = tmp2;
					}
				}
				/*if (list->blocks[0].attributes[0].name[0] == '\0') {
					list.
				}*/
				cout << x << ",D,";
				write(attr);
				cout << " == deleted" << endl;
				return true;
			}
			if (block->aCount == 0) {
				Block tmp;
				for (int y = x; y < 8 - 2; y++) {
					tmp = list->blocks[x + 1];
					list->blocks[y + 1] = list->blocks[y + 2];
					list->blocks[y] = tmp;
				}
				cout << x + 1 << ",D,";
				write(attr);
				cout << " == deleted" << endl;
				return true;
			}
			i++;
		}
	}
	return false;
}

void delSec(Node* list, int x) {
	int j = x - 1;
	while (j - 8 > 0) {
		j -= 8;
	}
	if (list->blocks->attributes[j].name[0] == '\0') {
		return;
	}
	
	for (int i = 0; i < list->blocks[j].sCount; i++) {
		delete[] list->blocks[j].selectors[i].name;
	}
	for (int i = 0; i < list->blocks[j].aCount; i++) {
		delete[] list->blocks[j].attributes[i].name;
		delete[] list->blocks[j].attributes[i].value;
	}
	list->b -= 1;
	Block tmp;
	cout << x << ",D,* == deleted" << endl;
	for (int i = j; i < 8 - 2; i++) {
		tmp = list->blocks[i + 1];
		list->blocks[i + 1] = list->blocks[i + 2];
		list->blocks[i] = tmp;
	}
}

void nextCommand(Node* list, char one[], char two[], char three[], int size1, int size3) {
	int i = 0, j = 0, x, shift = 0;
	if (ifNumber(one, size1 - 1)) {
		i = chToBin(one, size1 - 1);
		x = i;
		while (i > 8) {
			i = i - 8;
			shift++;
		}
		if (*two == 'S') {
			if (*three == '?') {
				if (x % 8 > list[shift].b) {
					return;
				}
				amountS(list[shift].blocks[i - 1].selectors, x);
			}
			else if (ifNumber(three, size3 - 1)) {
				j = chToBin(three, size3 - 1);
				selecName(list[shift].blocks[i - 1].selectors, j, x);
			}
		}
		else if (*two == 'A') {
			if (*three == '?') {
				amountA(list[shift].blocks[i - 1].attributes, x);
			}
			else {
				attribValue(list[shift].blocks[i - 1].attributes, three, x);
			}
		}
		else if (*two == 'D') {
			if (*three == '*') {
				delSec(list + shift, x);
			}
			else {
				if (delAttr(list[shift].blocks + i - 1, three, i - 1, list + shift)) {
					list[shift].b -= 1;
				}
			}
		}
	}
	else {
		if (*two == 'A') {
			if (*three == '?') {
				attribAppear(list, one);
			}
		}
		else if (*two == 'S') {
			if (*three == '?') {
				selecAppear(list, one);
			}
		}
		else if (*two == 'E') {
			Node tmp = *list;
			while (tmp.next != NULL) {
				tmp = *tmp.next;
			}
			getSelec(&tmp, one, three);
		}
	}
}

void command(char line[], Node* list) {
	int i = 0, k = 0, j = 0, x = 0;
	char pom[] = "****";

	if (compareC(line, pom)) {
		return;
	}
	if (line[0] != '\0') {
		if (line[0] == '?') {
			selNum(list);
		}
		else {
			char one[SIZE * 2] = {}, two[SIZE * 2] = {}, three[SIZE * 2] = {};
			while (line[x] != ',') {
				one[i] = line[x];
				x++;
				i++;
			}
			x++;
			while (line[x] != ',') {
				two[j] = line[x];
				x++;
				j++;
			}
			if (j > 1) {
				return;
			}
			x++;
			while (line[x] != '\0') {
				three[k] = line[x];
				k++;
				x++;
			}
			nextCommand(list, one, two, three, i, k);
		}

	}
}

void scan(char line[], int* size) {
	char c = ' ';
	int i = 0;
	while (c != '\n') {
		c = getchar();
		line[i] = c;
		i++;
	}
	line[i - 1] = '\0';
}

int main() {
	int size = SIZE, inUse = 0;
	Node* listT = new Node[size];
	Node* list = new Node[size];
	char line[SIZE * 10] = {}, c[] = "????", block[] = "****";
	line[0] = ' ';
	int i = 0;
	bool blockStart = true, com = false, det, lef;
	for (int b = 0; b < 8; b++) {
		for (int x = 0; x < SIZE * 2; x++) {
			reset(list->blocks[b].attributes[x].name, SIZE * 2 - 1);
			reset(list->blocks[b].attributes[x].value, SIZE * 2 - 1);
			reset(list->blocks[b].selectors[x].name, SIZE * 2 - 1);
		}
	}

	while (cin.getline(line, SIZE * 10)) {
		//scan(line, &size);
		//cin.getline(line, SIZE);
		lef = compareC(line, block);
		det = compareC(line, c);

		if (com == true) {
			command(line, list);
		}

		if (det == true) {// checks if user went into command detection mode
			com = true;
		}
		if (lef == true) {// checks if user left command deteection mode
			com = false;
		}
		if (com == false) {
			if (chooseDestination(line, list + i, &blockStart, &(list + i)->b, &(list + i)->selec, &(list + i)->attr, &(list + i)->val) == '}') {
				//cout << endl;

				(list + i)->b += 1;
				(list + i)->attr = 0;
				(list + i)->val = 0;
				(list + i)->selec = 0;
				(list + i)->size = inUse;
				blockStart = true;
				if ((list + i)->b == 8) {
					inUse++;

					if (i == size - 1) {
						size *= 2;
						listT = new Node[size];

						for (int y = 0; y < size / 2; y++) {
							listT[y] = list[y];
						}
						delete[] list;
						list = listT;
					}
					for (int x = 0; x <= i; x++) {
						list[x].next = &list[x + 1];
						list[x + 1].prev = &list[x];
					}
					i++;
				}
			}
		}
		reset(line, SIZE * 10 - 1);
	}
	command(line, list);

	delete[] list->blocks->attributes;
	delete[] list->blocks->selectors;

	delete[] list;
	return 0;
}
