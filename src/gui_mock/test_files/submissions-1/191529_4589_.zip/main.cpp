#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

enum { BLOCK_SIZE = 17, MAX_TOKEN_SIZE = 4444 };

struct Attribute {
    char* name = NULL;
    char* value = NULL;
};

struct Section {
    int n_selectors = 0;
    int cap_selectors = 0;

    int n_attributes = 0;
    int cap_attributes = 0;

    char** selectors = NULL;
    Attribute* attributes = NULL;
};

struct Block {
    Section sections[BLOCK_SIZE];
    int n = 0;
};

struct BlockNode {
    Block* block = NULL;
    BlockNode* next = NULL;
    BlockNode* prev = NULL;
};

struct BlockList {
    BlockNode* start = NULL;
    BlockNode* finish = NULL;
};

Block* AddBlock(BlockList* list) {
    BlockNode* node = (BlockNode*)calloc(1, sizeof(*node));
    node->block = (Block*)calloc(1, sizeof(*node->block));
    if (list->start == NULL) {
        list->start = list->finish = node;
        return node->block;
    }
    list->finish->next = node;
    node->prev = list->finish;
    list->finish = node;
    return node->block;
}

Section* AddSection(BlockList* list) {
    if (list->finish == NULL || list->finish->block->n == BLOCK_SIZE) {
        AddBlock(list);
    }
    return &(list->finish->block->sections[list->finish->block->n++]);
}

void AddSelector(Section* section, char* selector) {
    for(int i = 0; i < section->n_selectors; ++i) {
        if(strcmp(section->selectors[i], selector) == 0) {
            free(selector);
            return;
        }
    }

    if (section->cap_selectors == section->n_selectors) {
        if (section->cap_selectors == 0) {
            section->cap_selectors = 1;
        }
        else {
            section->cap_selectors *= 2;
        }
        section->selectors = (char**)realloc(
            section->selectors, sizeof(*(section->selectors)) * section->cap_selectors);
    }
    section->selectors[section->n_selectors++] = selector;
}

void AddAttribute(Section* section, char* name, char* value) {
    for (int i = 0; i < section->n_attributes; i++) {
        if (strcmp(section->attributes[i].name, name) == 0) {
            free(section->attributes[i].value);
            section->attributes[i].value = value;
            return;
        }
    }
    if (section->cap_attributes == section->n_attributes) {
        if (section->cap_attributes == 0) {
            section->cap_attributes = 1;
        }
        else {
            section->cap_attributes *= 2;
        }
        section->attributes = (Attribute*)realloc(
            section->attributes, sizeof(*(section->attributes)) * section->cap_attributes);
    }
    section->attributes[section->n_attributes].name = name;
    section->attributes[section->n_attributes].value = value;
    ++section->n_attributes;
}

BlockNode* GetBlockNodeBySectionIdx(BlockList* list, int section_idx, int* section_inblock_idx) {
    BlockNode* curr_node = list->start;
    int total_sections = 0;
    while (curr_node) {
        Block* curr_block = curr_node->block;
        total_sections += curr_block->n;
        if (total_sections > section_idx) {
            *section_inblock_idx = section_idx - (total_sections - curr_block->n);
            return curr_node;
        }
        curr_node = curr_node->next;
    }

    return NULL;
}

Block* GetBlockBySectionIdx(BlockList* list, int section_idx, int* section_inblock_idx) {
    BlockNode* node = GetBlockNodeBySectionIdx(list, section_idx, section_inblock_idx);
    return node ? node->block : NULL;
}


Section* GetSectionByIdx(BlockList* list, int section_idx) {
    int section_inblock_idx = 0;
    Block* block = GetBlockBySectionIdx(list, section_idx, &section_inblock_idx);

    return block ? &block->sections[section_inblock_idx] : NULL;
}

typedef void (*block_fun_t)(Block* block, void* contex);

void RemoveSection(Section* section) {
    free(section->attributes);
    free(section->selectors);
    section->n_attributes = section->cap_attributes = 0;
    section->n_selectors = section->cap_selectors = 0;
}

void RemoveBlock(Block* block) {
    for (int i = 0; i < block->n; ++i) {
        RemoveSection(&block->sections[i]);
    }

    block->n = 0;
}

void RemoveBlockNode(BlockList* list, BlockNode* node) {
    if (node == list->start) {
        list->start = node->next;
        if (list->start != NULL) {
            list->start->prev = NULL;
        }
    }
    if (node == list->finish) {
        list->finish = node->prev;
        if (list->finish != NULL) {
            list->finish->next = NULL;
        }
        return;
    }
    if (node->next != NULL && node->prev != NULL) {
        node->next->prev = node->prev;
        node->prev->next = node->next;
    }
    RemoveBlock(node->block);
    free(node->block);
    free(node);
}

void RemoveBlockList(BlockList* list) {
    while (list->start) {
        RemoveBlockNode(list, list->start);
    }
}

bool RemoveSectionByIndex(BlockList* list, int section_idx) {
    int section_inblock_idx = 0;

    BlockNode* node = GetBlockNodeBySectionIdx(list, section_idx, &section_inblock_idx);

    if (!node) {
        return false;
    }

    Block* block = node->block;

    RemoveSection(&block->sections[section_inblock_idx]);

    for (int i = section_inblock_idx + 1; i < block->n; ++i) {
        block->sections[i - 1] = block->sections[i];
    }

    --block->n;
    block->sections[block->n] = Section();

    if (!block->n) {
        RemoveBlockNode(list, node);
    }

    return true;
}

bool RemoveAttributeByName(BlockList* list, int section_idx, const char* attribute_name) {
    Section* section = GetSectionByIdx(list, section_idx);

    if (!section) {
        return false;
    }

    int delete_idx = -1;

    for (int i = 0; i < section->n_attributes; ++i) {
        if (strcmp(attribute_name, section->attributes[i].name) == 0) {
            delete_idx = i;
            break;
        }
    }

    if (delete_idx == -1) {
        return false;
    }

    free(section->attributes[delete_idx].name);
    free(section->attributes[delete_idx].value);

    for (int i = delete_idx + 1; i < section->n_attributes; ++i) {
        section->attributes[i - 1] = section->attributes[i];
    }

    --section->n_attributes;

    if (!section->n_attributes) {
        RemoveSectionByIndex(list, section_idx);
    }

    return true;
}

struct CountAttributesContext {
    const char* attribute_name = NULL;
    int counter = 0;
};

struct CountSelectorsContext {
    const char* selector_name = NULL;
    int counter = 0;
};

struct SaveLastAttributeValueContext {
    const char* selector_name = NULL;
    const char* attribute_name = NULL;
    const char* attribute_value = NULL;
};

void CountAttributes(Block* block, void* vcontext) {
    CountAttributesContext* context = (CountAttributesContext*)vcontext;

    for (int i = 0; i < block->n; i++) {
        for (int j = 0; j < block->sections[i].n_attributes; j++) {
            if (strcmp(block->sections[i].attributes[j].name, context->attribute_name) == 0) {
                (context->counter)++;
            }
        }
    }
}

void CountSelectors(Block* block, void* vcontext) {
    CountSelectorsContext* context = (CountSelectorsContext*)vcontext;
    for (int i = 0; i < block->n; i++) {
        for (int j = 0; j < block->sections[i].n_selectors; j++) {
            if (strcmp(block->sections[i].selectors[j], context->selector_name) == 0) {
                (context->counter)++;
            }
        }
    }
}

void SaveLastAttributeValue(Block* block, void* vcontext) {
    SaveLastAttributeValueContext* context = (SaveLastAttributeValueContext*)vcontext;

    for (int i = 0; i < block->n; i++) {
        bool has_selector = false;

        for (int j = 0; j < block->sections[i].n_selectors; ++j) {
            if (strcmp(block->sections[i].selectors[j], context->selector_name) == 0) {
                has_selector = true;
                break;
            }
        }

        if (!has_selector) {
            continue;
        }

        for (int j = 0; j < block->sections[i].n_attributes; j++) {
            if (strcmp(block->sections[i].attributes[j].name, context->attribute_name) == 0) {
                context->attribute_value = block->sections[i].attributes[j].value;
            }
        }
    }
}

void ForeachBlock(BlockList* list, block_fun_t fun, void* context) {
    BlockNode* current_node = list->start;
    while (current_node != NULL) {
        fun(current_node->block, context);
        current_node = current_node->next;
    }
}

//? – wypisz liczbę sekcji CSS;
void PrintNumberOfSections(BlockList* list) {
    BlockNode* current_node = list->start;
    int counter = 0;
    while (current_node != NULL) {
        counter += current_node->block->n;
        current_node = current_node->next;
    }
    printf("? == %d\n", counter);
}

// i,S,? – wypisz liczbę selektorów dla sekcji nr i (numery zaczynają się od 1), jeśli nie ma
// takiego bloku pomiń;
void PrintNumberOfSelectors(BlockList* list, int section_idx) {
    Section* section = GetSectionByIdx(list, section_idx);
    if (section != NULL) {
        printf("%d,S,? == %d\n", section_idx + 1, section->n_selectors);
    }
}

// i,A,? - wypisz liczbę atrybutów dla sekcji nr i, jeśli nie ma takiego bloku lub sekcji pomiń;
void PrintNumberOfAttributes(BlockList* list, int section_idx) {
    Section* section = GetSectionByIdx(list, section_idx);
    if (section != NULL && section->n_attributes != 0) {
        printf("%d,A,? == %d\n", section_idx + 1, section->n_attributes);
    }
}

// i,S,j – wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutów zaczynają się od 1)
// jeśli nie ma sekcji lub selektora pomiń;
void PrintSelector(BlockList* list, int section_idx, int selector_idx) {
    Section* section = GetSectionByIdx(list, section_idx);
    if (section != NULL && selector_idx < section->n_selectors) {
        printf("%d,S,%d == %s\n", section_idx + 1, selector_idx + 1,
            section->selectors[selector_idx]);
    }
}

// i,A,n – wypisz dla i-tej sekcji wartość atrybutu o nazwie n, jeśli nie ma takiego pomiń;
void PrintAttributeValueForSection(BlockList* list, int section_idx, const char* attribute_name) {
    Section* section = GetSectionByIdx(list, section_idx);

    if (section == NULL) {
        return;
    }

    for (int i = 0; i < section->n_attributes; ++i) {
        if (strcmp(attribute_name, section->attributes[i].name) == 0) {
            printf("%d,A,%s == %s\n", section_idx + 1, attribute_name,
                section->attributes[i].value);
            break;
        }
    }
}

// n,A,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n.
// (W ramach pojedynczego bloku duplikaty powinny zostać usunięte na etapie wczytywania).
// Możliwe jest 0;
void PrintTotalNumberOfAttributes(BlockList* list, const char* attribute_name) {
    CountAttributesContext context;
    context.attribute_name = attribute_name;
    ForeachBlock(list, CountAttributes, &context);
    printf("%s,A,? == %d\n", attribute_name, context.counter);
}

// z,S,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień selektora z. Możliwe jest 0;
void PrintTotalNumberOfSelectors(BlockList* list, const char* selector_name) {
    CountSelectorsContext context;
    context.selector_name = selector_name;
    ForeachBlock(list, CountSelectors, &context);
    printf("%s,S,? == %d\n", selector_name, context.counter);
}

// z,E,n – wypisz wartość atrybutu o nazwie n dla selektora z, w przypadku wielu wystąpień selektora
// z bierzemy ostatnie.
// W przypadku braku pomiń;
void PrintAttributeValueForSelector(BlockList* list, const char* selector_name,
    const char* attribute_name) {
    SaveLastAttributeValueContext context;
    context.selector_name = selector_name;
    context.attribute_name = attribute_name;
    ForeachBlock(list, SaveLastAttributeValue, &context);

    if (context.attribute_value != NULL) {
        printf("%s,E,%s == %s\n", selector_name, attribute_name, context.attribute_value);
    }
}

// i,D,* - usuń całą sekcję nr i (tj. separatory+atrybuty), po poprawnym wykonaniu wypisz deleted;
void DeleteSection(BlockList* list, int section_idx) {
    if (RemoveSectionByIndex(list, section_idx)) {
        printf("%d,D,* == deleted\n", section_idx + 1);
    }
}

// i,D,n – usuń z i-tej sekcji atrybut o nazwie n, jeśli w wyniku operacji pozostaje pusta sekcja
// powinna zostać również usunięta (wraz z ew. selektorami), po poprawnym wykonaniu wypisz deleted.
void DeleteAttribute(BlockList* list, int section_idx, const char* attribute_name) {
    if (RemoveAttributeByName(list, section_idx, attribute_name)) {
        printf("%d,D,%s == deleted\n", section_idx + 1, attribute_name);
    }
}

char* AllocStr(const char* s, int n) {
    if (n == -1) {
        n = strlen(s);
    }

    char* allocated_s = (char*)calloc(n + 1, 1);
    strncpy(allocated_s, s, n);
    allocated_s[n] = '\0';
    return allocated_s;
}

char* StripStr(const char* s, int n) {
    int l = n - 1;
    int r = 0;

    for (int i = 0; i < n; ++i) {
        if (!isspace(s[i])) {
            l = i;
            break;
        }
    }

    for (int i = n - 1; i >= 0; --i) {
        if (!isspace(s[i])) {
            r = i;
            break;
        }
    }

    if (l > r) {
        return AllocStr("", -1);
    }

    return AllocStr(s + l, r - l + 1);
}

// If meets **** or ???? returns them
// Also should trim space characters(including new lines)

char* GetNextToken(char delim1, char delim2, bool* first) {
    static bool is_eof = false;

    if(is_eof) {
        return NULL;
    }

    static char buf[MAX_TOKEN_SIZE];
    int c = 0;
    int count = 0;
    int last_new_line_idx = -1;
    while ((c = getchar()) != EOF) {
        if (c == '\n') {
            last_new_line_idx = count;
        }
        buf[count++] = c;
        if (count - last_new_line_idx - 1 == 4) {
            if (strncmp(buf + last_new_line_idx + 1, "****", 4) == 0) {
                return AllocStr("****", -1);
            }
            if (strncmp(buf + last_new_line_idx + 1, "????", 4) == 0) {
                return AllocStr("????", -1);
            }
        }
        if (c == delim1 || c == delim2) {
            break;
        }
    }
    if (c == EOF) {
        is_eof = true;

        if(!count) {
            return NULL;
        }

        char* s = StripStr(buf, count);

        if(strcmp("\0", s) == 0) {
            free(s);
            return NULL;
        }

        return s;
    }
    if (first) {
        *first = (c == delim1);
    }
    --count;
    return StripStr(buf, count);
}

bool ParseCss(BlockList* list) {
    while (true) {
        bool first = false;
        Section* section = NULL;
        char* token = NULL;

        while ((token = GetNextToken(',', '{', &first)) != NULL) {
            if (strcmp(token, "****") == 0) {
                free(token);
                continue;
            }
            else if (strcmp(token, "????") == 0) {
                free(token);
                return true;
            }

            if (section == NULL) {
                section = AddSection(list);
            }

            if(strcmp(token, "\0") != 0) {
                AddSelector(section, token);
            }

            if (!first) {
                break;
            }
        }

        if (token == NULL) {
            return false;
        }

        while (true) {
            char* attribute_name = GetNextToken(':', '}', &first);

            if(attribute_name == NULL) {
                break;
            }

            if (!first) {
                free(attribute_name);
                break;
            }

            char* attribute_value = GetNextToken(';', '}', &first);

            if(attribute_value == NULL) {
                break;
            }

            AddAttribute(section, attribute_name, attribute_value);

            if (!first) {
                break;
            }
        }
    }

    return true;
}

bool IsNumber(const char* s) {
    errno = 0;
    char* end = NULL;
    strtol(s, &end, 10);
    return errno == 0 && end != NULL && *end == '\0';
}

bool ParseCommands(BlockList* list) {
    while (true) {
        bool first = false;
        char* token = NULL;
        char* tokens[3] = {NULL, NULL, NULL};
        int tok_num = 0;

        while ((token = GetNextToken(',', '\n', &first)) != NULL) {
            if (strcmp(token, "????") == 0) {
                free(token);
                continue;
            }
            else if (strcmp(token, "****") == 0) {
                free(token);
                return true;
            }

            if(strcmp(token, "\0") == 0) {
                continue;
            }

            if(tok_num < 3) {
                tokens[tok_num++] = token;
            } else {
                ++tok_num;
                free(token);
            }

            if (!first) {
                break;
            }
        }
        
        if(tok_num <= 3) {
            if (tokens[0] != NULL && strcmp(tokens[0], "?") == 0 && (tokens[1] == NULL || strcmp(tokens[1], "\0") == 0) && (tokens[2] == NULL || strcmp(tokens[2], "\0") == 0)) {
                PrintNumberOfSections(list);
            }
            else if (tok_num == 3 && tokens[0] != NULL && tokens[1] != NULL && tokens[2] != NULL) {
                if (IsNumber(tokens[0]) && strcmp(tokens[1], "S") == 0 && strcmp(tokens[2], "?") == 0) {
                    PrintNumberOfSelectors(list, atoi(tokens[0]) - 1);
                }
                else if (IsNumber(tokens[0]) && strcmp(tokens[1], "A") == 0 &&
                    strcmp(tokens[2], "?") == 0) {
                    PrintNumberOfAttributes(list, atoi(tokens[0]) - 1);
                }
                else if (strcmp(tokens[1], "S") == 0 && strcmp(tokens[2], "?") == 0) {
                    PrintTotalNumberOfSelectors(list, tokens[0]);
                }
                else if (strcmp(tokens[1], "S") == 0) {
                    PrintSelector(list, atoi(tokens[0]) - 1, atoi(tokens[2]) - 1);
                }
                else if (strcmp(tokens[1], "A") == 0 && strcmp(tokens[2], "?") == 0) {
                    PrintTotalNumberOfAttributes(list, tokens[0]);
                }
                else if (strcmp(tokens[1], "A") == 0) {
                    PrintAttributeValueForSection(list, atoi(tokens[0]) - 1, tokens[2]);
                }
                else if (strcmp(tokens[1], "E") == 0) {
                    PrintAttributeValueForSelector(list, tokens[0], tokens[2]);
                }
                else if (strcmp(tokens[1], "D") == 0 && strcmp(tokens[2], "*") == 0) {
                    DeleteSection(list, atoi(tokens[0]) - 1);
                }
                else if (strcmp(tokens[1], "D") == 0) {
                    DeleteAttribute(list, atoi(tokens[0]) - 1, tokens[2]);
                }
            }
        } else {
            tok_num = 3;
        }

        for (int i = 0; i < tok_num; ++i) {
            free(tokens[i]);
        }

        if (!token) {
            return false;
        }
    }

    return true;
}

int main() {
    BlockList list;

    while (true) {
        if (!ParseCss(&list) || !ParseCommands(&list)) {
            break;
        }
    }

    //RemoveBlockList(&list);
}