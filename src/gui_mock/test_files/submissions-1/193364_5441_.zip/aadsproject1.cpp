#include "doublelist.h"
#define NULLCH '/0'
using namespace std;

bool checkSpecialSign(char sign) {
	if (sign == ';' || sign == ':' || sign == '\n' || sign == '\t' || sign == ' ' || sign=='\r')
		return false;
	else return true;
}
void clearString(String& s) {
	if (s.StringLength() == 0) return;
	s = String();
}
void clearList(List& l) {
	if (l.head != nullptr && l.length!=0) {
		l.head = nullptr;
		l.length = 0;
	}
}
void clearBlock(Block& b) {
	if (&b != nullptr) {
		if (&b.attribute != nullptr) {
			if (&b.attribute.attId != nullptr) {
				clearList(b.attribute.attId);
			}
			if (&b.attribute.attValue != nullptr) {
				clearList(b.attribute.attValue);
			}
		}
		if (&b.selector != nullptr) {
			clearList(b.selector);
		}
	}
	return;
}
void clearBlocksArray(BlockNode& array) {
	for (int i = 0; i < T; i++) {
		clearBlock(array.blocks[i]);
	}
}
bool checkIfNumber(String s) {
	if (s.data == NULL) return false;
	for (int i = 0; s.data[i] != '\0'; i++) {
		if (s.data[i] < '0' || s.data[i]>'9') return false;
	}
	return true;
}
int stringToInt(String& s) {
	int number=0;
	for (int i = 0; s.data[i] != '\0'; i++) {
		number = number * 10 + (s.data[i] - '0');
	}
	return number;
}
void createCommand(String& com1,String& com2, String& com3,char c,int& e) {
	com1.data = NULL; com2.data = NULL; com3.data = NULL;
	com1.length = 0; com2.length = 0; com3.length = 0;
	if (c == '?') {
		com1.AddChar(c);
		c = getchar();
		return;
	}
	while (c != ',') {
		com1.AddChar(c);
		c = getchar();
	}
	if (com1.data[com1.StringLength() - 1] == ' ' || com1.data[com1.StringLength() - 1] == '\r' || com1.data[com1.StringLength() - 1] == '\t') {
		com1.data[com1.StringLength() - 1] = '\0';
	}
	c = getchar();
	while (c != ',') {
		com2.AddChar(c);
		c = getchar();
	}
	if (com2.data[com2.StringLength() - 1] == ' ' || com2.data[com1.StringLength() - 1] == '\r' || com2.data[com1.StringLength() - 1] == '\t') {
		com2.data[com2.StringLength() - 1] = '\0';
	}
	c = getchar();
	while (c != '\n' && c!='\r' && c != EOF) {
		com3.AddChar(c);
		c = getchar();
	}
	if (com3.data[com3.StringLength() - 1] == ' ' || com3.data[com3.StringLength() - 1] == '\r' || com3.data[com3.StringLength() - 1] == '\t') {
		com3.data[com3.StringLength() - 1] = '\0';
	}
	if (c == EOF) e = 0;
}

void C1(DoubleList list, int index,String s1,String s2,String s3) { //liczba selektorów sekcji index
	if (index > list.blockcounter) return;
	Block b = list[index-1];
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << b.selector.length << endl;
}

void C2(DoubleList list, int index, String s1, String s2, String s3) { //liczba atrybutów sekcji index
	if (index > list.blockcounter) return;
	Block b = list[index-1];
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << b.attribute.attId.length<< endl;
}

void C3(DoubleList list,int bindex,int sindex, String s1, String s2, String s3) { // sindex selektor bindex sekcji
	if (bindex > list.blockcounter) return;
	if (sindex > list[bindex-1].selector.length) return;
	Block b = list[bindex - 1];
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << b.selector[sindex-1] << endl;
}

void C4(DoubleList list, int bindex, String n, String s1, String s2, String s3) { // wartosc atrybutu o nazwie n w bindex sekcji
	Block b = list[bindex-1];
	if (bindex > list.blockcounter) return;
	int aindex = b.attribute.attId[n.data]; //szuka w liście nazw atrybutow tego bloku elementu o nazwie n i zwraca jego indeks 
	if (aindex > b.attribute.attId.length || aindex==-1) return;
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	String wtf = b.attribute.attValue[aindex];
	cout << b.attribute.attValue[aindex].data << endl;
} //change it to give the last value!!!!!!!!!!1

void C5(DoubleList list, String n, String s1, String s2, String s3) { // liczba atrybutów o nazwie n
	int occur = 0;
	for (int i = 0; i < list.blockcounter; i++) {
		bool duplicate = false;
		for (int j = 0; j < list[i].attribute.attId.length; j++) {
			if (list[i].attribute.attId[j].data != NULL && n.CheckEqual(list[i].attribute.attId[j].data)) {
				if (duplicate) {
					for (int k = 0; k < j; k++) {
						if (list[i].attribute.attId[k].data != NULL && n.CheckEqual(list[i].attribute.attId[k].data)) {
							clearString(list[i].attribute.attId[k]);
							clearString(list[i].attribute.attValue[k]);
						}
					}
				}
				else duplicate = true;
			}
		}
	}
	for (int i = 0; i < list.blockcounter; i++) {
		for (int j = 0; j < list[i].attribute.attId.length; j++) {
			if (list[i].attribute.attId[j].data != NULL && n.CheckEqual(list[i].attribute.attId[j].data)) {
				occur++;
			}
		}
	}
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << occur << endl;
}

void C6(DoubleList list, String z, String s1, String s2, String s3) { // liczba selektorów z
	int occur = 0;
	for (int i = 0; i < list.blockcounter; i++) {
		for (int j = 0; j < list[i].selector.length; j++) {
			if (list[i].selector[j].data != NULL && z.CheckEqual(list[i].selector[j].data)) {
				occur++;
			}
		}
	}
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << occur << endl;
}

void C7(DoubleList list,String z,String n, String s1, String s2, String s3) { // wartość atrybutu o nazwie n dla selektora o nazwie z
	int blockIndex = -1;
	int attributeIndex = -1;

	for (int i = list.blockcounter ; i >= 0; i--) {
		for (int j = 0; j < list[i].selector.length; j++) {
			String selector = list[i].selector[j];
			if (selector.data != nullptr && z.CheckEqual(selector.data)) {
				for (int k = 0; k < list[i].attribute.attId.length; k++) {
					String attribute = list[i].attribute.attId[k];
					if (attribute.data != nullptr && n.CheckEqual(attribute.data)) {
						blockIndex = i;
						attributeIndex = k;
					}
				}
			}
		}
		if (blockIndex != -1 && attributeIndex != -1) {
			break;
		}
	}

	if (blockIndex == -1 || attributeIndex == -1) {
		return;
	}

	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << list[blockIndex].attribute.attValue[attributeIndex].data << endl;
}

void C8(DoubleList& list,int index, String s1, String s2, String s3) { // usuwa sekcje index
	if (index > list.blockcounter) return;
	//if(list[index-1]!=NULL)
	clearBlock(list[index-1]);
	list.blockcounter--;
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << "deleted" << endl;
}

void C9(DoubleList& list, int index, String n, String s1, String s2, String s3) { //usuwa atrybut o nazwie n z sekcji index
	if (index > list.blockcounter) return;
	bool empty = true;
	int a = list[index-1].attribute.attId[n.data]; //indeks miejsca w liście gdzie w tym bloku jest to słowo
	if (a > list[index - 1].attribute.attId.length) return;
	clearString(list[index-1].attribute.attId[a]);//czyści te liste nazw
	list[index - 1].attribute.attId[a].length--;
	clearString(list[index-1].attribute.attValue[a]);//czysci te liste wartosci
	list[index - 1].attribute.attValue[a].length--;
	for (int i = 0; i < list[index-1].attribute.attId.length; i++) {
		if (list[index-1].attribute.attId[i].data != NULL) {
			empty = false;
			break;
		}
	}
	if (empty == true) {
		clearBlock(list[index-1]);
		list.blockcounter--;
	}
	cout << s1.data << "," << s2.data << "," << s3.data << " == ";
	cout << "deleted" << endl;
}
void C10(DoubleList& list) {
	cout << "? == ";
	cout << list.blockcounter << endl;
}
bool checkDuplicate(List list, String name) {
	int dup = 0;
	for (int i = 0; i < list.length; i++) {
		if (list[i].CheckEqual(name.data)) {
			dup++;
		}
	}
	if (dup > 1) return true;
	else return false;
}

 


int main() {
	String string;
	String com1, com2, com3;
	List AttIds, AttVals, Selectors;
	Attribute Attributes = { AttIds,AttVals };
	Block block = { Attributes, Selectors };
	BlockNode blocknode;
	blocknode.next = nullptr;
	blocknode.prev = nullptr;
	DoubleList DLL;
	int i = 0;
	int j = 0;
	int k = 0;
	int sectionCounter = 0;
	int end = 1;


	char ch = getchar();
	while (ch != EOF) { //powtarzaj do końca inputu
		while (ch != '?') { //powtarzaj poki nie natrafimy na znak zapytania 
			if (checkSpecialSign(ch)) { //sprawdz czy to normalny znak, jezeli tak to tworzymy selektor
				while (ch != '{') {
					while (ch != ',' && ch!='\n' && ch!='{' && ch!='\t' && ch!='\r') { //dodajemy ch do stringa poki nie natrafimy na przecinek
						string.AddChar(ch);
						ch = getchar();
					}
					if(ch==',')ch = getchar(); //mamy przecinek, więc aby nastepny selektor sie dobrze tworzyl bierzemy nastepne ch
					if (string.data != NULL) {
						if (string.StringLength() > 0 && string.data[string.StringLength() - 1] == ' ') {
							string.data[string.StringLength() - 1] = '\0';
						}
						Selectors.AddNodeLast(&Selectors.head, new String(string)); //do obecnej listy selektorów dodajemy utworzonego stringa
						Selectors.length++;
						block.selector = Selectors; //do obecnej struktury blok przypisujemy obecną liste selektorów
						clearString(string);
					}
					if(ch!='{')ch = getchar(); //koniec selektora więc lecimy dalej
				}
				if (ch != '{')ch = getchar();
				while (ch != '}') {
					while (ch != ':') {
						string.AddChar(ch);
						ch = getchar();
					}if (string.StringLength()>0 && string.data[string.StringLength() - 1] == ' ') {
						string.data[string.StringLength() - 1] = '\0';
					}
					string.length = string.StringLength();
					AttIds.AddNodeLast(&AttIds.head, new String(string)); //do obecnej listy nazw atrybutów dodajemy utworzonego stringa
					AttIds.length++;
					if (checkDuplicate(AttIds, string)) {
						for (int a = 0; a < AttIds.length; a++) {
							if (AttIds[a].CheckEqual(string.data)) {
								AttIds[a].data = NULL;
								AttVals[a].data = NULL;
								AttIds[a-1].length = 0;
								AttVals[a-1].length = 0;
								AttIds.length--;
								AttVals.length--;
								break;
							}
						}
					}
					block.attribute.attId = AttIds; //do obecnej struktury blok przypisujemy liste nazw
					clearString(string);
					ch = getchar();
					while (ch == ' ' || ch == '\r' || ch == '\t')ch = getchar();
					while (ch != ';') {
						string.AddChar(ch);
						ch = getchar();
					}
					if (string.StringLength() > 0 && string.data[string.StringLength() - 1] == ' ') {
						string.data[string.StringLength() - 1] = '\0';
					}
					string.length = string.StringLength();
					AttVals.AddNodeLast(&AttVals.head, new String(string)); //do obecnej listy wartości atrybutów dodajemy utworzonego stringa
					AttVals.length++;
					block.attribute.attValue = AttVals; ////do obecnej struktury blok przypisujemy liste wartości
					clearString(string);
					ch = getchar();
					while (ch == '\n' || ch == '\t') ch = getchar(); //jeżeli mamy endline lub tabulator to sprawdzamy dalej 
				}
				if (DLL.AddToArray(DLL.head, block, i) == true) { //są miejsca w tablicy
					clearBlock(block);
					i++;
				}
				else { //nie ma miejsc w tablicy
					i = 0; //licznik się zeruje
					blocknode.blocks[i] = block;
					DLL.AddBlockLast(&DLL.head,&DLL.tail, blocknode.blocks); //do Big Listy dodajemy obecnego BlockNode'a
					clearBlocksArray(blocknode); //czyścimy BlockNode'a
					blocknode.blocks[i] = block; //do czystego BlockNode'a w i-tej komórce przypisujemy powstały blok 
					i++; //lecimy
					clearBlock(block);

				}
				clearList(AttIds); clearList(AttVals); clearList(Selectors); //czyścimy listy żeby ich dalej używać
				ch = getchar();
			}
			while (ch == '\t' || ch == '\n' || ch == ' ' || ch=='\r') ch = getchar();
		}
		clearString(string);
		j=1;
		ch = getchar();
		while (ch == '?') {
			ch = getchar();
			j++;
		}
		while (ch != '*' && ch != EOF) {
			while (ch == '\n' || ch == '\r') ch = getchar();
			if (ch == '*') {
				k++;
				break;
			}
			if (j == 4) {
				k = 0;
				createCommand(com1, com2, com3, ch,end);
				if (com1.data == NULL) {
					break;
				}
				else if (com1.data[0] == '?') {
					C10(DLL);
				}
				else if (checkIfNumber(com1)) {
					if (com2.data[0] == 'S') {
						if (com3.data[0] == '?')
						{
							C1(DLL, stringToInt(com1), com1, com2, com3);
						}
						else if (checkIfNumber(com3)) {

							C3(DLL, stringToInt(com1), stringToInt(com3), com1, com2, com3);
						}
					}
					else if (com2.data[0] == 'A') {
						if (com3.data[0] == '?') {
							C2(DLL, stringToInt(com1), com1, com2, com3);
						}
						else if (com3.data != NULL) {
							C4(DLL, stringToInt(com1), com3, com1, com2, com3);
						}
					}
					else if (com2.data[0] == 'D') {
						if (com3.data[0] == '*') {
							C8(DLL, stringToInt(com1), com1, com2, com3);
						}
						else if (com3.data != NULL) {
							C9(DLL, stringToInt(com1), com3, com1, com2, com3);
						}
					}
				}
				else if (com1.data != NULL) {
					if (com2.data[0] == 'A') {
						if (com3.data[0] == '?') {
							C5(DLL, com1, com1, com2, com3);
						}
					}
					else if (com2.data[0] == 'S') {
						if (com3.data[0] == '?') {
							C6(DLL, com1, com1, com2, com3);
						}
					}
					else if (com2.data[0] == 'E') {
						if (com3.data != NULL) {
							C7(DLL, com1, com3, com1, com2, com3);
						}
					}
				}
				else {
					if (ch == EOF) return 0;
					else break;
				}
			}
		ch = getchar();
		if (ch == EOF) return 0;
		if (end==0) return 0;
		}
		ch = getchar();
		while (ch == '*') {
			ch = getchar();
			k++;
		}
		if (k == 4) {
			j = 0;
		}
	}
	return 0;
}
