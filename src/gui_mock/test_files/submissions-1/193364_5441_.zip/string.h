#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

class String {
public:
	char* data;
	int length;
	friend std::ostream& operator<<(std::ostream& os, String s);
	String();
	int StringLength();
	void AddChar(char new_c);
	bool CheckEqual(char* b);
	~String();
};



