#include "doublelist.h"

using namespace std;

DoubleList::DoubleList() {
	head = nullptr;
	tail = nullptr;
	blockcounter = 0;
}

int DoubleList::DoubleListLength(BlockNode* head) {
	if (head == nullptr) return 0;
	int i = 0;
	BlockNode* tmp = head;
	while (tmp != NULL) //jeżeli tmp nie jest pusty to przeskakujemy do następnego i zwiększamy licznik
	{
		i++;
		tmp = tmp->next;
	}
	return i;
}

void DoubleList::AddBlockLast(BlockNode** head, BlockNode** tail, Block blocks[T]) {
	BlockNode* new_block = new BlockNode(); //creates a new BlockNode object using the new operator and assigns its address to the new_block pointer.
	for (int i = 0; i < T; i++)
	{
		new_block->blocks[i] = blocks[i]; //copies the contents of the block array into the block array of the new BlockNode.
	}	
	new_block->next = nullptr;
	BlockNode* tmp = *head;
	if (*head == NULL)
	{
		new_block->prev = nullptr;
		*head = new_block;
	}
	else
	{
		while (tmp->next != NULL)
		{
			tmp = tmp->next;
		}
		tmp->next = new_block;
		new_block->prev = tmp;
		*tail = new_block;
	}

	blockcounter++;
}

bool DoubleList::AddToArray(BlockNode* head,Block block,int count) {
	BlockNode* tmp = head;
	if (tmp == nullptr) return false;
	while (tmp->next!= NULL) {
		tmp = tmp->next;
	}
	if (count < T) {
		tmp->blocks[count] = block;
		blockcounter++;
		return true;
	}
	else return false;
}
Block& DoubleList::operator[](int index) {
	int blockIndex = index / T;
	int elementIndex = index % T;

	BlockNode* tmp = head;
	for (int i = 0; i < blockIndex; i++) {
		tmp = tmp->next;
	}

	Block* blocks = tmp->blocks;
	for (int i = 0; i < T; i++) {
		if (blocks[i].attribute.attId.ListLength(blocks[i].attribute.attId.head) == 0) {
			continue;
		}

		if (elementIndex == 0) {
			return blocks[i];
		}
		elementIndex--;
	}
	Block def;
	return def;
}


DoubleList::~DoubleList() {};
