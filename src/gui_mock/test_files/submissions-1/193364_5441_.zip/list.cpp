﻿#include "List.h"

List::List() {
	head = nullptr;
	length = 0;
}

int List::ListLength(Node* head) {
	if (head == nullptr) return 0;
	int i = 1;
	Node* tmp = head;
	while (tmp->next != NULL) //jeżeli tmp nie jest pusty to przeskakujemy do następnego i zwiększamy licznik
	{
		i++;
		tmp = tmp->next;
	}
	return i;
}

void List::AddNodeLast(Node** head,String* datas) {
	Node* new_node = new Node(); //alockacja pamięci na nowego node'a
	Node* tmp = *head; //wskaźnik do pierwszego elementu
	new_node->data = *datas; 
	new_node->next = NULL;
	if (*head == NULL) // jeżeli nie ma pierwszego elementu to new_node sie nim staje
	{
		*head = new_node;
	}
	else
	{
		while (tmp->next != NULL) //jeżeli następny nie jest pusty to przypisujemy obecnemu wartośc nastepnego
		{
			tmp = tmp->next;
		}
		tmp->next = new_node; //nastepny się staje nowym
	}
}

void List::PrintList(Node* head) {
	if (head == nullptr) std:: cout << "empty list";
	Node* tmp = head;
	while (tmp != nullptr)
	{
		std::cout << tmp->data<<" ";
		tmp = tmp->next;
	}
}

void List::CreateStrings(String str,List* lis, char c) {
	while (c != '\n') {
		if (c != ' ') {
			str.AddChar(c);
		}
		else {
			lis->AddNodeLast(&lis->head, new String(str));
			str.data = NULL;
			str.length = 0;
		}
		c = getchar();
	}
	lis->AddNodeLast(&lis->head, new String(str));
}
String& List::operator[](int index) { //should ommit empty ones
	Node* tmp = head;
	int i = 0;
	while (tmp != NULL) {
		// Skip over empty nodes
		while (tmp != NULL && tmp->data.StringLength() == 0) {
			tmp = tmp->next;
		}
		// Check if we reached the end of the list
		if (tmp == NULL) {
			break;
		}
		if (i == index) {
			return tmp->data;
		}
		i++;
		tmp = tmp->next;
	}
	static String def;
	return def;
}
int& List::operator[](char* name) {
	Node* tmp = head;
	int i = 0;
	while (tmp != NULL) {
		if (tmp->data.data!=NULL && tmp->data.CheckEqual(name)) {
			return i;
		}
		if (tmp->data.data != NULL) {
			i++;
		}
		tmp = tmp->next;
	}
	static int def = -1;
	return def;
}

List::~List(){}

