#pragma once
#include "list.h"
#define T 8

struct Attribute {
	List attId;
	List attValue;
};

struct Block {
	Attribute attribute;
	List selector;	
};

struct BlockNode {
	Block blocks[T];
	BlockNode* next;
	BlockNode* prev;
};

class DoubleList {
public:
	BlockNode* head;
	BlockNode* tail;
	int blockcounter;

	DoubleList();
	int DoubleListLength(BlockNode* head);
	void AddBlockLast(BlockNode** head, BlockNode** tail,Block blocks[T]);
	bool AddToArray(BlockNode* head, Block block,int count);
	Block& operator[](int index); //blok o danym indeksie

	~DoubleList();
	
};