﻿#include "String.h"
#include <cstring>
#define NULLCHAR (char)(0)
#define MORESPACE 5

String::String() {
	this->data = nullptr;
	this->length = 0;
}
int String::StringLength() {
	if (data == nullptr) return 0;
	else return std::strlen(data);
}
void String::AddChar(char new_c) {
	if (new_c != '\n' && new_c != '\t' && new_c != '{' && new_c != '}' && new_c != '\r' && new_c != ';') {
		if (length == 0 && new_c!=' '&& new_c!='\r' && new_c!='\t') {
			length = MORESPACE;
			data = (char*)malloc(sizeof(char) * (length + 1));
			if (data == nullptr) {
				return;
			}
			data[0] = new_c;
			data[1] = '\0'; // ensure that the string is null-terminated
		}
		else if (length < StringLength() + 1) {
			length = length + MORESPACE;
			char* new_data = (char*)realloc(data, sizeof(char) * length+1);
			if (new_data == NULL) {
				free(data);
				return; // failed to reallocate memory, return without modifying the string
			}
			data = new_data;
			data[length - MORESPACE] = new_c;
			data[length - MORESPACE + 1] = '\0'; // ensure that the string is null-terminated
		}
		else if (StringLength()>0) {
			data[StringLength() + 1] = '\0'; // ensure that the string is null-terminated
			data[StringLength()] = new_c;
		}
	}
}
bool String::CheckEqual(char* b) {
	int blen = 0;
	if (b == NULL) return false;
	for (int i = 0; b[i] != '\0'; i++) {
		blen++;
	}
	if (StringLength() != blen) return false;
		for (int i = 0; i < StringLength(); i++) {
			if (data[i] != b[i]) return false;
		}
		return true;
}

std::ostream& operator<<(std::ostream& os, String s) {
	if (s.data == nullptr) { 
		os << "NULL"; 
		return os;
	}
	for (int i = 0; s.data[i]!=NULLCHAR; i++)
		os << s.data[i];
	return os;
}

String::~String() {
//	free(data);
}
