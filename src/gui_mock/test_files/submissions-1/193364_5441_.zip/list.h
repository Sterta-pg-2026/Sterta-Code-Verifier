#pragma once
#include "string.h"

struct Node {
	String data;
	Node* next;
};

class List {
public:
	Node* head;
	int length;
	List();
	int ListLength(Node* head);
	void AddNodeLast(Node** head, String* datas);
	void PrintList(Node* head);
	void CreateStrings(String str, List* lis,char c);
	String& operator[](int index); //element listy o danym indeksie
	int& operator[](char* name);//element listy o danej nazwie

	~List();
};
