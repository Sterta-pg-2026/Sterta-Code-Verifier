#include "listatribute.h"

using namespace std;

NodeAtribute::NodeAtribute(int numberOfElementsInNode) {
	this->numberOfElementsInNode = numberOfElementsInNode;
	element = new Atribute[numberOfElementsInNode];
	numberOfElements = 0;
	isTaken = new bool[numberOfElementsInNode];
	for (int i = 0; i < numberOfElementsInNode; i++) {
		isTaken[i] = false;
	}
	preNode = nullptr;
	nextNode = nullptr;
}

//zwraca najni�szy wolny elemnet w tablicy, nie zwraca elemnet�w kt�r� maj� nad sob� wpisan� warto��
int NodeAtribute::GetEmpty() {
	int returnElement = -1;
	for (int i = numberOfElementsInNode-1; i >=0; i--) {
		if (isTaken[i] == false) {
			returnElement = i;
		}
		else {
			return returnElement;
		}
	}
	return returnElement;
}
int NodeAtribute::NumberOfTaken() {
	int numberOfTaken = 0;
	for (int i = 0; i < numberOfElementsInNode; i++) {
		if (isTaken[i] == true)
			numberOfTaken++;
	}
	return numberOfTaken;
}
int NodeAtribute::GetLast() {
	for (int i = numberOfElementsInNode - 1; i >= 0; i--) {
		if (isTaken[i] == true) {
			return i;
		}
	}
	return -1;
}



ListAtribute::ListAtribute() : ListAtribute(17) {}

ListAtribute::ListAtribute(int n) {
	start = nullptr;
	end = nullptr;
	numberOfElementsInNode = n;
	numberOfElemetns = 0;
}
void ListAtribute::Append() {
	if (end == nullptr || end->GetEmpty() != -1) {
		NodeAtribute* newNode = new NodeAtribute(numberOfElementsInNode);
		newNode->nextNode = nullptr;
		if (end == nullptr) {
			start = newNode;
			newNode->preNode = nullptr;
		}
		else {
			end->nextNode = newNode;
			newNode->preNode = end;
		}
		end = newNode;
	}
	int emptyElement = end->GetEmpty();
	end->isTaken[emptyElement] = true;
	end->numberOfElements++;
	numberOfElemetns++;
}
void ListAtribute::Append(Atribute& content) {
	this->Append();
	GetLast() = content;
}

Atribute& ListAtribute::GetElement(int n) {
	int index = 0;
	NodeAtribute* currentNode = start;
	while (currentNode != nullptr) {
		if (index + currentNode->numberOfElements < n) {

			index += currentNode->numberOfElements;
		}
		else {
			for (int i = 0; i < numberOfElementsInNode; i++) {
				if (currentNode->isTaken[i] == true) {
					if (index == n) {
						return currentNode->element[i];
					}
					else {
						index++;
					}
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
	Append();
	return GetLast();
}
void ListAtribute::UnsetElemnet(int n) {
	int index = 0;
	NodeAtribute* currentNode = start;
	while (currentNode != nullptr) {
		for (int i = 0; i < numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true) {
				if (index == n) {
					//zerowanie elemnetu
					currentNode->isTaken[i] = false;
					currentNode->numberOfElements--;
					numberOfElemetns--;
					currentNode->element[i].Name = "";
					currentNode->element[i].Value = "";
				//gdy w�ze� jest pusty, to w�ze� jest usuwany
					if (currentNode->NumberOfTaken() == 0) {
						if (currentNode->nextNode != nullptr) {
							currentNode->nextNode->preNode = currentNode->preNode;
						}
						else {
							end = currentNode->preNode;
						}
						if (currentNode->preNode != nullptr) {
							currentNode->preNode->nextNode = currentNode->nextNode;
						}
						else {
							start = currentNode->nextNode;
						}
						delete currentNode;
						return;
					}
				}
				else {
					index++;
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
}
bool ListAtribute::UnsetElemnet(StringMy& AtributeName) {
	NodeAtribute* currentNode = start;
	while (currentNode != nullptr) {
		for (int i = 0; i < numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true) {
				if (areEqual(currentNode->element[i].Name, AtributeName)) {
					currentNode->isTaken[i] = false;
					numberOfElemetns--;
					currentNode->element[i].Name = "";
					currentNode->element[i].Value = "";

					if (currentNode->NumberOfTaken() == 0) {
						if (currentNode->nextNode != nullptr) {
							currentNode->nextNode->preNode = currentNode->preNode;
						}
						else {
							end = currentNode->preNode;
						}
						if (currentNode->preNode != nullptr) {
							currentNode->preNode->nextNode = currentNode->nextNode;
						}
						else {
							start = currentNode->nextNode;
						}
						delete currentNode;
						return true;
					}
					return true;
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
	return false;
}
Atribute& ListAtribute::GetLast() {
	return end->element[end->GetLast()];
}

int ListAtribute::NumberOfElemnets() {
	return numberOfElemetns;
}
NodeAtribute* ListAtribute::GetEnd() {
	return end;
}
void ListAtribute::Destruct() {
	if (start != nullptr) {
		NodeAtribute* currentNode = start;
		while (currentNode->nextNode != nullptr) {
			currentNode = currentNode->nextNode;
			delete currentNode->preNode;
		}
		delete currentNode;
	}
	numberOfElemetns = 0;
	start = nullptr;
	end = nullptr;
}

ListAtribute::~ListAtribute() {
	Destruct();
}
