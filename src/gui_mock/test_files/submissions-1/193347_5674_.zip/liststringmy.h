#pragma once
#include "stringmy.h"
#include <iostream>

using namespace std;

class NodeStringMy {
public:
	NodeStringMy* preNode;
	NodeStringMy* nextNode;
	int numberOfElementsInNode;
	int numberOfElements;
	StringMy* element;
	bool* isTaken;

	NodeStringMy(int numberOfElementsInNode);
	int GetEmpty();
	int NumberOfTaken();
	int GetLast();
};

class ListStringMy {
	NodeStringMy* start, * end;
	int numberOfElementsInNode, numberOfElemetns;
public:
	ListStringMy();
	ListStringMy(int n);
	void Append(StringMy& content);
	void Append();
	StringMy& GetElement(int n);
	void UnsetElemnet(int n);
	StringMy& GetLast();
	int NumberOfElemnets();
	NodeStringMy* GetEnd();
	//T* GetEmptyElement();
	void Destruct();
	~ListStringMy();
};