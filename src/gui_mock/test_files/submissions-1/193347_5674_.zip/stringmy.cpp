#include "stringmy.h"
#include <stdio.h>

#define SCAN_BUFFOR_SIZE 16

#define LF 10
#define CR 13
#define TAB 9
#define SPACE 32

StringMy::StringMy(const char* other):content(nullptr), lenght(0) {
	this->Assign(other);
}
StringMy::StringMy() :content(nullptr), lenght(0) {
	this->Assign("");
}

StringMy::StringMy(const StringMy& other):content(nullptr), lenght(0) {

	this->Assign(other);
}
void StringMy::Assign(const char* other) {
	if (other != nullptr &&other!=content) {
		if (content != nullptr) {
			delete[] content;
			lenght = 0;
		}
		lenght = strlen(other);
		content = new char[lenght + 1];
		strcpy_s(content, lenght + 1, other);
	}
}

void StringMy::Assign(const StringMy& other) {
	if (this != &other) {
		this->Assign(other.content);
	}
}
void StringMy::Add(StringMy& other) {
	this->Add(other.content);
}
void StringMy::Add(const char* other) {
	if (other != nullptr) {
		lenght = strlen(other) + lenght;
		char* sum = new char[lenght + 1];
		strcpy_s(sum, lenght +1, content);
		strcat_s(sum, lenght +1, other);
		delete[] content;
		content = sum;
	}
}
void StringMy::Print() {
	cout << content;
}
bool inChars(char sign, const char* chars) {
	for (int i = 0; chars[i] != '\0'; i++) {
		if (sign == chars[i])
			return true;
	}
	return false;
}

char StringMy::Scan(const char *endingSigns, const char* ignoredSigns) {
	char buffor[SCAN_BUFFOR_SIZE];
	this->Assign("");
	int index = 0;

	char first;
	do {
		first = getchar();
		if (first==EOF)
			return EOF;
	} while (inChars(first, ignoredSigns) == true);
	
	if (inChars(first, endingSigns) == true) {
		return first;
	}
	
	buffor[0] = first;
	index++;

	buffor[index] = getchar();
	while ( inChars(buffor[index], endingSigns) == false) {
		if (buffor[index] == EOF)
			return EOF;
		index++;
		if (index == SCAN_BUFFOR_SIZE - 1) {
			buffor[index] = '\0';

			this->Add(buffor);
			index = 0;
		}	
		buffor[index] = getchar();
	}
	char returnSign = buffor[index];
	buffor[index] = '\0';
	this->Add(buffor);
	return returnSign;
}
void StringMy::DeleteEndingWhite() {
	StringMy Temp(*this);
	int index = Temp.lenght-1;
	while (Temp.content[index] == SPACE ||
		Temp.content[index] == LF ||
		Temp.content[index] == TAB ||
		Temp.content[index] == CR) {
		index--;
	}
	Temp.content[index + 1] = '\0';
	this->Assign(Temp);
}
char* StringMy::GetContent() {
	return content;
}


StringMy& StringMy::operator=(const StringMy& other) {
	this->Assign(other.content);
	return *this;
}
StringMy& StringMy::operator=(const char* newContent) {
	this->Assign(newContent);
	return *this;
}

ostream& operator<<(ostream& ostr, const StringMy& other) {
	ostr << other.content;
	return ostr;
}

StringMy::~StringMy() {
	delete[] content;
}

void zeroBuffor(char *buffor, int buffSize) {
	for (int i = 0; i < buffSize; i++) {
		buffor[i] = '\0';
	}
}
bool areEqual(const StringMy& first, const StringMy& second) {
	if (strcmp(first.content, second.content) == 0)
		return true;
	else
		return false;
}

bool areEqual(const StringMy& first, const char* second){
	if (strcmp(first.content, second) == 0)
		return true;
	else
		return false;
}
