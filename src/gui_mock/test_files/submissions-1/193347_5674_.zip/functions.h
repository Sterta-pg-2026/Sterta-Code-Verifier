#pragma once
#include "stringmy.h"
#include "liststringmy.h"
#include "listatribute.h"
#include "listsection.h"

#include <iostream>

bool inSelectors(ListStringMy& Selectors, StringMy& Temp);

StringMy* AtributeAppeard(ListAtribute& Atributes, StringMy& AtributeName); //sprawdza, czy atrybut si pojawi, jeli tak to zwraca wskanik na jego warto

StringMy numberOfSections(ListSection& CSS);

StringMy intToString(int number);

StringMy numberOfSections(ListSection& CSS);

StringMy numberOfSeletors(ListSection& CSS, int i);

StringMy getSelector(ListSection& CSS, int numberOfSection, int numberOfSelector);

StringMy numberOfSpecSelector(ListSection& CSS, StringMy& Name);

StringMy numberOfAtributes(ListSection& CSS, int i);

StringMy numberOfSpecAtribut(ListSection& CSS, StringMy& Name);

StringMy valueOfAtributeForSection(ListSection& CSS, StringMy& Name, int NumberOfSection);

StringMy valueOfAtributeForSelector(ListSection& CSS, StringMy& AtributeName, StringMy& SelectorName);

StringMy deleteSection(ListSection& CSS, int numberOfSection);

StringMy deleteAtribute(ListSection& CSS, int numberOfSection, StringMy AtributeName);

void programOutput(StringMy& Beggining, StringMy& Middle, StringMy& End, StringMy& content); //tworzy wyjcie na podstawie komunikatu od funkcji wywoanych komendami
void programOutput(StringMy& Beggining, StringMy& content);
