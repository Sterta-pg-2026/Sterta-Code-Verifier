#include "listsection.h"

using namespace std;

NodeSection::NodeSection(int numberOfElementsInNode) {
	this->numberOfElementsInNode = numberOfElementsInNode;
	numberOfElement = 0;
	element = new Section[numberOfElementsInNode];
	isTaken = new bool[numberOfElementsInNode];
	for (int i = 0; i < numberOfElementsInNode; i++) {
		isTaken[i] = false;
	}
	preNode = nullptr;
	nextNode = nullptr;
}

int NodeSection::GetEmpty() {
		int returnElement = -1;
		for (int i = numberOfElementsInNode - 1; i >= 0; i--) {
			if (isTaken[i] == false) {
				returnElement = i;
			}
			else {
				return returnElement;
			}
		}
		return returnElement;
}
int NodeSection::NumberOfTaken() {
	int numberOfTaken = 0;
	for (int i = 0; i < numberOfElementsInNode; i++) {
		if (isTaken[i] == true)
			numberOfTaken++;
	}
	return numberOfTaken;
}
int NodeSection::GetLast() {
	for (int i = numberOfElementsInNode - 1; i >= 0; i--) {
		if (isTaken[i] == true) {
			return i;
		}
	}
	return -1;
}



ListSection::ListSection() : ListSection(8) {}

ListSection::ListSection(int n) {
	start = nullptr;
	end = nullptr;
	numberOfElementsInNode = n;
	numberOfElemetns = 0;
}
void ListSection::Append() {
	if (end == nullptr || end->GetEmpty() != -1) {
		NodeSection* newNode = new NodeSection(numberOfElementsInNode);
		newNode->nextNode = nullptr;
		if (end == nullptr) {
			start = newNode;
			newNode->preNode = nullptr;
		}
		else {
			end->nextNode = newNode;
			newNode->preNode = end;
		}
		end = newNode;
	}
	int emptyElement = end->GetEmpty();
	//end->element[emptyElement] = content;
	end->isTaken[emptyElement] = true;
	end->numberOfElement++;
	numberOfElemetns++;
}
void ListSection::Append(Section& content) {
	this->Append();
	GetLast() = content;
}


Section& ListSection::GetElement(int n) {
	int index = 0;
	NodeSection* currentNode = start;

	while (currentNode != nullptr) {
		if (index + currentNode->numberOfElement < n) {

			index += currentNode->numberOfElement;
		}
		else {
			for (int i = 0; i < numberOfElementsInNode; i++) {
				if (currentNode->isTaken[i] == true) {
					if (index == n) {
						return currentNode->element[i];
					}
					else {
						index++;
					}
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
	Append();
	return GetLast();
}
void ListSection::UnsetElemnet(int n) {
	int index = 0;
	NodeSection* currentNode = start;
	while (currentNode != nullptr) {
		for (int i = 0; i < numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true) {
				if (index == n) {
					currentNode->isTaken[i] = false;
					currentNode->numberOfElement--;
					numberOfElemetns--;
					currentNode->element[i].GetAtributes().Destruct();
					currentNode->element[i].GetSelectors().Destruct();

					if (currentNode->NumberOfTaken() == 0) {
						if (currentNode->nextNode != nullptr) {
							currentNode->nextNode->preNode = currentNode->preNode;
						}
						else {
							end = currentNode->preNode;
						}
						if (currentNode->preNode != nullptr) {
							currentNode->preNode->nextNode = currentNode->nextNode;
						}
						else {
							start = currentNode->nextNode;
						}
						delete currentNode;
						return;
					}
				}
				else {
					index++;
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
}
Section& ListSection::GetLast() {
	return end->element[end->GetLast()];
}

int ListSection::NumberOfElemnets() {
	return numberOfElemetns;
}
NodeSection* ListSection::GetEnd() {
	return end;
}

ListSection::~ListSection() {
	if (start != nullptr) {
		NodeSection* currentNode = start;
		while (currentNode->nextNode != nullptr) {
			currentNode = currentNode->nextNode;
			delete currentNode->preNode;
		}
		delete currentNode;
	}
}




ListStringMy& Section::GetSelectors() {
	return Selectors;
}
ListAtribute& Section::GetAtributes() {
	return Atributes;
}