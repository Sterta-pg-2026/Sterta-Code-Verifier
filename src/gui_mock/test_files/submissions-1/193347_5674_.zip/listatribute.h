#pragma once
#include "stringmy.h"
#include <iostream>

using namespace std;

class Atribute {
public:
	StringMy Name;
	StringMy Value;
};

class NodeAtribute {
public:
	NodeAtribute* preNode;
	NodeAtribute* nextNode;
	int numberOfElementsInNode;
	int numberOfElements;
	Atribute* element;
	bool* isTaken;

	NodeAtribute(int numberOfElementsInNode);
	int GetEmpty();
	int NumberOfTaken();
	int GetLast();
};

class ListAtribute {
	NodeAtribute* start, * end;
	int numberOfElementsInNode, numberOfElemetns;
public:
	ListAtribute();
	ListAtribute(int n);
	void Append(Atribute& content);
	void Append();
	Atribute& GetElement(int n);
	void UnsetElemnet(int n);
	bool UnsetElemnet(StringMy& AtributeName);

	Atribute& GetLast();
	int NumberOfElemnets();
	NodeAtribute* GetEnd();
	void Destruct();
	~ListAtribute();
};