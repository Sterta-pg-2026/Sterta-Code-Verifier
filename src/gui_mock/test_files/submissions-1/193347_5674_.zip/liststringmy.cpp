#include "liststringmy.h"


using namespace std;

NodeStringMy::NodeStringMy(int numberOfElementsInNode) {
	this->numberOfElementsInNode = numberOfElementsInNode;
	numberOfElements = 0;
	element = new StringMy[numberOfElementsInNode];
	isTaken = new bool[numberOfElementsInNode];
	for (int i = 0; i < numberOfElementsInNode; i++) {
		isTaken[i] = false;
	}
	preNode = nullptr;
	nextNode = nullptr;
}

int NodeStringMy::GetEmpty() {
	int returnElement = -1;
	for (int i = numberOfElementsInNode - 1; i >= 0; i--) {
		if (isTaken[i] == false) {
			returnElement = i;
		}
		else {
			return returnElement;
		}
	}
	return returnElement;
}
int NodeStringMy::NumberOfTaken() {
	int numberOfTaken = 0;
	for (int i = 0; i < numberOfElementsInNode; i++) {
		if (isTaken[i] == true)
			numberOfTaken++;
	}
	return numberOfTaken;
}
int NodeStringMy::GetLast() {
	for (int i = numberOfElementsInNode - 1; i >= 0; i--) {
		if (isTaken[i] == true) {
			return i;
		}
	}
	return -1;
}



ListStringMy::ListStringMy() : ListStringMy(8) {}

ListStringMy::ListStringMy(int n) {
	start = nullptr;
	end = nullptr;
	numberOfElementsInNode = n;
	numberOfElemetns = 0;
}
void ListStringMy::Append() {
	if (end == nullptr || end->GetEmpty() != -1) {
		NodeStringMy* newNode = new NodeStringMy(numberOfElementsInNode);
		newNode->nextNode = nullptr;
		if (end == nullptr) {
			start = newNode;
			newNode->preNode = nullptr;
		}
		else {
			end->nextNode = newNode;
			newNode->preNode = end;
		}
		end = newNode;
	}
	int emptyElement = end->GetEmpty();
	end->isTaken[emptyElement] = true;
	end->numberOfElements++;
	numberOfElemetns++;
}
void ListStringMy::Append(StringMy& content) {
	this->Append();
	GetLast() = content;
}

StringMy& ListStringMy::GetElement(int n) {
	int index = 0;
	NodeStringMy* currentNode = start;
	while (currentNode != nullptr) {
		if (index + currentNode->numberOfElements < n) {

			index += currentNode->numberOfElements;
		}
		else {
			for (int i = 0; i < numberOfElementsInNode; i++) {
				if (currentNode->isTaken[i] == true) {
					if (index == n) {
						return currentNode->element[i];
					}
					else {
						index++;
					}
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
	Append();
	return GetLast();
}
void ListStringMy::UnsetElemnet(int n) {
	int index = 0;
	NodeStringMy* currentNode = start;
	while (currentNode != nullptr) {
		for (int i = 0; i < numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true) {
				if (index == n) {
					currentNode->isTaken[i] = false;
					currentNode->numberOfElements--;
					numberOfElemetns--;
					currentNode->element[i] = "";

					if (currentNode->NumberOfTaken() == 0) {
						if (currentNode->nextNode != nullptr) {
							currentNode->nextNode->preNode = currentNode->preNode;
						}
						else {
							end = currentNode->preNode;
						}
						if (currentNode->preNode != nullptr) {
							currentNode->preNode->nextNode = currentNode->nextNode;
						}
						else {
							start = currentNode->nextNode;
						}
						delete currentNode;
						return;
					}
				}
				else {
					index++;
				}
			}
		}
		currentNode = currentNode->nextNode;
	}
}
StringMy& ListStringMy::GetLast() {
	return end->element[end->GetLast()];
}

int ListStringMy::NumberOfElemnets() {
	return numberOfElemetns;
}
NodeStringMy* ListStringMy::GetEnd() {
	return end;
}

void ListStringMy::Destruct() {
	if (start != nullptr) {
		NodeStringMy* currentNode = start;
		while (currentNode->nextNode != nullptr) {
			currentNode = currentNode->nextNode;
			delete currentNode->preNode;
		}
		delete currentNode;
	}
	numberOfElemetns = 0;
	start = nullptr;
	end = nullptr;
}

ListStringMy::~ListStringMy() {
	Destruct();
}