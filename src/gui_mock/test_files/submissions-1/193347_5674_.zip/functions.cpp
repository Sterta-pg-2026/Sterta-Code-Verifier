#include "functions.h"

#define MAX_DIGITS 10

bool inSelectors(ListStringMy& Selectors, StringMy& Temp) {
	NodeStringMy* CurrentNode = Selectors.GetEnd();
	while (CurrentNode != nullptr) {
		for (int i = 0; i < CurrentNode->numberOfElementsInNode; i++) {
			if (areEqual(CurrentNode->element[i], Temp))
				return true;
		}
		CurrentNode = CurrentNode->preNode;
	}
	return false;
}

StringMy* AtributeAppeard(ListAtribute& Atributes, StringMy& AtributeName) {
	NodeAtribute* CurrentNode = Atributes.GetEnd();
	while (CurrentNode != nullptr) {
		for (int i = 0; i < CurrentNode->numberOfElementsInNode; i++) {
			if (CurrentNode->isTaken[i]==true && areEqual(CurrentNode->element[i].Name, AtributeName))
				return &(CurrentNode->element[i].Value);
		}
		CurrentNode = CurrentNode->preNode;
	}
	return nullptr;
}

StringMy intToString(int number) {
	char numberInChars[MAX_DIGITS];
	sprintf_s(numberInChars, "%d", number);
	StringMy ReturnStr(numberInChars);
	return ReturnStr;
}
StringMy numberOfSections(ListSection& CSS) {
	return intToString(CSS.NumberOfElemnets());
}

StringMy numberOfSeletors(ListSection& CSS, int i) {
	if (i <= CSS.NumberOfElemnets()) {
		return intToString(CSS.GetElement(i-1).GetSelectors().NumberOfElemnets());
	}
	StringMy ReturnStr;
	return ReturnStr;
}

StringMy getSelector(ListSection& CSS, int numberOfSection, int numberOfSelector) {
	if (numberOfSection <= CSS.NumberOfElemnets() &&
		CSS.GetElement(numberOfSection-1).GetSelectors().NumberOfElemnets() >= numberOfSelector) {
		return CSS.GetElement(numberOfSection-1).GetSelectors().GetElement(numberOfSelector-1);

	}
	StringMy ReturnStr;
	return ReturnStr;
}

StringMy numberOfSpecSelector(ListSection& CSS, StringMy& Name) {
	int numberOfOccurrences = 0;
	
	NodeSection *currentNode = CSS.GetEnd();
	while (currentNode != nullptr) {
		for (int i = 0; i < currentNode->numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true && inSelectors(currentNode->element[i].GetSelectors(), Name)) {
				numberOfOccurrences++;
			}
		}
		currentNode = currentNode->preNode;
	}
	return intToString(numberOfOccurrences);
}

StringMy numberOfAtributes(ListSection& CSS, int i) {
	if (i <= CSS.NumberOfElemnets()) {
		return intToString(CSS.GetElement(i-1).GetAtributes().NumberOfElemnets());
	}
	StringMy ReturnStr;
	return ReturnStr;
}

StringMy numberOfSpecAtribut(ListSection& CSS, StringMy& Name) {
	int numberOfOccurrences = 0;
	NodeSection* currentNode = CSS.GetEnd();

	while (currentNode != nullptr) {
		for (int i = 0; i < currentNode->numberOfElementsInNode; i++) {
			if (currentNode->isTaken[i] == true && AtributeAppeard(currentNode->element[i].GetAtributes(), Name) != nullptr) {
				numberOfOccurrences++;
			}
		}
		currentNode = currentNode->preNode;
	}
	return intToString(numberOfOccurrences);
}

StringMy valueOfAtributeForSection(ListSection& CSS, StringMy& Name, int NumberOfSection) {
	if (NumberOfSection <= CSS.NumberOfElemnets()&& NumberOfSection>0) {
		StringMy* Temp = AtributeAppeard(CSS.GetElement(NumberOfSection-1).GetAtributes(), Name);
		if (Temp != nullptr) {
			return *Temp;
		}
	}

	StringMy ReturnStr;
	return ReturnStr;
}
StringMy valueOfAtributeForSelector(ListSection& CSS, StringMy& AtributeName, StringMy& SelectorName) {
	NodeSection* currentNode = CSS.GetEnd();

	while (currentNode != nullptr) {
		for (int i = currentNode->numberOfElementsInNode-1; i>=0; i--) {
			if (currentNode->isTaken[i] == true && 
				inSelectors(currentNode->element[i].GetSelectors(), SelectorName) || currentNode->element[i].GetSelectors().NumberOfElemnets() == 0) {
				
				StringMy* Temp = AtributeAppeard(currentNode->element[i].GetAtributes(), AtributeName);
				if (Temp != nullptr) {
					return *Temp;
				}
			}

		}
		currentNode = currentNode->preNode;
	}
	StringMy ReturnStr;
	return ReturnStr;
}
StringMy deleteSection(ListSection& CSS, int numberOfSection) {
	StringMy Temp;
	if (numberOfSection>=1 && numberOfSection<=CSS.NumberOfElemnets()) {
		Temp = "deleted";
		CSS.UnsetElemnet(numberOfSection - 1);
	}
	return Temp;
}

StringMy deleteAtribute(ListSection& CSS, int numberOfSection, StringMy AtributeName) {
	StringMy Temp;
	if (CSS.NumberOfElemnets() >= numberOfSection && numberOfSection >0) {
		Section& currentSection = CSS.GetElement(numberOfSection - 1);
		if (currentSection.GetAtributes().UnsetElemnet(AtributeName) == true) {
			if (currentSection.GetAtributes().NumberOfElemnets() == 0) {
				CSS.UnsetElemnet(numberOfSection-1);
			}
			Temp = "deleted";
		}
	}

	return Temp;
}

void programOutput(StringMy& Beggining, StringMy& Middle, StringMy& End, StringMy& content) {
	if (!areEqual(content, ""))
		cout << Beggining << "," << Middle<< ","<< End<< " == " << content << endl;

}
void programOutput(StringMy& Beggining, StringMy& content) {
	if (!areEqual(content, ""))
		cout << Beggining << " == " << content << endl;
}
