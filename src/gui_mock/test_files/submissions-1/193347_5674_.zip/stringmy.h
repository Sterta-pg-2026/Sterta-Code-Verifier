#pragma once
#include <iostream>
#include <cstring>

using namespace std;

class StringMy {
	char* content;
	size_t lenght;
public:
	StringMy();
	StringMy(const char* other);
	StringMy(const StringMy& other);

	void Assign(const StringMy& other);
	void Assign(const char* other);
	void Add(const char* other);
	void Add(StringMy& other);
	void Print();
	char Scan(const char *endSigns, const char *ignoreSingns);
	StringMy& operator=(const StringMy& other);
	StringMy& operator=(const char* newContent);
	void DeleteEndingWhite();
	char* GetContent();
	friend bool areEqual(const StringMy& first, const StringMy& second); //porwnuje dwa rne strigni
	friend bool areEqual(const StringMy& first, const char* second);
	friend ostream& operator<<(ostream& ostr, const StringMy& other);

	~StringMy();
};

void zeroBuffor(char* buffor, int buffSize);
bool inChars(char sign, const char* chars); //sprawdza czy w tablicy charow jest dany znak
