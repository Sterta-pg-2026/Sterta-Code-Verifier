#pragma once
#include "stringmy.h"
//#include "Section.h"
#include "liststringmy.h"
#include "listatribute.h"
#include <iostream>

using namespace std;


class Section {
	ListStringMy Selectors;
	ListAtribute Atributes;
public:
	ListStringMy& GetSelectors();
	ListAtribute& GetAtributes();
};

class NodeSection {
public:
	NodeSection* preNode;
	NodeSection* nextNode;
	int numberOfElementsInNode;
	int numberOfElement;
	Section* element;
	bool* isTaken;

	NodeSection(int numberOfElementsInNode);
	int GetEmpty();
	int NumberOfTaken();
	int GetLast();
};

class ListSection {
	NodeSection* start, * end;
	int numberOfElementsInNode, numberOfElemetns;
public:
	ListSection();
	ListSection(int n);
	void Append(Section& content);
	void Append();
	Section& GetElement(int n);
	void UnsetElemnet(int n);
	Section& GetLast();
	int NumberOfElemnets();
	NodeSection* GetEnd();
	//T* GetEmptyElement();

	~ListSection();
};