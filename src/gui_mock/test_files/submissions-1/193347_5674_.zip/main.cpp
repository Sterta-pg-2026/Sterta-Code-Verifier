#include "stringmy.h"
#include "listatribute.h"
#include "listsection.h"
#include "liststringmy.h"
#include "functions.h"


#include <iostream>

using namespace std;

#define LF 10
#define CR 13
#define TAB 9
#define SPACE 32
#define OPENING_CURLY 123
#define CLOSING_CURLY 125
#define COMA 44
#define SEMICOLON 59
#define COLON 58


int main() {
	const char endingSelector[] = { OPENING_CURLY, COMA, CR, LF, '\0' };
	const char startingSelectors[] = { TAB, CR, LF, SPACE, '\0' };

	const char endingAtributeName[] = { COLON, CLOSING_CURLY, '\0' };
	const char startingAtributeName[] = { TAB, CR, LF, SPACE, '\0' };

	const char endingAtributeValue[] = { CLOSING_CURLY, SEMICOLON, '\0' };
	const char startingAtributeValue[] = { TAB, CR, LF, SPACE, '\0' };

	const char endingCommand[] = { TAB, CR, LF, COMA, '\0' };
	const char startingCommand[] = { TAB, CR, LF, SPACE, '\0' };

	ListSection Sections;
	Section newSection;
	Atribute TempAtribute;
	StringMy Temp;
	StringMy Beggining, Middle, End;
	char endedSign;
	bool readCommand = false;
	bool programEnd = false;

	/*Program działa w pętli do momentu gdy nie wystąpi EOF
	Pętla składa sięz dwóch sekcji: wczytywania CSS-a oraz wczytywania komend*/
	while (programEnd == false) {
		while (readCommand == false) {
			Sections.Append();
			ListStringMy& Selectors = Sections.GetLast().GetSelectors();


			//Pętla wczytująca selektory
			do {
				endedSign = Temp.Scan(endingSelector, startingSelectors);		//znak który zakończył wczytywanie jest zapamiętywany
				Temp.DeleteEndingWhite();

				if (endedSign == EOF)
					return 0;

				if (areEqual(Temp, "????")) {
					readCommand = true;
					break;
				}
				else if (!areEqual(Temp, "") && !inSelectors(Selectors, Temp)) {			// Doda� sprawdzanie, czy selektor sie nie pojawil
					Selectors.Append(Temp);
				}

			} while (endedSign != OPENING_CURLY);
			
			ListAtribute& Atributes = Sections.GetLast().GetAtributes();


			//Pętla wczytująca atrybuty
			while (endedSign != CLOSING_CURLY && readCommand == false) {

				endedSign = Temp.Scan(endingAtributeName, startingAtributeName);
				if (endedSign == EOF)
					return 0;

				if (endedSign == CLOSING_CURLY) {
					break;
				}
				Temp.DeleteEndingWhite();
				TempAtribute.Name = Temp;

				endedSign = Temp.Scan(endingAtributeValue, startingAtributeValue);
				if (endedSign == EOF)
					return 0;

				Temp.DeleteEndingWhite();
				TempAtribute.Value = Temp;

				StringMy* AppeardAtribute = AtributeAppeard(Atributes, TempAtribute.Name);

				if (AppeardAtribute == nullptr) {
					Atributes.Append(TempAtribute);
				}
				else {
					*(AppeardAtribute) = TempAtribute.Value;
				}
			}
			//Gdy brak argumentow, to nie ma selektora
			if (Atributes.NumberOfElemnets() == 0) {
				Sections.UnsetElemnet(Sections.NumberOfElemnets() - 1);
			}
		}

		while (readCommand == true && programEnd == false) {
			//ustawienie zmiennych wczytujących części komend
			Beggining = "", Middle = "", End = "";
			StringMy returnOutput;

			endedSign = Beggining.Scan(endingCommand, startingCommand);
			if (endedSign == EOF)
				programEnd = true;

			Beggining.DeleteEndingWhite();

			if (areEqual(Beggining, "****")) {
				readCommand = false;
				continue;
			}
			else if (areEqual(Beggining, "?")) {
				returnOutput = numberOfSections(Sections);
				programOutput(Beggining, returnOutput);
				continue;
			}

			if (programEnd == true)
				return 0;

			Middle.Scan(endingCommand, startingCommand);
			Beggining.DeleteEndingWhite();

			endedSign = End.Scan(endingCommand, startingCommand);
			End.DeleteEndingWhite();

			if (Middle.GetContent()[0] != '\0' && Middle.GetContent()[1] == '\0') {
				int numberI = atoi(Beggining.GetContent());
				int numberJ = atoi(End.GetContent());

				// wybor odpowiednich działań w zależności od poleceń
				//	każda funkcja zwraca stringa ze zwrotną wiadomością do wyświetlenia
				// gdy string jest pusty, to nic nie jest wyswietlane
				switch (Middle.GetContent()[0]) {
				case 'S':
					if (numberI != 0) {
						if (numberJ != 0) {
							returnOutput = getSelector(Sections, numberI, numberJ);
						}
						else if (areEqual(End, "?")) {
							returnOutput = numberOfSeletors(Sections, numberI);
						}
					}
					else {

						returnOutput = numberOfSpecSelector(Sections, Beggining);

					}
					break;
				case 'A':
					if (areEqual(End, "?")) {
						if (numberI != 0) {
							returnOutput = numberOfAtributes(Sections, numberI);
						}
						else {
							returnOutput = numberOfSpecAtribut(Sections, Beggining);
						}
					}
					else {
						returnOutput = valueOfAtributeForSection(Sections, End, numberI);
					}
					break;
				case 'E':
					returnOutput = valueOfAtributeForSelector(Sections, End, Beggining);
					break;
				case 'D':
					if (areEqual(End, "*")) {
						returnOutput = deleteSection(Sections, numberI);
					}
					else {
						returnOutput = deleteAtribute(Sections, numberI, End);
					}
				}
				programOutput(Beggining, Middle, End, returnOutput);
			}

			//wczytywanie znakow do momentu pojawienia sie entera
			//zapobiega błędą związanym z przpadkowym wpisaniu zbyt wielu argumentow w komendzie
			if (endedSign != CR && endedSign != LF && endedSign != EOF) {
				do {
					endedSign = getchar();
				} while (endedSign != CR && endedSign != LF && endedSign != EOF);
			}
		}
	}

	return 0;
}