#include <iostream>
#define T 8

struct StringNode
{
    StringNode *prev, *next;
    char letter;

    StringNode()
    {
        prev = this;
        next = this;
        letter = '<'; // this should not happen - unless there was '<' in input, otherwise '<' in output means bug/error
    }

    StringNode(char letter) : prev(this), next(this), letter(letter)
    {
    }

    StringNode(StringNode *prev, char letter) : prev(prev), next(this), letter(letter)
    {
        prev->next = this;
    }

    StringNode(StringNode *prev, StringNode *next, char letter)
    {
        if (prev != next)
        {
            this->prev = prev;
            this->next = next;
            prev->next = this;
            next->prev = this;
        }
        else
        {
            this->prev = this;
            this->next = next;
            next->prev = this;
        }
        this->letter = letter;
    }

    // destruktor i kontruktory kopiujace itp
};

struct String
{
    StringNode *text;
    String *prev, *next;

    String()
    {
        prev = this;
        next = this;
        text = NULL;
    }

    String(char letter)
    {
        this->prev = this;
        this->next = this;
        this->text = new StringNode(letter);
    }

    String(StringNode *text)
    {
        this->prev = this;
        this->next = this;
        this->text = text;
    }

    String(String *prev, char letter)
    {
        this->prev = prev;
        prev->next = this;
        this->next = this;
        this->text = new StringNode(letter);
    }

    String(String *prev, StringNode *text)
    {
        this->prev = prev;
        prev->next = this;
        this->next = this;
        this->text = text;
    }
};

struct SmallListNode
{
    String *atybuty, *selektory;

    SmallListNode()
    {
        atybuty = NULL;
        selektory = NULL;
    }

    SmallListNode(String *atrybuty, String *selektory) // przepisac na ladniejszy - : prev(), next() ..
    {
        this->atybuty = atrybuty;
        this->selektory = selektory;
    }
    // destruktor i kontruktory kopiujace itp
};

struct BigListNode
{
    BigListNode *prev, *next;
    SmallListNode *tab[T];
    short count;

    SmallListNode *addNewSmall()
    {
        if (tab[T - 1] != NULL)
        {
            BigListNode *newNode = new BigListNode(this->prev, this);///tutajjj
            newNode->prev = this->prev;
            newNode->next = this;
            newNode->count = 1;
            this->prev = newNode;
            newNode->tab[0] = new SmallListNode();
            return newNode->tab[0];
        }

        ++this->count;

        for (int i = T - 2; i >= 0; --i)
        {
            if (tab[i] != NULL)
            {
                tab[i + 1] = new SmallListNode();
                return tab[i + 1];
            }
        }

        tab[0] = new SmallListNode();
        return tab[0];
    }

    BigListNode()
    {
        prev = this;
        next = this;
        count = 0;
        for (int i = 0; i < T; ++i)
        {
            tab[i] = NULL;
        }
    }

    BigListNode(BigListNode *prev, BigListNode *next)
    {
        this->prev = prev;
        this->next = next;
        prev->next = this;
        next->prev = this;
        count = 0;
        for (int i = 0; i < T; ++i)
        {
            tab[i] = NULL;
        }
    }
};

bool cmp_attr(String pat, String *check)
{
    StringNode *pattern = pat.text;
    StringNode *checked = check->text;

    while (pattern->next != pattern && checked->next->letter != ':') /// do sprawdzenia
    {
        if (pattern->letter == checked->letter)
        {

            pattern = pattern->next;
            checked = checked->next;
        }
        else
            return false;
    }

    if (pattern->next == pattern && checked->next->letter == ':' && pattern->letter == checked->letter)
        return true;
    else
        return false;
}

bool cmp_sel(String pat, String *check)
{
    StringNode *pattern = pat.text;
    StringNode *checked = check->text;

    while (pattern->next != pattern && checked->next != checked)
    {
        if (pattern->letter == checked->letter)
        {
            pattern = pattern->next;
            checked = checked->next;
        }
        else
            return false;
    }

    if (pattern->next == pattern && checked->next == checked && pattern->letter == checked->letter)
        return true;
    else
        return false;
}

void delete_string(String *n)
{
    n->next->prev = n->prev;
    n->prev->next = n->next;

    StringNode *todelete = n->text;
    StringNode *nextlet = todelete->next;

    while (nextlet->next != nextlet)
    {
        delete todelete; /// stos ACCESS_VIOLATION
        todelete = nextlet;
        nextlet = nextlet->next;
    }

    delete nextlet;
}

SmallListNode *find_ith_node(int i, BigListNode front)
{
    BigListNode *section = front.next;
    int counter = 0;
    while (counter + section->count < i && section->next != section)
    {
        counter += section->count;
        section = section->next;
    }

    if (section->next == section)
    {
        return NULL;
    }
    else
    {
        SmallListNode *ith_node = NULL;
        for (int j = 0; j < T; ++j)
        {
            if (section->tab[j] != NULL)
                ++counter;
            if (counter == i)
            {
                ith_node = section->tab[j];
                return ith_node;
            }
        }
    }

    return NULL;
}

SmallListNode *unplug_ith_node(int i, BigListNode front)
{
    BigListNode *section = front.next;
    int counter = 0;
    while (counter + section->count < i && section->next != section)
    {
        section = section->next;
    }

    if (section->next == section)
    {
        return NULL;
    }

    else
    {
        SmallListNode *ith_node = NULL;
        for (int j = 0; j < T; ++j)
        {
            if (section->tab[j] != NULL)
                ++counter;
            if (counter == i)
            {
                ith_node = section->tab[j];
                section->tab[j] = NULL;
                section->count -= 1;
                if (section->count == 0)
                {
                    section->next->prev = section->prev;
                    section->prev->next = section->next;
                    delete section;
                }
                return ith_node;
            }
        }
    }
    return NULL;
}

void print_string(String *toprint)
{
    StringNode *currentchar = toprint->text;
    putchar(currentchar->letter);
    while (currentchar->next != currentchar)
    {
        currentchar = currentchar->next;
        putchar(currentchar->letter);
    }
    putchar('\n');
}

void count_blocks(BigListNode front)
{
    int i = 0;
    BigListNode *currnet = front.next;
    while (currnet->next != currnet)
    {
        i += currnet->count;
        currnet = currnet->next;
    }

    String *toprint = new String('?');
    StringNode *addedletter = new StringNode(toprint->text, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, i % 10 + '0');
    i /= 10;
    while (i)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
        i /= 10;
    }
    print_string(toprint);
    delete_string(toprint);
}

void print_attr_count(int i, BigListNode front)
{
    SmallListNode *ith_node = find_ith_node(i, front);
    if (ith_node == NULL)
        return;
    String *tocount = ith_node->atybuty;
    int count = 1;

    while (tocount->next != tocount)
    {
        tocount = tocount->next;
        ++count;
    }

    String *toprint = new String(i % 10 + '0');
    StringNode *addedletter = toprint->text;
    i /= 10;
    while (i)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
        i /= 10;
    }
    toprint->text = addedletter;
    while (addedletter->next != addedletter)
        addedletter = addedletter->next;
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'A');
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, '?');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, count % 10 + '0');
    count /= 10;
    while (count)
    {
        addedletter = new StringNode(addedletter, count % 10 + '0');
        count /= 10;
    }

    print_string(toprint);
    delete_string(toprint);
}

void print_n_attr_ith_sec(int i, String n, BigListNode front)
{
    SmallListNode *ith_node = find_ith_node(i, front);
    if (ith_node == NULL)
        return;

    String *tofind = ith_node->atybuty;
    bool found = cmp_attr(n, tofind);

    while (tofind->next != tofind && !found)
    {
        if (!found)
            tofind = tofind->next;
        found = cmp_attr(n, tofind);
    }

    if (!found)
        return;

    String *toprint = new String(i % 10 + '0');
    StringNode *addedletter = toprint->text;
    StringNode *let = tofind->text;
    i /= 10;
    while (i)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
        i /= 10;
    }
    toprint->text = addedletter;
    while (addedletter->next != addedletter)
        addedletter = addedletter->next;

    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'A');
    addedletter = new StringNode(addedletter, ',');
    do
    {
        addedletter = new StringNode(addedletter, let->letter);
        let = let->next;
    } while (let->letter != ':');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    let = let->next;
    while (let->next != let) /// do fixa
    {
        addedletter = new StringNode(addedletter, let->letter);
        let = let->next;
    }
    addedletter = new StringNode(addedletter, let->letter); /// zmiana
    print_string(toprint);
    delete_string(toprint);
}

void print_sel_count(int i, BigListNode front)
{
    SmallListNode *ith_node = find_ith_node(i, front);
    if (ith_node == NULL)
        return;

    String *selector = ith_node->selektory;
    int count = 0;

    if (selector != NULL)
    {
        count = 1;
        while (selector->next != selector)
        {
            ++count;
            selector = selector->next;
        }
    }

    String *toprint = new String('0' + i % 10);
    StringNode *addedletter = toprint->text;
    i /= 10;
    while (i)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, '0' + i % 10);
        i /= 10;
    }
    toprint->text = addedletter;
    while (addedletter->next != addedletter)
        addedletter = addedletter->next;
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'S');
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, '?');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '0' + count % 10);
    count /= 10;
    while (count)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, '0' + count % 10);
        count /= 10;
    }

    print_string(toprint);
    delete_string(toprint);
}

void delete_ith_node(int i, BigListNode front, bool print)
{
    SmallListNode *ith_node = unplug_ith_node(i, front);
    if (ith_node == NULL)
        return;
    String *attr = ith_node->atybuty;
    String *sel = ith_node->selektory;

    if (attr != NULL)
    {
        while (attr->next != attr)
        {
            attr = attr->next;
        }
        while (attr->prev != attr)
        {
            attr = attr->prev;
            delete_string(attr->next);
        }
        delete_string(ith_node->atybuty);
    }

    if (sel != NULL)
    {
        while (sel->next != sel)
        {
            sel = sel->next;
        }
        while (sel->prev != sel)
        {
            sel = sel->prev;
            delete_string(sel->next);
        }
        delete_string(ith_node->selektory);
    }

    if (print)
    {
        String *toprint = new String(i % 10 + '0');
        StringNode *addedletter = toprint->text;
        i /= 10;
        while (i)
        {
            addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
            i /= 10;
        }
        toprint->text = addedletter;
        while (addedletter->next != addedletter)
            addedletter = addedletter->next;
        addedletter = new StringNode(addedletter, ',');
        addedletter = new StringNode(addedletter, 'D');
        addedletter = new StringNode(addedletter, ',');
        addedletter = new StringNode(addedletter, '*');
        addedletter = new StringNode(addedletter, ' ');
        addedletter = new StringNode(addedletter, '=');
        addedletter = new StringNode(addedletter, '=');
        addedletter = new StringNode(addedletter, ' ');
        addedletter = new StringNode(addedletter, 'd');
        addedletter = new StringNode(addedletter, 'e');
        addedletter = new StringNode(addedletter, 'l');
        addedletter = new StringNode(addedletter, 'e');
        addedletter = new StringNode(addedletter, 't');
        addedletter = new StringNode(addedletter, 'e');
        addedletter = new StringNode(addedletter, 'd');

        print_string(toprint);
        delete_string(toprint);
    }
    delete ith_node;
}

void delete_attribute_n_ith_node(int i, String n, BigListNode front, bool print)
{
    SmallListNode *ith_node = find_ith_node(i, front);
    StringNode *let = n.text;
    if (ith_node == NULL)
        return;

    String *currentlychecked = ith_node->atybuty;
    bool found = false;
    do
    {
        found = cmp_attr(n, currentlychecked);
        currentlychecked = currentlychecked->next;
    } while (!found && currentlychecked->next != currentlychecked);

    if (found)
    {
        if (currentlychecked->prev == currentlychecked)
        {
            if (currentlychecked->next == currentlychecked)
                delete_ith_node(i, front, false);
            else
            {
                ith_node->atybuty = currentlychecked->next;
                String *nextatr = currentlychecked->next;
                delete_string(currentlychecked);
                nextatr->prev = nextatr; /// zmiana z (->next)
            }
        }
        else if (currentlychecked->next == currentlychecked) /// dodane
        {
            String *prevatr = currentlychecked->prev;
            delete_string(currentlychecked);
            prevatr->next = prevatr;
        }
        else
        {
            delete_string(currentlychecked);
        }
        if (print)
        {
            String *toprint = new String(i % 10 + '0');
            StringNode *addedletter = toprint->text;
            i /= 10;
            while (i)
            {
                addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
                i /= 10;
            }
            toprint->text = addedletter;
            while (addedletter->next != addedletter)
                addedletter = addedletter->next;

            addedletter = new StringNode(addedletter, ',');
            addedletter = new StringNode(addedletter, 'D');
            addedletter = new StringNode(addedletter, ',');
            addedletter = new StringNode(addedletter, let->letter);
            while (let != let->next)
            {
                let = let->next;
                addedletter = new StringNode(addedletter, let->letter);
            }
            addedletter = new StringNode(addedletter, ' ');
            addedletter = new StringNode(addedletter, '=');
            addedletter = new StringNode(addedletter, '=');
            addedletter = new StringNode(addedletter, ' ');
            addedletter = new StringNode(addedletter, 'd');
            addedletter = new StringNode(addedletter, 'e');
            addedletter = new StringNode(addedletter, 'l');
            addedletter = new StringNode(addedletter, 'e');
            addedletter = new StringNode(addedletter, 't');
            addedletter = new StringNode(addedletter, 'e');
            addedletter = new StringNode(addedletter, 'd');

            print_string(toprint);
            delete_string(toprint);
        }
    }
}

void delete_attribute_if_duplicate(String *pat, SmallListNode *ith_node)
{
    String *currentlychecked = ith_node->atybuty;
    bool found = false;
    do
    {
        found = cmp_attr(*pat, currentlychecked);
        currentlychecked = currentlychecked->next;
    } while (!found && currentlychecked->next != currentlychecked);

    if (found) /// jezeli poprzedni jest duplikatem to chyba przypal
    {
        if (currentlychecked->prev == currentlychecked)
        {
            ith_node->atybuty = currentlychecked->next;
            String *nextatr = currentlychecked->next;
            delete_string(currentlychecked);
            nextatr->prev = nextatr; /// zmiana
        }
        else
        {
            delete_string(currentlychecked);
        }
    }
}

void sel_n_count(String n, BigListNode front)
{
    BigListNode *curBig = front.next;
    String *checked;
    int counter = 0;
    while (curBig->next != curBig)
    {
        for (int i = 0; i < T; ++i)
        {
            if (curBig->tab[i] != NULL)
            {
                checked = curBig->tab[i]->selektory;
                if (checked == NULL)
                {
                    ++counter;
                    continue;
                }
                if (checked->next == checked)
                    counter += cmp_sel(n, checked);
                while (checked->next != checked)
                {
                    counter += cmp_sel(n, checked);
                    checked = checked->next;
                }
            }
        }
        curBig = curBig->next;
    }

    StringNode *let = n.text;
    String *toprint = new String(let->letter);
    StringNode *addedletter = toprint->text;
    do
    {
        let = let->next;
        addedletter = new StringNode(addedletter, let->letter);
    } while (let->next != let);
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'S');
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, '?');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, counter % 10 + '0');
    counter /= 10;
    while (counter)
    {
        addedletter = new StringNode(addedletter, counter % 10 + '0');
        counter /= 10;
    }

    print_string(toprint);
    delete_string(toprint);
}

void print_jth_sel_ith_node(int i, int j, const BigListNode front)
{
    SmallListNode *ith_node = find_ith_node(i, front);
    if (ith_node == NULL || ith_node->selektory == NULL)
        return;
    int counter = 1;
    String *jth_sel = ith_node->selektory;
    while (counter < j && jth_sel->next != jth_sel)
    {
        ++counter;
        jth_sel = jth_sel->next;
    }

    if (counter < j)
        return;

    String *toprint = new String(i % 10 + '0');
    StringNode *addedletter = toprint->text;
    i /= 10;
    while (i)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, i % 10 + '0');
        i /= 10;
    }
    toprint->text = addedletter;
    while (addedletter->next != addedletter)
        addedletter = addedletter->next;
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'S');
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, j % 10 + '0');
    j /= 10;
    while (j)
    {
        addedletter = new StringNode(addedletter->prev, addedletter, j % 10 + '0');
        j /= 10;
    }

    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    StringNode *let = jth_sel->text;
    addedletter = new StringNode(addedletter, let->letter);

    while (let->next != let)
    {
        let = let->next;
        addedletter = new StringNode(addedletter, let->letter); /// SEG FAULT
    }

    print_string(toprint);
    delete_string(toprint);
}

void n_attr_count(String n, BigListNode front)
{
    BigListNode *curBig = front.next;
    String *checked;
    int counter = 0;
    while (curBig->next != curBig)
    {
        for (int i = 0; i < T; ++i)
        {
            if (curBig->tab[i] != NULL)
            {
                checked = curBig->tab[i]->atybuty;
                counter += cmp_attr(n, checked);
                while (checked->next != checked)
                {
                    checked = checked->next;
                    counter += cmp_attr(n, checked);
                }
            }
        }
        curBig = curBig->next;
    }

    StringNode *let = n.text;
    String *toprint = new String(let->letter);
    StringNode *addedletter = toprint->text;
    while (let->next != let)
    {
        let = let->next;
        addedletter = new StringNode(addedletter, let->letter);
    }
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, 'A');
    addedletter = new StringNode(addedletter, ',');
    addedletter = new StringNode(addedletter, '?');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, '=');
    addedletter = new StringNode(addedletter, ' ');
    addedletter = new StringNode(addedletter, counter % 10 + '0');
    counter /= 10;
    while (counter)
    {
        addedletter = new StringNode(addedletter, counter % 10 + '0');
        counter /= 10;
    }

    print_string(toprint);
    delete_string(toprint);
}

void last_z_attr_val_for_last_sel_n(String n, String z, BigListNode back)
{
    BigListNode *currBig = back.prev;
    SmallListNode *currSmall;
    String *checked;
    bool foundSel = 0, foundAttr = 0;

    while (currBig->prev != currBig)
    {
        if (!(foundSel & foundAttr))
        {
            for (int i = T - 1; i >= 0; --i)
            {
                if (currBig->tab[i] != NULL)
                {
                    foundAttr = 0;
                    foundSel = 0;
                    currSmall = currBig->tab[i];
                    if (currSmall->selektory == NULL) /// stos ACCESS_VIOLATION
                        foundSel = true;
                    else
                    {
                        checked = currSmall->selektory;
                        if (cmp_sel(n, checked))
                        {
                            foundSel = true;
                        }
                        while (checked != checked->next&&foundSel!=true)
                        {
                            checked = checked->next;
                            if (cmp_sel(n, checked))
                            {
                                foundSel = true;
                                break;
                            }
                        }
                    }

                    checked = currSmall->atybuty;
                    if (cmp_attr(z, checked))
                    {
                        foundAttr = true;
                    }
                    while (checked != checked->next && foundAttr != true)
                    {
                        checked = checked->next;
                        if (cmp_attr(z, checked))
                        {
                            foundAttr = true;
                            break;
                        }
                    }
                    if (foundAttr & foundSel)
                        break;
                }
            }
            currBig = currBig->prev;
        }
        else
            break;
    }

    if (foundAttr & foundSel)
    {
        StringNode *let = n.text;
        String *toprint = new String(let->letter);
        StringNode *addedletter = toprint->text;
        while (let->next != let)
        {
            let = let->next;
            addedletter = new StringNode(addedletter, let->letter);
        }
        addedletter = new StringNode(addedletter, ',');
        addedletter = new StringNode(addedletter, 'E');
        addedletter = new StringNode(addedletter, ',');
        let = z.text;
        addedletter = new StringNode(addedletter, let->letter);
        do
        {
            let = let->next;
            addedletter = new StringNode(addedletter, let->letter);
        } while (let->next != let);
        addedletter = new StringNode(addedletter, ' ');
        addedletter = new StringNode(addedletter, '=');
        addedletter = new StringNode(addedletter, '=');
        let = checked->text;
        while (let->prev->letter != ':')
        {
            let = let->next;
        }
        while (let->next != let)
        {
            addedletter = new StringNode(addedletter, let->letter);
            let = let->next;
        }
        addedletter = new StringNode(addedletter, let->letter);
        print_string(toprint);
        delete_string(toprint);
    }
}

void read_css(char &last_char, bool &handling, BigListNode &currBigBack)
{
    if (last_char == '?')
    {
        handling = true;
        last_char = getchar(); // command section begins with ????
        last_char = getchar();
        last_char = getchar();
        last_char = getchar();
        return;
    }

    SmallListNode *currSmallBack = currBigBack.prev->addNewSmall();
    if (last_char == '{')
        currSmallBack->selektory = NULL;
    else
    {
        currSmallBack->selektory = new String(last_char);
        String *read = currSmallBack->selektory;
        StringNode *currentletter = read->text;
        last_char = getchar();

        while (last_char != '{') // selektory
        {
            if (last_char == ',')
            {
                while (currentletter->letter == ' ')
                {
                    currentletter = currentletter->prev;
                    delete currentletter->next;
                }

                last_char = getchar();
                while (last_char <= ' ')
                    last_char = getchar();
                read = new String(read, last_char);
                currentletter = read->text; /// zmianaaa!!
                last_char = getchar();
                continue;
            }
            currentletter = new StringNode(currentletter, last_char);
            last_char = getchar();
            while (last_char < ' ') last_char = getchar();
        }
        while (currentletter->letter <= ' ')
        {
            currentletter = currentletter->prev;
            delete currentletter->next;
        }
    }

    last_char = getchar();
    while (last_char <= ' ')
        last_char = getchar();
    currSmallBack->atybuty = new String(last_char);
    String *read = currSmallBack->atybuty;
    StringNode *currentletter = read->text;
    last_char = getchar();

    while (last_char != '}') // atrybuty
    {
        if (last_char == ';')
        {
            last_char = getchar();
            while (last_char <= ' ')
                last_char = getchar();
            if (last_char != '}')
            {
                read = new String(read, last_char);
                currentletter = read->text; /// zmianaaa!!
                last_char = getchar();
            }
            continue;
        }
        if (last_char == ':')
        {
            delete_attribute_if_duplicate(read, currSmallBack);
        }
        currentletter = new StringNode(currentletter, last_char);
        last_char = getchar();
    }
    last_char = getchar();
}

void handle_commands(char &last_char, bool &handling, BigListNode &front, BigListNode &back)
{
    if (last_char == '*')
    {
        handling = false;
        last_char = getchar(); // css section begins with ****
        last_char = getchar();
        last_char = getchar();
        last_char = getchar();
        return;
    }

    if (last_char == '?')
    {
        last_char = getchar();
        count_blocks(front); //?
    }
    else if (last_char >= '0' && last_char <= '9') // i,_,_
    {
        int i = last_char - '0';

        while ((last_char = getchar()) != ',')
        {
            i *= 10;
            i += last_char - '0';
        }

        last_char = getchar();

        if (last_char == 'A') // i,A,_
        {
            last_char = getchar(); //,
            if ((last_char = getchar()) == '?')
            {
                last_char = getchar();
                print_attr_count(i, front); // i,A,?
            }
            else
            {
                String n = String(last_char);
                StringNode *currentletter = n.text;

                while ((last_char = getchar()) >= ' ') // wczytanie reszty stringa n
                {
                    currentletter = new StringNode(currentletter, last_char);
                }

                print_n_attr_ith_sec(i, n, front); // i,A,n
                delete_string(&n);
            }
        }
        else if (last_char == 'S') // i,S,_
        {
            last_char = getchar(); //','
            if ((last_char = getchar()) == '?')
            {
                last_char = getchar();
                print_sel_count(i, front); // i,S,?
            }
            else
            {
                int j = last_char - '0';
                while ((last_char = getchar()) > ' ')
                {
                    j *= 10;
                    j += last_char - '0';
                }
                print_jth_sel_ith_node(i, j, front); // i,S,j
            }
        }
        else // i,D,_
        {
            last_char = getchar(); //','
            if ((last_char = getchar()) == '*')
            {
                last_char = getchar();
                delete_ith_node(i, front, true); // i,D,*
            }
            else
            {
                String n = String(last_char);
                StringNode *currentletter = n.text;
                while ((last_char = getchar()) >= ' ') // wczytanie reszty stringa n
                {
                    currentletter = new StringNode(currentletter, last_char);
                }

                delete_attribute_n_ith_node(i, n, front, true); // i,D,n
                delete_string(&n);
            }
        }
    }
    else // n,_,_
    {
        String n = String(last_char);
        StringNode *currentletter = n.text;
        while ((last_char = getchar()) != ',')
        {
            currentletter = new StringNode(currentletter, last_char);
        }

        last_char = getchar();

        if (last_char == 'A') // n,A,?
        {
            last_char = getchar();
            last_char = getchar(); // we know this will be , and ? respectively
            last_char = getchar();
            n_attr_count(n, front); // n,A,?
        }
        else if (last_char == 'S') // n,S,? (z,S,? w instrukcji)
        {
            last_char = getchar();
            last_char = getchar(); // we know this will be , and ? respectively
            last_char = getchar();
            sel_n_count(n, front); // z,S,?
        }
        else // n,E,z (z,E,n w instrukcji)
        {
            last_char = getchar(); //','
            last_char = getchar();
            String z = String(last_char);
            currentletter = z.text;
            while ((last_char = getchar()) >= ' ')
            {
                currentletter = new StringNode(currentletter, last_char);
            }
            while (currentletter->letter <= ' ')
            {
                currentletter = currentletter->prev;
                delete currentletter->next;
            }
            last_z_attr_val_for_last_sel_n(n, z, back); // z,E,n
            delete_string(&z);
        }
        delete_string(&n);
    }
}

int main()
{
    char last_char = getchar();
    bool handling_commands = false;
    BigListNode front = BigListNode(), back = BigListNode();
    front.next = new BigListNode(&front, &back);

    while (last_char != EOF)
    {
        if (handling_commands)
        {
            handle_commands(last_char, handling_commands, front, back);
        }
        else
        {
            read_css(last_char, handling_commands, back);
        }
        while (last_char <= ' ' && last_char != EOF)
        {
            last_char = getchar();
        }
    }
}