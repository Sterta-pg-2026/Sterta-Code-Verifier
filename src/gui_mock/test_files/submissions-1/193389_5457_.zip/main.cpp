
#include <iostream>

using namespace std;


class String
{
public:

	size_t size = 0;
	char* str = new char[size];

	

	String() {};

	String(int size)
	{
		str = new char[size];
	};

	String(char ch)
	{
		str[0] = ch;
	}

	String(const char* arg)
	{
		size = strlen(arg);
		str = new char[size + 1];
		//strcpy(str, arg);
	}

	char GetStr(int index)const
	{
		return str[index];
	}

	void SetStr(char* str /*int size*/)
	{
		this->str = str;
		//this->size = size;
	}


	void ClearString()
	{
		delete[] str;
		str = nullptr;
		size = 0;
	}


	friend ostream& operator<<(ostream& os, const String& string)
	{
		os << string.str;
		return os;
	}

	friend istream& operator>>(istream& is, String& string)
	{
		/*for (int i = 0; i < string.size; i++)
		{
			is >> string.str[i];
		}*/
		char buffer[4096];
		is >> buffer;
		string = buffer;

		return is;
	}

	void GetLine(istream& is, String& line)
	{
		char end = '\n';

		for (int i = 0; i < size; i++)
		{
			while (str[i] != end)
			{
				is >> line.str[i];
			}
		}
	}


	char operator[](int index) const
	{
		if (index < 0 || index >= this->size)
		{
			throw out_of_range("balsbd");
		}

		return this->str[index];
	}

	char operator+=(const String& string)
	{

		return string[0];
	}

	friend bool operator==(const String& s1, const String& s2)
	{
		if (s1.size != s2.size)
		{
			return false;
		}
		else
		{
			for (int i = 0; i < s1.size; i++)
			{
				if (s1[i] != s2[i])
				{
					return false;
				}
			}
			return true;
		}
	}

	friend bool operator!=(const String& s1, const String& s2)
	{
		if (s1.size != s2.size)
		{
			return true;
		}

		for (int i = 0; i < s1.size; i++)
		{
			if (s1[i] != s2[i])
			{
				return true;
			}
		}

		return false;
	}


	~String()
	{
		delete[] str;
	}
};




class Node
{
public:
	String name;
	Node* next;
	Node* prev;

	Node()
	{
		next = NULL;
		prev = NULL;
	}

	Node(String name)
	{
		this->name = name;
		this->next = next;
		this->prev = prev;
	}
};


class List
{
public:
	Node* head;

	List()
	{
		head = NULL;
	};

	void AddNode(String name)	//moze string*?
	{
		Node* new_node = new Node(name);

		if (head == NULL)
		{
			head = new_node;
			return;
		}

		Node* temp = head;
		while (temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = new_node;
	}


	int CountNodes()
	{
		//Node* head;

		Node* temp = head;
		int size = 0;

		if (temp != NULL)
		{
			size++;
			temp = temp->next;
		}
		return size;
	}
};





struct CssAttribute
{
	String name;
	String value;
};

struct CssBlock
{
	String selector_name;
	CssAttribute array[2];
};


int GetIndex(const String& string, char ch)
{
	int index = 0;

	for (int i = 0; i < string.size; i++)
	{
		if (string[i] == ch)
		{
			index = string[i];
		}
	}
	return index;
}



int main()
{
	List sections;
	CssBlock* block_arr = new CssBlock[8];

	Node node;
	String selector = node.name;

	String input;
	String commands;

	bool command_sec = false;

	Node head;

	Node end;
	end.next = NULL;


	String block_start = '{';
	String block_end = '}';
	char attribute = ':';


	//input.GetLine(cin, input);
	cin >> input;

	if (input == block_start)     //caly ten if przechodzi przez block, trzeba go jeszcze wpierdolic w zewnetrznego loopa ktory przechodzi przez wszytskie bloki
	{
		int index_start = GetIndex(input, '{');
		int index_end = GetIndex(input, '}');

		for (int i = 0; i < index_start; i++)
		{
			block_arr->selector_name += input[i];
		}


		while (input != block_end)
		{
			//cout << block_arr->selector_name;
			index_start = 0;
			for (int i = index_start + 1; i < index_end; i++)
			{
				if (input[i] == attribute)
				{
					GetIndex(input[input.size], ':');
				}
				block_arr->array[0].name[i];
				block_arr->array[1].value[i];
			}
		}

		if (input == block_end)
		{
			if (head.name != NULL)
			{

			}
			else
			{
				head.name = selector;       // pierwszy element LISTY
			}

			int index_block = 0;
			index_block++;          //block do pierwszego elementu tablicy, 
			input.ClearString();
		}
	}

	String commands_start = '????';
	String commands_end = '****';
	String num_of_sections = '?';

	if (input == commands_start)
	{
		command_sec = true;
		//continue;
	}

	while (command_sec == true)
	{
		//cout << "fupa";
		//cin>>commands;    // lub 
		commands.GetLine(cin, commands);


		if (input == commands_end)
		{
			command_sec = false;
			break;
		}


		if (input == num_of_sections)
		{
			//print number of sections == number of blocks == size of the list
			int num_sections = sections.CountNodes();
			cout << num_sections << endl;
		}


		/*if (input == "clear")
		{
			selectors.clear();
			continue;
		}*/
	}

	//selectors.clear();
	return 0;
}