// PROJECT 1 AISD.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.


#include <iostream>

#define T 17

using namespace std;

struct Attribute
{
    char* key;
    char* value;
};

struct Selector
{
    char* name;
};
int lenght(const char* a)
{
    int i = 0;
    while (a[i] != '\0')
    {
        i++;
    }
    return i;
}

bool eqString(char* str1, const char* str2) {
    if (lenght(str1) == lenght(str2)) {
        for (int i = 0; i < lenght(str1); i++) {
            if (str1[i] != str2[i]) {
                return false;
            }

        }
        return true;
    }
    return false;
}
class SingleNodeA
{

    Attribute A;
    SingleNodeA* next;

public:
    void setSingleNode(SingleNodeA* next)
    {
        this->next = next;
    }
    SingleNodeA* getNext()
    {
        return next;
    }
    void setA(Attribute A) {
        this->A = A;
    }
    Attribute getA() {
        return A;
    }

    char* getAValue() {
        return A.value;
    }
    char* getAKey() {
        return A.key;
    }
};

class SingleNodeS {
private:
    Selector S;

    SingleNodeS* next;
public:
    void setSingleNode(SingleNodeS* next)
    {
        this->next = next;
    }
    SingleNodeS* getNext()
    {
        return next;
    }

    void setS(Selector S)
    {
        this->S = S;
    }
    Selector getS()
    {
        return S;
    }
    char* getSName() {
        return S.name;
    }
};


class singleLinkedListA {
private:
    SingleNodeA* begin;
public:
public:
    singleLinkedListA()
    {
        begin = nullptr;
    }
    void insertA(Attribute a)
    {
        SingleNodeA* current = begin;
        while (current != nullptr) {
            if (eqString(a.key, current->getAKey())) {
                current->setA(a);
                return;
            }
            current = current->getNext();
        }

        SingleNodeA* newElement = new SingleNodeA;
        newElement->setA(a);
        newElement->setSingleNode(nullptr);
        if (begin == nullptr)
        {
            begin = newElement;
        }
        else
        {
            SingleNodeA* test = begin;
            while (test->getNext() != nullptr)
            {
                test = test->getNext();
            }
            test->setSingleNode(newElement);
        }
    }
    void printAttributes()
    {
        SingleNodeA* current = begin;
        while (current != nullptr)
        {
            cout << current->getA().key << ":" << current->getA().value << "|";
            current = current->getNext();
        }
    }
    void clearAll() {
        SingleNodeA* curr = begin;
        while (curr != nullptr) {
            SingleNodeA* temp = curr;
            curr = curr->getNext();
            temp = NULL;
        }
        begin = nullptr;
    }

    int counter() {
        SingleNodeA* current = begin;
        int counter = 0;
        while (current != NULL)
        {

            current = current->getNext();
            counter++;
        }

        return counter;
    }


    char* printTheAttribute(char a[]) {
        SingleNodeA* current = begin;

        while (current != nullptr) {

            if (eqString(a, current->getAKey())) {
                return current->getAValue();
            }
            current = current->getNext();

        }
        return 0;
    }

    bool deleteTheAttribute(char a[]) {
        if (eqString(begin->getAKey(), a)) {

            SingleNodeA* nodeToRemove = begin;
            if (begin->getNext() != nullptr) {
                begin = begin->getNext();
                delete nodeToRemove;
                return 1;
            }
            else {
                return 0;
            }
        }
        SingleNodeA* currentNode = begin;

        while (currentNode != nullptr) {
            if (eqString(currentNode->getNext()->getAKey(), a)) {
                SingleNodeA* nodeToDelete = currentNode->getNext();
                currentNode->setSingleNode(nodeToDelete->getNext());
                delete nodeToDelete;
                return 1;
            }
            currentNode = currentNode->getNext();
        }
        return 1;

    }

};

class singleLinkedListS
{
private:
    SingleNodeS* begin;

public:
    singleLinkedListS()
    {
        begin = nullptr;
    }

    void insertS(Selector s)
    {
        SingleNodeS* newElement = new SingleNodeS;
        newElement->setS(s);
        newElement->setSingleNode(nullptr);

        if (begin == nullptr)
        {
            begin = newElement;
        }
        else
        {
            SingleNodeS* test = begin;
            while (test->getNext() != nullptr)
            {

                if (eqString(test->getSName(), newElement->getSName())) {
                    return;
                }
                test = test->getNext();

            }
            if (eqString(test->getSName(), newElement->getSName())) {
                return;
            }
            test->setSingleNode(newElement);
        }
    }



    void printSelectors()
    {
        SingleNodeS* current = begin;
        while (current != nullptr)
        {
            cout << current->getS().name << "|";
            current = current->getNext();
        }
    }



    void clearAll() {
        SingleNodeS* curr = begin;
        while (curr != nullptr) {
            SingleNodeS* temp = curr;
            curr = curr->getNext();
            temp = NULL;
        }
        begin = nullptr;
    }

    int counter() {
        SingleNodeS* current = begin;
        int counter = 0;
        while (current != NULL)
        {

            current = current->getNext();
            counter++;
        }

        return counter;
    }
    char* printSelectorNum(int a) {
        SingleNodeS* current = begin;
        int counter = 1;
        while (a != counter) {
            current = current->getNext();
            counter++;
        }
        return current->getSName();
    }
    bool isTheSelector(char* a) {
        SingleNodeS* current = begin;

        while (current != nullptr) {

            if (eqString(a, current->getSName())) {
                return true;
            }
            current = current->getNext();

        }
        return false;
    }
};

struct Block
{

    singleLinkedListS Selectors;
    singleLinkedListA Attributes;
};

struct Node
{
    Block b[T];
    Node* next = nullptr;
    Node* prev = nullptr;
    int howMany = 0;
};

class twoLinkedList
{
private:
    Node* begin;
    Node* end;


public:
    twoLinkedList()
    {
        begin = nullptr;
        end = nullptr;



    }

    ~twoLinkedList()
    {
        Node* curr = begin;
        while (curr != nullptr) {
            Node* temp = curr;
            curr = curr->next;
            delete temp;
        }
    }


    int counterBlock() {
        Node* current = begin;
        int count = 0;

        while (current != nullptr) {

            count += current->howMany;
            current = current->next;

        }
        return count;
    }
    int counterAttributes(int a) {
        Node* current = begin;
        if (a > counterBlock()) {
            return -1;
        }
        else {
            while (a > current->howMany) {
                a -= current->howMany;
                current = current->next;

            }
            a--;
            return current->b[a % T].Attributes.counter();
        }
    }

    int counterSelectors(int a) {
        Node* current = begin;
        if (a > counterBlock()) {
            return -1;
        }
        else {
            while (a > current->howMany) {
                a -= current->howMany;
                current = current->next;

            }
            a--;
            return current->b[a].Selectors.counter();
        }
    }
    char* printTheSelector(int a, int b) {
        Node* current = begin;

        if (a > counterBlock()) {
            return 0;
        }
        else {
            while (a > current->howMany) {
                a -= current->howMany;
                current = current->next;

            }
            a--;
            if (b > current->b[a].Selectors.counter()) {
                return 0;
            }
            return current->b[a].Selectors.printSelectorNum(b);
        }
    }
    char* printTheAttribute(int a, char b[]) {
        Node* current = begin;
        if (a > counterBlock()) {
            return 0;
        }
        else {
            while (a > current->howMany) {
                a -= current->howMany;
                current = current->next;

            }
            a--;

            return current->b[a].Attributes.printTheAttribute(b);
        }
    }
    int countTheSpecialAttribute(char a[]) {
        Node* current = begin;
        int counter = 0;
        while (current != nullptr) {
            for (int i = 0; i < current->howMany; i++) {
                if (current->b[i].Attributes.printTheAttribute(a)) {
                    counter++;
                }

            }
            current = current->next;


        }
        return counter;
    }
    int countTheSpecialSelector(char a[]) {
        Node* current = begin;
        int counter = 0;
        while (current != nullptr) {
            for (int i = 0; i < current->howMany; i++) {
                if (current->b[i].Selectors.isTheSelector(a)) {
                    counter++;
                }

            }
            current = current->next;


        }
        return counter;
    }

    char* printTheAttributeinSelector(char a[], char b[]) {
        Node* current = end;

        while (current != nullptr) {
            for (int i = current->howMany - 1; i >= 0; i--) {
                if (current->b[i].Selectors.isTheSelector(a)) {
                    return current->b[i].Attributes.printTheAttribute(b);
                }

            }
            current = current->prev;


        }

        return 0;

    }
    bool deleteTheBlock(int a) {
        Node* current = begin;
        if (a > counterBlock()) {
            return 0;
        }
        else {



            while (a > current->howMany) {
                a -= current->howMany;
                current = current->next;

            }
            a--;
            for (int i = a; i < current->howMany - 1; i++) {
                current->b[i] = current->b[i + 1];
            }


            current->howMany--;
            return 1;
        }
    }

    bool deleteTheAttribute(int a, char b[]) {
        Node* current = begin;
        int tmp = a;
        if (a > counterBlock() || !printTheAttribute(a, b)) {
            return 0;
        }

        else {
            a -= 1;


            while (current != nullptr) {
                for (int i = 0; i < current->howMany; i++) {
                    if (a == i) {
                        bool temp = current->b[i].Attributes.deleteTheAttribute(b);
                        if (!temp) {
                            deleteTheBlock(tmp);
                            return 1;
                        }
                        else if (temp) {
                            return 1;
                        }
                    }

                }
                a -= current->howMany;
                current = current->next;
            }
            return 0;
        }
    }



    void createNode(Block b) {
        Node* newElement = new Node;
        newElement->howMany = 1;
        newElement->b[0] = b;
        newElement->next = nullptr;
        newElement->prev = end;
        if (end != nullptr)
        {
            end->next = newElement;
        }
        else
        {
            begin = newElement;
        }
        end = newElement;

    }


    void insertNode(Block b) {
        if (end == nullptr || end->howMany == T) {
            createNode(b);
        }
        else {
            end->howMany++;
            end->b[end->howMany - 1] = b;


        }
    }
    void printAll() {
        Node* current = begin;
        while (current != nullptr) {
            for (int j = 0; j < current->howMany; j++) {
                cout << "BLOCK:" << endl;
                cout << "Attr:";
                current->b[j].Attributes.printAttributes();
                cout << "Selec:";
                current->b[j].Selectors.printSelectors();
                cout << endl << endl;

            }
            current = current->next;
        }




    }
};

bool find(char a[], char b)
{
    int len = lenght(a);
    for (int i = 0; i < len; i++)
    {
        if (a[i] == b)
        {
            return true;
        }
    }
    return false;
}




void equalStr(char a[], char b[]) {
    int size = lenght(b);

    for (int i = 0; i < size; i++) {
        a[i] = b[i];

    }
    a[size] = '\0';
}

char* cutString(char string[], int a, int b) {

    char* newString = new char[150];
    int j = 0;

    if (string[b] == ';') {
        for (int i = a; i < b; i++) {
            if (i > a && i < b - 1) {
                newString[j] = string[i];
                j++;
            }
            else {
                if (string[i] > 33) {
                    newString[j] = string[i];
                    j++;
                }
            }
        }
    }
    else {
        for (int i = a; i < b; i++) {
            if (string[i] > 31 && a + 6 < i && b - 1 > i && string[i - 1] > 33 && string[i + 1] > 33) {
                newString[j] = string[i];
                j++;
            }
            else if (string[i] > 33) {
                newString[j] = string[i];
                j++;
            }

        }
    }

    newString[j] = '\0';
    return newString;
}



void readSelector(char* str, int& znaczenie, Block& b) {
    char* selector = new char[150];
    //char* attribute = new char[100];
    equalStr(selector, str);
    //char* temp = new char[100];
    Selector s;
    Attribute a;
    //cin >> selector;
    //int size = lenght(selector);
    int start = 0;
    //cin.getline(selector, 150);
    int size = lenght(selector);
    if (eqString(selector, "????")) {
        znaczenie = 3;
    }
    for (int i = 0; i < size; i++) {
        if (selector[i] == ',' && znaczenie == 1) {
            s.name = cutString(selector, start, i);
            if (lenght(s.name) > 0) {
                b.Selectors.insertS(s);
            }
            start = i + 1;

        }
        else if (selector[i] == '{' && znaczenie == 1) {
            if (i - start > 1) {
                s.name = cutString(selector, start, i);
                b.Selectors.insertS(s);
            }
            start = i + 1;
            znaczenie = 2;
        }
        else if (selector[i] == ':' && znaczenie == 2) {
            a.key = cutString(selector, start, i);
            start = i + 1;

        }
        else if (selector[i] == ';' && znaczenie == 2) {
            a.value = cutString(selector, start, i);
            start = i + 1;
            b.Attributes.insertA(a);
        }
        else if (selector[i] == '}' && znaczenie == 2) {
            znaczenie = 0;
        }

    }
    if (znaczenie == 1 && !find(selector, ',') && !find(selector, '{')) {
        s.name = cutString(selector, 0, size);
        if (lenght(s.name) > 0) {
            b.Selectors.insertS(s);
        }

    }
    else if (znaczenie == 1 && find(selector, ',') && !find(selector, '{') && size - start > 5) {
        s.name = cutString(selector, start, size);
        if (lenght(s.name) > 0) {
            b.Selectors.insertS(s);
        }
    }


    delete[] selector;


}

int convertCharToInt(char str[]) {
    int result = 0;
    int i = 0;
    while (str[i] >= '0' && str[i] <= '9') {
        result = result * 10 + (str[i] - '0');
        i++;
    }
    return result;
}
bool charOrInt(char str[]) {
    if (str[0] >= '0' && str[0] <= '9') {
        return true;
    }
    return false;
}
void readCommands(char* str, int& znacz, twoLinkedList& BLOCKS) {
    char* string = new char[100];
    equalStr(string, str);
    int size = lenght(string);
    int j1 = 0, j2 = 0, start = 0;
    char* string1 = new char[30];
    char* string2 = new char[30];
    char a = ' ';
    int znaczenie = 1;
    if (eqString(string, "****")) {
        znacz = 1;
        delete[] string1;
        delete []string2;
        delete []string;
        return;
    }
    else if (eqString(string, "?")) {
        cout << "? == " << BLOCKS.counterBlock() << endl;
        delete[] string1;
        delete [] string2;
        delete []string;
        return;
    }
    for (int i = 0; i < size; i++) {
        if (string[i] == ',' && znaczenie == 1) {
            string1 = cutString(string, 0, i);
            start = i;
            if (charOrInt(string1)) {
                j1 = convertCharToInt(string1);
            }


            znaczenie = 2;
        }
        else if (string[i] == ',' && znaczenie == 2) {
            a = string[i - 1];
            znaczenie = 3;
            start = i + 1;
        }
        else if (i == size - 1 && znaczenie == 3) {
            string2 = cutString(string, start, i + 1);
            if (charOrInt(string2)) {
                j2 = convertCharToInt(string2);
            }

        }

    }

    if (j1 != 0 && a == 'S' && eqString(string2, "?") && BLOCKS.counterSelectors(j1) != -1) {
        cout << j1 << "," << a << ",? == " << BLOCKS.counterSelectors(j1);
        cout << endl;
    }
    else if (j1 != 0 && a == 'A' && eqString(string2, "?") && BLOCKS.counterAttributes(j1) != -1) {
        cout << j1 << "," << a << ",? == " << BLOCKS.counterAttributes(j1);
        cout << endl;
    }
    else if (j1 != 0 && a == 'S' && j2 != 0 && BLOCKS.printTheSelector(j1, j2) != 0) {
        cout << j1 << "," << a << "," << j2 << " == " << BLOCKS.printTheSelector(j1, j2);
        cout << endl;


    }
    else if (j1 != 0 && a == 'A' && j2 == 0 && BLOCKS.printTheAttribute(j1, string2) != 0) {
        cout << j1 << "," << a << "," << string2 << " == " << BLOCKS.printTheAttribute(j1, string2);
        cout << endl;

    }
    else if (j1 == 0 && a == 'A' && eqString(string2, "?")) {
        cout << string1 << ",A,? == " << BLOCKS.countTheSpecialAttribute(string1);
        cout << endl;
    }
    else if (j1 == 0 && a == 'S' && eqString(string2, "?")) {
        cout << string1 << ",S,? == " << BLOCKS.countTheSpecialSelector(string1);
        cout << endl;
    }
    else if (j1 == 0 && a == 'E' && j2 == 0 && BLOCKS.printTheAttributeinSelector(string1, string2) != 0) {
        cout << string1 << ",E," << string2 << " == " << BLOCKS.printTheAttributeinSelector(string1, string2);
        cout << endl;
    }
    else if (j1 != 0 && a == 'D' && eqString(string2, "*") && BLOCKS.deleteTheBlock(j1)) {

        cout << j1 << ",D,* == deleted";
        cout << endl;
    }

    else if (j1 != 0 && a == 'D' && j2 == 0 && BLOCKS.deleteTheAttribute(j1, string2)) {

        cout << j1 << ",D," << string2 << " == deleted";
        cout << endl;
    }



    delete[] string;
    delete[] string1;
    delete[] string2;


}








int main()
{
    // ios_base::sync_with_stdio(0);
    char* selector = new char[150];
    Block b;
    twoLinkedList BLOCKS;
    int znacz = 1;
    // 0 - block
    // 1 - selectors
    // 2 - attributes
    // 3 - commands
    while (cin.getline(selector, 150)) {

        if (znacz == 0) {
            BLOCKS.insertNode(b);
            b.Attributes.clearAll();
            b.Selectors.clearAll();
            znacz = 1;
        }
        if (znacz == 1 || znacz == 2) {
            readSelector(selector, znacz, b);
        }
        if (znacz == 3) {
            readCommands(selector, znacz, BLOCKS);
        }
    }
    delete[] selector;
    return 0;
}
