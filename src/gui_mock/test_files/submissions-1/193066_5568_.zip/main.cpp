
#include <iostream>
#include <math.h>
#define T 8
#define MX_GETS 2048
#define MX_SELEC_SIZE 256



//WYWAL STRINGA
/*
class Node {

	secktion* sekcja;
	Node* prev_node;
	Node* next_node;

public:
	Node() {
		sekcja = new secktion[WIELKOSC_TABLICY];
		for (int i = 0; i < WIELKOSC_TABLICY; i++) {
			sekcja[i].if_empt = true;
		}
	}

	void append() {

	}

	void set_next_node(Node* prev) {

	}

	void set_prev_node(Node* prev) {

	}

	Node set_prev_node



};
*/

struct atribute {
	char* properties;
	char* values;

	atribute* next;
	atribute* prev;
};

struct selector {
	char* name;

	selector* next;
	selector* prev;
};




struct section {
	selector* selectors;

	atribute* atributes;

	long int amount_of_selecs;
	long int  amount_of_atributes;

	bool if_empt;
	bool if_deleted;
};

struct Node {

	section* eight_sections;
	Node* prev_node;
	Node* next_node;
};



long int str_len(char* in) {
	int out = 0;
	while (in[out] != '\0') {
		out++;
	}
	return out;
}



int change_str_to_int(char* str) {

	int size = str_len(str);
	int curr_pos = size - 1;
	int out = 0;
	for (int i = 0; i < size; i++) {
		out += (str[i] % 48) * pow(10, curr_pos);
		curr_pos--;

	}

	return out;


}


bool look_for_char(char* string, char wanted) {

	for (int i = 0; i < str_len(string); i++) {
		if (string[i] == wanted) return true;

	}
	return false;
}

void paste_onto_pos(char* from, char* to, int pos) {

	for (int i = 0; i < str_len(from); i++) {
		to[pos + i] = from[i];
	}

}

char* resize(char*& old, long int size)
{
	char* new_ptr;
	new_ptr = new char[size * 2];
	for (long int i = 0; i < size; ++i)
		new_ptr[i] = old[i];
	delete[] old;
	old = nullptr;
	return new_ptr;
}

int len_until_char(char* string, char wanted, int from_pos) {
	int out = 0;
	for (int i = 0; i < str_len(string); i++) {
		if (string[i] == wanted) return out;
		out++;
	}
	return -1;

}

bool if_whites_to_del(char* string, char separator, int pos) {

	//checks if a separator is next after the gap of white spaces


	int size = str_len(string);
	for (int i = pos; i < size; i++) {
		if (string[i] == separator) return true;
		else if ((int)string[i] > 32) return false;
	}
	return true;


}


int count_chars(char* string, char counted) {
	int out = 0;
	for (int i = 0; i < str_len(string); i++) {
		if (string[i] == counted) {
			out++;
		}
	}
	return out;
}


bool compare_strings(char* str1, char* str2) {
	int i = 0;

	while (str1[i] != '\0' || str2[i] != '\0') {
		if (str1[i] != str2[i]) return false;
		i++;
	}

	return true;

}

bool compare_strings(char* str1, const char* str2) {
	int i = 0;

	while (str1[i] != '\0' || str2[i] != '\0') {
		if (str1[i] != str2[i]) return false;
		i++;
	}

	return true;

}



char* strip_a_string(char*& string, char separator) {
	int size = str_len(string);

	char* stripped = new char[size + 1];

	bool del_whites = true;
	//strip front whites
	int j = 0;
	for (int i = 0; i < size; i++) {
		if (string[i] < 33) {
			if (del_whites) {
				continue;
			}
			else {
				del_whites = if_whites_to_del(string, separator, i);
				if (del_whites) continue;
				else {
					stripped[j] = string[i];
					j++;
				}
			}
		}
		else if (string[i] == separator) {
			stripped[j] = string[i];
			j++;
			del_whites = true;
		}
		else {
			stripped[j] = string[i];
			j++;
			del_whites = false;
		}

	}
	stripped[j] = '\0';


	return stripped;



}




class Parser {
	Node* main_node;
	//long int last_free_sect;


	//wskaznik na ostanit wezel;
	Node* tail;


public:


	section* init_sections() {
		section* sect = new section[T];
		for (int i = 0; i < T; i++) {
			sect[i].if_empt = true;
			sect[i].if_deleted = false;
			sect[i].atributes = NULL;
			sect[i].selectors = NULL;
			sect[i].amount_of_selecs = 0;
			sect[i].amount_of_atributes = 0;

		}
		return sect;
	}


	Parser() {
		//last_free_sect = 0;
		main_node = new Node;
		main_node->next_node = NULL;
		main_node->prev_node = NULL;
		main_node->eight_sections = init_sections();
		tail = main_node;

	}


	long int get_list_lenght() {
		long int lenght = 0;
		Node* tmp = main_node;
		while (tmp->next_node != NULL) {
			lenght++;
			tmp = tmp->next_node;
		}
		return lenght;
	}


	Node* get_main_node() {
		return main_node;
	}

	void insert_end() {
		//insert_empty_node

		Node* newNode = new Node;

		Node* last = main_node;

		newNode->next_node = NULL;

		newNode->eight_sections = init_sections();

		while (last->next_node != NULL) {
			last = last->next_node;
		}
		last->next_node = newNode;
		newNode->prev_node = last;

	}


	section get_nth_section(int n) {
		int ind = 1;
		int i = 0;

		Node* tmp_list = main_node;


		while (1) {

			if (i == T && tmp_list->next_node != NULL) {
				tmp_list = tmp_list->next_node;
				i = 0;

			}

			else if (i == T && tmp_list->next_node == NULL) {
				return { NULL,NULL };
			}

			if (ind == n) {
				return tmp_list->eight_sections[i];
			}


			if (!tmp_list->eight_sections[i].if_empt) {
				ind++;
			}
			i++;

		}

	}


	section* get_nth_section_pointer(int n) {
		int ind = 1;
		int i = 0;

		Node* tmp_list = main_node;


		while (1) {

			if (i == T && tmp_list->next_node != NULL) {
				tmp_list = tmp_list->next_node;
				i = 0;

			}

			if (ind == n) {
				return &tmp_list->eight_sections[i];
			}

			else if (i == T && tmp_list->next_node == NULL) {
				return  NULL;
			}


			if (!tmp_list->eight_sections[i].if_empt) {
				ind++;
			}
			i++;




			/*
						if(ind == n) return tmp_list->eight_sections[i];
						i++;
						ind++;
						if (i == T) {
							if (tmp_list->next_node != NULL) {
								tmp_list = tmp_list->next_node;
								i = 0;
							}
							else {
								return { NULL,NULL };
							}


						}
						*/
		}

	}


	void input_a_section(section section) {

		Node* tmp_list = main_node;

		int i = 0;


		//wskaznik na ostani wezel




		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {

				Node* new_node = new Node;
				tail = new_node;
				new_node->prev_node = tmp_list;
				new_node->next_node = NULL;
				tmp_list->next_node = new_node;
				new_node->eight_sections = init_sections();
				new_node->eight_sections[0] = section;
				new_node->eight_sections[0].if_empt = false;
				return;
			}



			if (tmp_list->eight_sections[i].if_empt && !tmp_list->eight_sections[i].if_deleted) {
				tmp_list->eight_sections[i] = section;
				tmp_list->eight_sections[i].if_empt = false;
				return;
			}
			i++;
		}

	}

	void run() {
		bool MODE_TC_FCO = true; // true = css reading  false = command reading
		int cur_section_len = 0;
		int cur_size_mltpr = 1;
		int size = MX_GETS;
		char* section_string = new char[size];
		char* tmp_string = new char[MX_GETS];
		char to_cmd[] = { '?','?','?','?', '\0' };
		char to_red[] = { '*','*','*','*','\0' };

		while (fgets(tmp_string, MX_GETS, stdin)) {

			char* mode_change_checker = strip_a_string(tmp_string, ' ');

			if (MODE_TC_FCO) {
				//reading mode
				if (compare_strings(mode_change_checker, to_cmd)) {

					MODE_TC_FCO = false;
					continue;
				}

				if (cur_section_len + str_len(tmp_string) + 10 >= size) {
					section_string = resize(section_string, size);
					size *= 2;
				}

				paste_onto_pos(tmp_string, section_string, cur_section_len);
				cur_section_len += str_len(tmp_string);

				if (look_for_char(tmp_string, '}')) {

					section_string[cur_section_len] = '\0';

					//input_a_section(distr_to_sect(section_string));
					input_a_section(distr_to_sect_v2(section_string));
					cur_section_len = 0;

				}

			}
			else {
				//command mode

				if (compare_strings(mode_change_checker, to_red)) {
					MODE_TC_FCO = true;
					continue;
				}


				command_handler(tmp_string);

			}










			//do testow
			/*
			if (look_for_char(tmp_string, 'Q')) {
				section_string[cur_section_len + 1] = '\0';
				print_all_sections();
			}
			else if (look_for_char(tmp_string, 'F')) {
				std::cout << tmp_string[1] << std::endl;
				section_string[cur_section_len + 1] = '\0';
				print_section(get_nth_section(tmp_string[1] % 48));
			}
			*/
			
		}

	}





	void command_handler(char* command_str) {

		char* tmp = strip_a_string(command_str, ',');


		if (tmp[0] == '?') {

			count_CSS_sections_COMMAND();
		}
		else if (count_chars(tmp, ',') != 2) {

			return;
			//mozliwe ze do poprawki
		}
		else {
			int w_o = 0;
			int j = 0;
			char* first_option = new char[33];
			char* scnd_option = new char[33];
			char* third_option = new char[33];

			for (int i = 0; i < str_len(tmp); i++) {

				if (tmp[i] == ',') {
					if (w_o == 0) {
						first_option[j] = '\0';
					}
					else if (w_o == 1) {
						scnd_option[j] = '\0';
					}

					w_o++;
					i++;
					j = 0;
				}

				if (w_o == 0) {
					first_option[j] = tmp[i];
					j++;
				}
				else if (w_o == 1) {
					scnd_option[j] = tmp[i];
					j++;
				}
				else if (w_o == 2) {
					third_option[j] = tmp[i];
					j++;
				}
				if (i + 1 == str_len(tmp)) {
					third_option[j] = '\0';
				}
			}


			if (scnd_option[0] == 'S') {

				S_type_command_handler(first_option, third_option);

			}
			else if (scnd_option[0] == 'A') {

				A_type_command_handler(first_option, third_option);

			}
			else if (scnd_option[0] == 'E') {
				//z,E,n – wypisz wartość atrybutu o nazwie n dla selektora z
				//, w przypadku wielu wystąpień selektora z bierzemy ostatnie. W przypadku braku pomiń;


				E_command_handler(first_option, third_option);

			}
			else if (scnd_option[0] == 'D') {
				D_type_command_handler(first_option, third_option);
			}














		}
	}

	void D_type_command_handler(char* first_option, char* third_option) {

		if (third_option[0] == '*') {
			delete_ith_section(change_str_to_int(first_option));
		}
		else {
			delete_atrib_N_in_I_sect(change_str_to_int(first_option), third_option);
		}



	}

	void delete_atrib_N_in_I_sect(int i, char* n) {
		section* tmp_sect = get_nth_sect_pointer_v2(i);
		
		atribute* curr_atrib = tmp_sect->atributes;

		atribute* to_del;

		char* wanted_string = curr_atrib->properties;


		if (curr_atrib == nullptr) return;


		if (compare_strings(n, wanted_string)) {

			tmp_sect->atributes = curr_atrib->next;
			delete curr_atrib;
			tmp_sect->amount_of_atributes--;

			std::cout << i << ",D," << n << " == deleted" << std::endl;

			if (tmp_sect->amount_of_atributes == 0) {
				delete_ith_section_sub(i);
			}
			return;

		}



		while (1) {

			if (compare_strings(curr_atrib->next->properties, wanted_string)) {
				
				if (curr_atrib->next->next == NULL) {
					delete curr_atrib->next;
					curr_atrib->next = NULL;
					tmp_sect->amount_of_atributes--;
					
				}
				else {
					
					to_del = curr_atrib->next;
					curr_atrib->next = curr_atrib->next->next;
					delete to_del;
					tmp_sect->amount_of_atributes--;
					

				}
				std::cout << i << ",D," << n << " == deleted" << std::endl;
				break;


			}
			else {

				if (curr_atrib->next->next == NULL) {
					return;
				}
				else {
					curr_atrib = curr_atrib->next;
					wanted_string = curr_atrib->properties;
				}


			}


		}
		
		if (tmp_sect->amount_of_atributes == 0) {
			delete_ith_section_sub(i);
		}

	}




	bool check_if_empt_node(Node* node) {
		for (int i = 0; i < T; i++) {
			if (!node->eight_sections[i].if_empt) return false;
		}

		return true;
	}








	void delete_ith_section(int n) {
		Node* tmp_list = main_node;

		int indeks = 1;
		int i = 0;



		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {
				return;
			}

			if (indeks == n && !tmp_list->eight_sections[i].if_empt) {
				tmp_list->eight_sections[i].if_deleted = true;
				tmp_list->eight_sections[i].if_empt = true;
				if (check_if_empt_node(tmp_list) && tmp_list != main_node) {
					
					if (tmp_list->next_node == NULL) {

						tmp_list->prev_node->next_node = NULL;
						delete[] tmp_list->eight_sections;
						delete tmp_list;

					}
					else {
						tmp_list->prev_node->next_node = tmp_list->next_node;
						tmp_list->next_node->prev_node = tmp_list->prev_node;
						delete[] tmp_list->eight_sections;
						delete tmp_list;
					}
				}
				else if (check_if_empt_node(tmp_list) && tmp_list == main_node) {
					if (tmp_list->next_node == NULL) {

						tmp_list->next_node->prev_node = NULL;
						main_node = tmp_list->next_node;
						delete[] tmp_list->eight_sections;
						delete tmp_list;

					}
				}
				std::cout << indeks << ",D,* == deleted" << std::endl;
				return;
			}




			if (!tmp_list->eight_sections[i].if_empt) {
				indeks++;
			}

				i++;

		}

	}



	void delete_ith_section_sub(int n) {
		Node* tmp_list = main_node;

		int indeks = 1;
		int i = 0;



		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {
				return;
			}

			if (indeks == n && !tmp_list->eight_sections[i].if_empt) {
				tmp_list->eight_sections[i].if_deleted = true;
				tmp_list->eight_sections[i].if_empt = true;
				if (check_if_empt_node(tmp_list) && tmp_list != main_node) {

					if (tmp_list->next_node == NULL) {

						tmp_list->prev_node->next_node = NULL;
						delete[] tmp_list->eight_sections;
						delete tmp_list;

					}
					else {
						tmp_list->prev_node->next_node = tmp_list->next_node;
						tmp_list->next_node->prev_node = tmp_list->prev_node;
						delete[] tmp_list->eight_sections;
						delete tmp_list;
					}
				}
				else if (check_if_empt_node(tmp_list) && tmp_list == main_node) {
					if (tmp_list->next_node == NULL) {

						tmp_list->next_node->prev_node = NULL;
						main_node = tmp_list->next_node;
						delete[] tmp_list->eight_sections;
						delete tmp_list;

					}
				}
				
				return;
			}




			if (!tmp_list->eight_sections[i].if_empt) {
				indeks++;
			}

			i++;

		}

	}













	void E_command_handler(char* z, char* n) {
		Node* tmp_list = tail;

		int i = T - 1;

		while (1) {

			if (tmp_list->prev_node != NULL && i == -1) {
				i = T - 1;
				tmp_list = tmp_list->prev_node;
			}
			else if (tmp_list->prev_node == NULL && i == -1) {
				return;
			}

			if (!tmp_list->eight_sections[i].if_empt) {

				selector* tmp = tmp_list->eight_sections[i].selectors;


				while (1) {

					if (tmp == NULL) break;
					if (tmp->next == NULL) {
						if (compare_strings(z, tmp->name)) {

							atribute* tmp_atr = tmp_list->eight_sections[i].atributes;

							while (1) {

								if (tmp_atr == NULL) break;
								if (compare_strings(tmp_atr->properties, n)) {
									std::cout << z << ",E," << n << " == " << tmp_atr->values << std::endl;
									return;
								}
								tmp_atr = tmp_atr->next;
							}

						}
						break;
					}
					else {
						if (compare_strings(z, tmp->name)) {
							atribute* tmp_atr = tmp_list->eight_sections[i].atributes;

							while (1) {


								if (tmp_atr == NULL) break;
								if (compare_strings(tmp_atr->properties, n)) {
									std::cout << z << ",E," << n << " == " << tmp_atr->values << std::endl;
									return;
								}
								tmp_atr = tmp_atr->next;

							}

						}
						tmp = tmp->next;
					}


				}

			}


			i--;
		}



	}



	void count_CSS_sections_COMMAND() {
		Node* tmp_list = main_node;

		int i = 0;

		int AM_OF_SEC_OUT = 0;


		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {
				std::cout << "? == " << AM_OF_SEC_OUT << std::endl;
				return;
			}



			if (!tmp_list->eight_sections[i].if_empt && tmp_list->eight_sections[i].if_deleted) AM_OF_SEC_OUT++;
			i++;

		}

	}
	void S_type_command_handler(char* first_option, char* third_option) {

		if ((int)first_option[0] < 48 || (int)first_option[0] > 57) {
			//z,S,? – wypisz łączną (dla wszystkich bloków) liczbę wystąpień selektora z. Możliwe jest 0;
			count_Z_selector_occurances(first_option);
		}
		else {
			if (third_option[0] == '?') {
				//i,S,? – wypisz liczbę selektorów dla sekcji nr i (numery zaczynają się od 1),
				//jeśli nie ma takiego bloku pomiń;

				amount_of_selecs_for_ith_section(change_str_to_int(first_option));

			}
			else {
				//i,S,j – wypisz j-ty selector dla i-tego bloku (numery sekcji oraz atrybutów zaczynają się od 1)
				//jeśli nie ma sekcji lub selektora pomiń

				write_J_selec_for_I_sect(change_str_to_int(first_option), change_str_to_int(third_option));
			}
		}

	}

	void count_Z_selector_occurances(char* z) {
		int out = 0;

		Node* tmp_list = main_node;

		int i = 0;


		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {
				std::cout << z << ",S,? == " << out << std::endl;
				return;
			}

			if (!tmp_list->eight_sections[i].if_empt) {

				selector* tmp = tmp_list->eight_sections[i].selectors;



				while (1) {
					if (tmp == NULL) break;
					if (tmp->next == NULL) {
						if (compare_strings(z, tmp->name)) out++;
						break;
					}
					else {
						if (compare_strings(z, tmp->name)) out++;
						tmp = tmp->next;
					}
				}

			}

			i++;


		}
	}

	void amount_of_selecs_for_ith_section(int i) {
		section out = get_nth_sect_v2(i);
		if (out.atributes != NULL && !out.if_empt) {
			std::cout << i << ",S,? == " << out.amount_of_selecs << std::endl;
		}
	}

	void write_J_selec_for_I_sect(int i, int j) {
		selector* tmp = get_nth_sect_v2(i).selectors;

		if (tmp == NULL) {
			return;
		}

		int ind = 1;

		while (1) {
			if (tmp->next == NULL) {
				if (ind == j) {
					std::cout << i << ",S," << j << " == " << tmp->name << std::endl;
					return;
				}
				else {
					return;
				}
			}

			if (ind == j) {
				std::cout << i << ",S," << j << " == " << tmp->name << std::endl;
				return;
			}
			else {
				tmp = tmp->next;
				ind++;
			}


		}

	}




	void A_type_command_handler(char* first_opt, char* third_opt) {
		if ((int)first_opt[0] < 48 || (int)first_opt[0] > 57) {

			//wypisz łączną (dla wszystkich bloków) liczbę wystąpień atrybutu nazwie n.
			if (third_opt[0] == '?') {

				count_N_atribute_occurances(first_opt);
			}




		}
		else {
			if (third_opt[0] == '?') {
				//i,S,? – wypisz liczbę selektorów dla sekcji nr i (numery zaczynają się od 1),
				//jeśli nie ma takiego bloku pomiń;

				amount_of_atribs_for_ith_section(change_str_to_int(first_opt));

			}
			else {

				//i, A, n – wypisz dla i - tej sekcji wartość atrybutu o nazwie n, jeśli nie ma takiego pomiń;
				value_of_N_prop_I_sect(change_str_to_int(first_opt), third_opt);

			}
		}





	}

	void value_of_N_prop_I_sect(int i, char* n) {
		atribute* tmp = get_nth_sect_v2(i).atributes;

		if (tmp == NULL) {
			return;
		}


		while (1) {

			if (tmp->next == NULL) {
				if (compare_strings(n, tmp->properties)) {
					std::cout << i << ",A," << n << " == " << tmp->values << std::endl;
					return;
				}
				else {
					return;
				}

			}

			if (compare_strings(n, tmp->properties)) {
				std::cout << i << ",A," << n << " == " << tmp->values << std::endl;
				return;
			}
			else {
				tmp = tmp->next;
			}


		}


	}











	void count_N_atribute_occurances(char* N) {
		int out = 0;

		Node* tmp_list = main_node;

		int i = 0;


		while (1) {

			if (tmp_list->next_node != NULL && i == T) {
				i = 0;
				tmp_list = tmp_list->next_node;
			}
			else if (tmp_list->next_node == NULL && i == T) {
				std::cout << N << ",A,? == " << out << std::endl;
				return;
			}

			if (!tmp_list->eight_sections[i].if_empt) {

				atribute* tmp = tmp_list->eight_sections[i].atributes;



				while (1) {
					if (tmp == NULL) break;
					if (tmp->next == NULL) {
						if (compare_strings(N, tmp->properties)) out++;
						break;
					}
					else {
						if (compare_strings(N, tmp->properties)) out++;
						tmp = tmp->next;
					}
				}

			}

			i++;


		}









	}



	void amount_of_atribs_for_ith_section(int i) {
		section out = get_nth_sect_v2(i);

		if (out.atributes != NULL && !out.if_empt) {
			std::cout << i << ",A,? == " << out.amount_of_atributes << std::endl;
		}

	}

























	//do testowania


	selector* distr_to_selec(char* input) {

		char* tmp = strip_a_string(input, ',');
		int size = str_len(tmp);


		selector* out = new selector;
		selector* tmp_out = out;

		out->prev = NULL;

		int j = 0;

		for (int i = 0; i < count_chars(tmp, ',') + 1; i++) {
			tmp_out->name = new char[MX_SELEC_SIZE];
			if (i != count_chars(tmp, ',')) {
				tmp_out->next = new selector;
				tmp_out->next->prev = tmp_out;
				tmp_out = tmp_out->next;
			}
			else {
				tmp_out->next = NULL;
			}
		}

		tmp_out = out;


		for (int i = 0; i < size; i++) {
			if (tmp[i] == ',') {
				tmp_out->name[j] = '\0';
				tmp_out = tmp_out->next;
				j = 0;

			}
			else {
				tmp_out->name[j] = tmp[i];
				j++;
			}
			if (i + 1 == size) {
				tmp_out->name[j] = '\0';
			}
		}
		tmp_out->next = NULL;

		return out;

	}


	atribute* distr_to_atrib(char* input) {
		char* tmp = strip_a_string(input, ';');
		tmp = strip_a_string(tmp, ':');
		int size = str_len(tmp);
		int am_of_atrs;
		atribute* out;
		if (tmp[size - 1] == ';') {
			am_of_atrs = count_chars(tmp, ';');
			size--;
		}
		else {
			am_of_atrs = count_chars(tmp, ';') + 1;

		}

		out = new atribute;
		atribute* tmp_out = out;

		out->prev = NULL;

		for (int i = 0; i < am_of_atrs; i++) {

			tmp_out->properties = new char[MX_SELEC_SIZE];
			tmp_out->values = new char[MX_SELEC_SIZE];

			if (i + 1 != am_of_atrs) {
				tmp_out->next = new atribute;
				tmp_out->next->prev = tmp_out;
				tmp_out = tmp_out->next;
			}
			else {
				tmp_out->next = NULL;
			}
		}

		int curr_atrib = 0;
		int j = 0;
		bool p_t_v_f = true;

		tmp_out = out;


		for (int i = 0; i < size; i++) {
			if (tmp[i] == ';') {
				tmp_out->values[j] = '\0';
				tmp_out = tmp_out->next;
				j = 0;


				p_t_v_f = true;

			}
			else if (tmp[i] == ':') {
				tmp_out->properties[j] = '\0';
				j = 0;
				p_t_v_f = false;
			}
			else {
				if (p_t_v_f) {
					tmp_out->properties[j] = tmp[i];
				}
				else {
					tmp_out->values[j] = tmp[i];
				}
				j++;
			}

			if (i + 1 == size) {
				tmp_out->values[j] = '\0';
			}



		}


		return out;

	}





	void check_for_reps_v2(section& sect) {
		atribute* curr_atrib = sect.atributes;
		atribute* sub_curr_atrib;
		atribute* to_del;
		int del = 0;

		if (curr_atrib == nullptr) {
			return;
		}


		while (curr_atrib->next != nullptr) {
			sub_curr_atrib = curr_atrib;

			while (sub_curr_atrib->next != nullptr) {

				if (compare_strings(sub_curr_atrib->next->properties, curr_atrib->properties)) {

					curr_atrib->values = sub_curr_atrib->next->values;
					del++;

					if (sub_curr_atrib->next->next == NULL) {
						delete sub_curr_atrib->next;
						sub_curr_atrib->next = NULL;

					}
					else {
						to_del = sub_curr_atrib->next;
						sub_curr_atrib->next = sub_curr_atrib->next->next;

					}
					sub_curr_atrib = curr_atrib;

				}
				else {
					sub_curr_atrib = sub_curr_atrib->next;
				}

			}
			if (curr_atrib->next == NULL) {
				break;
			}

			curr_atrib = curr_atrib->next;

		}




		sect.amount_of_atributes -= del;



	}



	void check_for_reps_selecs(section& sect) {

		selector* tmp_selec = sect.selectors;
		selector* sub_tmp_selec;
		selector* to_del;
		int to_del_selecs = 0;

		char* string_to_del;

		if (tmp_selec == NULL) {
			return;
		}


		while (1) {
			if (tmp_selec == NULL) break;

			string_to_del = tmp_selec->name;

			sub_tmp_selec = tmp_selec->next;

			if (tmp_selec->next == NULL) { break; }

			while (sub_tmp_selec != NULL) {
				if (compare_strings(sub_tmp_selec->name, string_to_del)) {

					to_del_selecs++;

					if (sub_tmp_selec->next == NULL) {
						sub_tmp_selec->prev->next = NULL;

						delete sub_tmp_selec;
						break;
					}
					else {
						sub_tmp_selec->prev->next = sub_tmp_selec->next;
						sub_tmp_selec->next->prev = sub_tmp_selec->prev;
						to_del = sub_tmp_selec;
						sub_tmp_selec = sub_tmp_selec->prev;

						delete to_del;


					}

				}
				else {
					if (sub_tmp_selec->next == NULL) {
						break;
					}
					else {
						sub_tmp_selec = sub_tmp_selec->next;
					}
				}



			}

			if (tmp_selec->next == NULL) {
				break;
			}

			tmp_selec = tmp_selec->next;



		}

		sect.amount_of_selecs -= to_del_selecs;

	}

	section get_nth_sect_v2(int n) {

		Node* tmp_node = main_node;


		int curr_indeks = 1;
		int i = 0;


		while (1) {

			if (i == T) {
				
				if (tmp_node->next_node == NULL) {
					return { NULL,NULL };
				}
				else {
					tmp_node = tmp_node->next_node;
					i = 0;
				}

			}

			if (curr_indeks == n && !tmp_node->eight_sections[i].if_empt) {
				return tmp_node->eight_sections[i];
			}

			if (!tmp_node->eight_sections[i].if_empt)curr_indeks++;


			i++;
		}



	}


	section* get_nth_sect_pointer_v2(int n) {

		Node* tmp_node = main_node;


		int curr_indeks = 1;
		int i = 0;


		while (1) {

			if (i == T) {

				if (tmp_node->next_node == NULL) {
					return NULL;
				}
				else {
					tmp_node = tmp_node->next_node;
					i = 0;
				}

			}

			if (curr_indeks == n && !tmp_node->eight_sections[i].if_empt) {
				return &tmp_node->eight_sections[i];
			}

			if (!tmp_node->eight_sections[i].if_empt)curr_indeks++;


			i++;
		}



	}









	void check_for_reps_selecs_v2(section& sect) {
		selector* curr_selec = sect.selectors;
		selector* sub_curr_selec;
		selector* to_del;
		int del = 0;

		if (curr_selec == nullptr) {
			return;
		}


		while (curr_selec->next != nullptr) {
			sub_curr_selec = curr_selec;

			while (sub_curr_selec->next != nullptr) {

				if (compare_strings(sub_curr_selec->next->name, curr_selec->name)) {


					del++;

					if (sub_curr_selec->next->next == NULL) {
						delete sub_curr_selec->next;
						sub_curr_selec->next = NULL;

					}
					else {
						to_del = sub_curr_selec->next;
						sub_curr_selec->next = sub_curr_selec->next->next;

					}
					sub_curr_selec = curr_selec;

				}
				else {
					sub_curr_selec = sub_curr_selec->next;
				}

			}
			if (curr_selec->next == NULL) {
				break;
			}

			curr_selec = curr_selec->next;

		}




		sect.amount_of_selecs -= del;


	}








	section distr_to_sect(char* input) {

		char* tmp = strip_a_string(input, ',');
		int selec_size = len_until_char(tmp, '{', 0);
		char* new_selecs = new char[selec_size + 1];

		new_selecs[selec_size] = '\0';

		for (int i = 0; i < selec_size; i++) {
			new_selecs[i] = tmp[i];
		}

		int atrib_size = len_until_char(tmp, '}', 0) - selec_size - 1;
		char* new_atribs = new char[atrib_size + 1];
		new_atribs[atrib_size] = '\0';
		for (int i = 0; i < atrib_size; i++) {
			new_atribs[i] = tmp[i + selec_size + 1];
		}


		tmp = strip_a_string(new_atribs, ';');


		section* section_out = new section;
		section_out->if_empt = false;
		if (selec_size > 0) {
			section_out->amount_of_selecs = count_chars(new_selecs, ',') + 1;
			section_out->selectors = distr_to_selec(new_selecs);
		}
		else {
			section_out->amount_of_selecs = 0;
			section_out->selectors = NULL;
		}



		if (tmp[str_len(tmp) - 1] == ';') {
			section_out->amount_of_atributes = count_chars(new_atribs, ';');
		}
		else {
			section_out->amount_of_atributes = count_chars(new_atribs, ';') + 1;
		}

		section_out->atributes = distr_to_atrib(new_atribs);

		//check_for_atr_name_rep(*section_out);
		check_for_reps_v2(*section_out);

		delete[] new_atribs, new_selecs;

		return *section_out;



	}

	section distr_to_sect_v2(char* input) {
		char* tmp = input;
		char* tmp_2 = strip_a_string(input, ',');
		tmp_2 = strip_a_string(tmp_2, ';');
		int selec_size = len_until_char(tmp, '{', 0);
		int atrib_size = len_until_char(tmp, '}', 0) - selec_size - 1;
		char* tmp_selecs = new char[selec_size];
		char* tmp_atribs = new char[atrib_size];
		char* new_selecs;
		char* new_atribs;



		for (int i = 0; i < selec_size; i++) {
			tmp_selecs[i] = tmp[i];
		}
		tmp_selecs[selec_size] = '\0';

		for (int i = 0; i < atrib_size; i++) {
			tmp_atribs[i] = tmp[i + selec_size + 1];
		}
		tmp_atribs[atrib_size] = '\0';

		new_selecs = strip_a_string(tmp_selecs, ',');
		new_atribs = strip_a_string(tmp_atribs, ';');



		section* section_out = new section;
		section_out->if_empt = false;
		if (selec_size > 0) {
			section_out->amount_of_selecs = count_chars(new_selecs, ',') + 1;
			section_out->selectors = distr_to_selec(new_selecs);
		}
		else {
			section_out->amount_of_selecs = 0;
			section_out->selectors = NULL;
		}



		if (tmp_2[str_len(tmp_2) - 2] == ';') {
			section_out->amount_of_atributes = count_chars(new_atribs, ';');
		}
		else {
			section_out->amount_of_atributes = count_chars(new_atribs, ';') + 1;
		}

		section_out->atributes = distr_to_atrib(new_atribs);

		//check_for_atr_name_rep(*section_out);
		check_for_reps_v2(*section_out);
		check_for_reps_selecs_v2(*section_out);


		delete[] new_atribs, new_selecs;

		return *section_out;



	}



	void print_atribs(atribute* atribs) const {
		std::cout << "Atrybuty: " << std::endl;
		atribute* tmp_atr = atribs;
		while (tmp_atr->next != NULL) {
			std::cout << "Prop: " << tmp_atr->properties << '\n';
			std::cout << "Value: " << tmp_atr->values << '\n';
			tmp_atr = tmp_atr->next;
		}
		std::cout << "Prop: " << tmp_atr->properties << '\n';
		std::cout << "Value: " << tmp_atr->values << '\n';

	}

	void print_selectors(selector* selecs) const {
		std::cout << "Selektory: " << std::endl;
		selector* tmp_selec = selecs;

		if (tmp_selec == NULL) {
			return;
		}

		while (tmp_selec->next != NULL) {
			std::cout << tmp_selec->name << '\n';
			tmp_selec = tmp_selec->next;

		}
		std::cout << tmp_selec->name << '\n';
	}

	void print_section(section sect) const {
		if (sect.if_empt) {
			std::cout << "EMPTY" << std::endl;

		}
		else {
			print_selectors(sect.selectors);
			std::cout << std::endl;
			print_atribs(sect.atributes);
		}
	}



	char* test_get_input() {

		int cur_section_len = 0;
		int size = MX_GETS;
		char* section_string = new char[size];
		char* tmp_string = new char[MX_GETS];

		while (true) {

			fgets(tmp_string, MX_GETS, stdin);
			if (cur_section_len + str_len(tmp_string) + 10 >= size) {
				section_string = resize(section_string, size);
				size *= 2;
			}

			paste_onto_pos(tmp_string, section_string, cur_section_len);
			cur_section_len += str_len(tmp_string);






			//do testow

			if (look_for_char(tmp_string, '}')) {
				section_string[cur_section_len] = '\0';
				break;
			}
		}
		return section_string;
	}



	/*

		void print_section(section sect) const {
			if (sect.atributes == NULL) {
				std::cout << "Selektors: ";
				std::cout << std::endl;
				std::cout << "Atrybuty: ";
				std::cout << std::endl;

			}
			else {
				std::cout << "Selektors: ";
				std::cout << sect.selectors << std::endl;
				std::cout << "Atrybuty: ";
				std::cout << sect.atributes << std::endl;
			}
		}


		*/

	void print_all_sections() const {
		
		int i = 0;
		int curr_node = 0;
		Node* tmp_list = main_node;

		std::cout << "Sekcje: {" << std::endl;

		while (1) {


			if (i == T && tmp_list->next_node != NULL) {
				i = 0;
				tmp_list = tmp_list->next_node;
				curr_node++;
			}

			if (i == T && tmp_list->next_node == NULL) {
				std::cout << "} \n";
					return;
			}
			if (!tmp_list->eight_sections[i].if_empt){
				std::cout << "Sekcja nr." << i + T * curr_node << std::endl;
				print_section(tmp_list->eight_sections[i]);
			}
			
			i++;
		}
		std::cout << "} \n";
	}

};






int main() {

	Parser main_parser;


	main_parser.run();








	return 1;
}

