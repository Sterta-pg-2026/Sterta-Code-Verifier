#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#define NUMBER_OF_CHARS_TO_INT 32
#define STRING_BUFFER 32
#define AMOUNT_OF_BLOCKS_IN_BLOCK_LIST 8

using namespace std;


struct section;
struct block_list;
struct selector_list_struct;
struct attribute_list_struct;
struct attribute;
class d_linked_list_selectors;
class d_linked_list_attributes;

char* char_copy_array(char* destination, const char* source)
{
    if (destination == NULL) {
        return NULL;
    }
    char* ptr = destination;
    while (*source != '\0')
    {
        *destination = *source;
        destination++;
        source++;
    }
    *destination = '\0';
    return ptr;
}

unsigned int size_of_char_array(const char *s)
{
    unsigned int count = 0;
    while(*s != '\0')
    {
        count++;
        s++;
    }
    return count;
}

bool compare_char_array(const char* str1, const char* str2)
{
    while (*str1 == *str2) {
        if (*str1 == '\0' || *str2 == '\0')
            break;
        str1++;
        str2++;
    }
    if (*str1 == '\0' && *str2 == '\0')
        return true;
    return false;
}

char* cat_char_array(char* s1, const char* s2)
{
    if ((s1 == NULL) && (s2 == NULL))
        return NULL;
    char* start = s1;
    while (*start != '\0')
        start++;

    while (*s2 != '\0')
        *start++ = *s2++;

    *start = '\0';
    return s1;
}

class superstring {
public:
    char* buffer;
    int lenght;
    int max_lenght;
    superstring() : buffer(nullptr), lenght(0), max_lenght(STRING_BUFFER) {
        buffer = new char[max_lenght];
        for (int i = 0; i < max_lenght; i++)
            buffer[i] = '\0';
    }

    superstring(const superstring& other) : buffer(nullptr), lenght(0), max_lenght(other.lenght + STRING_BUFFER) {
        *this = other;
    }

    superstring(const char* str) : buffer(nullptr), lenght(0), max_lenght(STRING_BUFFER) {
        int str_lenght = size_of_char_array(str);
        if (str_lenght > max_lenght) {
            max_lenght = str_lenght + STRING_BUFFER;
        }
        buffer = new char[max_lenght];
        char_copy_array(buffer, str);
        lenght = str_lenght;
    }

    superstring& operator=(const superstring& other) {
        delete[] buffer;
        lenght = other.lenght;
        max_lenght = other.max_lenght;
        buffer = new char[max_lenght];
        char_copy_array(buffer, other.buffer);
        return *this;
    }

    bool operator!=(superstring& secdond_string) {
        return !compare_char_array(buffer, secdond_string.buffer);
    }

    bool operator!=(const char* secdond_string) {
        return !compare_char_array(buffer, secdond_string);
    }

    bool operator==(const char* arr) {
        return compare_char_array(buffer, arr);
    }

    bool operator==(superstring& str) {
        return compare_char_array(buffer, str.buffer);
    }

    char operator[](const int index) {
        return this->buffer[index];
    }

    superstring& str_cat(const char& character) {
        if (lenght + 1 >= max_lenght) {
            max_lenght = max_lenght + STRING_BUFFER;
            char* new_buffer = new char[max_lenght];
            char_copy_array(new_buffer, buffer);
            delete[] buffer;
            buffer = new_buffer;
        }
        lenght++;
        buffer[lenght-1] = character;
        buffer[lenght] = '\0';
        return *this;
    }

    superstring& str_cat(superstring& other) {
        int new_lenght = lenght + other.lenght;
        if (new_lenght >= max_lenght) {
            max_lenght = new_lenght + STRING_BUFFER;
            char* new_buffer = new char[max_lenght];
            char_copy_array(new_buffer, buffer);
            delete[] buffer;
            buffer = new_buffer;
        }
        cat_char_array(buffer, other.buffer);
        lenght = new_lenght;
        return *this;
    }

    superstring& str_cat(const char* str) {
        int str_lenght = size_of_char_array(str);
        if (lenght + str_lenght >= max_lenght) {
            int sum = lenght + str_lenght;
            max_lenght = sum + STRING_BUFFER;
            char* new_buffer = new char[max_lenght];
            char_copy_array(new_buffer, buffer);
            delete[] buffer;
            buffer = new_buffer;
        }
        cat_char_array(buffer, str);
        lenght = lenght + str_lenght;
        return *this;
    }

    ~superstring() {
        delete[] buffer;
    }
};

ostream& operator<<(std::ostream& cout, const superstring& obj) {
    cout << obj.buffer;
    return cout;
}

struct selector_list_struct {
    selector_list_struct* prev = nullptr;
    superstring name;
    selector_list_struct* next = nullptr;
};

struct attribute {
    superstring name;
    superstring value;
};

struct attribute_list_struct {
    attribute_list_struct* prev;
    attribute attr;
    attribute_list_struct* next;
};

struct section {
    d_linked_list_selectors* selector_list = nullptr;
    d_linked_list_attributes* attribute_list = nullptr;
    bool deleted = false;
    int counter = 0;
};

struct block_list {
    block_list* prev = nullptr;
    section* sections = new section[AMOUNT_OF_BLOCKS_IN_BLOCK_LIST];
    block_list* next = nullptr;
    int amount_of_sections = 0;
    int actual_sections = 0;
};


class d_linked_list_attributes {
public:
    attribute_list_struct* head_node = nullptr;
    int amountOfBlocks = 0;
public:
    d_linked_list_attributes() {
        attribute_list_struct* head = new attribute_list_struct;
        head->prev = nullptr;
        head->next = nullptr;
        head_node = head;
    }

    void add_new_block_to_list(attribute_list_struct* next_block_list) {
        if (amountOfBlocks == 0) {
            head_node = next_block_list;
            head_node->next = nullptr;
            head_node->prev = nullptr;
            amountOfBlocks++;
        }
        else {
            attribute_list_struct* last = head_node;
            while (last->next != nullptr) {
                last = last->next;
            }
            last->next = next_block_list;
            next_block_list->prev = last;
            amountOfBlocks++;
        }
    }

    attribute_list_struct* get_last() {
        attribute_list_struct* last = head_node;
        while (last->next != nullptr) {
            last = last->next;
        }
        return last;
    }

    ~d_linked_list_attributes() {
        attribute_list_struct* temp = get_last();
        if (temp != nullptr) {
            while (temp != nullptr) {
                attribute_list_struct* temp2 = temp->prev;
                delete temp;
                temp = temp2;
            }
        }
    }
};

class d_linked_list_selectors{
public:
    selector_list_struct* head_node = nullptr;
    int amountOfBlocks = 0;
public:
    d_linked_list_selectors() {
        selector_list_struct* head = new selector_list_struct;
        head->prev = nullptr;
        head->next = nullptr;
        head_node = head;
    }

    void add_new_block_to_list(selector_list_struct* next_block_list) {
        if (amountOfBlocks == 0) {
            head_node = next_block_list;
            head_node->next = nullptr;
            head_node->prev = nullptr;
            amountOfBlocks++;
        }
        else {
            selector_list_struct* last = head_node;
            while (last->next != nullptr) {
                last = last->next;
            }
            last->next = next_block_list;
            next_block_list->prev = last;
            amountOfBlocks++;
        }
    }

    selector_list_struct* get_last() {
        selector_list_struct* last = head_node;
        while (last->next != nullptr) {
            last = last->next;
        }
        return last;
    }

    ~d_linked_list_selectors() {
        selector_list_struct* temp = get_last();
        if (temp != nullptr) {
            while (temp != nullptr) {
                selector_list_struct* temp2 = temp->prev;
                delete temp;
                temp = temp2;
            }
        }
    }
};

class d_block_linked_list{
public:
    block_list* head_node = nullptr;
    int amountOfBlocks = 0;
public:
    d_block_linked_list() {
        block_list* head = new block_list;
        head->prev = nullptr;
        head->next = nullptr;
        head_node = head;
    }

    void add_new_block_to_list(block_list* next_block_list) {
        if (amountOfBlocks == 0) {
            head_node = next_block_list;
            head_node->next = nullptr;
            head_node->prev = nullptr;
            amountOfBlocks++;
        }
        else {
            block_list* last = head_node;
            while (last->next != nullptr) {
                last = last->next;
            }
            last->next = next_block_list;
            next_block_list->prev = last;
            amountOfBlocks++;
        }
    }

    block_list* get_last() {
        block_list* last = head_node;
        while (last->next != nullptr) {
            last = last->next;
        }
        return last;
    }

    ~d_block_linked_list() {
        block_list* temp = get_last();
        if (temp != nullptr) {
            while (temp != nullptr) {
                block_list* temp2 = temp->prev;
                delete temp;
                temp = temp2;
            }
        }
    }
};

int number_of_comas(superstring str) {
    int counter = 0;
    int i = 0;
    while (str[i] != '\0') {
        i++;
        if (str[i] == ',') {
            counter++;
        }
        if (i == str.lenght)
            return counter;
    }
    return counter;
}

superstring remove_outside_spaces(superstring& str) {
    superstring to_return;
    int start = 0;
    int end = str.lenght - 1;
    bool is_start = false;
    bool is_end = false;

    for (int i = 0; i < str.lenght; i++) {
        if (str[i] > ' ' && !is_start) {
            start = i;
            is_start = true;
        }
        if (str[str.lenght - i - 1] > ' ' && !is_end){
            end = str.lenght - i - 1;
            is_end = true;
        };
    }
    for (int i = start; i <= end; i++) {
        to_return.str_cat(str[i]);
    }
    return to_return;
}

void read_css(d_block_linked_list* b_list) {
    char character;
    superstring selector_input;
    superstring attribute_input;
    superstring input;
    bool is_section_detected = false;
    superstring input2;
    superstring temp;
    int number_of_sections = 0;

    while (cin >> noskipws >> character) {
        if (character != '\n' && character != ' ' && character != '\t' && character != EOF)
            input.str_cat(character);
        else if (character == EOF || input == "????") {
            return;
        }
        else if (character < ' ')
            continue;


        if (character == '{') {
            is_section_detected = true;
        }
        else if (character == '}') {
            block_list* current_block = b_list->get_last();
            number_of_sections =  current_block->actual_sections;
            section current_section = current_block->sections[number_of_sections];
            d_linked_list_selectors* selector_list = new d_linked_list_selectors;
            d_linked_list_attributes* attribute_list = new d_linked_list_attributes;
            temp = "";
            number_of_sections = current_block->actual_sections;
            if (number_of_sections == AMOUNT_OF_BLOCKS_IN_BLOCK_LIST - 1) {
                block_list* newblock_list = new block_list;
                b_list->add_new_block_to_list(newblock_list);
                current_block = b_list->get_last();
                number_of_sections = current_block->actual_sections;
                current_section = current_block->sections[number_of_sections];
            }

            for (int i = 0; i < selector_input.lenght; i++) {
                if (i == selector_input.lenght - 1 || selector_input[i] == ',') {
                    if (selector_input.lenght - 1 == i) temp.str_cat(selector_input[i]);
                    selector_list_struct* new_node = new selector_list_struct;
                    new_node->name = remove_outside_spaces(temp);
                    new_node->prev = NULL;
                    new_node->next = NULL;
                    selector_list->add_new_block_to_list(new_node);
                    temp = "";
                }
                else {
                    temp.str_cat(selector_input[i]);
                }
            }
            temp = "";

            bool is_input_finished = false;
            for (int i = 0; i < attribute_input.lenght; i++) {
                is_input_finished = false;
                if ((i == attribute_input.lenght - 1) || attribute_input[i] == ';' ) {
                    if (attribute_input[i] != ';' && (i == attribute_input.lenght - 1))
                        temp.str_cat(attribute_input[i]);
                    attribute_list_struct* new_node = new attribute_list_struct;
                    new_node->next = nullptr;
                    new_node->prev = nullptr;
                    superstring name;
                    superstring value;

                    for (int second_i = 0; second_i < temp.lenght; second_i++) {
                        if (temp[second_i] == ':')
                            is_input_finished = true;
                        else if (temp[second_i] != ';') {
                            if (is_input_finished)
                                value.str_cat(temp[second_i]);
                            else
                                name.str_cat(temp[second_i]);

                        }
                    }
                    new_node->attr.name = remove_outside_spaces(name);
                    new_node->attr.value = remove_outside_spaces(value);

                    attribute_list->add_new_block_to_list(new_node);
                    temp = "";

                }
                else {
                    temp.str_cat(attribute_input[i]);
                }
            }
            input = "";
            current_section.attribute_list = attribute_list;
            current_section.selector_list = selector_list;
            int number_of_section = current_block->actual_sections;
            current_block->sections[number_of_section] = current_section;
            current_block->amount_of_sections++;
            current_block->actual_sections++;
            is_section_detected = false;
            selector_input = "";
            attribute_input = "";
        }
        if (character != '\n' && character != '\t' && character != '}' && character != '{')
            is_section_detected == true ? attribute_input.str_cat(character) : selector_input.str_cat(character);
    }
}

section* get_section_ptr(int section_index, d_block_linked_list* b_list) {
    section* section_to_return = new section;
    int counter = 0;
    block_list* block_list_temp = b_list->head_node;
    while (block_list_temp != nullptr) {
        for (int i = 0; i < block_list_temp->actual_sections; i++) {
            if (block_list_temp->sections[i].deleted == 0) {
                if (section_index != counter)
                    counter++;
                else
                    return &(block_list_temp->sections[i]);
            }

        }
        block_list_temp = block_list_temp->next;
    }
    return nullptr;
}

superstring print_out_number_of_sections(d_block_linked_list* b_list) { // ?
    block_list* temp = b_list->head_node;
    int counter = 0;
    while (temp != NULL) {
        counter += temp->amount_of_sections;
        temp = temp->next;
    }

    char counter_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(counter, counter_char, 10);
    superstring to_return = { "? == " };
    to_return.str_cat(counter_char);
    return to_return;
}

int count_selectors(selector_list_struct* temp) {
    int to_return = 0;
    if (temp != NULL) {
        while (temp != NULL) {
            if (temp->name.lenght != 0)
                to_return++;
            temp = temp->next;
        }
    }
    return to_return;
}

superstring write_selectors_for_section_number(int section_index, d_block_linked_list* b_list) { // iS?
    section* temp_section = get_section_ptr(section_index, b_list);

    char sec_index_char_default[NUMBER_OF_CHARS_TO_INT];
    _itoa(section_index + 1, sec_index_char_default, 10);
    superstring defaultValue{ sec_index_char_default };
    defaultValue.str_cat(",S,? == 0");
    if (temp_section == nullptr) {
        superstring empty;
        return empty;
    }
    if (temp_section->deleted == true) {
        superstring empty;
        return empty;
    }
    d_linked_list_selectors* temp_list = temp_section->selector_list;
    if (temp_list == nullptr)
        return defaultValue;
    selector_list_struct* temp = temp_list->head_node;
    if (temp == nullptr)
        return defaultValue;
    int counter = count_selectors(temp);

    char sec_index_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(section_index + 1, sec_index_char, 10);

    char counter_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(counter, counter_char, 10);

    superstring to_return;
    to_return.str_cat(sec_index_char);
    to_return.str_cat(",S,? == ");
    to_return.str_cat(counter_char);
    return to_return;

    return superstring{};
}

void remove_duplicates(d_linked_list_attributes* attribute_list) {
    attribute_list_struct* tail_node = attribute_list->get_last();
    attribute_list_struct* head = attribute_list->head_node;
    while (tail_node != nullptr) {
        attribute_list_struct* head_node = attribute_list->head_node;
        while (head_node != tail_node) {
            if (head_node->attr.name == tail_node->attr.name) {
                if (head_node != head) {
                    if (head_node->prev != nullptr)
                        head_node->prev->next = head_node->next;
                    if (head_node->next != nullptr) {
                        head_node->next->prev = head_node->prev;
                    }
                    head_node = head_node->next;
                }
                else {
                    if (head_node->prev != nullptr)
                        head_node->prev->next = head_node->next;
                    if (head_node->next != nullptr) {
                        head_node->next->prev = head_node->prev;
                    }
                    attribute_list->head_node = head_node->next;
                    head_node = head_node->next;
                }

            }
            else
                head_node = head_node->next;
        }
        tail_node = tail_node->prev;
    }
}

superstring write_number_of_attrs_in_section(int section_index, d_block_linked_list* b_list) { // iA?
    int counter = 0;
    section* temp_section = get_section_ptr(section_index, b_list);
    if (temp_section == nullptr)
        return superstring{};
    if (temp_section->deleted == true)
        return superstring{};

    d_linked_list_attributes* temp_list = temp_section->attribute_list;
    if (temp_list == nullptr)
        return superstring{};
    remove_duplicates(temp_list);
    attribute_list_struct* temp = temp_list->head_node;
    if (temp == nullptr)
        return superstring{};
    superstring empty_string;
    if (temp != NULL) {
        while (temp != NULL) {
            if (temp->attr.value.lenght != 0 || temp->attr.name.lenght != 0)
                counter++;
            temp = temp->next;
        }
    }

    char sec_index_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(section_index + 1, sec_index_char, 10);

    char counter_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(counter, counter_char, 10);

    if (counter != 0) {
        superstring to_return;
        to_return.str_cat(sec_index_char);
        to_return.str_cat(",A,? == ");
        to_return.str_cat(counter_char);
        return to_return;
    }
    return superstring{};
}

superstring write_specific_selector(int selector_index, int section_index, d_block_linked_list* b_list) { // iSj
    int counter = 0;
    section* temp_section = get_section_ptr(section_index, b_list);

    if (temp_section == nullptr)
        return superstring{};
    d_linked_list_selectors* temp_list = temp_section->selector_list;
    if (temp_list == nullptr)
        return superstring{};
    selector_list_struct* temp = temp_list->head_node;
    if (temp == nullptr)
        return superstring{};

    if (temp != NULL) {
        while (temp != NULL && counter != selector_index) {
            temp = temp->next;
            counter++;
        }
    }

    char sec_index_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(section_index + 1, sec_index_char, 10);

    char selec_index_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(selector_index + 1, selec_index_char, 10);

    if (counter == selector_index && temp != NULL && temp->name.lenght != 0) {
        superstring to_return{ sec_index_char };
        to_return.str_cat(",S,");
        to_return.str_cat(selec_index_char);
        to_return.str_cat(" == ");
        to_return.str_cat(temp->name);
        return to_return;
    }
    return superstring{};
}

superstring write_attr_of_ith_section_name(int section_index, superstring attr_name, d_block_linked_list* b_list) { // iAn
    int counter = 0;
    section* temp_section = get_section_ptr(section_index, b_list);
    if (temp_section == nullptr) return superstring{};

    d_linked_list_attributes* temp_list = temp_section->attribute_list;
    if (temp_list == nullptr) return superstring{};

    remove_duplicates(temp_list);

    attribute_list_struct* temp = temp_list->head_node;
    if (temp == nullptr) return superstring{};

    if (temp != NULL) {
        while (temp != NULL && temp->attr.name != attr_name) {
            temp = temp->next;
        }
    }

    char sec_index_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(section_index + 1, sec_index_char, 10);
    if (temp != NULL && temp->attr.name == attr_name && temp->attr.value.lenght != 0) {
        superstring to_return;
        to_return.str_cat(sec_index_char);
        to_return.str_cat(",A,");
        to_return.str_cat(attr_name);
        to_return.str_cat(" == ");
        to_return.str_cat(temp->attr.value.buffer);
        return to_return;
    }
    return superstring{};
}

superstring write_attribute_number(superstring attr_name, d_block_linked_list* b_list) { // nA?
    block_list* temp = b_list->head_node;
    int counter = 0;
    while (temp != NULL) {
        for (int i = 0; i < temp->actual_sections; i++) {
            if (temp->sections[i].deleted == false) {
                remove_duplicates(temp->sections[i].attribute_list);
                attribute_list_struct* current_attr_temp_list = temp->sections[i].attribute_list->head_node;
                while (current_attr_temp_list != NULL) {
                    if (current_attr_temp_list->attr.name == attr_name) {
                        counter++;
                    };
                    current_attr_temp_list = current_attr_temp_list->next;
                }
            }
        }
        temp = temp->next;
    }
    char counter_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(counter, counter_char, 10);
    superstring to_return;
    to_return.str_cat(attr_name);
    to_return.str_cat( ",A,? == ");
    to_return.str_cat(counter_char);
    return to_return;
}

superstring write_number_of_selectors(superstring selec_name, d_block_linked_list* b_list) { //iS?
    block_list* temp = b_list->head_node;
    int counter = 0;
    while (temp != NULL) {
        for (int i = 0; i < temp->actual_sections; i++) {
            if (temp->sections[i].deleted == false) {
                selector_list_struct* current_selec_temp_list = temp->sections[i].selector_list->head_node;
                while (current_selec_temp_list != NULL) {
                    if (current_selec_temp_list->name == selec_name) { 
                        counter++; 
                        break;
                    };
                    current_selec_temp_list = current_selec_temp_list->next;
                }
            }
        }
        temp = temp->next;
    }

    char counter_char[NUMBER_OF_CHARS_TO_INT];
    _itoa(counter, counter_char, 10);
    superstring to_return;
    to_return.str_cat(selec_name);
    to_return.str_cat(",S,? == ");
    to_return.str_cat(counter_char);
    return to_return;
}

superstring write_value_of_attr_with_name_in_given_section(superstring selec_name, superstring attr_name, d_block_linked_list* b_list) { // zEn
    
    block_list* temp = b_list->head_node;

    char attr_flag = 0;
    char selector_flag = 0;
    char superstring_flag = 0;
    superstring to_return;

    superstring last_value;
    superstring* last_value_ptr = &last_value;
    while (temp != nullptr) {
        for (int i = 0; i < temp->actual_sections; i++) {
            attr_flag = 0;
            selector_flag = 0;
            section* sec = &(temp->sections[i]);
            if (sec != NULL && sec->deleted == false) {
                d_linked_list_selectors* tmp_selec = sec->selector_list;
                d_linked_list_attributes* tmp_attr = sec->attribute_list;
                remove_duplicates(tmp_attr);
                selector_list_struct* current_selec_temp_list = tmp_selec->head_node;
                attribute_list_struct* current_attr_temp_list = tmp_attr->head_node;
                while (current_selec_temp_list != NULL) {
                    if (current_selec_temp_list->name == selec_name) {
                        selector_flag = 1;
                        break;
                    }
                    current_selec_temp_list = current_selec_temp_list->next;
                }

                while (current_attr_temp_list != NULL && selector_flag) {
                    if (current_attr_temp_list->attr.name == attr_name) {
                        attr_flag = 1;
                        last_value = "";
                        last_value.str_cat(current_attr_temp_list->attr.value);
                        superstring_flag = 1;
                    };
                    current_attr_temp_list = current_attr_temp_list->next;
                }
            }

        }
        temp = temp->next;
    }

    if (superstring_flag && last_value.lenght > 0 && last_value.buffer != "") {
        to_return.str_cat(selec_name);
        to_return.str_cat(",E,");
        to_return.str_cat(attr_name);
        to_return.str_cat(" == ");
        to_return.str_cat(last_value);
        return to_return;
    }
    return superstring{};
}

block_list* get_block_sec_index(int section_index, d_block_linked_list* b_list) {
    int counter = 0;
    block_list* block_list_temp = b_list->head_node;
    section* section_to_return = new section;
    while (block_list_temp != NULL) {
        for (int i = 0; i < block_list_temp->actual_sections; i++) {
            if (block_list_temp->sections[i].deleted == false) {
                if (section_index == counter) {
                    return block_list_temp;
                }
                counter++;
            }
        }
        block_list_temp = block_list_temp->next;
    }
    return nullptr;
}

superstring delete_section(d_block_linked_list* b_list, int section_index) { //iD*
    block_list* temp_block = get_block_sec_index(section_index, b_list);
    section* temp = get_section_ptr(section_index, b_list);
    if (temp != nullptr && temp_block != nullptr) {
        delete temp->selector_list;
        delete temp->attribute_list;
        temp->selector_list = new d_linked_list_selectors;
        temp->attribute_list = new d_linked_list_attributes;
        temp->selector_list->head_node = NULL;
        temp->attribute_list->head_node = NULL;
        temp->deleted = true;
        temp_block->amount_of_sections--;
        if (temp_block->amount_of_sections == -1) {
            return superstring{};
        }

        char sec_index_char[NUMBER_OF_CHARS_TO_INT];
        _itoa(section_index + 1, sec_index_char, 10);
        superstring to_return;
        to_return.str_cat(sec_index_char);
        to_return.str_cat(",D,* == deleted");

        return to_return;
    }
    else return superstring{};

}

bool is_attr_list_not_empty(d_linked_list_attributes* attribute_list) {
    int counter = 0;
    attribute_list_struct* temp = attribute_list->head_node;
    while (temp != NULL) {
        if (temp->attr.name.lenght != 0) {
            return false;
        }
        temp = temp->next;
    }
    return true;
}

void remove_node(attribute_list_struct* to_remove) {
    to_remove->attr.name = "";
    to_remove->attr.value = "";
    if (to_remove->next != nullptr)
        to_remove->next->prev = to_remove->prev;
    if (to_remove->prev != nullptr)
        to_remove->prev->next = to_remove->next;
}

superstring delete_section_by_attr(int section_index, superstring attr_name, d_block_linked_list* b_list) { // iDn
    section* temp = get_section_ptr(section_index, b_list);
    bool flag = false;
    if (temp == nullptr) return superstring{};
    d_linked_list_attributes* temp_attr_list = temp->attribute_list;
    if (temp_attr_list == nullptr) return superstring{ " " };

    remove_duplicates(temp_attr_list);

    attribute_list_struct* temp_attr_list_head = temp_attr_list->head_node;
    if (temp_attr_list_head == nullptr) return superstring{};

    while (temp_attr_list_head != NULL) {
        if (temp_attr_list_head->attr.name == attr_name) {
            remove_node(temp_attr_list_head);
            flag = true;
            break;
        }
        else {
            temp_attr_list_head = temp_attr_list_head->next;
        }
    }

    if (is_attr_list_not_empty(temp_attr_list)) {
        delete_section(b_list, section_index);
    }
    if (flag) {
        superstring to_return;
        char sec_index_char[NUMBER_OF_CHARS_TO_INT];
        _itoa(section_index + 1, sec_index_char, 10);
        to_return.str_cat(sec_index_char);
        to_return.str_cat(",D,");
        to_return.str_cat(attr_name);
        to_return.str_cat(" == deleted");
        return to_return;
    }
    else {
        return superstring{};
    }


}



void parse_commands(char& character, superstring& input, superstring* output,  d_block_linked_list* block_list, bool flag) {
    if ((character == '\n' || character == '\t' || character == EOF || flag)) {
        if (input == "****") {
            read_css(block_list);
        }
        else if (input == "?") {
            output->str_cat(print_out_number_of_sections(block_list).buffer);
            output->str_cat("\n");
        }
        else if (number_of_comas(input) == 2) {
            input = remove_outside_spaces(input);
            superstring first_param;
            superstring second_param;
            superstring third_param;
            superstring temp;
            for (int i = 0; i < input.lenght; i++) {
                if (i == input.lenght - 1 || input[i] == ',' ) {
                    if (i == input.lenght - 1)
                        temp.str_cat(input[i]);
                    if (first_param == "") first_param = temp;
                    if (second_param == "" && first_param != temp) second_param = temp;
                    else third_param = temp;
                    temp = "";
                }
                else {
                    temp.str_cat(input[i]);

                }
            }
            first_param = remove_outside_spaces(first_param);
            second_param = remove_outside_spaces(second_param);
            third_param = remove_outside_spaces(third_param);

            int first_number = atoi(first_param.buffer);
            int third_number = atoi(third_param.buffer);

            int first_number_minus_one = 0;
            int third_number_minus_one = 0;
            if (first_number)
                first_number_minus_one = first_number - 1;
            if (third_number)
                third_number_minus_one = third_number - 1;

            if (second_param == "S") {
                if (third_param == "?" && first_number) {
                    output->str_cat(write_selectors_for_section_number(first_number_minus_one, block_list).buffer);
                    output->str_cat("\n");
                }
                else if (third_number && first_number) {
                    output->str_cat(write_specific_selector(third_number_minus_one, first_number_minus_one, block_list).buffer);
                    output->str_cat("\n");

                }
                else if (third_param == "?" && !first_number) {
                    output->str_cat(write_number_of_selectors(first_param, block_list).buffer);
                    output->str_cat("\n");
                }
            }
            else if (second_param == "A") {
                if (third_param == "?" && first_number) {
                    output->str_cat(write_number_of_attrs_in_section(first_number_minus_one, block_list).buffer);
                    output->str_cat("\n");
                }
                else if (first_number && !third_number) {
                    output->str_cat(write_attr_of_ith_section_name(first_number_minus_one, third_param, block_list).buffer);
                    output->str_cat("\n");
                }
                else if (!first_number && third_param == "?") {
                    output->str_cat(write_attribute_number(first_param, block_list).buffer);
                    output->str_cat("\n");
                }
            }
            else if (second_param == "E") {
                if (!first_number && !third_number) {
                    output->str_cat(write_value_of_attr_with_name_in_given_section(first_param, third_param, block_list).buffer);
                    output->str_cat("\n");
                }
            }
            else if (second_param == "D") {
                if (first_number && third_param == "*") {
                    output->str_cat(delete_section(block_list, first_number_minus_one).buffer);
                    output->str_cat("\n");
                }
                else if (first_number) {
                    output->str_cat(delete_section_by_attr(first_number_minus_one, third_param, block_list).buffer);
                    output->str_cat("\n");
                }
            }
        }
        input = "";
    }
    else if (character != '\n' && character != '\t' && !flag) {
        input.str_cat(character);
    }
}

int main() {
    d_block_linked_list* block_list_ptr = new d_block_linked_list;
    block_list* first_block = new block_list;
    block_list_ptr->add_new_block_to_list(first_block);
    char character;
    superstring input;
    superstring* ptr_output = new superstring;
    read_css(block_list_ptr);
    while (cin >> character >> noskipws) {
        parse_commands(character, input, ptr_output, block_list_ptr, false);
    }
    if (input.buffer!= "")
        parse_commands(character, input, ptr_output, block_list_ptr, true);

    cout << ptr_output->buffer[0];
    for (int i = 0; i < ptr_output->lenght - 1; i++) {
        if (ptr_output->buffer[i] == '\n' && ptr_output->buffer[i + 1] == '\n')
            continue;
        else if (ptr_output->buffer[i+1] != '|' && ptr_output->buffer[i+1] != '\t')
            cout << ptr_output->buffer[i+1];
    }
    return 0;
}