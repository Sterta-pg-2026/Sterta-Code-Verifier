#include<iostream>
#include<string.h>

using namespace std;
const int T = 19;
const int Temporary_Variable = 50;
int TakenNodes = 0;
int IleSekcji = 0;

struct attributes {
	attributes* next = nullptr;
	attributes* last = nullptr;
	char property[Temporary_Variable] = {};
	char value[Temporary_Variable] = {};
	int ile = 0;
};
struct selectors {
	selectors* next = nullptr;
	selectors* last = nullptr;
	char name[Temporary_Variable] = {};
	int ile = 0;
};
struct section {
	section* next = nullptr;
	section* prev = nullptr;
	attributes* FirstAtt = nullptr;
	selectors* FirstSelec = nullptr;
	bool IsTaken = 0;

};

 class DoubleLinkedList {
private:
	section* CurrentNode = nullptr;
	section* FirstNode = nullptr;
	section* LastNode = nullptr;

public:

	void Add(selectors* sel, attributes* att) {
		if (FirstNode == nullptr) {
			section* NewNode = new section[T];
			FirstNode = NewNode;
			CurrentNode = FirstNode;
			LastNode = FirstNode + T - 1;
			FirstNode[0].FirstSelec = sel;
			FirstNode[0].FirstAtt = att;
			IleSekcji = T;
			++TakenNodes;
			FirstNode->IsTaken = 1;
			for (int i = 0; i < T; ++i) {
				if (i + 1 < T) {
					FirstNode[i].next = FirstNode + 1 + i;
					FirstNode[i + 1].prev = FirstNode + i;
				}
			}
		}
		else {
			CurrentNode = FirstNode;
			while (CurrentNode != nullptr)
				if (!CurrentNode->IsTaken) {
					CurrentNode->FirstSelec = sel;
					CurrentNode->FirstAtt = att;
					CurrentNode->IsTaken = 1;
					++TakenNodes;
					return;
				}
				else
					CurrentNode = CurrentNode->next;
		}
		if (CurrentNode == nullptr) {
			section* NewNode = new section[T];
			for (int i = 0; i < T; ++i) {
				if (i + 1 < T) {
					NewNode[i].next = NewNode + 1 + i;
					NewNode[i + 1].prev = NewNode + i;
				}
			}
			NewNode->FirstSelec = sel;
			NewNode->FirstAtt = att;
			NewNode->IsTaken = 1;
			LastNode->next = NewNode;
			NewNode[0].prev = LastNode;
			LastNode = NewNode + T - 1;
			IleSekcji = IleSekcji + T;
			++TakenNodes;
		}
	}
	void DeleteSection(int nr, char* komenda) {
		if (nr > IleSekcji)
			return;
		CurrentNode = FirstNode;


		for (int i = 1; i <= nr; ++i) {
			CurrentNode = CurrentNode->next;
		}
		if (CurrentNode->IsTaken) {
			CurrentNode->IsTaken = 0;
			attributes* temp1, * temp2 = nullptr;
			temp1 = CurrentNode->FirstAtt->next;
			if (temp1 != nullptr)
				temp2 = temp1->next;
			while (temp2 != nullptr) {
				delete temp1;
				temp1 = temp2;
				temp2 = temp1->next;
			}
			if (CurrentNode->FirstAtt != CurrentNode->FirstAtt->last) {
				delete CurrentNode->FirstAtt->last;
				delete CurrentNode->FirstAtt;
			}
			else
				delete CurrentNode->FirstAtt;

			selectors* temp3, * temp4 = nullptr;
			temp3 = CurrentNode->FirstSelec->next;
			if (temp3 != nullptr)
				temp4 = temp3->next;
			while (temp4 != nullptr) {
				delete temp3;
				temp3 = temp4;
				temp4 = temp3->next;
			}
			if (CurrentNode->FirstSelec != CurrentNode->FirstSelec->last) {
				delete CurrentNode->FirstSelec->last;
				delete CurrentNode->FirstSelec;
			}
			else
				delete CurrentNode->FirstSelec;
			--TakenNodes;

			cout << komenda << " == deleted" << endl;
		}
		else
			return;
	}
	void FindLastAt(char* selec, char* name, char* komenda) {
		CurrentNode = LastNode;
		while (CurrentNode != nullptr) {
			if (CurrentNode->IsTaken) {
				selectors* sel = CurrentNode->FirstSelec;
				while (sel != nullptr) {
					if (!strcmp(sel->name, selec)) {
						attributes* At = CurrentNode->FirstAtt;
						while (At != nullptr) {
							if (!strcmp(At->property, name)) {
								cout << komenda << " == " << At->value << endl;
								return;
							}
							else
								At = At->next;
						}
					}
					sel = sel->next;
				}
			}
			CurrentNode = CurrentNode->prev;
		}
		return;
	}
	void DeleteAtt(int nr, char* name, char* komenda) {
		if (nr > IleSekcji)
			return;
		CurrentNode = FirstNode;
		int ArrayIndex = nr;
		attributes* temp, * temp2;

		for (int i = 1; i <= nr; ++i) {
			CurrentNode = CurrentNode->next;
		}
		if (CurrentNode->IsTaken) {
			if (!strcmp(CurrentNode->FirstAtt->property, name)) {
				if (CurrentNode->FirstAtt->next != nullptr) {
					temp = CurrentNode->FirstAtt->next;
					delete CurrentNode->FirstAtt;
					CurrentNode->FirstAtt = temp;
				}
				else {
					DeleteSection(nr, komenda);
					return;
				}

			}
			else {
				if (CurrentNode->FirstAtt->next != nullptr) {
					temp = CurrentNode->FirstAtt->next;
					temp2 = CurrentNode->FirstAtt;
					while (temp != nullptr) {
						if (!strcmp(temp->property, name)) {
							if (temp->next != nullptr)
								temp2->next = temp->next;
							delete temp;
							cout << komenda << " == deleted" << endl;
							return;
						}
						else {
							temp2 = temp2->next;
							temp = temp->next;
						}
					}
				}
				else
					return;
			}
		}
		else return;

	}
	void NumberOfAttInSection(int nr, char* komenda) {
		if (nr > IleSekcji) {
			return;
		}
		CurrentNode = FirstNode;
		for (int i = 1; i < nr; ++i) {
			CurrentNode = CurrentNode->next;

		}
		if (CurrentNode->IsTaken) {
			cout << komenda << " == " << CurrentNode->FirstAtt->ile << endl;
		}
		else
			return;
	}

	void NumberOfSelecInSection(int nr, char* komenda) {
		if (nr > IleSekcji) {
			return;
		}
		CurrentNode = FirstNode;
		for (int i = 0; i < nr - 1; ++i) {
			CurrentNode = CurrentNode->next;

		}
		if (CurrentNode->IsTaken) {
			cout << komenda << " == " << CurrentNode->FirstSelec->ile << endl;
		}
		else
			return;
	}
	void ISelectorDlaBlokuJ(int SecNumb, int SelecNumb, char* komenda) {
		if (SecNumb > TakenNodes) {
			return;
		}
		CurrentNode = FirstNode;
		for (int i = 1; i < SecNumb; ++i) {
			CurrentNode = CurrentNode->next;
		}
		if (SelecNumb > CurrentNode->FirstSelec->ile)
			return;
		else {
			selectors* help = CurrentNode->FirstSelec;
			for (int i = 0; i < SelecNumb - 1; ++i) {
				help = help->next;
			}
			cout << komenda << " == " << help->name << endl;
			return;
		}
	}
	void AtributeForISection(int SecNumb, char* name, char* komenda) {

		if (SecNumb > IleSekcji) {
			return;
		}

		CurrentNode = FirstNode;
		for (int i = 1; i < SecNumb; ++i) {
			CurrentNode = CurrentNode->next;
		}
		attributes* help = CurrentNode->FirstAtt;
		while (help != nullptr) {
			if (!strcmp(help->property, name)) {
				cout << komenda << " == " << help->value << endl;
				return;

			}
			else {
				help = help->next;
			}
		}
		return;
	}
	int NamedAttNr(char* name) {
		int ile = 0;
		CurrentNode = FirstNode;
		for (int i = 0; i <= IleSekcji; ++i) {
			if (CurrentNode == nullptr)
				break;
			if (CurrentNode->IsTaken) {
				attributes* temp = CurrentNode->FirstAtt;
				while (temp != nullptr) {
					if (!strcmp(temp->property, name))
						++ile;
					temp = temp->next;
				}
			}
			CurrentNode = CurrentNode->next;
		}
		return ile;

	}
	int NamedSelecNr(char* name) {
		int ile = 0;
		CurrentNode = FirstNode;
		while (CurrentNode != nullptr) {
			if (CurrentNode->IsTaken) {
				selectors* temp = CurrentNode->FirstSelec;
				while (temp != nullptr) {
					if (!strcmp(temp->name, name))
						++ile;
					temp = temp->next;
				}
			}
			CurrentNode = CurrentNode->next;
		}
		return ile;

	}
	~DoubleLinkedList() {

	}
};
template<typename T>  void Link(T* Current, T* Next) {
	if (Current->last == nullptr) {
		Current->next = Next;
		Current->last = Next;
		Next->last = Next;
	}
	else {
		T* first = Current;
		Current = Current->last;
		Current->next = Next;
		Next->last = Next;
		Current = first;
		Current->last = Next;
	}

}
void AddAttValues(attributes* At, char* property, char* value) {
	attributes* CurrentAt = At;
	char help[Temporary_Variable] = {};
	while (CurrentAt != nullptr) {
		if (!strcmp(CurrentAt->property, help) && !strcmp(CurrentAt->value, help)) {
			for (int i = 0; i < Temporary_Variable; ++i) {
				CurrentAt->property[i] = property[i];
				CurrentAt->value[i] = value[i];
			}
			At->ile++;
			return;
		}
		else if (!strcmp(CurrentAt->property, property)) {
			for (int i = 0; i < Temporary_Variable; ++i) {

				CurrentAt->value[i] = value[i];
			}
			return;
		}
		CurrentAt = CurrentAt->next;
	}
	attributes* New = new attributes;
	for (int i = 0; i < Temporary_Variable; ++i) {
		New->property[i] = property[i];
		New->value[i] = value[i];
	}
	At->ile++;
	Link(At, New);

}
void AddSelectors(selectors* Sel, char* name) {
	selectors* CurrentSel = Sel;
	char help[Temporary_Variable] = {};
	while (CurrentSel != nullptr) {
		if (!strcmp(CurrentSel->name, help)) {
			for (int i = 0; i < Temporary_Variable; ++i) {
				CurrentSel->name[i] = name[i];
			}
			Sel->ile++;
			return;
		}
		else if (!strcmp(CurrentSel->name, name)) {
			return;
		}
		CurrentSel = CurrentSel->next;
	}
	selectors* New = new selectors;
	for (int i = 0; i < Temporary_Variable; ++i) {
		New->name[i] = name[i];
	}
	Sel->ile++;
	Link(Sel, New);
}
void TrybCSS(char c, DoubleLinkedList* Lista) {
	if (c > ' ') {
		selectors* FirstS = new selectors;
		attributes* FirstA = new attributes;
		while (c != '{') {
			char selecname[Temporary_Variable] = {};
			int i = 0;
			while (c != ',' && c != '{') {
				if (c > ' ') {
					selecname[i] = c;
					++i;
				}
				c = getchar();
			}
			if (c == ',') {
				AddSelectors(FirstS, selecname);
				c = getchar();
			}
			else if (c == '{') {
				AddSelectors(FirstS, selecname);
				break;
			}
		}

		c = getchar();
		while (c != '}') {
			char attproperty[Temporary_Variable] = {};
			char attvalue[Temporary_Variable] = {};
			int i = 0;
			while (c != ';' && c != '}' && c >= ' ') {
				while (c != ':' && c != '}') {
					if (c >= ' ') {
						attproperty[i] = c;
						++i;
					}
					c = getchar();
				}
				if (c == ':') {
					c = getchar();
					i = 0;
				}
				c = getchar();
				while (c >= ' ' && c != ';' && c != '}') {
					attvalue[i] = c;
					++i;
					c = getchar();
				}
				AddAttValues(FirstA, attproperty, attvalue);
			}
			c = getchar();
		}
		Lista->Add(FirstS, FirstA);
	}
	return;
}
void TrybKomend(char c , DoubleLinkedList*Lista) {
	{
		if (c == '/n')
			c = getchar();

		while (c != '/n' && c != EOF) {
			if (c == '*')
				break;
			if (c == '?') {
				cout << "? == " << TakenNodes << endl;
				break;
			}
			if (c > ' ') {
				char komenda[Temporary_Variable] = {};
				char name[Temporary_Variable] = {};
				char name2[Temporary_Variable] = {};
				int i = 0;
				int secnumber = 0;
				int othernumber = 0;
				char litera;
				if (c >= '0' && c <= '9') {
					while (c >= '0' && c <= '9') {
						secnumber = secnumber * 10 + (c - 48);
						komenda[i] = c;
						++i;
						c = getchar();
					}
				}
				else {
					while (c != ',') {
						name2[i] = c;
						komenda[i] = c;
						++i;
						c = getchar();
					}
				}

				komenda[i] = c;
				++i;
				c = getchar();
				komenda[i] = c;
				++i;
				litera = c;
				c = getchar();
				komenda[i] = c;
				++i;
				c = getchar();
				if (c == '?') {
					komenda[i] = c;
					++i;
					if (secnumber > 0) {
						if (secnumber <= IleSekcji) {
							if (litera == 'A') {
								Lista->NumberOfAttInSection(secnumber, komenda);
							}
							else if (litera == 'S') {
								Lista->NumberOfSelecInSection(secnumber, komenda);
							}
						}
					}
					else {
						if (litera == 'A')
							cout << komenda << " == " << Lista->NamedAttNr(name2) << endl;
						else if (litera == 'S')
							cout << komenda << " == " << Lista->NamedSelecNr(name2) << endl;
					}

				}
				else if (litera == 'D') {
					if (c == '*') {
						komenda[i] = c;
						++i;
						Lista->DeleteSection(secnumber, komenda);
					}
					else {
						int j = 0;
						while (c > ' ') {
							name[j] = c;
							komenda[i] = c;
							++i;
							++j;
							c = getchar();
						}
						Lista->DeleteAtt(secnumber, name, komenda);

					}

				}
				else if (litera == 'A') {
					if (c > ' ') {
						int j = 0;
						while (c >= ' ') {
							name[j] = c;
							komenda[i] = c;
							++i;
							++j;
							c = getchar();
						}
					}
					Lista->AtributeForISection(secnumber, name, komenda);

				}
				else if (litera == 'S') {
					if (c >= '1' && c <= '9') {
						while (c >= '1' && c <= '9') {
							othernumber = othernumber * 10 + (c - 48);
							komenda[i] = c;
							++i;
							c = getchar();
						}
						Lista->ISelectorDlaBlokuJ(secnumber, othernumber, komenda);
					}

				}
				else if (litera == 'E') {
					if (c > ' ') {
						int j = 0;
						while (c >= ' ') {
							name[j] = c;
							komenda[i] = c;
							++i;
							++j;
							c = getchar();
						}
					}
					Lista->FindLastAt(name2, name, komenda);
				}
			}
			c = getchar();

		}

	}
	return;

}
int main() {
	DoubleLinkedList Lista;
	char c = NULL;
	bool tryb = 1;
	while (c != EOF) {

		c = getchar();
		if (c == EOF)
			return 0;
		if (tryb == 1 && c == '?') {
			c = getchar();
			c = getchar();
			c = getchar();
			c = getchar();
			//c = getchar();
			tryb = 0;
		}
		if (tryb == 0 && c == '*') {
			c = getchar();
			c = getchar();
			c = getchar();
			c = getchar();
			c = getchar();
			tryb = 1;
		}
		if (tryb == 1) {
			TrybCSS(c, &Lista);
		}
		if (tryb == 0 && c != '*') {
			TrybKomend(c, &Lista);

				
		}
	}

	return 0;
}