#pragma once

#include <iostream>

struct Str
{
	char* str;
	void Add(char* n)
	{
		int i = 0;
		while (i < strlen(n))
		{
			this->str[i] = n[i];
			i++;
		}
	}
};

struct Node
{
	Str data;
	Node* next;
	Node()
	{
		this->next = NULL;
		this->data.str = new char[256];
	}
};

class List
{
public:
	Node* first;
	List();
	~List();
	Node* AddLast();
	Node* GetLast();
	Node* Delete(char* n);
	Node* DeletePosition(int x);
};

