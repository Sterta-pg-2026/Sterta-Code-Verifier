#pragma once

#include "list.h"

#include <iostream>

#define T 8

struct Block
{
	List selector;
	List attributeName;
	List attributeValue;
};

struct NodeBlock
{
	Block block[T];
	NodeBlock* prev;
	NodeBlock* next;
	int counter;
	NodeBlock()
	{
		this->prev = NULL;
		this->next = NULL;
		counter = 0;
	}
};

class DoubleList
{
public:
	NodeBlock* first;
	NodeBlock* last;
	NodeBlock* AddLast();
	NodeBlock* GetLast();
	void InitLast(int actualT);
	DoubleList();
	~DoubleList();
};