#include "doublelist.h"

#include <iostream>

DoubleList::DoubleList()
{
	this->first = new NodeBlock();
	this->first->next = NULL;
	this->first->prev = NULL;
	this->last = this->first;
	
}
DoubleList::~DoubleList()
{

}
NodeBlock* DoubleList::AddLast()
{
	NodeBlock* newNodeBlock = new NodeBlock();
	newNodeBlock->next = NULL;
	newNodeBlock->prev = NULL;
	if (this->last == NULL)
	{
		return newNodeBlock;
	}
	this->last->next = newNodeBlock;
	newNodeBlock->prev = this->last;
	this->last = this->GetLast();
	return first;
}
NodeBlock* DoubleList::GetLast()
{
	NodeBlock* tmp = this->first;
	if (tmp == nullptr)
	{
		return nullptr;
	}
	while (tmp->next != NULL)
	{
		tmp = tmp->next;

	}
	return tmp;
}
void DoubleList::InitLast(int actualT)
{
	this->last->block[actualT].selector.first = new Node();
	this->last->block[actualT].selector.first->next = NULL;
	this->last->block[actualT].selector.first->data.str = new char[256];
	*this->last->block[actualT].selector.first->data.str = ' ';

	this->last->block[actualT].attributeName.first = new Node();
	this->last->block[actualT].attributeName.first->next = NULL;
	this->last->block[actualT].attributeName.first->data.str = new char[256];
	*this->last->block[actualT].attributeName.first->data.str = ' ';

	this->last->block[actualT].attributeValue.first = new Node();
	this->last->block[actualT].attributeValue.first->next = NULL;
	this->last->block[actualT].attributeValue.first->data.str = new char[256];
	*this->last->block[actualT].attributeValue.first->data.str = ' ';

}
