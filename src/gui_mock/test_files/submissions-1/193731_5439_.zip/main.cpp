// AiSD project1.cpp
#define _CRT_SECURE_NO_WARNINGS 1

#include <iostream>
#include <string.h>
#include "doublelist.h"

#define T 8
#define SelectorInput 1
#define AttributeInput 2
#define AttributeValueInput 3

#define STRLEN 256

using namespace std;

int findListPosition(List list, char* n)
{
    int i = 0;
    while (list.first != NULL)
    {
        if (!strcmp(list.first->data.str, n))
        {
            return i;
        }
        list.first = list.first->next;
        i++;
    }
    return -1;
}

bool duplicate(List list, char* n)
{
    int number = 0;
    while (list.first != NULL)
    {
        if (!strcmp(list.first->data.str, n))
        {
            number++;
        }
        list.first = list.first->next;
    }

    if (number > 1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void cleanString(char* &a)
{
    for (int i = 0; i < strlen(a); i++)
    {
        if ((a[i] == '\t') || (a[i]) == '\r')
        {
            a[i] = ' ';
        }
    }
}

bool isStringEqual(char* a, char* b)
{
    return !strcmp(a, b);
    
    if (strlen(a) != strlen(b))
    {
        return false;
    }
    int i = 0;
    while (i < strlen(a))
    {
        if (a[i] != b[i])
        {
            return false;
        }
        i++;
    }
    return true;
    
}

//i,A,? i,S,?
void function(int i, char a, char b, DoubleList dlist)
{
    if (i > dlist.first->counter)
    {
        return;
    }

    int output = i;

    int number = 0;

    if ((a == 'S') && (b == '?'))
    {
        i--;
        NodeBlock* tmp = dlist.first;
        while (i >= T)
        {
            i -= T;
            tmp = tmp->next;
        }
        Node* tmp2 = new Node();
        tmp2 = tmp->block[i].selector.first;
        while (tmp2 != NULL)
        {
            tmp2 = tmp2->next;
            number++;
        }
        cout << output << "," << a << "," << b << " == " << number << endl;
    }

    else if ((a == 'A') && (b == '?'))
    {
        i--;
        NodeBlock* tmp = dlist.first;
        while (i >= T)
        {
            i -= T;
            tmp = tmp->next;
        }
        Node* tmp2 = new Node();
        tmp2 = tmp->block[i].attributeName.first;
        while (tmp2 != NULL)
        {
            tmp2 = tmp2->next;
            number++;
        }
        cout << output << "," << a << "," << b << " == " << number << endl;
    }

}
//i,S,j
void function(int i, char a, int j, DoubleList dlist)
{
    if (i > dlist.first->counter)
    {
        return;
    }

    int output = i;

    if (a == 'S')
    {
        i--;
        j--;
        int k = 0;
        NodeBlock* tmp = dlist.first;
        while (i >= T)
        {
            i -= T;
            tmp = tmp->next;
        }
        Node* tmp2 = new Node();
        tmp2 = tmp->block[i].selector.first;
        while ((k<j)&&(tmp2!=NULL))
        {
            tmp2 = tmp2->next;
            k++;
        }
        if (tmp2 == NULL)
        {
            return;
        }
        cout << output << "," << a << "," << ++j << " == " << tmp2->data.str << endl;
    }
}
//n,A,? z,S,?
void function(char* n, char a, char b, NodeBlock first)
{
    if ((a == 'A') && (b == '?'))
    {
        int number = 0;
        int actualT = 0;
        NodeBlock tmp = first;

        while (tmp.block[actualT].selector.first != NULL)
        {
            
            while (tmp.block[actualT].attributeName.first != NULL)
            {
                if (isStringEqual(tmp.block[actualT].attributeName.first->data.str, n))
                {
                    number++;
                }
                tmp.block[actualT].attributeName.first = tmp.block[actualT].attributeName.first->next;
            }

            if (actualT == 7)
            {

                actualT = 0;
                tmp = *tmp.next;
            }
            else
            {
                actualT++;
            }
        }
        cout << n << "," <<a<< "," << b << " == " << number << endl;
    }
    else if ((a == 'S') && (b == '?'))
    {
        int number = 0;
        int actualT = 0;
        NodeBlock tmp = first;
        int kok = 0;
        while (kok<first.counter)
        {
            while (tmp.block[actualT].selector.first != NULL)
            {
                if (isStringEqual(tmp.block[actualT].selector.first->data.str, n))
                {
                    number++;
                    break;
                }
                tmp.block[actualT].selector.first = tmp.block[actualT].selector.first->next;
            }
            if (actualT == 7)
            {

                actualT = 0;
                tmp = *tmp.next;
            }
            else
            {
                actualT++;
            }
            kok++;
        } 
            
        cout << n << "," << a << "," << b << " == " << number << endl;
    }
}

//z,E,n
void function(char* z, char a, char* n, NodeBlock last, int counter)
{
    if (a == 'E')
    {
        int number = 0;
        int actualT;
        int i = 0;
        NodeBlock tmp = last;

        counter--;
        actualT = counter % T;

        while ((i<(counter+1)))
        {
            while (tmp.block[actualT].selector.first != NULL)
            {
                if (isStringEqual(tmp.block[actualT].selector.first->data.str, z))
                {
                    while (tmp.block[actualT].attributeName.first != NULL)
                    {
                        if (isStringEqual(tmp.block[actualT].attributeName.first->data.str, n))
                        {
                            cout << z << "," << a << "," << n << " == " << tmp.block[actualT].attributeValue.first->data.str << endl;
                            return;
                        }
                        tmp.block[actualT].attributeName.first = tmp.block[actualT].attributeName.first->next;
                        tmp.block[actualT].attributeValue.first = tmp.block[actualT].attributeValue.first->next;
                    }
                }
                tmp.block[actualT].selector.first = tmp.block[actualT].selector.first->next;
            }

            if (actualT == 0)
            {
                actualT = 7;
                if (tmp.prev != NULL)
                {
                    tmp = *tmp.prev;
                }              
            }
            else
            {
                actualT--;
            }
            i++;
        }        
        return;
    }
}

//i,A,n
void functionA(int i, char a, char* n, NodeBlock first)
{
    
    if (a == 'A')
    {
        if (i > first.counter)
        {
            return;
        }
        int flag = 0;
        int output = i;
        i--;
        int k = 0;
        NodeBlock tmp = first;

        while (i >= T)
        {
            i -= T;
            tmp = *tmp.next;
        }

        Node* tmp2 = tmp.block[i].attributeValue.first;
        Node* tmp3 = tmp.block[i].attributeName.first;
        while ((tmp3 != NULL))
        {
            //groch2
            if (isStringEqual(tmp3->data.str, n))
            {

                cout << output << "," << a << "," << n << " == " << tmp2->data.str << endl;
                flag = 1;
                break;
            }
            tmp2 = tmp2->next;
            tmp3 = tmp3->next;
            k++;
        }
        
        if (flag == 0)
        {
            return;
        }
        
    }
}


//i,D,*
void functionDstar(int i, char d, char star, NodeBlock* first, int docout)
{
    int output = i;
    int cnt = 0;
    i--;
    NodeBlock* tmp = first;
    while (i>T)
    {
        i -= T;
        tmp = tmp->next;
    }

    while (cnt<first->counter)
    {

        if (i != 7)
        {
            if (tmp->block[i + 1].selector.first != NULL)
            {
                tmp->block[i] = tmp->block[i + 1];
            }
        }
        else if (i == 7)
        {

            if (tmp->next->block[0].selector.first != NULL)
            {
                tmp->block[i] = tmp->next->block[0];
            }
        }

        if (i == 7)
        {
            i = 0;
            tmp = tmp->next;
        }
        else
        {
            i++;
        }

        cnt++;

    }

    first->counter--;

    if (docout == 1)
    {
        cout << output << "," << d << "," << star << " == deleted" << endl;
    }
    
    return;

}

//i,D,n
void functionD(int i, char d, char* n, NodeBlock& first, NodeBlock second)
{
    int output;
    output = i;
    i--;
    NodeBlock tmp = first;
    while (i > T)
    {
        i -= T;
        tmp = *tmp.next;
    }

    int position = findListPosition(second.block[i].attributeName, n);
    first.block[i].attributeName.first = first.block[i].attributeName.Delete(n);
    first.block[i].attributeValue.first = first.block[i].attributeValue.DeletePosition(position);

    if (first.block[i].attributeName.first == NULL)
    {
        functionDstar(i, 'D', '*', &first, 0);
    }

    cout << output << "," << d << "," << n << " == deleted" << endl;
    return;

}

int stringToInt(char* number)
{
    int i = 1;
    int result = number[0]-'0';
    while (i < strlen(number))
    {
        result = result * 10 + (number[i] - '0');
        i++;
    }
    return result;
}

int main()
{
    DoubleList dlist = DoubleList();
    Node* last = new Node();

    char* one;
    char* two;
    char* three;
    one = new char[STRLEN];
    two = new char[STRLEN];
    three = new char[STRLEN];

    Node* newNode = new Node();

    char* l = new char[STRLEN];
    int actualT = 0;
    int integer = 0, integer2 = 0;
    
    dlist.first = new NodeBlock();
    dlist.last = new NodeBlock();
    
    dlist.last = dlist.first;

    NodeBlock* actual = new NodeBlock();
    actual = dlist.first;

    dlist.InitLast(actualT);

    int input = SelectorInput;
    int flag = 1;
    
    while ((flag == 1))
   {
        if (!cin.getline(l, STRLEN, '\n'))
        {
            return 0;
        }
        cleanString(l);
     int character = 0;
     while (character<strlen(l))
     {
         switch (l[character])
         {
         case ' ':
             character++;
             break;
         case '{':
             character++;
             input = AttributeInput;
             break;
         case ',':
             character++;
             break;
         case ':':
             character++;
             input = AttributeValueInput;
             break;
         case ';':
             character++;
             input = AttributeInput;
             break;
         case '}':
             input = SelectorInput;
             character++;
             if (actualT == 7)
             {
                 actualT = 0;
                 dlist.AddLast();
                 actual = dlist.last;
                 dlist.InitLast(actualT);   
                 dlist.first->counter++;
             }
             else
             {
                 actualT++;
                 dlist.InitLast(actualT);
                 dlist.first->counter++;
             }
             break;
         case '\0':
             character = STRLEN;
             break;
         case '\r':
             character = STRLEN;
             break;
         case '\t':
             
             break;
         case '?':
             flag = 0;
             character++;
             while (flag==0)
             {
                 if (!cin.getline(l, STRLEN, '\n'))
                 {
                     return 0;
                 }
                 if (l[0] == '\n')
                 {
                     break;
                 }

                 cleanString(l);

                 for (int i = 0; i < strlen(l); i++)
                 {
                     if ((l[i] == '\n') || (l[i] == '\r') || (l[i] == '\t'))
                     {
                         l[i] = '\0';
                     }
                 }

                 if (l[0] == '?')
                 {
                     cout << "? == " << dlist.first->counter << endl;
                 }
                 else if (l[0] == '*')
                 {
                     flag = 1;
                     character += STRLEN;
                 }
                 else
                 {
                     *one = ' ';
                     int i = 0;
                     int j = 0;
                     while (l[i] != ',')
                     {
                         one[j] = l[i];
                         i++;
                         j++;
                     }
                     one[j] = '\0';
                     i++;
                     j = 0;
                     while (l[i] != ',')
                     {
                         two[j] = l[i];
                         i++;
                         j++;
                     }
                     two[j] = '\0';
                     i++;
                     j = 0;
                     while(i<strlen(l))
                     {
                         three[j] = l[i];
                         i++;
                         j++;
                     }
                     three[j] = '\0';
                     if (((one[0] >= '0') && (one[0] <= '9')) && ((three[0] >= '0') && (three[0] <= '9')))
                     {
                         //i,S,j
                         integer = stringToInt(one);
                         integer2 = stringToInt(three);
                         function(integer, *two, integer2, dlist);
                     }
                     else if ((one[0] >= '0') && (one[0] <= '9') && (*three == '?'))
                     {
                         //i,S,? i,A,?
                         integer = stringToInt(one);
                         function(integer, *two, *three, dlist);
                     }
                     else if (*two == 'E')
                     {
                         //z,E,n
                         function(one, *two, three, *dlist.last, dlist.first->counter);
                     }
                     else if((*three=='?'))
                     {
                         //n,A,? z,B,?
                         function(one, *two, *three, *dlist.first);
                     }
                     else if ((*two == 'A')&&((one[0] >= '0') && (one[0] <= '9')))
                     {
                         //i,A,n
                         integer = stringToInt(one);
                         functionA(integer, *two, three, *dlist.first);
                     }
                     else if ((*two = 'D') && (*three == '*'))
                     {
                         //i,D,*
                         integer = stringToInt(one);
                         functionDstar(integer, *two, *three, dlist.first, 1);
                     }
                     else if ((one[0] >= '0') && (one[0] <= '9')&&(*two = 'D')&&(*three!='\0'))
                     {
                         //i,D,n
                         integer = stringToInt(one);
                         functionD(integer, *two, three, *dlist.first, *dlist.first);
                     }
                     else
                     {

                     }
                 }
             }
             break;
         default:
             if (input == SelectorInput)
             {
                 
                 if (*actual->block[actualT].selector.first->data.str != ' ')
                 {
                     actual->block[actualT].selector.AddLast();
                 }
                 last = actual->block[actualT].selector.GetLast();
     
                 int i = 0;
                 
                 while (((l[character] != '{')&&(character!=strlen(l)))&&(l[character] != ','))
                 {
                     last->data.str[i] = l[character];
                     i++;
                     character++;
                 }
                 if (last->data.str[i - 1] == ' ')
                 {
                     last->data.str[i - 1] = '\0';
                 }
                 
                 last->data.str[i] = '\0';
             }
             else if (input == AttributeInput)
             {

                 if (*actual->block[actualT].attributeName.first->data.str != ' ')
                 {
                     actual->block[actualT].attributeName.AddLast();
                 }
                 int i = 0;
                 last = actual->block[actualT].attributeName.GetLast();
                 while ((l[character] != ':'))
                 {
                     last->data.str[i] = l[character];
                     i++;
                     character++;
                 }
                 last->data.str[i] = '\0';
             }
             else if (input == AttributeValueInput)
             {

                 if (*actual->block[actualT].attributeValue.first->data.str != ' ')
                 {
                     actual->block[actualT].attributeValue.AddLast();
                 }
                 int i = 0;
                 last = actual->block[actualT].attributeValue.GetLast();
                 while ((l[character] != ';'))
                 {
                     last->data.str[i] = l[character];
                     i++;
                     character++;
                 }
                 last->data.str[i] = '\0';

                 //if there are duplicates, then we delete them
                 if (duplicate(actual->block[actualT].attributeName, actual->block[actualT].attributeName.GetLast()->data.str))
                 {
                     int position = findListPosition(actual->block[actualT].attributeName, actual->block[actualT].attributeName.GetLast()->data.str);
                     actual->block[actualT].attributeName.first = actual->block[actualT].attributeName.Delete(actual->block[actualT].attributeName.GetLast()->data.str);
                     actual->block[actualT].attributeValue.first = actual->block[actualT].attributeValue.DeletePosition(position);
                 }

             }
             break;
         }
     }
   }

   //cout << dlist.block[0].selector.first.data.str;

   /*
    cout << "data:";
    int t = actualT;
    actualT = 0;
    NodeBlock* tmp = dlist.first;
    cout << endl;
    int i = 0;
    while (i<dlist.first->counter)
    {
        Node* tmplist = tmp->block[actualT].selector.first;
        while (tmplist != NULL)
        {
            cout << tmplist->data.str << ", ";
            tmplist = tmplist->next;
        }
        cout << "{"<<endl;

        tmplist = tmp->block[actualT].attributeName.first;
        Node* tmplist2 = tmp->block[actualT].attributeValue.first;

        while (tmplist != NULL)
        {
            cout << tmplist->data.str << ":";
            cout << tmplist2->data.str << ";" << endl;
            tmplist = tmplist->next;
            tmplist2 = tmplist2->next;
        }
        cout << "}" << endl;
        if (actualT == 7)
        {
            actualT = 0;
            tmp = tmp->next;
        }
        else {
            actualT++;
        }
        i++;
    }
    cout << "koniec";
    */
}