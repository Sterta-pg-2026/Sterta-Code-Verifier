#include "list.h"

#include <iostream>

List::List()
{
	first = NULL;
}
List::~List()
{

}

Node* List::AddLast()
{
	Node* newNode = new Node();
	newNode->next = NULL;
	newNode->data.str = new char[256];
	Node* tmp = this->first;
	while (tmp->next != NULL)
	{
		tmp = tmp->next;
		
	}
	tmp->next = newNode;
	return tmp->next;
}
Node* List::GetLast()
{
		Node* tmp = new Node();
		tmp = this->first;
		if (tmp == NULL)
		{
			return NULL;
		}
		
		while (tmp->next != NULL)
		{
			tmp = tmp->next;
				
		}
		return tmp;
}
Node* List::Delete(char* n)
{
	Node* tmp = this->first;
	if (this->first == NULL)
	{
		return this->first;
	}
	if (!strcmp(this->first->data.str, n))
	{
		return this->first->next;
	}
	while (tmp->next != NULL)
	{
		if (!strcmp(tmp->next->data.str, n))
		{
			tmp->next = tmp->next->next;
			break;
		}
		tmp = tmp->next;
	}
	return this->first;

	return 0;
}

Node* List::DeletePosition(int x)
{
	int i = 0;
	Node* tmp = this->first;
	if (x<0)
	{
		return this->first;
	}
	if (x == 0)
	{
		return this->first->next;
	}
	while (tmp->next != NULL)
	{
		
		if (i+1==x)
		{
			
			tmp->next = tmp->next->next;
			break;
		}
		tmp = tmp->next;
		i++;
	}
	return this->first;

	return 0;
}
