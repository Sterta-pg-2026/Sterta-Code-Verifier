#include <iostream>
#include <string.h>

using namespace std;

const int T = 8; // Constant array size

bool char_equal(char* text, const char* t) //checks the equality of strings
{
	int a = strlen(text); //assigns text to a
	int b = strlen(t); //assigns text to b
	int max = a;
	if (b > a)
		max = b;
	for (int i = 0; i < max; ++i)
	{
		if (text[i] != t[i]) // compares strings
			return false;
	}
	return true;
}
//removes spaces
char* trim_string(char* text) 
{
	char* end;
	while (isspace((unsigned char)*text))
		text++;
	if (*text == 0)
		return text;
	end = text + strlen(text) - 1;
	while (end > text && isspace((unsigned char)*end))
		end--;
	*(end + 1) = '\0';
	return text;
}

// reset a string
void string_reset(char* str, int length)
{
	for (int i = 0; i < length; ++i)
	{
		str[i] = '\0';
	}
}

// append a char to a string
void append_char(char* str, char append)
{
	for (; *str != '\0'; ++str)
		;
	*str = append;
}
// append a string to a string
void append_string(char* str, char* append)
{
	for (; *str != '\0'; ++str)
		;
	for (; *append != '\0'; ++append)
	{
		*str = *append;
		++str;
	}
}
struct attribute // make an attribute
{
	char* name = new char[100];
	char* value = new char[100];

	attribute()
	{
		string_reset(name, 100);
		string_reset(value, 100);
	}

	friend ostream& operator<<(ostream& o, const attribute& a)
	{
		o << a.value;
		return o;
	}
};

struct selector // make a selector
{
	char* name = new char[100];

	selector* next = nullptr;

	selector()
	{
		string_reset(name, 100);
	}

	friend ostream& operator<<(ostream& o, const selector& s)
	{
		o << s.name;
		return o;
	}
};

struct section // make a doubly linked list for a section
{
	size_t attributes_size = 0;
	attribute* block;
	selector* selectors;

	section* prev = nullptr;
	section* next = nullptr;

	section()
	{
		block = new attribute[T]; // dynamic allocation
		selectors = new selector();
	}

	section* add_section() // add a new section
	{
		section* new_block = new section();
		this->next = new_block;
		new_block->prev = this;
		return new_block;
	}

	selector* new_selector()
	{ // add a new selector
		selector* s = selectors;
		while (s->next != nullptr)
		{
			s = s->next;
		}
		selector* new_selector = new selector();
		s->next = new_selector;
		return s->next;
	}

	void add_attribute(attribute a) // add a new attribute
	{
		//trim the attribute
		a.name = trim_string(a.name);
		a.value = trim_string(a.value);
		// enlarge block array
		if (attributes_size >= T)
		{
			attribute* cpy = new attribute[attributes_size + 1];
			for (int i = 0; i < attributes_size; ++i)
			{
				cpy[i] = block[i];
			}
			block = cpy;
		}
		block[attributes_size] = a;
		attributes_size++;
	}

	//checks if there is a selector
	bool selector_exists(char* name)
	{
		for (selector* current = selectors; current != nullptr; current = current->next)
		{
			if (char_equal(current->name, name))
				return true;
		}
		return false;
	}
	//gets an attribute
	attribute* get_attribute(char* name)
	{
		for (int i = 0; i < attributes_size; ++i)
		{
			if (char_equal(block[i].name, name))
			{
				return &(block[i]);
			}
		}
		return nullptr;
	}
	//removes an attribute
	void remove_attribute(int index_to_remove)
	{
		// Shift elements after index_to_remove one position to the left
		for (int i = index_to_remove; i < attributes_size - 1; i++)
		{
			block[i] = block[i + 1];
		}

		// Decrement attributes_size
		attributes_size--;
	}
	//removes attribute
	bool remove_attribute(char* name)
	{
		for (int index_to_remove = 0; index_to_remove < attributes_size; ++index_to_remove)
		{
			if (char_equal(block[index_to_remove].name, name))
			{
				remove_attribute(index_to_remove);
				return true;
			}
		}
		return false;
	}
};
//engine for checking the code css
section* parse_css(char* css)
{
	bool selectors_or_section = true;
	bool name_or_value = true;

	section* current_section = new section();
	selector* current_selector = current_section->selectors;
	attribute* current_attribute = new attribute();

	for (int i = 0; css[i] != '\0'; ++i)
	{
		if (css[i] == '\n' || css[i] == '\t')
			continue;
		if (selectors_or_section)
		{
			// add to current selector
			if (css[i] == ',')
			{
				// new selector
				//trim the selector before
				current_selector->name = trim_string(current_selector->name);
				current_selector = current_section->new_selector();
			}
			else if (css[i] == '{')
			{
				current_selector->name = trim_string(current_selector->name);
				selectors_or_section = false;
			}
			else
			{
				append_char(current_selector->name, css[i]);
			}
		}
		else if (!selectors_or_section && name_or_value && css[i] != '}')
		{ // name check
			if (css[i] == ':')
			{
				name_or_value = false; // change to value
			}
			else
			{
				append_char(current_attribute->name, css[i]);
			}
		}
		else if (!name_or_value && css[i] != '}')
		{
			if (css[i] == ';')
			{
				name_or_value = true; // change to name
				// add the current attribute to the current block
				current_section->add_attribute(*current_attribute);
				// create a new attribute
				current_attribute = new attribute();
			}
			else
			{
				append_char(current_attribute->value, css[i]);
			}
		}
		else if (css[i] == '}')
		{
			// end the block add next current section
			current_section = current_section->add_section();
			current_selector = current_section->selectors;
			selectors_or_section = true; // change to selector
			name_or_value = true;
		}
	}
	// get rid of last current_section
	current_section = current_section->prev;
	current_section->next = nullptr;
	while (current_section->prev != nullptr)
	{
		current_section = current_section->prev;
	}
	return current_section;
}
//gets a section
section* getSection(section* s, int i)
{
	section* current = s;
	for (int ix = 1; ix < i && current->next != nullptr; ++ix)
	{
		current = current->next;
	}
	return current;
}
//gets a selector
selector* getSelector(section* s, int i)
{
	selector* current = s->selectors;
	for (int ix = 1; ix < i && current->next != nullptr; ++ix)
	{
		current = current->next;
	}
	return current;
}
//counting selectors
int countSelectors(section* s)
{
	selector* current = s->selectors;
	int i = 1;
	for (; current->next != nullptr; ++i)
	{
		current = current->next;
	}
	return i;
}
//counting selectors
int countSections(section* s)
{ //?
	section* current = s;
	int i = 1;
	for (; current->next != nullptr; ++i)
	{
		current = current->next;
	}
	return i;
}
//counting attributes
int countAttributes(section* s)
{
	return s->attributes_size;
}
//search for the last attribute
attribute* getLastAttribute(section* s, char* sel, char* att)
{
	section* current = getSection(s, countSections(s));
	for (; current != nullptr; current = current->prev)
	{
		// check if selector sel is present in current section
		// otherwise continue
		if (!current->selector_exists(sel))
			continue;

		attribute* found = current->get_attribute(att);
		// return the attribute named att
		if (found != nullptr)
			return found;
	}
	return nullptr;
}
//counts selectors in the whole code
int countOccurancesSelectors(section* s, char* sel)
{
	int count = 0;
	for (section* current = s; current != nullptr; current = current->next)
	{
		for (selector* current_selector = current->selectors;
			current_selector != nullptr; current_selector = current_selector->next)
		{
			if (char_equal(current_selector->name, sel))
				count++;
		}
	}
	return count;
}
//counts attributes
int countAllAttributes(section* s, char* name)
{
	int count = 0;
	for (section* current = s; current != nullptr; current = current->next)
	{
		int section_count = 0;
		for (int i = 0; i < current->attributes_size; ++i)
		{
			if (char_equal(current->block[i].name, name))
			{
				++section_count;
				if (section_count > 1)
				{
					section_count--;
					current->remove_attribute(i);
				}
			}
		}
		count += (section_count > 0) ? 1 : 0;
	}
	return count;
}
//removes selector
bool removeSection(section* s, int i)
{
	if (countSections(s) < i)
		return false;
	section* to_be_deleted = getSection(s, i);
	// assing the parent's next to be the next of the section to be deleted
	if (to_be_deleted->prev != nullptr)
		(to_be_deleted->prev)->next = to_be_deleted->next;
	if (to_be_deleted->next != nullptr)
		(to_be_deleted->next)->prev = to_be_deleted->prev;
	if (i == 1) // in case of removing the first section, change the parent pointer to be the next element
		s = to_be_deleted->next;
	delete to_be_deleted;
	return true;
}
//removes attributes
bool removeAttribute(section* s, int i, char* n)
{
	if (countSections(s) < i)
		return false;
	bool ret = getSection(s, i)->remove_attribute(n);
	return ret;
}
//counts attributes in selectors
attribute* countAttributesForSelector(section* s, char* sel, char* name)
{
	int selectors = countOccurancesSelectors(s, sel);
	for (section* current = s; current->next != nullptr; current = current->next)
	{
		for (selector* current_selector = current->selectors;
			current_selector->next != nullptr; current_selector = current_selector->next)
		{
			if (char_equal(current_selector->name, sel))
				selectors--;
		}
		if (selectors <= 0)
		{
			return current->get_attribute(name);
		}
	}
	return nullptr;
}
//commands for selectors
void handleSelectors(section* s, char* first, char* third)
{
	int i = atoi(first);
	if (i == 0)
	{
		// first is a selector name
		// z,S,?
		// first is z
		cout << first << ",S,?"
			<< " == " << countOccurancesSelectors(s, first) << endl;
	}
	else
	{
		if (third[0] == '?')
		{
			// i,S,?
			// remove line break and append the count_selectors number
			if (countSections(s) >= i)
				cout << first << ",S,?"
				<< " == " << countSelectors(getSection(s, i)) << endl; // cursor goes up
		}
		else
		{
			// i,S,j
			int j = atoi(third);
			if (countSections(s) >= i)
				if (countSelectors(getSection(s, i)) >= j)
					cout << first << ",S," << third << " == " << *(getSelector(getSection(s, i), j)) << endl;
		}

		// first is 'i'
	}
}
//commands for attributes
void handleAttributes(section* s, char* first, char* third)
{
	int i = atoi(first);
	if (i == 0)
	{
		// n,A,?
		if (third[0] == '?')
			cout << first << ",A,?"
			<< " == " << countAllAttributes(s, first) << endl;
		else // z,E,n
		{
			attribute* att = getLastAttribute(s, first, third);
			if (att != nullptr)
				cout << first << ",E," << third << " == " << *att << endl;
		}

	}
	else
	{
		// i,A,?
		if (third[0] == '?')
		{
			if (countSections(s) >= i)
				cout << first << ",A,?"
				<< " == " << getSection(s, i)->attributes_size << endl;
		}
		else
		{
			// i,A,n
			if (countSections(s) >= i)
			{
				attribute* att = getSection(s, i)->get_attribute(third);
				if (att != nullptr)
					cout << first << ",A," << third << " == " << *att << endl;

			}
		}
	}
}
//commands
section* handleCommand(section* s, char* line)
{
	int number = 0;
	char first[50];
	char second = 0;
	char third[50];
	string_reset(first, 50);
	string_reset(third, 50);
	if (line[0] == '?')
	{
		cout << "? == " << countSections(s) << endl;
		return s;
	}
	for (int i = 0; line[i] != '\0'; ++i)
	{
		switch (line[i])
		{
		case ',':
			// increment the current pointer
			number++;
			break;
		default:
			if (number == 0)
				append_char(first, line[i]);
			else if (number == 1)
				second = line[i];
			else
				append_char(third, line[i]);
			break;
		}
	}
	switch (second)
	{
	case 'S':
		handleSelectors(s, first, third);
		break;
	case 'E':
	case 'A':
		handleAttributes(s, first, third);
		break;
	case 'D':
		if (third[0] == '*')
		{
			// remove the whole section
			// i,D,*
			section* n = s->next;
			if (removeSection(s, atoi(first)))
			{
				if (atoi(first) == 1)
					s = n;
				cout << first << ",D,*" << " == deleted" << endl;
			}
		}
		else
		{
			// remove the attribute named n
			// i,D,n

			section* n = s->next;
			if (removeAttribute(s, atoi(first), third))
			{
				cout << first << ",D," << third << " == deleted" << endl;
				if (s->attributes_size <= 0)
				{
					removeSection(s, atoi(first));
					if (atoi(first) == 1)
						s = n;
				}
			}
		}
		break;
	}
	return s;
}

int main()
{
	bool cssEdit = true; //css code
	bool commandSession = false; //command input

	char* css = new char[2000000]; //code css
	section* my_section = new section();
	string_reset(css, 2000000); // filled the css array with a string term.
	while (true)
	{
		char* line = new char[200]; //command input
		string_reset(line, 200);
		cin.getline(line, 200);	// input
		if (atoi(line) <= 126) { 
			if (char_equal(line, "????")) // check if input equals to ????
			{
				commandSession = true;
				cssEdit = false;
				my_section = parse_css(css);
				continue;
			}
			if (cssEdit)
			{
				// append line to css (at the end of it)
				append_string(css, line);
			}

			if (commandSession)
			{
				my_section = handleCommand(my_section, line);
			}

			if (char_equal(line, "****")) // check if input equals to****
			{
				commandSession = false;
				cssEdit = true;
				continue;
			}
		}
		else break;
	}
	cout << endl;
	cout << css;
	return 0;
}
