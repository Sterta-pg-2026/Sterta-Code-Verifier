#pragma once
#include <iostream>

class String{
private:
    char* data;
    int size;

public:
    String() : data(nullptr), size(0) {}
    String(const char* str)
    {
        if (str != nullptr)
        {
            size = strlen(str);
            data = new char[size + 1];
            for (int i = 0; i < size + 1; i++)
            {
                data[i] = str[i];
            }
            data[size] = '\0';
        }
        else
        {
            data = nullptr;
            size = 0;
        }
    }
    String(const String& other) : size(other.size) {
        data = new char[size+1];
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
        data[size] = '\0';
    }

    ~String() {
        if (data != nullptr)
            delete[] data;
        data = nullptr;
        size = 0;
    }

    String& operator=(const String& other) {
        if (data != nullptr && size != 0)
            delete[] data;
        size = other.size;
        data = new char[size+1];
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
        data[size] = '\0';
        return *this;
    }

    char& operator[](int index) {
        return data[index];
    }
    const char& operator[](int index) const {
        return data[index];
    }


    int getLength() const {
        return size;
    }
    const char* getString() const {
        return data;
    }

    void append_char(char c) {
        char* new_data = new char[size + 2];
        for (int i = 0; i < size; ++i) {
            new_data[i] = data[i];
        }
        new_data[size] = c;
        new_data[size + 1] = '\0';
        delete[] data;
        data = new_data;
        ++size;
    }

    void clear() {
        if (data != nullptr)
            delete[] data;
        data = nullptr;
        size = 0;
    }

    void remove_spaces() {
        int first_non_space = 0, last_non_space = size - 1;

        while (first_non_space < size && data[first_non_space] == ' ') {
            first_non_space++;
        }

        while (last_non_space >= 0 && data[last_non_space] == ' ') {
            last_non_space--;
        }
        char* new_data = new char[last_non_space - first_non_space + 2];
        int j = 0;
        for (int i = first_non_space; i <= last_non_space; i++) {
            new_data[j] = data[i];
            j++;
        }
        new_data[j] = '\0';
        delete[] data;
        data = new_data;
        size = last_non_space - first_non_space + 1;
    }

    void remove_char(char c) {
        if (size <= 0) return;
        char* new_data = new char[size+1];

        int j = 0;
        for (int i = 0; i < size; i++)
        {
            if (data[i] != c) {
                new_data[j] = data[i];
                j++;
            }
        }
        new_data[j] = '\0';
        delete[] data;
        data = new_data;
        size = j;
    }

    friend bool operator==(const String& lhs, const String& rhs) {
        if (lhs.size != rhs.size) {
            return false;
        }
        for (int i = 0; i < lhs.size; ++i) {
            if (lhs.data[i] != rhs.data[i]) {
                return false;
            }
        }
        return true;
    }
    friend bool operator!=(const String& lhs, const String& rhs) {
        return !(lhs == rhs);
    }

    friend std::ostream& operator<<(std::ostream& os, const String& str) {
        os << str.data;
        return os;
    };

    bool containsOnlyDigit() const {
        for (int i = 0; i < size; i++) {
            if (isdigit(data[i]) == false) {
                return false;
            }
        }
        return true;
    }

    String* split(char delimiter) {
        int output_size = 1;
        for (int i = 0; i < size; i++) {
            if (data[i] == delimiter) {
                output_size++;
            }
        }
        int part_start = 0;
        int part_index = 0;
        String* output = new String[output_size];

        for (int i = 0; i < size; i++) {
            if (data[i] == delimiter || i == size - 1) {
                int part_size;
                if (i == size - 1) {
                    part_size = i - part_start + 1;
                }
                else {
                    part_size = i - part_start;
                }

                char* part = new char[part_size + 1];
                for (int j = 0; j < part_size; j++) {
                    part[j] = data[part_start + j];
                }
                part[part_size] = '\0';
                output[part_index] = String(part);

                part_index++;
                part_start = i + 1;
                delete[] part;
            }
        }
        return output;
    }

    int toInt() const {
        int result = 0;
        for (int i = 0; i<size; i++) {
            if (data[i] >= '0' && data[i] <= '9') {
                result = result * 10 + (data[i] - '0');
            }
            else {
                return 0;
            }
        }
        return result;
    }

    int countChar(char c) const {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (data[i] == c) {
                count++;
            }
        }
        return count;
    }

};
