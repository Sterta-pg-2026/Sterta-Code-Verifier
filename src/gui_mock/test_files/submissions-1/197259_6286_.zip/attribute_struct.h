#pragma once
#include "str.h"
#include <iostream>

struct Attribute {
    String name;
    String value;
};