#pragma once
#include "array_of_sections.h"

class List_of_Arrays {
private:
    struct Node {
        Array_of_Sections data;
        Node* prev;
        Node* next;

        Node(const Array_of_Sections& arr) : data(arr), prev(nullptr), next(nullptr) {}
    };

    Node* head;
    Node* tail;

public:
    List_of_Arrays() : head(nullptr), tail(nullptr) {}
    ~List_of_Arrays() {
        while (head) {
            Node* next = head->next;
            delete head;
            head = next;
        }
    }

    void push_back_Array(const Array_of_Sections& arr) {
        Node* node = new Node(arr);
        if (!tail) {
            head = node;
            tail = node;
        }
        else {
            node->prev = tail;
            tail->next = node;
            tail = node;
        }
    }

    void addNewSection(const Section& section) {
        Node* current = tail;
        while (current) {
            if (current->data.countOccupiedSections() != current->data.getSize()) {
                current->data.push_back_Section(section);
                return;
            }
            current = current->prev;
        }

        // no space left, add new array
        Array_of_Sections new_array;
        new_array.push_back_Section(section);
        push_back_Array(new_array);
    }

    Array_of_Sections& operator[](int index) {
        Node* current = head;
        int i = 0;
        while (current && i < index) {
            current = current->next;
            i++;
        }
        if (!current) {
            throw std::out_of_range("Index out of range!");
        }
        return current->data;
    }

    int size() const {
        int count = 0;
        Node* current = head;
        while (current) {
            count++;
            current = current->next;
        }
        return count;
    }

    int countSections() const {
        int count = 0;
        Node* current = head;
        while (current) {
            for (int i = 0; i < current->data.getSize(); i++) {
                if (!current->data[i].empty()) {
                    count++;
                }
            }
            current = current->next;
        }
        return count;
    }

    int countAttribute(String& attributeName) {
        int count = 0;
        Node* current = head;
        while (current) {
            for (int i = 0; i < current->data.getSize(); i++) {
                bool attributeFound = false;
                for (int j = 0; j < current->data[i].attributes.get_size(); j++) {
                    if (current->data[i].attributes[j].name == attributeName) {
                        if (!attributeFound) {
                            attributeFound = true;
                            count++;
                        }
                    }
                }
            }
            current = current->next;
        }
        return count;
    }

    int countSelector(String& selector) {
        int count = 0;
        Node* current = head;
        while (current) {
            for (int i = 0; i < current->data.getSize(); i++) {
                for (int j = 0; j < current->data[i].selectors.get_size(); j++) {
                    if (current->data[i].selectors[j] == selector) {
                        count++;
                    }
                }
            }
            current = current->next;
        }
        return count;
    }

    String getAttributeValue(String z, String n) {
        String value;
        Node* current = tail;
        while (current) {
            for (int i = current->data.getSize() - 1; i >= 0; i--) {
                if (current->data[i].selectors.contains(z)) {
                    for (int j = current->data[i].attributes.get_size() - 1; j >= 0; j--) {
                        if (current->data[i].attributes[j].name == n) {
                            value = current->data[i].attributes[j].value;
                            return value;
                        }
                    }
                }
            }
            current = current->prev;
        }
        return nullptr;
    }

    bool removeSection(int blockIndex, int sectionIndex) {
        Node* current = head;
        int i = 0;
        while (current && i < blockIndex) {
            current = current->next;
            i++;
        }
        if (!current) {
            return false;
        }
        if (current->data.remove(sectionIndex))
        {
            if (current->data.countOccupiedSections() == 0) {
                if (current == head) {
                    head = current->next;
                }
                else {
                    current->prev->next = current->next;
                }
                if (current == tail) {
                    tail = current->prev;
                }
                else {
                    current->next->prev = current->prev;
                }
                delete current;
            }
            return true;
        }
            
        return false;
    }

    bool removeAttribute(int blockIndex, int sectionIndex, String& attributeName) {
        Node* current = head;
        int i = 0;
        while (current && i < blockIndex) {
            current = current->next;
            i++;
        }
        if (!current) {
            return false;
        }
        if (current->data[sectionIndex].attributes.remove_attribute(attributeName)) {
            if (current->data[sectionIndex].attributes.get_size() == 0) {
                current->data.remove(sectionIndex);
            }
            if (current->data.countOccupiedSections() == 0) {
                if (current == head) {
                    head = current->next;
                }
                else {
                    current->prev->next = current->next;
                }
                if (current == tail) {
                    tail = current->prev;
                }
                else {
                    current->next->prev = current->prev;
                }
                delete current;
            }
            return true;
        }
        return false;
    }

    bool isSectionValid(int blockIndex, int sectionIndex) const {
        Node* current = head;
        int i = 0;
        while (current && i < blockIndex) {
            current = current->next;
            i++;
        }
        if (!current) {
            return false;
        }
        if (sectionIndex < 0 || sectionIndex >= current->data.getSize()) {
            return false;
        }
        return !current->data[sectionIndex].empty();
    }

    bool isBlockValid(int index) const {
        if (index < 0 || index >= size()) {
            return false;
        }
        Node* current = head;
        int i = 0;
        while (current && i < index) {
            current = current->next;
            i++;
        }
        if (!current) {
            return false;
        }
        for (int i = 0; i < current->data.getSize(); i++) {
            if (!current->data[i].empty()) {
                return true;
            }
        }
        return false;
    }

    int findNonEmptySectionIndex(int n) {
        int count = 0;
        int empty_sections = 0;
        Node* current = head;
        while (current) {
            for (int i = 0; i < current->data.getSize(); i++) {
                if (!current->data[i].empty()) {
                    count++;
                    if (count == n) {
                        return count + empty_sections - 1;
                    }
                }
                else empty_sections++;
            }
            current = current->next;
        }
        return -1;
    }


    friend std::ostream& operator<<(std::ostream& os, List_of_Arrays& list) {
        Node* current = list.head;
        int i = 0;
        while (current) {
            os << "Array no." << i <<"\n";
            os << current->data << "\n";
            i++;
            current = current->next;
        }
        return os;
    }
};
