#pragma once
#include <iostream>
#include "str.h"
#include "css_section.h"
#include "list_of_attributes.h"
#include "list_of_selectors.h"
#include "list_of_arrays.h"
#include "array_of_sections.h"
using namespace std;


/// SEKCJA BOOLI

void starts_of_sections(int& c, int& question_mark_counter, int& star_counter, bool& czy_sekcja_css, String& input) {
    if (c == '?')
        question_mark_counter++;
    else question_mark_counter = 0;

    if (question_mark_counter == 4) {
        czy_sekcja_css = false;
        input.clear();
    }
    if (c == '*')
        star_counter++;
    else star_counter = 0;

    if (star_counter == 4) {
        czy_sekcja_css = true;
        input.clear();
    }
}

/// SEKCJA PARSOWANIA

void add_to_selectors(String& input, List_of_Selectors& selectors) {
    if (input != nullptr)
    {
        input.remove_char('\n');
        input.remove_char('}');
        input.remove_char(',');
        input.remove_char('{');
        input.remove_char('\t');
        input.remove_spaces();
        if (input != "")
            selectors.add_selector(input);
        input.clear();
    }
}
void add_name_to_attributes(String& input, List_of_Attributes& attributes) {
    if (input != nullptr)
    {
        input.remove_char('\n');
        input.remove_char(':');
        input.remove_char('\t');
        input.remove_spaces();
        if (input != "")
            attributes.add_name(input);
        input.clear();
    }
}
void add_value_to_attributes(String& input, List_of_Attributes& attributes) {
    if (input != nullptr) {
        input.remove_char('\t');
        input.remove_char('\n');
        input.remove_char(';');
        input.remove_char('}');
        input.remove_spaces();
        if (input != "")
            attributes.add_value(input);
        input.clear();
    }
}

void add_section(String& input, List_of_Attributes& attributes, List_of_Selectors& selectors, Section& css, Array_of_Sections& sections, List_of_Arrays& list_of_arrays) {
    selectors.remove_duplicates();
    css.selectors = selectors;
    css.attributes = attributes;

    int last_index = list_of_arrays.size() - 1;
    if (list_of_arrays.size() == 0 || !list_of_arrays[last_index].push_back_Section(css))
    {
        sections = Array_of_Sections();
        sections.push_back_Section(css);
        list_of_arrays.push_back_Array(sections);
    }

    selectors = List_of_Selectors();
    attributes = List_of_Attributes();
    css = Section();
}

void Parsing_section(bool& is_selectors, bool& is_attributes, int& c, String& input, List_of_Attributes& attributes, List_of_Selectors& selectors, Section& css, Array_of_Sections& sections, List_of_Arrays& list_of_arrays) {
    if (is_selectors)
    {
        if (c == '{' || c == ',')
        {
            add_to_selectors(input, selectors);
        }
    }
    if (c == '{') {
        is_attributes = true;
        is_selectors = false;
    }
    if (is_attributes)
    {
        if (c == ':')
        {
            add_name_to_attributes(input, attributes);

        }
        else if (c == ';' || c == '}')
        {
            add_value_to_attributes(input, attributes);
        }
    }
    if (c == '}') {
        is_selectors = true;
        is_attributes = false;

        add_section(input, attributes, selectors, css, sections, list_of_arrays);
    }
}


/// SEKCJA KOMEND



void S_commands_starting_with_number(String*& command, String& input, int& block_index, int& section_index_in_block, List_of_Arrays& list_of_arrays) {
    if (command[2] == "?") {
        cout << input << " == " << list_of_arrays[block_index][section_index_in_block].selectors.get_size() << endl;
    }
    else {
        int selector_index = command[2].toInt() - 1;
        if (selector_index < list_of_arrays[block_index][section_index_in_block].selectors.get_size())
            cout << input << " == " << list_of_arrays[block_index][section_index_in_block].selectors[selector_index] << endl;
    }
}
void A_commands_starting_with_number(String*& command, String& input, int& block_index, int& section_index_in_block, List_of_Arrays& list_of_arrays) {
    if (command[2] == "?") {
        cout << input << " == " << list_of_arrays[block_index][section_index_in_block].attributes.count_unique_attributes() << endl;
    }
    else {
        if (list_of_arrays[block_index][section_index_in_block].attributes.find_value_by_name(command[2]) != nullptr)
            cout << input << " == " << list_of_arrays[block_index][section_index_in_block].attributes.find_value_by_name(command[2]) << endl;
    }
}
void D_commands_starting_with_number(String*& command, String& input, int& block_index, int& section_index_in_block, List_of_Arrays& list_of_arrays) {
    if (command[2] == "*") {
        if (list_of_arrays.removeSection(block_index, section_index_in_block)) {
            cout << input << " == " << "deleted" << endl;
        }
    }
    else {
        if (list_of_arrays.removeAttribute(block_index, section_index_in_block, command[2]))
            cout << input << " == " << "deleted" << endl;
    }
}

void Commands_starting_with_number(String& input, String*& command, Array_of_Sections& sections, List_of_Arrays& list_of_arrays) {
    int index = command[0].toInt();
    int non_empty_index = list_of_arrays.findNonEmptySectionIndex(index); //indeks i-tej niepustej sekcji
    int block_index = non_empty_index / sections.getSize(); //indeks bloku
    int section_index_in_block = non_empty_index % sections.getSize(); //indeks sekcji w bloku

    if (list_of_arrays.isBlockValid(block_index) && list_of_arrays.isSectionValid(block_index, section_index_in_block)) {
        if (command[1] == "S") {
            S_commands_starting_with_number(command, input, block_index, section_index_in_block, list_of_arrays);
        }
        else if (command[1] == "A") {
            A_commands_starting_with_number(command, input, block_index, section_index_in_block, list_of_arrays);
        }
        else if (command[1] == "D") {
            D_commands_starting_with_number(command, input, block_index, section_index_in_block, list_of_arrays);
        }
    }
}

void Commands_starting_with_name(String& input, String*& command, List_of_Arrays& list_of_arrays) {
    if (command[1] == "A")
        cout << input << " == " << list_of_arrays.countAttribute(command[0]) << endl;
    else if (command[1] == "S")
        cout << input << " == " << list_of_arrays.countSelector(command[0]) << endl;
    else if (command[1] == "E") {
        if (list_of_arrays.getAttributeValue(command[0], command[2]) != nullptr)
            cout << input << " == " << list_of_arrays.getAttributeValue(command[0], command[2]) << endl;
    }
}

void Command_section(int& c, String*& command, String& input, Array_of_Sections& sections, List_of_Arrays& list_of_arrays) {
    if (c == '\n' || c == EOF) {
        input.remove_char('\n');
        input.remove_char(EOF);
        if (input != nullptr)
        {
            //case "?"
            if (input == "?") {
                cout << input << " == " << list_of_arrays.countSections() << endl;
            }
            // other cases
            else if (input.countChar(',') == 2)
            {
                command = input.split(',');
                command[0].remove_spaces();
                command[1].remove_spaces();
                command[2].remove_spaces();
                if (command[0].containsOnlyDigit())
                {
                    Commands_starting_with_number(input, command, sections, list_of_arrays);
                }
                else {
                    Commands_starting_with_name(input, command, list_of_arrays);
                }
            }
            input.clear();
        }
    }
}