#pragma once
#include "css_section.h"
class Array_of_Sections {
private:
    static const int T = 17;
    Section sections[T];
public:
    Array_of_Sections() {}
    ~Array_of_Sections() {}

    void setSection(int index, const Section& section) {
        if (index < 0 || index >= T) {
            throw std::out_of_range("Index out of range!");
        }
        sections[index] = section;
    }
    bool push_back_Section(const Section& section) {
        for (int i = 0; i < T; i++) {
            if (sections[i].empty()) {
                sections[i] = section;
                return true;
            }
        }
        return false;
    }

    int getSize() const {
        return T;
    }

    Section& operator[](int index) {
        if (index < 0 || index >= T) {
            throw std::out_of_range("Index out of range!");
        }
        return sections[index];
    }

    bool remove(int index) {
        if (index < 0 || index >= T) {
            return false;
        }
        if (sections[index].empty()) {
            return false;
        }
        for (int i = index + 1; i < T; i++) {
            sections[i - 1] = sections[i];
        }
        sections[T-1] = Section();
        return true;
    }

    int countOccupiedSections() {
        int count = 0;
        for (int i = 0; i < T; i++) {
            if (!sections[i].empty()) {
                count++;
            }
        }
        return count;
    }

    friend std::ostream& operator<<(std::ostream& os, Array_of_Sections& sectionArray) {
        for (int i = 0; i < T; i++) {
            os << "Index[" << i << "]\n";
            os << sectionArray[i] << "\n";
        }
        return os;
    }
};