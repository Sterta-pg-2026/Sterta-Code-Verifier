#pragma once
#include <iostream>
#include "str.h"

class List_of_Selectors {
private:
    struct Node {
        String selector;
        Node* next;
        Node* prev;

        Node() : next(nullptr), prev(nullptr) {}
    };

    Node* head;
    Node* tail;
    int size;

public:
    List_of_Selectors() : head(nullptr), tail(nullptr), size(0) {}

    List_of_Selectors(const List_of_Selectors& other) : head(nullptr), tail(nullptr), size(0) {
        Node* current = other.head;
        while (current != nullptr) {
            add_selector(current->selector);
            current = current->next;
        }
    }

    ~List_of_Selectors() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void add_selector(String s) {
        Node* new_node = new Node;
        new_node->selector = s;

        if (head == nullptr) {
            head = new_node;
            tail = new_node;
        }
        else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
        size++;
    }
    void clear() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        tail = nullptr;
        size = 0;
    }

    List_of_Selectors& operator=(const List_of_Selectors& other) {
        if (this == &other) {
            return *this;
        }
        clear();
        Node* current = other.head;
        while (current != nullptr) {
            add_selector(current->selector);
            current = current->next;
        }
        return *this;
    }

    int get_size() const {
        return size;
    }

    void remove_duplicates() {
        Node* current = head;
        while (current != nullptr) {
            Node* runner = current->next;
            while (runner != nullptr) {
                if (current->selector == runner->selector) {
                    Node* temp = runner;
                    runner = runner->next;
                    if (temp == head) {
                        head = temp->next;
                    }
                    else {
                        temp->prev->next = temp->next;
                    }
                    if (temp == tail) {
                        tail = temp->prev;
                    }
                    else {
                        temp->next->prev = temp->prev;
                    }
                    delete temp;
                    size--;
                }
                else {
                    runner = runner->next;
                }
            }
            current = current->next;
        }
    }

    bool contains(String& s) {
        Node* current = head;
        while (current != nullptr) {
            if (current->selector == s) {
                return true;
            }
            current = current->next;
        }
        return false;
    }


    String& operator[](int index) {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        return current->selector;
    }


    friend std::ostream& operator<<(std::ostream& os, const List_of_Selectors& selectors) {
        Node* current = selectors.head;
        while (current != nullptr) {
            os << current->selector << "\n";
            current = current->next;
        }
        return os;
    }
};