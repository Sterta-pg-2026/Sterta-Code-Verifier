#include <iostream>
#include "str.h"
#include "css_section.h"
#include "list_of_attributes.h"
#include "list_of_selectors.h"
#include "list_of_arrays.h"
#include "array_of_sections.h"
#include "main_functions.h"
using namespace std;

int main() {
    String input;

    Array_of_Sections sections;
    List_of_Selectors selectors;
    List_of_Attributes attributes;
    List_of_Arrays list_of_arrays;
    Section css;

    int question_mark_counter = 0;
    int star_counter = 0;

    int c;
    String* command = {};

    bool czy_sekcja_css = true;
    bool is_selectors = true;
    bool is_attributes = false;

    list_of_arrays.push_back_Array(sections);

    do {
        c = getchar();
        if (c >= ' ')
            input.append_char((char)c);

        starts_of_sections(c, question_mark_counter, star_counter, czy_sekcja_css, input);

        if (czy_sekcja_css)
        {
            Parsing_section(is_selectors, is_attributes, c, input, attributes, selectors, css, sections, list_of_arrays);
        }
        else {
            Command_section(c, command, input, sections, list_of_arrays);
        }
    }  while (c != EOF);

    return 0;
}