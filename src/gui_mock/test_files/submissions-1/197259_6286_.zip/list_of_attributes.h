#pragma once
#include <iostream>
#include "str.h"
#include "attribute_struct.h"

class List_of_Attributes {
private:
    struct Node {
        Attribute attribute;
        Node* next;
        Node* prev;

        Node() : next(nullptr), prev(nullptr) {}
    };

    Node* head;
    Node* tail;
    int size;

public:
    // konstruktor
    List_of_Attributes() : head(nullptr), tail(nullptr), size(0) {}

    List_of_Attributes(const List_of_Attributes& other) : head(nullptr), tail(nullptr), size(0) {
        Node* current = other.head;
        while (current != nullptr) {
            add_name(current->attribute.name);
            add_value(current->attribute.value);
            current = current->next;
        }
    }

    // destruktor
    ~List_of_Attributes() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    // metody
    void add_name(String& name) {
        Node* new_node = new Node;
        new_node->attribute.name = name;

        if (head == nullptr) {
            head = new_node;
            tail = new_node;
        }
        else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }

        size++;
    }

    void add_value(String& value) {
        if (tail == nullptr) {
            throw std::out_of_range("No name added yet");
        }
        tail->attribute.value = value;
    }

    int get_size() const {
        return size;
    }

    List_of_Attributes& operator=(const List_of_Attributes& other) {
        if (this != &other) {
            while (head != nullptr) {
                Node* temp = head;
                head = head->next;
                delete temp;
            }
            tail = nullptr;
            size = 0;

            Node* current = other.head;
            while (current != nullptr) {
                add_name(current->attribute.name);
                add_value(current->attribute.value);
                current = current->next;
            }
        }
        return *this;
    }



    Attribute& operator[](int index) {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        return current->attribute;
    }

    friend std::ostream& operator<<(std::ostream& os, const List_of_Attributes& attributes) {
        Node* current = attributes.head;
        while (current != nullptr) {
            os << current->attribute.name << ": " << current->attribute.value << "\n";
            current = current->next;
        }
        return os;
    }

    void print_attribute(int index) const {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        std::cout << current->attribute.name << ": " << current->attribute.value << "\n";
    }

    String find_value_by_name(String name) const {
        Node* current = head;
        String value;
        while (current != nullptr) {
            if (current->attribute.name == name) {
                value = current->attribute.value;
            }
            current = current->next;
        }
        return value;
    }

    bool remove_attribute(String name) {
        Node* current = head;
        while (current != nullptr) {
            if (current->attribute.name == name) {
                if (current == head) {
                    head = current->next;
                    if (head != nullptr) {
                        head->prev = nullptr;
                    }
                }
                else if (current == tail) {
                    tail = current->prev;
                    tail->next = nullptr;
                }
                else {
                    current->prev->next = current->next;
                    current->next->prev = current->prev;
                }
                size--;
                delete current;
                return true;
            }
            current = current->next;
        }
        return false;
    }

    int count_unique_attributes() const {
        List_of_Attributes unique_names;
        Node* current = head;
        while (current != nullptr) {
            bool name_exists = false;
            Node* unique_current = unique_names.head;
            while (unique_current != nullptr) {
                if (unique_current->attribute.name == current->attribute.name) {
                    name_exists = true;
                    break;
                }
                unique_current = unique_current->next;
            }
            if (!name_exists) {
                unique_names.add_name(current->attribute.name);
            }
            current = current->next;
        }
        return unique_names.get_size();
    }
};