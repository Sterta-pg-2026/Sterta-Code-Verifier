#pragma once
#include "list_of_selectors.h"
#include "list_of_attributes.h"
struct Section {
	List_of_Selectors selectors;
	List_of_Attributes attributes;

	Section& operator=(const Section& other) {
		if (this != &other) {
			selectors = other.selectors;
			attributes = other.attributes;
		}
		return *this;
	}

	bool empty() const {
		if (attributes.get_size() == 0 && selectors.get_size() == 0)
			return true;
		else return false;
	}

	friend std::ostream& operator<<(std::ostream& os, const Section& section) {
		os << "Selectors:\n" << section.selectors << "\n";
		os << "Attributes:\n" << section.attributes;
		return os;
	}
};
