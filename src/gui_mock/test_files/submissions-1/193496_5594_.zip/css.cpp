#include <iostream>
#include "string.h"
#define NUMBER_MAX 29
#define SELEKTOR 1
#define ATRYBUT 2
#define PARSOWANIE 10
#define KOMENDY 11
#define NIE 100
#define TAK 101
#define MOZNA 102
#define NIE_MOZNA 103
#define NAZWA_ATRYBUTU 10
#define WARTOSC_ATRYBUTU 11
using namespace std;

class ATTRIBUTE {
public:
	STRING nazwa;
	STRING value;
	ATTRIBUTE* next = NULL;
};

class SELECTOR {
public:
	STRING name;
	SELECTOR* next = NULL;
	ATTRIBUTE* list_at = NULL;
};

class BLOCK {
public:
	BLOCK* next = NULL;
	BLOCK* prev = NULL;
	int licznik = 0;
	SELECTOR* list_sel = NULL;
};

struct variables {
	STRING attr_name, attr_val, sel, word, space, free, pars, kom;
	int doing, mozna, moge, pozycja, wczytywanie, wyraz, spacja, wczyt;
	BLOCK* block_list;
	ATTRIBUTE* attr_list;
};

ATTRIBUTE* AddAttribute(ATTRIBUTE* list, STRING nazwa, STRING value) {
	ATTRIBUTE* nowa = new ATTRIBUTE;
	nowa->nazwa = nazwa;
	nowa->value = value;
	if (list == NULL) {
		list = nowa;
	}
	else {
		ATTRIBUTE* temp = list;
		while (temp->next != NULL) {
			temp = temp->next;
		}
		temp->next = nowa;
		nowa->next = NULL;
	}
	return list;
}
int ChechAttrExist(ATTRIBUTE* list, STRING nazwa, STRING value) {
	if (list == NULL) return 0;
	else {
		ATTRIBUTE* temp = list;
		while (temp != NULL) {
			if (temp->nazwa == nazwa) {
				temp->value = value;
				return 1;
			}
			temp = temp->next;
		}
	}
	return 0;
}
SELECTOR* AddSelector(SELECTOR* list, STRING name, ATTRIBUTE* list_at) {
	SELECTOR* nowa = new SELECTOR;
	nowa->name = name;
	nowa->list_at = list_at;
	if (list == NULL) {
		list = nowa;
	}
	else {
		SELECTOR* temp = list;
		while (temp->next != NULL) {
			temp = temp->next;
		}
		temp->next = nowa;
		nowa->next = NULL;
	}
	return list;
}
BLOCK* GetLast(BLOCK* firstNode) {
	if (firstNode == NULL) {
		return NULL;
	}
	BLOCK* temp = firstNode;
	while (temp->next != NULL) {
		temp = temp->next;
	}
	return temp;
}
BLOCK* AddSelectorToBlock(BLOCK* list, STRING name, ATTRIBUTE* list_al) {
	if (list == NULL) {
		BLOCK* nowa = new BLOCK;
		nowa->list_sel = AddSelector(nowa->list_sel, name, list_al);
		nowa->licznik++;
		return nowa;
	}
	else {
		BLOCK* last = GetLast(list);
		if (last->licznik < NUMBER_MAX) {
			last->list_sel = AddSelector(last->list_sel, name, list_al);
			last->licznik++;
			return list;
		}
		else {
			BLOCK* nowy = new BLOCK;
			nowy->prev = last;
			nowy->list_sel = AddSelector(nowy->list_sel, name, list_al);
			nowy->licznik++;
			if (last == NULL) {
				return nowy;
			}
			last->next = nowy;
			return list;
		}
	}
}
void Section_number(BLOCK* list) {
	if (list == NULL) { return; }
	int count = 0;
	BLOCK* temp = list;
	count = temp->licznik;
	while (temp->next != NULL) {
		temp = temp->next;
		count = count + temp->licznik;
	}
	std::cout << "? == " << count << endl;
}
void nazwa_na_pozycji(STRING napis, int position, int rem1, int rem2) {
	char napisik[100];
	int counter = 1, licznik_liter = 0;
	for (int j = 0; j < napis.length();j++) {
		if (napis.GetConcreteElement(j) == ',') {
			counter++;
		}
		else if (counter == position) {
			napisik[licznik_liter] = napis.GetConcreteElement(j);
			licznik_liter++;
		}
	}
	if (position <= counter) {
		STRING pom(napisik, licznik_liter);
		if (pom.GetConcreteElement(pom.length() - 1) == ',') pom = pom.WithoutLastElement();
		std::cout << rem2 << ",S," << rem1 << " == " << pom << endl;
	}
}
int znajdz_pozycje_bloku(BLOCK *list, int *position) {
	int counter=0;
	BLOCK* tymczasowy = list;
	while (tymczasowy != NULL && *position > tymczasowy->licznik) {
		*position = *position - tymczasowy->licznik;
		counter++;
		tymczasowy = tymczasowy->next;
	}
	return counter;
}
void licz__wystapienia_selektora(SELECTOR* temp, int rem, STRING pom) {
	if (temp->name.length() == 0) {
		std::cout << rem << ",S,? == 0" << endl;
		return;
	}
	int counter = 1;
	for (int i = 0; i < pom.length(); i++) {
		if (pom.GetConcreteElement(i) == ',') counter++;
	}
	std::cout << rem << ",S,? == " << counter << endl;
	return;
}
void wypisz_nazwe_na_pozycji(SELECTOR* temp, int rem1, int rem2, STRING pom) {
	if (temp->name.length() == 0) {
		return;
	}
	nazwa_na_pozycji(pom, rem1, rem1, rem2);
	return;
}

void liczba_atrybutow(ATTRIBUTE* tutaj, int rem2, SELECTOR* temp) {
	tutaj = temp->list_at;
	int count = 0;
	while (tutaj != NULL) {
		count++;
		tutaj = tutaj->next;
	}
	std::cout << rem2 << ",A,? == " << count << endl;
	return;
}
void wartosc_atrybutu(ATTRIBUTE* tutaj, int rem2, SELECTOR* temp, STRING nazwa) {
	tutaj = temp->list_at;
	while (tutaj != NULL) {
		if (tutaj->nazwa == nazwa) {
			std::cout << rem2 << ",A," << nazwa << " == " << tutaj->value << endl;
			return;
		}
		tutaj = tutaj->next;
	}
}
void szukaj_w_pierwszym_bloku(BLOCK*list, int num_block, int position, int parametr, STRING nazwa) {
	STRING pom;
	ATTRIBUTE* tutaj=NULL;
	int rem1 = num_block, rem2 = position;
	SELECTOR* temp = list->list_sel;
	while (temp != NULL) {
		if (position == 1) {
			pom = temp->name;
			if (parametr == 0) licz__wystapienia_selektora(temp, rem2, pom);
			else if (parametr == 1) wypisz_nazwe_na_pozycji(temp, rem1, rem2, pom);
			else if (parametr == 2) liczba_atrybutow(tutaj, rem2, temp);
			else if (parametr == 3) wartosc_atrybutu(tutaj, rem2, temp, nazwa);
		}
		position--;
		temp = temp->next;
	}
}
void szukaj_w_kolejnych_blokach(BLOCK* list, int num_block, int position, int parametr, STRING nazwa) {
	STRING pom;
	ATTRIBUTE* tutaj=NULL;
	int rem1 = num_block, rem2 = position;
	int count = znajdz_pozycje_bloku(list, &position);
	BLOCK* tmp = list;
	while (tmp != NULL) {
		if (count == 0) {
			SELECTOR* temp = tmp->list_sel;
			while (temp != NULL) {
				if (position == 1) {
					pom = temp->name;
					if (parametr == 0) licz__wystapienia_selektora(temp, rem2, pom);
					else if (parametr == 1) wypisz_nazwe_na_pozycji(temp, rem1, rem2, pom);
					else if (parametr == 2) liczba_atrybutow(tutaj, rem2, temp);
					else if (parametr == 3) wartosc_atrybutu(tutaj, rem2, temp, nazwa);
				}
				position--;
				temp = temp->next;
			}
		}
		count--;
		tmp = tmp->next;
	}
}
void NumAttrinAllSection(STRING nazwa, BLOCK* list) {
	int count = 0;
	BLOCK* tmp = list;
	while (tmp != NULL) {
		SELECTOR* temp = tmp->list_sel;
		while (temp != NULL) {
			ATTRIBUTE* tp = temp->list_at;
			while (tp != NULL) {
				if (tp->nazwa == nazwa) count++;
				tp = tp->next;
			}
			temp = temp->next;
		}
		tmp = tmp->next;
	}
	std::cout << nazwa << ",A,? == " << count << endl;
}
bool CzyZawieraNazwe(STRING s1, STRING s2) {
	int count = 0;
	for (int i = 0; i < s1.length(); i++) {
		if (s1.GetConcreteElement(i) == s2.GetConcreteElement(0)) {
			for (int pom = i, j = 0; j < s2.length(); j++, pom++) {
				if (s1.GetConcreteElement(pom) == s2.GetConcreteElement(j)) {
					count++;
				}
				else {
					count--;
				}
			}
			if (count == s2.length()) {
				return true;
			}
			else {
				count = 0;
			}
		}
	}
	return false;
}
bool CzyZawieraNapoczatku(STRING s1, STRING s2) {
	int i = 0;
	for (i; i < s2.length(); i++) {
		if (s1.GetConcreteElement(i) != s2.GetConcreteElement(i)) {
			return false;
		}
	}
	if (s1.GetConcreteElement(i) == ',') return true;
	return false;
}
bool CzyZawieraNakoncu(STRING s1, STRING s2) {
	int i = s2.length()-1 , j=s1.length()-1;
	for (i,j; i >= 0; i--, j--) {
		if (s1.GetConcreteElement(j) != s2.GetConcreteElement(i)) {
			return false;
		}
	}
	if (s1.GetConcreteElement(j) == ' ' && s1.GetConcreteElement(j-1)==',') return true;
	return false;
}
int przypadki_zawierania_nazwy(SELECTOR* temp, STRING nazwa, STRING nazwa_pom) {
	int counter = 0;
	while (temp != NULL) {
		if (temp->name == nazwa) counter++;
		else if (CzyZawieraNapoczatku(temp->name, nazwa) == true) counter++;
		else if (CzyZawieraNakoncu(temp->name, nazwa) == true) counter++;
		else if (CzyZawieraNazwe(temp->name, nazwa_pom) == true) counter++;
		temp = temp->next;
	}
	return counter;
}
int stworz_napis_pomocniczy(char tab[], STRING nazwa) {
	int licznik = 0;
	tab[0] = ',';
	licznik++;
	tab[1] = ' ';
	licznik++;
	for (int i = 0, j = licznik; i < nazwa.length();i++, j++) {
		tab[j] = nazwa.GetConcreteElement(i);
		licznik++;
	}
	tab[licznik] = ',';
	licznik++;
	return licznik;
}
void NumOfSelector(BLOCK* list, STRING nazwa) {
	int count = 0, licz = 0;
	char naz[100];
	licz=stworz_napis_pomocniczy(naz, nazwa);
	STRING nazwa_pom(naz,licz);
	BLOCK* tmp = list;
	while (tmp != NULL) {
		SELECTOR* temp = tmp->list_sel;
		count=count+przypadki_zawierania_nazwy(temp, nazwa, nazwa_pom);
		tmp = tmp->next;
	}
	std::cout << nazwa << ",S,? == " << count << endl;
}
void szukanie_wartosci_atrybutu(SELECTOR* temp, STRING nazwa_sel, STRING nazwa_atr, STRING nazwa_pom, int *flag, STRING *rem) {
	ATTRIBUTE* tp = NULL;
	if (przypadki_zawierania_nazwy(temp,nazwa_sel,nazwa_pom) != 0) {
		tp = temp->list_at;
		while (tp != NULL) {
			if (tp->nazwa == nazwa_atr) *rem = tp->value;
			tp = tp->next;
		}
		*flag = 1;
	}
}
void PrintLastValue(BLOCK* list, STRING nazwa_atr, STRING nazwa_sel) {
	int licz = 0;
	char naz[100];
	licz = stworz_napis_pomocniczy(naz, nazwa_sel);
	STRING nazwa_pom(naz, licz);
	BLOCK* last = GetLast(list);
	STRING rem(" ");
	int flag = 0;
	while (last != NULL) {
		SELECTOR* temp = last->list_sel;
		while (temp != NULL) {
			szukanie_wartosci_atrybutu(temp, nazwa_sel, nazwa_atr, nazwa_pom, &flag, &rem);
			temp = temp->next;
		}
		if (flag == 1) {
			if (rem.GetConcreteElement(0) != ' ') {
				std::cout << nazwa_sel << ",E," << nazwa_atr << " == " << rem << endl;
			}

			return;
		}
		last = last->prev;
	}
}
SELECTOR* RemoveNode(SELECTOR* firstNode, SELECTOR* node) {
	if (node == NULL) return firstNode;
	if (firstNode == node) {
		return firstNode->next;
	}
	SELECTOR* tmp = firstNode;

	while (tmp->next != NULL) {
		if (tmp->next == node) {
			tmp->next = tmp->next->next;
			break;
		}
		tmp = tmp->next;
	}
	return firstNode;
}
ATTRIBUTE* RemoveAttr(ATTRIBUTE* firstNode, ATTRIBUTE* node) {
	if (node == NULL) return firstNode;
	if (firstNode == node) {
		return firstNode->next;
	}
	ATTRIBUTE* tmp = firstNode;
	while (tmp->next != NULL) {
		if (tmp->next == node) {
			tmp->next = tmp->next->next;
			break;
		}
		tmp = tmp->next;
	}
	return firstNode;
}
bool czy_ma_dwukropek(STRING word) {
	for (int j = 0; j < word.length();j++) {
		if (word.GetConcreteElement(j) == ':') {
			return true;
		}
	}
	return false;
}
int czy_ma_przecinek(STRING word) {
	int count = 0;
	for (int j = 0; j < word.length();j++) {
		if (word.GetConcreteElement(j) == ',') {
			count++;
		}
	}
	return count;
}
int zamiennapisnaliczbe(STRING word) {
	int count = 0, pom = 1;
	for (int i = word.length() - 1; i >= 0; i--) {
		count = count + pom * (word.GetConcreteElement(i) - '0');
		pom = pom * 10;
	}
	return count;
}
void usun_sekcje(BLOCK* list, SELECTOR*temp, int rem) {
	list->list_sel = RemoveNode(list->list_sel, temp);
	std::cout << rem << ",D,* == deleted" << endl;
	return;
}
void usun_atrybut(SELECTOR* temp, STRING nazwa, int rem, BLOCK* list) {
	ATTRIBUTE* pom = temp->list_at;
	while (pom != NULL) {
		if (pom->nazwa == nazwa) {
			temp->list_at = RemoveAttr(temp->list_at, pom);
			if (temp->list_at == NULL) {
				list->list_sel = RemoveNode(list->list_sel, temp);
				list->licznik--;
			}

			std::cout << rem << ",D," << nazwa << " == deleted" << endl;
			return;
		}
		pom = pom->next;
	}
}
void usun_w_pierwszym_bloku(int position, BLOCK*list, int parametr, STRING nazwa_atr) {
	int rem = position;
	SELECTOR* temp = list->list_sel;
	while (temp != NULL) {
		if (position == 1) {
			if (parametr == 0) {
				usun_sekcje(list, temp, rem);
				list->licznik--;
			}
			else if (parametr == 1) usun_atrybut(temp, nazwa_atr, rem, list);
		}
		position--;
		temp = temp->next;
	}
}
void usun_w_kolejnych_blokach(int position, BLOCK*list, STRING nazwa_atr, int parametr) {
	int rem = position;
	int count = znajdz_pozycje_bloku(list, &position);
	BLOCK* tmp = list;
	while (tmp != NULL) {
		if (count == 0) {
			SELECTOR* temp = tmp->list_sel;
			while (temp != NULL) {
				if (position == 1) {
					if (parametr == 0) {
						usun_sekcje(tmp, temp, rem);
						tmp->licznik--;
					}
					else if (parametr == 1) usun_atrybut(temp, nazwa_atr, rem, tmp);
				}
				position--;
				temp = temp->next;
			}
		}
		count--;
		tmp = tmp->next;
	}
}
void sprawdz_czy_parsowanie(variables* main) {
	main->doing = PARSOWANIE;
	main->mozna = NIE_MOZNA;
}
void sprawdz_czy_komendy(variables* main) {
	main->doing = KOMENDY;
	main->mozna = NIE_MOZNA;
}
void parsowanie_slowa_z_nawiasem_z_lewej(variables* main) {
	main->wczytywanie = ATRYBUT;
	main->wyraz = NIE;
	main->moge = NIE_MOZNA;
	main->attr_name = main->word;
	main->attr_name = main->attr_name.WithoutLastElement();
	main->attr_name = main->attr_name.WithoutFirstElement();
}
void parsowanie_slowa_z_nawiasem_z_prawej(variables* main) {
	main->wczytywanie = SELEKTOR;
	main->spacja = NIE;
	main->attr_val = main->word;
	main->attr_val = main->attr_val.WithoutLastElement();
	main->attr_val = main->attr_val.WithoutLastElement();
	if (ChechAttrExist(main->attr_list, main->attr_name, main->attr_val) == 0) main->attr_list = AddAttribute(main->attr_list, main->attr_name, main->attr_val);
	main->attr_name = main->free;
	main->attr_val = main->free;
	main->block_list = AddSelectorToBlock(main->block_list, main->sel, main->attr_list);
	main->sel = main->free;
	main->attr_list = NULL;
	main->moge = NIE_MOZNA;
}
void parsowanie_nawias_z_lewej(variables* main) {
	main->wczytywanie = ATRYBUT;
	main->wyraz = NIE;
	main->moge = NIE_MOZNA;
}
void parsowanie_nawias_z_prawej(variables* main) {
	main->wczytywanie = SELEKTOR;
	main->spacja = NIE;
	main->block_list = AddSelectorToBlock(main->block_list, main->sel, main->attr_list);
	main->sel = main->free;
	main->attr_list = NULL;
	main->moge = NIE_MOZNA;
}
void parsowanie_selektora(variables* main) {
	if (main->wyraz == TAK) main->sel = main->sel + main->space;
	main->wyraz = TAK;
	main->sel = main->sel + main->word;
	if (main->sel.GetConcreteElement(main->sel.length() - 1) == '{') {
		main->sel = main->sel.WithoutLastElement();
		main->wczytywanie = ATRYBUT;
		main->moge = NIE_MOZNA;
	}
}
void parsowanie_nazwy_atrybutu_proste(variables* main) {
	if (main->spacja == TAK) main->attr_name = main->attr_name + main->space;
	main->spacja = TAK;
	main->attr_name = main->attr_name + main->word;
}
void parsowanie_wartosci_atrybutu_proste(variables* main) {
	if (main->spacja == TAK) main->attr_val = main->attr_val + main->space;
	main->spacja = TAK;
	main->attr_val = main->attr_val + main->word;
}
void parsowanie_nazwy_atrybutu_z_dwukropkiem(variables* main) {
	main->wczyt = WARTOSC_ATRYBUTU;
	main->spacja = NIE;
}
void parsowanie_wartosci_atrybutu_z_przecinkiem(variables* main) {
	main->wczyt = NAZWA_ATRYBUTU;
	main->spacja = NIE;
	main->attr_name = main->attr_name.WithoutLastElement();
	main->attr_val = main->attr_val.WithoutLastElement();
	if (ChechAttrExist(main->attr_list, main->attr_name, main->attr_val) == 0) main->attr_list = AddAttribute(main->attr_list, main->attr_name, main->attr_val);
	main->attr_name = main->free;
	main->attr_val = main->free;
}
void parsowanie_atrybutu(variables* main) {
	if (main->wczyt == NAZWA_ATRYBUTU) {
		parsowanie_nazwy_atrybutu_proste(main);
	}
	else if (main->wczyt == WARTOSC_ATRYBUTU) {
		parsowanie_wartosci_atrybutu_proste(main);
	}
	if (main->word.GetConcreteElement(main->word.length() - 1) == ':') {
		parsowanie_nazwy_atrybutu_z_dwukropkiem(main);

	}
	else if (main->word.GetConcreteElement(main->word.length() - 1) == ';') {
		parsowanie_wartosci_atrybutu_z_przecinkiem(main);
	}
}
void pomoc(variables* main, char name[], char value[], int &i, int &licznik_n, int &j, int &licznik_v, int parametr) {
	while (main->word.GetConcreteElement(i) != ':') {
		name[i] = main->word.GetConcreteElement(i);
		i++, licznik_n++;
	}
	i++;
	if (parametr == 0) {
		while (main->word.GetConcreteElement(i) != ';') {
			value[j] = main->word.GetConcreteElement(i);
			j++, i++, licznik_v++;
		}
	}
	if (parametr == 1) {
		while (i < main->word.length()) {
			value[j] = main->word.GetConcreteElement(i);
			j++, i++, licznik_v++;
		}
	}
}
void pomoc_do_atrybutu_jako_jedno_slowo(variables* main) {
	char name[100], value[100];
	int i = 0, j = 0, licznik_v = 0, licznik_n = 0;
	pomoc(main, name, value, i, licznik_n, j, licznik_v, 0);
	STRING pom_v(value, licznik_v), pom_n(name, licznik_n);
	main->attr_val = pom_v;
	main->attr_name = pom_n;
}
void atrybut_jako_jedno_slowo(variables* main) {
	pomoc_do_atrybutu_jako_jedno_slowo(main);
	if (ChechAttrExist(main->attr_list, main->attr_name, main->attr_val) == 0) main->attr_list = AddAttribute(main->attr_list, main->attr_name, main->attr_val);
	main->attr_name = main->free;
	main->attr_val = main->free;
	main->moge = NIE_MOZNA;
	main->wczytywanie = ATRYBUT;
}
void atrybut_z_dwukropkiem_i_spacja_jako_wartosc_pomoc(variables* main) {
	char name[100], value[100];
	int i = 0, licznik_n = 0, j = 0, licznik_v = 0; 
	pomoc(main, name, value, i, licznik_n, j, licznik_v, 1);
	value[j] = ' ';
	j++, licznik_v++;
	std::cin >> main->word;
	while (main->word.GetConcreteElement(main->word.length() - 1) != ';') {
		int k = 0;
		while (k < main->word.length()) {
			value[j] = main->word.GetConcreteElement(k);
			j++, k++, licznik_v++;
		}
		value[j] = ' ';
		j++, licznik_v++;
		std::cin >> main->word;
	}
	int k = 0;
	value[j] = ' ';
	j++, licznik_v++;
	while (k < main->word.length() - 1) {
		value[j] = main->word.GetConcreteElement(k);
		j++, k++, licznik_v++;
	}
	STRING pom_v(value, licznik_v), pom_n(name, licznik_n);
	main->attr_val = pom_v;
	main->attr_name = pom_n;
}
void atrybut_z_dwukropkiem_i_spacja_jako_wartosc(variables* main) {
	atrybut_z_dwukropkiem_i_spacja_jako_wartosc_pomoc(main);
	if (ChechAttrExist(main->attr_list, main->attr_name, main->attr_val) == 0) main->attr_list = AddAttribute(main->attr_list, main->attr_name, main->attr_val);
	main->attr_name = main->free;
	main->attr_val = main->free;
	main->moge = NIE_MOZNA;
	main->wczytywanie = ATRYBUT;
}
void parsowanie_szczegolne_przypadki(variables* main) {
	if (main->word.GetConcreteElement(main->pozycja) == '{' && main->word.length() != 1) {
		parsowanie_slowa_z_nawiasem_z_lewej(main);
	}
	else if (main->word.GetConcreteElement(main->word.length() - 1) == '}' && main->word.length() != 1) {
		parsowanie_slowa_z_nawiasem_z_prawej(main);
	}
	else if (main->word.GetConcreteElement(main->word.length() - 1) == ';' && czy_ma_dwukropek(main->word) == true) {
		atrybut_jako_jedno_slowo(main);
	}
	else if (czy_ma_dwukropek(main->word) == true && main->word.GetConcreteElement(main->word.length() - 1) != ';' && main->word.GetConcreteElement(main->word.length() - 1) != ':' && main->wczytywanie == ATRYBUT) {
		atrybut_z_dwukropkiem_i_spacja_jako_wartosc(main);
	}
	else if (main->word.GetConcreteElement(main->pozycja) == '{') {
		parsowanie_nawias_z_lewej(main);
	}
	else if (main->word.GetConcreteElement(main->pozycja) == '}') {
		parsowanie_nawias_z_prawej(main);
	}
}
void parsowanie_proste_przypadki(variables* main) {
	if (main->wczytywanie == SELEKTOR && main->moge == MOZNA) {
		parsowanie_selektora(main);
	}
	else if (main->wczytywanie == ATRYBUT && main->moge == MOZNA) {
		parsowanie_atrybutu(main);
	}
}
void parsowanie(variables* main) {
	parsowanie_szczegolne_przypadki(main);
	parsowanie_proste_przypadki(main);
	main->moge = MOZNA;
}
void sprawdzenie_czy_komenda_kompletna(variables* main) {
	while (czy_ma_przecinek(main->word) < 2) {
		STRING pom;
		main->word = main->word + main->space;
		std::cin >> pom;
		main->word = main->word + pom;
	}
}
void pomoc_z_komendami(variables* main, char A[], char B[], char C[], int &licznikA, int &licznikB, int &licznikC, int &i) {
	while (main->word.GetConcreteElement(i) != ',') {
		A[i] = main->word.GetConcreteElement(i);
		i++, licznikA++;
	}
	i++;
	B[0] = main->word.GetConcreteElement(i);
	i = i + 2, licznikB++;
	while (i < main->word.length()) {
		C[licznikC] = main->word.GetConcreteElement(i);
		i++, licznikC++;
	}
}
void komendy_z_S(variables* main, STRING wordA, STRING wordC) {
	if (wordC.GetConcreteElement(0) == '?' && wordA.GetConcreteElement(0) >= '0' && wordA.GetConcreteElement(0) <= '9') {
		int liczba = zamiennapisnaliczbe(wordA);
		if (liczba < main->block_list->licznik) szukaj_w_pierwszym_bloku(main->block_list, 0, liczba, 0, main->free);
		else szukaj_w_kolejnych_blokach(main->block_list, 0, liczba, 0, main->free);
	}
	else if (wordC.GetConcreteElement(0) == '?') {
		NumOfSelector(main->block_list, wordA);
	}
	else {
		int liczbai = zamiennapisnaliczbe(wordA), liczbaj = zamiennapisnaliczbe(wordC);
		if (liczbai < main->block_list->licznik) szukaj_w_pierwszym_bloku(main->block_list, liczbaj, liczbai, 1, main->free);
		else szukaj_w_kolejnych_blokach(main->block_list, liczbaj, liczbai, 1, main->free);
	}
}
void komendy_z_A(variables* main, STRING wordA, STRING wordC) {
	if (wordC.GetConcreteElement(0) == '?' && wordA.GetConcreteElement(0) >= '0' && wordA.GetConcreteElement(0) <= '9') {
		int liczba = zamiennapisnaliczbe(wordA);
		if (liczba < main->block_list->licznik) szukaj_w_pierwszym_bloku(main->block_list, 0, liczba, 2, main->free);
		else szukaj_w_kolejnych_blokach(main->block_list, 0, liczba, 2, main->free);
	}
	else if (wordC.GetConcreteElement(0) == '?') {
		NumAttrinAllSection(wordA, main->block_list);
	}
	else {
		int liczba = zamiennapisnaliczbe(wordA);
		if (liczba < main->block_list->licznik) szukaj_w_pierwszym_bloku(main->block_list, 0, liczba, 3, wordC);
		else szukaj_w_kolejnych_blokach(main->block_list, 0, liczba, 3, wordC);
	}
}
void komendy_zlozone_z_trzech_elementow(STRING wordA, STRING wordB, STRING wordC, variables* main) {
	if (wordB.GetConcreteElement(0) == 'S') {
		komendy_z_S(main, wordA, wordC);
	}
	else if (wordB.GetConcreteElement(0) == 'A') {
		komendy_z_A(main, wordA, wordC);
	}
	else if (wordB.GetConcreteElement(0) == 'E') {
		PrintLastValue(main->block_list, wordC, wordA);
	}
	else if (wordC.GetConcreteElement(0) == '*') {
		int liczba = zamiennapisnaliczbe(wordA);
		if (liczba < main->block_list->licznik) usun_w_pierwszym_bloku(liczba, main->block_list, 0, main->free);
		else usun_w_kolejnych_blokach(liczba, main->block_list, main->free, 0);
	}
	else {
		int liczba = zamiennapisnaliczbe(wordA);
		if (liczba < main->block_list->licznik) usun_w_pierwszym_bloku(liczba, main->block_list, 1, wordC);
		else usun_w_kolejnych_blokach(liczba, main->block_list, wordC, 1);
	}
}
void komendy(variables* main) {
	if (main->word.length() == 1 && main->word.GetConcreteElement(0) == '?') {
		Section_number(main->block_list);
	}
	else {
		sprawdzenie_czy_komenda_kompletna(main);
		char A[100], B[100], C[100];
		int licznikA = 0, licznikB = 0, licznikC = 0, i = 0;
		pomoc_z_komendami(main, A, B, C, licznikA, licznikB, licznikC, i);
		STRING wordA(A, licznikA), wordB(B, licznikB), wordC(C, licznikC);
		komendy_zlozone_z_trzech_elementow(wordA, wordB, wordC, main);
	}
}
void wczytywanie(variables* main) {
	if (main->word == main->pars) {
		sprawdz_czy_parsowanie(main);
	}
	else if (main->word == main->kom) {
		sprawdz_czy_komendy(main);
	}
	else if (main->doing == PARSOWANIE && main->mozna == MOZNA) {
		parsowanie(main);
	}
	else if (main->doing == KOMENDY && main->mozna == MOZNA) {
		komendy(main);
	}
	main->mozna = MOZNA;
}
int main()
{
	variables main;
	main.doing = PARSOWANIE, main.mozna = MOZNA;
	STRING space1(" "), free1(""), pars1("****"), kom1("????");
	main.space = space1, main.free = free1, main.pars = pars1, main.kom = kom1;
	main.block_list = NULL;
	main.attr_list = NULL;
	main.moge = MOZNA, main.pozycja = 0, main.wczytywanie = SELEKTOR, main.wyraz = NIE, main.spacja = NIE, main.wczyt = NAZWA_ATRYBUTU;
	while (cin >> main.word) {
		wczytywanie(&main);
	}
	return 0;
}

