#pragma once

int NumberOfSections(List* temp);
void NumberOfSelectorsInSection(List* temp, MyString& input, int len);
void NumberOfAttributesInSection(List* temp, MyString& input, int len);
void JSelectorInIBlock(List* temp, MyString& input, int len);
void NAttributeForSectionI(List* temp, MyString& input, int len);
void NumberOfNAttribute(List* temp, MyString& input);
void NumberOfSelectorZ(List* temp, MyString& input);
void ValueOfNForSelectorZ(List* temp, MyString& input, int len);
//bool ExecuteCommands(List* temp);