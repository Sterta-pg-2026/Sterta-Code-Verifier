#include "node3.h"
#define T 29

Node3::Node3() : prev(nullptr), next(nullptr) {
}
Node3::~Node3() {
}