#include "list.h"
#define T 29
#define MAX 64

List::List() : nblok(nblok=0), first(nullptr),last(nullptr) {

}

void List::addNewNode() {
	if (nblok == 0) {
		Node* node = new Node();
		node->next = first;
		first = node;
		last = node;
		if (first != nullptr) {
			first->prev = node;
		}
		nblok++;
	}
	else {
		Node* node = new Node();
		last->next = node;
		node->prev = last;
		last = node;
		nblok++;
	}
}
void List::addNewElement(String element) {
	Node* curr_node = first;
	int f = 0;
	int k = -1;
	int l = element.getLength();
	int n = 0;
	String selector[MAX];
	String free;
	while (element.tab[l-1] == ' ') {
		l--;
	}
	while (element.tab[k] == ' ') {
		k++;
	}
	while (l != k) {
		k++;
		while (element.tab[k] != ',' && l != k) {
			selector[n].addLetter(element.tab[k]);
			k++;
		}
		n++;
	}
	while (curr_node != nullptr && f != 1) {
		for (int i = 0; i < T; i++) {
			if (curr_node != nullptr && curr_node->blok[i].name.isFree() == 1) {
				for (int p = 0; p < n; p++) {
					curr_node->blok[i].name.addNewElement(selector[p]);
				}
				f = 1;
				break;
			}
		}
		if (f == 0) {
			curr_node = curr_node->next;
		}
	}
	if (f == 0) {
		addNewNode();
		addNewElement(element);
	}
	}
void List::addNewAttribute(String attributes) {
	Node* curr_node = first;
	int f = 0;
	int k = 0;
	int n = 0;
	String attribute[MAX][2];
	String free;
	while (attributes.getLength() != k) {
		while (attributes.tab[k] != ':') {
			attribute[n][0].addLetter(attributes.tab[k]);
			k++;
		}
		k++;
		while (attributes.tab[k] != ';' && attributes.getLength() != k) {
			attribute[n][1].addLetter(attributes.tab[k]);
			k++;
		}
		k++;
		n++;
	}
	while (curr_node != nullptr && f != 1) {
		for (int i = 0; i < T; i++) {
			if (curr_node != nullptr && curr_node->blok[i].attributes.isFree() == 1) {
				for (int p = 0; p < n; p++) {
					if (curr_node->blok[i].attributes.findValue(attribute[p][0]).length != 0){
						curr_node->blok[i].attributes.swap(attribute[p][0], attribute[p][1]);
					}
					else {
						curr_node->blok[i].attributes.addNewElement(attribute[p][0], attribute[p][1]);
					}
				}
				f = 1;
				break;
			}
		}
		if (f == 0) {
			curr_node = curr_node->next;
		}
	}
	if (f == 0) {
		addNewNode();
		addNewAttribute(attributes);
	}
}
void List::S(int i, int j) {
	Node* curr_node = first;
	int l = i / T;
	int f = i % T;
	for (int k = 0; k < l; k++) {
		curr_node = curr_node->next;
	}
	if (curr_node != nullptr) {
		String result = curr_node->blok[f].name.showAll(j);
		if (result.getLength() != 0) {
			cout << i + 1 << ",S," << j + 1 << " == " << result << endl;
		}
	}
}
void List::S1(int i) {
	Node* curr_node = first;
	int n = 0;
	int l = i / T;
	int f = i % T;
	if (l <= nblok - 1) {
		for (int k = 0; k < l; k++) {
			curr_node =curr_node->next;
		}
		if (curr_node->blok[f].name.isFree() == 0) {
			n += curr_node->blok[f].name.countAttributes();
			cout << i + 1 << ",S,? == " << n << endl;
		}
	}
}

void List::A(int i) {
	Node* curr_node = first;
	int n = 0;
	int l = i / T;
	int f = i % T;
	if (l <= nblok - 1) {
		for (int k = 0; k < l; k++) {
			curr_node = curr_node->next;
		}
		if (curr_node->blok[f].attributes.isFree() == 0) {
			n = curr_node->blok[f].attributes.countAttributes();
			cout << i + 1 << ",A,? == " << n << endl;
		}
	}
}
void List::A1(int i, String attribute) {
	Node* curr_node = first;
	int l = i / T;
	int f = i % T;
	if (l <= nblok - 1) {
		for (int i = 0; i < l; i++) {
			curr_node = curr_node->next;
		}
		String result = curr_node->blok[f].attributes.findValue(attribute);
		if (result.length != 0) {
			cout << i + 1 << ",A," << attribute << " ==" << result << endl;
		}
	}
}
void List::A2(String attribute) {
	Node* curr_node = first;
	int n = 0;
	while (curr_node != nullptr) {
		for (int i = 0; i < T; i++) {
			String result = curr_node->blok[i].attributes.findValue(attribute);
			if (result.length != 0) {
				n++;
			}
		}

		curr_node = curr_node->next;
	}
	cout << attribute << ",A,? == " << n << endl;
}
void List::S2(String selector) {
	Node* curr_node = first;
	int n = 0;
	while (curr_node != nullptr) {
		for (int i = 0; i < T; i++) {
			String result = curr_node->blok[i].name.findValue(selector);
			if (result.length != 0) {
				n++;
			}
		}

		curr_node = curr_node->next;
	}
	cout << selector << ",S,? == " << n<<endl;
}
void List::E(String selector, String attribute) {
	Node* curr_node = first;
	String result;
	String l;
	while (curr_node != nullptr) {
		for (int i = 0; i <T; i++) {
			result = curr_node->blok[i].name.findValue(selector);
			if (result.length != 0) {
				result = curr_node->blok[i].attributes.findValue(attribute);
				if (result.length != 0) {
					l = result;
				}
			}
		}
		curr_node = curr_node->next;
	}
	if (l.length != 0) {
		cout << selector << ",E," << attribute << " == " << l << endl;
	}
}
int List::D1(int i, String attribute) {
	Node* curr_node = first;
	int n = 0;
	int l = i / T;
	int f = i % T;
	if (l <= nblok - 1) {
		for (int k = 0; k < l; k++) {
			curr_node = curr_node->next;
		}
		n=curr_node->blok[f].attributes.deleteSection(attribute);
		if (curr_node->blok[f].attributes.countAttributes() == 0) {
			if (n == 1) {
				D(i, 2);
				cout << i + 1 << ",D," << attribute << " == deleted" << endl;
				return 1;
			}
			return 0;
		}
		if (n == 1) {
			cout << i + 1 << ",D," << attribute << " == deleted" << endl;
		}
		return 0;
	}
	return 0;
}
void List::D(int i,int t) {
	Node* curr_node = first;
	int l = i / T;
	int f = i % T;
	int d = f;
	int o=f;
	if (l <= nblok - 1) {
		for (int k = 0; k < l; k++) {
			curr_node = curr_node->next;
		}
		curr_node->blok[f].name.deleteSection();
		curr_node->blok[f].attributes.deleteSection();
		if (t != 2) {
			cout << i + 1 << ",D,* == deleted" << endl;
		}
		while (curr_node != nullptr) {
		for (d=o; d < T; d++) {
			if (d != T - 1) {
				curr_node->blok[d] = curr_node->blok[d + 1];
			}
			else {
				curr_node = curr_node->next;
				o = 0;
				if (curr_node != nullptr) {
					curr_node->prev->blok[T - 1] = curr_node->blok[0];
				}
			}
			}
		}
	}
}
List::~List() {
	Node* curr_node = first;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		if (curr_node != nullptr) {
			delete curr_node->prev;
		}
		if (curr_node == last) {
			delete curr_node;
			break;
		}
	}
}