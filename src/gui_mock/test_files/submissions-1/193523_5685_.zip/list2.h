#pragma once
#include "node2.h"

class ListofAttirbutes {
public:
	int nblok;
	Node2* first;
	Node2* last;
public:
	ListofAttirbutes();
	void addNewNode();
	void addNewElement(String element, String value);
	int getnBlok();
	int countAttributes();
	void swap(String attribute, String value);
	int isFree();
	void deleteSection();
	int deleteSection(String attribute);
	String findValue(String attribute);
	~ListofAttirbutes();
};