#pragma once
#include <iostream>
#include "list.h"
using namespace std;

class Parser {
public:
	List selectors;
	char zn;
	int sel = 0;
	int i = 0, j = 0;
	String name;
	String element;
public:
	void parse();
	void commands();
	void loading();
};