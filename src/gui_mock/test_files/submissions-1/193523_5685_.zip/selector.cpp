#include "selector.h"
#define T 29

Selector::Selector(){
}
