#include "string.h"

String::String(){
	tab = new char[0];
	length = 0;
}

char* String::getTab() const {
	return tab;
}
int String::getLength() const {
	return length;
}
ostream& operator << (ostream& out, const String& string) {
	for (int i = 0; i < string.length; i++) {
		out << string.tab[i];
	}
	return out;
}
int operator==(const String& string, const String& string1) {
	if (string.getLength() != string1.getLength()) return 0;
	else for (int i = 0; i < string.getLength(); i++) {
		if (string.getTab()[i] != string1.getTab()[i]) {
			return 0;
		}
	}
	return 1;
}
int operator!=(const String& string, const String& string1) {
	if (string.getLength() != string1.getLength()) return 1;
	else for (int i = 0; i < string.getLength(); i++) {
		if (string.getTab()[i] != string1.getTab()[i]) {
			return 1;
		}
	}
	return 0;
}
void String::addLetter(char letter) {
	char* tabcopy = new char[length];
	for (int i = 0; i < length; i++) {
		tabcopy[i] = tab[i];
	}
	delete [] tab;
	tab = new char[length + 1];
	for (int i = 0; i < length; i++) {
		tab[i] = tabcopy[i];
	}
	tab[length] = letter;
	length++;
	delete [] tabcopy;
}

void String::clear() {
	delete [] tab;
	tab = new char[0];
	length = 0;
}
String::~String() {
}