#include "node2.h"
#define T 29

Node2::Node2() : prev(nullptr), next(nullptr) {
}
Node2::~Node2() {
}