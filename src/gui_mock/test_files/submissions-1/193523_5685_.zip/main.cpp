#include <iostream>
#include "string.h"
#include "parser.h"

using namespace std;

int main() {
	Parser css;
	css.parse();
}