#include "node.h"
#define T 29

Node::Node() : prev(nullptr), next(nullptr), blok(new Selector[T]) {
}
Node::~Node() {
}