#pragma once
#include "string.h"

class Node3 {
public:
	Node3* prev;
	Node3* next;
	String name;
public:
	Node3();
	~Node3();
};