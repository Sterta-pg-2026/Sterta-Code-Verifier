#include "list3.h"
#define T 29

ListofSelectors::ListofSelectors() : nblok(nblok = 0), first(nullptr), last(nullptr) {

}
int ListofSelectors::getnBlok() {
	return nblok;
}
void ListofSelectors::addNewNode() {
	if (nblok == 0) {
		Node3* node = new Node3();
		node->next = first;
		first = node;
		last = node;
		if (first != nullptr) {
			first->prev = node;
		}
		nblok++;
	}
	else {
		Node3* node = new Node3();
		last->next = node;
		node->prev = last;
		last = node;
		nblok++;
	}
}
void ListofSelectors::addNewElement(String element) {
	Node3* curr_node = first;
	int f = 0;
	String free;
	while (curr_node != nullptr && curr_node->name != free) {
		curr_node = curr_node->next;
	}
	if (curr_node != nullptr && curr_node->name == free) {
		for (int i = 0; i < element.getLength(); i++) {
			curr_node->name.addLetter(element.tab[i]);
		}
		f = 1;
	}
	if (f == 0) {
		addNewNode();
		addNewElement(element);
	}
}
int ListofSelectors::countAttributes() {
	Node3* curr_node = first;
	int i = 0;
	int f = 0;
	while (curr_node != nullptr) {
		for (int p = 0; p < curr_node->name.length; p++) {
			if (curr_node->name.tab[p]>=97 && 122>= curr_node->name.tab[p]){
				f = 1;
			}
		}
		if (f==1) {
			i++;
		}
		curr_node = curr_node->next;
	}
	return i;
}
String ListofSelectors::showAll(int i) {
	Node3* curr_node = first;
	int f = 0;
	String free;
	while (curr_node != nullptr && f!=i) {
		f++;
		curr_node = curr_node->next;	
	}
	if (f == i && curr_node != nullptr) {
		for (int p = 0; p < curr_node->name.length; p++) {
			if (curr_node->name.tab[p] >= 97 && 122 >= curr_node->name.tab[p]) {
				f = 1;
			}
		}
		if (f==1) {
			return curr_node->name;
		}
	}
	return free;
}
int ListofSelectors::isFree() {
	Node3* curr_node = first;
	int i = 0;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		i++;
	}
	if (i == 0) {
		return 1;
	}
	else {
		return 0;
	}
}
void ListofSelectors::deleteSection() {
	Node3* curr_node = first;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		if (curr_node != nullptr) {
			delete curr_node->prev;
		}
		if (curr_node == last) {
			delete curr_node;
			break;
		}
	}
}

String ListofSelectors::findValue(String selector) {
	Node3* curr_node = first;
	String p;
	while (curr_node != nullptr) {
		if (curr_node->name == selector) {
			return curr_node->name;
		}
		curr_node = curr_node->next;
	}
	return p;
}

ListofSelectors::~ListofSelectors() {
	Node3* curr_node = first;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		if (curr_node != nullptr) {
			delete curr_node->prev;
		}
		if (curr_node == last) {
			delete curr_node;
			break;
		}
	}
}