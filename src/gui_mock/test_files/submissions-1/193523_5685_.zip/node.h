#pragma once
#include "selector.h"

class Node {
public:
	Node* prev;
	Node* next;
	Selector *blok;
public:
	Node();
	~Node();
};