#pragma once
#include <iostream>
using namespace std;

class String {
public:
	char *tab;
	int length;
public:
	friend ostream& operator<<(ostream& out, const String& string);
	friend int operator==(const String& string, const String& string1);
	friend int operator!=(const String& string, const String& string1);
	String();
	void clear();
	void addLetter(char letter);
	char* getTab() const;
	int getLength() const;
	~String();
};