#pragma once
#include "node.h"
#pragma once
#include "node.h"

class List {
public:
	int nblok;
	Node* first;
	Node* last;
public:
	List();
	void addNewNode();
	void addNewElement(String element);
	void addNewAttribute(String attributes);
	void S(int i, int j);
	void S1(int i);
	void A(int i);
	void A1(int i, String attribute);
	void A2(String attribute);
	void S2(String selector);
	void E(String selector, String attribute);
	void D(int i, int t);
	int D1(int i, String attribute);
	~List();
};