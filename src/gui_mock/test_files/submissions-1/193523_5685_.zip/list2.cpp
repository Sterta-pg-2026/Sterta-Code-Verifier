#include "list2.h"
#define T 29

ListofAttirbutes::ListofAttirbutes() : nblok(nblok = 0), first(nullptr), last(nullptr) {

}
int ListofAttirbutes::getnBlok() {
	return nblok;
}
void ListofAttirbutes::addNewNode() {
	if (nblok == 0) {
		Node2* node = new Node2();
		node->next = first;
		first = node;
		last = node;
		if (first != nullptr) {
			first->prev = node;
		}
		nblok++;
	}
	else {
		Node2* node = new Node2();
		last->next = node;
		node->prev = last;
		last = node;
		nblok++;
	}
}
void ListofAttirbutes::addNewElement(String element, String value) {
	Node2* curr_node = first;
	int f = 0;
	String free;
	while (curr_node != nullptr && curr_node->av[0] != free) {
		curr_node = curr_node->next;
	}
	if (curr_node != nullptr && curr_node->av[0] == free) {
		for (int i = 0; i < element.getLength(); i++) {
			curr_node->av[0].addLetter(element.tab[i]);
		}
		for (int i = 0; i < value.getLength(); i++) {
			curr_node->av[1].addLetter(value.tab[i]);
		}
		f = 1;
	}
	if (f == 0) {
		addNewNode();
		addNewElement(element, value);
	}
}
void ListofAttirbutes::swap(String attribute, String value) {
	Node2* curr_node = first;
	String p;
	while (curr_node != nullptr) {
		if (curr_node->av[0] == attribute) {
			curr_node->av[1] = value;
		}
		curr_node = curr_node->next;
	}
}
int ListofAttirbutes::countAttributes() {
	Node2* curr_node = first;
	int i = 0;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		i++;
	}
	return i;
}
String ListofAttirbutes::findValue(String attribute){
	Node2* curr_node = first;
	String p;
	while (curr_node != nullptr) {
		if (curr_node->av[0] == attribute) {
			return curr_node->av[1];
		}
		curr_node = curr_node->next;
	}
	return p;
}
int ListofAttirbutes::deleteSection(String attribute) {
	Node2* curr_node = first;
	String p;
	int f = 0;
	while (curr_node != nullptr&&f!=1) {
		if (curr_node->av[0] == attribute) {
			curr_node->av[1] = p;
			curr_node->av[0] = p;
			Node2* prev_node;
			Node2* next_node;
			if (curr_node == first) {
				first = first->next;
				if (first != nullptr) {
					first->prev = nullptr;
				}
				delete curr_node;
			}
			else if (curr_node == last) {
				last = last->prev;
				last->next = nullptr;
				delete curr_node;

			}
			else {
				prev_node = curr_node->prev;
				next_node = curr_node->next;
				prev_node->next = next_node;
				next_node->prev = prev_node;
				delete curr_node;
			}
			f = 1;
			return 1;
		}
		if (f == 0) {
			curr_node = curr_node->next;
		}
	}
	return 0;
}
void ListofAttirbutes::deleteSection() {
	Node2* curr_node = first;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		if (curr_node != nullptr) {
			delete curr_node->prev;
		}
		if (curr_node == last) {
			delete curr_node;
			break;
		}
	}
}
int ListofAttirbutes::isFree() {
	Node2* curr_node = first;
	int i = 0;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		i++;
	}
	if (i == 0) {
		return 1;
	}
	else {
		return 0;
	}
}

ListofAttirbutes::~ListofAttirbutes() {
	Node2* curr_node = first;
	while (curr_node != nullptr) {
		curr_node = curr_node->next;
		if (curr_node != nullptr) {
			delete curr_node->prev;
		}
		if (curr_node == last) {
			delete curr_node;
			break;
		}
	}
}