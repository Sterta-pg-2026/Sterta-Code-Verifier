#include "parser.h"

void Parser::loading() {
	cin >> zn;
	while (zn != '?') {
		while (zn != '{') {
			while (zn != '\n' && zn != '{') {
				element.addLetter(zn);
				cin >> noskipws >> zn;
			}
			if (zn == '\n') {
				cin >> zn;
			}
		}
		if (zn == '{') {
			selectors.addNewElement(element);
			element.clear();
			sel++;
			cin >> skipws >> zn;
			String attribute;
			while (zn != '}') {
				while (zn != ';') {
					attribute.addLetter(zn);
					cin >> noskipws >> zn;
				}
				attribute.addLetter(zn);
				cin >> skipws >> zn;
			}
			selectors.addNewAttribute(attribute);
			attribute.clear();
		}
		cin >> zn;
	}
}
void Parser::commands() {
	cin >> zn;
	while (zn != '*' && cin) {
		if (zn == '?') {
			cout << "? == " << sel << endl;;
		}
		if (zn >= 97 && zn <= 122 || zn == '#' || zn == '.' || zn == '-') {
			while (zn != ',' && zn != '?') {
				name.addLetter(zn);
				cin >> noskipws >> zn;
			}
			cin >> zn;
			if (zn == 'A') {
				cin >> zn;
				cin >> zn;
				selectors.A2(name);
				zn = 0;
			}
			if (zn == 'S') {
				cin >> zn;
				cin >> zn;
				selectors.S2(name);
				zn = 0;
			}
			if (zn == 'E') {
				String att;
				cin >> zn;
				cin >> zn;
				while (zn != '\n') {
					att.addLetter(zn);
					cin >> noskipws >> zn;
				}
				selectors.E(name, att);
				att.clear();
			}
			else {
				while (zn != '\n') {
					cin >> noskipws >> zn;
				}
				zn = 0;
			}
			zn = 0;
			name.clear();
		}
		if (zn >= 48 && zn <= 57) {
			i = (int)zn - 48;
			cin >> zn;
			if (zn >= 48 && zn <= 57) {
				i *= 10;
				i += int(zn) - 48;
				cin >> zn;
			}
			if (zn >= 48 && zn <= 57) {
				i *= 10;
				i += int(zn) - 48;
				cin >> zn;
			}
			else {
				cin >> zn;
			}
		}
		if (zn == 'S') {
			cin >> zn;
			cin >> zn;
			if (zn == '?') {
				selectors.S1(i - 1);
				zn = 0;
			}
			if (zn >= 48 && zn <= 57) {
				j = (int)zn - 48;
				selectors.S(i - 1, j - 1);
			}
			zn = 0;
		}
		if (zn == 'D') {
			cin >> zn;
			cin >> zn;
			if (zn == '*') {
				if (i <= sel) {
					selectors.D(i - 1, 0);
					sel--;
					zn = 0;
				}
			}
			if (zn != '*' && zn != 0) {
				while (zn != '\n') {
					name.addLetter(zn);
					cin >> noskipws >> zn;
				}
				zn = 0;
				int u = selectors.D1(i - 1, name);
				if (u == 1) {
					sel--;
				}
				name.clear();
			}
			zn = 0;
		}
		if (zn == 'A') {
			cin >> zn;
			cin >> zn;
			if (zn == '?') {
				selectors.A(i - 1);
				zn = 0;
			}
			else {
				while (zn != '\n') {
					name.addLetter(zn);
					cin >> noskipws >> zn;
				}
				selectors.A1(i - 1, name);
				name.clear();
				zn = 0;
			}
		}
		cin >> zn;
	}
}

void Parser::parse() {
	while (cin) {
		loading();
		for (int i = 0; i < 3; i++) {
			cin >> zn;
		}
		commands();	
		for (i = 0; i < 3; i++) {
			cin >> zn;
		}
	}
}
