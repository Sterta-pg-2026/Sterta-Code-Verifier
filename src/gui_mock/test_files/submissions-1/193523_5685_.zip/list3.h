#pragma once
#include "node3.h"

class ListofSelectors {
public:
	int nblok;
	Node3* first;
	Node3* last;
public:
	ListofSelectors();
	void addNewNode();
	void addNewElement(String element);
	int getnBlok();
	int countAttributes();
	String showAll(int i);
	int isFree();
	void deleteSection();
	String findValue(String selector);
	~ListofSelectors();
};