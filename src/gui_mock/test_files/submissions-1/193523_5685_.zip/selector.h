#pragma once
#include "list2.h"
#include "list3.h"
class Selector {
public:
	ListofSelectors name;
	ListofAttirbutes attributes;
public:
	Selector();
};