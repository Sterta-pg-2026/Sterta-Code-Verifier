#pragma once
#include "string.h"

class Node2 {
public:
	Node2* prev;
	Node2* next;
	String av[2];
public:
	Node2();
	~Node2();
};