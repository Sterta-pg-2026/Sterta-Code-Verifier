#pragma once
#include <iostream>

template <typename T>
class MainNode
{
public:
	T values[19];
	MainNode<T>* next;
	MainNode<T>* previous;
	int counter;

	MainNode()
	{
		this->next = nullptr;
		this->previous = nullptr;
		this->counter = 0;
	}

	int size() {
		return counter;
	}

	void add(T value) {
		values[counter] = value;
		counter++;
	}

	void removeAt(int index) {

		if (index < 0 || index >= counter) {
			return;
		}
		counter--;
		for (int i = index; i < counter; i++) {
			values[i] = values[i + 1];

		}
	}
};

template <typename T> class MainList {
public:
	MainNode<T>* head;
	MainNode<T>* last;

	MainList() {
		this->head = nullptr;
		this->last = nullptr;
	}

	int size() {
		MainNode<T>* current = head;
		int s = 0;
		while (current != nullptr) {
			s += current->size();
			current = current->next;
		}
		return s;
	};

	T valueAt(int index) {
		MainNode<T>* tmp = head;
		while (index >= tmp->size()) {
			index = index - tmp->size();
			tmp = tmp->next;
		}

		return tmp->values[index];

	}

	void add(T value) {
		if (head == nullptr) {
			MainNode<T>* tmp = new MainNode<T>();
			tmp->add(value);

			head = tmp;
			last = tmp;
		}
		else {
			if (last->counter >= 19) {
				MainNode<T>* tmp = new MainNode<T>();
				tmp->add(value);

				last->next = tmp;
				tmp->previous = last;
				last = tmp;
			}
			else {
				last->add(value);
			}
		}
	}

	void deleteAt(int index) {
		MainNode<T>* tmp = head;
		while (index >= tmp->size()) {
			index = index - tmp->size();
			tmp = tmp->next;
		}
		tmp->removeAt(index);
		if (tmp->size() == 0) {
			if (tmp->previous == nullptr && tmp->next == nullptr) {
				head = nullptr;
				last = nullptr;
			}
			else if (tmp->previous == nullptr) {
				tmp->next->previous = nullptr;
				head = tmp->next;

			}
			else if (tmp->next == nullptr) {
				tmp->previous->next = nullptr;
				last = tmp->previous;
			}
			else {
				tmp->previous->next = tmp->next;
				tmp->next->previous = tmp->previous;

			}
		}
	};

	void toString(std::ostream& os) const
	{
		os << "[";
		MainNode<T>* current = head;
		while (current != nullptr)
		{
			os << current->value;
			if (current != last)
			{
				os << ", ";
			}
			current = current->next;
		}
		os << "]";
	}

};

template <typename T>
std::ostream& operator<<(std::ostream& os, const MainList<T>& list) {
	list.toString(os);
	return os;
}
