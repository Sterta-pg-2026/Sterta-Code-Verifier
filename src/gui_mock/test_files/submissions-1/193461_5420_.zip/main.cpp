#include <iostream>
#include "list.h"

#include <cctype>
#include "mystring.h"

using namespace std;

void printCmdResult(MyString command, MyString result) {
    cout << command << " = " << result << endl;
}
enum Mode {
    CSS,
    COMMAND,
    EXIT
};

struct Attribute {
   MyString name;
   MyString value;

};

struct BlockCSS {
    MyList<Attribute> attributes;
    MyList<MyString> selectors;
};

void addOrReplace(MyList<Attribute>& list, Attribute n) {
    Node<Attribute>* tmp = list.head;
    while (tmp != nullptr)
    {
        if (tmp->value.name == n.name)
        {
            tmp->value.value = n.value;
            return;
        }
        tmp = tmp->next;
    }
    list.add(n);
}

MyList<BlockCSS> block;
Mode current = CSS;

void test(bool test)
{
    cout << (test ? "PASSED" : "FAILED") << endl;
}
void listTest()
{
    MyList<int> list;

    test(list.size() == 0);
    test(list.head == NULL);
    test(list.last == NULL);

    list.add(1);
    list.add(2);
    list.add(3);
    test(list.size() == 3);
    test(list.elementAt(0)->value == 1);
    test(list.elementAt(1)->value == 2);
    test(list.elementAt(2)->value == 3);
    test(list.head->value == 1);
    test(list.last->value == 3);


    list.deleteAt(1);

    test(list.size() == 2);

    test(list.elementAt(0)->value == 1);
    test(list.elementAt(1)->value == 3);

    test(list.head->value == 1);
    test(list.last->value == 3);

    Node<int>* foundNode = list.find(1);
   test(foundNode != NULL);
    test(foundNode->value == 1);

    foundNode = list.findBack(1);
    test(foundNode != NULL);
    test(foundNode->value == 1);

    foundNode = list.find(7);
    test(foundNode == NULL);

    foundNode = list.findBack(7);
    test(foundNode == NULL);

    list.deleteAt(0);
    list.deleteAt(0);

    test(list.head == NULL);
    test(list.last == NULL);
}

int stoi(MyString& other) {
    int liczba = 0;
    for (int i = 0; i < other.length(); i++) {
        liczba = liczba * 10 + (other[i] - '0');
    }
    return liczba;
}

MyString getline(istream& stream, char until) {
    MyString x = "";
    char a = NULL;
    stream >> ws;

    while (a != until) {
        if (a != NULL) {
            x = x + a;
        }
        if (until == '\n' && stream.peek() == until || stream.eof()) break;
        //stream >> a;
        stream.get(a);
    }
    return x;
}

MyList<Attribute> parseAttributes(istream& stream) {
    MyList<Attribute> list;
    Attribute tmp;
    char a = NULL;
    MyString wyraz="";
   

    while (a != '}') {
        
        stream >> a;
        if (a == ':') {
            tmp.name = wyraz;
            wyraz = "";
        }

        else if (a == ';') {
            tmp.value = wyraz;
            wyraz = "";
            addOrReplace(list,tmp);     
        }
        
        else if(a!='\t') wyraz = wyraz + a;
        if(stream.peek() == ' ' && wyraz.length() > 0) wyraz = wyraz + ' ';
      
    }

    return list;
}

MyList<MyString> parseSelectors(istream& stream) {
    MyList<MyString> list;
    char a=NULL;
    MyString wyraz = "";
    bool addSpace = false;

    if (stream.peek() == '{') return list;

    while (a != '{') {
        stream >> a;
       
        if (a == ','||a=='{') {
            list.add(wyraz);
            wyraz = "";
            addSpace = false;
        }
        else if (a != ' ' && '\t') {
            if (addSpace) {
                wyraz = wyraz + ' ';
                addSpace = false;
            }
            wyraz = wyraz + a;
        }

        if (stream.peek() == ' ') addSpace = true;

    }

   // cout << list;
    return list;
};

void parseCssBlock(istream& stream) {
    stream >> ws;
    if (stream.eof())
    {
        current = EXIT;
        return;
    }
    if (stream.peek() == '?')
    {
        stream.ignore(4);
        current = COMMAND;
        return;
    }

    BlockCSS tmp;
    tmp.selectors = parseSelectors(stream);
    tmp.attributes = parseAttributes(stream);
    block.add(tmp);

};

std::ostream& operator<<(std::ostream& os, const Attribute& attr) {
    os << attr.name << "=\"" << attr.value << "\"";
    return os;
}

std::ostream& operator<<(std::ostream& os, const BlockCSS& attr) {
    os << attr.selectors << " {" << attr.attributes << "}";
    return os;
}



void parseCommands(istream& stream) {
    stream >> ws;
    if (stream.eof())
    {
        current = EXIT;
        return;
    }
    if (stream.peek() == '*')
    {
        stream.ignore(4);
        current = CSS;
        return;
    }
    if (stream.peek() == '?')
    {
        stream.ignore(1);
       cout<<"? == "<< block.size()<<endl;
        return;
    }
    

    MyString com = "";
    MyString s1, s2, s3;
    s1 = getline(stream, ',');
    s2 = getline(stream, ',');
    s3 = getline(stream, '\n');

    //cout << s1 << endl << s2 << endl << s3;
    
    /*com = "";
    char a = NULL;*/


        //while (a != '\n'&&a!=',') {
        //    com += a;
        //    //cin.get(a);
        //    if (stream.peek() == '\n') break;
        //    //cout << ": " << stream.peek() << endl;
        //    stream >> a;
        //}
        //array[i] = com;
        //cout << array[i];
    


 
    //cout << array[1][0];

    switch (s2[0]) {
    case 'S':
        if (s3 == "?") {
            if (isdigit(s1[0])) {
               int i = stoi(s1);
               if(block.size()>=i)
                 cout << s1 << ',' << s2 << ',' << s3 << " == " << block.valueAt(i-1).selectors.size()<<endl;
            }
            else {
                int licznik = 0;
                for (int i = 0; i < block.size(); i++) {
                    if (block.valueAt(i).selectors.find(s1) != nullptr) licznik++;
                }
                cout << s1 << ',' << s2 << ',' << s3 << " == " << licznik << endl;
            }
          
        } 
        else {
            int i = stoi(s1);
            int j = stoi(s3);
            if (block.size() < i) break;
            else if (block.valueAt(i-1).selectors.size() < j) break;
            else  cout << s1 << ',' << s2 << ',' << s3 << " == " << block.valueAt(i-1).selectors.valueAt(j - 1)<<endl;
        }
        break;
        
    case 'E':
        for (int i = block.size() - 1; i >= 0; i--) {
            if (block.valueAt(i).selectors.findBack(s1) != nullptr) {
                //for (int j = block.valueAt(i - 1).selectors.size() - 1; j <= 0; j--) {
                    
                    Node<Attribute>* tmp = block.valueAt(i).attributes.last;
                    while (tmp != nullptr) {
                        if (tmp->value.name == s3) {
                            break;
                        }
                        tmp = tmp->previous;
                    }
                    if (tmp == nullptr)
                        continue;
                    cout << s1 << ',' << s2 << ',' << s3 << " == " << tmp->value.value << endl;
                    break;
               // }
            }      
        }
        break;

    case 'A':
        if (s3 == "?") {
            if (isdigit(s1[0])) {
                int i = stoi(s1);
                if (block.size() >= i)
                cout << s1 << ',' << s2 << ',' << s3 << " == " << block.valueAt(i - 1).attributes.size()<<endl;
            }

            else {
                
                int licznik = 0;
                for (int i = 0; i < block.size(); i++) {
                    
                    Node<Attribute>* tmp = block.valueAt(i).attributes.head;
                    
                    while (tmp != nullptr) {
                        if (tmp->value.name ==s1 ) {
                            licznik++;
                        }
                        tmp = tmp->next;
                    }
                    if (tmp == nullptr)
                        continue;
                    
                }
                cout << s1 << ',' << s2 << ',' << s3 << " == " << licznik<<endl;
            }

        }
        else {
            int i = stoi(s1);
            Node<Attribute>* tmp = block.valueAt(i-1).attributes.head;//pierwszy atrybut w sekcji
            while (tmp != nullptr) {
                if (tmp->value.name == s3) {
                    cout << s1 << ',' << s2 << ',' << s3 << " == " << tmp->value.value<<endl;
                    break;  
                }
                tmp = tmp->next;
            }
        }
        break;

    case 'D':
        if (s3[0] == '*') {
            int i = stoi(s1);
            if (block.size() < i) break;
            block.deleteAt(i - 1);
            cout << s1 << ',' << s2 << ',' << s3 << " == deleted" <<endl;
        }

        else {
          int i = stoi(s1);
            int l = 0;
            if (block.size() < i) break;

            BlockCSS k = block.valueAt(i - 1);
            Node<Attribute>* tmp = k.attributes.head;
           

            while (tmp != nullptr) {

                if (tmp->value.name == s3) {
                  
                    k.attributes.deleteAt(l);

                    cout << s1 << ',' << s2 << ',' << s3 << " == deleted" << endl;
                    if (k.attributes.size() == 0) {
                        block.deleteAt(i - 1);
 
                    }
                    break;
                }
                tmp = tmp->next;
                l++;
            }        
        }
        break;
    }
   
};

void parse(istream& stream) {
    while (true) {
        switch (current) {
        case CSS:
            //parseCssBlock(przyklad);
            parseCssBlock(stream);
            //cout << block;
            break;

        case COMMAND:
            parseCommands(stream);
            //cin.get();
            break;

        case EXIT:
            return;
        }

    }
}

int main() {

    //fstream przyklad("plik.txt");
    //fstream i1("../tests/1.in");
    parse(cin);
    //parse(i1);
    return 0;
}

