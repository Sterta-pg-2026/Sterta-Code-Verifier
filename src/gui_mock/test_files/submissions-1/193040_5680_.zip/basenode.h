#ifndef BASENODE_H
#define BASENODE_H
#include "selectorlist.h"
#include "attributelist.h"
#define T 17
struct par {
    SelectorList* sels;
    AttributeList* atts;
};
class BaseNode
{
    private:
        BaseNode* prev;
        BaseNode* next;
        //T list selektorów i atrybutów
        struct par lists[T];
        int used;
    public:
        BaseNode(BaseNode* from);
        virtual ~BaseNode();
        BaseNode* getPrev();
        BaseNode* getNext();
        int getUsed();
        struct par* getLists(int index);
        void setLists(int index, struct par what);
        void setPrev(BaseNode* toset);
        void setNext(BaseNode* toset);
        void setUsed(int toset);
};

#endif // BASENODE_H
