#ifndef SELECTORLIST_H
#define SELECTORLIST_H
#include "selectornode.h"

class SelectorList
{
    private:
        SelectorNode* first;
        SelectorNode* last;
        int size;
    public:
        SelectorList();
        virtual ~SelectorList();
        void pushback(char* text);
        void popback();
        char* getSelector(int index); //liczone od ZERA
        int getSize();
        char isThere(char* sel);
        void check();
};

#endif // SELECTORLIST_H
