#include "attributenode.h"
#include <cstring>
#include <cstdio>
AttributeNode::AttributeNode(AttributeNode* from)
{
    prev = from;
    next = nullptr;
    property = nullptr;
    value = nullptr;
}
AttributeNode::AttributeNode(AttributeNode* from, char* prop, char* val)
{
    prev = from;
    next = nullptr;
    property = new char[strlen(prop)+1];
    value = new char[strlen(val)+1];
    memcpy(property, prop, strlen(prop)+1);
    memcpy(value, val, strlen(val)+1);
}
char* AttributeNode::getProperty() {
    return property;
}
char* AttributeNode::getValue() {
    return value;
}
AttributeNode* AttributeNode::getPrev() {
    return prev;
}
AttributeNode* AttributeNode::getNext() {
    return next;
}
void AttributeNode::setProperty(char* toset) {
    property = toset;
}
void AttributeNode::setValue(char* toset) {
    value = toset;
}
void AttributeNode::setPrev(AttributeNode* toset) {
    prev = toset;
}
void AttributeNode::setNext(AttributeNode* toset) {
    next = toset;
}
AttributeNode::~AttributeNode()
{
    //dtor
    delete[] property;
    delete[] value;
}
