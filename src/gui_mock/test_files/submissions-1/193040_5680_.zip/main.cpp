#include <cstdio>
#include <iostream>
#include <string.h>
#include "basenode.h"
#include "baselist.h"
#include "selectorlist.h"
#include "selectornode.h"
#include "attributelist.h"
#include "attributenode.h"
using namespace std;
char isANumber(char cr) {
    if (cr >= '0' && cr <= '9') return 1;
    return 0;
}
int StringToNumber(char* str) {
    int result = 0;
    int multiplier = 1;
    for (int i=strlen(str)-1; i>=0; --i) {
        int ad = str[i]-'0';
        result += ad * multiplier;
        multiplier *= 10;
    }
    return result;
}
int main()
{
    BaseList sekcje;
    char entry[100000];
    enum Mode {
        COMMAND,
        SELECTOR,
        PROPERTY,
        VALUE
    };
    Mode mode = SELECTOR;
    while (/*scanf("%s", entry) != EOF*/std::cin.getline(entry, 100000)) { //wczytuj, a wykonaj jak nie wczytasz EOF
        if (mode == COMMAND) {
            char trans[5] = "****";
            if (strcmp(trans, entry) == 0) {
                mode = SELECTOR;
            }
            char par1[100000];
            char par2='\0';
            char par3[100000];
            int ct=0;
            par1[0]='\0';
            for (int i=0; entry[i] != ',' && entry[i] != '\0'; ++i) {
                par1[i] = entry[i];
                par1[i+1] = '\0';
                ct++;
            }
            for (int i=strlen(par1)-1; i>=0; --i) {
                if (par1[i]<=' ') {
                    par1[i]='\0';
                }
                else break;
            }
            if (par1[0] == '?') {
                printf("? == %d\n", sekcje.getCount());
                continue;
            }
            ct++; //przejscie za przecinek
            par2 = entry[ct];
            ct+=2; //przejscie za przecinek
            for (int i=ct; entry[i] != '\0'; ++i) {
                par3[i-ct] = entry[i];
                par3[i-ct+1] = '\0';
            }
            if (par2 == 'A') {
                if (par3[0] != '?') {
                    int firstPar = StringToNumber(par1);
                    struct par* fnd = sekcje.getByIndex(firstPar-1);
                    if (fnd != nullptr) {
                        char* prop = fnd->atts->findValuebyProperty(par3);
                        if (prop != nullptr)
                            printf("%d,A,%s == %s\n", firstPar, par3, prop);
                    }
                }
                else {
                    if (isANumber(par1[0])) {
                        int firstPar = StringToNumber(par1);
                        struct par* fnd = sekcje.getByIndex(firstPar-1);
                        if (fnd != nullptr) {
                            printf("%d,A,? == %d\n", firstPar, fnd->atts->getSize());
                        }
                    }
                    else {
                        printf("%s,A,? == %d\n", par1, sekcje.getAttributeCount(par1));
                    }
                }
            }
            else if (par2 == 'S') {
                if (par3[0] != '?') {
                    int firstPar = StringToNumber(par1);
                    struct par* fnd = sekcje.getByIndex(firstPar-1);
                    if (fnd != nullptr) {
                        int thirdPar = StringToNumber(par3);
                        char* prop = fnd->sels->getSelector(thirdPar-1);
                        if (prop != nullptr)
                            printf("%d,S,%d == %s\n", firstPar, thirdPar, prop);
                    }
                }
                else {
                    if (isANumber(par1[0])) {
                        int firstPar = StringToNumber(par1);
                        if (firstPar < 0) continue;
                        struct par* fnd = sekcje.getByIndex(firstPar-1);
                        if (fnd != nullptr) {
                            printf("%d,S,? == %d\n", firstPar, fnd->sels->getSize());
                        }
                    }
                    else {
                        if (par1[0] != '\0') printf("%s,S,? == %d\n", par1, sekcje.getSelectorCount(par1));
                    }
                }
            }
            else if (par2 == 'E') {
                char* res = sekcje.getValue(par1, par3);
                if (res != nullptr) {
                    printf("%s,E,%s == %s\n", par1, par3, res);
                }
            }
            else if (par2 == 'D') {
                if (par3[0]=='*') {
                    int firstPar = StringToNumber(par1);
                    int res = sekcje.deleteSection(firstPar-1);
                    if (res) printf("%d,D,* == deleted\n", firstPar);
                }
                else {
                    int firstPar = StringToNumber(par1);
                    struct par* fnd = sekcje.getByIndex(firstPar-1);
                    if (fnd != nullptr) {
                        int delr = fnd->atts->deleteAttribute(par3);
                        if (delr == 1 &&fnd->atts->getSize()==0) {
                            int res = sekcje.deleteSection(firstPar-1);
                            if (delr == 1 && res == 1) printf("%d,D,%s == deleted\n", firstPar, par3);
                        }
                        else {
                            if (delr == 1) printf("%d,D,%s == deleted\n", firstPar, par3);
                        }
                    }
                }
            }
        }
        else {
            char str1[100000];
            char str2[100000];
            char trans[5]="????";
            if (strcmp(entry, trans) == 0) {
                mode = COMMAND;
                continue;
            }
            char trans2[5]="****";
            if (strcmp(entry, trans2) == 0) {
                continue;
            }
            int ct=0;
            static int sectionAllocated=0;
            static int firstValChar =0;
            static int ignoreSection = 0;
            for (int i=0; entry[i]!='\0'; ++i) {
                if (mode == SELECTOR) {
                    if ((entry[i]<=' ' && firstValChar==0) || entry[i]=='*') {
                        continue;
                    }
                    else if (entry[i]==',') {
                        //if first allocate section
                        if (sectionAllocated==0 && firstValChar == 1) {
                            sekcje.allocate();
                            sectionAllocated++;
                        }
                        //add selector
                        for (int i=strlen(str1)-1; i>=0; --i) {
                            if (str1[i]<=' ' || str1[i]=='*') {
                                str1[i]='\0';
                            }
                            else break;
                        }
                        if (str1[0] != '\0')
                            sekcje.getLastTaken()->sels->pushback(str1);
                        //flush stream
                        str1[0]='\0';
                        firstValChar = 0;
                        ct=0;
                    }
                    else if (entry[i]=='{') {
                        //if first allocate section
                        if (sectionAllocated==0) {
                            sekcje.allocate();
                        }
                        //add selector
                        for (int i=strlen(str1)-1; i>=0; --i) {
                            if (str1[i]<=' ' || str1[i]=='*') {
                                str1[i]='\0';
                            }
                            else break;
                        }
                        if (str1[0] != '\0')
                            sekcje.getLastTaken()->sels->pushback(str1);
                        /*if (sekcje.getLastTaken()->sels->getSize() == 0) {
                            ignoreSection = 1;
                        }*/
                        //flush stream
                        str1[0]='\0';
                        firstValChar = 0;
                        ct=0;

                        mode = PROPERTY;
                    }
                    else {
                        firstValChar = 1;
                        str1[ct] = entry[i];
                        str1[ct+1] = '\0';
                        ct++;
                    }
                }
                else if (mode == PROPERTY) {
                    if (entry[i]<=' ' || ignoreSection == 1) {
                        continue;
                    }
                    else if (entry[i]==':') {
                        mode = VALUE;
                        ct=0;
                    }
                    else if (entry[i]=='}') {
                        mode = SELECTOR;
                        sectionAllocated=0;
                        str1[0]='\0';
                        ct=0;
                        if (sekcje.getLastTaken()->sels->getSize() == 0 && sekcje.getLastTaken()->atts->getSize() == 0) {
                            sekcje.deleteSection(sekcje.getCount()-1);
                        }
                    }
                    else {
                        str1[ct] = entry[i];
                        str1[ct+1] = '\0';
                        ct++;
                    }
                }
                else if (mode == VALUE) {
                    if ((entry[i]<=' ' && firstValChar==0) || ignoreSection == 1) {
                        continue;
                    }
                    else if (entry[i]==';') {
                        for (int i=strlen(str2)-1; i>=0; --i) {
                            if (str2[i]<=' ') {
                                str2[i]='\0';
                            }
                            else break;
                        }
                        if (sekcje.getLastTaken()->atts->findValuebyProperty(str1) != nullptr) {
                            sekcje.getLastTaken()->atts->deleteAttribute(str1);
                        }
                        sekcje.getLastTaken()->atts->pushback(str1,str2);
                        str1[0]='\0';
                        str2[0]='\0';
                        mode = PROPERTY;
                        firstValChar=0;
                        ct=0;
                    }
                    else if (entry[i]=='}') {
                        if (ignoreSection == 1) {
                            ignoreSection = 0;
                            continue;
                        }
                        if (str1[0]!='\0' && str2[0]!='\0') {
                            for (int i=strlen(str2)-1; i>=0; --i) {
                                if (str2[i]<=' ') {
                                        str2[i]='\0';
                                }
                                else break;
                            }
                            if (sekcje.getLastTaken()->atts->findValuebyProperty(str1) != nullptr) {
                                sekcje.getLastTaken()->atts->deleteAttribute(str1);
                            }
                            sekcje.getLastTaken()->atts->pushback(str1,str2);
                            str1[0]='\0';
                            str2[0]='\0';
                        }
                        sectionAllocated=0;
                        firstValChar=0;
                        ct=0;
                        mode = SELECTOR;
                        if (sekcje.getLastTaken()->sels->getSize() == 0 && sekcje.getLastTaken()->atts->getSize() == 0) {
                            sekcje.deleteSection(sekcje.getCount()-1);
                        }
                    }
                    else {
                        firstValChar=1;
                        str2[ct] = entry[i];
                        str2[ct+1] = '\0';
                        ct++;
                    }
                }
            }
        }
    }

    return 0;
}
