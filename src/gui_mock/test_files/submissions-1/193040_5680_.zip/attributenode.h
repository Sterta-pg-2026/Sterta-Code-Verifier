#ifndef ATTRIBUTENODE_H
#define ATTRIBUTENODE_H


class AttributeNode
{
    private:
        AttributeNode* prev;
        AttributeNode* next;
        char* property;
        char* value;
    public:
        AttributeNode(AttributeNode* from);
        AttributeNode(AttributeNode* from, char* prop, char* val);
        virtual ~AttributeNode();
        char* getProperty();
        char* getValue();
        AttributeNode* getPrev();
        AttributeNode* getNext();
        void setProperty(char* toset);
        void setValue(char* toset);
        void setPrev(AttributeNode* toset);
        void setNext(AttributeNode* toset);
};

#endif // ATTRIBUTENODE_H
