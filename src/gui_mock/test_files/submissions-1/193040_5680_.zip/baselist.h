#include "basenode.h"
#ifndef BASELIST_H
#define BASELIST_H
class BaseList
{
    private:
        BaseNode* first;
        BaseNode* last;
        int size;
    public:
        BaseList();
        virtual ~BaseList();
        void pushback();
        void popback();
        void allocate();
        struct par* getLastTaken();
        struct par* getByIndex(int index); //liczone od ZERA!!!
        int getCount();
        int getAttributeCount(char* param);
        int getSelectorCount(char* param);
        char* getValue(char* sel, char* prop);
        int deleteSection(int index);
};

#endif // BASELIST_H
