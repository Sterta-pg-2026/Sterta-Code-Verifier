#include "basenode.h"
#include <cstdio>
#define T 17
BaseNode::BaseNode(BaseNode* from)
{
    //ctor
    prev = from;
    next = nullptr;
    used = 0;
    for (int i=0; i<T; ++i) {
        lists[i].sels = nullptr;
        lists[i].atts = nullptr;
    }
}
BaseNode* BaseNode::getPrev() {
    return prev;
}
BaseNode* BaseNode::getNext() {
    return next;
}
int BaseNode::getUsed() {
    return used;
}
struct par* BaseNode::getLists(int index) {
    return lists+index;
}
void BaseNode::setLists(int index, struct par what) {
    lists[index] = what;
}
void BaseNode::setPrev(BaseNode* toset) {
    prev = toset;
}
void BaseNode::setNext(BaseNode* toset) {
    next = toset;
}
void BaseNode::setUsed(int toset) {
    used = toset;
}
BaseNode::~BaseNode()
{
    //dtor
    for (int i=0; i<T; ++i) {
        if (lists[i].sels != nullptr) {
            delete lists[i].sels;
            lists[i].sels = nullptr;
        }
        if (lists[i].atts != nullptr) {
            delete lists[i].atts;
            lists[i].atts = nullptr;
        }
    }
}
