#include "baselist.h"
#include <cstdio>
#include <cstring>
#define T 17
BaseList::BaseList()
{
    first = nullptr;
    last = nullptr;
    size = 0;
}

BaseList::~BaseList() {
    //jezeli sÄ elementy to je usun
   while (size>1) {
        last = last->getPrev();
        delete last->getNext();
        size--;
    }
    if (size==1) {
        size--;
        delete last;
        last = nullptr;
        first = nullptr;
    }
}
void BaseList::pushback() {
    last = new BaseNode(last);
    size++;
    if (size==1) {
        first = last;
    }
    else {
        last->getPrev()->setNext(last);
    }
}
void BaseList::popback() {
    if (size>1) {
        last = last->getPrev();
        delete last->getNext();
        last->setNext(nullptr);
        size--;
    }
    else if (size==1) {
        size--;
        delete last;
        last = nullptr;
        first = nullptr;
    }
}
void BaseList::allocate() {
    BaseNode* akt = this->last;
    if (akt== nullptr || akt->getUsed() == T) {
        this->pushback();
        akt = this->last;
    }
    akt->getLists(akt->getUsed())->sels = new SelectorList();
    akt->getLists(akt->getUsed())->atts = new AttributeList();
    last->setUsed(last->getUsed()+1);
}
struct par* BaseList::getLastTaken() {
    return last->getLists(last->getUsed()-1);
}
struct par* BaseList::getByIndex(int index) {
    BaseNode* akt = this->first;
    int past = index;
    while (akt != nullptr && past >= akt->getUsed()) {
        past -= akt->getUsed();
        akt = akt->getNext();
    }
    if (akt != nullptr) {
        return akt->getLists(past);
    }
    else return nullptr;
}
int BaseList::getCount() {
    BaseNode* akt = this->first;
    int ct=0;
    while (akt!=nullptr) {
        ct += akt->getUsed();
        akt = akt->getNext();
    }
    return ct;
}
int BaseList::getAttributeCount(char* param) {
    BaseNode* akt = first;
    int ct=0;
    while (akt!=nullptr) {
        for (int i=0; i<akt->getUsed(); ++i) {
            char* wyn = (akt->getLists(i))->atts->findValuebyProperty(param);
            if (wyn != nullptr) ct++;
        }
        akt = akt->getNext();
    }
    return ct;
}
int BaseList::getSelectorCount(char* param) {
    BaseNode* akt = first;
    int ct=0;
    while (akt!=nullptr) {
        for (int i=0; i<akt->getUsed(); ++i) {
            char wyn = (akt->getLists(i))->sels->isThere(param);
            if (wyn == 1) ct++;
        }
        akt = akt->getNext();
    }
    return ct;
}
char* BaseList::getValue(char* sel, char* prop) {
    BaseNode* akt = last;
    while (akt!=nullptr) {
        for (int i=akt->getUsed()-1; i>=0; --i) {
            if ((akt->getLists(i))->sels->isThere(sel)) {
                char* wyn = (akt->getLists(i))->atts->findValuebyProperty(prop);
                if (wyn != nullptr) {
                    return wyn;
                }
            }
        }
        akt = akt->getPrev();
    }
    return nullptr;
}
int BaseList::deleteSection(int index) {
    BaseNode* akt = first;
    int ct = index;
    if (index<0) return 0;
    while (akt!= nullptr && ct >= akt->getUsed()) {
        ct -= akt->getUsed();
        akt = akt->getNext();
        if (ct==0) break;
    }
    if (akt==nullptr) return 0;
    if (akt!=nullptr) {
        struct par tmp = *(akt->getLists(ct));
        struct par tmp2 = *(akt->getLists(akt->getUsed()-1));
        akt->setLists(ct, tmp2);
        akt->setLists(akt->getUsed()-1, tmp);
        for (int i=ct; i<akt->getUsed()-2; ++i) {
            tmp = *(akt->getLists(i));
            tmp2 = *(akt->getLists(i+1));
            akt->setLists(i, tmp2);
            akt->setLists(i+1, tmp);
        }
        int selsiz = (akt->getLists(akt->getUsed()-1))->sels->getSize();
        for (int i=0; i<selsiz; ++i) {
            (akt->getLists(akt->getUsed()-1))->sels->popback();
        }
        int attsiz = (akt->getLists(akt->getUsed()-1))->atts->getSize();
        for (int i=0; i<attsiz; ++i) {
            (akt->getLists(akt->getUsed()-1))->atts->popback();
        }
        akt->setUsed(akt->getUsed()-1);
        if (akt->getUsed() == 0) {
            if (akt==last) last = akt->getPrev();
            if (akt==first) first = akt->getNext();
            if (akt->getPrev() != nullptr) akt->getPrev()->setNext(akt->getNext());
            if (akt->getNext() != nullptr) akt->getNext()->setPrev(akt->getPrev());
            delete akt;
            akt = nullptr;
            size--;
        }
    }
    return 1;
}
