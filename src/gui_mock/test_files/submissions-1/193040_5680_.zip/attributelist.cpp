#include "attributelist.h"
#include <cstdio>
#include <string.h>
AttributeList::AttributeList()
{
    //ctor
    first = nullptr;
    last = nullptr;
    size = 0;
}
void AttributeList::pushback(char* prop, char* val) {
    last = new AttributeNode(last, prop, val);
    size++;
    if (size==1) {
        first = last;
    }
    else {
        last->getPrev()->setNext(last);
    }
}
void AttributeList::popback() {
    if (size>1) {
        last = last->getPrev();
        delete last->getNext();
        last->setNext(nullptr);
        size--;
    }
    else if (size==1) {
        size--;
        delete last;
        last = nullptr;
        first = nullptr;
    }
}
char* AttributeList::getProperty(int index) {
    AttributeNode* toget = first;
    for (int i=0; i<index; ++i) {
        toget = toget->getNext();
    }
    return toget->getProperty();
}
char* AttributeList::getValue(int index) {
    AttributeNode* toget = first;
    for (int i=0; i<index; ++i) {
        toget = toget->getNext();
    }
    return toget->getValue();
}
int AttributeList::getSize() {
    return size;
}
char* AttributeList::findValuebyProperty(char* param) {
    AttributeNode* akt = last;
    while (true) {
        if (akt==nullptr) break;
        if (strcmp(akt->getProperty(), param) == 0) {
            return akt->getValue();
        }
        akt = akt->getPrev();
        if (akt==nullptr) break;
    }
    return nullptr;
}
int AttributeList::deleteAttribute(char* param) {
    AttributeNode* akt = last;
    while (akt != nullptr) {
        if (strcmp(akt->getProperty(), param) == 0) {
            if (akt != first) akt->getPrev()->setNext(akt->getNext());
            if (akt != last) akt->getNext()->setPrev(akt->getPrev());
            if (akt == last) last = akt->getPrev();
            if (akt == first) first = akt->getNext();
            size--;
            delete akt;
            akt = nullptr;
            return 1;
        }
        akt = akt->getPrev();
    }
    return 0;
}
AttributeList::~AttributeList()
{
    //dtor
    while (size>1) {
        last = last->getPrev();
        delete last->getNext();
        size--;
    }
    if (size==1) {
        size--;
        delete last;
        last = nullptr;
        first = nullptr;
    }
}
