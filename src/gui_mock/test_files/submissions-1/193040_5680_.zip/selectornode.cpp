#include "selectornode.h"
#include <cstring>
#include <cstdio>
SelectorNode::SelectorNode(SelectorNode* from)
{
    prev = from;
    next = nullptr;
    content = nullptr;
}
SelectorNode::SelectorNode(SelectorNode* from, char* text)
{
    prev = from;
    next = nullptr;
    content = new char[strlen(text)+1];
    memcpy(content, text, strlen(text)+1);

}
char* SelectorNode::getContent() {
    return content;
}
SelectorNode* SelectorNode::getPrev() {
    return prev;
}
SelectorNode* SelectorNode::getNext() {
    return next;
}
void SelectorNode::setContent(char* toset) {
    content = toset;
}
void SelectorNode::setPrev(SelectorNode* toset) {
    prev = toset;
}
void SelectorNode::setNext(SelectorNode* toset) {
    next = toset;
}
SelectorNode::~SelectorNode()
{
    //dtor
    delete[] content;
}
