#ifndef ATTRIBUTELIST_H
#define ATTRIBUTELIST_H
#include "attributenode.h"

class AttributeList
{
    private:
        AttributeNode* first;
        AttributeNode* last;
        int size;
    public:
        AttributeList();
        virtual ~AttributeList();
        void pushback(char* prop, char* val); //dodaj kolejny atrybut
        void popback();
        char* getProperty(int index); //liczone od ZERA!
        char* getValue(int index);
        char* findValuebyProperty(char* param);
        int getSize();
        int deleteAttribute(char* param);
};

#endif // ATTRIBUTELIST_H
