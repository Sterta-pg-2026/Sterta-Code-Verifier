#ifndef SELECTORNODE_H
#define SELECTORNODE_H
class SelectorNode
{
    private:
        SelectorNode* prev;
        SelectorNode* next;
        char* content;
    public:
        SelectorNode(SelectorNode* from);
        SelectorNode(SelectorNode* from, char* text);
        virtual ~SelectorNode();
        char* getContent();
        SelectorNode* getPrev();
        SelectorNode* getNext();
        void setContent(char* toset);
        void setPrev(SelectorNode* toset);
        void setNext(SelectorNode* toset);
};

#endif // SELECTORNODE_H
