#include "selectorlist.h"
#include <cstdio>
#include <cstring>
SelectorList::SelectorList()
{
    //ctor
    first = nullptr;
    last = nullptr;
    size = 0;
}
void SelectorList::pushback(char* text) {
    last = new SelectorNode(last, text);
    size++;
    if (size==1) {
        first = last;
    }
    else {
        last->getPrev()->setNext(last);
    }
}
void SelectorList::check() {
    SelectorNode* akt = first;
    for (int i=0; i<size; ++i) {
        printf("%d %s\n",akt, akt->getContent());
        akt = akt->getNext();
    }
}
void SelectorList::popback() {
    if (size>1) {
        last = last->getPrev();
        delete last->getNext();
        last->setNext(nullptr);
        size--;
    }
    else if (size==1) {
        size--;
        delete last;
        last = nullptr;
        first = nullptr;
    }
}
char* SelectorList::getSelector(int index) {
    if (index>=size) return nullptr;
    SelectorNode* toget = first;
    for (int i=0; toget!=nullptr && i<index; ++i) {
        toget = toget->getNext();
    }
    if (toget != nullptr) return toget->getContent();
    else return nullptr;
}
int SelectorList::getSize() {
    return size;
}
char SelectorList::isThere(char* sel) {
    SelectorNode* akt = last;
    while (true) {
        if (akt==nullptr) break;
        if (strcmp(akt->getContent(), sel) == 0) {
            return 1;
        }
        akt = akt->getPrev();
        if (akt==nullptr) break;
    }
    return 0;
}
SelectorList::~SelectorList()
{
    //dtor
    while (size>1) {
        last = last->getPrev();
        delete last->getNext();
        size--;
    }
    if (size==1) {
        size--;
        delete first;
        last = nullptr;
        first = nullptr;
    }
}
