#pragma once
#include "string.h"

int strcmp2(const char* cs, const char* ct)
{
    while (1) {
        unsigned char c1, c2;
        c1 = *cs++;
        c2 = *ct++;
        if (c1 != c2)
            return c1 < c2 ? -1 : 1;
        if (!c1)
            break;
    }
    return 0;
}

class LinkedList {
    struct Node {
        String name;
        String value;
        int size;
        Node* next;
        Node* prev;

        Node(String& x) {
            Node(nullptr, nullptr, x); 
        }

        Node(Node* prev, Node* next, String& value) {
            this->prev = prev;
            this->next = next;
            this->value = value;
            this->size = 0;
        }

        Node(Node* prev, Node* next, String& atrr_name, String& attr_value) {
            this->prev = prev;
            this->next = next;
            this->name = atrr_name;
            this->value = attr_value;
            this->size = 0;
        }
    };

    Node* head; 
    Node* tail; 
    int numberOfNodes;

public:

    explicit LinkedList() {
        head = nullptr;
        tail = nullptr;
        numberOfNodes = 0;
    }

    void addAtHead(String& attr_name, String& attr_value) {
        head = new Node(nullptr, head, attr_name, attr_value); 
        if (head->next) {
            head->next->prev = head;
        }
        else {
            tail = head;
        }
    }

    int getNumberOfAttributs() const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            cnt++;
            temp = temp->next;
        }
        return cnt;
    }

    int findSelectorName(String& name) const {
        Node* temp = head;
        while (temp != nullptr) {
            if (strcmp2(name.c_str(), temp->value.c_str()) == 0) {
                return (1);
            }
            temp = temp->next;
        }
        return (0);
    }

    int findAttributeName(String& name) const {
        Node* temp = head;
        while (temp != nullptr) {
            if (strcmp2(name.c_str(), temp->name.c_str()) == 0) {
                return (1);
            }
            temp = temp->next;
        }
        return (0);
    }

    String getNameOfValue(String& name) const {
        Node* temp = head;
        while (temp != nullptr) {
            if (strcmp2(name.c_str(), temp->name.c_str()) == 0) {
                return temp->value.c_str();
            }
            temp = temp->next;
        }
        String nullStr("-1");
        return nullStr.c_str();
    }

    String getNameOfThSelector(int x1) const {
        Node* temp = head;
        int cnt = 1;
        while (temp != nullptr) {
            if (cnt == x1) {
                return temp->value.c_str();
            }
            cnt = cnt + 1;
            temp = temp->next;
        }
        String nullStr("-1");
        return nullStr.c_str();
    }

    int getNumberOfSelector() const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            if (strcmp2(temp->value.c_str(), "") == 0) {
                return 0;
            }
            cnt++;
            temp = temp->next;
        }
        return cnt;
    }

    void addAtTail(String& attr_name) {
        if (head == nullptr) {
            head = new Node(nullptr, head, attr_name);
            if (head->next) {
                head->next->prev = head;
            }
            else {
                tail = head;
            }
        }
        else {
            tail->next = new Node(tail, nullptr, attr_name);
            tail = tail->next;
        }
    }

    int findAttributeNameAndReplace(String& attr_name, String& attr_value) const {
        Node* temp = head;
        while (temp != nullptr) {
            if (strcmp2(attr_name.c_str(), temp->name.c_str()) == 0) {
                temp->value = attr_value;
                return (1);
            }
            temp = temp->next;
        }
        return (0);

    }

    void addAtTailOrReplace(String& attr_name, String& attr_value) {
        if (head == nullptr) {
            addAtHead(attr_name, attr_value);
        }
        else {
            if (findAttributeNameAndReplace(attr_name, attr_value) == 0) {
                tail->next = new Node(tail, nullptr, attr_name, attr_value);
                tail = tail->next;

            }
        }
    }

    int getNumberOfNodes() const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            cnt++;
            temp = temp->next;
        }
        return cnt;
    }

    int getIndexOfAttribute(String& attr_name) const {
        Node* temp = head;
        int idx = 0;
        while (temp != nullptr) {
            if (strcmp2(attr_name.c_str(), temp->name.c_str()) == 0) {
                return (idx);
            }
            idx = idx + 1;
            temp = temp->next;
        }
        return (-1);
    }

    void deleteAtIndex(int index) {
        if (index == 0) {
            if (head) {
                Node* delNode = head;
                head = head->next;
                if (head)
                    head->prev = nullptr;
                else tail = nullptr;
                delete delNode;
            }
        }
        else {
            Node* pre = head;
            for (int i = 1; i < index && pre; ++i)
                pre = pre->next;

            if (pre && pre->next) {
                Node* delNode = pre->next;
                pre->next = delNode->next;
                if (pre->next)
                    pre->next->prev = pre;
                else tail = pre;
                delete delNode;
            }
        }
    }
};