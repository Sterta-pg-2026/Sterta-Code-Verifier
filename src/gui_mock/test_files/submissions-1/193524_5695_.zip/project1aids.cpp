﻿#include <iostream>
#include "singlelist.h"
#include "doublelinkedlist.h"
#include "string.h"
using namespace std;
#define ENTER '\n'
#define SEMICOLON ';'
#define COLON ':'
#define QUESTIONMARK '?'
#define ASTERISK '*'
#define COMMA ','
#define STARTBRACE '{'
#define ENDBRACE '}'

void removeBlankCharacterAtTheEnd(String& str) {
    for (int i = str.length() - 1; i >= 0; i--) {
        if (str.getChar(i) < 33) {
            str.data[i] = '\0';
        }
        else {
            return;
        }
    }
}

void separateSelector(DoubleLinkedList* obj, String& str) {
    String temp;
    bool isChar = false;
    if (str.length() == 0) {
        String nulls("");
        obj->addAtHeadSelector(nulls);
        return;
    }
    for (int i = 0; i < str.length(); ++i) {
        char c;
        c = str.getChar(i);
        if (c > 32 && isChar == false) {
            isChar = true;
        }
        if (c == COMMA) {
            removeBlankCharacterAtTheEnd(temp);
            obj->addAtHeadSelector(temp);
            temp.clear();
            isChar = false;
            continue;
        }
        else if (c < 31 || (str.getChar(i) == ASTERISK)) {
            continue;
        }
        else {
            if (isChar != false) {
                temp.push_back(c);
            }
        }
    }
    removeBlankCharacterAtTheEnd(temp);
    obj->addAtHeadSelector(temp);
}

struct Comand {
    String st;
    String nd;
    String th;
};

int strcmp1(const char* cs, const char* ct)
{
    while (1) {
        unsigned char c1, c2;
        c1 = *cs++;
        c2 = *ct++;
        if (c1 != c2)
            return c1 < c2 ? -1 : 1;
        if (!c1)
            break;
    }
    return 0;
}

bool checkNumber(const char* c) {
    int number = (int)(*c);
    if (number >= 48 && number <= 57) {
        return true;
    }
    return false;
}

bool isNumber(const string& str) {
    for (int i = 0; i < str.length(); i++) {
        const char c = str[i];
        if (checkNumber(&c) == false) {
            return false;
        }
    }
    return true;
}

void check(DoubleLinkedList* obj, Comand& cmd) {
    int st_is_number = isNumber(cmd.st.c_str());
    int th_is_number = isNumber(cmd.th.c_str());

    //print the number of attributes for block number i, if there is no such block, skip
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "A") == 0 && strcmp1(cmd.th.c_str(), "?") == 0) {
        int num = atoi(cmd.st.c_str());
        int cnt = obj->printNumberOfAttributesforBlockNumberI(num);
        if (cnt != -1) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << cnt << ENTER;
        }
        return;
    }
    
    //print the value of the attribute with the name n for the i-th block
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "A") == 0 && th_is_number == false) {
        int num = atoi(cmd.st.c_str());
        String cnt = obj->printValueOfAttributeforBlockNumberI(num, cmd.th);
        if (cnt.cmp("\0") != 0 && cnt.cmp("-1") != 0) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << cnt.c_str() << ENTER;
        }
        return;
    }

    //print the total (for all blocks) number of occurrences of attribute named n
    if (st_is_number == false && strcmp1(cmd.nd.c_str(), "A") == 0 && strcmp1(cmd.th.c_str(), "?") == 0) {
        int cnt = obj->printNumberOfAttributeOccurrencesForAllSections(cmd.st);
        std::cout <<
            cmd.st.c_str() << "," <<
            cmd.nd.c_str() << "," <<
            cmd.th.c_str() << " == " << cnt << ENTER;
        return;
    }

    //print the total (for all blocks) number of occurrences of selector z
    if (st_is_number == false && strcmp1(cmd.nd.c_str(), "S") == 0 && strcmp1(cmd.th.c_str(), "?") == 0) { 
        int cnt = obj->printNumberOfSelectorOccurrencesForAllSections(cmd.st);
        std::cout <<
            cmd.st.c_str() << "," <<
            cmd.nd.c_str() << "," <<
            cmd.th.c_str() << " == " << cnt << ENTER;
        return;
    }

    //print name of the j-th selector for the i-th block 
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "S") == 0 && th_is_number == true) {
        int num = atoi(cmd.st.c_str());
        int num1 = atoi(cmd.th.c_str());
        String cnt = obj->printNameOfSelectedSelector(num, num1);
        if (cnt.cmp("\0") != 0 && cnt.cmp("-1") != 0) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << cnt.c_str() << ENTER;
        }
        return;
    }
    
    // print the number of selectors for block number i 
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "S") == 0 && strcmp1(cmd.th.c_str(), "?") == 0) {
        int num = atoi(cmd.st.c_str());
        int cnt = obj->printNumberOfSelectorsforBlockI(num);
        if (cnt != -1) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << cnt << ENTER;
        }
        return;
    }

    //print the value of the attribute named n for the selector z
    if (strcmp1(cmd.nd.c_str(), "E") == 0) {
        String cnt = obj->printValueOfAttributeForSelectorZ(cmd.st, cmd.th);
        if (cnt.cmp("\0") != 0 && cnt.cmp("-1") != 0) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << cnt.c_str() << ENTER;
        }
        return;
    }

    //remove the entire block number i
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "D") == 0 && strcmp1(cmd.th.c_str(), "*") == 0) {
        int num = atoi(cmd.st.c_str());
        bool cnt = obj->removeEntireBlockI(num);
        if (cnt == true) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << "deleted" << ENTER;
        }
        return;
    }

    //remove the attribute named n from the i-th block
    if (st_is_number == true && strcmp1(cmd.nd.c_str(), "D") == 0 && th_is_number == false) {
        int num = atoi(cmd.st.c_str());
        bool cnt = obj->removeFromIthBlockAttributeN(num, cmd.th);
        if (cnt == true) {
            std::cout <<
                cmd.st.c_str() << "," <<
                cmd.nd.c_str() << "," <<
                cmd.th.c_str() << " == " << "deleted" << ENTER;
        }
        return;
    }
}

void parseCommand(DoubleLinkedList* obj, String& lhs) {
    //print the number of CSS blocks
    if ((int)lhs.length() == 1) {
        int cnt = obj->getNumberOfSection();
        std::cout << "? == " << cnt << ENTER;
        return;
    }

    String rhs;
    rhs.clear();
    int idx = 0;
    Comand cmd;
    bool isChar = false;
    for (int i = 0; i < lhs.length(); ++i) {
        char c = lhs.getChar(i);
        if (c > 32 && isChar == false) {
            isChar = true;
        }
        if (c == COMMA) {
            if (idx == 0) {
                cmd.st = rhs;
            }
            else if (idx == 1) {
                cmd.nd = rhs;
            }
            else {
                cmd.th = rhs;
            }
            idx++;
            isChar = false;
            rhs.clear();
        }
        else {
            if (isChar == true) {
                rhs.push_back(lhs.getChar(i));
            }
        }
    }
    if (rhs.c_str() != "") {
        cmd.th = rhs;
    }
    check(obj, cmd);
}

void commands(DoubleLinkedList* obj) {
    char c;
    int zn = 0;
    String temp;
    while (cin.get(c)) {
        if (c == ENTER) {
            parseCommand(obj, temp);
            zn = 0;
            temp.clear();
            continue;
        }
        if (c == ASTERISK) {
            zn++;
            if (zn == 4) {
                return;
            }
        }
        if (c != ENTER) {
            temp.push_back(c);
        }
    }
    if (temp.length() != 0) {
        parseCommand(obj, temp);
    }
}

void parse(DoubleLinkedList* obj) {
    char s;
    String str;
    char sep = STARTBRACE;
    int zn = 0;
    while (cin.get(s)) {
        if (s == QUESTIONMARK) {
            zn++;
            if (zn == 4) {
                commands(obj);
                zn = 0;
                continue;
            }
            continue;
        }
        if (s == STARTBRACE) {
            separateSelector(obj, str);
            zn = 0;
            char c;
            String* atrr_name = new String();
            String* attr_value = new String();
            String* atrr = new String();
            atrr->clear();
            bool isName = true;
            bool isChar = false;
            while (true) {
                cin.get(c);
                if (c > 32 && isChar == false) {
                    isChar = true;
                }
                if (c < 31) {
                    continue;
                }
                if (c == ENDBRACE) {
                    break;
                }
                if (c == COLON) {
                    isName = false;
                    isChar = false;
                    continue;
                }
                if (c == SEMICOLON) {
                    removeBlankCharacterAtTheEnd(*atrr_name);
                    removeBlankCharacterAtTheEnd(*attr_value);
                    obj->addAtHeadAttribute(*atrr_name, *attr_value);
                    atrr_name->clear();
                    attr_value->clear();
                    isName = true;
                    isChar = false;
                    continue;
                }
                if (isName == false && isChar != false) {
                    attr_value->push_back(c);
                }
                else if (isName == true && isChar != false) {
                    atrr_name->push_back(c);
                }
            }
            if (atrr_name->length() != 0 || attr_value->length() != 0) {
                obj->addAtHeadAttribute(*atrr_name, *attr_value);
            }
            str.clear();
            obj->addSize();
            delete atrr_name;
            delete attr_value;
            delete atrr;
            continue;
        }
        if (s != ENTER) {
            str.push_back(s);
        }
    }
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    DoubleLinkedList* obj = new DoubleLinkedList();
    parse(obj);

    return 0;
}
