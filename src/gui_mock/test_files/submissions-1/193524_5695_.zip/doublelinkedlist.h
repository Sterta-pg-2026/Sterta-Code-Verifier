#pragma once
#include "string.h"
#define MAX_NR_OF_NODES 8

struct ListOfList {
    LinkedList* selectorList;
    LinkedList* attributeList;
    ListOfList() {
        selectorList = new LinkedList();
        attributeList = new LinkedList();
    }
    ~ListOfList() {
        delete selectorList;
        delete attributeList;
    }
};

class DoubleLinkedList {
    struct Node {
        ListOfList data[MAX_NR_OF_NODES];
        int size;
        Node* next;
        Node* prev;

        Node(Node* prev = nullptr, Node* next = nullptr) {
            this->prev = prev;
            this->next = next;
            this->size = 0;
        }
    };

    Node* head;    
    Node* tail;    
    Node* current;
    int numberOfNodes;

public:
    explicit DoubleLinkedList() {
        head = nullptr;
        tail = nullptr;
        current = nullptr;
        numberOfNodes = 0;
    }

    void addAtHeadSelector(String& x) {
        if (current == nullptr) {
            head = new Node();
            tail = current = head;
            numberOfNodes = numberOfNodes + 1;
        }
        if (current->size == MAX_NR_OF_NODES) {
            current->next = new Node(current, nullptr);
            current = current->next;
            tail = current;
            numberOfNodes = numberOfNodes + 1;
        }
        current->data[current->size].selectorList->addAtTail(x);
    }

    void addSize() { current->size++; }

    bool removeEntireBlockI(int num) const {
        Node* temp = head;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr && iter == num) {
                    if (temp->data[i].attributeList != nullptr) {
                        temp->data[i].attributeList->deleteAtIndex(-1);
                    }
                    temp->data[i].selectorList = nullptr;
                    temp->data[i].attributeList = nullptr;
                    return true;
                }
                if (temp->data[i].selectorList != nullptr) {
                    iter = iter + 1;
                }
            }
            temp = temp->next;
        }
        return false;
    }

    void addAtHeadAttribute(String& atrr_name, String& atrr_value) {
        if (current == nullptr) {
            head = new Node();
            tail = current = head;
            numberOfNodes = numberOfNodes + 1;
        }
        if (current->size == MAX_NR_OF_NODES) {
            current->next = new Node(current, nullptr);
            current = current->next;
            tail = current;
            numberOfNodes = numberOfNodes + 1;
        }
        current->data[current->size].attributeList->addAtTailOrReplace(atrr_name,
            atrr_value);
    }

    int getNumberOfSection() const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr && temp->data[i].attributeList != nullptr) {
                    cnt++;
                }
            }
            temp = temp->next;
        }
        return cnt;
    }

     int printNumberOfSelectorOccurrencesForAllSections(String& name) const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr) {
                    cnt += temp->data[i].selectorList->findSelectorName(name);
                }
            }
            temp = temp->next;
        }
        return cnt;
    }

    String printValueOfAttributeForSelectorZ(String& selector_name,String& attribute_name) const {
        Node* temp = head;
        String res("-1");
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr) {
                    if (temp->data[i].selectorList->findSelectorName(selector_name) ==
                        1) {
                        if (temp->data[i].attributeList != nullptr) {
                            res = temp->data[i].attributeList->getNameOfValue(attribute_name);
                        }
                    }
                }
            }
            temp = temp->next;
        }
        return res;
    }

    int printNumberOfAttributeOccurrencesForAllSections(String& name) const {
        Node* temp = head;
        int cnt = 0;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].attributeList != nullptr) {
                    cnt += temp->data[i].attributeList->findAttributeName(name);
                }
            }
            temp = temp->next;
        }
        return cnt;
    }

    String printValueOfAttributeforBlockNumberI(int num, String& name) const {
        Node* temp = head;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].attributeList != nullptr && iter == num) {
                    return temp->data[i].attributeList->getNameOfValue(name);
                }
                if (temp->data[i].attributeList != nullptr)
                    iter = iter + 1;
            }
            temp = temp->next;
        }
        String res("-1");
        return res;
    }

    bool removeFromIthBlockAttributeN(int num, String& name) const {
        Node* temp = head;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr && iter == num) {
                    if (temp->data[i].attributeList != nullptr) {
                        int index = temp->data[i].attributeList->getIndexOfAttribute(name);
                        if (index == -1) {
                            return false;
                        }
                        else {
                            temp->data[i].attributeList->deleteAtIndex(index);
                            if (temp->data[i].attributeList->getNumberOfNodes() == 0) {
                                temp->data[i].selectorList = nullptr;
                                temp->data[i].attributeList = nullptr;
                            }
                            return true;
                        }
                    }
                    else {
                        return false;
                    }
                }
                if (temp->data[i].selectorList != nullptr) {
                    iter = iter + 1;
                }
            }
            temp = temp->next;
        }
        return false;
    }

   String printNameOfSelectedSelector(int x1, int x2) const {
        Node* temp = head;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr && x1 == iter) {
                    return temp->data[i].selectorList->getNameOfThSelector(x2);
                }
                if (temp->data[i].selectorList != nullptr) {
                    iter = iter + 1;
                }
            }
            temp = temp->next;
        }
        String res("-1");
        return res;
    }
 
   int printNumberOfAttributesforBlockNumberI(int num) const {
        Node* temp = head;
        int cnt = 0;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].attributeList != nullptr && iter == num) {
                    cnt += temp->data[i].attributeList->getNumberOfAttributs();
                    return cnt;
                }
                if (temp->data[i].attributeList != nullptr) {
                    iter = iter + 1;
                }
            }
            temp = temp->next;
        }
        return -1;
    }

    int printNumberOfSelectorsforBlockI(int num) const {
        Node* temp = head;
        int cnt = 0;
        int iter = 1;
        while (temp != nullptr) {
            for (int i = 0; i < temp->size; ++i) {
                if (temp->data[i].selectorList != nullptr && iter == num) {
                    cnt += temp->data[i].selectorList->getNumberOfSelector();
                    return cnt;
                }
                if (temp->data[i].selectorList != nullptr) {
                    iter = iter + 1;
                }
            }
            temp = temp->next;
        }
        return -1;
    }
};