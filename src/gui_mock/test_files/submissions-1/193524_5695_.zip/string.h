#pragma once
class String {
private:
    size_t size;

public:
    char* data;
    String() {
        this->data = new char[1];
        this->data[0] = '\0';
    }

    String(const char* str) {
        if (str == nullptr) {
            data = new char[1];
            data[0] = '\0';
        }
        else {
            data = new char[strlen(str) + 1];
            cpy(data, str);
            data[strlen(str)] = '\0';
        }
    }

    char* cpy(char* dest, const char* src) {
        char* tmp = dest;
        while ((*dest++ = *src++) != '\0')
            ;
        return tmp;
    }

    void push_back(char c) {
        const int length = strlen(this->data);
        char* buffer = new char[length + 2];
        cpy(buffer, this->data);
        buffer[length] = c;
        buffer[length + 1] = '\0';
        *this = String(buffer);
        delete[] buffer;
    }

    int cmp(const char* rhs) {
        while (*this->data != '\0' && *rhs != '\0' && *this->data == *rhs) {
            *(this->data)++;
            *rhs++;
        }
        return *this->data - *rhs;
    }

    const char getChar(int index) { return *(this->data + index); }

    const char* c_str() const { return this->data; }

    size_t length() const { return strlen(this->data); }

    void clear() {
        this->data = nullptr;
        this->data = new char[1];
        this->data[0] = '\0';
    }
};