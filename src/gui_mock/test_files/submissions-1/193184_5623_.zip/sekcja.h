#pragma once

#include "ownstring.h";
#include "selektor.h"
#include "atrybuty.h"

#define SIZE 17


struct sekcja {
    Selektor selektory;
    Atrybuty atrybuty;
    bool deleted = false;
};

class Blok {
public:
	sekcja tablica[SIZE];
    int taken;
	Blok* next;
	Blok* prev;
	Blok() {
		next = nullptr;
		prev = nullptr;
        taken = 0;
	}

};

class DoublyLinkedList {
public:
    Blok* head;
    Blok* tail;
    int size;
    int sections;

    DoublyLinkedList();

    ~DoublyLinkedList();

    void appendSelektory(OwnString selektor);

    void addSelektor(OwnString selektor);
    
    void addAtrybut(OwnString atrybut, OwnString wartosc, char znak);

    int calcSekcje() const;
    
    int calcSel(int sekcja) const;
    
    int iloscAtrybutu(OwnString nazwa) const;
    
    int calcAtr(int sekcja) const;
    
    void printAtr(int sekcja, OwnString nazwa, OwnString first, OwnString second, OwnString third) const;
    
    bool isNumber(OwnString string);
   
    void printSel(int sekcja, int selektor, OwnString first, OwnString second, OwnString third) const;

    int iloscSelektora(OwnString nazwa) const;
    
    void findWartoscForSelektor(OwnString nazwa, OwnString selektor) const;

    void performBuffer(OwnString first, OwnString second, OwnString third);
    
    void performBuffer(OwnString info) const;

    bool deleteSekcja(int sekcja);

    void deleteAtrybut(OwnString first, OwnString second, OwnString third);

    void traverseToStart()const;


    void traverseToEnd()const;
    
    void appendBlok();


    void print() const;
};


