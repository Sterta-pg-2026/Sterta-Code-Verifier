#pragma once
#include "ownstring.h"

class SelektorNode {
public:
	OwnString nazwa;
	SelektorNode* next;
	SelektorNode(OwnString givenNazwa) : nazwa(givenNazwa){
		next = nullptr;
	}
	SelektorNode() {
		nazwa = "";
		next = nullptr;
	}
	~SelektorNode() {
		delete next;
	};

};
class Selektor {
public:
	SelektorNode* first;
	int ilosc;
	Selektor();
	void push(OwnString givenNazwa);
	int iloscSelektora(OwnString nazwa) const;
	void showSelektor() const;
	int zliczSelektory() const;
	~Selektor();
};

