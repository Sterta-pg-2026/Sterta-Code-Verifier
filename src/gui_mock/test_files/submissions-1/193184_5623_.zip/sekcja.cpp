#include "sekcja.h"


DoublyLinkedList::DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
        size = 0;
        sections = 0;
    }

DoublyLinkedList::~DoublyLinkedList() {
        Blok* current = head;
        while (current != nullptr) {
            Blok* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
        tail = nullptr;
        size = 0;
        sections = 0;
    }

    void DoublyLinkedList::appendSelektory(OwnString selektor) {
        Blok* newNode = new Blok;
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    void DoublyLinkedList::addSelektor(OwnString selektor) {
        OwnString temp = selektor;
        selektor.trim();
        if (strcmp(selektor.str, "") == 0) {
            //cout << endl;
           /* cout << "sel(" << selektor << ")";
            cout << "temp(" << temp << ")" << endl;*/
            //return;
        }

        if (tail == nullptr) {
            cout << "Pucha" << endl;
        }
        else {
            Blok* curr = head;

            while (curr->next != NULL) {
                curr = curr->next;
            }
            if (curr->taken != SIZE) {
                curr->tablica[curr->taken].selektory.push(selektor);
            }
            else {
                this->appendBlok();
                addSelektor(selektor);
            }
        }
    }

    void DoublyLinkedList::addAtrybut(OwnString atrybut, OwnString wartosc, char znak) {
        if (tail == nullptr) {
            cout << "Pucha" << endl;
        }
        else {
            Blok* curr = head;
            while (curr->next != NULL) {
                curr = curr->next;
            }
            if (curr->taken != SIZE) {
                if (!((strcmp(atrybut.str, "")) == 0 || (strcmp(wartosc.str, "") == 0)))
                    curr->tablica[curr->taken].atrybuty.push(atrybut, wartosc);
                if (znak == '}') {
                    //curr->tablica[curr->taken].selektory.showSelektor();
                    /* curr->tablica[curr->taken].atrybuty.showAtrybuty();*/
                    curr->taken += 1;
                    this->sections += 1;

                }
            }
            else {

                this->appendBlok();
                addAtrybut(atrybut, wartosc, znak);
            }

        }
    }

    int DoublyLinkedList::calcSekcje() const {
        int licznik = 0;
        if (tail == NULL) {
            return licznik;
        }
        else {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted != true) {
                        licznik++;
                    }
                }
                curr = curr->next;

            }
            return licznik;
        }
    }

    int DoublyLinkedList::calcSel(int sekcja) const {
        if (sekcja > sections)
            return -1;
        int licznik = 0;
        if (tail == NULL) {
            return licznik;
        }
        else
        {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted == 1)
                        continue;
                    else
                    {
                        licznik++;
                        if (licznik == sekcja) {
                            return curr->tablica[i].selektory.zliczSelektory();
                        }
                    }
                }
                curr = curr->next;
            }
        }
        return 0;
    }

    int DoublyLinkedList::iloscAtrybutu(OwnString nazwa) const {
        int licznik = 0;
        if (tail == NULL) {
            return licznik;
        }
        else {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted)
                        continue;
                    licznik = licznik + curr->tablica[i].atrybuty.iloscAtrybutu(nazwa);
                }
                curr = curr->next;
            }
            /*         for (int i = 0; i < curr->taken; i++) {
                         if (curr->tablica[i].deleted)
                             continue;
                         licznik = licznik + curr->tablica[i].atrybuty.iloscAtrybutu(nazwa);
                     }*/
            return licznik;
        }
    }

    int DoublyLinkedList::calcAtr(int sekcja) const {
        if (sekcja > sections)
            return 0;
        int licznik = 0;
        if (tail == NULL) {
            return licznik;
        }
        else
        {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted == 1)
                        continue;
                    else
                    {
                        licznik++;
                        if (licznik == sekcja) {
                            return curr->tablica[i].atrybuty.zliczAtrybuty();
                        }
                    }
                }
                curr = curr->next;
            }
        }
        return 0;
    }

    void DoublyLinkedList::printAtr(int sekcja, OwnString nazwa, OwnString first, OwnString second, OwnString third) const {
        int licznik = 1;
        if (sekcja > sections)
            return;
        if (tail == NULL) {
            return;
        }
        else {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    //curr->tablica[i].atrybuty.showAtrybuty();
                    if (curr->tablica[i].deleted == 1) {
                        continue;
                    }

                    else {
                        if (licznik == sekcja) {
                            AtrybutNode* temp = curr->tablica[i].atrybuty.first;

                            while (temp) {
                                if (strcmp(temp->nazwa.str, nazwa.str) == 0) {
                                    cout << first << "," << second << "," << third << " == " << temp->wartosc << endl;
                                }
                                temp = temp->next;
                            }
                        }
                        licznik++;
                    }
                }
                curr = curr->next;
            }
        }
    }

    bool DoublyLinkedList::isNumber(OwnString string) {
        bool result = true;
        for (unsigned int i = 0; i < strlen(string.str); i++) {
            if (!isdigit(string.str[i]))
                result = false;
        }
        return result;
    }

    void DoublyLinkedList::printSel(int sekcja, int selektor, OwnString first, OwnString second, OwnString third) const {
        int licznik = 1;
        int pozycja = 0;
        if (sekcja > sections) {
            return;
        }
        if (tail == NULL) {
            return;
        }
        else {
            Blok* curr = head;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted == 1)
                        continue;
                    else {
                        if (licznik == sekcja) {
                            SelektorNode* temp = curr->tablica[i].selektory.first;
                            while (temp) {
                                pozycja++;
                                if (pozycja == selektor) {
                                    if (strcmp(temp->nazwa.str, "") != 0) {
                                        cout << first << "," << second << "," << third << " == " << temp->nazwa << endl;
                                        return;
                                    }
                                }
                                temp = temp->next;
                            }
                        }
                        licznik++;
                    }
                }

                curr = curr->next;
            }
        }
    }

    int DoublyLinkedList::iloscSelektora(OwnString nazwa) const {
        int licznik = 0;
        if (tail == NULL) {
            return licznik;
        }
        else {
            Blok* curr = head;
            while (curr->next != NULL) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted)
                        continue;
                    licznik = licznik + curr->tablica[i].selektory.iloscSelektora(nazwa);
                }
                curr = curr->next;
            }
            for (int i = 0; i < curr->taken; i++) {
                if (curr->tablica[i].deleted)
                    continue;
                licznik = licznik + curr->tablica[i].selektory.iloscSelektora(nazwa);
            }
            return licznik;
        }
    }

    void DoublyLinkedList::findWartoscForSelektor(OwnString nazwa, OwnString selektor) const {
        if (tail == NULL) {
            cout << "List is empty." << endl;
        }
        else {
            Blok* curr = tail;
            while (curr) {
                for (int i = curr->taken - 1; i >= 0; i--) {
                    if (curr->tablica[i].deleted)
                        continue;
                    SelektorNode* temp = curr->tablica[i].selektory.first;
                    while (temp) {
                        if (strcmp(temp->nazwa.str, selektor.str) == 0) {

                            AtrybutNode* atrib = curr->tablica[i].atrybuty.first;
                            while (atrib) {
                                if (strcmp(atrib->nazwa.str, nazwa.str) == 0) {
                                    cout << selektor << ",E," << nazwa << " == " << atrib->wartosc << endl;
                                    return;
                                }
                                atrib = atrib->next;
                            }
                        }
                        temp = temp->next;
                    }
                }
                curr = curr->prev;
            }
        }
    }

    void DoublyLinkedList::performBuffer(OwnString first, OwnString second, OwnString third) {
        bool pierwszy_liczba = isNumber(first);
        int liczba1 = 0;
        //cout << "(" << first << "," << second << "," << third << ")" << endl;

        if (strcmp(second.str, "s") == 0)
            return;
        else if (strcmp(second.str, "S") == 0) {
            if (pierwszy_liczba && strcmp(third.str, "?") == 0) {
                liczba1 = atoi(first.str);
                if (calcSel(liczba1) != -1)
                    cout << first << "," << second << "," << third << " == " << calcSel(liczba1) << endl;
            }
            else if (pierwszy_liczba) {
                liczba1 = atoi(third.str);
                printSel(atoi(first.str), liczba1, first, second, third);

            }
            else {
                cout << first << "," << second << "," << third << " == " << iloscSelektora(first) << endl;
            }

        }
        else if (strcmp(second.str, "A") == 0) {
            if (pierwszy_liczba && strcmp(third.str, "?") == 0) {
                liczba1 = atoi(first.str);
                if (calcAtr(liczba1) != 0)
                    cout << first << "," << second << "," << third << " == " << calcAtr(liczba1) << endl;
            }
            else if (pierwszy_liczba) {
                liczba1 = atoi(first.str);
                printAtr(liczba1, third, first, second, third);
            }
            else {
                cout << first << "," << second << "," << third << " == " << iloscAtrybutu(first) << endl;
            }
        }
        else if (strcmp(second.str, "E") == 0) {
            findWartoscForSelektor(third, first);

        }
        else if (strcmp(third.str, "*") == 0) {
            liczba1 = atoi(first.str);
            if (deleteSekcja(liczba1))
                cout << first << "," << second << "," << third << " == deleted" << endl;
        }
        else
        {
            deleteAtrybut(first, second, third);
        }
        ;
        return;
    }

    void DoublyLinkedList::performBuffer(OwnString info) const {
        //cout << info << " == "<< calcSekcje() << endl;
        cout << info << " == " << sections << endl;
    }

    bool DoublyLinkedList::deleteSekcja(int sekcja) {
        if (tail == NULL) {
            cout << "List is empty." << endl;
        }
        else {
            Blok* curr = head;
            int indeks = 1;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted)
                        continue;
                    if (indeks == sekcja) {
                        curr->tablica[i].deleted = true;
                        sections = sections - 1;
                        return true;
                    }
                    indeks++;
                }
                curr = curr->next;
            }
        }
        return false;

    }

    void DoublyLinkedList::deleteAtrybut(OwnString first, OwnString second, OwnString third) {
        int sekcja = atoi(first.str);
        if (tail == NULL) {
            cout << "List is empty." << endl;
        }
        else {
            Blok* curr = head;
            int indeks = 1;
            while (curr) {
                for (int i = 0; i < curr->taken; i++) {
                    if (curr->tablica[i].deleted == true)
                        continue;
                    if (indeks == sekcja) {
                        if (curr->tablica[i].atrybuty.usunAtrybut(third.str) == 0)
                            return;
                        cout << first << "," << second << "," << third << " == deleted" << endl;
                        if (curr->tablica[i].atrybuty.zliczAtrybuty() == 0) {
                            deleteSekcja(sekcja);
                            return;
                        }
                        return;
                    }
                    indeks++;
                }
                curr = curr->next;
            }
        }
    }

    void DoublyLinkedList::traverseToStart()const {
        if (tail == NULL) {
            cout << "List is empty." << endl;
        }
        else {
            Blok* curr = tail;
            if (curr->prev == NULL) {
            }
            while (curr->prev != NULL) {
                cout << curr->taken;
                curr = curr->prev;

            }
            cout << curr->taken;
            cout << "End of list: " << endl;
        }
    }


    void DoublyLinkedList::traverseToEnd()const {
        if (tail == NULL) {
            cout << "List is empty." << endl;
        }
        else {
            Blok* curr = head;
            if (curr->next == NULL) {
            }
            while (curr->next != NULL) {
                cout << curr->taken;
                curr = curr->next;

            }
            cout << curr->taken;
            cout << "End of list: " << endl;
        }
    }

    void DoublyLinkedList::appendBlok() {
        Blok* newNode = new Blok;

        if (tail == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }


    void DoublyLinkedList::print() const {
        Blok* current = head;
        while (current != nullptr) {
            current->tablica[0].selektory.showSelektor();
            current = current->next;
        }
        cout << endl;
    }