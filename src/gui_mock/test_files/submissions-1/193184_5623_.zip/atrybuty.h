#pragma once
#include "ownstring.h"

class AtrybutNode {
public:
	OwnString nazwa;
	OwnString wartosc;
	AtrybutNode* next;
	AtrybutNode(OwnString givenNazwa, OwnString givenWartosc) : nazwa(givenNazwa), wartosc(givenWartosc){
		next = nullptr;
	}
	AtrybutNode() {
		nazwa = "";
		wartosc = "";
		next = nullptr;
	}
	~AtrybutNode() {
		delete next;
	};
};

class Atrybuty {
public:
	AtrybutNode* first;
	Atrybuty();
	int zliczAtrybuty() const;
	int iloscAtrybutu(OwnString nazwa) const;
	bool usunAtrybut(OwnString nazwa);
	void push(OwnString givenNazwa, OwnString givenWartosc);
	void showAtrybuty() const;
	~Atrybuty();
};