#include "selektor.h"


Selektor::Selektor(){
	first = NULL;
	ilosc = 0;
}

void Selektor::push(OwnString givenNazwa) {
	SelektorNode* selekt = new SelektorNode(givenNazwa);

	if (first == nullptr) {
		first = selekt;
		ilosc += 1;
		return;
	}
	SelektorNode* temp = first;
	if (strcmp(temp->nazwa.str, givenNazwa.str) == 0) {
		return;
	}
	while (temp->next != NULL) {
		if (strcmp(temp->nazwa.str, givenNazwa.str) == 0) {
			return;
		}
		temp = temp->next;
	}

	temp->next = selekt;
	ilosc += 1;
}
void Selektor::showSelektor() const {
	SelektorNode* temp = first;
	while (temp) {
		cout <<"<" << temp->nazwa <<">" << "->";
		temp = temp->next;
	}
	cout << " koniec" << endl;

}
int Selektor::iloscSelektora(OwnString nazwa) const{
	int licznik = 0;
	SelektorNode* temp = first;
	while (temp) {
		if (strcmp(nazwa.str, temp->nazwa.str) == 0) {
			licznik += 1;
		}
		temp = temp->next;
	}
	return licznik;

}
int Selektor::zliczSelektory() const {
	int licznik = 0;
	//showSelektor();
	SelektorNode* temp = first;
	while (temp) {
		if(strcmp(temp->nazwa.str, "")!=0)
			licznik += 1;
		temp = temp->next;
	}
	return licznik;

}

Selektor::~Selektor() {
	delete first;
}