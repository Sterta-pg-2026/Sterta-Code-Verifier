﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

#include "ownstring.h";
#include "selektor.h"
#include "atrybuty.h"
#include "sekcja.h"

using namespace std;


int main()
{
	OwnString selektor;
	OwnString buffer;
	OwnString nazwa;
	OwnString polecenie;
	int elementy = 0;
	DoublyLinkedList db;
	db.appendBlok();
	int readSelekt = 1;
	bool css = true;
	//FILE* plik = fopen("TESTY_1-6/1.in", "r"); //TESTY_1-6/2.inTESTY_1-6/5.in
	//char hold = getc(plik);
	char hold = getchar();
	while (hold != EOF) {
		if (css) {
			if (readSelekt) {
				if (hold < ' ' && hold != '\n') {

				}
				else if (hold == ',') {
					db.addSelektor(buffer);
					buffer = "";
				}
				else if (hold == '{') {
					db.addSelektor(buffer);
					buffer = "";
					readSelekt = 0;
				}
				else if (hold == '\n') {
					buffer.trim();
					if (strcmp(buffer.str, "????") == 0) {
						buffer = "";
						css = false;
					}
					else if (strcmp(buffer.str, "") != 0) {
						buffer.addChar(hold);
					}
				}
				else
					buffer.addChar(hold);

			}
			else {
				if (hold == ':') {
					buffer.trim();
					nazwa = buffer;
					buffer = "";
				}
				else if (hold == ';') {
					buffer.trim();
					db.addAtrybut(nazwa, buffer, hold);
					buffer = "";
				}
				else if (hold == '}')
				{
					buffer.trim();
					db.addAtrybut(nazwa, buffer, hold);
					buffer = "";
					readSelekt = 1;
				}
				else
				{
					buffer.addChar(hold);
				}
			}
		}
		else {
			if (hold == '\n') {
				buffer.trim();
				if (strcmp(buffer.str, "****") == 0) {
					buffer = "";
					css = true;
					readSelekt = 1;

				}//
				else if (strcmp(buffer.str, "") == 0) {

				}
				else if (elementy == 0) {
					db.performBuffer(buffer);
					buffer = "";
				}
				else if (elementy == 2) {
					db.performBuffer(nazwa, polecenie, buffer);
					buffer = "";
					nazwa = "";
					polecenie = "";
					elementy = 0;
				}
				else{
					buffer.addChar(hold);
				}
			}
			else if (hold == ',') {
				if (elementy == 0) {
					buffer.trim();
					nazwa = buffer;
					buffer = "";
					elementy++;
				}
				else if (elementy == 1) {
					buffer.trim();
					polecenie = buffer;
					buffer = "";
					elementy++;
				}
				else if (elementy > 2) {
					buffer = "";
					nazwa = "";
					polecenie = "";
					elementy = 0;
				}
			}
			else
				buffer.addChar(hold);
		}
		hold = getchar();
		//hold = getc(plik);
	}
	if (strcmp(buffer.str, "") == 0) {
	}
	else if ((strcmp(buffer.str, "?") == 0) && elementy == 0) {
		db.performBuffer(buffer);
		buffer = "";
		elementy = 0;
	}
	else {
		db.performBuffer(nazwa, polecenie, buffer);
		buffer = "";
		nazwa = "";
		polecenie = "";
		elementy = 0;
	}
}
