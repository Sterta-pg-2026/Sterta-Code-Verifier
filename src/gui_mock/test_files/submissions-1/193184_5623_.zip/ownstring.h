#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

class OwnString
{
public:
	char* str;
	size_t size;

	OwnString(const char* other = "");
	~OwnString();

	OwnString(OwnString const& other);

	void addChar(char other);
	void trim();

	OwnString& operator=(const OwnString& other);
	OwnString& operator=(const char* other);

	friend ostream& operator<<(ostream& ostr, const OwnString& str);
};

