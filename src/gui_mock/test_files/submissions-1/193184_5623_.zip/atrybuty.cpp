#include "atrybuty.h"


Atrybuty::Atrybuty() {
	first = nullptr;
}
void Atrybuty::push(OwnString givenNazwa, OwnString givenWartosc) {
	AtrybutNode* atrib = new AtrybutNode(givenNazwa, givenWartosc);

	if (first == NULL) {
		first = atrib;
		return;
	}
	AtrybutNode* temp = first;
	if (strcmp(temp->nazwa.str, givenNazwa.str)==0) {
		temp->wartosc = givenWartosc;
		return;
	}
	while (temp->next != NULL) {
		temp = temp->next;
		if (strcmp(temp->nazwa.str, givenNazwa.str) == 0) {
			temp->wartosc = givenWartosc;
			return;
		}
	}

	temp->next = atrib;
}
int Atrybuty::zliczAtrybuty() const {
	int licznik = 0;
	AtrybutNode* temp = first;
	while (temp) {
		licznik += 1;
		temp = temp->next;
	}
	return licznik;

}
bool Atrybuty::usunAtrybut(OwnString nazwa) {
	AtrybutNode* current = first;
	AtrybutNode* temp = NULL;

	while (current != NULL && strcmp(current->nazwa.str, nazwa.str)!=0) {
		temp = current;
		current = current->next;
	}

	if (current == NULL) { // pusta lista
		return false;
	}
	else if (temp == NULL) {
		first = current->next;
	}
	else {
		temp->next = current->next;
	}
	return true;

}


int Atrybuty::iloscAtrybutu(OwnString nazwa) const {
	int licznik = 0;
	AtrybutNode* temp = first;
	while (temp) {
		if (strcmp(nazwa.str, temp->nazwa.str) == 0) {
			licznik += 1;
		}
		temp = temp->next;
	}
	return licznik;
}
void Atrybuty::showAtrybuty()const {
	AtrybutNode* temp = first;
	while (temp) {
		cout << temp->nazwa << ":" << temp->wartosc <<"->";
		temp = temp->next;
	}
	cout << endl;
}
Atrybuty::~Atrybuty() {
	delete first;
}


