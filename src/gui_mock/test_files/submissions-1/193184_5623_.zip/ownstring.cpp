#include "ownstring.h"


OwnString::~OwnString() {
	delete[] str;
}

OwnString::OwnString(const char* other) {
	size = strlen(other);
	str = new char[size + 1];
	strcpy(str, other);
	str[size] = '\0';
};

OwnString::OwnString(const OwnString& other)
{
	size = strlen(other.str);
	str = new char[size + 1];
	strcpy(str, other.str);
	str[strlen(other.str)] = '\0';
}


OwnString&	OwnString::operator=(const char* other) {
	delete[] str;
	size = strlen(other);
	str = new char[size + 1];
	strcpy(str, other);
	return *this;
}

void OwnString::addChar(char other) {
	char* temp = new char[size + 2];
	strcpy(temp, str);
	temp[size] = other;
	temp[size+1] = '\0';
	delete[] str;
	str = temp;
	size = size + 1;
}

void OwnString::trim() {
	int len = strlen(str);
	int begin = 0, end = len - 1;

	while (isspace((unsigned char)str[begin]) && begin < len) {
		begin++;
	}
	while (end > begin && isspace((unsigned char)str[end])) {
		end--;
	}
	int shift = begin;
	for (int i = begin; i <= end; i++) {
		str[i - shift] = str[i];
	}
	str[end - begin + 1] = '\0';
}

OwnString& OwnString::operator=(const OwnString& other) {
	delete[] str;
	size = strlen(other.str);
	str = new char[size + 1];
	strcpy(str, other.str);
	return *this;
}

ostream& operator<<(ostream& ostr, const OwnString& str) {
	//size_t i = 0;
	
	ostr << str.str;
	//for (int i = 0; i < str.size; i++)
	//{
	//	ostr << str.str[i];
	//}
	return ostr;
}