#include "attribute.hpp"

using CssEngine::Utils::String;
using CssEngine::Engine::Css::Attribute;

Attribute::Attribute(String property, String value): property(property), value(value) {}

const String& Attribute::getProperty() const {
	return property;
}

const String& Attribute::getValue() const {
	return value;
}
