#include <iostream>
#include <exception>

#include "inputparser.hpp"
#include "string.hpp"

using CssEngine::Engine::InputParser;
using CssEngine::Utils::String;

int main() {
	try {
		InputParser inputParser{};

		while (!std::cin.eof()) {
			String input;
			std::cin >> input;

			if (input.length() > 0) {
				inputParser.parseInput(input);
			}
		}

		inputParser.processCommands();

		return 0;
	}
	catch (std::exception& e) {
		std::cout << e.what() << std::endl;
		return 1;
	}
}
