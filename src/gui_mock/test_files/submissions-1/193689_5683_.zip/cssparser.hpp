#ifndef _CSSPARSER_HPP
#define _CSSPARSER_HPP

#include "string.hpp"
#include "list.hpp"
#include "block.hpp"
#include "blockslist.hpp"

namespace CssEngine {
	using Utils::String;
	using Utils::List;

	namespace Engine {
		using Css::Block;
		using Css::BlocksList;
		using Css::Section;
		using Css::Attribute;

		class CSSParser {
		public:
			CSSParser();

			BlocksList& getBlocksList();

			void parseInput(const String& input);
		private:
			void processSection(const String& sectionString);

			List<String> extractSelectors(const String& sectionString);
			List<Attribute> extractAttributes(const String& sectionString);
			void makeSelectorsUnique(List<String>& selectors);
			void makeAttributesUnique(List<Attribute>& attributes);

			BlocksList blocksList;
			String inputStorage;
		};

	}
}

#endif