#include "cssparser.hpp"

using CssEngine::Utils::String;
using CssEngine::Utils::List;
using CssEngine::Engine::CSSParser;
using CssEngine::Engine::Css::Section;
using CssEngine::Engine::Css::Block;
using CssEngine::Engine::Css::Attribute;
using CssEngine::Engine::Css::BlocksList;

CSSParser::CSSParser(): blocksList(), inputStorage() {}

BlocksList& CSSParser::getBlocksList() {
	return blocksList;
}

void CSSParser::parseInput(const String& input) {
	inputStorage = inputStorage + input;

	int cssSectionEndAt;

	do {
		cssSectionEndAt = inputStorage.find("}");

		if (cssSectionEndAt != -1) {
			processSection(inputStorage.substr(0, cssSectionEndAt + 1));
			inputStorage = inputStorage.substr(cssSectionEndAt + 1, inputStorage.length());
		}

	} while (cssSectionEndAt != -1);
}

void CSSParser::processSection(const String& sectionString) {
	List<String> selectors = extractSelectors(sectionString);
	List<Attribute> attributes = extractAttributes(sectionString);

	blocksList.appendSection(Section{ selectors, attributes });
}

List<String> CSSParser::extractSelectors(const String& sectionString) {
	List<String> selectors;

	int sectionOpenedAt = sectionString.find("{");
	int cursor = 0;

	while (cursor < sectionOpenedAt) {
		auto nextSelectorSeparator = sectionString.find(",", cursor);
		if (nextSelectorSeparator >= sectionOpenedAt || nextSelectorSeparator == -1) {
			nextSelectorSeparator = sectionOpenedAt;
		}

		auto selector = sectionString.substr(cursor, nextSelectorSeparator).trim();
		selectors.pushBack(selector);

		cursor = nextSelectorSeparator + 1;
	}

	makeSelectorsUnique(selectors);

	return selectors;
}

List<Attribute> CSSParser::extractAttributes(const String& sectionString) {
	List<Attribute> attributes;

	int sectionOpenedAt = sectionString.find("{");
	int cursor = sectionOpenedAt == -1 ? 0 : sectionOpenedAt + 1;

	while (cursor != -1) {
		auto propertyValueSeparatorAt = sectionString.find(":", cursor);
		auto attributeEndSeparatorAt = sectionString.find(";", cursor);

		if (propertyValueSeparatorAt != -1 && attributeEndSeparatorAt == -1) {
			attributeEndSeparatorAt = static_cast<int>(sectionString.length() - 1);
		}

		if (propertyValueSeparatorAt != -1 && attributeEndSeparatorAt != -1) {
			auto attribute = Attribute{
				sectionString.substr(cursor, propertyValueSeparatorAt).trim(),
				sectionString.substr(propertyValueSeparatorAt + 1, attributeEndSeparatorAt).trim()
			};

			attributes.pushBack(attribute);
		}

		cursor = (attributeEndSeparatorAt != -1) ? attributeEndSeparatorAt + 1 : -1;

		if (cursor >= sectionString.length()) {
			cursor = -1;
		}
	}

	makeAttributesUnique(attributes);

	return attributes;
}

void CSSParser::makeSelectorsUnique(List<String>& selectors) {
	auto selectorNode = selectors.begin();
	while (selectorNode) {
		auto helperNode = selectors.end();

		while (helperNode && helperNode != selectorNode) {
			auto prevHelperNode = helperNode->prev;

			if (selectorNode->value == helperNode->value) {
				selectors.deleteNode(helperNode);
			}

			helperNode = prevHelperNode;
		}

		selectorNode = selectorNode->next;
	}
}

void CSSParser::makeAttributesUnique(List<Attribute>& attributes) {
	auto attributeNode = attributes.end();
	while (attributeNode) {
		auto helperNode = attributes.begin();

		while (helperNode && helperNode != attributeNode) {
			auto nextHelperNode = helperNode->next;

			if (attributeNode->value.getProperty() == helperNode->value.getProperty()) {
				attributes.deleteNode(helperNode);
			}

			helperNode = nextHelperNode;
		}

		attributeNode = attributeNode->prev;
	}
}
