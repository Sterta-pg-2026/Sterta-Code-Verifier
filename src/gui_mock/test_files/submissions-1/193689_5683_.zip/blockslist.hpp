#ifndef _BLOCKS_LIST_HPP
#define _BLOCKS_LIST_HPP

#include "block.hpp"
#include "list.hpp"

namespace CssEngine {
	using Utils::List;

	namespace Engine {
		namespace Css {
			
			class BlocksList {
			public:
				List<Block>& getBlocks();

				//LEGACY
				Block* getLastNonEmptyBlock();
				Section* getSectionBySelectors(List<String> selectors);
				//

				std::size_t getCountOfSections();
				std::size_t getCountOfAttributeProperty(String property);
				std::size_t getCountOfSelector(String selector);
				Section* getNthSection(std::size_t n);

				void appendSection(Section section);
				bool deleteSection(std::size_t index);
			private:

				List<Block> blocks;
			};

		}
	}
}

#endif