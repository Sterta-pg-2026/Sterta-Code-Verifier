#include <stdexcept>
#include <cstring>

#include "block.hpp"

using CssEngine::Engine::Css::Block;
using CssEngine::Engine::Css::Section;

Block::Block(): size(0) {
	sections = new Section[Block::MAX_SIZE];
}

Block::~Block() {
	delete[] sections;
}

Block::Block(Block const& other) : size(other.size) {
	sections = new Section[Block::MAX_SIZE];

	size = other.size;

	for (std::size_t i = 0; i < other.size; i++) {
		sections[i] = other.sections[i];
	}
}

Block& Block::operator=(Block const& other) {
	if (this == &other) {
		return *this;
	}

	size = other.size;

	for (std::size_t i = 0; i < other.size; i++) {
		sections[i] = other.sections[i];
	}

	return *this;
}

void Block::throwIfIndexOutOfBounds(std::size_t index) const {
	if (index < 0 || index >= size) {
		throw std::out_of_range("Index out of bounds");
	}
}

Section& Block::operator[](std::size_t index) {
	throwIfIndexOutOfBounds(index);

	return sections[index];
}

Section& Block::getSection(std::size_t index) {
	return (*this)[index];
}

void Block::deleteIndex(std::size_t index) {
	throwIfIndexOutOfBounds(index);

	if (isEmpty()) {
		throw std::runtime_error("Block is empty");
	}

	if (index < MAX_SIZE - 1) {
		for (std::size_t i = index; i < MAX_SIZE - 1; i++) {
			sections[i] = sections[i + 1];
		}
	}

	size--;
}

void Block::appendSection(Section section) {
	if (isFull()) {
		throw std::runtime_error("Block is full");
	}

	sections[size++] = section;
}

bool Block::isFull() const {
	return size >= MAX_SIZE;
}

bool Block::isEmpty() const {
	return size <= 0;
}

std::size_t Block::getMaxSize() const {
	return Block::MAX_SIZE;
}

std::size_t Block::getSize() const {
	return size;
}
