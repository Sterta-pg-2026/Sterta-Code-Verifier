#ifndef _SECTION_HPP
#define _SECTION_HPP

#include "list.hpp"
#include "string.hpp"
#include "attribute.hpp"

namespace CssEngine {
	using Utils::List;
	using Utils::String;

	namespace Engine {
		namespace Css {

			class Section {
			public:
				Section();
				Section(List<String> selectors, List<Attribute> attributes);

				List<String>& getSelectors();
				List<Attribute>& getAttributes();
			private:
				List<String> selectors;
				List<Attribute> attributes;
			};

		}
	}
}

#endif