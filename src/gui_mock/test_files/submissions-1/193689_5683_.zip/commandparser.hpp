#ifndef _COMMAND_PARSER_HPP
#define _COMMAND_PARSER_HPP

#include "string.hpp"
#include "list.hpp"
#include "command.hpp"

namespace CssEngine {
	using Utils::String;
	using Utils::List;

	namespace Engine {
		using Commands::Command;

		class CommandParser {
		private:
			struct CommandInputParts {
				String a;
				String b;
				String c;
				bool invalid;

				CommandInputParts(String a, String b, String c, bool invalid = false) : a(a), b(b), c(c), invalid(invalid) {};
			};

			CommandInputParts splitInputToParts(const String& commandInput) const;
			bool isNumber(const String& commandInput) const;
			void deleteCommandObjects();

			List<Command*> commands;
		public:
			~CommandParser();

			const List<Command*>& getCommands() const;

			void parseInput(const String& commandInput);
			void clear();
		};

	}
}

#endif