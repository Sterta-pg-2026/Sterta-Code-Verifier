#include "inputparser.hpp"

using CssEngine::Utils::String;
using CssEngine::Engine::InputParser;

InputParser::InputParser() : state(State::PARSE_CSS), cssParser(), commandParser() {};

void InputParser::parseInput(const String& input) {
	if (input == "????") {
		state = State::PARSE_COMMANDS;
	} else if (input == "****") {
		processCommands();
		state = State::PARSE_CSS;
	} else {
		proxyInputToParsers(input);
	}
}

void InputParser::proxyInputToParsers(const String& input) {
	if (state == State::PARSE_COMMANDS) {
		commandParser.parseInput(input);
	}
	else {
		cssParser.parseInput(input);
	}
}

void InputParser::processCommands() {
	auto commandsNode = commandParser.getCommands().begin();
	while (commandsNode) {
		auto& command = commandsNode->value;

		command->execute(cssParser);

		commandsNode = commandsNode->next;
	}

	commandParser.clear();
}
