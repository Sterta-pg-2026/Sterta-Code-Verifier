#define _CRT_SECURE_NO_WARNINGS 1

#include <cstring>
#include <stdexcept>

#include "string.hpp"

using CssEngine::Utils::String;

String::String(): m_length(0) {
    m_data = new char[m_length + 1];
    m_data[0] = '\0';
}

String::String(const char* str): m_length(std::strlen(str)) {
    m_data = new char[m_length + 1];
    std::strncpy(m_data, str, m_length + 1);
}

String::String(const char* str, std::size_t n) : m_length(n) {
    m_data = new char[m_length + 1];
    std::strncpy(m_data, str, m_length);
    m_data[m_length] = '\0';
}

String::String(const String& other): m_length(other.m_length) {
    m_data = new char[m_length + 1];
    std::strncpy(m_data, other.m_data, m_length + 1);
}

String::~String() {
    delete[] m_data;
}

String& String::operator=(const String& other) {
    if (this != &other) {
        delete[] m_data;
        m_length = other.m_length;
        m_data = new char[m_length + 1];
        std::strncpy(m_data, other.m_data, m_length + 1);
    }
    return *this;
}

String String::operator+(const String& other) {
    char* data = new char[m_length + other.m_length + 1];

    std::strncpy(data, m_data, m_length);
    std::strncpy(&data[m_length], other.m_data, other.m_length + 1);

    String newString{ data };

    delete[] data;
    return newString;
}

const char& String::operator[](std::size_t n) const {
    if (n < 0 || n >= length()) {
        throw std::invalid_argument("Index out of bounds");
    }

    return data()[n];
}

bool String::operator==(const String& other) const {
    if (m_length != other.m_length) {
        return false;
    }

    return std::strcmp(m_data, other.m_data) == 0;
}

bool String::operator!=(const String& other) const {
    return !(*this == other);
}

const char* String::data() const {
    return m_data;
}

std::size_t String::length() const {
    return m_length;
}

int String::find(const char* str, const char* substr) const {
    auto result = std::strstr(str, substr);

    if (result != nullptr) {
        return static_cast<int>(result - data());
    }

    return -1;
}

int String::find(const char* substr) const {
    return find(data(), substr);
}

int String::find(const char* substr, std::size_t from) const {
    if (from >= length()) {
        throw std::invalid_argument("Index out of bounds");
    }

    return find(&data()[from], substr);
}

String String::substr(std::size_t begin, std::size_t end) const {
    if (begin > end || begin < 0 || end > length()) {
        throw std::invalid_argument("Invalid indices");
    }

    return String{ &data()[begin], end - begin };
}

String String::trim() const {
    auto isWhitespace = [](char c) {
        return (c == ' ' || c == '\t' || c == '\n' || c == '\r');
    };

    std::size_t beginTrimmed = 0;
    while (beginTrimmed < length() && isWhitespace(data()[beginTrimmed])) {
        beginTrimmed++;
    }
    
    std::size_t endTrimmed = length();
    while (endTrimmed > 0 && isWhitespace(data()[endTrimmed - 1])) {
        endTrimmed--;
    }

    if ((beginTrimmed == 0) && (endTrimmed == length())) {
        return *this;
    }

    if (beginTrimmed >= endTrimmed) {
        return String{};
    }

    return this->substr(beginTrimmed, endTrimmed);
}

namespace CssEngine {
    namespace Utils {

        std::ostream& operator<<(std::ostream& stream, const String& str) {
            stream << str.m_data;
            return stream;
        }

        std::istream& operator>>(std::istream& stream, String& str) {
            const std::size_t BUFFER_SIZE = 1024;

            String newString;
            char buffer[BUFFER_SIZE];

            do {
                stream.clear(stream.rdstate() & ~std::ios_base::failbit);
                stream.getline(buffer, BUFFER_SIZE);

                newString = newString + String{ buffer };
            } while (stream.fail() && !stream.eof());

            str = str + newString;
            return stream;
        }

    }
}
