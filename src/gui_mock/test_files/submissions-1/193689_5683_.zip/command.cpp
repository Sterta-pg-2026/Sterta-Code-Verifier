#include "command.hpp"

using CssEngine::Engine::CSSParser;
using namespace CssEngine::Engine::Commands;

void ListNumberOfSectionsCommand::execute(CSSParser& parser) const {
	auto numberSections = parser.getBlocksList().getCountOfSections();

	std::cout << "? == " << numberSections << std::endl;
}

void PrintNumberOfSelectorsInSection::execute(CSSParser& parser) const {
	auto nthSection = parser.getBlocksList().getNthSection(this->nthSection);

	if (nthSection) {
		auto numberSelectors = nthSection->getSelectors().size();
		std::cout << this->nthSection + 1 << ",S,? == " << numberSelectors << std::endl;
	}
}
	 
void PrintNumberOfAttributesInSection::execute(CSSParser& parser) const {
	auto nthSection = parser.getBlocksList().getNthSection(this->nthSection);

	if (nthSection) {
		auto numberAttributes = nthSection->getAttributes().size();
		std::cout << this->nthSection + 1 << ",A,? == " << numberAttributes << std::endl;
	}
}	 
	 
void PrintNthSelectorOfNthSection::execute(CSSParser& parser) const {
	auto nthSection = parser.getBlocksList().getNthSection(this->nthSection);

	if (nthSection) {
		auto selectorCounter = 0;
		auto selectorNode = nthSection->getSelectors().begin();

		while (selectorNode) {
			if (selectorCounter++ == this->nthSelector) {
				std::cout << this->nthSection + 1 << ",S," << this->nthSelector + 1 << " == " << selectorNode->value << std::endl;
				return;
			}

			selectorNode = selectorNode->next;
		}
	}
}
	 
void PrintAttributeValueOfNthSection::execute(CSSParser& parser) const {	 
	auto nthSection = parser.getBlocksList().getNthSection(this->nthSection);

	if (nthSection) {
		auto attributeNode = nthSection->getAttributes().begin();
		while (attributeNode) {
			auto& attribute = attributeNode->value;
			if (attribute.getProperty() == this->attributeProperty) {
				std::cout << this->nthSection + 1 << ",A," << this->attributeProperty << " == " << attribute.getValue() << std::endl;
				return;
			}

			attributeNode = attributeNode->next;
		}
	}
}	 
	 
void PrintTotalCountOfAttributeProperty::execute(CSSParser& parser) const {
	auto countAttribute = parser.getBlocksList().getCountOfAttributeProperty(this->attributeProperty);

	std::cout << this->attributeProperty << ",A,? == " << countAttribute << std::endl;
}

void PrintTotalCountOfSelector::execute(CSSParser& parser) const {
	auto countSelector = parser.getBlocksList().getCountOfSelector(this->selector);

	std::cout << this->selector << ",S,? == " << countSelector << std::endl;
;}	 
	 
void PrintAttributeValueOfLastSelector::execute(CSSParser& parser) const {
	auto blocksNode = parser.getBlocksList().getBlocks().end();
	while (blocksNode) {
		auto& block = blocksNode->value;

		for(int i = block.getSize() - 1; i >= 0; i--) {
			auto& section = block.getSection(i);
			auto& selectors = section.getSelectors();
			auto& attributes = section.getAttributes();

			auto selectorsNode = selectors.begin();
			while (selectorsNode) {
				auto& selector = selectorsNode->value;

				if (selector == this->selector) {
					auto attributeNode = attributes.begin();
					while (attributeNode) {
						auto& attribute = attributeNode->value;

						if (attribute.getProperty() == this->attributeProperty) {
							std::cout << this->selector << ",E," << this->attributeProperty << " == " << attribute.getValue() << std::endl;
							return;
						}

						attributeNode = attributeNode->next;
					}
				}

				selectorsNode = selectorsNode->next;
			}
		}

		blocksNode = blocksNode->prev;
	}
}	 
	 
void DeleteNthSection::execute(CSSParser& parser) const {
	if (parser.getBlocksList().deleteSection(this->nthSection)) {
		std::cout << this->nthSection + 1 << ",D,* == deleted" << std::endl;
	}
}	 
	 
void DeleteAttributeOfNthSection::execute(CSSParser& parser) const {
	auto nthSection = parser.getBlocksList().getNthSection(this->nthSection);
	
	if (nthSection) {
		auto attributesNode = nthSection->getAttributes().begin();
		while (attributesNode) {
			auto nextAttributesNode = attributesNode->next;

			auto& attribute = attributesNode->value;
			if (attribute.getProperty() == this->attributeProperty) {
				nthSection->getAttributes().deleteNode(attributesNode);

				std::cout << this->nthSection + 1 << ",D," << this->attributeProperty << " == deleted" << std::endl;

				if (nthSection->getAttributes().size() <= 0) {
					parser.getBlocksList().deleteSection(this->nthSection);
				}
			}

			attributesNode = nextAttributesNode;
		}
	}
}
