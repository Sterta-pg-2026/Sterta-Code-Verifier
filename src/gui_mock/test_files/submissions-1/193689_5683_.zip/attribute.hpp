#ifndef _ATTRIBUTE_HPP
#define _ATTRIBUTE_HPP

#include "string.hpp"

namespace CssEngine {
	using Utils::String;

	namespace Engine {
		namespace Css {

			class Attribute {
			public:
				Attribute(String property, String value);

				const String& getProperty() const;
				const String& getValue() const;
			private:
				String property;
				String value;
			};

		}
	}
}

#endif