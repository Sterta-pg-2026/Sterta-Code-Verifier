#ifndef STRING_HPP
#define STRING_HPP

#include <iostream>

namespace CssEngine {
    namespace Utils {

        class String {
        public:
            String();
            String(const char* str);
            String(const String& other);
            ~String();

            String& operator=(const String& other);
            String operator+(const String& other);

            const char& operator[](std::size_t n) const;

            bool operator==(const String& other) const;
            bool operator!=(const String& other) const;

            const char* data() const;
            std::size_t length() const;

            int find(const char* substr) const;
            int find(const char* substr, std::size_t from) const;
            String substr(std::size_t begin, std::size_t end) const;
            String trim() const;

            friend std::ostream& operator<<(std::ostream& stream, const String& str);
            friend std::istream& operator>>(std::istream& stream, String& str);
        private:
            String(const char* str, std::size_t n);

            int find(const char* str, const char* substr) const;

            char* m_data;
            std::size_t m_length;
        };

    }
};

#endif
