#ifndef _COMMAND_HPP
#define _COMMAND_HPP

#include "cssparser.hpp"
#include "string.hpp"

namespace CssEngine {
	using Utils::String;

	namespace Engine {
		namespace Commands {

			class Command {
			public:
				virtual ~Command() {};
				virtual void execute(CSSParser& parser) const = 0;
			};

			class ListNumberOfSectionsCommand : public Command {
			public:
				virtual ~ListNumberOfSectionsCommand() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintNumberOfSelectorsInSection : public Command {
			private:
				int nthSection;
			public:
				PrintNumberOfSelectorsInSection(int nthSection) : nthSection(nthSection) {};

				virtual ~PrintNumberOfSelectorsInSection() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintNumberOfAttributesInSection : public Command {
			private:
				int nthSection;
			public:
				PrintNumberOfAttributesInSection(int nthSection) : nthSection(nthSection) {};

				virtual ~PrintNumberOfAttributesInSection() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintNthSelectorOfNthSection : public Command {
			private:
				int nthSelector;
				int nthSection;
			public:
				PrintNthSelectorOfNthSection(int nthSelector, int nthSection) : nthSelector(nthSelector), nthSection(nthSection) {};

				virtual ~PrintNthSelectorOfNthSection() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintAttributeValueOfNthSection : public Command {
			private:
				int nthSection;
				String attributeProperty;
			public:
				PrintAttributeValueOfNthSection(int nthSection, String attributeProperty) : nthSection(nthSection), attributeProperty(attributeProperty) {};

				virtual ~PrintAttributeValueOfNthSection() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintTotalCountOfAttributeProperty : public Command {
			private:
				String attributeProperty;
			public:
				PrintTotalCountOfAttributeProperty(String attributeProperty) : attributeProperty(attributeProperty) {};

				virtual ~PrintTotalCountOfAttributeProperty() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintTotalCountOfSelector : public Command {
			private:
				String selector;
			public:
				PrintTotalCountOfSelector(String selector) : selector(selector) {};

				virtual ~PrintTotalCountOfSelector() {};
				void execute(CSSParser& parser) const override;
			};

			class PrintAttributeValueOfLastSelector : public Command {
			private:
				String attributeProperty;
				String selector;
			public:
				PrintAttributeValueOfLastSelector(String attributeProperty, String selector) : attributeProperty(attributeProperty), selector(selector) {};

				virtual ~PrintAttributeValueOfLastSelector() {};
				void execute(CSSParser& parser) const override;
			};

			class DeleteNthSection : public Command {
			private:
				int nthSection;
			public:
				DeleteNthSection(int nthSection) : nthSection(nthSection) {};

				~DeleteNthSection() {};
				void execute(CSSParser& parser) const override;
			};

			class DeleteAttributeOfNthSection : public Command {
			private:
				String attributeProperty;
				int nthSection;
			public:
				DeleteAttributeOfNthSection(String attributeProperty, int nthSection) : attributeProperty(attributeProperty), nthSection(nthSection) {};

				virtual ~DeleteAttributeOfNthSection() {};
				void execute(CSSParser& parser) const override;
			};
		}
	}
}

#endif
