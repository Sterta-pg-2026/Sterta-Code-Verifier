#include <cctype>

#include "commandparser.hpp"

using CssEngine::Utils::List;
using CssEngine::Utils::String;
using CssEngine::Engine::CommandParser;
using CssEngine::Engine::Command;
using namespace CssEngine::Engine::Commands;

CommandParser::~CommandParser() {
	deleteCommandObjects();
}

const List<Command*>& CommandParser::getCommands() const {
	return commands;
}

void CommandParser::parseInput(const String& commandInput) {
	if (commandInput == "?") {
		return commands.pushBack(new ListNumberOfSectionsCommand());
	}

	auto parts = splitInputToParts(commandInput);
	if (parts.invalid) {
		return;
	}

	auto isFirstPartDigit = isNumber(parts.a);
	auto isThirdPartDigit = isNumber(parts.c);

	if (isFirstPartDigit) {
		auto firstPartDigit = atoi(parts.a.data());

		if (parts.b == "S" && parts.c == "?") {
			return commands.pushBack(new PrintNumberOfSelectorsInSection{ firstPartDigit - 1 });
		}

		if (parts.b == "A" && parts.c == "?") {
			return commands.pushBack(new PrintNumberOfAttributesInSection{ firstPartDigit - 1 });
		}

		if (isThirdPartDigit) {
			auto thirdPartDigit = atoi(parts.c.data());

			if (parts.b == "S") {
				return commands.pushBack(new PrintNthSelectorOfNthSection{ thirdPartDigit - 1, firstPartDigit - 1 });
			}
		}
		else {
			if (parts.b == "A") {
				return commands.pushBack(new PrintAttributeValueOfNthSection{ firstPartDigit - 1, parts.c });
			}

			if (parts.b == "D" && parts.c == "*") {
				return commands.pushBack(new DeleteNthSection{ firstPartDigit - 1 });
			}

			if (parts.b == "D") {
				return commands.pushBack(new DeleteAttributeOfNthSection{ parts.c, firstPartDigit - 1 });
			}
		}
	}
	else {
		if (parts.b == "A" && parts.c == "?") {
			return commands.pushBack(new PrintTotalCountOfAttributeProperty{ parts.a });
		}

		if (parts.b == "S" && parts.c == "?") {
			return commands.pushBack(new PrintTotalCountOfSelector{ parts.a });
		}

		if (parts.b == "E") {
			return commands.pushBack(new PrintAttributeValueOfLastSelector{ parts.c, parts.a });
		}
	}
}

CommandParser::CommandInputParts CommandParser::splitInputToParts(const String& commandInput) const {
	auto firstToSecondSeparator = commandInput.find(",");
	auto secondToThirdSeparator = commandInput.find(",", firstToSecondSeparator + 1);

	if (firstToSecondSeparator == -1 || secondToThirdSeparator == -1) {
		return CommandInputParts{ "", "", "", true };
	}

	auto a = commandInput.substr(0, firstToSecondSeparator);
	auto b = commandInput.substr(firstToSecondSeparator + 1, secondToThirdSeparator);
	auto c = commandInput.substr(secondToThirdSeparator + 1, commandInput.length());

	return CommandInputParts{ a, b, c };
}

bool CommandParser::isNumber(const String& str) const {
	for (std::size_t i = 0; i < str.length(); i++) {
		if (!std::isdigit(str[i])) {
			return false;
		}
	}
	
	return true;
}

void CommandParser::deleteCommandObjects() {
	auto commandNode = commands.begin();
	while (commandNode) {
		delete commandNode->value;

		commandNode = commandNode->next;
	}
}

void CommandParser::clear() {
	deleteCommandObjects();
	commands = List<Command*>{};
}
