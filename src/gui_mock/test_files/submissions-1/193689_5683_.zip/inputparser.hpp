#ifndef _INPUT_PARSER_HPP
#define _INPUT_PARSER_HPP

#include "string.hpp"
#include "cssparser.hpp"
#include "commandparser.hpp"

namespace CssEngine {

	using Utils::String;

	namespace Engine {

		class InputParser {
		private:
			enum class State {
				PARSE_COMMANDS,
				PARSE_CSS,
			};
		public:
			InputParser();

			void parseInput(const String& input);
			void processCommands();
		private:
			State state;
			CSSParser cssParser;
			CommandParser commandParser;

			void proxyInputToParsers(const String& input);
		};

	}
}

#endif