#ifndef _BLOCK_HPP
#define _BLOCK_HPP

#include <cstdlib>

#include "section.hpp"

namespace CssEngine {
	namespace Engine {
		namespace Css {

			class Block {
			public:
				Block();
				Block(const Block& other);
				~Block();

				Block& operator=(Block const& other);

				Section& operator[](std::size_t index);

				Section& getSection(std::size_t index);
				void deleteIndex(std::size_t index);
				void appendSection(Section section);

				bool isFull() const;
				bool isEmpty() const;

				std::size_t getMaxSize() const;
				std::size_t getSize() const;
			private:
				static const std::size_t MAX_SIZE{ 8 };

				void throwIfIndexOutOfBounds(std::size_t index) const;

				Section* sections;
				std::size_t size;
			};

		}
	}
}

#endif
