#include "blockslist.hpp"

using CssEngine::Utils::List;
using CssEngine::Utils::String;
using CssEngine::Engine::Css::Block;
using CssEngine::Engine::Css::Section;
using CssEngine::Engine::Css::BlocksList;

List<Block>& BlocksList::getBlocks() {
	return blocks;
}

Block* BlocksList::getLastNonEmptyBlock() {
	auto blocksNode = blocks.begin();
	while (blocksNode) {
		auto& block = blocksNode->value;

		if (!block.isFull()) {
			return &block;
		}

		blocksNode = blocksNode->next;
	}

	return nullptr;
}

Section* BlocksList::getSectionBySelectors(List<String> selectors) {
	auto blocksNode = blocks.begin();
	while (blocksNode) {
		auto& block = blocksNode->value;

		for (std::size_t i = 0; i < block.getSize(); i++) {
			auto& section = block.getSection(i);

			if (section.getSelectors() == selectors) {
				return &section;
			}
		}

		blocksNode = blocksNode->next;
	}

	return nullptr;
}

void BlocksList::appendSection(Section section) {
	if (blocks.size() <= 0 || blocks.end()->value.isFull()) {
		blocks.pushBack(Block{});
	}

	blocks.end()->value.appendSection(section);
}

bool BlocksList::deleteSection(std::size_t index) {
	auto blocksNode = blocks.begin();
	while (blocksNode) {
		if (index < blocksNode->value.getSize()) {
			blocksNode->value.deleteIndex(index);
			return true;
		}

		index -= blocksNode->value.getSize();

		blocksNode = blocksNode->next;
	}

	return false;
}

std::size_t BlocksList::getCountOfSections() {
	std::size_t countOfSections = 0;

	auto blocksNode = blocks.begin();
	while (blocksNode) {
		countOfSections += blocksNode->value.getSize();
		blocksNode = blocksNode->next;
	}

	return countOfSections;
}

std::size_t BlocksList::getCountOfAttributeProperty(String property) {
	std::size_t countOfAttribute = 0;

	auto blocksNode = blocks.begin();
	while (blocksNode) {
		auto& block = blocksNode->value;

		for (std::size_t i = 0; i < block.getSize(); i++) {
			auto& attributes = block.getSection(i).getAttributes();

			auto attributesNode = attributes.begin();
			while (attributesNode) {
				if (attributesNode->value.getProperty() == property) {
					countOfAttribute++;
				}

				attributesNode = attributesNode->next;
			}
		}

		blocksNode = blocksNode->next;
	}

	return countOfAttribute;
}

std::size_t BlocksList::getCountOfSelector(String selector) {
	std::size_t countOfSelector = 0;

	auto blocksNode = blocks.begin();
	while (blocksNode) {
		auto& block = blocksNode->value;

		for (std::size_t i = 0; i < block.getSize(); i++) {
			auto& selectors = block.getSection(i).getSelectors();

			auto selectorsNode = selectors.begin();
			while (selectorsNode) {
				if (selectorsNode->value == selector) {
					countOfSelector++;
				}

				selectorsNode = selectorsNode->next;
			}
		}

		blocksNode = blocksNode->next;
	}

	return countOfSelector;
}

Section* BlocksList::getNthSection(std::size_t n) {
	auto blocksNode = blocks.begin();
	while (blocksNode) {
		if (n < blocksNode->value.getSize()) {
			return &blocksNode->value.getSection(n);
		}

		n -= blocksNode->value.getSize();

		blocksNode = blocksNode->next;
	}

	return nullptr;
}

