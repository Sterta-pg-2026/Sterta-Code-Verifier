#include "section.hpp"

using CssEngine::Utils::List;
using CssEngine::Utils::String;
using CssEngine::Engine::Css::Section;
using CssEngine::Engine::Css::Attribute;

Section::Section(): selectors(), attributes() {}

Section::Section(List<String> selectors, List<Attribute> attributes): selectors(selectors), attributes(attributes) {}

List<String>& Section::getSelectors() {
	return selectors;
}

List<Attribute>& Section::getAttributes() {
	return attributes;
}
