#ifndef _LIST_HPP
#define _LIST_HPP

#include <cstdlib>

namespace CssEngine {
	namespace Utils {

        template <typename T>
        struct Node {
        public:
            T value;
            Node<T>* next;
            Node<T>* prev;

            Node(const T& value) : value(value), next(nullptr), prev(nullptr) {};
            Node(const T& value, Node<T>* next, Node<T>* prev): value(value), next(next), prev(prev) {}
        };

        template <typename T>
        class List {
        public:
            List() : m_head(nullptr), m_tail(nullptr), m_size(0) {};

            ~List() {
                auto node = begin();
                while (node) {
                    auto nextNode = node->next;
                    delete node;
                    node = nextNode;
                }

            };

            List(List<T> const& other): m_head(nullptr), m_tail(nullptr), m_size(0) {
                auto node = other.begin();
                while (node) {
                    auto value = node->value;
                    pushBack(value);
                    node = node->next;
                }
            }

            List<T>& operator=(List<T> const& other) {
                if (this == &other) {
                    return *this;
                }

                auto ownedNode = begin();
                while (ownedNode) {
                    auto nextNode = ownedNode->next;
                    delete ownedNode;
                    ownedNode = nextNode;
                }

                m_head = m_tail = nullptr;
                m_size = 0;

                auto othersNode = other.begin();
                while (othersNode) {
                    auto value = othersNode->value;
                    pushBack(value);
                    othersNode = othersNode->next;
                }

                return *this;
            }

            void pushFront(T value) {
                Node<T>* node = new Node<T>{ value, m_head, nullptr };

                m_head = node;
                if (isEmpty()) {
                    m_tail = node;
                }

                m_size++;
            }

            void pushBack(T value) {
                Node<T>* node = new Node<T>{ value, nullptr, m_tail };

                if (isEmpty()) {
                    m_head = node;
                } else {
                    m_tail->next = node;
                }

                m_tail = node;
                m_size++;

            }

            void deleteNode(Node<T>* nodePtr) {
                auto node = begin();
                while (node) {
                    auto nextNode = node->next;

                    if (node == nodePtr) {
                        if (node->prev) {
                            node->prev->next = node->next;
                        }
                        else {
                            m_head = node->next;
                        }

                        if (node->next) {
                            node->next->prev = node->prev;
                        }
                        else {
                            m_tail = node->prev;
                        }

                        delete node;
                        m_size--;
                    }

                    node = nextNode;
                }
            }

            Node<T>* begin() {
                return m_head;
            }

            const Node<T>* begin() const {
                return m_head;
            }

            Node<T>* end() {
                return m_tail;
            }

            const Node<T>* end() const {
                return m_tail;
            }

            std::size_t size() const {
                return m_size;
            };

            bool isEmpty() const {
                return size() == 0;
            }

            bool operator==(List<T>& other) {
                if (size() != other.size()) return false;

                auto thisNode = begin();
                auto otherNode = other.begin();
                while (thisNode && otherNode) {
                    auto thisNodeValue = thisNode->value;
                    auto otherNodeValue = otherNode->value;

                    if (thisNodeValue != otherNodeValue) {
                        return false;
                    }

                    thisNode = thisNode->next;
                    otherNode = otherNode->next;
                }

                return true;
            }

        private:
            Node<T>* m_head;
            Node<T>* m_tail;
            std::size_t m_size;
        };
	}
}

#endif
