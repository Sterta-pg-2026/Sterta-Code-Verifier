#include <iostream>
#include "nodes.h"
#define  T    8
#define MAX_WORD_LENGTH 100
#define MAX_SECTION_LENGTH  2000



char *trimString(char *str)
{
    char *end;

    // Trim leading space
    while(isspace((unsigned char)*str)) str++;

    if(*str == 0)  // All spaces?
        return str;

    // Trim trailing space
    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end)) end--;

    // Write new null terminator character
    end[1] = '\0';

    return str;
}

char* splitStr(char* str, char ch) {
    char* ptr = strchr(str , ch);
    if(ptr == nullptr) {
        return nullptr;
    }
    *ptr = '\0';
     return str+ strlen(str)+1;
}

void printCommandOutput(char* command, const char* result) {
    std::cout<< command << " == " << result << std::endl;
}
void printCommandOutput(char* command, int result) {
    std::cout<< command << " == " << result << std::endl;
}

void executeCommand(char* command, sectionNode** sectionList) {
    command = trimString(command);
    char* cmd = (char* )malloc(sizeof(char)*(strlen(command)+1));
    strcpy(cmd, command);
    if(*command == 0) {
        free(cmd);
        return;
    }
    //std::cout << command << " == " ;
    if(*command=='?') {
        printCommandOutput(cmd,sectionNode::countNodes(*sectionList));
    }else {
        //we split command into 3 parts
        char *partA, *partB, *partC;
        partA = command;
        partB = splitStr(command, ',');
        partC = splitStr(partB, ',');
        switch (*partB) {
            case 'S':
                if(*partC == '?') { //i,S,? and z,S,?
                    int i= atoi(partA);
                    if(i == 0) { //z,S,?
                        printCommandOutput(cmd, sectionNode::countSelectorsByName(*sectionList, partA));
                    }else {//i,S,?
                        sectionNode* sec = dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                                *sectionList, i));
                        if(sec != nullptr) {
                            printCommandOutput(cmd, selectorNode::countNodes(sec->getSelectors()));
                        }
                    }
                }else { //i,S,j
                    sectionNode* sec =dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                            *sectionList, atoi(partA)));
                    if(sec != nullptr) {
                        selectorNode* selecJ = dynamic_cast<selectorNode*>(selectorNode::getIthNode(
                                sec->getSelectors(), atoi(partC)));
                        if(selecJ != nullptr) {
                            printCommandOutput(cmd, selecJ->getName());
                        }
                    }
                }
                break;
            case 'A':
                if(*partC == '?') { //i,A,? and n,A,?
                    int i= atoi(partA);
                    if(i == 0) { //n,A,?
                        printCommandOutput(cmd, sectionNode::countAttributesByName(*sectionList, partA));
                    }else {//i,A,?
                        sectionNode* sec = dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                                *sectionList, i));
                        if(sec != nullptr) {
                            printCommandOutput(cmd, attributeNode::countNodes(*sec->getAttributes()));
                        }
                    }
                }else { //i,A,n
                    int i= atoi(partA);
                    sectionNode* sec = dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                            *sectionList, i));
                    if(sec != nullptr) {
                       attributeNode* aNode = dynamic_cast<attributeNode*>(attributeNode::findNodeByName(
                               partC,*sec->getAttributes()));
                       if(aNode != nullptr) {
                           printCommandOutput(cmd, aNode->getValue());
                       }
                    }
                }
                break;
            case 'E': {
                char* val = sectionNode::getValueByAS(partA, partC, *sectionList);
                if(val != nullptr) {
                    printCommandOutput(cmd, val);
                }
                break;
            }
            case 'D':
                int i= atoi(partA);
                if(*partC == '*') { //i,D,*
                    sectionNode* sec = dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                            *sectionList, i));
                    if(sec != nullptr) {
                        sectionNode::deleteSection(sec,sectionList);
                        char const *out = "deleted";
                        printCommandOutput(cmd,out);
                    }
                }else { //i,D,n
                    sectionNode* sec = dynamic_cast<sectionNode*>(sectionNode::getIthNode(
                            *sectionList, i));
                    if(sec != nullptr) {
                        attributeNode** attrList = sec->getAttributes();
                        attributeNode* node = dynamic_cast<attributeNode*>(attributeNode::findNodeByName(
                                partC, *attrList));
                        if(node != nullptr) {
                            listNode::deleteNode(node, (listNode**)attrList);
                            char const *out = "deleted";
                            printCommandOutput(cmd,out);
                            if(*attrList== nullptr) {
                                sectionNode::deleteSection(sec,sectionList);
                            }
                        }
                    }
                }
                break;
        }
    }
    free(cmd);
}

attributeNode* addAttribute(char* attribute, attributeNode* firstNode) {
    attribute = trimString(attribute);
    char* value = trimString(splitStr(attribute, ':'));
    char* name = trimString(attribute);
    //check if attribute is already defined
    attributeNode* oldNode = dynamic_cast<attributeNode*>(attributeNode::findNodeByName(name,firstNode));
    if(oldNode != nullptr) {
        oldNode->setValue(value);
        return firstNode;
    }
    if(firstNode == nullptr) {
        firstNode = new attributeNode(name, value , nullptr, nullptr);
    }else {
        attributeNode *lastNode = dynamic_cast<attributeNode *>(attributeNode::getLastNode(firstNode));
        attributeNode *newNode = new attributeNode(name, value , lastNode, nullptr);
        lastNode->setNext(newNode);
    }
    //std::cout << "Adding attributeNode: name:[" << name << "], val["<< value << "]" << std::endl;
    return firstNode;
}

selectorNode* addSelector(char* selector, selectorNode* selectorsList) {
    selector = trimString(selector);
    //check if selector is already defined in this section
    selectorNode* oldNode = dynamic_cast<selectorNode*>(selectorNode::findNodeByName(selector,selectorsList));
    if(oldNode != nullptr) {
        return selectorsList;
    }
    if(selectorsList == nullptr) { //the case of the empty list
        selectorsList = new selectorNode(selector, nullptr, nullptr);
    }else { //the case of nonempty list
        selectorNode *lastNode = dynamic_cast<selectorNode*>(selectorNode::getLastNode(selectorsList));
        selectorNode *newNode = new selectorNode(selector, lastNode, nullptr);
        lastNode->setNext(newNode);
    }
    return selectorsList;
    //std::cout << "Adding selectorNode: " << selector << std::endl;
}

sectionNode* parseSection(char* sectionStr, sectionNode* firstNode) {
    char* attributes = splitStr(sectionStr, '{');
    char* selectors = sectionStr;
    selectorNode* selectorsList = nullptr;
    attributeNode* attributesList = nullptr;
    //we first parse selectors
    selectors = trimString(selectors);
    if(*selectors != 0) //in the case of sectionNode without selectors we leave selectorsList = nullptr;
    {
        char* newAdr;
        while ((newAdr=splitStr(selectors , ',')) != nullptr){
            selectorsList = addSelector(selectors,selectorsList);
            selectors = newAdr;
        }
        selectorsList = addSelector(selectors,selectorsList);
    }
    //we next parse attributes
    attributes = trimString(attributes);
    if(*(attributes + strlen(attributes) - 1) == ';'){ //we remove trailing semicolon
        *(attributes + strlen(attributes) - 1) = '\0';
    }
    char* newAdr;
    while ((newAdr = splitStr(attributes , ';'))!= nullptr){
        attributesList = addAttribute(attributes,attributesList);
        attributes = newAdr;
    }
    attributesList = addAttribute(attributes,attributesList);
    //creating a new section node
    if(firstNode == nullptr) {
        firstNode = new sectionNode(selectorsList,attributesList,
                                    nullptr, nullptr);
    }else {
        sectionNode *lastNode = dynamic_cast<sectionNode*>(sectionNode::getLastNode(firstNode));
        sectionNode *newNode = new sectionNode(selectorsList,attributesList,
                                               lastNode, nullptr);
        lastNode->setNext(newNode);
    }
    return firstNode;
    /*
    //---------
    std::cout << "Selectors list: " << std::endl;
    selectorNode* pm = selectorsList;
    while (pm != nullptr) {
        std::cout << pm->getName() <<"__";
        pm = (selectorNode*)pm->getNext() ;
    }
    std::cout <<"||"<< std::endl;
    //----------
    //---------
    std::cout << "Attributes list: " << std::endl;
    attributeNode* pm2 = attributesList;
    while (pm2 != nullptr) {
        std::cout << pm2->getName()<< ":" << pm2->getValue() << "__";
        pm2 = (attributeNode*)pm2->getNext();
    }
    std::cout <<"||"<< std::endl;
    //----------*/
}

int main() {
    //char** words = new char*[n];
    char* buffer = new char[MAX_WORD_LENGTH];
    char* sectionTmp = new char[MAX_SECTION_LENGTH];
    //readingState rState = inSelector;
    bool inCommandMode = false;
    sectionNode* sectionList = nullptr;
    do {
        std::cin >> buffer;
        if(inCommandMode) {
            if(strcmp(buffer, "****")==0) {
                //std::cout << "Out command" << std::endl;
                inCommandMode = false;
            }else {
                strcpy(sectionTmp,buffer);
                std::cin.getline(sectionTmp+ strlen(buffer),MAX_SECTION_LENGTH, '\n');
                executeCommand(sectionTmp,&sectionList);
            }
        }else {
            if(strcmp(buffer, "????")==0) {
                //std::cout << "In command" << std::endl;
                inCommandMode = true;
            }else {
                //std::cout << "<<" << buffer << ">>"<<std::endl;
                strcpy(sectionTmp,buffer);
                std::cin.getline(sectionTmp+ strlen(buffer),MAX_SECTION_LENGTH, '}');
                sectionList = parseSection(sectionTmp,sectionList);
            }
        }

        //std::cout << buffer << std::endl;

    }while(strcmp(buffer, "")!=0);
    //unsigned int maxLen=0;

    //    maxLen = strlen(buffer) > maxLen ? strlen(buffer) : maxLen;
    //    words[i] = new char[MAX_WORD_SIZE];
    //    strcpy(words[i], buffer);
        //words[i] = buffer;

    return 0;
}
