#include "nodes.h"

void listNode::setPrev(listNode *node) {
    this->prev = node;
}

void listNode::setNext(listNode *node) {
    this->next = node;
}

listNode *listNode::getPrev() {
    return this->prev;
}

listNode *listNode::getNext() {
    return this->next;
}

listNode *listNode::getLastNode(listNode *node) {
    listNode* ret = node;
    while(ret->next != nullptr) {
        ret = ret->next;
    }
    return ret;
}

listNode *listNode::getIthNode(listNode *firstNode, int i) {
    listNode* ret = firstNode;
    while(i>1){
        if(ret == nullptr) {
            return nullptr;
        }else {
            ret=ret->next;
            i--;
        }
    }
    return ret;
}

int listNode::countNodes(listNode *firstNode) {
    int i=0;
    listNode* pm = firstNode;
    while(pm != nullptr) {
        i++;
        pm = pm->getNext();
    }
    return i;
}

void listNode::deleteList(listNode *firstNode) {
    while(firstNode != nullptr) {
        listNode* next = firstNode->getNext();
        delete firstNode;
        firstNode = next;
    }
}

void listNode::deleteNode(listNode *node, listNode **firstNode) {//we assume that node != nullptr
    if(node->getPrev() == nullptr && node->getNext() == nullptr) { //single node
        delete node;
        *firstNode= nullptr;
    }else if(node->getPrev() == nullptr) { //first node
        listNode* next = dynamic_cast<listNode*>(node->getNext());
        next->setPrev(nullptr);
        delete node;
        *firstNode = next;
    }else if(node->getNext() == nullptr) {
        listNode* prev = dynamic_cast<listNode*>(node->getPrev());
        prev->setNext(nullptr);
        delete node;
    }else { //middle node
        listNode* next = dynamic_cast<listNode*>(node->getNext());
        listNode* prev = dynamic_cast<listNode*>(node->getPrev());
        prev->setNext(next);
        next->setPrev(prev);
        delete node;
    }
}
