#ifndef CSS_ENGINE_NODES_H
#define CSS_ENGINE_NODES_H
#include <iostream>
class listNode {
protected:
    listNode* prev;
    listNode* next;
public:
    void setPrev(listNode* node);
    void setNext(listNode* node);
    listNode* getPrev();
    listNode* getNext();
    static listNode* getLastNode(listNode* node);
    static listNode* getIthNode(listNode* firstNode, int i);
    static int countNodes(listNode* firstNode);
    static void deleteList(listNode* firstNode);
    static void deleteNode(listNode* node, listNode** firstNode);
    virtual ~listNode() = default;
};

class listNodeWithName: public listNode {
protected:
    char* name;
public:
    char* getName() {
        return name;
    }
    static listNodeWithName* findNodeByName(char* name, listNodeWithName* firstNode){
        listNodeWithName* pm = firstNode;
        while(pm != nullptr) {
            if(strcmp(name,pm->getName())==0) {
                return pm;
            }
            pm = dynamic_cast<listNodeWithName*>(pm->getNext());
        }
        return nullptr;
    }

    static int countNodesByName(listNodeWithName* firstNode, char* name) {
        int i = 0;
        listNodeWithName *node = firstNode;
        while (node != nullptr) {
            if (strcmp(node->getName(), name) == 0) {
                i++;
            }
            node = dynamic_cast<listNodeWithName*>(node->getNext());
        }
        return i;
    }
    virtual ~listNodeWithName() = default;
};

class attributeNode: public listNodeWithName{
    char* value;
public:
    attributeNode(char* name, char* value, attributeNode* prev, attributeNode* next) {
        this->name = (char* )malloc(sizeof(char)*(strlen(name)+1));
        strcpy(this->name, name);
        this->value = (char* )malloc(sizeof(char)*(strlen(value)+1));
        strcpy(this->value, value);
        this->prev=prev;
        this->next=next;
    }
    char* getValue() {
        return value;
    }
    void setValue(char* val) {
        free(value);
        value = (char* )malloc(sizeof(char)*(strlen(val)+1));
        strcpy(value, val);
    }

    ~attributeNode() {
        free(this->name);
        free(this->value);
    }
};

class selectorNode: public listNodeWithName{
public:
    selectorNode(char* name, selectorNode* prev, selectorNode* next) {
        this->name = (char* )malloc(sizeof(char)*(strlen(name)+1));
        strcpy(this->name, name);
        this->prev=prev;
        this->next=next;
    }

    ~selectorNode() {
        free(this->name);
    }
};


class sectionNode: public listNode {
    attributeNode* firstAttribute;
    selectorNode* firstSelector;
    //static sectionNode blocks[T];
    //int counter;
public:
    sectionNode(selectorNode* firstSelector, attributeNode* firstAttribute,
                sectionNode* prev, sectionNode* next) {
        this->firstSelector=firstSelector;
        this->firstAttribute=firstAttribute;
        this->prev=prev;
        this->next=next;
    }
    attributeNode** getAttributes() {
        return &firstAttribute;
    }
    selectorNode* getSelectors() {
        return firstSelector;
    }
    static int countSelectorsByName(sectionNode* firstNode, char* name) {
        int i = 0;
        sectionNode* node = firstNode;
        while(node != nullptr) {
            selectorNode* sNode = node->getSelectors();
            i+=listNodeWithName::countNodesByName(sNode,name);
            node = dynamic_cast<sectionNode*>(node->next);
        }
        return i;
    }

    static int countAttributesByName(sectionNode* firstNode, char* name) {
        int i = 0;
        sectionNode* node = firstNode;
        while(node != nullptr) {
            attributeNode* aNode = *node->getAttributes();
            i+=listNodeWithName::countNodesByName(aNode,name);
            node = dynamic_cast<sectionNode*>(node->next);
        }
        return i;
    }
    static void deleteSection(sectionNode* node, sectionNode** firstNode){//we assume that node != nullptr
        listNode::deleteList(*node->getAttributes());
        listNode::deleteList(node->getSelectors());
        listNode::deleteNode(node, (listNode**)firstNode);
    }
    static char* getValueByAS(char* selector, char* attribute, sectionNode* firstNode) {
        sectionNode* node = firstNode;
        char* value = nullptr;
        while(node != nullptr) {
            if(node->getSelectors() == nullptr ||
               selectorNode::findNodeByName(selector,node->getSelectors()) != nullptr) {
                attributeNode* attr = dynamic_cast<attributeNode*>(attributeNode::findNodeByName(
                        attribute, *node->getAttributes()));
                if(attr != nullptr) {
                    value = attr->getValue();
                }
            }
            node = dynamic_cast<sectionNode*>(node->getNext());
        }
        return value;
    }
};




#endif //CSS_ENGINE_NODES_H
