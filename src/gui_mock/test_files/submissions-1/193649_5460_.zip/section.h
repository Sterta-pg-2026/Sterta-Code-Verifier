#pragma once
#include "utils.h"

#include <stdlib.h>
#include <string.h>

#define BUFFER_LENGTH 1024
#define SCANF_LENGTH "1023"

struct Attribute {

    char *name = nullptr;
    char *value = nullptr;

    ~Attribute() {
        delete[] name;
        delete[] value;
    }

    bool read() {

        char name[BUFFER_LENGTH];
        char value[BUFFER_LENGTH];

        if (scanf(" %" SCANF_LENGTH "[^:}] : %" SCANF_LENGTH "[^;}] ;", name, value) == 2) {

            trimRight(name);
            trimRight(value);
            this->name = allocateString(name);
            this->value = allocateString(value);
            return true;

        }

        return false;

    }

};

struct Section {

    DList<char *> selectors;
    DList<Attribute> attributes;

    bool read() {

        // Read selectors until brace
        while (!testScanf(" {%n")) {

            if (!readSelector()) return false;

        }

        // Read attributes
        while (!testScanf(" }%n")) {

            Attribute newAttribute;

            // Read the attribute
            if (newAttribute.read()) {

                // If the attribute exists, override it
                if (auto oldAttribute = getAttribute(newAttribute.name)) {

                    *oldAttribute = newAttribute;

                }

                // It doesn't, append a new one
                else attributes.append(newAttribute);

                // Prevent the attribute from getting freed
                newAttribute = Attribute();

            }

        }

        return true;

    }

    bool readSelector() {

        auto selector = new char[BUFFER_LENGTH];

        // Scan until comma or brace
        if (scanf(" %" SCANF_LENGTH "[^,{],", selector) == 1) {

            trimRight(selector);
            selectors.append(selector);
            return true;

        }

        // Failed, the selector won't be necessary
        delete[] selector;

        return false;

    }

    bool hasSelector(const char *needle) const {

        for (auto item : selectors) {

            if (strcmp(item, needle) == 0) {

                return true;

            }

        }

        return false;

    }

    /// Get attribute by name; return null if not found.
    Attribute *getAttribute(const char *name) const {

        for (auto &attr : attributes) {

            if (strcmp(attr.name, name) == 0) {
                return &attr;
            }

        }

        return nullptr;

    }

};
