#include "utils.h"

#include <stdio.h>
#include <string.h>
#include <assert.h>

bool testScanf(const char *fmt) {

    int result = 0;
    scanf(fmt, &result);

    return result;

}

void trimRight(char *string) {

    char *whiteTail = string;

    // Go through the string
    for (; *string != '\0'; string++) {

        // Found whitespace
        if (*string == ' ' || *string == '\n' || *string == '\r') {
            continue;
        }

        // Offset the non-white indicator
        whiteTail = string + 1;

    }

    // Remove space if any
    *whiteTail = '\0';

}

char *allocateString(const char *source) {

    // Allocate space for the string, include the terminator
    auto result = new char[strlen(source) + 1];

    // Copy the string
    strcpy(result, source);
    return result;

}

void testDList() {

    DList<int, 3> list;
    assert(list.countNodes() == 0);

    list.append(1);
    list.append(2);

    assert(list[0] == 1);
    assert(list[1] == 2);

    for (auto item : list) {

        assert(item == 1 || item == 2);

    }

    // Test creating new pages
    list.append(3);
    assert(list.countNodes() == 1);
    list.append(4);
    assert(list.countNodes() == 2);

    assert(list[2] == 3);
    assert(list[3] == 4);

    // Remove item at index 2
    list.remove(2);

    // Expected structure: [1, 2] [4]
    assert(list.countNodes() == 2);
    assert(list[0] == 1);
    assert(list[1] == 2);
    assert(list[2] == 4);

    // Add a couple of new items
    list.append(5);
    list.append(6);
    list.append(7);
    list.append(8);

    // Expected structure: [1, 2] [4, 5, 6] [7, 8]
    assert(list.countNodes() == 3);
    assert(list[2] == 4);
    assert(list[3] == 5);
    assert(list[4] == 6);
    assert(list[5] == 7);
    assert(list[6] == 8);

    // Remove the items in the middle segment
    auto it = list.get(2);
    size_t i = 3;
    while (i --> 0) {
        list.remove(it);
    }

    // Expected structure: [1, 2] [7, 8]
    assert(list.countNodes() == 2);
    assert(list[2] == 7);
    assert(list.frontNode != list.backNode);

    // Remove the last two nodes too
    list.remove(it);
    list.remove(it);
    assert(list.countNodes() == 1);

    // Add another item
    list.append(3);
    assert(list.countNodes() == 1);
    assert(list[0] == 1);
    assert(list[1] == 2);
    assert(list[2] == 3);
    assert(list.frontNode == list.backNode);

    // Empty it now!
    it = list.begin();
    i = 3;
    while (i --> 0) {
        list.remove(it);
    }
    assert(list.countNodes() == 0);
    assert(list.frontNode == nullptr);
    assert(list.backNode == nullptr);

}
