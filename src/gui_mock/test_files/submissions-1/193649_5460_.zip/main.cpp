#include "utils.h"
#include "section.h"

#include <cstdio>
#include <cstring>

#define SECTION_BLOCK_SIZE 8

void test() {

    testDList();

}

void printPrompt(const char *lefthand, char command, const char *righthand) {

    printf("%s,%c,%s == ", lefthand, command, righthand);

}

void querySelectors(DList<Section, SECTION_BLOCK_SIZE> &css, const char *lefthand, const char *righthand) {

    // Possible options:
    //   %d,S,?
    //   %d,S,%d
    //   %s,S,?

    int sectionNumber;

    // Number first
    if (sscanf(lefthand, "%d", &sectionNumber) == 1) {

        // Find the section
        auto section = css.get(sectionNumber - 1);
        if (!section) return;

        // Count selectors
        if (strcmp(righthand, "?") == 0) {

            printPrompt(lefthand, 'S', righthand);
            printf("%zd\n", section->selectors.count());

        }

        // Look selector up by number
        else {

            int selectorNumber;
            sscanf(righthand, "%d", &selectorNumber);

            // Find the selector
            auto selector = section->selectors.get(selectorNumber - 1);

            // Output if it exist
            if (selector) {
                printPrompt(lefthand, 'S', righthand);
                printf("%s\n", *selector);
            }

        }

    }

    // Count occurences of given selector
    else {

        int result = 0;

        // Check each section
        for (auto &section : css) {

            // And each selector
            for (auto selector : section.selectors) {

                // Find the specific selector
                if (strcmp(lefthand, selector) == 0) {
                    result++;
                    break;
                }

            }

        }

        printPrompt(lefthand, 'S', righthand);
        printf("%d\n", result);

    }

}

void queryAttributes(DList<Section, SECTION_BLOCK_SIZE> &css, const char *lefthand, const char *righthand) {

    // Possible options:
    //   %d,A,?
    //   %d,A,%s
    //   %s,A,?

    int sectionNumber;

    // Number first
    if (sscanf(lefthand, "%d", &sectionNumber) == 1) {

        // Find the section
        auto section = css.get(sectionNumber - 1);
        if (!section) return;

        // Count attributes
        if (strcmp(righthand, "?") == 0) {

            printPrompt(lefthand, 'A', righthand);
            printf("%zd\n", section->attributes.count());

        }

        // Look up attributes
        else for (auto &attribute : section->attributes) {

            // Found the attribute
            if (strcmp(attribute.name, righthand) == 0) {

                printPrompt(lefthand, 'A', righthand);
                printf("%s\n", attribute.value);
                return;

            }

        }

    }

    // Count occurences given attribute
    else {

        int result = 0;

        for (auto &section : css) {

            // Count matching attributes, up to one per section
            if (section.getAttribute(lefthand)) {
                result++;
            }

        }

        printPrompt(lefthand, 'A', righthand);
        printf("%d\n", result);

    }

}

void queryFind(DList<Section, SECTION_BLOCK_SIZE> &css, const char *lefthand, const char *righthand) {

    const char *result = nullptr;

    for (auto &section : css) {

        // Find sections with the given selector
        if (!section.hasSelector(lefthand)) continue;

        // Find the attribute
        if (auto attribute = section.getAttribute(righthand)) {

            result = attribute->value;

        }

    }

    // Found the attribute
    if (result) {
        printPrompt(lefthand, 'E', righthand);
        printf("%s\n", result);
    }

}

/// Remove nodes
void deleteData(DList<Section, SECTION_BLOCK_SIZE> &css, const char *lefthand, const char *righthand) {

    int sectionNumber;
    sscanf(lefthand, "%d", &sectionNumber);

    auto section = css.get(sectionNumber - 1);
    if (!section) return;

    // Remove section
    if (strcmp(righthand, "*") == 0) {

        css.remove(section);
        printPrompt(lefthand, 'D', righthand);
        printf("deleted\n");

    }

    // Remove attribute
    else {

        auto &attributes = section->attributes;
        bool deleted = false;

        for (auto it = attributes.begin(); it != attributes.end(); ++it) {

            // Found the attribute
            if (strcmp(righthand, it->name) == 0) {

                // Remove it
                attributes.remove(it);
                deleted = true;

            }

        }

        // Remove the section if emptied
        if (attributes.isEmpty()) {
            css.remove(section);
        }

        if (deleted) {
            printPrompt(lefthand, 'D', righthand);
            printf("deleted\n");
        }

    }

}

bool runCommands(DList<Section, SECTION_BLOCK_SIZE> &css) {

    // Count sections
    if (testScanf(" ?%n")) {

        printf("? == %zd\n", css.count());
        return true;

    }

    // Load buffers for command input
    char lefthand[BUFFER_LENGTH] = { 0 };
    char righthand[BUFFER_LENGTH] = { 0 };
    char command;

    int result = scanf(" %" SCANF_LENGTH "[^,], %c, %" SCANF_LENGTH "[^\n]", lefthand, &command, righthand);

    // Stop if reached end of file
    if (result == EOF) return false;

    // Invalid command
    else if (result != 3) {

        // Skip until end of line
        scanf("%*[^\n]");
        return true;

    }

    trimRight(lefthand);
    trimRight(righthand);

    switch (command) {

        case 'S':
            querySelectors(css, lefthand, righthand);
            break;

        case 'A':
            queryAttributes(css, lefthand, righthand);
            break;

        case 'E':
            queryFind(css, lefthand, righthand);
            break;

        case 'D':
            deleteData(css, lefthand, righthand);
            break;

        // Unknown command
        default:
            break;

    }

    return true;

}

int main() {

    test();

    DList<Section, SECTION_BLOCK_SIZE> css;

    bool commandMode = false;

    // Read data
    while (true) {

        Section section;

        // Command mode
        if (commandMode) {

            // Mode switch
            if (testScanf(" ****%n")) {
                commandMode = false;
            }

            // Run commands; stop on failure
            else if (!runCommands(css)) break;

        }

        // CSS mode
        else {

            // Mode switch
            if (testScanf(" ????%n")) {
                commandMode = true;
            }

            // Read CSS sections
            else if (section.read()) {
                css.append(section);
            }

            // Stop on failure
            else break;

        }

    }

    // Print remaining buffer for debugging
    char buffer[BUFFER_LENGTH] = { 0 };
    scanf("%" SCANF_LENGTH "s", buffer);
    printf("%s", buffer);

}
