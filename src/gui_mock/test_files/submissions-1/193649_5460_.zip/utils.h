#pragma once
#include <stdio.h>
#include <assert.h>
#include <stddef.h>

/// Run a scanf containing only a %n modifier and return true if matched.
bool testScanf(const char *fmt);

/// Remove trailing whitespace from the string.
void trimRight(char *string);

/// Allocate the given string on the heap.
char *allocateString(const char *source);

template <typename T, size_t blockSize = 1>
struct DList;

template <typename T, size_t blockSize = 1>
struct DListNode {

    /// The previous and next nodes in the chain.
    DListNode *previous = nullptr;
    DListNode *next = nullptr;

    /// Number of items in the chain.
    size_t length = 0;

    /// Stored item.
    T data[blockSize];

};

template <typename T, size_t blockSize = 1>
struct DListIterator {

    DListNode<T, blockSize> *node = nullptr;
    size_t index = 0;

    bool operator!=(const DListIterator & other) const {

        return node  != other.node
            || index != other.index;

    }

    void operator++() {

        // Ignore if this is the end
        if (node == nullptr) return;

        assert(node->length <= blockSize);

        // Advance to the next item
        index++;

        // Reached end of the array
        if (index >= node->length) {

            // Advance to the next node
            node = node->next;
            index = 0;

        }

    }

    T &operator*() const {

        return node->data[index];

    }

    T *operator->() const {

        return &node->data[index];

    }

    operator bool() const {

        return node != nullptr;

    }

};

template <typename T, size_t blockSize>
struct DList {

    DListNode<T, blockSize> *frontNode = nullptr;
    DListNode<T, blockSize> *backNode = nullptr;

    DList() { }
    DList(const DList &) = delete;

    /// Check if the list is empty.
    bool isEmpty() const {

        return backNode == nullptr;

    }

    /// Add a new item at any spot in the list.
    void append(const T &item) {

        append() = item;

    }

    /// Add a new item at any spot in the list.
    T &append() {

        // No elements present or the tail is full
        if (backNode == nullptr || backNode->length == blockSize) {

            // Add a new node and insert the item
            auto node = appendNode();
            node->length = 1;
            return node->data[0];

        }

        // Free space in the last item
        else return backNode->data[backNode->length++];

    }

    /// Remove item by index
    void remove(size_t index) {

        auto it = get(index);
        remove(it);

    }

    /// Remove the item from the list and advance to the next one.
    void remove(DListIterator<T, blockSize> &it) {

        // Reduce node length
        it.node->length -= 1;

        // If there are no items left, remove the node
        if (it.node->length == 0) {

            auto nextNode = it.node->next;

            // Resolve linkage with the left node
            if (it.node->previous) it.node->previous->next = it.node->next;
            else frontNode = it.node->next;

            // Resolve linkage with the right node
            if (it.node->next) it.node->next->previous = it.node->previous;
            else backNode = it.node->previous;

            // Delete the node itself
            delete it.node;

            // Advance to the next node
            it.node = nextNode;
            it.index = 0;

        }

        // Shift all following items leftwards
        else {

            for (size_t i = it.index; i < it.node->length; i++) {

                it.node->data[i] = it.node->data[i+1];

            }

            // Overflowed, advance
            if (it.index >= it.node->length) {

                it.node = it.node->next;
                it.index = 0;

            }

        }

    }

    /// Get an item iterator by index.
    DListIterator<T, blockSize> get(size_t index) const {

        auto node = frontNode;

        while (node != nullptr) {

            // If this node contains the item
            if (index < node->length) {

                return DListIterator<T, blockSize> { node, index };

            }

            // Advance to the next node
            index -= node->length;
            node = node->next;

        }

        // Invalid node
        return end();

    }

    /// Get an item by index.
    T &operator[](size_t index) {

        auto iterator = get(index);

        assert(iterator.node != nullptr);

        return *iterator;

    }

    T &front() {

        return frontNode->data[0];

    }

    T &back() {

        return backNode->data[backNode->length - 1];

    }

    /// Get the first element in the list, used for iteration.
    DListIterator<T, blockSize> begin() const {

        return DListIterator<T, blockSize> { frontNode };

    }

    /// Get the end of the list.
    DListIterator<T, blockSize> end() const {

        return DListIterator<T, blockSize> { nullptr };

    }

    /// Count number of nodes in the list.
    size_t countNodes() const {

        auto node = frontNode;
        size_t result = 0;

        while (node != nullptr) {

            result += 1;
            node = node->next;

        }

        return result;

    }

    /// Count number of items in the list
    size_t count() const {

        auto node = frontNode;
        size_t result = 0;

        while (node != nullptr) {

            result += node->length;
            node = node->next;

        }

        return result;

    }

private:

    /// Allocate space for a new list item.
    T *allocate() {

        auto node = frontNode;

        // Iterate through each node
        while (node != nullptr) {

            // Free space
            if (node->length != blockSize) {

                // Use it up
                return &node->data[node->length++];

            }

            // Advance to the next node
            node = node->next;

        }

        // No free space found, add a new node
        node = appendNode();
        node->length = 1;

        return &node->data[0];

    }

    DListNode<T, blockSize> *appendNode() {

        // Add a new node to the chain
        auto node = new DListNode<T, blockSize>;
        node->previous = backNode;

        // Link it up to the previous node, if applicable
        if (backNode) backNode->next = node;

        // If it's the first item, mark it as such
        if (!frontNode) frontNode = node;

        // Make it the last item
        return backNode = node;

    }

};

void testDList();
