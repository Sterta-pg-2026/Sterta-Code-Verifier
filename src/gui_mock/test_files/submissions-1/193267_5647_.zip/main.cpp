#include <iostream>
#include <cmath>
#define CSS_INPUT_MODE 0
#define COMMAND_INPUT_MODE 1
#define T 8
#define STRING_SIZE 300
using namespace std;
struct text
{
    char text[STRING_SIZE];
    int i;
};
struct ListSelector {
    text selector;
    ListSelector* next;
};
struct ListAttr {
    text attr_name;
    text attr_value;
    ListAttr* next;
};
struct Section {
    ListSelector Selectors;
    ListAttr Attrs;
    ListSelector* first_s;
    ListSelector* last_s;
    ListAttr* first_a;
    ListAttr* last_a;
    Section() {
        first_s = nullptr;
        last_s = nullptr;
        first_a = nullptr;
        last_a = nullptr;
    }

};
struct List_1lvl {
    List_1lvl* next;
    List_1lvl* prev;
    Section section[T];
};

int texttoint(text z) {
    int i = 0;
    for (int k = 0; k < z.i; k++)
    {
        i = i + (((int)z.text[z.i - k - 1] - 48) * pow(10, k));
    }
    return i;
}


void add_List_1lvl(List_1lvl*& first, List_1lvl*& last) {
    List_1lvl* newItem = new List_1lvl;
    newItem->next = nullptr;
    newItem->prev = last;
    if (first== nullptr) {
        first = newItem;
        last = newItem;
    }
    else {
        last->next = newItem;
        last = newItem;
    }
}
void add_selector(text* selector, Section* section) {
    ListSelector* new_selector = new ListSelector;
    for (int i = 0; i < selector->i; i++) {
        new_selector->selector.text[i] = selector->text[i];
    }
    new_selector->selector.i = selector->i;
    new_selector->next = nullptr;
    if (section->first_s == nullptr) {
        section->first_s = new_selector;
        section->last_s = new_selector;
    }
    else {
        section->last_s->next = new_selector;
        section->last_s = new_selector;
    }
}

void add_attr(text* attr_name, text* attr_value, Section* section) {
    ListAttr* new_attr = new ListAttr;
    for (int i = 0; i < attr_name->i; i++) {
        new_attr->attr_name.text[i] = attr_name->text[i];
    }
    new_attr->attr_name.i = attr_name->i;
    for (int i = 0; i < attr_value->i; i++) {
        new_attr->attr_value.text[i] = attr_value->text[i];
    }
    new_attr->attr_value.i = attr_value->i;
    new_attr->next = nullptr;
    if (section->first_a == nullptr) {
        section->first_a = new_attr;
        section->last_a = new_attr;
    }
    else {
        section->last_a->next = new_attr;
        section->last_a = new_attr;
    }
}

void selector_getter(text* selector, bool* mode, Section* section) {
    char t;
    int counter = 0, mode_counter = 0;
    selector->i = 0;
    while (cin >> t) {
        counter++;
        if (t == '?') mode_counter++;
        if (counter == 4 && mode_counter == 4) {
            *mode = COMMAND_INPUT_MODE;
            break;
        }
        if (*mode == CSS_INPUT_MODE)
        {
            if (t == '{' || t == ',') {
                if (t == '{') {
                    add_selector(selector, section);
                    break;
                }
                if (t == ',') {
                    add_selector(selector, section);
                    selector->i = 0;
                }
        }
            else {
                selector->text[selector->i] = t;
                selector->i++;
            }
        }
        
    }
}

void attr_getter(text* attr_name, text* attr_value, Section* section , bool *mode) {
    if (*mode != COMMAND_INPUT_MODE) {
        char t;
        bool insert = false;
        bool app_mode = false;
        attr_name->i = 0;
        attr_value->i = 0;
        while (t = getchar()) {
            if (t > 32) {
                if (t != ':' && insert == false) {
                    attr_name->text[attr_name->i] = t;
                    attr_name->i++;
                }
                if (t == ':') insert = true;
                if (t == ';') {
                    insert = false;
                    add_attr(attr_name, attr_value, section);
                    attr_name->i = 0;
                    attr_value->i = 0;
                }
                if (t == '}') {
                    break;
                }
            }
            if (t != ';' && t!= ':' && insert == true) {
                    attr_value->text[attr_value->i] = t;
                    attr_value->i++;
            }

        }
    }
    

}

void count_attr(text command, List_1lvl* first) {
    text n;
    n.i = 0;
    while (command.text[n.i] != ',') {
        n.text[n.i] = command.text[n.i];
        n.i++;
    }
    int count = 0;
    List_1lvl* current_lvl = first;
    while (current_lvl != nullptr) {
        for (int i = 0; i < T; i++) {
            Section* section = &(current_lvl->section[i]);
            if (section->first_a != nullptr) {
                ListAttr* attr = section->first_a;
                bool is = false;
                while (attr != nullptr) {
                    bool same = true;
                    text current_attr_name = attr->attr_name;
                    for (int k = 0; k < current_attr_name.i; k++) {
                        if (current_attr_name.text[k] != n.text[k]) {
                            same = false;
                            break;
                        }
                    }
                    if (same) is = true;
                    attr = attr->next;
                }
                if (is) count++;
                is = false;
            }
        }
        current_lvl = current_lvl->next;
    }
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == " << count << endl;

}


void last_E_print(text command, List_1lvl* first) {
    text z, n;
    z.i = 0;
    n.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int pom = z.i + 3;
    while (pom < command.i) {
        n.text[n.i] = command.text[pom];
        n.i++;
        pom++;
    }
    List_1lvl* current_1lvl = first;
    text final;
    final.i = 0;
    int count = 0;
    while (current_1lvl != nullptr) {
        for (int i = 0; i < T; i++) {
            Section* section = &(current_1lvl->section[i]);
            if (section->first_s != nullptr) {
                ListSelector* selector = section->first_s;
                ListAttr* attr = section->first_a;
                while (selector != nullptr) {
                    bool same_selector = true;
                    text current_selector = selector->selector;
                    for (int k = 0; k < current_selector.i; k++) {
                        if (current_selector.text[k] != z.text[k]) {
                            same_selector = false;
                            break;
                        }
                    }
                    if (same_selector) {
                        while (attr != nullptr) {
                            bool same_attr = true;
                            text current_attr_name = attr->attr_name;
                            text current_attr_value = attr->attr_value;
                            for (int k = 0; k < current_attr_name.i; k++) {
                            if (current_attr_name.text[k] != n.text[k]) {
                                same_attr = false;
                                break;
                                }
                            }
                            if (same_attr){
                            final = current_attr_value;
                            }
                        attr = attr->next;
                        }
                    }
                    selector = selector->next; 
                }
            }
        }
        current_1lvl = current_1lvl->next;
    }
    if (final.i != 0) {
        for (int k = 0; k < command.i; k++)
        {
            cout << command.text[k];
        }
        cout << " == ";
        for (int k = 0; k < final.i; k++)
        {
            cout << final.text[k];
        }
        cout << endl;
    }
}
void count_selectors(text command, List_1lvl* first) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int count = 0;
    List_1lvl* current_lvl = first;
    while (current_lvl != nullptr) {
        for (int i = 0; i < T; i++) {
            Section* section = &(current_lvl->section[i]);
            if (section->first_s != nullptr) {
                ListSelector* selector = section->first_s;
                while (selector != nullptr) {
                    bool same = true;
                    text current = selector->selector;
                    for (int k = 0; k < current.i; k++) {
                        if (current.text[k] != z.text[k]) {
                            same = false;
                            break;
                        }
                    }
                    if (same) {
                        count++;
                    }
                    selector = selector->next;
                }
            }
        }
        current_lvl = current_lvl->next;
    }
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == " << count << endl;
    
}

void count_selectors_in_section(text command, List_1lvl* first, int sections_num) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int i = texttoint(z);
    int count = 0;
    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i-1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    Section* current_section = &(current_lvl1->section[section_number]);
    if (current_section->first_a == nullptr) return;
    ListSelector* current_selector = current_section->first_s;
    while (current_selector != nullptr) {
        count++;
        current_selector = current_selector->next;
    }
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout <<" == "<< count << endl;
}

void count_attr_in_section(text command, List_1lvl* first, int sections_num) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int i = texttoint(z);
    int count = 0;
    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i - 1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    Section* current_section = &(current_lvl1->section[section_number]);
    if (current_section->first_a == nullptr) return;
    ListAttr* current_attr = current_section->first_a;
    while (current_attr != nullptr) {
        count++;
        current_attr = current_attr->next;
    }
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == " << count << endl;
}


void print_sections_number(List_1lvl* first) {
    int count = 0;
    List_1lvl* current = first;
    while (current != nullptr) {
        for (int i = 0; i < T; i++) {
            if (current->section[i].first_s != nullptr) {
                count++;
            }
        }
        current = current->next;
    }

    cout << "? == " << count << endl;
}

void print_attr_value(text command, List_1lvl* first) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int i = texttoint(z);
    int pom = z.i + 3;
    text y;
    y.i = 0;
    while (pom < command.i) {
        y.text[y.i] = command.text[pom];
        y.i++;
        pom++;
    }
    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i - 1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    Section* current_section = &(current_lvl1->section[section_number]);
    if (current_section == nullptr) return;
    ListAttr* current_attr = current_section->first_a;
    while (current_attr != nullptr) {
        bool same = true;
        text current = current_attr->attr_name;
        for (int k = 0; k < current.i; k++) {
            if (current.text[k] != y.text[k]){
                same = false;
                break;
            }
        }
        if (same) {
            for (int k = 0; k < command.i; k++)
            {
                cout << command.text[k];
            }
            cout << " == ";
            for (int k = 0; k < current_attr->attr_value.i; k++)
            {
                cout << current_attr->attr_value.text[k];
            }
            cout << endl;
            return;

        }
        else current_attr = current_attr->next;
    }


}

void print_selector(text command, List_1lvl* first) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int pom = z.i + 3;
    text y;
    y.i = 0;
    while (pom<command.i) {
        y.text[y.i] = command.text[pom];
        y.i++;
        pom++;
    }
    int i = texttoint(z);
    int j = texttoint(y);
    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i - 1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    Section* current_section = &(current_lvl1->section[section_number]);
    if (current_section == nullptr) return;
    ListSelector* current_selector = current_section->first_s;
    for (int k = 0; k < j-1; k++) {
        current_selector = current_selector->next;
        if (current_selector == nullptr) return;
    }
    if (current_selector == nullptr) return;
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == ";
    for (int k = 0; k < current_selector->selector.i; k++)
    {
        cout << current_selector->selector.text[k];
    }
    cout << endl;
}

void delete_all(text command, List_1lvl* first) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int i = texttoint(z);
    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i - 1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    for (int k = section_number; k < T; k++) {

        current_lvl1->section[k] = current_lvl1->section[k + 1];
        
        if (current_lvl1->section[k+1].first_s == nullptr) {
            current_lvl1->section[k].first_s = nullptr;
            break;
        }
    }
    current_lvl1->section[T - 1].first_s = nullptr;
    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == deleted";
    cout << endl;
}

void delete_specific(text command, List_1lvl* first) {
    text z;
    z.i = 0;
    while (command.text[z.i] != ',') {
        z.text[z.i] = command.text[z.i];
        z.i++;
    }
    int i = texttoint(z);
    int pom = z.i + 3;
    text y;
    y.i = 0;
    while (pom < command.i) {
        y.text[y.i] = command.text[pom];
        y.i++;
        pom++;
    }

    List_1lvl* current_lvl1 = first;
    int lvl1 = i / T;
    int section_number = i - 1 % T;
    for (int k = 0;k < lvl1; k++) {
        current_lvl1 = current_lvl1->next;
    }
    if (current_lvl1 == nullptr) return;
    Section* current_section = &(current_lvl1->section[section_number]);
    if (current_section == nullptr) return;
    ListAttr* current_attr = current_section->first_a;
    while (current_attr != nullptr) {
        //do oddzielnej funkcji
        bool same = true;
        text current = current_attr->attr_name;
        for (int k = 0; k < current.i; k++) {
            if (current.text[k] != y.text[k]) {
                same = false;
                break;
            }
        }
        if (same) {
            if (current_section->first_a == current_section->last_a) {
                delete_all(command, first);
            }
            else
            {
                if (current_section->first_a == current_attr) current_section->first_a = current_attr->next;
                while (current_attr != nullptr)
                    current_attr = current_attr->next;
            }
            return;
        }
    }

    for (int k = 0; k < command.i; k++)
    {
        cout << command.text[k];
    }
    cout << " == deleted";
    cout << endl;
}


void command_input(text* command) {
    char t;
    command->i = 0;
    while (t = getchar()) {
        if (t == EOF) return;
        if (t != '\n' && t != '\t' && t != '\v' && t != '\f' && t != '\r' && t<127) {
            command->text[command->i] = t;
            command->i++;
        }
        else if ((t == '\n') && command->i == 0) {
            continue;
        }
        else if (t == '\n') {
            return;
        }
    }
}
void command_handler(text* command,bool *mode, List_1lvl* first, List_1lvl* last, int sections_num) {
    bool mode_change = true;
    for (int i = 0; i < 4;i++) {
        if (command->text[i] != '*') mode_change = false;
    }
    if (mode_change) {
        *mode = CSS_INPUT_MODE;
    }
    else {
        if (command->i == 1 && command->text[0] == '?') print_sections_number(first);
        else {
            bool intig_1st = true;
            for (int i = 0; i < command->i; i++)
            {
                if ((command->text[i] < 48 || command->text[i]>57)&&command->text[i]!=',') intig_1st = false;
                if (command->text[i] == ',') {
                    if (command->text[i + 1] == 'S') { 
                        if (command->text[i + 3] == '?') {
                            if (intig_1st) count_selectors_in_section(*command, first, sections_num);
                            else count_selectors(*command, first);
                        }
                        else print_selector(*command, first);
                    }
                    if (command->text[i + 1] == 'A') {
                        if (command->text[i + 3] == '?') {
                            if (intig_1st) count_attr_in_section(*command, first, sections_num);
                            else count_attr(*command,first);
                        }
                        else print_attr_value(*command, first);
                    }
                    if (command->text[i + 1] == 'E') { last_E_print(*command, first); }
                    if (command->text[i + 1] == 'D') {
                        if (command->text[i + 3] == '*') {
                            delete_all(*command, first);
                        }
                        else delete_specific(*command, first);
                    }
                }
            }
        }
    }
}


int main() {
    List_1lvl* first = nullptr;
    List_1lvl* last = nullptr;
    bool mode = CSS_INPUT_MODE;
    int sections_num=0;
    text selektor, attr_value, attr_name, command;
    while (1) {
        if (mode == CSS_INPUT_MODE) {
            if (sections_num % T == 0) add_List_1lvl(first, last);
            selector_getter(&selektor, &mode, &last->section[sections_num % T]);
            attr_getter(&attr_name,&attr_value,&last->section[sections_num % T],&mode);
            if (mode == CSS_INPUT_MODE) { sections_num++; }
            
        }
        if (mode == COMMAND_INPUT_MODE) {
            command_input(&command);
            if (command.i == 0) return 0;
            command_handler(&command,&mode,first,last,sections_num);
        }
    }
    return 0;
}