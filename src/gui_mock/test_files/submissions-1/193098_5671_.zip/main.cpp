#include <iostream>
#include <cstdio>
#include <cstring>

#define MAX_LINE_LENGTH 1024
#define ARRAY_SIZE 10
#define T 8

using namespace std;

struct technical{
    char* output[ARRAY_SIZE]{};
    char* outputL[ARRAY_SIZE]{};
    char* outputR[2]{};
    char *deleted = new char[10];
    char *a = new char[3];
    char *b = new char[5];
    char *c = new char[5];
    char *d = new char[5];
    technical(){
        for(auto & i : output){i=nullptr;}
        for(auto & i : outputL){i=nullptr;}
        for(auto & i : outputR){i=nullptr;}
        strcpy(a,",");
        strcpy(b,",;{");
        strcpy(c,":;");
        strcpy(d,"{}");
        strcpy(deleted,"deleted");
    }

};

void splitString(char* str, char** output, char* divider);
void deleteArray(char **output);
void oneLineException(char* line, technical *t);
void removeStartingOrEndingSpaces(char* word);

struct declaration{
    char *attribute{};
    char *value{};
    declaration* next;

    declaration(){
        attribute=nullptr;
        value=nullptr;
        next=nullptr;
    }
    explicit declaration(char* attributeIn, char* valueIn){
        if(attribute == nullptr){
            delete attribute;
            attribute = new char[strlen(attributeIn)+1];
        }
        if(value == nullptr){
            delete value;
            value = new char[strlen(valueIn)+1];
        }
        strcpy(attribute,attributeIn);
        strcpy(value,valueIn);
        next= nullptr;
    }
};

struct selector {
    char *value{};
    selector* next;

    selector(){
        value= nullptr;
        next=nullptr;
    }
    explicit selector(char* valueIn){
        if(value == nullptr){
            delete value;
            value = new char[strlen(valueIn)+1];
        }
        strcpy(value,valueIn);
        next= nullptr;
    }
};

template <class L>
class List{
public:
    L* head;
    L* tail;

    List(){
        head = new L;
        tail = head;
    }
};

class section{
public:
    bool done;
    int selectorNumber;
    int declarationNumber;
    List<selector>* listS;
    List<declaration>* listD;

    section(){
        done=false;
        selectorNumber=0;
        declarationNumber=0;
        listS = new List<selector>;
        listD = new List<declaration>;
    }

    void setSelector(char* value) {
        if (listS->head->value != nullptr) {
            selector *tmp = new selector(value);
            listS->tail->next = tmp;
            listS->tail = tmp;
        }
        else {
            listS->head = new selector(value);
            listS->tail=listS->head;
        }
    }

    void setDeclaration(char* attribute, char* value){
        if(listD->head->value != nullptr) {
            declaration *tmp = new declaration(attribute, value);
            listD->tail->next = tmp;
            listD->tail = tmp;
        }
        else{
            listD->head = new declaration(attribute,value);
            listD->tail=listD->head;
        }
    }

    void setSelectorArray(char* values[]) {
        int i = 0;
        while (listS->head != nullptr && values[i] != nullptr) {
            removeStartingOrEndingSpaces(values[i]);
            setSelector(values[i]);
            selectorNumber++;
            i++;
        }
    }

    selector* getSelector(char *selectorVal, bool *found){
        selector* tmp = listS->head;
        *found = false;

        //Check if there are any selectors
        if(tmp->value == nullptr){
            *found=false;
            return tmp;
        }

        //Search for selector
        while(true){
            if(strcmp(tmp->value,selectorVal)==0) {
                *found=true;
                return tmp;
            }
            if(tmp->next==nullptr){
                *found=false;
                return tmp;
            }
            else tmp=tmp->next;
        }
        return tmp;
    }

    declaration* getAttribute(char *attributeVal, bool *found){
        declaration* tmp = listD->head;
        if(tmp!=nullptr) {
            while (true) {
                if (tmp->attribute != nullptr) {
                    if (strcmp((tmp->attribute), attributeVal) == 0) {
                        *found = true;
                        return tmp;
                    }
                }
                if (tmp->next == nullptr) {
                    *found = false;
                    return tmp;
                } else tmp = tmp->next;
            }
        }
        *found=false;
        return tmp;
    }

    declaration* getPrevAttribute(char* attributeVal, bool* found) {
        declaration* tmp = listD->head;

        while (tmp != nullptr) {
            if (tmp->next != nullptr) {
                if (strcmp(tmp->next->attribute, attributeVal) == 0) {
                    *found = true;
                    return tmp;
                }
            }
            if(tmp->next!=nullptr) tmp = tmp->next;
            else break;
        }
        *found = false;
        return nullptr;
    }

    char* getSelectorByNumber(int number, bool *found){
        int i=1;
        *found=false;
        selector* tmp = listS->head;

        //Reaches max end
        while(tmp->next != nullptr && i < number){
            tmp = tmp->next;
            i++;
        }

        //Check if result is valid
        if(tmp->next == nullptr && i< number){
            *found=false;
            return tmp->value;
        }

        if(tmp->value!=nullptr){

            //If ok
            *found=true;
            return tmp->value;
        }
        *found=false;
        return tmp->value;
    }

    char* getValueByAttribute(char *attribute, bool *error){
        declaration* tmp = getAttribute(attribute, error);
        return tmp->value;
    }

    void removeSelectors(){
        selector* curr = listS->head;
        while (curr != nullptr) {
            selector* next = curr->next;
            delete[] curr->value; // free memory allocated for value
            delete curr; // delete selector object
            curr = next;
        }
        listS->head = nullptr;
        listS->tail = nullptr;
    }

    void removeDeclarations(){
        if (listD && listD->head) { // check that listD and its head are not null
            declaration *curr = listD->head;
            while (curr) {
                declaration *next = curr->next;
                delete[] curr->attribute; // free memory allocated for attribute
                delete[] curr->value; // free memory allocated for value
                delete curr; // delete declaration object
                curr = next;
            }
            listD->head = nullptr; // set head to null
            listD->tail = nullptr; // set tail to null
        }
    }
};

struct bigNode{
    int nodeOccupancy;
    section* data[T]{};
    bigNode* next;
    bigNode* prev;

    explicit bigNode(bigNode* prevPtr){
        for(int i=0;i<T;i++){
            data[i] = new section();
        }
        prev=prevPtr;
        next=nullptr;
        nodeOccupancy=0;
    }
};

class bigList{
public:
    int sectionNumber;
    bigNode* head;
    bigNode* tail;

    bigList() {
        bigNode* tmp = new bigNode(nullptr);
        sectionNumber=0;
        head=tmp;
        tail=tmp;
    }
    ~bigList()= default;

    void SELECTOR(char* line, technical* t, int *status){
        setBigNodeIfNecessary();
        removeStartingOrEndingSpaces(line);
        int i=0;

        //Gets last char of line
        while(line[i+1]!='\0') i++;

        //One line exception
        if(line[i]=='}'){
            oneLineException(line, t);
            getFirstFreeSection()->setSelectorArray(t->outputL);
            DECLARATION(t->outputR);
            deleteArray(t->outputL);
            //deleteArray(t->outputR);
            closeSection(status);
        }

            //Normal selectors
        else {
            if(line[i]=='{') *status=2;
            splitString(line,t->output,t->b);
            getFirstFreeSection()->setSelectorArray(t->output);
        }

        //Deletes output no matter the case
        deleteArray(t->output);
    }

    void DECLARATION(char** array){
        setBigNodeIfNecessary();
        bool found = false;

        section* tmp = getFirstFreeSection();
        declaration* dcl;
        dcl = tmp->getAttribute(array[0], &found);

        //No repeats
        if(!found){
            removeStartingOrEndingSpaces(array[0]);
            removeStartingOrEndingSpaces(array[1]);
            tmp->setDeclaration(array[0],array[1]);
            tmp->declarationNumber++;
        }

            //Repeats found
        else{
            if(dcl->value != nullptr)

                //Update value
                delete dcl->value;
            dcl->value = new char[strlen(array[1])+1];
            strcpy(dcl->value,array[1]);
        }
    }

    section* getFirstFreeSection() const{
        for(int i=0;i<T;i++)
        {
            if(!tail->data[i]->done) {
                return tail->data[i];
            }
        }
        return tail->data[0]; //DANGER
    }

    void setBigNodeIfNecessary(){
        if(tail->nodeOccupancy==T) {
            auto *newSection = new bigNode(tail);
            tail->next = newSection;
            tail = newSection; //Why it's never used?
        }
    }

    void closeSection(int* status) {
        *status = 1;
        if(getFirstFreeSection()->declarationNumber==0) cout << "//DELETE SECTION" << endl;
        getFirstFreeSection()->done=true;
        sectionNumber++;
        tail->nodeOccupancy++;
    }

    section* getSectionByNumber(int sctNumber, bool* found) const{
        bigNode* tmp = head;
        *found=false;
        while(true) {
            if (tmp->nodeOccupancy < sctNumber) {
                sctNumber -= tmp->nodeOccupancy;
                if (tmp->next != nullptr) {
                    tmp = tmp->next;
                } else {
                    return tmp->data[0];
                }
            }
            else{
                int i = 0;
                int count = 0;
                while (true) {
                    if (tmp->data[i]->done) {
                        count++;
                        if (count == sctNumber) {
                            *found = true;
                            return tmp->data[i];
                        }
                    }
                    i++;
                    if(i>T) break;
                }
                *found = false;
                return nullptr;
            }
        }
        return tmp->data[0];
    }

    bigNode* getBigNodeBySectionNumber(int sctNumber, bool* found) const{
        bigNode* tmp = head;
        *found=false;
        while(true) {
            if (tmp->nodeOccupancy < sctNumber) {
                sctNumber -= tmp->nodeOccupancy;
                if (tmp->next != nullptr) {
                    tmp = tmp->next;
                } else {
                    return tmp;
                }
            }
            else{
                int i = 0;
                int count = 0;
                while (true) {
                    if (tmp->data[i]->done) {
                        count++;
                        if (count == sctNumber) {
                            *found = true;
                            return tmp;
                        }
                    }
                    i++;
                    if(i>T) break;
                }
                *found = false;
                return nullptr;
            }
        }
        return tmp;
    }

    int getAttributeOccurences(char* attribute) const{
        int occurences=0;
        bool found=false;
        bigNode* tmp = head;
        while(true){
            for(int i=0;i<T;i++){
                if(tmp->data[i]->done)
                {
                    tmp->data[i]->getAttribute(attribute,&found);
                    if(found) occurences++;
                }
            }
            if(tmp->next!=nullptr) tmp=tmp->next;
            else return occurences;
        }
    }

    int getSelectorOccurences(char* selector) const{
        int occurences=0;
        bool found = false;
        bigNode* tmp = head;
        while(true){
            for(int i=0;i<T;i++){
                if(tmp->data[i]->done) {
                    tmp->data[i]->getSelector(selector, &found);
                    if (found) occurences++;
                }
            }
            if(tmp->next!=nullptr) tmp=tmp->next;
            else return occurences;
        }
    }

    char* magicCommandE(char* selectorVal, char* attributeVal, bool* found){
        bigNode* tmp = tail;
        char* error = nullptr;
        while(true){
            for(int i=T-1;i>=0;i--){
                if(tmp->data[i]->done){
                    tmp->data[i]->getSelector(selectorVal,found);
                    if(*found){
                        declaration* dec = tmp->data[i]->getAttribute(attributeVal,found);
                        return dec->value;
                    }
                }
            }
            if(tmp->prev!=nullptr) tmp = tmp->prev;
            else{
                *found = false;
                return error;
            }
        }
        return error;
    }

    void removeSection(section*& tmp, int sctNumber, bool* found){
        /*tmp->removeDeclarations();
        tmp->removeSelectors();*/

        //Update values
        getBigNodeBySectionNumber(sctNumber,found)->nodeOccupancy--;
        sectionNumber--;

        tmp->done=false;
        tmp->declarationNumber=0;
        tmp->selectorNumber=0;

        delete tmp->listD;
        delete tmp->listS;
        tmp->listS = new List<selector>;
        tmp->listD = new List<declaration>;
    }

    void removeDeclaration(int sctNumber, char* attName, bool* found){
        bool foundPrev;

        //Necessary pointers
        section* tmp = getSectionByNumber(sctNumber, found);
        declaration* attPrev = tmp->getPrevAttribute(attName,&foundPrev);
        declaration* att     = tmp->getAttribute(attName,found);
        declaration* attNext = att->next;

        //Delete attribute
        if(*found) {
            delete att;
            att = new declaration();

            //Pointers management
            if (foundPrev) attPrev->next = attNext;
            else if(attNext!=nullptr) tmp->listD->head=attNext;

            //Updates declarationNumber
            if (tmp->declarationNumber == 1) removeSection(tmp, sctNumber, found);
            else tmp->declarationNumber--;
        }
    }
};

void splitString(char* str, char** output, char* divider) {
    char* strCopy = new char[strlen(str) + 1];
    char* ptr = strCopy;
    while (*str) {
        if (*str != '\t' && *str != '\n') {
            *ptr++ = *str;
        }
        str++;
    }
    *ptr = '\0';

    int arrayNumber = 0;
    char* word;
    word = strtok(strCopy, divider);
    while (word != nullptr) {
        output[arrayNumber] = new char[strlen(word) + 1];
        strcpy(output[arrayNumber++], word);
        word = strtok(nullptr, divider);
    }
    delete[] strCopy;
}

void sanitizeInput(char* line){
    bool isWord=false;

    //Remove leading tab character
    if (line[0] == '\t') {
        for (int i = 0; line[i] != '\0'; i++) {
            line[i] = line[i+1];
        }
    }

    //Replace newline characters
    for (int i = 0; line[i] != '\0'; i++) {
        if (line[i] == '\n') line[i] = '\0';
        if (line[i] < ' ' && line[i] != '\0') line[i] = ' ';
        if (line[i] > ' ') isWord=true;
    }

    //If line contains only spaces, white signs etc. the line is removed;
    if(!isWord) line[0] = '\0';
}

void removeStartingOrEndingSpaces(char* word) {

    //Basic info about word
    int len = strlen(word);
    int end = len - 1;
    int start = 0;

    // Find the index of the first non-whitespace character
    while (start < len && word[start] <= 32 && word[start]!='\0') {
        start++;
    }

    // Shift all characters to the left by the i
    for (int i = 0; i < len - start; i++) {
        word[i] = word[start + i];
    }

    //Ends word with \0
    word[len - start] = '\0';

    //Back
    while(word[end] == '\t' || word[end] == ' '){
        word[end]='\0';
        if(end>0) end--;
        else break;
    }
}

void deleteArray(char **output){
    if(output != nullptr){
        for (int i = 0; i < ARRAY_SIZE; i++) {
            if(output[i] != nullptr){
                delete[] output[i];
                output[i] = nullptr;
            }
        }
    }
}

bool isItNumber(const char* value){
    if(value[0]>='0' && value[0]<='9') return true;
    else return false;
}

int charToNumberConvert(char* value) {
    int result = 0;

    while (*value != '\0') {
        int digit = *value - '0';

        if (digit >= 0 && digit <= 9) {
            result = result * 10 + digit;
        } else {
            return 0;
        }

        value++;
    }

    return result;
}

void printVal(char* line, char* value){
    cout << line << " ==";
    if(value[0]!=' ') cout << " ";
    cout << value << endl;
}

void printNum(char* line, int number){
    cout << line << " == " << number << endl;
}

void oneLineException(char* line, technical *t){
    splitString(line,t->output,t->d);
    splitString(t->output[0],t->outputL,t->b);
    splitString(t->output[1],t->outputR,t->c);
}

int main(){
    bigList CSS;

    bool cssActive=true, found=false;
    char line[MAX_LINE_LENGTH];
    technical t;

    int status=1;   // 1-looking for selectors
    // 2-looking for declarations

    while (fgets(line, MAX_LINE_LENGTH,stdin) != nullptr) {
        sanitizeInput(line);
        if (strlen(line) > 0) {
            if (cssActive) {
                if (strcmp(line, "????") == 0) {
                    cssActive = false;
                    continue;
                }
                switch (status) {
                    case 1:
                        CSS.SELECTOR(line,&t,&status);
                        break;
                    case 2:
                        splitString(line, t.output, t.c);
                        int i=0;
                        while(t.output[i]!= nullptr) {
                            removeStartingOrEndingSpaces(t.output[i]);
                            i++;
                        }
                        if (strcmp(t.output[0], "}") == 0) CSS.closeSection(&status);
                        else CSS.DECLARATION(t.output);

                        deleteArray(t.output);
                        break;
                }
            }
            else {
                found = false;
                if (strcmp(line, "****") == 0) {
                    cssActive = true;
                    status = 1;
                    continue;
                }

                splitString(line, t.output, t.a);

                //Command 1
                if (strcmp(t.output[0], "?") == 0) {
                    printNum(line, CSS.sectionNumber);
                }

                    //General commands with number on the front (2/3/4/5/.../9/10)
                else if (isItNumber(t.output[0])) {
                    int number = charToNumberConvert(t.output[0]);
                    section *tmp = CSS.getSectionByNumber(number, &found);

                    if(found) {
                        //Commands 2 & 3
                        if (strcmp(t.output[2], "?") == 0) {
                            //Command 2
                            if (strcmp(t.output[1], "S") == 0) { printNum(line, tmp->selectorNumber); }

                            //Command 3
                            if (strcmp(t.output[1], "A") == 0) { printNum(line, tmp->declarationNumber); }
                        }

                            //Command 4
                        else if (isItNumber(t.output[2]) && strcmp(t.output[1], "S") == 0) {
                            number = charToNumberConvert(t.output[2]);
                            char *printable = tmp->getSelectorByNumber(number, &found);
                            if (found) printVal(line, printable);
                        }

                            //Command 5
                        else if (!isItNumber(t.output[2]) && strcmp(t.output[1], "A") == 0) {
                            char *printable = tmp->getValueByAttribute(t.output[2], &found);
                            if (found) printVal(line, printable);
                        }

                            //Command 9
                        else if (strcmp(t.output[2], "*") == 0 && strcmp(t.output[1], "D") == 0){
                            CSS.removeSection(tmp,number,&found);
                            if(found) printVal(line,t.deleted);
                        }

                            //Command 10
                        else if (!isItNumber(t.output[2]) && strcmp(t.output[1], "D")==0){
                            CSS.removeDeclaration(number,t.output[2],&found);
                            if(found) printVal(line,t.deleted);
                        }
                    }
                }

                    //General commands with name on the front (6/7/8)
                else {

                    //Command 6 & 7
                    if (strcmp(t.output[2], "?") == 0) {
                        int printable = 0;

                        //Command 6
                        if (strcmp(t.output[1], "A") == 0) {
                            printable = CSS.getAttributeOccurences(t.output[0]);
                        }

                        //Command 7
                        if (strcmp(t.output[1], "S") == 0) {
                            printable = CSS.getSelectorOccurences(t.output[0]);
                        }

                        if (!found) printNum(line, printable);
                    }

                        //Command 8
                    else if(strcmp(t.output[1],"E")==0 && !isItNumber(t.output[2])){
                        char* printable = CSS.magicCommandE(t.output[0],t.output[2],&found);
                        if(found) {printVal(line,printable);}
                    }
                }
                deleteArray(t.output);
            }
        }
    }
    deleteArray(t.output);
    return 0;
}