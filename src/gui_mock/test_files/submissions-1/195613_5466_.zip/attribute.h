#pragma once

class Attribute {
private:
    char* left = nullptr;
    char* right = nullptr;
public:
    Attribute(char* l = nullptr, char* r = nullptr)
    {
        left = std::move(l);
        right = std::move(r);
    }

    char* getLeft()
    {
        return left;
    }
    char* getRight()
    {
        return right;
    }
};