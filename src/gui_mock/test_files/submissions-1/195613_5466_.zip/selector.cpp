#include "selector.h"
#include <iostream>
using namespace std;
/*
void SelectorNode::insertFront (SelectorNode** head, string newName) {

	SelectorNode* newNode = new SelectorNode();
	newNode->name = newName;
	newNode->next = *head;
	*head = newNode;
}

void SelectorNode::insertEnd(SelectorNode** head, string newName) {

	SelectorNode* newNode = new SelectorNode();
	newNode->name = newName;
	newNode->next = NULL;

	if (*head == NULL) {
		*head = newNode;
		return;
	}

	SelectorNode* last = *head;
	while(last->next != NULL) {
		last = last->next;
	}
	last->next = newNode;
}

void SelectorNode::insertAfter(SelectorNode* previous, string newName) {
	if (previous == NULL) {
		return;
	}
	SelectorNode* newNode = new SelectorNode();
	newNode->name = newName;
	newNode->next = previous->next;
	previous->next = newNode;
}*/

SelectorNode* SelectorNode::insertNext(SelectorNode* newSel)
{
	if (this->next == nullptr)
	{
		this->next = newSel;
		return newSel;
	}
	else {
		return this->next->insertNext(newSel);
	}
}