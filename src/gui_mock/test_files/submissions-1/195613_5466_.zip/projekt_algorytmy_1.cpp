#include <iostream>
#include "selector.h"
#include "section.h"
#include <string.h>
#include <ctype.h>
#include "functions.h"

using namespace std;

const int MAX_HEIGHT = 100;
const int MAX_LENGTH = 100;

void convertBlock(Section* section, char user_input[MAX_HEIGHT][MAX_LENGTH], int max_lines, int& index, int x)
{
	char* shift = &(user_input[index][x]);
	Block* currentBlock = new Block();
	for (; index < max_lines;)
	{
		// divide the line into smaller fragments
		char* divider = (char*)strchr(shift, (int)':');
		char* semicolon = (char*)strchr(shift, (int)';');
		// no divider in current line (can be end of the block or just the begining)
		if (divider == nullptr)
		{
			// check whether the current line contains '}'
			if (strchr(shift, '}') != nullptr)
			{
				index++;
				break;
			}
			{
				++index;
				shift = user_input[index];
				continue;
			}
		}

		char* left = new char[48];
		char* right = new char[48];

		memset(left, 0, 48);
		memset(right, 0, 48);

		// copy the contents of user_input from the beggening to the ':'
		// TODO: fix it!

		my_memcpy(left,
			shift, divider);
		my_memcpy(right,
			divider + 1, semicolon);

		// remove all the whitespaces
		strip(left);
		strip(right);
		Attribute* att = new Attribute(left, right);
		currentBlock->addAttribute(att);

		if (divider != nullptr)
		{
			shift = semicolon + 1;
		}
	}
	section->addBlock(currentBlock);
}

void convertCSS(Section* nextSection, char user_input[MAX_HEIGHT][MAX_LENGTH], int max_lines)
{

	// until '{' not found add selectors to the section
	char* selector = new char[20];
	memset(selector, '\0', 20);

	for (int i = 0; i < max_lines; ++i)
	{
		// go through all the lines (first iterator in the user_input array) in code
		for (int x = 0; x < MAX_LENGTH; ++x)
		{
			bool end_of_the_line = false;
			switch (user_input[i][x])
			{
			case '\0':
			case -52:
			case ' ':
				// do nothing
				break;
			case '}':
			case '\n':
				end_of_the_line = true;
				break;
			case '{':
			{
				// new block
				nextSection->addSelector(selector);
				selector = new char[20];
				memset(selector, '\0', 20);
				// execute block-building function
				convertBlock(nextSection, user_input, max_lines, i, x + 1);
				i--;
				end_of_the_line = true;
				// add attributes until '}' found
				// create a new section and repeat
				Section* newSection = new Section();
				nextSection->setNext(newSection);
				newSection->setBefore(nextSection);
				nextSection = newSection;
			}
			break;
			case ',':
				// new selector
				nextSection->addSelector(selector);
				selector = new char[20];
				memset(selector, '\0', 20);
				break;
			default:
				// add character to the current selector
				appendCharToCString(selector, user_input[i][x]);
				break;
			}
			if (end_of_the_line)
				break;
		}
	}

	// remove the last section (= nullptr)
	nextSection = nextSection->before();
	delete nextSection->next();
	nextSection->setNext(nullptr);
}

void executeCommands(Section** s, char* command_input)
{
	char cmd[100];
	if (command_input != nullptr)
		sprintf(cmd, "%s", command_input);
	char* first = strtok(command_input, ",");
	char* second = strtok(NULL, ",");
	char* third = strtok(NULL, ",");
	// if wrong command
	if ((first == nullptr || second == nullptr || third == nullptr) && strcmp(cmd, "?") != 0)
		return;
	if (strcmp(cmd, "?") == 0)
	{
		print_ret(cmd, q(*s));
		return;
	}
	switch (second[0])
	{
	case 'S':
	{
		if (atoi(first) > 0)
		{
			if (strcmp(third, "?") == 0) // i,S,?
				print_ret(cmd, isq(*s, atoi(first)));
			else if (atoi(third) > 0) // i,S,j
				print_ret(cmd, isj(*s, atoi(first), atoi(third)));
		}
		else
		{
			// z,S,?
			if (strcmp(third, "?") == 0)
				print_ret(cmd, zsq(*s, first));
		}
	}
	break;
	case 'A':
	{
		if (atoi(first) > 0)
		{
			if (strcmp(third, "?") == 0) // i,A,?
			{
				print_ret(cmd, iaq(*s, atoi(first)));
			}
			else
			{ // i,A,n
				print_ret(cmd, ian(*s, atoi(first), third));
			}
		}
		else
		{
			// n,A,?
			if (strcmp(third, "?") == 0)
				print_ret(cmd, naq(*s, first));
		}
	}
	break;
	case 'E':
	{
		// z,E,n
		print_ret(cmd, zen(*s, third, first));
	}
	break;
	case 'D':
	{
		if (strcmp(third, "*") == 0 && atoi(first) > 0)
		{
			// i,D,*
			print_ret(cmd, idstar(s, atoi(first)));
		}
		else
		{
			// i,D,n
			if (atoi(first) > 0)
				print_ret(cmd, idn(s, atoi(first), third));
		}
	}
	break;
	}
}

int main()
{
	char user_input[MAX_HEIGHT][MAX_LENGTH];
	char command_input[MAX_LENGTH];

	// cin, etc.
	unsigned int i = 0;
	while (true)
	{
		for (; i < MAX_HEIGHT; ++i)
		{
			char line[MAX_LENGTH];
			cin.getline(line, MAX_LENGTH);
			// cin >> user_input[i];
			// change last character in user_input from \0
			// TODO: make it work
			if (strcmp(line, "????") == 0)
			{
				break;
			}
			sprintf(user_input[i], "%s", line);
			// catch ????
			// break;
		}

		// convert the css code to data structures
		Section* section = new Section();
		convertCSS(section, user_input, i);

		// enter commands
		while (true)
		{
			cin.getline(command_input, MAX_LENGTH);
			// handle the command

			if (strcmp(command_input, "****") == 0)
				break;
			executeCommands(&section, command_input);
		}
		// catch ****
		// compile the commands
	}
}
