#pragma once
#include <iostream>

using namespace std;

class SelectorNode {
public:
	char* name;
	SelectorNode* next = nullptr;

	SelectorNode(char* n)
	{
		this->name = std::move(n);
	}

	void print_list() {
		print();
		if (this->next != nullptr)
		{
			this->next->print_list();
		}
	}

	void print() {
		cout << this->name;
	}

	SelectorNode* insertNext(SelectorNode*);
};