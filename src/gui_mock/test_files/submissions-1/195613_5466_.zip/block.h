#pragma once
#include "attribute.h"
#include <string.h>

#define T 8

class Block
{
private:
    Attribute* attributes;
    size_t length;

public:
    Block()
    {
        attributes = new Attribute[T];
        length = 0;
    }

    void addAttribute(Attribute* attribute)
    {
        // increase the size of the attributes array if size of the array is greater than T
        if (++length > T)
        {
            // make a copy of an array and increment the length
            Attribute* cpy = new Attribute[length];
            for (int i = 0; i < length - 1; ++i)
            {
                cpy[i] = attributes[i];
            }
            // check whether it causes SEGFAULT
            delete[] attributes;
            attributes = cpy;
        }
        attributes[length - 1] = *attribute;
    }

    bool removeAttribute(int i)
    {
        --i;
        if (i < 0 || i >= length)
        {
            return false; // index out of bounds
        }

        for (int j = i; j < length - 1; j++)
        {
            attributes[j] = attributes[j + 1];
        }

        length--;

        return true;
    }

    size_t getLength() const
    {
        return length;
    }

    Attribute* getAttribute(int i)
    {
        if (--i < length && i >= 0)
        {
            return &(attributes[i]);
        }
        return nullptr;
    }

    Attribute* getAttributeByName(char* name)
    {
        for (int i = 0; i < length; i++)
        {
            if (strcmp(attributes[i].getLeft(), name) == 0)
            {
                return &(attributes[i]);
            }
        }
        return nullptr;
    }
};