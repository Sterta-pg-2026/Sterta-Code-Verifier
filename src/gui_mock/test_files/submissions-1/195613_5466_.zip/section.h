#pragma once
#include "block.h"
#include "selector.h"

class Section
{
private:
    Section* n = nullptr;
    Section* b = nullptr;
    Block* block = nullptr;
    SelectorNode* parentSelector = nullptr;
    int selectors_count = 0;

public:
    Section()
    {
    }
    Section(Section* next, Section* before);

    Section* next()
    {
        return n;
    }
    Section* before()
    {
        return b;
    }

    void setNext(Section* sec)
    {
        this->n = sec;
    }
    void setBefore(Section* sec)
    {
        this->b = sec;
    }

    SelectorNode* addSelector(char* selector)
    {
        SelectorNode* newSel = new SelectorNode(selector);
        selectors_count++;
        if (parentSelector == nullptr)
        {
            parentSelector = newSel;
            return parentSelector;
        }
        else
        {
            return parentSelector->insertNext(newSel);
        }
    }

    /* get the selector at index */
    SelectorNode* getSelector(int index)
    {
        SelectorNode* currentSelector = parentSelector;
        for (int i = 1; i < index; ++i)
        {
            currentSelector = currentSelector->next;
        }
        return currentSelector;
    }

    void addBlock(Block* b)
    {
        block = b;
    }

    size_t getNumberOfAttributes()
    {
        return block->getLength();
    }

    size_t getNumberOfSelectors()
    {
        return selectors_count;
    }

    Section* getIndex(int index)
    {
        Section* ret = this;
        for (int i = 1; i < index && ret != nullptr; ++i)
        {
            ret = ret->next();
            if (ret == nullptr)
                return nullptr;
        }
        return ret;
    }

    Block* getBlock() {
        return block;
    }
};