#pragma once
#include <string.h>
#include <iostream>
#include <stdio.h>

/*void* memset(void* ptr, int value, size_t num) {
    unsigned char* p = static_cast<unsigned char*>(ptr);

    for (size_t i = 0; i < num; i++) {
        p[i] = static_cast<unsigned char>(value);
    }

    return ptr;
}
*/

void strip(char* str)
{
    // Remove leading whitespace
    char* start = str;
    while (*start != '\0' && isspace(*start))
    {
        start++;
    }

    // Remove trailing whitespace
    size_t len = strlen(str);
    char* end = start + len - 1;
    while (end != start && isspace(*end))
    {
        end--;
    }
    *(end + 1) = '\0';

    // Shift stripped string to the start of the input buffer
    memmove(str, start, strlen(start) + 1);
}

/*char* strchr(char* str, char a)
{
    char* ptr = str;
    for (; *ptr != a && *ptr != '\0'; ++ptr);
    if (*ptr == '\0')
        return nullptr;
    else
        return ptr;
}
*/
int nr_of_sections(Section* parentSection)
{
    int i = 1;
    Section* pointer = parentSection;
    for (; pointer->next() != nullptr; ++i)
    {
        pointer = pointer->next();
    }
    return i;
}

int nr_of_sels(int nr_of_sec, Section* parentSection)
{
    Section* pointer = parentSection;
    for (int i = 0; i < nr_of_sec && pointer->next() != nullptr; i++)
    {
        pointer = pointer->next();
    }
    return pointer->getNumberOfSelectors();
}
void my_memcpy(char* dst, char* beg, char* end)
{
    for (; beg != end; ++beg)
    {
        *dst = *beg;
        ++dst;
    }
}

void appendCharToCString(char* str, char ch)
{
    int len = strlen(str);
    str[len] = ch;
    str[len + 1] = '\0';
}

char* q(Section* s)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    int count = 1;
    Section* ptr = s;
    while (ptr->next() != nullptr)
    {
        count++;
        ptr = ptr->next();
    }
    sprintf(str, "%d", count);
    return str;
}

// i,S,?
char* isq(Section* s, int i)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    Section* section_number = s->getIndex(i);
    if (section_number != nullptr)
    {
        sprintf(str, "%d", section_number->getNumberOfSelectors());
    }
    return str;
}

char* iaq(Section* s, int i)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    Section* section_number = s->getIndex(i);
    if (section_number != nullptr)
    {
        sprintf(str, "%d", section_number->getNumberOfAttributes());
        return str;
    }
    return nullptr;
}

char* isj(Section* s, int i, int j)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    Section* section_number = s->getIndex(i);
    if (section_number != nullptr && j <= s->getNumberOfSelectors())
    {
        SelectorNode* selector = s->getSelector(j);
        if (selector != nullptr)
        {
            return selector->name;
        }
    }
    return nullptr;
}

// i,A,n
char* ian(Section* s, int i, char* n)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    Section* section_number = s->getIndex(i);
    if (section_number != nullptr)
    {
        Attribute* attribute_number = (section_number->getBlock() != nullptr)
            ? (section_number->getBlock()->getAttributeByName(n))
            : nullptr;
        if (attribute_number != nullptr)
        {
            return attribute_number->getRight();
        }
    }
    return nullptr;
}

// n,A,q
char* naq(Section* s, char* n)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    int count = 0;
    Section* current = s;
    while (current != nullptr)
    {
        Block* block = current->getBlock();
        if (block != nullptr)
        {
            int duplicates = -1;
            for (int i = 1; i <= block->getLength(); i++)
            {
                Attribute* attribute = block->getAttribute(i);
                if (attribute != nullptr && strcmp(attribute->getLeft(), n) == 0)
                {
                    duplicates++;
                    if (duplicates > 0)
                    {
                        block->removeAttribute(i);
                        duplicates = -1;
                        i = 0;
                    }
                }
            }
            count += (duplicates + 1);
        }
        current = current->next();
    }
    sprintf(str, "%d", count);
    return str;
}

char* zsq(Section* s, char* z)
{
    char* str = new char[50];
    memset((void*)str, 0, 50);
    int count = 0;
    Section* currentSection = s;
    while (currentSection != nullptr)
    {
        SelectorNode* currentSelectorNode = currentSection->getSelector(1);
        for (int i = 1; i <= currentSection->getNumberOfSelectors(); i++)
        {
            if (strcmp(currentSelectorNode->name, z) == 0)
            {
                count++;
            }
            currentSelectorNode = currentSelectorNode->next;
        }
        currentSection = currentSection->next();
    }
    sprintf(str, "%d", count);
    return str;
}

char* zen(Section* s, char* n, char* z)
{
    Section* currentSection = s;
    while (currentSection->next() != nullptr)
    {
        currentSection = currentSection->next();
    }

    while (currentSection != nullptr)
    {
        SelectorNode* selector = currentSection->getSelector(1);
        while (selector != nullptr)
        {
            if (strcmp(selector->name, z) == 0)
            {
                Block* block = currentSection->getBlock();
                if (block != nullptr)
                {
                    Attribute* a = block->getAttributeByName(n);
                    if (a != nullptr)
                    {
                        return a->getRight();
                    }
                }
                else
                {
                    break;
                }
            }
            selector = selector->next;
        }
        currentSection = currentSection->before();
    }

    return nullptr;
}

char* idstar(Section** s, int i)
{
    char* ret = new char[11];
    memset((void*)ret, 0, 11);
    sprintf(ret, "%s", "");
    if (*s == nullptr)
    {
        return ret;
    }
    if (i == 1)
    {
        Section* temp = *s;
        *s = (*s)->next();
        delete temp;
        sprintf(ret, "%s", "deleted");
        return ret;
    }
    Section* current = *s;
    Section* prev = nullptr;
    int count = 1;
    while (current != nullptr && count != i)
    {
        prev = current;
        current = current->next();
        count++;
    }

    // If section not found, return false
    if (current == nullptr)
    {
        return ret;
    }

    // Remove the section
    prev->setNext(current->next());
    delete current;

    sprintf(ret, "%s", "deleted");
    return ret;
}

char* idn(Section** s, int i, char* n)
{
    char* ret = new char[11];
    memset((void*)ret, 0, 11);
    sprintf(ret, "%s", "");
    Section* current = (*s)->getIndex(i);
    if (current == nullptr) {
        return ret;
    }

    Block* block = current->getBlock();
    if (block == nullptr)
        return ret;
    for (int att = 1; att <= block->getLength(); ++att)
    {
        if (strcmp(block->getAttribute(att)->getLeft(), n) == 0)
        {
            block->removeAttribute(att);
            if (block->getLength() == 0)
                idstar(s, i);
            sprintf(ret, "%s", "deleted");
            return ret;
        }
    }
    return ret;
}

void print_ret(const char* command, char* r)
{
    if (r == nullptr)
        return;
    std::cout << *command << " == " << *r << std::endl;
}