#include <iostream>
#include <cstdlib>
#include <new>
#include <iomanip>
#define T 8
using namespace std;
struct komendy_t
{
	char* wynik;
	char* komendy;
	int len_wynik;
	int len_komendy;
	komendy_t* poprzedni;
	komendy_t* nastepny;
	komendy_t()
	{
		this->wynik = new char[100] {0};
		this->komendy = new char[25] {0};
		this->len_wynik = 100;
		this->len_komendy = 25;
		this->poprzedni = NULL;
		this->nastepny = NULL;
	}
	~komendy_t() {}
};
struct attr_t
{
	char* atrybut;
	int len_atrybut;
	attr_t* poprzedni;
	attr_t* nastepny;
	attr_t()
	{
		this->atrybut = new char[25] {0};
		this->len_atrybut = 25;
		this->poprzedni = NULL;
		this->nastepny = NULL;
	}
	~attr_t() {}
};
struct lista_t
{
	char* selektory;
	int len_selektory;
	attr_t* wsk_attr;
	attr_t* wsk_attr_kon;
	lista_t* poprzedni;
	lista_t* nastepny;
	lista_t()
	{
		this->selektory = new char[25] {0};
		this->len_selektory = 25;
		this->wsk_attr = new attr_t();
		this->wsk_attr_kon = this->wsk_attr;
		this->poprzedni = NULL;
		this->nastepny = NULL;
	}
	~lista_t() {}
};
struct koniec_t
{
	lista_t* wskkon;
	koniec_t() {}
	~koniec_t() {}
};
koniec_t* global = new koniec_t();
lista_t* global1 = new lista_t();
lista_t* global2 = new lista_t();
attr_t* global3 = new attr_t();
attr_t* global4 = new attr_t();
int global5 = 0;
int global6 = 0;
int global7 = 0;
lista_t* dodajNaKoniec(lista_t* wsk, lista_t* wezel);
attr_t* dodajNaKoniecAttr(attr_t* wsk, attr_t* wezel);
komendy_t* dodajNaKoniecKom(komendy_t* wsk, komendy_t* wezel);
lista_t* usunWezel(lista_t* wsk, lista_t* wskkon);
void usunWezelAttr(attr_t* wsk, lista_t* lokalny);
void procesor();
void css(koniec_t* koniec, char zn);
void wczytajSelektory(lista_t* wezel, char zn);
void wczytajBlok(lista_t* wezel);
bool czyJuzBylo(attr_t* wsk, attr_t* wezel);
void dynalokacja(char* tab, int* len);
komendy_t* komendy(komendy_t* kompocz, komendy_t* komkon, lista_t* wskpocz, koniec_t* koniec);
char* komenda1(lista_t* wskpocz);
char* komendaS(lista_t);
char* komendaiSp(int nr, lista_t* wskpocz);
char* komendazSp(komendy_t* komenda, lista_t* wskpocz);
char* komendaiSj(int nr_bloku, int nr_selektora, lista_t* wskpocz);
char* komendaiAp(int nr_sekcji, lista_t* wskpocz);
char* komendanAp(komendy_t* komenda, lista_t* wskpocz);
char* komendaiAn(int nr_sekcji, int od_kiedy, lista_t* wskpocz, komendy_t* komenda);
char* komendaiDg(int nr_sekcji, lista_t* wskpocz, koniec_t* koniec);
char* komendaiDn(int nr_sekcji, int od_kiedy, lista_t* wskpocz, koniec_t* koniec, komendy_t* komenda);
char* komendazEn(int od_kiedy, lista_t* wskkon, komendy_t* komenda);
void wypiszWyniki(komendy_t* kompocz);
int charWInt(char* tab, int od_kiedy);
char* intWChar(int liczba);
int main()
{
	procesor();

}
lista_t* dodajNaKoniec(lista_t* wsk, lista_t* wezel)
{
	wsk->nastepny = wezel;
	wezel->poprzedni = wsk;
	return wsk->nastepny;
}
attr_t* dodajNaKoniecAttr(attr_t* wsk, attr_t* wezel)
{
	wsk->nastepny = wezel;
	wezel->poprzedni = wsk;
	return wsk->nastepny;
}
komendy_t* dodajNaKoniecKom(komendy_t* wsk, komendy_t* wezel)
{
	wsk->nastepny = wezel;
	wezel->poprzedni = wsk;
	return wsk->nastepny;
}
lista_t* usunWezel(lista_t* wsk, lista_t* wskkon)
{
	if (wsk == wskkon)
		wskkon = wskkon->poprzedni;
	if (wsk->poprzedni != NULL)
		wsk->poprzedni->nastepny = wsk->nastepny;
	if (wsk->nastepny != NULL)
		wsk->nastepny->poprzedni = wsk->poprzedni;
	wsk->poprzedni = NULL;
	wsk->nastepny = NULL;

	wsk->~lista_t();
	return wskkon;
}
void usunWezelAttr(attr_t* wsk, lista_t* lokalny)
{
	if (wsk == lokalny->wsk_attr_kon)
		lokalny->wsk_attr_kon = lokalny->wsk_attr_kon->poprzedni;
	if (wsk->nastepny != NULL)
		wsk->nastepny->poprzedni = wsk->poprzedni;
	if (wsk->poprzedni != NULL)
		wsk->poprzedni->nastepny = wsk->nastepny;

	wsk->poprzedni = NULL;
	wsk->nastepny = NULL;

	wsk->~attr_t();
	return;
}
void procesor()
{
	lista_t* wskpocz = new lista_t();
	koniec_t* koniec = new koniec_t();
	koniec->wskkon = wskpocz;
	komendy_t* kompocz = new komendy_t();
	komendy_t* komkon = kompocz;
	lista_t* wezel;
	attr_t* wezelAttr;
	attr_t* wsk;
	*global = *koniec;
	char zn = ' ';
	while (cin >> zn)
	{
		if (zn != ' ' && zn != '\n')
		{
			if (zn == '?')
			{
				komkon = komendy(kompocz, komkon, wskpocz, koniec);
			}
			else
			{
				wezel = new lista_t();
				int i = 0;
				while (zn != '{')
				{
					if (zn == '\n')
					{
						if (i != 0 && wezel->selektory[i - 1] != ',')
						{
							char znp;
							cin >> noskipws >> znp;
							if (znp != ' ' && znp != '{' && znp != '\n')
							{
								wezel->selektory[i] = znp;
								i++;
								if (i + 2 >= wezel->len_selektory)
									dynalokacja(wezel->selektory, &(wezel->len_selektory));
								cin >> noskipws >> zn;
								continue;
							}
							else if (znp == '{')
							{
								zn = '{';
								break;
							}
							else if (znp == ' ')
							{
								while (zn == ' ' || zn == '\n')
									cin >> noskipws >> zn;
								if (zn == ',')
								{
									wezel->selektory[i] = zn;
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									cin >> noskipws >> zn;
									continue;
								}
								else if (zn == '{')
									break;
								else
								{
									wezel->selektory[i] = ' ';
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									wezel->selektory[i] = zn;
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									cin >> noskipws >> zn;
									continue;
								}
							}
							else
							{
								cin >> noskipws >> zn;
								continue;
							}
						}
						else
						{
							cin >> noskipws >> zn;
							continue;
						}
					}
					if (zn == ' ')
					{
						if (i != 0 && wezel->selektory[i - 1] != ',')
						{
							char znp;
							cin >> noskipws >> znp;
							if (znp != ' ' && znp != ',' && znp != '{' && znp != '\n')
							{
								wezel->selektory[i] = zn;
								i++;
								if (i + 2 >= wezel->len_selektory)
									dynalokacja(wezel->selektory, &(wezel->len_selektory));
								wezel->selektory[i] = znp;
								i++;
								if (i + 2 >= wezel->len_selektory)
									dynalokacja(wezel->selektory, &(wezel->len_selektory));
								cin >> noskipws >> zn;
								continue;
							}
							else if (znp == ',')
							{
								wezel->selektory[i] = znp;
								i++;
								if (i + 2 >= wezel->len_selektory)
									dynalokacja(wezel->selektory, &(wezel->len_selektory));
								cin >> noskipws >> zn;
								continue;
							}
							else if (znp == '{')
							{
								zn = '{';
								break;
							}
							else if (znp == '\n')
							{
								while (zn == ' ' || zn == '\n')
									cin >> noskipws >> zn;
								if (zn == ',')
								{
									wezel->selektory[i] = zn;
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									cin >> noskipws >> zn;
									continue;
								}
								else if (zn == '{')
									break;
								else
								{
									wezel->selektory[i] = ' ';
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									wezel->selektory[i] = zn;
									i++;
									if (i + 2 >= wezel->len_selektory)
										dynalokacja(wezel->selektory, &(wezel->len_selektory));
									cin >> noskipws >> zn;
									continue;
								}
							}
							else
							{
								cin >> noskipws >> zn;
								continue;
							}
						}
						else
						{
							cin >> noskipws >> zn;
							continue;
						}
					}
					wezel->selektory[i] = zn;
					i++;
					if (i + 2 >= wezel->len_selektory)
						dynalokacja(wezel->selektory, &(wezel->len_selektory));
					cin >> noskipws >> zn;
				}
				cin.setf(ios::skipws);
				wezel->selektory[i] = '\0';
				i--;
				while (wezel->selektory[i] == ' ' || wezel->selektory[i] == '\n')
				{
					wezel->selektory[i] = '\0';
					i--;
				}
				zn = '{';
				*global1 = *wezel;
				if (wezel->len_selektory >= 50)
				{
					wezel->wsk_attr->~attr_t();
					wezel->wsk_attr = new attr_t();
					wezel->wsk_attr_kon = wezel->wsk_attr;
				}
				bool czy_byl = false;
				i = 0;


				while (cin >> skipws >> zn && zn != '}')
				{
					czy_byl = false;
					if (zn == '\n')
						continue;
					i = 0;
					wezelAttr = new attr_t();
					while (zn != ';')
					{
						if (zn == ':')
						{
							czy_byl = true;
						}
						if (zn == ' ' && wezelAttr->atrybut[i - 1] == ':')
						{
							cin >> noskipws >> zn;
							continue;
						}
						if (zn == ' ' && !czy_byl)
						{
							cin >> noskipws >> zn;
							continue;
						}
						wezelAttr->atrybut[i] = zn;
						i++;
						if (i + 2 >= wezelAttr->len_atrybut)
						{
							dynalokacja(wezelAttr->atrybut, &(wezelAttr->len_atrybut));
						}
						cin >> noskipws >> zn;
						if (zn == '}' || zn == '\n')
						{
							break;
						}

					}
					wezelAttr->atrybut[i] = '\0';

					*global3 = *wezelAttr;
					global5++;
					wsk = new attr_t();
					wsk = wezel->wsk_attr;
					bool czybylo = false;
					while (wsk->nastepny != NULL)
					{
						wsk = wsk->nastepny;
						i = 0;
						bool p = true;
						while (wsk->atrybut[i] != ':' && wezelAttr->atrybut[i] != ':')
						{
							if (wsk->atrybut[i] != wezelAttr->atrybut[i])
								p = false;
							i++;
						}
						if (wsk->atrybut[i] == wezelAttr->atrybut[i] && p)
						{
							for (i; i < wezelAttr->len_atrybut; i++)
							{
								if (wezelAttr->atrybut[i] == '\0')
									break;
								if (i + 2 >= wsk->len_atrybut)
								{
									dynalokacja(wsk->atrybut, &(wsk->len_atrybut));
								}
								wsk->atrybut[i] = wezelAttr->atrybut[i];
							}
							czybylo = true;
							break;
						}
					}
					*global4 = *wezelAttr;
					global7++;
					wsk = NULL;
					wsk->~attr_t();
					if (!czybylo)
					{
						wezel->wsk_attr_kon = dodajNaKoniecAttr(wezel->wsk_attr_kon, wezelAttr);
					}
					wezelAttr = NULL;
					wezelAttr->~attr_t();
				}
				*global2 = *wezel;
				global6++;
				koniec->wskkon = dodajNaKoniec(koniec->wskkon, wezel);
				wezel = NULL;
				wezel->~lista_t();
			}
		}
	}
	wypiszWyniki(kompocz);
	kompocz->~komendy_t();
	komkon->~komendy_t();
	wskpocz->~lista_t();
	koniec->~koniec_t();
}
void css(koniec_t* koniec, char zn)
{

}
void wczytajSelektory(lista_t* wezel, char zn)
{

}
void wczytajBlok(lista_t* wezel)
{
	char zn;
	bool czy_byl = false;
	int i = 0, j = 0;
	while (cin >> skipws >> zn && zn != '}')
	{
		czy_byl = false;
		if (zn == '\n')
			continue;
		i = 0;
		attr_t* wezelAttr = new attr_t();
		while (zn != ';')
		{
			if (zn == ':')
			{
				czy_byl = true;
			}
			if (zn == ' ' && wezelAttr->atrybut[i - 1] == ':')
			{
				cin >> noskipws >> zn;
				continue;
			}
			if (zn == ' ' && !czy_byl)
			{
				cin >> noskipws >> zn;
				continue;
			}
			wezelAttr->atrybut[i] = zn;
			i++;
			if (i + 2 >= wezelAttr->len_atrybut)
			{
				dynalokacja(wezelAttr->atrybut, &(wezelAttr->len_atrybut));
			}
			cin >> noskipws >> zn;
			if (zn == '}' || zn == '\n')
			{
				break;
			}
		}
		wezelAttr->atrybut[i] = '\0';
		if (!czyJuzBylo(wezel->wsk_attr, wezelAttr))
		{
			wezel->wsk_attr_kon = dodajNaKoniecAttr(wezel->wsk_attr_kon, wezelAttr);
			wezelAttr = NULL;
			wezelAttr->~attr_t();
		}

	}
}
bool czyJuzBylo(attr_t* wsk, attr_t* wezel)
{
	while (wsk->nastepny != NULL)
	{
		wsk = wsk->nastepny;
		int i = 0;
		bool p = true;
		while (wsk->atrybut[i] != ':' && wezel->atrybut[i] != ':')
		{
			if (wsk->atrybut[i] != wezel->atrybut[i])
				p = false;
			i++;
		}
		if (wsk->atrybut[i] == wezel->atrybut[i] && p)
		{
			for (i; i < wezel->len_atrybut; i++)
			{
				if (wezel->atrybut[i] == '\0')
					break;
				if (i + 2 >= wsk->len_atrybut)
					dynalokacja(wsk->atrybut, &(wsk->len_atrybut));
				wsk->atrybut[i] = wezel->atrybut[i];
			}
			return true;
		}
	}
	return false;
}
void dynalokacja(char* tab, int* len)
{
	char* nowa = new char[2 * (*len)] {0};
	int i;
	for (i = 0; i < *len; i++)
		nowa[i] = tab[i];
	tab = new char[2 * (*len)] {0};
	tab = nowa;
	nowa = NULL;
	delete[] nowa;
	tab[i] = '\0';
	*len *= 2;
}
komendy_t* komendy(komendy_t* kompocz, komendy_t* komkon, lista_t* wskpocz, koniec_t* koniec)
{
	char zn;
	cin >> zn;
	cin >> zn;
	cin >> zn;
	komendy_t* wezel = new komendy_t();
	komendy_t* pomoc;
	int h = 0;
	while (cin >> zn)
	{
		h = 0;
		if (zn == '\n' && h == 0)
		{
			continue;
		}
		while (zn != '\n')
		{
			wezel->komendy[h] = zn;
			h++;
			if (cin >> noskipws >> zn)
			{
				if (h + 2 >= wezel->len_komendy)
					dynalokacja(wezel->komendy, &(wezel->len_komendy));
			}
			else
				break;
		}
		cin.setf(ios::skipws);
		wezel->komendy[h] = '\0';
		h = 0;
		int q = 0;
		while (wezel->komendy[h] != '\0')
		{
			if (wezel->komendy[h] == ',')
			{
				q++;
			}
			h++;
		}
		if (q>2)
			continue;
		if (wezel->komendy[0] == '\0')
			break;
		bool czy = false;
		int nr_sekcji = charWInt(wezel->komendy, 0);
		if (wezel->komendy[0] == '*' && wezel->komendy[1] == '*' && wezel->komendy[2] == '*' && wezel->komendy[3] == '*')
			return komkon;
		int i = 0;
		while (wezel->komendy[i] != ',' && wezel->komendy[0] != '?')
			i++;
		char funkcja;
		char tryb;
		int nr_j;
		if (wezel->komendy[0] != '?')
		{
			funkcja = wezel->komendy[i + 1];
			tryb = wezel->komendy[i + 3];
			nr_j = charWInt(wezel->komendy, i + 3);
		}
		if (wezel->komendy[0] == '?')
		{
			char* wynik = komenda1(wskpocz);
			int g = 0;
			if (wynik != NULL)
			{
				while (wynik[g] != '\0')
				{
					wezel->wynik[g] = wynik[g];
					g++;
					if (g + 2 >= wezel->len_wynik)
						dynalokacja(wezel->wynik, &(wezel->len_wynik));
				}
				wezel->wynik[g] = '\0';
			}
			else
				wezel->wynik = NULL;
		}
		else if (funkcja == 'S')
		{
			if (tryb == '?')
			{
				if (nr_sekcji != NULL)
				{

					char* wynik = komendaiSp(nr_sekcji, wskpocz);
					int g = 0;
					if (wynik != NULL)
					{
						while (wynik[g] != '\0')
						{
							wezel->wynik[g] = wynik[g];
							g++;
							if (g + 2 >= wezel->len_wynik)
								dynalokacja(wezel->wynik, &(wezel->len_wynik));
						}
						wezel->wynik[g] = '\0';
					}
					else
						wezel->wynik = NULL;
				}
				else
				{
					char* wynik = komendazSp(wezel, wskpocz);
					int g = 0;
					if (wynik != NULL)
					{
						while (wynik[g] != '\0')
						{
							wezel->wynik[g] = wynik[g];
							g++;
							if (g + 2 >= wezel->len_wynik)
								dynalokacja(wezel->wynik, &(wezel->len_wynik));
						}
						wezel->wynik[g] = '\0';
					}
					else
						wezel->wynik = NULL;
				}
			}
			else
			{
				char* wynik = komendaiSj(nr_sekcji, nr_j, wskpocz);
				int g = 0;
				if (wynik != NULL)
				{
					while (wynik[g] != '\0')
					{
						wezel->wynik[g] = wynik[g];
						g++;
						if (g + 2 >= wezel->len_wynik)
							dynalokacja(wezel->wynik, &(wezel->len_wynik));
					}
					wezel->wynik[g] = '\0';
				}
				else
					wezel->wynik = NULL;
			}

		}
		else if (funkcja == 'A')
		{
			if (tryb == '?')
			{
				if (nr_sekcji != NULL)
				{
					char* wynik = komendaiAp(nr_sekcji, wskpocz);
					int g = 0;
					if (wynik != NULL)
					{
						while (wynik[g] != '\0')
						{
							wezel->wynik[g] = wynik[g];
							g++;
							if (g + 2 >= wezel->len_wynik)
								dynalokacja(wezel->wynik, &(wezel->len_wynik));
						}
						wezel->wynik[g] = '\0';
					}
					else
						wezel->wynik = NULL;
				}
				else
				{
					char* wynik = komendanAp(wezel, wskpocz);
					int g = 0;
					if (wynik != NULL)
					{
						while (wynik[g] != '\0')
						{
							wezel->wynik[g] = wynik[g];
							g++;
							if (g + 2 >= wezel->len_wynik)
								dynalokacja(wezel->wynik, &(wezel->len_wynik));
						}
						wezel->wynik[g] = '\0';
					}
					else
						wezel->wynik = NULL;
				}
			}
			else
			{
				char* wynik = komendaiAn(nr_sekcji, i + 3, wskpocz, wezel);
				int g = 0;
				if (wynik != NULL)
				{
					while (wynik[g] != '\0')
					{
						wezel->wynik[g] = wynik[g];
						g++;
						if (g + 2 >= wezel->len_wynik)
							dynalokacja(wezel->wynik, &(wezel->len_wynik));
					}
					wezel->wynik[g] = '\0';
				}
				else
					wezel->wynik = NULL;
			}
		}
		else if (funkcja == 'D')
		{
			if (tryb == '*')
			{
				char* wynik = komendaiDg(nr_sekcji, wskpocz, koniec);
				int g = 0;
				if (wynik != NULL)
				{
					while (wynik[g] != '\0')
					{
						wezel->wynik[g] = wynik[g];
						g++;
						if (g + 2 >= wezel->len_wynik)
							dynalokacja(wezel->wynik, &(wezel->len_wynik));
					}
					wezel->wynik[g] = '\0';
				}
				else
					wezel->wynik = NULL;
				czy = true;
			}
			else
			{
				char* wynik = komendaiDn(nr_sekcji, i + 3, wskpocz, koniec, wezel);
				int g = 0;
				if (wynik != NULL)
				{
					while (wynik[g] != '\0')
					{
						wezel->wynik[g] = wynik[g];
						g++;
						if (g + 2 >= wezel->len_wynik)
							dynalokacja(wezel->wynik, &(wezel->len_wynik));
					}
					wezel->wynik[g] = '\0';
				}
				else
					wezel->wynik = NULL;
				czy = true;
			}
		}
		else if (funkcja == 'E')
		{
			char* wynik = komendazEn(i + 3, koniec->wskkon, wezel);
			int g = 0;
			if (wynik != NULL)
			{
				while (wynik[g] != '\0')
				{
					wezel->wynik[g] = wynik[g];
					g++;
					if (g + 2 >= wezel->len_wynik)
						dynalokacja(wezel->wynik, &(wezel->len_wynik));
				}
				wezel->wynik[g] = '\0';
			}
			else
				wezel->wynik = NULL;
		}
		else if(funkcja=='s')
			continue;
		komkon = dodajNaKoniecKom(komkon, wezel);
		wezel = NULL;
		wezel = new komendy_t();
	}
	return komkon;
}
char* komenda1(lista_t* wskpocz)
{
	int ile = 0;
	lista_t* lokalny = wskpocz;
	while (lokalny->nastepny != NULL)
	{
		lokalny = lokalny->nastepny;
		ile++;
	}
	char* wynik = intWChar(ile);
	return wynik;
}
char* komendaiSp(int nr, lista_t* wskpocz)
{
	lista_t* lokalny = wskpocz;
	int i = 0;
	while (i < nr && lokalny->nastepny != NULL)
	{
		i++;
		lokalny = lokalny->nastepny;
	}
	if (i != nr)
		return NULL;
	i = 0;
	int licznik = 0;
	while (lokalny->selektory[i] != '\0')
	{
		if (lokalny->selektory[i] == ',')
			licznik++;
		i++;
	}
	if (i != 0)
		licznik++;
	char* wynik = intWChar(licznik);
	return wynik;
}
char* komendazSp(komendy_t* komenda, lista_t* wskpocz)
{
	int licznik = 0;
	while (wskpocz->nastepny != NULL)
	{
		wskpocz = wskpocz->nastepny;
		bool p = true;
		for (int i = 0, j = 0; i < wskpocz->len_selektory; i++, j++)
		{

			if (komenda->komendy[j] == ',')
			{
				if ((wskpocz->selektory[i] == '\0' || wskpocz->selektory[i] == ',') && p)
				{
					licznik++;
					break;
				}
				else
					while (wskpocz->selektory[i] != '\0' && wskpocz->selektory[i] != ',')
						i++;
				j = -1;
				p = true;
			}
			else if (wskpocz->selektory[i] != '\0')
			{
				if (wskpocz->selektory[i] != komenda->komendy[j])
					p = false;
				if (wskpocz->selektory[i] == ',')
				{
					j = -1;
					p = true;
				}

			}
			else
				break;
		}
	}
	char* wynik = intWChar(licznik);
	return wynik;
}
char* komendaiSj(int nr_bloku, int nr_selektora, lista_t* wskpocz)
{
	int i = 0;
	lista_t* lokalny = wskpocz;
	while (i != nr_bloku && lokalny->nastepny != NULL)
	{
		lokalny = lokalny->nastepny;
		i++;
	}
	if (i != nr_bloku)
		return NULL;
	i = 1;
	int j = 0;
	while (i != nr_selektora && lokalny->selektory[j] != '\0')
	{
		if (lokalny->selektory[j] == ',')
			i++;
		j++;
	}
	if (i != nr_selektora || lokalny->selektory[0] == '\0')
		return NULL;
	char* wynik = new char[lokalny->len_selektory] {0};
	i = 0;
	while (lokalny->selektory[j] != ',' && lokalny->selektory[j] != '\0' && j < lokalny->len_selektory)
	{
		wynik[i] = lokalny->selektory[j];
		i++;
		j++;
	}
	return wynik;
}
char* komendaiAp(int nr_sekcji, lista_t* wskpocz)
{
	int i = 0;
	int licznik = 0;
	lista_t* lokalny = wskpocz;
	while (lokalny->nastepny != NULL && i != nr_sekcji)
	{
		lokalny = lokalny->nastepny;
		i++;
	}
	if (i != nr_sekcji)
		return NULL;
	attr_t* lokalnyAttr = lokalny->wsk_attr;
	while (lokalnyAttr->nastepny != NULL)
	{
		lokalnyAttr = lokalnyAttr->nastepny;
		licznik++;
	}
	char* wynik = intWChar(licznik);
	return wynik;
}
char* komendanAp(komendy_t* komenda, lista_t* wskpocz)
{
	int i = 0;
	int licznik = 0;
	bool p = true;
	lista_t* lokalny = wskpocz;
	while (lokalny->nastepny != NULL)
	{
		lokalny = lokalny->nastepny;
		attr_t* lokalnyAttr = lokalny->wsk_attr;
		while (lokalnyAttr->nastepny != NULL)
		{
			p = true;
			i = 0;
			lokalnyAttr = lokalnyAttr->nastepny;
			for (i; lokalnyAttr->atrybut[i] != ':'; i++)
			{
				if (i >= komenda->len_komendy)
					break;
				if (lokalnyAttr->atrybut[i] != komenda->komendy[i])
				{
					p = false;
					break;
				}
			}
			if (komenda->komendy[i] == ',' && p)
				licznik++;
		}
	}
	char* wynik = intWChar(licznik);
	return wynik;
}
char* komendaiAn(int nr_sekcji, int od_kiedy, lista_t* wskpocz, komendy_t* komenda)
{
	lista_t* lokalny = wskpocz;
	int i = 0;
	bool p = true;
	while (lokalny->nastepny != NULL && i != nr_sekcji)
	{
		lokalny = lokalny->nastepny;
		i++;
	}
	if (i != nr_sekcji)
		return NULL;
	attr_t* lokalnyAttr = lokalny->wsk_attr;
	while (lokalnyAttr->nastepny != NULL)
	{
		i = 0;
		lokalnyAttr = lokalnyAttr->nastepny;
		int j = od_kiedy;
		p = true;
		while (lokalnyAttr->atrybut[i] != ':')
		{
			if (lokalnyAttr->atrybut[i] != komenda->komendy[j])
			{
				p = false;
				break;
			}
			i++;
			j++;
			if (komenda->komendy[j] == '\0')
				break;
		}
		if (lokalnyAttr->atrybut[i] == ':' && komenda->komendy[j] == '\0' && p)
		{
			i++;
			int k = 0;
			char* wynik = new char[lokalnyAttr->len_atrybut] {0};
			while (lokalnyAttr->atrybut[i] != '\0')
			{
				wynik[k] = lokalnyAttr->atrybut[i];
				i++;
				k++;
			}
			return wynik;
		}
	}
	return NULL;
}
char* komendaiDg(int nr_sekcji, lista_t* wskpocz, koniec_t* koniec)
{
	lista_t* lokalny = wskpocz;
	int i = 0;
	while (lokalny->nastepny != NULL && i != nr_sekcji)
	{
		lokalny = lokalny->nastepny;
		i++;
	}
	if (i != nr_sekcji)
		return NULL;
	koniec->wskkon = usunWezel(lokalny, koniec->wskkon);
	char* wynik = new char[8] {0};
	wynik[0] = 'd';
	wynik[1] = 'e';
	wynik[2] = 'l';
	wynik[3] = 'e';
	wynik[4] = 't';
	wynik[5] = 'e';
	wynik[6] = 'd';
	return wynik;
}
char* komendaiDn(int nr_sekcji, int od_kiedy, lista_t* wskpocz, koniec_t* koniec, komendy_t* komenda)
{
	lista_t* lokalny = wskpocz;
	int i = 0;
	bool p = true;
	while (lokalny->nastepny != NULL && i != nr_sekcji)
	{
		lokalny = lokalny->nastepny;
		i++;
	}
	if (i != nr_sekcji)
		return NULL;
	attr_t* lokalnyAttr = lokalny->wsk_attr;
	while (lokalnyAttr->nastepny != NULL)
	{
		i = 0;
		lokalnyAttr = lokalnyAttr->nastepny;
		int j = od_kiedy;
		p = true;
		while (lokalnyAttr->atrybut[i] != ':')
		{
			if (lokalnyAttr->atrybut[i] != komenda->komendy[j])
			{
				p = false;
				break;
			}
			i++;
			j++;
			if (komenda->komendy[j] == '\0')
				break;
		}
		if (lokalnyAttr->atrybut[i] == ':' && komenda->komendy[j] == '\0' && p)
		{
			usunWezelAttr(lokalnyAttr, lokalny);
			if (lokalny->wsk_attr->nastepny == NULL)
			{
				koniec->wskkon = usunWezel(lokalny, koniec->wskkon);
			}
			char* wynik = new char[8] { 0 };
			wynik[0] = 'd';
			wynik[1] = 'e';
			wynik[2] = 'l';
			wynik[3] = 'e';
			wynik[4] = 't';
			wynik[5] = 'e';
			wynik[6] = 'd';
			return wynik;
		}
	}
	return NULL;
}
char* komendazEn(int od_kiedy, lista_t* wskkon, komendy_t* komenda)
{
	lista_t* lokalny = wskkon;
	while (lokalny->poprzedni != NULL)
	{
		bool p = true;
		bool czy_byl_sel = false;
		for (int i = 0, j = 0; i < lokalny->len_selektory; i++, j++)
		{
			if (komenda->komendy[j] == ',')
			{
				if ((lokalny->selektory[i] == ',' || lokalny->selektory[i] == '\0') && p)
				{
					czy_byl_sel = true;
					if (lokalny->selektory[i] == '\0')
						break;
				}
				else
					while (lokalny->selektory[i] != ',' && lokalny->selektory[i] != '\0')
						i++;
				j = -1;
				p = true;
			}
			else if (lokalny->selektory[i] != '\0')
			{
				if (lokalny->selektory[i] == ',')
				{
					j = -1;
					p = true;
				}
				if (lokalny->selektory[i] != komenda->komendy[j])
					p = false;
			}
			else
				break;
		}
		if (czy_byl_sel)
		{
			attr_t* lokalnyAttr = lokalny->wsk_attr_kon;
			while (lokalnyAttr->poprzedni != NULL)
			{
				int j = od_kiedy;
				int i = 0;
				p = true;
				while (lokalnyAttr->atrybut[i] != ':')
				{
					if (lokalnyAttr->atrybut[i] != komenda->komendy[j])
					{
						p = false;
						break;
					}
					i++;
					j++;
					if (komenda->komendy[j] == '\0')
						break;
				}
				if (lokalnyAttr->atrybut[i] == ':' && komenda->komendy[j] == '\0' && p)
				{
					i++;
					int k = 0;
					char* wynik = new char[lokalnyAttr->len_atrybut] {0};
					while (lokalnyAttr->atrybut[i] != '\0')
					{
						wynik[k] = lokalnyAttr->atrybut[i];
						i++;
						k++;
					}
					return wynik;
				}
				lokalnyAttr = lokalnyAttr->poprzedni;
			}
		}
		lokalny = lokalny->poprzedni;
	}
	return NULL;
}
void wypiszWyniki(komendy_t* kompocz)
{
	while (kompocz->nastepny != NULL)
	{
		kompocz = kompocz->nastepny;
		if (kompocz->wynik != NULL)
			cout << kompocz->komendy << " == " << kompocz->wynik << endl;
	}
}
int charWInt(char* tab, int od_kiedy)
{
	int wynik = 0;
	while (tab[od_kiedy] != ',' && tab[od_kiedy] != '\0')
	{
		if (tab[od_kiedy] < 48 || tab[od_kiedy]>57)
			return NULL;
		wynik = 10 * wynik + (int)tab[od_kiedy] - 48;
		od_kiedy++;
	}
	return wynik;
}
char* intWChar(int liczba)
{
	char* wynik = new char[10] {0};
	int i = 0;
	if (liczba == 0)
	{
		wynik[0] = '0';
		wynik[1] = '\0';
		return wynik;
	}
	while (liczba != 0)
	{
		int a = liczba % 10;
		wynik[i] = (char)(a + 48);
		i++;
		liczba /= 10;
	}
	char* wynik_fakt = new char[10] {0};
	wynik_fakt[i] = '\0';
	i--;
	int j = 0;
	while (i != -1)
	{
		wynik_fakt[i] = wynik[j];
		j++;
		i--;
	}
	return wynik_fakt;
}
