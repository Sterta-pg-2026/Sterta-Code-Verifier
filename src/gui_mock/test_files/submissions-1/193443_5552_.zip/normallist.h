#pragma once
#include "listnode.h"

template <typename T>
class normalList
{
	int size = 0;
	normalListNode<T>* first = nullptr;
	normalListNode<T>* node = nullptr;
	normalListNode<T>* getLastNode() const;
public:
	int getSize() const;
	bool empty() const;
	bool deleteN(int n);
	void pushBack(const T& element);
	T* getN(int n) const;
	T* getFirst() const;
	T* getLast() const;
	~normalList();

	T* get();
	bool isNode() const;
	void next();
	void begin();
};




template <typename T>
normalListNode<T>* normalList<T>::getLastNode() const{
	normalListNode<T>* node = first;
	while (node->nxt != nullptr)
		node = node->nxt;
	return node;
}

template <typename T>
int normalList<T>::getSize() const{
	return size;
}

template <typename T>
bool normalList<T>::empty() const{
	return size == 0;
}


template <typename T>
bool normalList<T>::deleteN(int n) {
	normalListNode<T>* node = first->nxt;
	normalListNode<T>* prNode = first;
	if (n == 1) {
		if (empty()) return false;
		delete first;
		first = node;
		size--;
		return true;
	}
	for (int i = 2; i <= size; i++) {
		if (i == n) {
			prNode->nxt = node->nxt;
			delete node;
			size--;
			return true;
		}
		prNode = node;
		node = node->nxt;
	}
	return false;
}

template <typename T>
void normalList<T>::pushBack(const T& element) {
	normalListNode<T>* node = new normalListNode<T>;
	node->nxt = nullptr;
	node->item = element;
	if (empty())
		first = node;
	else
		getLastNode()->nxt = node;
	size++;
}

template <typename T>
T* normalList<T>::getN(int n) const{
	normalListNode<T>* node = first;
	for (int i = 1; i <= size; i++) {
		if (i == n)
			return &node->item;
		node = node->nxt;
	}
	return nullptr;
}

template <typename T>
T* normalList<T>::getFirst() const{
	if (!first)
		return nullptr;
	return first->item;
}

template <typename T>
T* normalList<T>::getLast() const{
	normalListNode<T>* last = getLastNode();
	if (!last)
		return nullptr;
	return &last->item;
}

template <typename T>
normalList<T>::~normalList() {
	while (!empty())
		deleteN(1);
}

template <typename T>
T* normalList<T>::get() {
	return &node->item;
}

template <typename T>
bool normalList<T>::isNode() const{
	return node;
}

template <typename T>
void normalList<T>::begin() {
	node = first;
}

template <typename T>
void normalList<T>::next() {
	if (node)
		node = node->nxt;
}



