#pragma once
#define BLOCKSIZE 27
#include <iostream>
#include <cctype>
#include "normallist.h"
#include "blocklist.h"
#include "mystring.h"

//autor: Damian Trowski 193443

#define MAXWORDLENGTH 10000

using namespace std;

enum ParsingMode {
	selectorMode,
	attributeMode,
	valueMode
};

struct Attribute
{
	myString name;
	myString value;
};
struct Selector
{
	myString name;
};
struct Section
{
	normalList<Selector> selectors;
	normalList<Attribute> attributes;
};

blockList<Section, BLOCKSIZE> sections;

myString extr(char str[], int size) {
	int strLng = 0, endLng = 0;
	for (int i = 0; i < size; i++) {
		if (isspace(str[i]))
			strLng++;
		else
			break;
	}
	for (int i = size - 1; i >= 0; i--) {
		if (isspace(str[i]))
			endLng++;
		else
			break;
	}
	myString ret(str+strLng, size-endLng-strLng);
	return ret;
}

void deleteDuplicate() {
	normalList<Attribute>* atr = &sections.getLast()->attributes;
	Attribute* last = sections.getLast()->attributes.getLast();
	for (atr->begin(); atr->isNode() && atr->get()!=last; atr->next())
		if (atr->get()->name == last->name) {
			atr->get()->value = last->value;
			atr->deleteN(atr->getSize());
			break;
		}
}
void print();
void parse() {
	char input;
	int cLetter = 0;
	char word[MAXWORDLENGTH];
	myString atrName;
	ParsingMode mode = selectorMode;
	bool sectionNeeded = true;
	while (cin.get(input)) {
			if (input == '?') {
				for (int i = 0; i < 3; i++)
					cin.get(input);
				return;
			}
			if (input == ',' && mode == selectorMode) {
				sections.getLast()->selectors.pushBack({extr(word, cLetter)});
				cLetter = 0;
			}
			else if (input == '{') {
				mode = attributeMode;
				if (extr(word, cLetter) != "") {
					sections.getLast()->selectors.pushBack({ extr(word, cLetter) });
					cLetter = 0;
				}
			}
			else if (input == '}') {
				if (mode == valueMode) {
					sections.getLast()->attributes.pushBack({atrName, extr(word, cLetter)});
					deleteDuplicate();
				}
				cLetter = 0;
				mode = selectorMode;
				sectionNeeded = true;
			}
			else if (input == ':' && mode == attributeMode) {
				mode = valueMode;
				atrName = extr(word, cLetter);
				cLetter = 0;
			}
			else if (input == ';' && mode == valueMode) {
				mode = attributeMode;
				sections.getLast()->attributes.pushBack({ atrName, extr(word, cLetter) });
				cLetter = 0;
				deleteDuplicate();
			}
			else {
				word[cLetter] = input;
				cLetter++;
				if (sectionNeeded && !isspace(input)) {
					sections.pushBack({});
					sectionNeeded = false;
				}
			}
	}
}

int toInt(const myString& value) {
	int ret = 0, mltp = 1, intValue;
	for (int i = value.getLength() - 1; i >= 0; i--) {
		intValue = value[i] - '0';
		if (intValue < 0 || intValue>9)
			return 0;
		ret += intValue * mltp;
		mltp *= 10;
	}
	return ret;
}

Attribute* getAttribute(Section* sec, const myString& name) {
	if (!sec) return nullptr;
	normalList<Attribute>* atr=&sec->attributes;
	for (atr->begin(); atr->isNode(); atr->next())
		if (atr->get()->name == name)
			return atr->get();
	return nullptr;
}

Attribute* getAttribute(const myString& selector, const myString& attribute) {
	Attribute* atr;
	for (sections.end(); sections.isNode(); sections.prev()) {
		Section *sec=sections.get();
		for (sec->selectors.begin(); sec->selectors.isNode(); sec->selectors.next())
			if (sec->selectors.get()->name == selector) {
				atr = getAttribute(sec, attribute);
				if (atr)
					return atr;
			}
	}
	return nullptr;
}

int getAllAttributesC(const myString& name) {
	int ret = 0;
	for (sections.begin(); sections.isNode(); sections.next()) 
		if (getAttribute(sections.get(), name))
			ret++;
	return ret;
}

int getAllSelectorsC(const myString& name) {
	int ret = 0;
	for (sections.begin(); sections.isNode(); sections.next()) {
		normalList<Selector>* sel = &sections.get()->selectors;
		for(sel->begin(); sel->isNode(); sel->next())
			if (sel->get()->name == name) {
				ret++;
				break;
			}
	}
	return ret;
}

bool deleteAttribute(int index, const myString& name) {
	bool ret=false;
	Section *sec = sections.getN(index);
	if (!sec) return false;
	normalList<Attribute>* atr = &sec->attributes;
	atr->begin();
	for (int i = 1; i <= atr->getSize();i++) {
		if (atr->get()->name == name) {
			ret=atr->deleteN(i);
			break;
		}
		atr->next();
	}
	if (sec->attributes.empty())
		sections.deleteN(index);
	return ret;
}

void parseCommand() {
	myString command, cp[3];
	int crnt;
	char inputLine[MAXWORDLENGTH];
	int lineLength, wordLength;
	while (cin.getline(inputLine, MAXWORDLENGTH)) {
		lineLength = (int)strlen(inputLine);
		crnt = 0;
		wordLength = 0;
		for (int i = 0; i < 3; i++)
			cp[i] = "";
		command = extr(inputLine, lineLength);
		if (command == "****") {
			parse();
			continue;
		}
		if (command == "?") {
			cout << inputLine << " == " << sections.getSize() << endl;
			continue;
		}
		for (int i = 0; i <= lineLength; i++) {
			if (i== lineLength || inputLine[i] == ','&&crnt<2) {
				cp[crnt] = extr(inputLine+i-wordLength, wordLength);
				wordLength = 0;
				crnt++;
			}
			else
				wordLength++;
		}
		if (toInt(cp[0]) && cp[1] == "S" && cp[2] == "?") {
			Section* sec=sections.getN(toInt(cp[0]));
			if (sec)
				cout << inputLine << " == " << sec->selectors.getSize() << endl;
		}	
		else if (toInt(cp[0]) && cp[1] == "A" && cp[2] == "?") {
			Section* sec=sections.getN(toInt(cp[0]));
			if (sec)
				cout << inputLine << " == " << sec->attributes.getSize() << endl;
		}
		else if (toInt(cp[0]) && cp[1] == "S" && toInt(cp[2])) {
			Section* sec = sections.getN(toInt(cp[0]));
			if (sec) {
				Selector* sel = sections.getN(toInt(cp[0]))->selectors.getN(toInt(cp[2]));
				if(sel)
					cout << inputLine << " == " << sel->name << endl;
			}
		}	
		else if (toInt(cp[0]) && cp[1] == "A" && !toInt(cp[2])) {
			Attribute* atr = getAttribute(sections.getN(toInt(cp[0])), cp[2]);
			if (atr) 
				cout << inputLine << " == " << atr->value << endl;
		}
		else if (!toInt(cp[0]) && cp[1] == "A" && cp[2] == "?") {
			cout << inputLine << " == " << getAllAttributesC(cp[0]) << endl;
		}
		else if (!toInt(cp[0]) && cp[1] == "S" && cp[2] == "?") {
			cout << inputLine << " == " << getAllSelectorsC(cp[0]) << endl;
		}
		else if (cp[1] == "E") {
			Attribute* atr = getAttribute(cp[0], cp[2]);
			if (atr) 
				cout << inputLine << " == " << atr->value << endl;
		}	
		else if (cp[1] == "D" && cp[2] == "*") {
			if (sections.deleteN(toInt(cp[0])))
				cout << inputLine << " == deleted" << endl;
		}
		else if (cp[1] == "D") {
			if (deleteAttribute(toInt(cp[0]), cp[2]))
				cout << inputLine << " == deleted" << endl;
		}
	}
}

void print() {
	Section* sec;
	sections.begin();
	for (int i = 1; i <= sections.getSize(); i++, sections.next()) {
		sec = sections.get();
		if (!sec) continue;
		normalList<Selector>* sel=&sec->selectors;
		sel->begin();
		normalList<Attribute>* atr=&sec->attributes;
		atr->begin();
		cout << "\nsekcja nr: " << i << endl; 
		for (int j = 1; j <= sel->getSize(); j++, sel->next())
			cout << "\ts" << j << ": '" << sel->get()->name << "'\n";
		if(sec->selectors.getSize())
			cout << "\t||" << endl;
		for (int j = 1; j <= atr->getSize(); j++, atr->next())
			cout << "\ta" << j << ": '" << atr->get()->name << "': '" << atr->get()->value << "';\n";
		cout << endl;
	}
}

int main(int argc, char** argv)
{
	parse();
	parseCommand();
	if (argc > 1 && argv[1][0] == 't')
		print();
	return 0;
}