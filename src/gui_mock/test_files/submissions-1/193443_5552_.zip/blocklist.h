#pragma once
#include "listnode.h"

#ifndef BSIZE
#define BSIZE 6
#endif 

template <typename T, int blockSize>
class blockList
{
	int size = 0;
	blockListNode<T, blockSize>* first = nullptr;
	blockListNode<T, blockSize>* last = nullptr;
	int iter=0, piter=0;
	blockListNode<T, blockSize>* node = nullptr;
public:
	bool empty() const;
	int getSize() const;
	bool deleteN(int n);
	void pushBack(const T& element);
	T* getN(int n) const;
	T* getNR(int n) const;
	T* getLast() const;
	T* getFirst() const;
	~blockList();
	
	T* get();
	bool isNode() const;
	void next();
	void prev();
	void begin();
	void end();
};

template <typename T, int blockSize>
int blockList<T, blockSize>::getSize() const{
	return size;
}

template <typename T, int blockSize>
bool blockList<T, blockSize>::empty() const{
	return size == 0;
}


template <typename T, int blockSize>
bool blockList<T, blockSize>::deleteN(int n) {
	if (empty())
		return false;
	if (n<1||n>size) 
		return false;
	if (size == 1) {
		delete first;
		first = nullptr;
		last = nullptr;
		size--;
		return true;
	}
	int p = 0;
	blockListNode<T, blockSize>* blck = first;
	while (p + blck->size < n) {
		p += blck->size;
		blck = blck->nxt;
	}
	for (int i = 0; i < blockSize; i++) {
		if (blck->set[i]) {
			p++;
			if (p == n) {
				blck->set[i]=false;
				blck->size--;
				size--;
				if (blck->size == 0) {
					if (!blck->prv) {
						first = blck->nxt;
						blck->nxt->prv = nullptr;
					}
					else if (!blck->nxt) {
						last = blck->prv;
						blck->prv->nxt = nullptr;
					}
					else {
						blck->nxt->prv = blck->prv;
						blck->prv->nxt = blck->nxt;
					}
					delete blck;
				}
				return true;
			}
		}
	}
	return false;
}

template <typename T, int blockSize>
void blockList<T, blockSize>::pushBack(const T& element) {
	if (empty()) {
		first = new blockListNode<T, blockSize>();
		first->item[0] = element;
		first->set[0] = true;
		first->size = 1;
		first->freeSlot = 1;
		last = first;
	}
	else {
		if (last->freeSlot<blockSize) {
			blockListNode<T, blockSize>* blck = last;
			blck->item[blck->freeSlot] = element;
			blck->set[blck->freeSlot] = true;
			blck->size++;
			blck->freeSlot++;
		}
		else {
			blockListNode<T, blockSize>* tmp = new blockListNode<T, blockSize>();
			tmp->item[0] = element;
			tmp->set[0] = true;
			tmp->size = 1;
			tmp->freeSlot = 1;
			tmp->prv = last;
			last->nxt = tmp;
			last = tmp;
		}
	}
	size++;
}

template <typename T, int blockSize>
T* blockList<T, blockSize>::getN(int n) const{
	int p = 0;
	if (empty())
		return nullptr;
	if (n<1||n>size) 
		return nullptr;
	blockListNode<T, blockSize>* blck = first;
	while (p + blck->size < n) {
		p += blck->size;
		blck = blck->nxt;
	}
	for (int i = 0; i < blockSize; i++) {
		if (blck->set[i]) {
			p++;
			if (p == n) 
				return &blck->item[i];
		}
	}
	return nullptr;
}

template <typename T, int blockSize>
T* blockList<T, blockSize>::getNR(int n) const{
	int p = 0;
	if (empty()) 
		return nullptr;
	if (n<1 || n>size)
		return nullptr;
	blockListNode<T, blockSize>* blck = last;
	while (p + blck->size < n) {
		p += blck->size;
		blck = blck->prv;
	}
	for (int i = blockSize-1; i >=0; i--) {
		if (blck->set[i]) {
			p++;
		if (p == n)
			return &blck->item[i];
		}
	}
	return nullptr;
}

template <typename T, int blockSize>
T* blockList<T, blockSize>::getFirst() const{
	return getN(1);
}

template <typename T, int blockSize>
T* blockList<T, blockSize>::getLast() const{
	return getNR(1);
}

template <typename T, int blockSize>
blockList<T, blockSize>::~blockList() {
	while (!empty())
		deleteN(1);
}



template <typename T, int blockSize>
T* blockList<T, blockSize>::get() {
	if (!node)
		return nullptr;
	int cnt = 0;
	for (int i = 0; i < blockSize; i++) {
		if (!node->set[i]);
		else if (cnt == iter - piter)
			return &node->item[i];
		else 
			cnt++;
	}
	return nullptr;
}

template <typename T, int blockSize>
bool blockList<T, blockSize>::isNode() const{
	return (iter>=0&&iter<size);
}

template <typename T, int blockSize>
void blockList<T, blockSize>::begin() {
	iter=0, piter=0;
	node = first;
}

template <typename T, int blockSize>
void blockList<T, blockSize>::end() {
	iter = size-1, piter = size - last->size;
	node = last;
}

template <typename T, int blockSize>
void blockList<T, blockSize>::next() {
	if (!node)
		return;
	iter++;
	if (iter - piter >= node->size) {
		piter += node->size;
		node = node->nxt;
	}
}

template <typename T, int blockSize>
void blockList<T, blockSize>::prev() {
	if (!node)
		return;
	iter--;
	if (iter - piter < 0 && node->prv) {
		node = node->prv;
		piter -= node->size;
	}
}



