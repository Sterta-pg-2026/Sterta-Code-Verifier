#pragma once

//#include<cstring>
#include<iostream>

class myString
{	
	char* array=nullptr;
	int length=0;
	void set(const char str[]);
public:
	myString();
	myString(const char str[]);
	myString(const char str[], int size);
	myString(const myString& mstr);
	myString& operator=(const char str[]);
	myString& operator=(myString mstring);
	bool operator==(const char str[]) const;
	bool operator!=(const char str[]) const;
	bool operator==(myString mstr) const;
	char operator[](int index) const;
	int getLength() const;
	~myString();
	friend std::ostream& operator<<(std::ostream& os, const myString& mstr);
};
