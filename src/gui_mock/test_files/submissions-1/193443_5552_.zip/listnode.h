#pragma once

template <typename T>
class normalListNode
{
public:
	T item;
	normalListNode<T>* nxt=nullptr;
};

template <typename T, int blockSize>
class blockListNode
{
public:
	int size=0;
	int freeSlot=0;
	T item[blockSize];
	bool set[blockSize];
	blockListNode<T, blockSize>* nxt = nullptr;
	blockListNode<T, blockSize>* prv = nullptr;
	//~blockListNode();
};

template <typename T>
class ListNode
{
public:
	T item;
	ListNode* nxt = nullptr;
	ListNode* prv = nullptr;
};

