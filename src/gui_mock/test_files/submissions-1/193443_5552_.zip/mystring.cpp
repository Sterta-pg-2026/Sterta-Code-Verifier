#include "mystring.h"

void myString::set(const char str[]) {
	if (!str)
		return;
	length = (int)strlen(str);
	array = new char[length + 1];
	for (int i = 0; i < length; i++)
		array[i] = str[i];
	array[length] = '\0';
}
myString::myString() {

}
myString::myString(const char str[]) {
	set(str);
}
myString::myString(const char str[], int size) {
	if (!str||size<1)
		return;
	length = size;
	array = new char[length + 1];
	for (int i = 0; i < length; i++)
		array[i] = str[i];
	array[length] = '\0';
}
myString::myString(const myString& mstr) : myString(mstr.array) {
}
myString& myString::operator=(const char str[]) {
	if (length)
		delete[] array;
	length = 0;
	set(str);
	return *this;
}
myString& myString::operator=(myString mstring) {
	return operator=(mstring.array);
}
bool myString::operator==(const char str[]) const {
	if (strlen(str) != length)
		return false;
	for (int i = 0; i < length; i++)
		if (array[i] != str[i])
			return false;
	return true;
}
bool myString::operator!=(const char str[]) const {
	return !operator==(str);
}
bool myString::operator==(myString mstr) const {
	return operator==(mstr.array);
}
char myString::operator[](int index) const {
	return array[index];
}
int myString::getLength() const {
	return length;
}
myString::~myString() {
	if (length)
		delete[] array;
}

std::ostream& operator<<(std::ostream& os, const myString& mstr) {
	return os << mstr.array;
}
