#include "interpreter.hpp"
#include <iostream>

void Interpreter::load_input(std::istream& in) {
	String input;
	char c;
	while ((c = std::cin.get()) && !std::cin.fail())
		input.append(c);

	String styles;
	String commands;
	
	do {
		styles = input.cut_at("????");
		css.process(styles);
		commands = input.cut_at("****");
		if (commands.size() > 0)
			interpret_commands(commands);
		else
			interpret_commands(input);
		 
	} while (styles.size() > 0 && commands.size() > 0);
}

Interpreter::Command::Command(String& init) {
	auto fragments = init.explode(',');
	for (auto& fragment: fragments)
		fragment.trim();

	if (fragments.size() == 1) {
		action = fragments.first();
	}
	else if (fragments.size() == 3) {
		auto it = fragments.begin();
		
		arg1 = *it;
		action = *++it;
		arg2 = *++it;
	}
	else {
		action = "skip";
	}
}

void Interpreter::interpret_commands(String& input) {
	for (auto& command: input.explode('\n')) {
		//DEBUG: std::cout << "Got command: " << command << "\n";
		Command cmd(command);

		if (cmd.action == "?") {
			print_output(cmd, count_sections());
		}
		else if (cmd.action == "E") {
			String result = get_attribute_value(cmd.arg1, cmd.arg2);
			if (result.without(String::whitespace).size() > 0)
				print_output(cmd, get_attribute_value(cmd.arg1, cmd.arg2));
		}
		else if (cmd.action == "S") {
			dispatch_selector_command(cmd);
		}
		else if (cmd.action == "A") {
			dispatch_attribute_command(cmd);
		}
		else if (cmd.action == "D") {
			dispatch_delete_command(cmd);
		}
		else {
			//DEBUG: std::cout << "Skipped command: " << command << "\n";
			continue;
		}
	};
}

void Interpreter::dispatch_selector_command(const Command& cmd) {
	if (cmd.arg2 != "?") {
		String result = get_selector(cmd.arg1.to_int(), cmd.arg2.to_int());
		if (result.without(String::whitespace).size() != 0)
			print_output(cmd, result);
	}
	else if (cmd.arg1.is_num()) {
		int result = count_all_selectors(cmd.arg1.to_int());
		if (result != -1)
			print_output(cmd, result);
	}
	else {
		print_output(cmd, count_selector(cmd.arg1));
	}
}

void Interpreter::dispatch_attribute_command(const Command& cmd) {
	if (cmd.arg2 != "?") {
		String result = get_attribute_value(cmd.arg1.to_int(), cmd.arg2);
		if (result.without(String::whitespace).size() != 0)
			print_output(cmd, result);
	}
	else if (cmd.arg1.is_num()) {
		int result = count_all_attributes(cmd.arg1.to_int());
		if (result != -1)
			print_output(cmd, result);
	}
	else {
		print_output(cmd, count_attribute(cmd.arg1));
	}
}

void Interpreter::dispatch_delete_command(const Command& cmd) {
	bool deleted;

	if (cmd.arg2 == "*")
		deleted = remove(cmd.arg1.to_int());
	else
		deleted = remove(cmd.arg1.to_int(), cmd.arg2);

	if (deleted)
		print_output(cmd, "deleted");
}

template <typename T>
void Interpreter::print_output(Command command, T value) {
	List<String> fragments;
	if (command.arg1.size() != 0)
		fragments.append(command.arg1);
	if (command.action.size() != 0)
		fragments.append(command.action);
	if (command.arg2.size() != 0)
		fragments.append(command.arg2);

	String cmd_name = fragments.fold(String::combine_with(","));

	std::cout << cmd_name << " == " << value << "\n";
}

int Interpreter::count_sections() {
	return css.get_data().size();
}

int Interpreter::count_all_selectors(int section) {
	if (css.get_data().size() < section)
		return -1;
	
	int count = 0;
	for (auto& selector: css.get_data().get(section-1).selectors)
		if (selector.size() > 0)
			count++;

	return count;
}

int Interpreter::count_selector(const String& name) {
	int count = 0;
	for (auto& block: css.get_data())
		for (auto& selector: block.selectors)
			if (selector == name)
				count++;

	return count;
}

String Interpreter::get_selector(int section, int selector) {
	if (css.get_data().size() < section
	    || css.get_data().get(section-1).selectors.size() < selector)
		return String();
	
	return css.get_data().get(section-1).selectors.get(selector-1);
}

String Interpreter::get_attribute_value(String selector, String name) {
	String value;
	
	for (auto& block: css.get_data())
		if (block.selectors.count_matching([selector](const String& s) {
			return s == selector;
		}) > 0) {
			for (auto& attribute: block.attributes)
				if (attribute.name == name)
					value = attribute.value;
		}

	return value;
}

String Interpreter::get_attribute_value(int section, String name) {
	if (css.get_data().size() < section)
		return String();

	String value;
	for (auto& attribute: css.get_data().get(section-1).attributes)
		if (attribute.name == name)
			value = attribute.value;
	
	return value;
}

int Interpreter::count_attribute(String name) {
	int count = 0;
	for (auto& section: css.get_data())
		for (auto& attribute: section.attributes)
			if (attribute.name == name) {
				count++;
				break;
			}

	return count;
}

int Interpreter::count_all_attributes(int section) {
	if (css.get_data().size() < section)
		return -1;

	List<String> unique;
	for (auto& attribute: css.get_data().get(section-1).attributes)
		if (!unique.contains(attribute.name))
			unique.append(attribute.name);
	
	return unique.size();
}

bool Interpreter::remove(int index) {
	if (css.get_data().size() < index)
		return false;
	
	css.get_data().remove(index-1);
	return true;
}

bool Interpreter::remove(int section, String name) {
	name.trim();
	
	int before = css.get_data().get(section-1).attributes.size();

	css.get_data().get(section-1).attributes.filter_this([name](auto a) {
		return a.name != name;
	});

	int after = css.get_data().get(section-1).attributes.size();

	if (after == before)
		return false;

	if (after == 0)
		return remove(section);

	return true;
}
