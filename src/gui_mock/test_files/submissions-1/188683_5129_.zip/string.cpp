#include "string.hpp"
#include <cctype>
#include <cstdlib>

String::String(const char* const str) : String::String() {
	*this = str;
}

String::String(List<char>&& source) : List<char>(std::move(source)) { }

String& String::operator=(const char* const str) {
	clear();
	for (int i=0; str[i] != '\0'; push_back(str[i++]));
	return *this;
}

ArrayList<String> String::explode(char delimiter) const {
	ArrayList<String> result;
	String temp;

	for (auto& c: *this) {
		if (c == delimiter) {
			result.push_back(temp);
			temp.clear();
		}
		else {
			temp.push_back(c);
		}
	}

	if (temp.size() != 0)
		result.push_back(temp);

	return result;
}

String& String::remove(const List<char>& elements) {
	filter_this([elements](char c) {
		bool pass = true;
		for (auto& element: elements)
			if (c == element) {
				pass = false;
				break;
			}

		return pass;
	});

	return *this;
}

String String::without(const List<char>& elements) const {
	String copy = *this;
	return copy.remove(elements);
}

char* String::alloc_new_cstr() const {
	char* cstring = new char[size()+1]{'\0'};
	
	auto it = begin();
	for (int i=0; i<size(); i++)
		cstring[i] = *it++;

	return cstring;
}

int String::to_int() const {
	char* cstring = alloc_new_cstr();
	int result = atoi(cstring);
	delete[] cstring;
	return result;
}

bool String::is_num() const {
	bool is_number = true;
	
	auto it = begin();
	if (*it == '-')
		it++;
	
	while (it != end() && is_number) {
		is_number = std::isdigit(static_cast<unsigned char>(*it));
		it++;
	}

	return is_number;
}

bool operator==(const String& a, const String& b) {
	if (a.size() != b.size())
		return false;

	bool is_equal = true;
	auto it_a = a.begin();
	auto it_b = b.begin();
	while (is_equal && it_a != a.end())
		if (*it_a++ != *it_b++)
			is_equal = false;
	
	return is_equal;
}

bool operator!=(const String& a, const String& b) {
	return !(a == b);
}

String String::cut_at(const char* c) {
	auto it = begin();
	
	while (it != end()) {
		if (*it == c[0]) {
			int i = 0;
			bool equal = true;
			
			while (c[i] != '\0' && it != end() && c[i] == *it) {
				it++;
				i++;
			}
			
			it--;

			if (c[i] == '\0') {
				String result = split_at(it);
				while (i--)
					result.pop();
				return result;
			}
		}

		it++;
	}
	
	return String();
}

String& String::trim() {
	while (size() > 0 && iswspace(*begin())) {
		pop_front();
	}

	while (size() > 0 && iswspace(*--end())) {
		pop();
	}

	return *this;
}

String String::trimmed() const {
	String copy = *this;
	return copy.trim();
}

	std::ostream& operator<<(std::ostream& out, const String& str) {
	for (auto& element: str)
		out << element;

	return out;
}

std::istream& operator>>(std::istream& in, String& str) {
	in >> std::ws;

	str.clear();
	char c;

	while (in.get(c) && !iswspace(c))
		str.push_back(c);
	
	return in;
}

std::function<String(const String&, const String&)>
String::combine_with(const String& delim) {
	return [delim](const String& a, const String& b) {
		return a + delim + b;
	};
}

List<char> String::whitespace = {' ', '\t', '\n','\r', '\f', '\v'};
