#pragma once

#include "list.hpp"
#include "arraylist.hpp"
#include <ostream>
#include <istream>

class String : public List<char> {
public:
	String() = default;
	String(const char* const str);
	String(List<char>&&);
	String& operator=(const char* const str);

	ArrayList<String> explode(char delim) const;
	String& remove(const List<char>&);
	String without(const List<char>&) const;
	String cut_at(const char*);
	String& trim();
	String trimmed() const;
	
	char* alloc_new_cstr() const;
	int to_int() const;
	bool is_num() const;
	
	friend bool operator==(const String&, const String&);
	friend bool operator!=(const String&, const String&);
	friend std::ostream& operator<<(std::ostream&, const String&);
	friend std::istream& operator>>(std::istream&, String&);

	static std::function<String(const String&, const String&)>
	combine_with(const String&);

	static List<char> whitespace;
};
