#pragma once
#include <initializer_list>
#include <iterator>
#include <functional>
#include <cstddef>
#include <ostream>

template <typename T>
class List {
	struct Node {
		T value;
		Node* prev = nullptr;
		Node* next = nullptr;

		Node() = default;
		Node(const T& init) : value(init) {};
	};

	class Iterator {
		using iterator_category = std::bidirectional_iterator_tag;
		using difference_type   = std::ptrdiff_t;
		using value_type        = T;
		using pointer           = T*;
		using reference         = T&;

		int index = 0;
		Node* raw_ptr;

	public:
		Iterator() = default;
		Iterator(Node* init) : raw_ptr(init) {};
		
		reference operator*() const {
			return raw_ptr->value;
		}
		pointer   operator->() {
			return &raw_ptr->value;
		}
		Iterator& operator++() {
			raw_ptr = raw_ptr->next;
			++index;
			return *this;
		}
		Iterator  operator++(int) {
			auto tmp = *this;
			++(*this);
			return tmp;
		}
		Iterator& operator--() {
			raw_ptr = raw_ptr->prev;
			--index;
			return *this;
		}
		Iterator  operator--(int) {
			auto tmp = *this;
			--(*this);
			return tmp;
		}
		bool operator==(const Iterator& iter) {
			return raw_ptr == iter.raw_ptr;
		}
		bool operator!=(const Iterator& iter) {
			return !(*this == iter);
		}

		friend List<T>;
	};

	Node* root;
	Node* tail;
	int   count;

protected:
	void init();
	void destroy();
	Node* get_node(int) const;
	T remove_node(Node*&);

public:
	List();
	List(std::initializer_list<T>);
	List(const List<T>&);
	List(List<T>&&);
	~List();
	List<T>& operator=(const List<T>&);

	Iterator begin() const;
	Iterator end()   const;
	
	void append(const T&);
	void append(const List<T>&);
	void push_back(const T&);
	void clear();
	T pop();
	T pop_front();
	T first() const;
	T& front();
	T last() const;
	T& back();
	int size() const;
	int length() const;
	T& get(int);
	T  get(int) const;
	T remove(int);
	T remove(Iterator);
	void insert_at(int, const T&);
	List<T> split_at(Iterator);
	bool contains(const T&) const;
	void remove_repeating();

	List<T> operator+(const List<T>&) const;
	List<T>& operator+=(const List<T>&);

	List<T>& map_this(std::function<T(T)>);
	List<T>  map(std::function<T(T)>) const;
	List<T>& filter_this(std::function<bool(T)>);
	List<T>  filter(std::function<bool(T)>) const;
	T fold(std::function<T(T, T)>) const;

	int count_matching(std::function<bool(const T&)>) const;

	template <typename U>
friend std::ostream& operator<<(std::ostream&, const List<U>&);
};

#include "list_templates.hpp"
