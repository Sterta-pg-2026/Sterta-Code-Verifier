#include "stylesheet.hpp"
#include <iostream>

void Stylesheet::process(String& stream) {
	ArrayList<String> selectors;
	ArrayList<String> attribute_stream;
	
	do {
		selectors = std::move(stream.cut_at("{").explode(','));
		for (auto& selector: selectors)
			selector.trim();
		selectors.remove_repeating();
		
		attribute_stream = std::move(stream.cut_at("}").explode(';'));
		ArrayList<Attribute> attributes;

		for (auto& line: attribute_stream) {
			String name = line.cut_at(":").trim();
			String value = line.trim();
			if (name.without(String::whitespace).size() > 0
			    && value.without(String::whitespace).size() > 0)
				attributes.append(Attribute(name, line));
		}

		if (attributes.size() > 0) {
			//DEBUG: Section s(selectors, attributes);
			//print_section(s);
			sections.append(std::move(Section(selectors, attributes)));
		}
		
	} while (selectors.size() > 0 && attribute_stream.size() > 0);

}

void Stylesheet::print_section(Stylesheet::Section& s) {
	std::cout << "-------SECTION:--------\n";
	std::cout << "Selectors: ";
	for (auto& s: s.selectors)
		std::cout << "[" << s << "] ";
	std::cout << "\nAttributes:\n";
	for (auto& a: s.attributes)
		std::cout << "[" << a.name << "] -> [" << a.value << "]\n"; 
}

void Stylesheet::print() {
	for (auto& section: sections) {
		print_section(section);
	}
}

ArrayList<Stylesheet::Section>& Stylesheet::get_data() {
	return sections;
}
