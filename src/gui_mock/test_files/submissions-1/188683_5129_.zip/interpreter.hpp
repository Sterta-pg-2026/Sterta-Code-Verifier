#pragma once

#include "stylesheet.hpp"
#include "string.hpp"
#include <istream>

class Interpreter {
	Stylesheet css;
	String DEFAULT_COMMAND = "****";
	
	struct Command {
		String action;
		String arg1;
		String arg2;

		Command(String&);
	};

protected:
	void dispatch_selector_command(const Command&);
	void dispatch_attribute_command(const Command&);
	void dispatch_delete_command(const Command&);

	template <typename T>
	void print_output(Command, T);

	int count_sections();
	
	int count_all_selectors(int section);
	int count_selector(const String&);
	String get_selector(int block_no, int selector_no);
	
	String get_attribute_value(String selector, String name);
	String get_attribute_value(int section_no, String name);
	int count_attribute(String name);
	int count_all_attributes(int section);

	bool remove(int index);
	bool remove(int index, String name);
	
public:
	void load_input(std::istream&);
	void interpret_commands(String&);
};
