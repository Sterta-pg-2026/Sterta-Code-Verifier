#pragma once

#include "list.hpp"
#include <ostream>

template <typename T>
class ArrayList {
	struct Block {
		static const int SIZE = 17;
		T memory[SIZE];

		Block() = default;
		Block(const T&);
	};
	
	List<Block> blocks;
	int count = 0;

	class Iterator {
		using iterator_category = std::bidirectional_iterator_tag;
		using difference_type   = std::ptrdiff_t;
		using value_type        = T;
		using pointer           = T*;
		using reference         = T&;

		int index;
		int block_no;
		decltype(blocks.begin()) block;
		
	public:
		Iterator() = default;

		Iterator(int init, decltype(blocks.begin()) iter) {
			index = init;
			block_no = init / Block::SIZE;
			block = iter;
		};
		
		reference operator*() const {
			return (*block).memory[index % Block::SIZE];
		}
		pointer   operator->() {
			return &(*block).memory[index % Block::SIZE];
		}
		Iterator& operator++() {
			index++;
			if (index/8 > block_no) {
				block++;
				block_no++;
			}
			return *this;
		}
		Iterator  operator++(int) {
			auto tmp = *this;
			++(*this);
			return tmp;
		}
		Iterator& operator--() {
			index--;
			if (index/8 < block_no) {
				block--;
				block_no--;
			}
			return *this;
		}
		Iterator  operator--(int) {
			auto tmp = *this;
			--(*this);
			return tmp;
		}
		bool operator==(const Iterator& iter) {
			return (index == iter.index); 
		}
		bool operator!=(const Iterator& iter) {
			return !(*this == iter);
		}
	};
	
public:
	ArrayList() = default;
	ArrayList(std::initializer_list<T>);
	ArrayList(const List<T>&);
	
	Iterator begin() const;
	Iterator end() const;
	
	void append(const T&);
	void push_back(const T&);
	void clear();
	T pop();
	T first() const;
	T& front();
	T last() const;
	T& back();
	int size() const;
	int length() const;
	T& get(int);
	T  get(int) const;
	T remove(int);
	void insert_at(int, const T&);
	bool contains(const T&) const;
	void remove_repeating();

	template <typename U>
friend std::ostream& operator<<(std::ostream&, const ArrayList<U>&);

	ArrayList<T>& map_this(std::function<T(T)>);
	ArrayList<T>  map(std::function<T(T)>) const;
	ArrayList<T>& filter_this(std::function<bool(T)>);
	ArrayList<T>  filter(std::function<bool(T)>) const;
	T fold(std::function<T(T, T)>) const;
	
	int count_matching(std::function<bool(const T&)>) const;
};

#include "arraylist_templates.hpp"
