template <typename T>
ArrayList<T>::ArrayList(std::initializer_list<T> init) {
	for (auto& element: init)
		append(element);
}

template <typename T>
ArrayList<T>::ArrayList(const List<T>& init) {
	for (auto& element: init)
		append(element);
}

template <typename T>
typename ArrayList<T>::Iterator ArrayList<T>::begin() const {
	return ArrayList<T>::Iterator(0, blocks.begin());
}

template <typename T>
typename ArrayList<T>::Iterator ArrayList<T>::end() const {
	return ++ArrayList<T>::Iterator(count-1, --blocks.end());
}

template <typename T>
ArrayList<T>::Block::Block(const T& element) {
	memory[0] = element;
}

template <typename T>
void ArrayList<T>::append(const T& element) {
	if (count/Block::SIZE >= blocks.size())
		blocks.append(Block(element));
	else
		blocks.back().memory[count%Block::SIZE] = element;

	count++;
}

template <typename T>
inline void ArrayList<T>::push_back(const T& element) {
	append(element);
}

template <typename T>
inline void ArrayList<T>::clear() {
	blocks.clear();
	count = 0;
}

template <typename T>
T ArrayList<T>::pop() {
	T element = last();
	
	if (count%Block::SIZE == 1)
		blocks.pop();

	count--;
	return element;
}

template <typename T>
inline T ArrayList<T>::first() const {
	return blocks.first().memory[0];
}

template <typename T>
inline T& ArrayList<T>::front() {
	return blocks.first().memory[0];
}

template <typename T>
inline T ArrayList<T>::last() const {
	return blocks.last().memory[(count - 1)%Block::SIZE];
}

template <typename T>
inline T& ArrayList<T>::back() {
	return blocks.last().memory[(count - 1)%Block::SIZE];
}

template <typename T>
inline int ArrayList<T>::size() const {
	return count;
}

template <typename T>
inline int ArrayList<T>::length() const {
	return count;
}

template <typename T>
T& ArrayList<T>::get(int index) {
	return blocks.get(index/Block::SIZE).memory[index%Block::SIZE];
}

template <typename T>
T ArrayList<T>::get(int index) const {
	return blocks.get(index/Block::SIZE).memory[index%Block::SIZE];
}

template <typename T>
inline void swap(T& a, T& b) {
	T temp = a;
	a = b;
	b = temp;
}

template <typename T>
T ArrayList<T>::remove(int index) {
	if (index == count-1)
		return pop();
	
	T element = get(index);
	T move = pop();
	int reverse_index = count - index;

	auto it = --end();

	while (reverse_index--) {
		swap(move, *it);
		it--;
	}
	
	return element;
}

template <typename T>
std::ostream& operator<<(std::ostream& out, const ArrayList<T>& list) {
	if (list.size() != 0) {
		auto it = list.begin();
		auto it_end = --list.end();
	
		while (it != it_end)
			out << *it++ << " "; 
		out << *it;
	}

	return out;
}

template <typename T>
ArrayList<T>& ArrayList<T>::map_this(std::function<T(T)> f) {
	for (auto& element: *this)
		element = f(element);
	return *this;
}

template <typename T>
ArrayList<T> ArrayList<T>::map(std::function<T(T)> f) const {
	auto result = *this;
	for (auto& element: result)
		element = f(element);
	return result;
}

template <typename T>
ArrayList<T>& ArrayList<T>::filter_this(std::function<bool(T)> cond) {
	return (*this = filter(cond));
}

template <typename T>
ArrayList<T> ArrayList<T>::filter(std::function<bool(T)> cond) const {
	ArrayList<T> result;
	for (const auto& element: *this)
		if (cond(element))
			result.append(element);
	return result;
}

template <typename T>
T ArrayList<T>::fold(std::function<T(T, T)> combine) const {
	T result = first();

	for (auto iter = ++begin(); iter != end(); iter++)
		result = combine(result, *iter);
		
	return result;
}

template <typename T>
int ArrayList<T>::count_matching(std::function<bool(const T&)> cond) const {
	int result = 0;
	for (auto& element: *this)
		if (cond(element))
			result++;

	return result;
}

template <typename T>
void ArrayList<T>::remove_repeating() {
	ArrayList<T> found;
	for (auto& element: *this)
		if (!found.contains(element))
			found.append(element);

	*this = std::move(found);
}

template <typename T>
bool ArrayList<T>::contains(const T& value) const {
	for (auto& element: *this)
		if (element == value)
			return true;

	return false;
}
