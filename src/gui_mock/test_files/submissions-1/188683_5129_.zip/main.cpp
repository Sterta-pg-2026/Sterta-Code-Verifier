#include "interpreter.hpp"
#include "list.hpp"
#include <iostream>

auto main() -> int {
	//std::ios::sync_with_stdio(false);
	Interpreter program;
	program.load_input(std::cin);
}
