#pragma once

#include "list.hpp"
#include "arraylist.hpp"
#include "string.hpp"

class Stylesheet {
	struct Attribute {
		String name;
		String value;

		Attribute() = default;
		Attribute(const String& n, const String& v)
			: name(n), value(v) {}
	};

	struct Section {
		ArrayList<String> selectors;
		ArrayList<Attribute> attributes;

		Section() = default;
		Section(const ArrayList<String>& s, const ArrayList<Attribute>& a)
			: selectors(s), attributes(a) {}
	};

	ArrayList<Section> sections;

public:
	void process(String&);
	void print();
	void print_section(Section&);
	ArrayList<Section>& get_data();
};
