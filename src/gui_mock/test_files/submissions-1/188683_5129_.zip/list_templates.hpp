template <typename T>
typename List<T>::Iterator List<T>::begin() const {
	return Iterator(root->next);
}

template <typename T>
typename List<T>::Iterator List<T>::end() const {
	return Iterator(tail);
}

template <typename T>
void List<T>::init() {
	root = new List<T>::Node();
	tail = new List<T>::Node();
	
	root->next = tail;
	tail->prev = root;

	count = 0;
}

template <typename T>
void List<T>::destroy() {
	decltype(root) ptr;
	while (root != nullptr) {
		ptr = root->next;
		delete root;
		root = ptr;
	}
}

template <typename T>
List<T>::List() {
	init();
}

template <typename T>
List<T>::List(std::initializer_list<T> init)
: List<T>::List() {
	for (const auto& item: init)
		append(item);
}

template <typename T>
List<T>::List(const List<T>& source)
: List<T>::List() {
	*this = source;
}

template <typename T>
List<T>::List(List<T>&& source) {
	root = source.root;
	tail = source.tail;
	count = source.count;

	source.root = nullptr;
	source.tail = nullptr;
	source.count = 0;
}

template <typename T>
List<T>::~List() {
	destroy();
}

template <typename T>
List<T>& List<T>::operator=(const List<T>& source) {
	clear();
	
	for (const auto& element: source)
		append(element);
	
	return *this;
}

template <typename T>
typename List<T>::Node* List<T>::get_node(int index) const {
	decltype(root) ptr;

	if (index < count/2) {
		ptr = root->next;
		while (index--)
			ptr = ptr->next;
	}
	else {
		ptr = tail->prev;
		index = count - index-1;
		while (index--)
			ptr = ptr->prev;
	}

	return ptr;
}

template <typename T>
void List<T>::clear() {
	destroy();
	init();
}

template <typename T>
void List<T>::append(const T& value) {
	auto back = tail->prev;
	back->next = new List<T>::Node(value);
	back->next->prev = back;
	back->next->next = tail;
	tail->prev = back->next;
	
	count++;
}

template <typename T>
void List<T>::append(const List<T>& list) {
	for (auto& element: list)
		append(element);
}

template <typename T>
inline void List<T>::push_back(const T& value) {
	append(value);
}

template <typename T>
T List<T>::pop() {
	auto back = tail->prev;
	T val = back->value;
	back = back->prev;
	delete back->next;
	count--;
	back->next = tail;
	tail->prev = back;
	return val;
}

template <typename T>
T List<T>::pop_front() {
	auto front = root->next;
	T val = front->value;
	front = front->next;
	delete front->prev;
	count--;
	front->prev = root;
	root->next = front;
	return val;
}

template <typename T>
inline T List<T>::first() const {
	return root->next->value;
}

template <typename T>
inline T& List<T>::front() {
	return root->next->value;
}

template <typename T>
inline T List<T>::last() const {
	return tail->prev->value;
}

template <typename T>
inline T& List<T>::back() {
	return tail->prev->value;
}

template <typename T>
inline int List<T>::size() const {
	return count;
}

template <typename T>
inline int List<T>::length() const {
	return size();
}

template <typename T>
T& List<T>::get(int index) {
	return get_node(index)->value;
}

template <typename T>
T List<T>::get(int index) const {
	return get_node(index)->value;
}

template <typename T>
T List<T>::remove_node(Node*& node) {
	node->prev->next = node->next;
	if (node->next != nullptr)
		node->next->prev = node->prev;

	T removed = node->value;
	delete node;
	count--;
	
	return removed;
}

template <typename T>
inline T List<T>::remove(int index) {
	return remove_node(get_node(index));
}

template <typename T>
inline T List<T>::remove(Iterator it) {
	return remove_node(it.raw_ptr);
}

template <typename T>
void List<T>::insert_at(int index, const T& value) {
	auto ptr = root;
	while (index--)
		ptr = ptr->next;

	auto temp = ptr->next;
	ptr->next = new Node(value);
	ptr->next->prev = ptr;
	ptr->next->next = temp;

	if (temp != nullptr)
		temp->prev = ptr->next;

	count++;
}

template <typename T>
List<T> List<T>::split_at(List<T>::Iterator it) {
	auto list_begin = root->next;
	
	root->next = it.raw_ptr->next;
	it.raw_ptr->next->prev = root;
	count -= it.index + 1;

	List<T> result;
	result.root->next = list_begin;
	list_begin->prev = result.root;
	result.tail->prev = it.raw_ptr;
	it.raw_ptr->next = result.tail;
	result.count = it.index + 1;

	return result;
}

template <typename T>
bool List<T>::contains(const T& value) const {
	for (auto& element: *this)
		if (element == value)
			return true;

	return false;
}

template <typename T>
inline List<T> List<T>::operator+(const List<T>& list) const {
	List<T> copy = *this;
	copy.append(list);
	return copy;
}

template <typename T>
inline List<T>& List<T>::operator+=(const List<T>& list) {
	append(list);
	return *this;
}

template <typename T>
List<T>& List<T>::map_this(std::function<T(T)> f) {
	for (auto& element: *this)
		element = f(element);
	return *this;
}

template <typename T>
List<T> List<T>::map(std::function<T(T)> f) const {
	auto result = *this;
	for (auto& element: result)
		element = f(element);
	return result;
}

template <typename T>
List<T>& List<T>::filter_this(std::function<bool(T)> cond) {
	*this = std::move(filter(cond));
	return *this;
}

template <typename T>
List<T> List<T>::filter(std::function<bool(T)> cond) const {
	List<T> result;
	for (const auto& element: *this)
		if (cond(element))
			result.append(element);
	return result;
}

template <typename T>
T List<T>::fold(std::function<T(T, T)> combine) const {
	if (size() == 0)
		return T();
	
	T result = first();

	for (auto iter = ++begin(); iter != end(); iter++)
		result = combine(result, *iter);
		
	return result;
}

template <typename T>
std::ostream& operator<<(std::ostream& out, const List<T>& list) {
	if (list.size() != 0) {
		auto back = --list.end();
		for (auto it = list.begin(); it != back; it++)
			out << *it << " ";
		out << *back;
	}

	return out;
}

template <typename T>
int List<T>::count_matching(std::function<bool(const T&)> cond) const {
	int result = 0;
	for (auto& element: *this)
		if (cond(element))
			result++;

	return result;
}

template <typename T>
void List<T>::remove_repeating() {
	List<T> found;
	for (auto& element: *this)
		if (!found.contains(element))
			found.append(element);

	*this = std::move(found);
}
