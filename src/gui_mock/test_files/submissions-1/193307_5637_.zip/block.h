#pragma once
#include <iostream>

const int BLOCK_SIZE = 8;

template <typename T>class Block
{
	T* data[BLOCK_SIZE];
	size_t size;
	Block<T>* next;
	Block<T>* prev;
public:
	Block();
	Block(Block<T>&);
	~Block();
	T& operator[](size_t);
	T* getElement(size_t);
	void setNext(Block<T>*);
	void setPrev(Block<T>*);
	Block<T>* getNext();
	Block<T>* getPrev();
	void add(T*);
	void remove(size_t);
	void removeByElement(T);
	void replaceElement(T*);
	size_t getSize() const;
	bool hasElement(T*) const;
	size_t getElementsIndex(T*)const;
	T* findElement(T*)const;
	bool isFull();
};

//template<typename T>
//bool operator==(const T& right, const T& left)
//{
//	return right == left;
//}

template<typename T>
inline Block<T>::Block()
{
	size = 0;
	next = nullptr;
	prev = nullptr;
	for (int i = 0; i < BLOCK_SIZE;i++)
	{
		data[i] = nullptr;
	}
}

template<typename T>
inline Block<T>::Block(Block<T>& block)
{
	Block();
	size = block.size;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		*data[i] = *block.data[i];
	}
	next = nullptr;
	prev = nullptr;
}

template<typename T>
Block<T>::~Block()
{
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (data[i] != nullptr)
		{
			delete data[i];
		}
	}
	next = nullptr;
	prev = nullptr;
	size = 0;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		data[i] = nullptr;
	}
}

template<typename T>
T& Block<T>::operator[](size_t index)
{
	if (index < size)
	{
		return data[index];
	}
	else throw;
}

template<typename T>
T* Block<T>::getElement(size_t index)
{
	if (index < BLOCK_SIZE)
	{
		size_t elementIndex = 0;
		for (int i = 0; i < BLOCK_SIZE; i++)
		{
			if (data[i] != nullptr)
			{
				if (elementIndex == index)
				{
					return data[i];
				}
				elementIndex++;
			}
		}
		return nullptr;
	}
	else throw;
}

template<typename T>
void Block<T>::setNext(Block<T>* next)
{
	this->next = next;
	if (next != nullptr)
	{
		next->prev = this;
	}
}

template<typename T>
void Block<T>::setPrev(Block<T>* prev)
{
	this->prev = prev;
	if (prev != nullptr)
	{
		prev->next = this;
	}
}

template<typename T>
Block<T>* Block<T>::getNext()
{
	return next;
}

template<typename T>
Block<T>* Block<T>::getPrev()
{
	return prev;
}


template<typename T>
void Block<T>::add(T* newElement)
{
	size_t index = BLOCK_SIZE;
	for (int i = BLOCK_SIZE-1; i >= 0; i--)
	{
		if (data[i] == nullptr)
		{
			index--;
		}
		else
		{
			break;
		}
	}
		data[index] = newElement;
		size++;
}

template<typename T>
void Block<T>::remove(size_t index)
{
	if (index < size)
	{
		size_t elementIndex = 0;
		for (int i = 0; i < BLOCK_SIZE; i++)
		{
			if (data[i] != nullptr)
			{
				if (elementIndex == index)
				{
					data[i] = nullptr;
					size--;
					return;
				}
				elementIndex++;
			}
		}
	}
	else throw;
}

template<typename T>
void Block<T>::removeByElement(T element)
{
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (data[i]!=nullptr && * data[i] == element)
		{
			data[i] = nullptr;
			size--;
			return;
		}
	}
}

template<typename T>
inline void Block<T>::replaceElement(T* element)
{
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (*data[i] == *element)
		{
			data[i] = element;
			return;
		}
	}
	return;
}

template<typename T>
size_t Block<T>::getSize() const
{
	return size;
}

template<typename T>
bool Block<T>::hasElement(T* element)const
{
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (data[i] != nullptr && *data[i] == *element)
		{
			return true;
		}
	}
	return false;
}

template<typename T>
inline size_t Block<T>::getElementsIndex(T* element) const
{
	size_t elementsIndex = 0;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (data[i] != nullptr)
		{
			if (*data[i] == *element)
			{
				return elementsIndex;
			}
			else
			{
				elementsIndex++;
			}
		}
	}
}

template<typename T>
inline T* Block<T>::findElement(T* element) const
{
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (data[i] != nullptr && *data[i] == *element)
		{
			return data[i];
		}		
	}
	return nullptr;
}

template<typename T>
inline bool Block<T>::isFull()
{
	return data[BLOCK_SIZE - 1] != nullptr;
}

