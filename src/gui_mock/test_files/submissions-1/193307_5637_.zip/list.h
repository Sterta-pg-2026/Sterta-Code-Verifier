
#include <iostream>
#include "block.h"
template <typename T>class List
{
	Block<T>* firstBlock;
	Block<T>* lastBlock;
	size_t size;
	size_t elementNumber;

	Block<T>* findBlock(size_t& index) const;
	void InsertFirst(T*);
	void deleteEmptyBlock(Block<T>*);
	
public:
	List();
	~List();
	void InsertAfter(T&);
	void InsertBefore(T&);
	T* getFirstElement();
	Block<T>* getFirstBlock();
	Block<T>* getLastBlock();
	size_t getSize();
	T& operator[](size_t index);
	bool operator==(const List<T>& right)
	{
		if (this->getElementNumber() != right.getElementNumber())
		{
			return false;
		}
		else
		{
			for (size_t i = 0; i < right.getElementNumber(); i++)
			{
				if (*this->getElement(i) != *right.getElement(i))
				{
					return false;
				}
			}
		}
		return true;
	}
	T* getElement(size_t index) const;
	void deleteElement(size_t index);
	void deleteElement(T*);
	void replaceElement(T*);
	void clear();
	size_t getElementNumber() const;
	bool hasElement(T*);
	size_t getElementsIndex(T*);
	T* findElement(T*);
};

template<typename T>
Block<T>* List<T>::findBlock(size_t& index) const
{
	if (index < elementNumber)
	{
		Block<T>* tmp = firstBlock;
		while (index >= tmp->getSize())
		{
			index -= tmp->getSize();
			tmp = tmp->getNext();
		}
		return tmp;
	}
	else throw;

}
template<typename T>
inline List<T>::List()
{
	size = 0;
	elementNumber = 0;
	firstBlock = nullptr;
	lastBlock = nullptr;
}



template<typename T>
List<T>::~List()
{
	while (size != 0)
	{
		Block<T>* temp = firstBlock;
		firstBlock = temp->getNext();
		delete temp;
		size--;
	}
	firstBlock = nullptr;
	lastBlock = nullptr;
}

template<typename T>
void List<T>::InsertAfter(T &data)
{
	T* newElement = &data;
	if (size == 0)
	{
		InsertFirst(newElement);
	}
	else
	{
		if (!lastBlock->isFull())
		{
			lastBlock->add(newElement);
		}
		else
		{
			Block<T>* newBlock = new Block<T>;
			newBlock->add(newElement);
			size++;
			lastBlock->setNext(newBlock);
			newBlock->setPrev(lastBlock);
			lastBlock = newBlock;
		}
	}
	elementNumber++;
}

template<typename T>
void List<T>::InsertBefore(T &data)
{
	T* newElement = new T;
	*newElement = data;
	if (size == 0)
	{
		InsertFirst(newElement);
	}
	else
	{
		if (firstBlock->getSize() != BLOCK_SIZE)
		{
			firstBlock->add(newElement);
		}
		else
		{
			Block<T>* newBlock = new Block<T>;
			newBlock->add(newElement);
			size++;
			firstBlock->setPrev(newBlock);
			newBlock->setNext(firstBlock);
			firstBlock = newBlock;
		}
	}
	elementNumber++;
}

template<typename T>
inline T* List<T>::getFirstElement()
{
	return firstBlock->getElement(0);
}

template<typename T>
inline Block<T>* List<T>::getFirstBlock()
{
	return firstBlock;
}

template<typename T>
inline Block<T>* List<T>::getLastBlock()
{
	return lastBlock;
}

template<typename T>
inline size_t List<T>::getSize()
{
	return size;
}

template<typename T>
T& List<T>::operator[](size_t index)
{
	if (index < elementNumber)
	{
		Block<T>* tmp = findBlock(index);
		return *tmp->getElement(index);
	}
	else throw;
}


template<typename T>
T* List<T>::getElement(size_t index) const
{
	if (index < elementNumber)
	{
		Block<T>* tmp = findBlock(index);
		return tmp->getElement(index);
	}
	else throw;
}

template<typename T>
void List<T>::deleteElement(size_t index)
{
	if (elementNumber > 0 && index < elementNumber)
	{
		Block<T>* tmp = findBlock(index);
		tmp->remove(index);
		elementNumber--;
		deleteEmptyBlock(tmp);
	}
	else throw;
}

template<typename T>
void List<T>::deleteElement(T* element)
{
	Block<T>* temp = firstBlock;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (temp->hasElement(element))
		{
			temp->removeByElement(*element);
			elementNumber--;
			deleteEmptyBlock(temp);
			return;
		}
		temp = temp->getNext();
	}
	return;
}

template<typename T>
inline void List<T>::replaceElement(T* element)
{
	Block<T>* temp = firstBlock;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (temp->hasElement(element))
		{
			temp->replaceElement(element);
			return;
		}
		temp = temp->getNext();
	}
	return;
}

template<typename T>
void List<T>::clear()
{
	while (elementNumber != 0)
	{
		size_t tmp = 0;
		deleteElement(tmp);
	}
}

template<typename T>
size_t List<T>::getElementNumber() const
{
	return elementNumber;
}

template<typename T>
bool List<T>::hasElement(T* element)
{
	Block<T>* temp = firstBlock;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < temp->getSize(); j++)
		{
			if (*element == *temp->getElement(j))
			{
				return true;
			}
		}
		temp = temp->getNext();
	}
	return false;
}

template<typename T>
inline size_t List<T>::getElementsIndex(T* element)
{
	size_t index = 0;
	Block<T>* temp = firstBlock;
	for (int i = 1; i < size; i++)
	{
		if (temp->hasElement(element))
		{
			return index + temp->getElementsIndex(element);
		}
		else
		{
			index += temp->getSize();
			temp = temp->getNext();
		}
	}
	return -1;
}

template<typename T>
inline T* List<T>::findElement(T*element)
{
	Block<T>* temp = firstBlock;
	for (int i = 0; i < BLOCK_SIZE; i++)
	{
		if (temp->hasElement(element))
		{
			return temp->findElement(element);
		}
		temp = temp->getNext();
	}
	return nullptr;
}


template<typename T>
void List<T>::InsertFirst(T* newElement)
{
	Block<T>* newBlock = new Block<T>;
	newBlock->add(newElement);
	firstBlock = newBlock;
	lastBlock = newBlock;
	size++;
}

template<typename T>
void List<T>::deleteEmptyBlock(Block<T>* tmp)
{
	if (tmp->getSize() == 0)
	{
		if (tmp == firstBlock && tmp == lastBlock)
		{
			firstBlock = nullptr;
			lastBlock = nullptr;
		}
		else if (tmp == firstBlock)
		{
			firstBlock = tmp->getNext();
			firstBlock->setPrev(nullptr);
		}
		else if (tmp == lastBlock)
		{
			lastBlock = tmp->getPrev();
			lastBlock->setNext(nullptr);
		}
		else
		{
			tmp->getNext()->setPrev(tmp->getPrev());
			tmp->getPrev()->setNext(tmp->getNext());
		}
		size--;
	}
}