#include "program.h"

List<char>* Program::getLine(bool& quitProgram)
{
	char* ch = new char;
	*ch = getchar();
	List<char>* line= new List<char>;
	while (*ch != '\n')
	{
		if (*ch == EOF)
		{
			quitProgram = true;
			return line;
		}
		line->InsertAfter(*ch);
		ch = new char;
		*ch = getchar();	
	}
	return line;
}

Program::Program()
{
	sections = new List<CSS_Section>;
}

void Program::run()
{
	bool quitProgram = false;
	while (!quitProgram)
	{
		readCSS(quitProgram);
		if (quitProgram)break;
		handleCommands(quitProgram);
	}
}
void Program::handleCommands(bool& quitProgram)
{
	bool quit = false;
	while (quit == false&&quitProgram==false)
	{
		List<char>* instructionParts[INSTRCUTION_PARTS_SIZE];
		for (int i = 0; i < INSTRCUTION_PARTS_SIZE; i++)
		{
			instructionParts[i] = new List<char>;
		}
		List<char>* line = getLine(quitProgram);
		if (!isCommandValid(*line)) continue;
		getInstructionParts(*line,instructionParts);
		executeCommands(quit, instructionParts);
		delete line;
	}
}

void Program::executeCommands(bool& quit, List<char>* instructionParts[INSTRCUTION_PARTS_SIZE])
{
	//instructionParts += 2;
	if (instructionParts[0]->getElementNumber() == 0) return;
	else if (*instructionParts[0]->getElement(0) == '*')
	{
		quit = true;
	}
	else
	{
		if (*instructionParts[0]->getElement(0) == '?')
		{
			printSectionNumber();
		}
		else if (instructionParts[1]->getElementNumber() != 0 && instructionParts[2]->getElementNumber() != 0)
		{
			if (*instructionParts[2]->getElement(0) == '?')
			{
				if (*instructionParts[1]->getElement(0) == 'S')
				{
					if (isNumber(instructionParts[0]))
					{
						printSelectorsNumberForIthSection(toNumber(instructionParts[0]));
					}
					else
					{
						printNumberOfSelectorOccurances(new Selector(*instructionParts[0]));
					}
				}
				else if (*instructionParts[1]->getElement(0) == 'A')
				{
					if (isNumber(instructionParts[0]))
					{
						printAttributesNumberForIthSection(toNumber(instructionParts[0]));
					}
					else
					{
						Attribute* attribute = new Attribute();
						attribute->setName(*instructionParts[0]);
						printNumberOfAttributeOccurances(attribute);
					}
				}
			}
			else if (*instructionParts[2]->getElement(0) == '*')
			{
				deleteSection(toNumber(instructionParts[0]));
			}
			else if (isNumber(instructionParts[2])&& *instructionParts[1]->getElement(0) == 'S')
			{
				printJthSelectorofIthSection(toNumber(instructionParts[0]), toNumber(instructionParts[2]));
			}
			else
			{
				switch (*instructionParts[1]->getElement(0))
				{
				case 'A':
					printNnamedAttributeforIthsection(toNumber(instructionParts[0]), instructionParts[2]);
					break;
				case 'E':
					printValueOfNnamedAttributeofZSelector(instructionParts[2], new Selector(*instructionParts[0]));
					break;
				case 'D':
					Attribute * attribute = new Attribute(*instructionParts[2]);
					deleteNnamedAttributefromIthSection(toNumber(instructionParts[0]), attribute);
					break;
				}
			}
		}
	}
}

void Program::getInstructionParts(List<char> &line, List<char>*instructionParts[INSTRCUTION_PARTS_SIZE])
{
	size_t lineIndex = 0;
	size_t instructionIndex = 0;
	List<char> *part = new List<char>;
	while (lineIndex != line.getElementNumber())
	{
		if (line[lineIndex] == ',')
		{
			for (int i = 0; i < part->getElementNumber(); i++)
			{
				instructionParts[instructionIndex]->InsertAfter(*part->getElement(i));
			}
			part->clear();
			instructionIndex++;
		}
		else
		{
			char* temp = new char(line[lineIndex]);
			part->InsertAfter(*temp);
		}
		lineIndex++;
	}
	for (int i = 0; i < part->getElementNumber(); i++)
	{
		instructionParts[instructionIndex]->InsertAfter(*part->getElement(i));
	}
}

void Program::printSectionNumber()
{
	std::cout<<"? == "<<sections->getElementNumber()<<std::endl;
}

void Program::printSelectorsNumberForIthSection(size_t i)
{
	if (i <= sections->getElementNumber())
	{
		std::cout << i-- << ",S,? == ";
		std::cout<<sections->getElement(i)->getSelectors()->getElementNumber() << std::endl;
	}
}

void Program::printAttributesNumberForIthSection(size_t i)
{
	if (i <= sections->getElementNumber())
	{
		std::cout << i-- << ",A,? == ";
		std::cout<<sections->getElement(i)->getAttributes()->getElementNumber() << std::endl;
	}
}

void Program::printJthSelectorofIthSection(size_t i, size_t j)
{
	if (i <= sections->getElementNumber() && j <= sections->getElement(i-1)->getSelectors()->getElementNumber())
	{
		{
			std::cout << i-- << ",S," << j-- << " == ";
			printCharList(sections->getElement(i)->getSelectors()->getElement(j)->getName());
			std::cout << std::endl;
		}
	}
	
}

void Program::printNnamedAttributeforIthsection(size_t i, List<char>* name)
{
	Attribute* attribute = new Attribute();
	attribute->setName(*name);
	if (sections->getElement(i-1)->getAttributes()->hasElement(attribute))
	{
		std::cout << i--<< ",A,"; 
		printCharList(name);
		std::cout << " == ";
		printCharList(sections->getElement(i)->findValueOfNnamedAttribute(name));
		std::cout << std::endl;
	}
}

void Program::printNumberOfAttributeOccurances(Attribute *attribute)
{
	int number = 0;
	Block<CSS_Section>* temp = sections->getFirstBlock();
	for (int i = 0; i < sections->getSize(); i++)
	{
		for (int j = 0; j < temp->getSize(); j++)
		{
			List<Attribute>* attributes = temp->getElement(j)->getAttributes();
			if (attributes->hasElement(attribute))
			{
				number++;
			}
		}
		if (i != sections->getSize() - 1)
		{
			temp = temp->getNext();
		}
	}
	printCharList(attribute->getName());
	std::cout << ",A,? == " << number << std::endl;
}

void Program::printNumberOfSelectorOccurances(Selector* selector)
{
	int number = 0;
	Block<CSS_Section>* temp = sections->getFirstBlock();
	for (int i = 0; i < sections->getSize(); i++)
	{
		for (int j = 0; j < temp->getSize(); j++)
		{
			List<Selector>* selectors = temp->getElement(j)->getSelectors();
			if (selectors->hasElement(selector))
			{
				number++;
			}
		}
		if (i != sections->getSize() - 1)
		{
			temp = temp->getNext();
		}
	}
	printCharList(selector->getName());
	std::cout << ",S,? == " << number << std::endl;
}

void Program::printValueOfNnamedAttributeofZSelector(List<char>*attributeName, Selector *selector)
{
	Block<CSS_Section>* temp = sections->getLastBlock();
	for (int i = sections->getSize() - 1; i >= 0; i--)
	{
		for (int j = temp->getSize()-1; j >=0 ; j--)
		{
			List<Selector>* selectors = temp->getElement(j)->getSelectors();
			if (selectors->hasElement(selector))
			{
				if (selectors->hasElement(selector) || selectors->getElementNumber() == 0)
				{
					List<Attribute>* attributes = temp->getElement(j)->getAttributes();
					for (int k = 0; k < attributes->getSize(); k++)
					{
						if (*attributes->getElement(k)->getName() == *attributeName)
						{
							printCharList(selector->getName());
							std::cout << ",E,";
							printCharList(attributeName);
							std::cout << " == ";
							printCharList(attributes->getElement(k)->getValue());
							std::cout << std::endl;
							return;
						}
					}
				}
			}
		}
		if (i != 0)
		{
			temp = temp->getPrev();
		}
	}
}

void Program::deleteSection(size_t i)
{
	if (i <= sections->getElementNumber())
	{
		std::cout << i-- << ",D,* == ";
		sections->deleteElement(i);
		std::cout << "deleted" << std::endl;
	}
}

void Program::deleteNnamedAttributefromIthSection(size_t i, Attribute *attribute)
{
	if (sections->getElementNumber() != 0&&i<= sections->getElementNumber())
	{
		i--;
		CSS_Section* section = sections->getElement(i);
		List<Attribute>* attributes = section->getAttributes();
		if (attributes->getElementNumber()!=0)
		{
			if (attributes->hasElement(attribute))
			{
				std::cout << i + 1 << ",D,";
				printCharList(attribute->getName());
				std::cout << " == ";
				//printCharList(attributes->findElement(attribute)->getValue());
				attributes->deleteElement(attribute);
				if (sections->getElement(i)->getAttributes()->getElementNumber() == 0)
				{
					sections->deleteElement(i);
					//std::cout << "Implicit delete";
				}
				std::cout << "deleted" << std::endl;
			}
		}
	}
}

bool Program::isNumber(List<char>* list)
{
	for (size_t i = 0; i < list->getElementNumber(); i++)
	{
		size_t temp = *list->getElement(i) - '0';
		if (temp < 0
			|| temp > 9) 
			return false;
	}
	return true;
}

size_t Program::toNumber(List<char>* list)
{
	size_t result = 0;
	for (size_t i = 0; i < list->getElementNumber(); i++)
	{
		result *= 10;
		result += ( *list->getElement(i) - '0');
	}
	return result;
}

void Program::printCharList(List<char> *writing)
{
	for (int i = 0; i < writing->getElementNumber(); i++)
	{
		std::cout << *writing->getElement(i);
	}
}

bool Program::isCommandValid(List<char>& line)
{
	size_t commaNumber = 0;
	for (size_t i = 0; i < line.getElementNumber(); i++)
	{
		if (line[i] == ',') commaNumber++;
	}
	if (commaNumber > 2)
	{
		return false;
	}
	else return true;
}

void Program::deleteWhiteCharsFromEnd(List<char>* line)
{
	while ((*line)[line->getElementNumber() - 1] <= ' ')
	{
		line->deleteElement(line->getElementNumber() - 1);
	}
}


void Program::readCSS(bool& quitProgram)
{
	bool quit = false;
	List<char>* line = new List<char>;
	List<Selector>* currentSelectors = new List<Selector>;
	List<Attribute>* currentAttributes = new List<Attribute>;
	bool selectorReadingMode = true;
	while (quit == false && quitProgram == false)
	{
		line = getLine(quitProgram);
		if (line->getElementNumber() > 0 && (*line)[line->getElementNumber() - 1] == EOF)
		{
			quitProgram = true;
			return;
		}
		size_t index = 0;
		if (selectorReadingMode)
		{
			selectorReadingMode = readSelectorsNames(quit, quitProgram, *line, *currentSelectors, index);
		}
		if(!selectorReadingMode)
		{
			selectorReadingMode = readAttributes(quit, quitProgram, *line, *currentAttributes, index);
			if (selectorReadingMode)
			{
				if (currentAttributes->getElementNumber() != 0)
				{
					CSS_Section* currentSection = new CSS_Section(currentSelectors, currentAttributes);
					sections->InsertAfter(*currentSection);
				}
				currentAttributes = new List<Attribute>;
				currentSelectors = new List<Selector>;
			}
		}
		delete line;
		line = new List<char>;
	}
}

bool Program::readSelectorsNames(bool&quit , bool&quitProgram, List<char>&line, List<Selector>& currentSelectors, size_t& index)
{
	Selector* currentSelector = new Selector();
	while (std::cin&& !quit && index != line.getElementNumber())
	{
		if (line[index] != ',' && line[index] != '{')
		{
			if (line[index] == '?')
			{
				setQuits(quit, quit);
			}
			else if (line[index] > ' ' || currentSelector->getName()->getElementNumber()!=0)
			{
				currentSelector->appendLetter(new char(line[index]));
			}
		}
		else
		{
			if (currentSelector->getName()->getElementNumber() != 0)
			{
				deleteWhiteCharsFromEnd(currentSelector->getName());
				if (!currentSelectors.hasElement(currentSelector))
				{
					currentSelectors.InsertAfter(*currentSelector);
					
				}
				currentSelector = new Selector();
			}
			if (line[index] == '{')
			{
				index++;
				return false;
			}
		}
		index++;
	}
	if (currentSelector->getName()->getElementNumber()!=0)
	{
		deleteWhiteCharsFromEnd(currentSelector->getName());
		if (!currentSelectors.hasElement(currentSelector))
		{
			currentSelectors.InsertAfter(*currentSelector);
		}
	}
	return true;
}

bool Program::readAttributes(bool& quit, bool&quitProgram, List<char>&line, List<Attribute>& currentAttributes,size_t&index)
{
	Attribute *currentAttribute = new Attribute();
	bool isAttributeValue = false;
	while (std::cin && !quit && index != line.getElementNumber())
	{
		if (line[index] != '}')
		{
			if (line[index] == ';')
			{
				deleteWhiteCharsFromEnd(currentAttribute->getName());
				deleteWhiteCharsFromEnd(currentAttribute->getValue());
				if (currentAttributes.hasElement(currentAttribute))
				{
					currentAttributes.replaceElement(currentAttribute);
				}
				else
				{
					currentAttributes.InsertAfter(*currentAttribute);
				}
				currentAttribute = new Attribute();
				isAttributeValue = false;
			}
			else if (line[index] == ':')
			{
				isAttributeValue = true;
			}
			else
			{
				if (line[index] > ' ' && !isAttributeValue)
				{
					currentAttribute->appendLetterToName(new char(line[index]));
				}
				else if (line[index] > ' ' || 
					currentAttribute->getValue()->getElementNumber() != 0)
				{
					currentAttribute->appendLetterToValue(new char(line[index]));
				}
			}
		}
		else
		{
			if (currentAttribute->getName()->getElementNumber() != 0 && currentAttribute->getValue()->getElementNumber()!=0)
			{
				deleteWhiteCharsFromEnd(currentAttribute->getName());
				deleteWhiteCharsFromEnd(currentAttribute->getValue());
				if (currentAttributes.hasElement(currentAttribute))
				{
					currentAttributes.replaceElement(currentAttribute);
				}
				else
				{
					currentAttributes.InsertAfter(*currentAttribute);
				}
			}
			return true;
		}
		index++;
	}
	if (currentAttribute->getValue()->getElementNumber() != 0)
	{
		deleteWhiteCharsFromEnd(currentAttribute->getName());
		deleteWhiteCharsFromEnd(currentAttribute->getValue());
		if (currentAttributes.hasElement(currentAttribute))
		{
			currentAttributes.replaceElement(currentAttribute);
		}
		else
		{
			currentAttributes.InsertAfter(*currentAttribute);
		}
		currentAttribute = new Attribute();
	}
	return false;
}



void Program::readGlobalAttribute(List<char>& line,List<Attribute>&currentAttributes, size_t&index)
{
	Attribute* currentAttribute = new Attribute();
	bool isAttributeValue = false;
	while (std::cin && index != line.getElementNumber())
	{
		if (line[index] == ';')
		{
			currentAttributes.InsertAfter(*currentAttribute);
			return;
		}
		else if (line[index] == ':')
		{
			isAttributeValue = true;
		}
		else
		{
			if (line[index] != ' ' && !isAttributeValue)
			{
				currentAttribute->appendLetterToName(new char(line[index]));
			}
			else if (line[index] != ' ' ||
				currentAttribute->getValue()->getElementNumber() != 0)
			{
				currentAttribute->appendLetterToValue(new char(line[index]));
			}
		}
		index++;
	}
}

void Program::setQuits(bool& quit, bool& quitProgram)
{
	quit = true;
	quitProgram = true;
}

