#pragma once
#include "attribute.h"
class Selector
{
	List<char>* name;
public:
	Selector();
	Selector(List<char>&);
	~Selector();
	void setName(List<char>&);
	bool operator==(Selector& selector) const
	{
		if (*this->name == *selector.name)
			return true;
		else return false;
	}
	void appendLetter(char*);
	void clear();
	List<char>* getName();
};

