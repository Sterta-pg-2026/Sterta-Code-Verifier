#include "selector.h"

Selector::Selector()
{
	name = new List<char>;
}

Selector::Selector(List<char> &name)
{
	this->name = new List<char>;
	for (int i = 0; i < name.getElementNumber(); i++)
	{
		appendLetter(new char(*name.getElement(i)));
	}
}

Selector::~Selector()
{
	delete name;
}

void Selector::setName(List<char>& name)
{
	*this->name = name;
}

void Selector::appendLetter(char *ch)
{
	name->InsertAfter(*ch);
}

void Selector::clear()
{
	name = nullptr;
	name = new List<char>;
}



List<char>* Selector::getName()
{
	return name;
}
