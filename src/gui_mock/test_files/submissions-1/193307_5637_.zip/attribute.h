#pragma once
#include "list.h"
class Attribute
{
	List<char> *name;
	List<char> *value;
public:
	Attribute();
	Attribute(List<char>&, List<char>&);
	Attribute(List<char>&);
	Attribute(Attribute&);
	~Attribute();
	void setName(List<char>&);
	void setValue(List<char>&);
	void appendLetterToName(char*);
	void appendLetterToValue(char*);
	void clear();
	List<char>* getName();
	List<char>* getValue();
	bool operator==(const Attribute&);
};

