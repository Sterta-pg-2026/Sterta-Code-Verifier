﻿
#include <iostream>
#include "program.h"

int main()
{
    Program program;
    program.run();
    return 0;
}