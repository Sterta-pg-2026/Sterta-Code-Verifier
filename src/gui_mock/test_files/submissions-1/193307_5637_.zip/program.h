#pragma once
#include "css_section.h"
#include<string>
#include<iostream>
const int INSTRCUTION_PARTS_SIZE = 3;
class Program
{
	List<CSS_Section> *sections;
	List<char>* getLine(bool &);
	void readCSS(bool&);
	bool readSelectorsNames(bool&, bool&, List<char>&, List<Selector>&, size_t&);
	bool readAttributes(bool&, bool&, List<char>&, List<Attribute>&, size_t&);
	void readGlobalAttribute(List<char>&, List<Attribute>&, size_t&);
	void setQuits(bool&, bool&);
	void handleCommands(bool&);
	void executeCommands(bool& quit,List<char>* instructionParts[INSTRCUTION_PARTS_SIZE]);
	void getInstructionParts(List<char> &,List<char>* instructionParts[INSTRCUTION_PARTS_SIZE]);
	void printSectionNumber();
	void printSelectorsNumberForIthSection(size_t);
	void printAttributesNumberForIthSection(size_t);
	void printJthSelectorofIthSection(size_t, size_t);
	void printNnamedAttributeforIthsection(size_t, List<char>*);
	void printNumberOfAttributeOccurances(Attribute*);
	void printNumberOfSelectorOccurances(Selector*);
	void printValueOfNnamedAttributeofZSelector(List<char>*, Selector*);
	void deleteSection(size_t);
	void deleteNnamedAttributefromIthSection(size_t, Attribute*);
	bool isNumber(List<char>*);
	size_t toNumber(List<char>*);
	void printCharList(List<char>*);
	bool isCommandValid(List<char>&);
	void deleteWhiteCharsFromEnd(List<char>*);
public:
	Program();
	void run();
};

