#include "attribute.h"

Attribute::Attribute()
{
	name = new List<char>;
	value = new List<char>;
}

Attribute::Attribute(List<char>& name, List<char>& value)
{
	*this->name = name;
	*this->value = value;
}

Attribute::Attribute(List<char>& name)
{
	this->name = new List<char>;
	for (int i = 0; i < name.getElementNumber(); i++)
	{
		this->name->InsertAfter(*name.getElement(i));
	}
	value = new List<char>;
}

Attribute::Attribute(Attribute& attribute)
{
	name = attribute.name;
	value = attribute.value;
}

Attribute::~Attribute()
{
	delete name;
	delete value;
}

void Attribute::setName(List<char>& name)
{
	*this->name = name;
}

void Attribute::setValue(List<char>& value)
{
	*this->value = value;
}

void Attribute::appendLetterToName(char *ch)
{
	name->InsertAfter(*ch);
}

void Attribute::appendLetterToValue(char *ch)
{
	value->InsertAfter(*ch);
}

void Attribute::clear()
{
	name = nullptr;
	value = nullptr;
	name = new List<char>;
	value = new List<char>;
}

List<char>* Attribute::getName()
{
	return name;
}

List<char>* Attribute::getValue()
{
	return value;
}

bool Attribute::operator==(const Attribute& attribute)
{
	if (*name == *attribute.name)
	{
		return true;
	}
	else return false;
}
