#pragma once
#include"selector.h"
#include "attribute.h"
class CSS_Section
{
	List<Selector> *selectors;
	List<Attribute> *attributes;
public:
	CSS_Section();
	CSS_Section(List<Selector>*, List<Attribute>*);
	~CSS_Section();
	void addAttribute(Attribute);
	void addSelector (Selector);
	Attribute* getAttribute(size_t);
	List<char>*  findValueOfNnamedAttribute(List<char>*);
	List<Selector>* getSelectors();
	List<Attribute>* getAttributes();
};

