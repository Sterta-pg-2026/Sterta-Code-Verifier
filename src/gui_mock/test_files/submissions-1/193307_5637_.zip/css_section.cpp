#include "css_section.h"

CSS_Section::CSS_Section()
{
}

CSS_Section::CSS_Section(List<Selector> *selectors, List<Attribute> *attributes)
{
	this->selectors = selectors;
	this->attributes=attributes;
}

CSS_Section::~CSS_Section()
{
	delete selectors;
	delete attributes;
}

void CSS_Section::addAttribute(Attribute attribute)
{
	attributes->InsertAfter(attribute);
}

void CSS_Section::addSelector(Selector selector)
{
	selectors->InsertAfter(selector);
}
Attribute* CSS_Section::getAttribute(size_t index)
{
	return attributes->getElement(index);
}

List<char>* CSS_Section::findValueOfNnamedAttribute(List<char>* name)
{
	for (int i = 0; i < attributes->getElementNumber(); i++)
	{
		Attribute *attribute = attributes->getElement(i);
		if (*attribute->getName() == *name)
		{
			return attribute->getValue();
		}
	}
	return nullptr;
}

List<Selector>* CSS_Section::getSelectors()
{
	return selectors;
}

List<Attribute>* CSS_Section::getAttributes()
{
	return attributes;
}
