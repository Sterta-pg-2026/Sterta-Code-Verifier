#include <iostream>
using namespace std;

class Node {
public:
    char* data;
    Node* prev, * next;

public:
    Node(char* data) {
        this->data = data;
        this->prev = this->next = NULL;
    }
};

class LinkedList {
public:
    Node* head, * tail;
public:
    LinkedList() {
        head = tail = NULL;
    }

    ~LinkedList() {
        while (head != NULL)
            pop_front();
    }

    /*Node* push_front(double data) {
        Node* tmp = new Node(data);
        tmp->next = head;
        if (head != NULL)
            head->prev = tmp;
        if (tail == NULL)
            tail = tmp;
        head = tmp;
        return tmp;
    }*/

    Node* push_back(char* data) {
        Node* tmp = new Node(data);
        tmp->prev = tail;
        if (tail != NULL)
            tail->next = tmp;
        if (head == NULL)
            head = tmp;
        tail = tmp;
        return tmp;
    }

    void pop_front() {
        if (head == NULL) return;

        Node* tmp = head->next;
        if (tmp != NULL)
            tmp->prev = NULL;
        else 
            tail = NULL;

        delete head;
        head = tmp;
    }

    void pop_back() {
        if (tail == NULL) return;

        Node* tmp = tail->prev;
        if (tmp != NULL)
            tmp->next = NULL;
        else
            head = NULL;

        delete tail;
        tail = tmp;
    }

    Node* getAt(int index) {
        Node* tmp = head;
        int n = 0;
        while (n != index) {
            if (tmp == NULL)
                return tmp;
            tmp = tmp->next;
            n++;
        }
        return tmp;
    }

    Node* operator [] (int index) {
        return getAt(index);
    }

    //Node* insert(int index, double data) {
    //    Node* right = getAt(index);
    //    if (right == NULL)
    //        return push_back(data);

    //    Node* left = right->prev;
    //    if (left == NULL)
    //        return push_front(data);

    //    Node* tmp = new Node(data);

    //    tmp->prev = left;
    //    tmp->next = right;
    //    left->next = tmp;
    //    right->prev = tmp;

    //    return tmp;
    //}

    void erase(int index) {
        Node* tmp = getAt(index);
        if (tmp == NULL)
            return;

        if (tmp->prev == NULL) {
            pop_front();
            return;
        }

        if (tmp->next == NULL) {
            pop_back();
            return;
        }

        Node* left = tmp->prev;
        Node* right = tmp->next;
        left->next = right;
        right->prev = left;

        delete tmp;
    }
};

#define MAX_LEN 60

int main()
{
    LinkedList selektory;
    LinkedList atrybuty;
    LinkedList komendy;

    char list[60];
    int stop = 0, new_line = 0, start = 0, start_kom = 0, ilosc_sekc = 0, nr_sekc1 = 0;
    char selektor[10];
    int atryb_il[20], atrybutow_tyle = 0;
    int skip_nextline = 0, sekcji = 0, add_new = 0, nr_sekc = 0, nr_selekt = 0, nr_atr = 0, liczb_selekt = 1, liczb_atr = 0;
    bool write_select = false;
    while (cin.getline(list, MAX_LEN))    //  Wczytanie
    {
        int size_s = 0, size_a = 0, size_k = 0;
        int poz = 0;

        if (list[0] == '\0' && skip_nextline == 0) {     //  Kiedy koniec
            stop = 1;
            start_kom = 0;
        }

        if (list[0] == '?' && list[1] == '?' && list[2] == '?' && list[3] == '?')
            start_kom = 1;

        if (list[0] == '*' && list[1] == '*' && list[2] == '*' && list[3] == '*') {
            start_kom = 0;
            skip_nextline = 1;
            add_new = 1;
        }

        if (start != 1) {
            if (list[0] == '#')
                start = 1;
        }

        else {
            if (skip_nextline == 0) {

                if (start_kom == 0) {

                    if (stop != 1) {
                        if (new_line != 1) {
                            while (list[poz] != '{') {
                                size_s++;
                                poz++;
                            }

                            if (list[0] == '{') {
                                size_s = 1;
                            }

                            if (list[poz + 1] == '\0')
                                new_line = 1;
                            else {
                                while (list[poz + 1] != '}') {

                                    if (list[poz + 1] == ':')
                                        liczb_atr++;
                                    size_a++;
                                    poz++;

                                }
                                if (list[poz + 1] == '}') {
                                    skip_nextline = 1;
                                    atryb_il[ilosc_sekc] = liczb_atr;
                                    ilosc_sekc++;
                                    liczb_atr = 0;
                                }
                                new_line = 0;
                            }
                        }

                        else {
                            while (list[poz] != '\0') {
                                if (list[poz] == '}') {
                                    new_line = 0;
                                    atryb_il[ilosc_sekc] = liczb_atr;
                                    ilosc_sekc++;
                                    skip_nextline = 1;
                                    liczb_atr = 0;
                                    break;
                                }
                                else if (list[poz] == ':')
                                    liczb_atr++;
                                size_a++;
                                poz++;
                            }
                        }

                        if (size_s != 0) {
                            char* selekt = (char*)malloc(sizeof(char) * size_s);
                            if (list[0] == '{') {
                                selekt[0] = ' ';
                            }
                            else {
                                strcpy(selekt, list);    //  Wpisanie selektorow
                                selekt[size_s] = '\0';
                            }
                            selektory.push_back(selekt);              //   Dodanie selektorow
                        }
                        if (size_a != 0) {
                            char* attr = (char*)malloc(sizeof(char) * size_a);
                            strcpy(attr, list);      //   Wpisanie atrybutow

                            if (new_line != 1) {
                                if (attr[poz] == ';')
                                    attr[poz] = '\0';
                                else if (attr[poz] != ';')
                                    attr[poz + 1] = '\0';
                                for (int i = 0, j = size_s + 1; i <= size_a; i++, j++) {
                                    attr[i] = attr[j];
                                }
                            }
                            else {
                                if (attr[poz - 1] == ';')
                                    attr[poz - 1] = '\0';
                                else if (attr[poz - 1] != ';')
                                    attr[poz + 1] = '\0';
                            }
                            atrybuty.push_back(attr);                   //   Dodanie atrybutow
                        }
                    }
                }
            }

            if (skip_nextline == 1 && (list[0] == '\0' || list[0] == '?' || (list[0] == '*' && list[1] == '*')))
                skip_nextline = 0;

            if (start_kom == 1) {
                while (list[poz] != '\0') {
                    size_k++;
                    poz++;
                }

                if (list[0] != '\0') {
                    char* kom = (char*)malloc(sizeof(char) * size_k);
                    strcpy(kom, list);

                    if (list[0] == '?' && list[1] == '\0')
                        sekcji = 1;

                    if (list[0] != '?' || list[1] != '?' || list[2] != '?' || list[3] != '?')
                        komendy.push_back(kom);
                }

                switch (list[0]) {
                case '1':
                    nr_sekc = 1;
                    break;
                case '2':
                    nr_sekc = 2;
                    break;
                case '3':
                    nr_sekc = 3;
                    break;
                case '4':
                    nr_sekc = 4;
                    break;
                case '5':
                    nr_sekc = 5;
                    break;
                case '6':
                    nr_sekc = 6;
                    break;
                }

                if (list[0] != '\0' && list[1] == ',' && list[2] == 'S' && list[3] == ',' && list[4] == '?') {
                    int numer = 1;
                    nr_sekc1 = nr_sekc;
                    for (Node* tmp = selektory.head; numer <= nr_sekc1; tmp = tmp->next, numer++) {
                        if (numer == nr_sekc1) {
                            int i = 0;
                            if (selektory.head == NULL) {
                                liczb_selekt = 0;
                                break;
                            }
                            else if (tmp->data[0] == ' ') {
                                liczb_selekt = 0;
                                break;
                            }
                            else {
                                while (tmp->data[i] != '\0') {
                                    if (tmp->data[i] == ',')
                                        liczb_selekt++;
                                    i++;
                                }
                            }
                        }
                    }
                    if (liczb_selekt == 1)
                        liczb_selekt = 0;
                }

                switch (list[4]) {
                case '1':
                    nr_selekt = 1;
                    nr_atr = 1;
                    break;
                case '2':
                    nr_selekt = 2;
                    nr_atr = 2;
                    break;
                case '3':
                    nr_selekt = 3;
                    nr_atr = 3;
                    break;
                case '4':
                    nr_selekt = 4;
                    nr_atr = 4;
                    break;
                case '5':
                    nr_selekt = 5;
                    nr_atr = 5;
                    break;
                case '6':
                    nr_selekt = 6;
                    nr_atr = 6;
                    break;
                }

                if (list[0] != '\0' && list[1] == ',' && list[2] == 'A' && list[3] == ',' && list[4] == '?') {
                    atrybutow_tyle = atryb_il[nr_sekc - 1];
                }

                if (list[0] != '\0' && list[1] == ',' && list[2] == 'S' && list[3] == ',' && list[4] != '?') {
                    int numer_sekcji = 1, pozycja = 0, selektor_numer = 1;
                    liczb_selekt = 1;
                    for (Node* tmp = selektory.head; numer_sekcji <= nr_sekc; tmp = tmp->next, numer_sekcji++) {
                        if (numer_sekcji == nr_sekc) {
                            if (tmp->data[0] == ' ') {
                                write_select = false;
                                break;
                            }
                            int przecinek = 0;
                            while (tmp->data[pozycja] != '{') {
                                if (tmp->data[pozycja] == ',') {
                                    selektor_numer++;
                                    pozycja = pozycja + 1 + 1;
                                    przecinek++;
                                }
                                else pozycja++;
                                if (selektor_numer == nr_selekt) {
                                    int length_selekt = pozycja, slowo_nowe = 0;
                                    while (tmp->data[length_selekt] != ' ') {
                                        if (przecinek == 0)
                                            selektor[slowo_nowe] = tmp->data[length_selekt - 1];
                                        else
                                            selektor[slowo_nowe] = tmp->data[length_selekt];
                                        length_selekt++;
                                        slowo_nowe++;
                                    }
                                        selektor[slowo_nowe] = '\0';
                                    write_select = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                /*      if (list[1] == ',' && list[2] == 'A' && list[3] == ',' && list[4] != '?') {
                          int numer_sekcji = 1;
                          for (Node* tmp = atrybuty.head; numer_sekcji <= nr_sekc; tmp = tmp->next, numer_sekcji++) {
                              if (numer_sekcji == nr_sekc) {
                                  int i = 0, j = 0;
                                  while (tmp->data[i] != '\0') {
                                      if (tmp->data[i] == ',')
                                          liczb_atr++;
                                      if (tmp->data[0] == '\0')
                                          liczb_atr = 0;
                                      if (liczb_atr == nr_atr) {
                                          while (tmp->data[i + 2] != ',') {
                                              selektor[j] = tmp->data[i + 2];
                                              j++;
                                              i++;
                                              write_select = true;
                                          }
                                      }
                                      i++;
                                  }
                              }
                          }
                      }*/
            }

            if (stop == 1) {                                       //    Koniec i wypisywanie znaczeń
                if (sekcji == 1)
                    cout << "? == " << ilosc_sekc << endl;

                if (write_select == true) {
                    int i = 0;
                    cout << nr_sekc << ",S," << nr_selekt << " == ";
                    while (selektor[i] != '\0') {
                        cout << selektor[i];
                        i++;
                    }
                    cout << endl;
                }

                if (nr_sekc1 != 0)
                    cout << nr_sekc1 << ",S,? == " << liczb_selekt << endl;

                if (atrybutow_tyle != 0)
                    cout << nr_sekc << ",A,? == " << atrybutow_tyle << endl;

                for (Node* tmp = selektory.head; tmp != NULL; tmp = tmp->next)
                    cout << tmp->data << "  ";
                cout << endl;

                for (Node* tmp = atrybuty.head; tmp != NULL; tmp = tmp->next)
                    cout << tmp->data << " ";
                cout << endl;

                for (Node* tmp = komendy.head; tmp != NULL; tmp = tmp->next)
                    cout << tmp->data << " ";
                cout << endl;
                return 0;
            }
        }
    }
}
