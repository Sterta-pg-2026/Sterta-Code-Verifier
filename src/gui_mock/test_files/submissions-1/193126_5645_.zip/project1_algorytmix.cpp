#include <iostream>
#include "list.h"
#include "my_string.h"

using namespace std;

#define SELECTORS 0
#define ATTRIBUTES 1
#define VALUES_OF_ATT 2
#define COMMAND 3
#define ASCII_ZERO 48
#define EMPTY_INT -1

List* FindEmptySpace(List* first); //finds node with space for new section and returns it, can return new node
void AddEmptyNode(List** first, List** last, List* empty); //adds new node to list
void AddSelector(List* node, my_String* name, bool* firstNew);
void AddValue(List* node, my_String* value);
int CountSections(const List* first);
List* GetSectionNode_i(List* first, int i, int* k); //returns pointer with section and updates k so block[k] is section i, can return NULL
int CountSelectors_i(List* first, int i); //returns EMPTY_INT if there is no i section
int CountAttributes_i(List* first, int i); //returns EMPTY_INT if there is no i section
my_String GetSelector_ij(List* first, int i, int j); //returns EMPTY if there is no i section or j selector
my_String GetValueOfAtt_n(List* first, int i, my_String n); //returns EMPTY if there is no i section or n attribute
int GetNumberOfAttribute_z(const List* first, my_String z);
int GetNumberOfSelector_z(const List* first, my_String z);
my_String GetValueOfAtt_n_for_z(const List* last, my_String z, my_String n); //returns EMPTY if there is no z selector or n attribute
void DeleteNode(List** first, List** last, List* tmp); //deletes whole List node
bool DeleteSection_i(List** first, List** last, int i); //returns true on successful delete, else false
bool DeleteAttribute_n(List** first, List** last, my_String n, int i); //returns true on successful delete, else false
void RemoveWhiteSpcaeAtTheEnd(my_String* n);


List* FindEmptySpace(List* first)
{
    while (first != NULL)
    {
        if (first->GetEdited() != T - 1)
        {
            first->SetEdited(first->GetEdited() + 1);
            return first;
        }

        first = first->GetNext();
    }

    return new List();
}

void AddEmptyNode(List** first, List** last, List* empty)
{
    if (empty->GetNext() == NULL && empty->GetPrev() == NULL)
    {
        if (*first == NULL)
        {
            *first = empty;
            *last = empty;
        }
        else if (*first != empty)
        {
            (*last)->SetNext(empty);
            empty->SetPrev(*last);
            *last = empty;
        }
    }
}

void AddSelector(List* node, my_String* name, bool* firstNew)
{
    RemoveWhiteSpcaeAtTheEnd(name);
    node->InsertSelector(*name);
    *name = "";
    *firstNew = false;
}

void AddValue(List* node, my_String* value)
{
    RemoveWhiteSpcaeAtTheEnd(value);
    node->InsertValue(*value);
    *value = "";
}

int CountSections(const List* first)
{
    int sections = 0;
    while (first != NULL)
    {
        sections += first->GetNumberOfStructures();
        first = first->GetNext();
    }
    return sections;
}

List* GetSectionNode_i(List* first, int i, int* k)
{
    int section = 0;
    while (section != i && first != NULL)
    {
        if (section + first->GetNumberOfStructures() >= i)
        {
            while (section < i)
            {
                if (first->IsBlockEmpty(*k + 1) == false)
                {
                    section++;
                }
                (*k)++;
            }
        }
        else
        {
            section += first->GetNumberOfStructures();
            first = first->GetNext();
        }
    }

    return first;
}

int CountSelectors_i(List* first, int i)
{
    int k = -1;
    first = GetSectionNode_i(first, i, &k);

    if (first != NULL)
    {
        return first->GetNumberOfSelektors(k);
    }
    else
    {
        return EMPTY_INT;
    }
}

int CountAttributes_i(List* first, int i)
{
    int k = -1;
    first = GetSectionNode_i(first, i, &k);

    if (first != NULL)
    {
        return first->GetNumberOfAttributes(k);
    }
    else
    {
        return EMPTY_INT;
    }
}

my_String GetSelector_ij(List* first, int i, int j)
{
    int k = -1;
    first = GetSectionNode_i(first, i, &k);

    if (first != NULL)
    {
        return first->GetJSelektor(k, j);
    }
    else
    {
        return EMPTY;
    }
}

my_String GetValueOfAtt_n(List* first, int i, my_String n)
{
    int k = -1;
    first = GetSectionNode_i(first, i, &k);

    if (first != NULL)
    {
        return first->GetValueOf_n(k, n);
    }
    else
    {
        return EMPTY;
    }
}

int GetNumberOfAttribute_z(const List* first, my_String z)
{
    int sum = 0;
    while (first != NULL)
    {
        sum += first->CountAttribute_z(z);
        first = first->GetNext();
    }

    return sum;
}

int GetNumberOfSelector_z(const List* first, my_String z)
{
    int sum = 0;
    while (first != NULL)
    {
        sum += first->CountSelector_z(z);
        first = first->GetNext();
    }

    return sum;
}

my_String GetValueOfAtt_n_for_z(const List* last, my_String z, my_String n)
{
    my_String value = EMPTY;
    while (last != NULL)
    {
        for (int i = T - 1; i >= 0; i--)
        {
            if (last->hasSelector(z, i))
            {
                value = last->GetValueOf_n(i, n);
                if (value != EMPTY)
                {
                    return value;
                }
            }
        }

        last = last->GetPrev();
    }

    return EMPTY;
}

void DeleteNode(List** first, List** last, List* tmp)
{
    if (tmp == *first)
    {
        *first = tmp->GetNext();
    }
    if (tmp == *last)
    {
        *last = tmp->GetPrev();
    }

    if (tmp->GetPrev() != NULL)
    {
        tmp->GetPrev()->SetNext(tmp->GetNext());
    }
    if (tmp->GetNext() != NULL)
    {
        tmp->GetNext()->SetPrev(tmp->GetPrev());
    }

    delete tmp;
}

bool DeleteSection_i(List** first, List** last, int i)
{
    int k = -1;
    List* tmp = GetSectionNode_i(*first, i, &k);

    if (tmp != NULL)
    {
        tmp->DeleteSection(k);
        if (tmp->GetNumberOfStructures() == 0)
        {
            DeleteNode(first, last, tmp);
        }

        return true;
    }
    else
    {
        return false;
    }
}

bool DeleteAttribute_n(List** first, List** last, my_String n, int i)
{
    int k = -1;
    List* tmp = GetSectionNode_i(*first, i, &k);

    if (tmp != NULL)
    {
        if (tmp->DeleteAttribute_n(n, k))
        {
            if (tmp->GetNumberOfStructures() == 0)
            {
                DeleteNode(first, last, tmp);
            }

            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

void RemoveWhiteSpcaeAtTheEnd(my_String* n)
{
    int i = (*n).size() - 1;
    while ((*n)[i] <= ' ' && i > 0)
    {
        (*n)[i] = '\0';
        i--;
    }
}

int main()
{
    //input in COMMAND mode is for taking command type (S,A,D,E)
    //in other modes, input takes whole user-input
    //helpz is for COMMAND mode to help handle wrong command input
    //in COMMAND mode, z will always be input before comma, n for input after last comma
    //firstNew is to tell if we get first selector, isEOF is to loop 1 more time after EOF
    //commaCounter is to count commas while reading in COMMAND mode, becasue more than 2 commas means incorrect command
    int i = 0, j = 0, mode = SELECTORS, commaCounter = 0;
    my_String input = "", n = "", z = "", helpz = "";
    char character;
    List* first = new List;
    List* last = first;
    List* empty = first;
    bool firstNew = true, isEOF = false;

    while (cin >> noskipws >> character || isEOF == false)
    {
        switch (mode)
        {

        case SELECTORS:
            if (character == ',')
            {
                if (firstNew)
                {
                    empty = FindEmptySpace(first);
                    AddEmptyNode(&first, &last, empty);
                }

                AddSelector(empty, &input, &firstNew);
            }
            else if (character == '{')
            {
                if (firstNew)
                {
                    empty = FindEmptySpace(first);
                    AddEmptyNode(&first, &last, empty);
                }

                AddSelector(empty, &input, &firstNew);
                mode = ATTRIBUTES;
            }
            else if ((input == "" && character > ' ') || input != "")
            {
                input = input + character;

                if (input == "????")
                {
                    mode = COMMAND;
                    input = "";
                }
            }
            break;

        case ATTRIBUTES:
            if (character == ':')
            {
                empty->InsertAttribute(input);
                input = "";
                mode = VALUES_OF_ATT;
            }
            else if (character == '}')
            {
                if (empty->GetNumberOfAttributes(empty->GetEdited()) == 0)
                {
                    empty->DeleteSection(empty->GetEdited());
                }

                empty->IncreaseNumberOfStructures(1);
                input = "";
                mode = SELECTORS;
                firstNew = true;
            }
            else if (character > ' ') //attributes in CSS cannot have white spaces
            {
                input = input + character;
            }
            break;

        case VALUES_OF_ATT:
            if (character == ';')
            {
                AddValue(empty, &input);
                mode = ATTRIBUTES;
            }
            else if (character == '}')
            {
                AddValue(empty, &input);
                empty->IncreaseNumberOfStructures(1);
                mode = SELECTORS;
                firstNew = true;
            }
            else if ((input == "" && character > ' ') || input != "")
            {
                input = input + character;
            }

            break;
            
        case COMMAND:
            //Selector name cannot start with digit
            if (z == "" && character >= '0' && character <= '9' && (input == "" || (input == "S" && n == "")))
            {
                if (input == "")
                {
                    i *= 10;
                    i += int(character) - ASCII_ZERO;
                }
                else
                {
                    j *= 10;
                    j += int(character) - ASCII_ZERO;
                }
            }
            else if (character == ',')
            {
                RemoveWhiteSpcaeAtTheEnd(&z);
                if (commaCounter == 1 && (z == "S" || z == "A" || z == "E" || z == "D"))
                {
                    input = z;
                    if (helpz == "")
                    {
                        z = "";
                    }
                    else
                    {
                        z = helpz;
                    }
                }
                else if (commaCounter == 0)
                {
                    helpz = z;
                    z = "";
                    commaCounter++;
                }
                else
                {
                    input = "error";
                }
            }
            else if (character == '\n' || cin.fail() == true) //there we execute command
            {
                commaCounter = 0;
                RemoveWhiteSpcaeAtTheEnd(&n);
                if (input == "error")
                {
                    input = "";
                    z = "";
                    n = "";
                    i = 0;
                    j = 0;
                }
                else if (z == "****")//CSS reading
                {
                    mode = SELECTORS;
                    z = "";
                }
                else if (z == "?")//number of CSS sections
                {
                    cout << z << " == " << CountSections(first) << endl;
                    z = "";
                }
                else if (z == "" && input == "S" && n == "?")//number of selectors for i section
                {
                    int selektors = CountSelectors_i(first, i);
                    if (selektors != EMPTY_INT)
                    {
                        cout << i << "," << input << "," << n << " == " << selektors << endl;
                    }

                    i = 0;
                    input = "";
                    n = "";
                }
                else if (z == "" && input == "A" && n == "?")//number of attributes for i section
                {
                    int attributes = CountAttributes_i(first, i);
                    if (attributes != EMPTY_INT)
                    {
                        cout << i << "," << input << "," << n << " == " << attributes << endl;
                    }

                    i = 0;
                    input = "";
                    n = "";
                }
                else if (z == "" && input == "S" && n == "")//j selector for i section
                {
                    my_String selector = GetSelector_ij(first, i, j);
                    if (selector > ' ')
                    {
                        cout << i << "," << input << "," << j << " == " << selector << endl;
                    }

                    i = 0;
                    input = "";
                    j = 0;
                }
                else if (z == "" && input == "A" && n != "")//value of n attribute for i section
                {
                    my_String value = GetValueOfAtt_n(first, i, n);
                    if (value != EMPTY)
                    {
                        cout << i << "," << input << "," << n << " == " << value << endl;
                    }

                    i = 0;
                    input = "";
                    n = "";
                }
                else if (z != "" && input == "A" && n == "?")//number of z attributes
                {
                    int ile = GetNumberOfAttribute_z(first, z);
                    cout << z << "," << input << "," << n << " == " << ile << endl;

                    z = "";
                    input = "";
                    n = "";
                }
                else if (z != "" && input == "S" && n == "?")//number of z selectors
                {
                    int ile = GetNumberOfSelector_z(first, z);
                    cout << z << "," << input << "," << n << " == " << ile << endl;

                    z = "";
                    input = "";
                    n = "";
                }
                else if (z != "" && input == "E" && n != "")//value of n attribute for z selector
                {
                    my_String value = GetValueOfAtt_n_for_z(last, z, n);
                    if (value != EMPTY)
                    {
                        cout << z << "," << input << "," << n << " == " << value << endl;
                    }

                    z = "";
                    input = "";
                    n = "";
                }
                else if (z == "" && input == "D" && n == "*")//delete whole i section
                {
                    if (DeleteSection_i(&first, &last, i))
                    {
                        cout << i << "," << input << "," << n << " == deleted" << endl;
                    }

                    i = 0;
                    input = "";
                    n = "";
                }
                else if (z == "" && input == "D" && n != "")//delete n attribute for i section
                {
                    if (DeleteAttribute_n(&first, &last, n, i))
                    {
                        cout << i << "," << input << "," << n << " == deleted" << endl;
                    }

                    i = 0;
                    input = "";
                    n = "";
                }
                else
                {
                    input = "";
                    z = "";
                    n = "";
                    i = 0;
                    j = 0;
                }
            }
            else if (input == "")
            {
                if ((z == "" && character > ' ') || z != "")
                {
                    z = z + character;
                }
            }
            else if (input.size() == 1)
            {
                n = n + character;
            }

            break;
        }

        if (cin.fail() == true)
        {
            isEOF = true;
        }
    }

    last = NULL;
    while (first != NULL)
    {
        empty = first;
        first = first->GetNext();
        delete empty;
    }

    return 0;
}
