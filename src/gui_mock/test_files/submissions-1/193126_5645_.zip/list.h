#pragma once

#include <iostream>
#include "block.h"
#include "my_string.h"
using namespace std;

#define T 8
#define EMPTY "\t"

class List
{
    int number_of_structures;
    int edited;
    Block* block;
    List* next;
    List* prev;

public:

    List();

    int GetEdited() const;
    void InsertSelector(my_String name); //inserts selector to block[edited]
    void InsertAttribute(my_String name); //inserts attribute to block[edited]
    void InsertValue(my_String value); //inserts value to block[edited]
    List* GetNext() const;
    List* GetPrev() const;
    void SetNext(List* next);
    void SetPrev(List* prev);
    bool IsBlockEmpty(int i) const; //checks if block[i] is empty
    void SetEdited(int value);
    int GetNumberOfStructures() const;
    int GetNumberOfSelektors(int i) const; //returns number of selectors from i block
    int GetNumberOfAttributes(int i) const; //returns number of attributes from i block
    my_String GetJSelektor(int i, int j) const; //returns EMPTY if there is no j selector for block[i]
    void IncreaseNumberOfStructures(int i); //increases number_of_structures by i
    my_String GetValueOf_n(int i, my_String n) const; //returns EMPTY if there is no n attribute for block[i]
    int CountAttribute_z(my_String z) const; //counts number of z attributes for whole block[]
    int CountSelector_z(my_String z) const; //counts number of z selectors for whole block[]
    bool hasSelector(my_String z, int i) const; //checks if block[i] has z selector
    void DeleteSection(int i); //clears whole block[i]
    bool DeleteAttribute_n(my_String n, int i); //deletes n attribute from block[i]

    ~List();
};