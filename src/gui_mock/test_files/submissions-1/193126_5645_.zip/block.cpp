#include "block.h"

Block::Block()
{
    firstS = NULL;
    firstA = NULL;
}

Selector* Block::GetFirstS() const
{
    return firstS;
}

Attribute* Block::GetFirstA() const
{
    return firstA;
}

void Block::CreateFirstS(my_String name)
{
    firstS = new Selector(name);
}

void Block::AddSelectorNode(my_String name)
{
    Selector* tmp = firstS;

    while (tmp->GetNext() != NULL)
    {
        tmp = tmp->GetNext();
    }

    tmp->SetNext(new Selector(name));
}

void Block::CreateFirstA(my_String name)
{
    firstA = new Attribute(name);
}

void Block::AddAttributeNode(my_String name)
{
    Attribute* tmp = firstA;

    while (tmp->GetName() != name && tmp->GetNext() != NULL)
    {
        tmp = tmp->GetNext();
    }

    if (tmp->GetName() == name)
    {
        tmp->SetValue("");
    }
    else
    {
        tmp->SetNext(new Attribute(name));
    }
}

void Block::AddValueToAtt(my_String value)
{
    Attribute* tmp = firstA;

    while (tmp->GetValue() != "")
    {
        tmp = tmp->GetNext();
    }

    tmp->SetValue(value);
}

bool Block::IsAttribute_z(my_String z) const
{
    Attribute* tmp = firstA;
    while (tmp != NULL)
    {
        if (tmp->GetName() == z)
        {
            return true;
        }
        tmp = tmp->GetNext();
    }

    return false;
}

bool Block::IsSelector_z(my_String z) const
{
    Selector* tmp = firstS;
    while (tmp != NULL)
    {
        if (tmp->GetName() == z)
        {
            return true;
        }
        tmp = tmp->GetNext();
    }

    return false;
}

void Block::DeleteBlock()
{
    Attribute* tmpa = firstA;
    Attribute* tmpa2;
    while (tmpa != NULL)
    {
        tmpa2 = tmpa->GetNext();
        delete tmpa;
        tmpa = tmpa2;
    }

    Selector* tmps = firstS;
    Selector* tmps2;
    while (tmps != NULL)
    {
        tmps2 = tmps->GetNext();
        delete tmps;
        tmps = tmps2;
    }

    firstA = NULL;
    firstS = NULL;
}

bool Block::DeleteAttribute(my_String n)
{
    Attribute* tmp = firstA;
    Attribute* tmp2 = tmp;
    while (tmp != NULL && tmp->GetName() != n)
    {
        tmp2 = tmp;
        tmp = tmp->GetNext();
    }

    if (tmp != NULL && tmp->GetName() == n)
    {
        if (firstA == tmp)
        {
            firstA = tmp->GetNext();
        }
        else
        {
            tmp2->SetNext(tmp->GetNext());
        }

        delete tmp;
        return true;
    }
    else
    {
        return false;
    }
}