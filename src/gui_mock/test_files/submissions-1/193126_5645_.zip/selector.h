#pragma once

#include <iostream>
#include "my_string.h"

using namespace std;

class Selector
{
    my_String name;
    Selector* next;

public:

    Selector(my_String name);

    Selector* GetNext() const;
    void SetNext(Selector* next);
    my_String GetName() const;
};