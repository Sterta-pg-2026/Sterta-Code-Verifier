#pragma once

#include <iostream>
#include "attribute.h"
#include "selector.h"
#include "my_string.h"

using namespace std;

class Block
{
    Selector* firstS;
    Attribute* firstA;

public:

    Block();

    Selector* GetFirstS() const;
    Attribute* GetFirstA() const;
    void CreateFirstS(my_String name);
    void AddSelectorNode(my_String name);
    void CreateFirstA(my_String name);
    void AddAttributeNode(my_String name);
    void AddValueToAtt(my_String value); //adds value to attribute node with no value
    bool IsAttribute_z(my_String z) const; //checks if there is z attribute
    bool IsSelector_z(my_String z) const; //checks if there is z selector
    void DeleteBlock();
    bool DeleteAttribute(my_String n); //returns true on successful n attribute delete
};