#include "attribute.h"

Attribute::Attribute(my_String name)
{
    this->name = name;
    value = "";
    next = NULL;
}

Attribute* Attribute::GetNext() const
{
    return next;
}

void Attribute::SetNext(Attribute* next)
{
    this->next = next;
}

void Attribute::SetValue(my_String value)
{
    this->value = value;
}

my_String Attribute::GetName() const
{
    return name;
}

my_String Attribute::GetValue() const
{
    return value;
}