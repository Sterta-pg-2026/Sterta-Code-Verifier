#include "list.h"

List::List()
{
    next = NULL;
    prev = NULL;
    block = new Block[T];
    number_of_structures = 0;
    edited = 0;
}

int List::GetEdited() const
{
    return edited;
}

void List::InsertSelector(my_String name)
{
    if (block[edited].GetFirstS() == NULL)
    {
        block[edited].CreateFirstS(name);
    }
    else
    {
        block[edited].AddSelectorNode(name);
    }
}

void List::InsertAttribute(my_String name)
{
    if (block[edited].GetFirstA() == NULL)
    {
        block[edited].CreateFirstA(name);
    }
    else
    {
        block[edited].AddAttributeNode(name);
    }
}

void List::InsertValue(my_String value)
{
    block[edited].AddValueToAtt(value);
}

List* List::GetNext() const
{
    return next;
}

List* List::GetPrev() const
{
    return prev;
}

void List::SetNext(List* next)
{
    this->next = next;
}

void List::SetPrev(List* prev)
{
    this->prev = prev;
}

bool List::IsBlockEmpty(int i) const
{
    if (block[i].GetFirstS() == NULL)
    {
        return true;
    }

    return false;
}

void List::SetEdited(int value)
{
    edited = value;
}

int List::GetNumberOfStructures() const
{
    return number_of_structures;
}

int List::GetNumberOfSelektors(int i) const
{
    Selector* tmp = block[i].GetFirstS();
    int number = 0;
    while (tmp != NULL)
    {
        if (tmp->GetName() != "")
        {
            number++;
        }
        tmp = tmp->GetNext();
    }
    return number;
}

int List::GetNumberOfAttributes(int i) const
{
    Attribute* tmp = block[i].GetFirstA();
    int number = 0;
    while (tmp != NULL)
    {
        number++;
        tmp = tmp->GetNext();
    }
    return number;
}

my_String List::GetJSelektor(int i, int j) const
{
    Selector* tmp = block[i].GetFirstS();
    int number = 1;
    while (tmp != NULL && number < j)
    {
        number++;
        tmp = tmp->GetNext();
    }

    if (tmp != NULL)
    {
        return tmp->GetName();
    }
    else
    {
        return EMPTY;
    }
}

void List::IncreaseNumberOfStructures(int i)
{
    number_of_structures += i;
}

my_String List::GetValueOf_n(int i, my_String n) const
{
    Attribute* tmp = block[i].GetFirstA();
    while (tmp != NULL && tmp->GetName() != n)
    {
        tmp = tmp->GetNext();
    }

    if (tmp != NULL && tmp->GetName() == n)
    {
        return tmp->GetValue();
    }
    else
    {
        return EMPTY;
    }
}

int List::CountAttribute_z(my_String z) const
{
    int sum = 0;
    for (int i = 0; i < T; i++)
    {
        if (block[i].IsAttribute_z(z))
        {
            sum++;
        }
    }

    return sum;
}

int List::CountSelector_z(my_String z) const
{
    int sum = 0;
    for (int i = 0; i < T; i++)
    {
        if (block[i].IsSelector_z(z))
        {
            sum++;
        }
    }

    return sum;
}

bool List::hasSelector(my_String z, int i) const
{
    Selector* tmp = block[i].GetFirstS();

    while (tmp != NULL)
    {
        if (tmp->GetName() == z)
        {
            return true;
        }
        tmp = tmp->GetNext();
    }

    return false;
}

void List::DeleteSection(int i)
{
    block[i].DeleteBlock();
    number_of_structures--;
}

bool List::DeleteAttribute_n(my_String n, int i)
{
    if (block[i].DeleteAttribute(n))
    {
        if (block[i].GetFirstA() == NULL)
        {
            DeleteSection(i);
        }
        return true;
    }
    else
    {
        return false;
    }
}

List::~List()
{
    delete[] block;
}
