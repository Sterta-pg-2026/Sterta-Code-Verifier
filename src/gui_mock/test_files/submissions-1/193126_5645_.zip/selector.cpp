#include "selector.h"

Selector::Selector(my_String name)
{
    this->name = name;
    next = NULL;
}

Selector* Selector::GetNext() const
{
    return next;
}

void Selector::SetNext(Selector* next)
{
    this->next = next;
}

my_String Selector::GetName() const
{
    return name;
}