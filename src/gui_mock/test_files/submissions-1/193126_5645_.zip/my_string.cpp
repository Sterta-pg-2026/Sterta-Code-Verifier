// my_String napisany przy pomocy stron internetowych : 
// https://www.geeksforgeeks.org/how-to-create-a-custom-string-class-in-c-with-basic-functionalities/
// https://medium.com/swlh/write-your-own-c-stl-string-class-e20113a8de79

#include "my_string.h"

my_String::my_String() : str(nullptr) {}

my_String::my_String(char* val)
{
    if (val == nullptr) 
    {
        str = nullptr;
    }
    else 
    {
        str = new char[strlen(val) + 1];

        strcpy(str, val);
        str[strlen(val)] = '\0';
    }
}

my_String::my_String(const char* val)
{
    if (val == nullptr)
    {
        str = nullptr;
    }
    else
    {
        str = new char[strlen(val) + 1];

        strcpy(str, val);
        str[strlen(val)] = '\0';
    }
}

my_String::my_String(const my_String& source)
{
    if (source.str == nullptr)
    {
        str = nullptr;
    }
    else
    {
        str = new char[strlen(source.str) + 1];
        strcpy(str, source.str);
        str[strlen(source.str)] = '\0';
    }
}

my_String::my_String(my_String&& source)
{
    if (source.str == nullptr)
    {
        str = nullptr;
    }
    else
    {
        str = source.str;
        source.str = nullptr;
    }
}

size_t my_String::size()
{
    return strlen(str);
}

my_String my_String::operator+(const my_String& obj)
{
    int length = strlen(obj.str) + strlen(this->str);
    char* buff = new char[length + 1];

    strcpy(buff, this->str);
    strcat(buff, obj.str);
    buff[length] = '\0';

    my_String temp{ buff };
    delete[] buff;

    return temp;
}

my_String my_String::operator+(const char* obj)
{
    int length = strlen(obj) + strlen(this->str);
    char* buff = new char[length + 1];

    strcpy(buff, this->str);
    strcat(buff, obj);
    buff[length] = '\0';

    my_String temp{ buff };
    delete[] buff;

    return temp;
}

my_String my_String::operator+(char obj)
{
    int length = 1 + strlen(this->str);
    char* buff = new char[length + 1];

    strcpy(buff, this->str);
    buff[length - 1] = obj;
    buff[length] = '\0';

    my_String temp{ buff };
    delete[] buff;

    return temp;
}

my_String& my_String::operator=(const my_String& obj)
{
    if (this == &obj)
    {
        return *this;
    }

    delete[] str;
    str = new char[strlen(obj.str) + 1];
    strcpy(str, obj.str);
    return *this;
}

my_String& my_String::operator=(my_String&& obj)
{
    if (this == &obj)
    {
        return *this;
    }

    delete[] str;
    str = obj.str;
    obj.str = nullptr;
    return *this;
}

my_String& my_String::operator=(const char* obj)
{
    if (this->str == obj)
    {
        return *this;
    }

    delete[] str;
    str = new char[strlen(obj) + 1];
    strcpy(str, obj);
    return *this;
}

my_String& my_String::operator=(char obj)
{
    delete[] str;
    str = new char[2];
    str[0] = obj;
    str[1] = '\0';
    return *this;
}

bool my_String::operator==(const my_String& obj)
{
    if (strcmp(this->str, obj.str) == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool my_String::operator!=(const my_String& obj)
{
    if (strcmp(this->str, obj.str) != 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

char& my_String::operator[](int i)
{
    return str[i];
}

bool my_String::operator>(char obj)
{
    if (strlen(this->str) > 1 || str[0] > obj)
    {
        return true;
    }
    else
    {
        return false;
    }
}

my_String::~my_String()
{
    delete str;
}

ostream& operator<<(ostream& os, const my_String& obj)
{
    os << obj.str;
    return os;
}