#pragma once

#include <iostream>
#include "my_string.h"

using namespace std;

class Attribute
{
    my_String name, value;
    Attribute* next;

public:

    Attribute(my_String name);

    Attribute* GetNext() const;
    void SetNext(Attribute* next);
    void SetValue(my_String value);
    my_String GetName() const;
    my_String GetValue() const;
};