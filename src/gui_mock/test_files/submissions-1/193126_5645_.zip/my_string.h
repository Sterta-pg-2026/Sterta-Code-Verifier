// my_String napisany przy pomocy stron internetowych : 
// https://www.geeksforgeeks.org/how-to-create-a-custom-string-class-in-c-with-basic-functionalities/
// https://medium.com/swlh/write-your-own-c-stl-string-class-e20113a8de79

#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

using namespace std;

class my_String
{
	char* str;

public:
	my_String();
	my_String(char* val);
	my_String(const char* val);
	my_String(const my_String& source);
	my_String(my_String&& source);

	size_t size();

	my_String operator+(const my_String& obj);
	my_String operator+(const char* obj);
	my_String operator+(char obj);
	my_String& operator=(const my_String& obj);
	my_String& operator=(my_String&& obj);
	my_String& operator=(const char* obj);
	my_String& operator=(char obj);
	char& operator[](int i);
	bool operator==(const my_String& obj);
	bool operator!=(const my_String& obj);
	bool operator>(char obj);
	friend ostream& operator<<(ostream& os, const my_String& obj);

	~my_String();
};