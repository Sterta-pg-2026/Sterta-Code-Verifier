#pragma once
#include "string.h"

class doubleStringNode {
private:
	String prop;
	String val;
	doubleStringNode* next;
	doubleStringNode* prev;
	friend class doubleStringList;
public:
	doubleStringNode();
	doubleStringNode(String prop, String val);
	void Add(String prop, String val);
	String getValue();
	String getProperty();
	void ConnectNeighbours();
	~doubleStringNode();
};

class doubleStringList
{
private:
	doubleStringNode* head;
	doubleStringNode* tail;
	int listSize;
public:
	doubleStringList();
	void Add(String prop, String val);
	int Length() const;
	void Remove(int number);
	doubleStringNode* getLastNode();
	doubleStringNode* getNode(int index);
	String findByProperty(String prop);
	int getUniqueAttributes();
	int deleteByProperty(String prop);
	~doubleStringList();
};