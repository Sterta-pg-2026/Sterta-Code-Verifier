#include "stringnode.h"	

StringNode::StringNode() {
	this->next = nullptr;
	this->prev = nullptr;
	this->data = "*";
}

StringNode::StringNode(String data) {
	this->next = nullptr;
	this->prev = nullptr;
	this->data = data;
}

void StringNode::Add(String selector)
{
	this->data = selector;
}

String StringNode::getValue() {
	String temp = data;
	return temp;
}

StringNode::~StringNode()
{
	next = nullptr;
	prev = nullptr;
}