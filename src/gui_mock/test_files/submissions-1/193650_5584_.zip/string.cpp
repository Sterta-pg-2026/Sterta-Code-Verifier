#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "string.h"
    String::String(const char* str) {
        if (str != nullptr)
        {
            size = std::strlen(str);
            data = new char[size + 1];
            std::strcpy(data, str);
            data[size] = '\0';
        }
        else
        {
            size = 0;
            data = nullptr;
        }
    }

    String::String(const String& other) {
        size = other.size;
        data = new char[size + 1];
        std::strcpy(data, other.data);
    }

    String::String(String&& other) noexcept {
        size = other.size;
        data = other.data;
        other.size = 0;
        other.data = nullptr;
    }

    String::~String() {
        if(data != nullptr)
            delete[] data;
        size = 0;
    }

    String& String::operator=(const String& other) {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = new char[size + 1];
            std::strcpy(data, other.data);
        }
        return *this;
    }

    String& String::operator=(String&& other) noexcept {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = other.data;
            other.size = 0;
            other.data = nullptr;
        }
        return *this;
    }

    String String::operator+(const String& other) const {
        String result;
        result.size = size + other.size;
        result.data = new char[result.size + 1];
        std::strcpy(result.data, data);
        std::strcat(result.data, other.data);
        return result;
    }

    bool String::operator==(const String& other) const {
        return std::strcmp(data, other.data) == 0;
    }

    char& String::operator[](size_t index) {
        return data[index];
    }

    size_t String::getSize() const {
        return size;
    }
    char* String::getText(){
        return data;
    }

    void String::clearString() {
        this->data = nullptr;
        size = 0;
    }

    int String::findChar(char c) const
    {
        for (int i = 0; i < this->size; i++)
        {
            if (data[i] == c) return i;
        }
        return -1;
    }

    std::ostream& operator<<(std::ostream& os, String& string)
    {
        os << string.getText();
        return os;
    }

    std::istream& operator>>(std::istream& input, String& str) {
        char* temp = new char[256];
        input >> temp;
        str = String(temp);
        return input;
    }