#include "stringnode.h"
StringList::StringList()
{
	head = nullptr;
	tail = nullptr;
	listSize = 0;
}
void StringList::Add(String selector)
{
	listSize++;
	StringNode* node = new StringNode();
	node->Add(selector);
	if (head == nullptr)
	{
		head = node;
		tail = head;
	}
	else if (head->next == nullptr)
	{
		tail = node;
		tail->prev = head;
		head->next = tail;
	}
	else
	{
		StringNode* temp = tail;
		tail = node;
		tail->prev = temp;
		temp->next = tail;
	}
}
int StringList::Length() const
{
	return listSize;
}

void StringList::Remove(int number)
{
	listSize--;
	if (number < listSize / 2)
	{
		StringNode* temp = head;
		if (number == 1)
		{
			head = head->next;
			head->next->prev = head;
			temp = nullptr;
		}
		else
		{
			for (int i = 1; i < number; i++)
			{
				temp = temp->next;
			}
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			temp = nullptr;
		}

	}
	else
	{
		StringNode* temp = tail;
		if (number == Length())
		{
			tail = tail->prev;
			tail = nullptr;
		}
		else
		{
			for (int i = Length(); i > 0; i--)
			{
				temp = temp->next;
			}
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			temp = nullptr;
		}
	}
	listSize--;
}

StringNode* StringList::getLastNode() {
	return tail;
}

StringNode* StringList::getNode(int index)
{
	if (index == 0)
	{
		return head;
	}
	if (index > 0)
	{
		StringNode* temp = head;
		for (int i = 0; i < listSize; i++)
		{
			if (index == i) return temp;
			temp = temp->next;
		}
	}
	return nullptr;
}

StringList::~StringList() {
	StringNode* curr = head;
	StringNode* temp;
	while (curr != nullptr) {
		temp = curr;
		curr = curr->next;
		delete temp;
	}
	head = nullptr;
	tail = nullptr;
	listSize = 0;
}