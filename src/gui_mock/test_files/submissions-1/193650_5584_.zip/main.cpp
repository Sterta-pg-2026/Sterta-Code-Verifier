#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "string.h"
#include "list.h"
#include "node.h"
#include "const.h"
using namespace std;

int main()
{
	String input; //input word
	String space = " ", putter, first, second, third;
	String tempProperty, tempValue, tempSelector;
	List CSS; //list containing css
	CSS.Add();
	int token = 0, check = -1; //0 = selector, 1 = property, 2 = value, 3 - Commands
	int seqnum = 0, flag = 0, tempint = 0;


	while (cin >> input)
	{
		if (CSS.getLastNode()->checkfull(T - 1) == true)
		{
			CSS.Add();
		}
		if (input == "????")
		{
			token = 3;
		}
		else if (input == "****")
		{
			token = 0;
		}
		else if (input == "{")
		{
			if (tempSelector.getSize() != 0)
			{
				CSS.getLastNode()->AddSelector(tempSelector);
				tempSelector.clearString();
			}
			token = 1;
			flag = 0;
		}
		else if (input == "}")
		{
			CSS.getLastNode()->tickfull(CSS.getLastNode()->checkfull());
			token = 0;
			seqnum++;
		}
		else
		{
			if (input[0] == '{')
			{
				token = 1;
				if (tempSelector.getSize() != 0)
				{
					CSS.getLastNode()->AddSelector(tempSelector);
					tempSelector.clearString();
				}
				putter = strtok(input.getText(), "{");
			}
			if (input[0] == '}')
			{
				token = 0;
				if (tempProperty.getSize() != 0)
				{
					CSS.getLastNode()->AddAttribute(tempProperty,tempValue);
					tempProperty.clearString();
					tempValue.clearString();
					CSS.getLastNode()->tickfull(CSS.getLastNode()->checkfull());
					token = 0;
					seqnum++;
				}
				putter = strtok(input.getText(), "}");
			}
			if (token == 0)
			{
				check = input.findChar('{');
				if (input.findChar(',') == -1)
				{
					flag = 10;
				}
				else
				{
					flag = 0;
				}
				if (check == -1)
				{
					char* word = strtok(input.getText(), ",");
					while (word != nullptr)
					{
						if (tempSelector.getSize() == 0)
						{
							tempSelector = word;
						}
						else
						{
							tempSelector = tempSelector + space + word;
						}
						if (flag != 10) {
							CSS.getLastNode()->AddSelector(tempSelector);
							tempSelector.clearString();
						}
						word = strtok(nullptr, ",");
					}
					delete[] word;
				}
				else
				{
					putter = strtok(input.getText(), ",");
					while (putter.findChar('{') == -1)
					{
						if (tempSelector.getSize() == 0)
						{
							tempSelector = putter;
						}
						else
						{
							tempSelector = tempSelector + space + putter;
						}
						putter = strtok(nullptr, ",");
					}
					putter = strtok(putter.getText(), "{");
					if (tempSelector.getSize() == 0)
					{
						tempSelector = putter;
					}
					else
					{
						tempSelector = tempSelector + space + putter;
					}
					CSS.getLastNode()->AddSelector(tempSelector);
					tempSelector.clearString();
					token = 1;
					putter = strtok(input.getText(), "{");
					putter = strtok(nullptr, "{");
					input.clearString();
				}
			}
			if (token == 1)
			{
				if (putter.getText() != nullptr)
				{
					token = 2;
					if (putter[putter.getSize() - 1] == ':') flag = 10;
					tempProperty = strtok(putter.getText(), ":");
					putter = strtok(nullptr, ":");
				}
				else if(input.getText() != nullptr)
				{
					token = 2;
					if (input[input.getSize() - 1] == ':') flag = 10;
					tempProperty = strtok(input.getText(), ":");
					putter = strtok(nullptr, ":");
				}
				if (flag == 10)
				{
					flag = 0;
					continue;
				}
			}
			if (token == 2)
			{
				if (putter.getText() != nullptr)
				{
					if (putter.findChar('}') != -1)
						flag = 10;

					if (putter.findChar(';') != -1)
					{
						if (tempValue.getSize() == 0)
						{
							tempValue = strtok(putter.getText(), ";");
						}
						else
						{ 
							tempValue = tempValue + space + putter;
						}
						CSS.getLastNode()->AddAttribute(tempProperty, tempValue);
						tempProperty.clearString();
						tempValue.clearString();
						token = 1;
					}
					else
					{
						if (tempValue.getSize() == 0)
						{
							tempValue = strtok(putter.getText(), "}");
						}
						else
						{
							tempValue = tempValue + space + putter;
						}
					}
				}
				else
				{
					if (input.findChar('}') != -1)
						flag = 10;
					if (input.findChar(';') != -1)
					{
						if (tempValue.getSize() == 0)
						{
							tempValue = strtok(input.getText(), ";");
						}
						else
						{
							putter = strtok(input.getText(), ";");
							tempValue = tempValue + space + putter;
						}
						token = 1;
						CSS.getLastNode()->AddAttribute(tempProperty, tempValue);
						tempProperty.clearString();
						tempValue.clearString();
					}
					else
					{
						if (tempValue.getSize() == 0)
							tempValue = input;
						else
							tempValue = tempValue + space + input;
					}
				}
				if (flag == 10)
				{
					if (tempProperty.getSize() != 0)
					{
						CSS.getLastNode()->AddAttribute(tempProperty, tempValue);
						tempProperty.clearString();
						tempValue.clearString();
					}
					CSS.getLastNode()->tickfull(CSS.getLastNode()->checkfull());
					flag = 0;
					token = 0;
					seqnum++;
				}
			}
			if (token == 3)
			{

				if (input == "?")
				{
					cout << "? == " << seqnum << endl;
				}
				else
				{
					if (input.findChar(',') == -1 && first.getSize() == 0)
					{
						first = input;
						continue;
					}
					else if (input.findChar(',') == -1 && first.getSize() != 0)
					{
						first = first + space + input;
						continue;
					}
					else if (first.getSize() != 0 && input.findChar(',') != -1)
					{
						first = first + space + strtok(input.getText(), ",");
						second = strtok(nullptr, ",");
						third = strtok(nullptr, ",");
					}
					else
					{
						first = strtok(input.getText(), ",");
						second = strtok(nullptr, ",");
						third = strtok(nullptr, ",");
						if (second.getText() == nullptr || third.getText() == nullptr)
						{
							first.clearString();
							cin >> input;
							continue;
						}
					}
					if (second == "S")
					{
						if (atoi(first.getText()) != 0 && third == "?")
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr && CSS.getNodeByNumber(atoi(first.getText()) - 1)->checkfull(CSS.getIndexByNumber(atoi(first.getText()))) == true)
							{
								tempint = CSS.getNodeByNumber(atoi(first.getText()) - 1)->getSelectors(CSS.getIndexByNumber(atoi(first.getText())))->Length();
								cout << first << "," << second << "," << third << " == " << tempint << endl;
							}
						}
						else if (atoi(first.getText()) != 0 && atoi(third.getText()) != 0)
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr && CSS.getNodeByNumber(atoi(first.getText()) - 1)->checkfull(CSS.getIndexByNumber(atoi(first.getText()))) == true && CSS.getNodeByNumber(atoi(first.getText()) - 1)->getSelectors(CSS.getIndexByNumber(atoi(first.getText())))->Length() >= atoi(third.getText()))
							{
								cout << first << "," << second << "," << third << " == " << CSS.getNodeByNumber(atoi(first.getText()) - 1)->getSelectors(CSS.getIndexByNumber(atoi(first.getText())))->getNode(atoi(third.getText()) - 1)->getValue().getText() << endl;
							}
						}
						else if(third == "?")
						{
							cout << first << "," << second << "," << third << " == " << CSS.getNumSel(first) << endl;
						}
					}
					else if (second == "A")
					{
						if (atoi(first.getText()) != 0 && third == "?")
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr && CSS.getNodeByNumber(atoi(first.getText()) - 1)->checkfull(CSS.getIndexByNumber(atoi(first.getText()))) == true)
							{
								tempint = CSS.getNodeByNumber(atoi(first.getText()) - 1)->getAttributes(CSS.getIndexByNumber(atoi(first.getText())))->getUniqueAttributes();
								cout << first << "," << second << "," << third << " == " << tempint << endl;
							}

						}
						else if (atoi(first.getText()) != 0 && third.getText() != "?")
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr && CSS.getNodeByNumber(atoi(first.getText()) - 1)->checkfull(CSS.getIndexByNumber(atoi(first.getText()))) == true)
							{
								putter = CSS.getNodeByNumber(atoi(first.getText()) - 1)->getAttributes(CSS.getIndexByNumber(atoi(first.getText())))->findByProperty(third);
								if (putter == "")
								{
									//tu nic nie robimy ;)
								}
								else
								{
									cout << first << "," << second << "," << third << " == " << putter << endl;
								}
							}
						}
						else
						{
							cout << first << "," << second << "," << third << " == " << CSS.getNumAttr(first) << endl;
						}
					}
					else if (second == "E")
					{
						putter = CSS.getValueOfSelector(first, third);
						if (putter == "") {}
						else
						{
							cout << first << "," << second << "," << third << " == " << putter << endl;
						}
					}
					else if (second == "D")
					{
						if (third == "*")
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr)
							{
								switch (CSS.getNodeByNumber(atoi(first.getText()) - 1)->deleteSection(CSS.getIndexByNumber(atoi(first.getText()))))
								{
								case 0:
									cout << first << "," << second << "," << third << " == deleted" << endl;
									seqnum--;
									if (seqnum == 0)
									{
										CSS.Add();
									}
									break;
								case -1:
									cout << first << "," << second << "," << third << " == deleted" << endl;
									CSS.RemoveNode(CSS.getNodeByNumber(atoi(first.getText()) - 1));
									seqnum--;
									if (seqnum == 0)
									{
										CSS.Add();
									}
										break;
								}
							}
						}
						else
						{
							if (CSS.getNodeByNumber(atoi(first.getText()) - 1) != nullptr && CSS.getNodeByNumber(atoi(first.getText()) - 1)->checkfull(CSS.getIndexByNumber(atoi(first.getText()))) == true)
							{
								switch (CSS.getNodeByNumber(atoi(first.getText()) - 1)->getAttributes(CSS.getIndexByNumber(atoi(first.getText())))->deleteByProperty(third.getText()))
								{
								case 0:
									cout << first << "," << second << "," << third << " == deleted" << endl;
									break;
								case -1:
									cout << first << "," << second << "," << third << " == deleted" << endl;
									if (CSS.getNodeByNumber(atoi(first.getText()) - 1)->deleteSection((CSS.getIndexByNumber(atoi(first.getText())))) == -1)
									{
										CSS.RemoveNode(CSS.getNodeByNumber(atoi(first.getText()) - 1));
										seqnum--;
										if (seqnum == 0)
										{
											CSS.Add();
										}
									}
									else
									{
										seqnum--;
									}
									
									break;
								}
							}
						}	
					}
				}
				first.clearString();
				second.clearString();
				third.clearString();
			}
		}
		putter.clearString();
	}
	return 0;
}