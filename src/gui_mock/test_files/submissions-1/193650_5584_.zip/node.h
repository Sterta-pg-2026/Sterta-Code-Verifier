#pragma once
#include "string.h"
#include "const.h"
#include "stringnode.h"
#include "doublestringnode.h"
class Node { //Node = CSS Block
private:
	Node* prev;
	Node* next;
	StringList selectors[T];
	bool empty[T];
	doubleStringList attributes[T];
	friend class List;
public:
	Node();
	void AddSelector(String selector);
	void AddAttribute(String prop, String val);
	int checkfull();
	bool checkfull(int index) const;
	void tickfull(int n);
	bool* getEmpty();
	StringList* getSelectors(int index);
	doubleStringList* getAttributes(int index);
	int deleteSection(int index);
	int EmptyOfNumber(int index);
	~Node();
};