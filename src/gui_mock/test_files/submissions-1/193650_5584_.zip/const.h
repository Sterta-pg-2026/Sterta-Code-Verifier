#pragma once
const int T = 19;