#include "doublestringnode.h"
	doubleStringList::doubleStringList()
	{
		head = nullptr;
		tail = nullptr;
		listSize = 0;
	}
	void doubleStringList::Add(String prop, String val)
	{
		listSize++;
		doubleStringNode* node = new doubleStringNode(prop, val);
		if (head == nullptr)
		{
			head = node;
			tail = head;
		}
		else if (head->next == nullptr)
		{
			tail = node;
			tail->prev = head;
			head->next = tail;
		}
		else
		{
			doubleStringNode* temp = tail;
			tail = node;
			tail->prev = temp;
			temp->next = tail;
		}
	}
	int doubleStringList::Length() const
	{
		return listSize;
	}

	void doubleStringList::Remove(int number)
	{
		listSize--;
		if (number < listSize / 2)
		{
			doubleStringNode* temp = head;
			if (number == 1)
			{
				head = head->next;
				head->next->prev = head;
				temp = nullptr;
			}
			else
			{
				for (int i = 1; i < number; i++)
				{
					temp = temp->next;
				}
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				temp = nullptr;
			}

		}
		else
		{
			doubleStringNode* temp = tail;
			if (number == Length())
			{
				tail = tail->prev;
				tail = nullptr;
			}
			else
			{
				for (int i = Length(); i > 0; i--)
				{
					temp = temp->next;
				}
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				temp = nullptr;
			}
		}
		listSize--;
	}

	doubleStringNode* doubleStringList::getLastNode() {
		return tail;
	}

	doubleStringNode* doubleStringList::getNode(int index)
	{
		doubleStringNode* temp = head;
		for (int i = 0; i < listSize; i++)
		{
			if (index == i) return temp;
			temp = temp->next;
		}
		return nullptr;
	}

	String doubleStringList::findByProperty(String prop)
	{
		doubleStringNode* temp = tail;
		while (temp != nullptr)
		{
			if (temp->getProperty() == prop) return temp->getValue();
			temp = temp->prev;
		}
		return "";
	}

	int doubleStringList::getUniqueAttributes()
	{
		doubleStringNode* temp = tail;
		doubleStringNode* tempback = temp;
		int token = 0, counter = 0;
		while (temp != nullptr)
		{
			tempback = temp;
			while (tempback != nullptr)
			{
				if (tempback->getProperty() == temp->getProperty() && tempback != temp)
				{
					token = 1;
					break;
				}
				tempback = tempback->prev;
			}
			if (token == 0)
			{
				counter++;
			}
			token = 0;

			temp = temp->prev;
		}
		return counter;
	}

	int doubleStringList::deleteByProperty(String prop)
	{
		doubleStringNode* temp;
		if (tail == nullptr)
		{
			temp = head;
		}
		else
		{
			temp = tail;
		}
		while (temp != nullptr)
		{
			if (temp->getProperty() == prop)
			{
				listSize--;
				if (listSize == 0)
				{
					return -1;
				}
				else
				{
					if (temp == head)
					{
						head = head->next;
						head->prev = nullptr;
					}
					else if (temp == tail)
					{
						tail = temp->prev;
						tail->next = nullptr;
					}
					else
					{
						temp->ConnectNeighbours();
					}
					temp->~doubleStringNode();
					return 0;
				}
			}
			temp = temp->prev;
		}
		return 1;
	}

	doubleStringList::~doubleStringList() {
		doubleStringNode* curr = head;
		while (curr != nullptr) {
			doubleStringNode* temp = curr;
			curr = curr->next;
			delete temp;
		}
		head = nullptr;
		tail = nullptr;
		listSize = 0;
	}