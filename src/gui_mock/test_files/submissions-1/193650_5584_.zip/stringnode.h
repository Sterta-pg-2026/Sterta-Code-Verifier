#pragma once
#include "string.h"
class StringNode {
private:
	String data;
	StringNode* next;
	StringNode* prev;
	friend class StringList;
public:
	StringNode();
	StringNode(String data);
	void Add(String selector);
	String getValue();
	~StringNode();
};

class StringList
{
private:
	StringNode* head;
	StringNode* tail;
	int listSize;
public:
	StringList();
	void Add(String selector);
	int Length() const;
	void Remove(int number);
	StringNode* getLastNode();
	StringNode* getNode(int index);
	~StringList();
};