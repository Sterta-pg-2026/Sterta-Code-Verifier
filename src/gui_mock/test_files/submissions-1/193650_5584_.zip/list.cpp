#include "list.h"

List::List()
{
	head = nullptr;
	tail = nullptr;
	listSize = 0;
}
void List::Add()
{
	listSize++;
	Node* node = new Node();
	if (listSize == 1)
	{
		head = node;
	}
	else if (listSize == 2)
	{
		tail = node;
		tail->prev = head;
		head->next = tail;
	}
	else
	{
		Node* temp = tail;
		tail = node;
		tail->prev = temp;
		temp->next = tail;
	}
}
int List::Length() const
{
	return listSize;
}

void List::Remove(int number)
{
	this->listSize -= 1;
	Node* temp = head;
	if (number == 1)
	{
		if (head->next != nullptr)
		{
			head = head->next;
			head->prev = nullptr;
			head->next->prev = head;
		}
		temp->~Node();
	}
	else
	{

		for (int i = 1; i < number; i++)
		{
			temp = temp->next;
		}
		temp->prev->next = temp->next;
		temp->next->prev = temp->prev;
		temp = nullptr;
	}
}

void List::RemoveNode(Node* node)
{
	listSize--;
	if (node == head && head->next != nullptr)
	{
		head = node->next;
	}
	else if (node == tail && tail->prev != nullptr)
	{
		tail = node->prev;
	}
	else
	{
		node->next->prev = node->prev;
		node->prev->next = node->next;
	}
	node->~Node();
}

Node* List::getLastNode() {
	if (listSize == 1)
	{
		return head;
	}
	return tail;
}

int List::getNumSel(String selector) const {
	Node* temp = head;
	int reps = 0;
	while (temp != nullptr) {
		for (int i = 0; i < T; i++)
		{
			if (temp->getEmpty()[i] == true)
			{
				for (int j = 1; j <= temp->getSelectors(i)->Length(); j++)
				{
					if (selector == temp->getSelectors(i)->getNode(j - 1)->getValue())
					{
						reps++; break;
					}
				}
			}
		}
		temp = temp->next;
	}
	return reps;
}

int List::getNumAttr(String selector) const {
	Node* temp = head;
	int reps = 0;
	while (temp != nullptr) {
		for (int i = 0; i < T; i++)
		{
			for (int j = 1; j <= temp->getAttributes(i)->Length(); j++)
			{
				if (selector == temp->getAttributes(i)->getNode(j - 1)->getProperty())
				{
					reps++; break;
				}
			}
		}
		temp = temp->next;
	}
	return reps;
}

String List::getValueOfSelector(String selector, String prop) const
{
	if (head->next == nullptr)
	{
		Node* temp = head;
		for (int i = T - 1; i >= 0; i--)
		{
			for (int j = temp->getSelectors(i)->Length(); j > 0; j--)
			{
				if ((temp->getSelectors(i)->getNode(j - 1)->getValue() == selector) || (temp->getSelectors(i)->getNode(j - 1)->getValue() == ""))
				{
					for (int k = temp->getAttributes(i)->Length(); k > 0; k--)
					{
						if (prop == temp->getAttributes(i)->getNode(k - 1)->getProperty()) return temp->getAttributes(i)->getNode(k - 1)->getValue();
					}
				}
			}
		}
	}
	else
	{
		Node* temp = tail;
		while (temp != nullptr) {
			for (int i = T - 1; i >= 0; i--)
			{
				for (int j = temp->getSelectors(i)->Length(); j > 0; j--)
				{
					if ((temp->getSelectors(i)->getNode(j - 1)->getValue() == selector) || (temp->getSelectors(i)->getNode(j - 1)->getValue() == ""))
					{
						for (int k = temp->getAttributes(i)->Length(); k > 0; k--)
						{
							if (prop == temp->getAttributes(i)->getNode(k - 1)->getProperty()) return temp->getAttributes(i)->getNode(k - 1)->getValue();
						}
					}
				}
			}
			temp = temp->prev;
		}
	}
	return "";
}

Node* List::getNodeByNumber(int index) {
	if (index == 0) return head;
	int indexcounter = 0;
	Node* temp = head;
	while (temp != nullptr)
	{
		for (int i = 0; i < T; i++) {
			if (index == indexcounter) return temp;
			if (temp->checkfull(i) == true) indexcounter++;
		}
		temp = temp->next;
	}
	return nullptr;
}

int List::getIndexByNumber(int index) const {
	int indexcounter = 0;
	Node* temp = head;
	while (temp != nullptr)
	{
		for (int i = 0; i < T; i++) {
			if (temp->checkfull(i) == true) indexcounter++;
			if (index == indexcounter) return i;
		}
		temp = temp->next;
	}
	return -1;
}

List::~List() {
	Node* curr = head;
	while (curr != nullptr) {
		Node* temp = curr;
		curr = curr->next;
		delete temp;
	}
	head = nullptr;
	tail = nullptr;
}