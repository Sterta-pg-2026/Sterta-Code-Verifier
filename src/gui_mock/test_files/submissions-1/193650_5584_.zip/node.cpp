#include "node.h"
Node::Node() {
	this->prev = nullptr;
	this->next = nullptr;
	for (int i = 0; i < T; i++)
	{
		empty[i] = false;
	}
}
void Node::AddSelector(String selector)
{
	int check = checkfull();
	if (check != -1)
	{
		selectors[check].Add(selector);
	}
}
void Node::AddAttribute(String prop, String val)
{
	int check = checkfull();
	if (check != -1)
	{
		attributes[check].Add(prop,val);
		
	}
}
	int Node::checkfull()
	{
		for (int i = 0; i < T; i++)
		{
			if (empty[i] == false) return i;
		}
		return -1;
	}
	void Node::tickfull(int n) {
		empty[n] = true;
	}

	bool* Node::getEmpty()
	{
		return empty;
	}

	StringList* Node::getSelectors(int index)
	{
		return &selectors[index];
	}

	doubleStringList* Node::getAttributes(int index)
	{
		return &attributes[index];
	}

	int Node::deleteSection(int index) {
		if (checkfull(index) == true)
		{
			selectors[index].~StringList();
			attributes[index].~doubleStringList();
			empty[index] = false;
			for (int i = 0; i < T; i++)
			{
				if (empty[i] == true) return 0;
			}
			return -1;
		}
		return 1;
	}

	bool Node::checkfull(int index) const {
		if(index < T)
			if (empty[index] == true)
					return true;
		return false;
	}
	int Node::EmptyOfNumber(int index)
	{
		int full = 0;
		for (int i = 0; i < T; i++)
		{
			if (full == index) return i;
			if (empty[i] == true) full++;
		}
		return -1;
	}

	Node::~Node()
	{
		next = nullptr;
		prev = nullptr;
	}
