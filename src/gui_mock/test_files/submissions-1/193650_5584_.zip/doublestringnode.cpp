#include "doublestringnode.h"

doubleStringNode::doubleStringNode() {
	this->next = nullptr;
	this->prev = nullptr;
}

doubleStringNode::doubleStringNode(String prop, String val) {
	this->next = nullptr;
	this->prev = nullptr;
	this->prop = prop;
	this->val = val;
}

void doubleStringNode::Add(String prop, String val)
{
	this->prop = prop;
	this->val = val;
}

String doubleStringNode::getValue() {
	String temp = val;
	return temp;
}

String doubleStringNode::getProperty() {
	String temp = prop;
	return temp;
}

void doubleStringNode::ConnectNeighbours() {
	next->prev = prev;
	prev->next = next;
}

doubleStringNode::~doubleStringNode()
{
	next = nullptr;
	prev = nullptr;
}
