#pragma once
#include "node.h"

class List
{
private:
	Node* head;
	Node* tail;
	int listSize;
public:
	List();
	void Add();
	int Length() const;
	void Remove(int number);
	void RemoveNode(Node* node);
	Node* getLastNode();
	int getNumSel(String selector) const;
	int getNumAttr(String selector) const;
	String getValueOfSelector(String selector, String prop) const;
	Node* getNodeByNumber(int index);
	int getIndexByNumber(int index) const;
	~List();
};