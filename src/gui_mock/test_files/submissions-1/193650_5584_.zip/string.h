#pragma once
#include <iostream>
class String
{
private:
	char* data;
	size_t size;
public:
	String(const char* str = "");
	String(const String& other);
	String(String&& other) noexcept;
	~String();
	String& operator=(const String& other);
	String& operator=(String&& other) noexcept;
	String operator+(const String& other) const;
	bool operator==(const String& other) const;
	char& operator[](size_t index);
	size_t getSize() const;
	char* getText();
	void clearString();
	int findChar(char c) const;
};
std::ostream& operator<<(std::ostream& os, String& string);
std::istream& operator>>(std::istream& is, String& string);
