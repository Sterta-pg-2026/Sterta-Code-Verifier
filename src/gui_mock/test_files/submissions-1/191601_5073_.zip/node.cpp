#include "node.h"

Node::Node() : next(nullptr) {
}

Node::~Node() {
}

char* Node::GetSelector() {
    return nullptr;
}

char* Node::GetKey() {
    return nullptr;
}

char* Node::GetValue() {
    return nullptr;
}

void Node::PrintData(std::ostream& os) const {
    os << "";
    return;
}