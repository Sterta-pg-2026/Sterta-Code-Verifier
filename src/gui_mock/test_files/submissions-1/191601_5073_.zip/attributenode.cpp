#include <string.h>
#include "attributenode.h"
#pragma warning(disable : 4996)

AttributeNode::AttributeNode() : key(nullptr), value(nullptr) {
}

AttributeNode::AttributeNode(char* key, char* value) {
    this->key = new char[strlen(key) + 1];
    strcpy(this->key, key);
    this->key[strlen(key)] = '\0';
    this->value = new char[strlen(value) + 1];
    strcpy(this->value, value);
    this->value[strlen(value)] = '\0';
};

AttributeNode::~AttributeNode() {
    delete[] key;
    delete[] value;
}

char* AttributeNode::GetKey() {
    return key;
}

char* AttributeNode::GetValue() {
    return value;
}

void AttributeNode::PrintData(std::ostream& os) const {
    os << key << ": " << value << std::endl;
    return;
}