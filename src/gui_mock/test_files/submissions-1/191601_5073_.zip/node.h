#pragma once
#include <iostream>

class Node {
public:
    Node* next;
    Node();
    virtual ~Node();
    virtual char* GetSelector();
    virtual char* GetKey();
    virtual char* GetValue();
    virtual void PrintData(std::ostream& os) const;
};