#include "doublylinkedlist.h"

DoublyLinkedList::DoublyLinkedList() : head(nullptr) {
}

SectionNode* DoublyLinkedList::GetHead() {
    return head;
}

DoublyLinkedList::~DoublyLinkedList() {
    SectionNode* tmp = new SectionNode();
    while (head != nullptr) {
        tmp = head;
        head = head->next;
        delete tmp;
    }
    return;
}

void DoublyLinkedList::SetHead(SectionNode& newHead) {
    head = &newHead;
}

void DoublyLinkedList::AddLast(SectionNode* newNode) {
    newNode->next = nullptr;
    if (head == nullptr) {
        head = newNode;
        return;
    }
    SectionNode* tmp = head;
    while (tmp->next != nullptr) {
        tmp = tmp->next;
    }
    tmp->next = newNode;
    newNode->previous = tmp;
    return;
}

void DoublyLinkedList::RemoveNode(SectionNode* node) {
    SectionNode* del = node;
    if (node->next == nullptr && node->previous == nullptr) {
        head = nullptr;
        delete del;
    }
    else if (node->previous == nullptr) {
        head = node->next;
        head->previous = nullptr;
        delete del;
    }
    else if (node->next == nullptr) {
        node->previous->next = nullptr;
        delete del;
    }
    else if (node->next != nullptr) {
        node->previous->next = node->next;
        delete del;
    }
    return;
}

std::ostream& operator<<(std::ostream& os, DoublyLinkedList& list) {
    SectionNode* tmp = list.GetHead();
    if (tmp == nullptr) {
        os << "List is empty\n";
        return os;
    }
    while (tmp != nullptr) {
        tmp->PrintData(os);
        tmp = tmp->next;
    }
    return os;
}