#pragma once
#include "node.h"

class SelectorNode : public Node {
public:
    char* selector;
    SelectorNode();
    SelectorNode(char* selector);
    ~SelectorNode();
    void PrintData(std::ostream& os) const override;
    char* GetSelector() override;
};