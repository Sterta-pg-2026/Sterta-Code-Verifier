#pragma once
#include <iostream>
#include "linkedlist.h"

LinkedList::LinkedList() : head(nullptr) {
}

LinkedList::~LinkedList() {
    Node* tmp = new Node();
    while (head != nullptr) {
        tmp = head;
        head = head->next;
        delete tmp;
    }
    return;
}

Node* LinkedList::GetHead() {
    return head;
}

void LinkedList::SetHead(Node& newHead) {
    head = &newHead;
    return;
}

void LinkedList::AddLast(Node* newNode) {
    if (head == nullptr) {
        head = newNode;
        return;
    }
    newNode->next = nullptr;
    Node* tmp = head;
    while (tmp->next != nullptr) {
        tmp = tmp->next;
    }
    tmp->next = newNode;
    return;
}

Node* LinkedList::FindSelNode(char* dataPattern) {
    Node* tmp = head;
    while (tmp != nullptr) {
        if (strcmp(dataPattern, tmp->GetSelector()) == 0) {
            return tmp;
        };
        tmp = tmp->next;
    }
    return nullptr;
}

Node* LinkedList::FindAttrNode(char* dataPattern) {
    Node* tmp = head;
    while (tmp != nullptr) {
        if (strcmp(dataPattern, tmp->GetKey()) == 0) break;
        tmp = tmp->next;
    }
    return tmp;
}

Node* LinkedList::FindBefore(char* dataPattern) {
    Node* tmp = head;
    if (tmp == nullptr) return nullptr;
    if (strcmp(dataPattern, tmp->GetKey()) == 0) return tmp;
    if (tmp->next == nullptr) return tmp;
    while (tmp != nullptr && tmp->next != nullptr) {
        if (strcmp(dataPattern, tmp->next->GetKey()) == 0) return tmp;
        tmp = tmp->next;
    }
    return nullptr;
}

Node* LinkedList::RemoveFirst(Node* head) {
    Node* del = head;
    head = head->next;
    delete del;
    return head;
}

std::ostream& operator<<(std::ostream& os, LinkedList& list) {
    if (&list == nullptr) return os;
    Node* tmp = list.GetHead();
    if (tmp == nullptr) {
        os << "List is empty\n";
        return os;
    }
    while (tmp != nullptr) {
        tmp->PrintData(os);
        tmp = tmp->next;
    }
    return os;
}