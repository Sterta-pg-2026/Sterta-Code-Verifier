#pragma once
#include "node.h"

class AttributeNode : public Node {
public:
    char* key;
    char* value;
    AttributeNode();
    AttributeNode(char* key, char* value);
    ~AttributeNode();
    void PrintData(std::ostream& os) const override;
    char* GetKey() override;
    char* GetValue() override;
};