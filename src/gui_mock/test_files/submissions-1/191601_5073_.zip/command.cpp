#include <string.h>
#include "command.h"
#pragma warning(disable : 4996)

Command::Command() {
    args = new char* [COMMAND_ARGS];
}

Command::Command(char** args) {
    this->args = new char* [COMMAND_ARGS];
    for (int i = 0; i < COMMAND_ARGS; i++) {
        if (args[i] != nullptr) {
            this->args[i] = new char(strlen(args[i] + 1));
            strcpy(this->args[i], args[i]);
            this->args[i][strlen(args[i])] = '\0';
        }
    }
}

Command::~Command() {
    for (int i = 0; i < COMMAND_ARGS; i++) {
        delete[] args[i];
    }
    delete[] args;
}

std::ostream& operator<<(std::ostream& os, Command& command) {
    for (int i = 0; i < COMMAND_ARGS; i++) {
        if (command.args[i] != nullptr) os << command.args[i];
        if (i < COMMAND_ARGS - 1 && command.args[0] != nullptr) os << ",";
    }
    return os;
}