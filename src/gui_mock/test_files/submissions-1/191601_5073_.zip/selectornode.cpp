#include <string.h>
#include "selectornode.h"
#pragma warning(disable : 4996)

SelectorNode::SelectorNode() : selector(nullptr) {
}

SelectorNode::SelectorNode(char* selector) {
    this->selector = new char[strlen(selector) + 1];
    strcpy(this->selector, selector);
    this->selector[strlen(selector)] = '\0';
};

SelectorNode::~SelectorNode() {
    delete[] selector;
}

char* SelectorNode::GetSelector() {
    return selector;
}

void SelectorNode::PrintData(std::ostream& os) const {
    os << selector << std::endl;
    return;
}