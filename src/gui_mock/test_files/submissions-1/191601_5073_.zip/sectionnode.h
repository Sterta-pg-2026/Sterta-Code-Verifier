#pragma once
#include <iostream>
#include "linkedlist.h"
#include "section.h"
#define SIZE 17

class SectionNode {
public:
    SectionNode* next;
    SectionNode* previous;
    Section sections[SIZE];
    int usedCells;
    SectionNode();
    ~SectionNode();
    void PrintData(std::ostream& os) const;
    Section& operator[](std::size_t i);
};

std::ostream& operator<<(std::ostream& os, const SectionNode& section);