#pragma once
#include <iostream>
#define COMMAND_ARGS 3

class Command {
public:
    char** args;
    Command();
    Command(char** args);
    ~Command();
};

std::ostream& operator<<(std::ostream& os, Command& command);