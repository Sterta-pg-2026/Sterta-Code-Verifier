// Project_1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
#include <sstream>
#include "linkedlist.h"
#include "node.h"
#include "selectornode.h"
#include "attributenode.h"
#include "doublylinkedlist.h"
#include "section.h"
#include "sectionnode.h"
#include "command.h"
#pragma warning(disable : 4996)
#define BUFFER 150
#define COMM_KEY_POS 1
using namespace std;

enum stopParsing {
    PARSE,
    END_OF_CSS,
    END_OF_FILE
};

enum {
    NUM1 = 1,
    STR1 = 2,
    QUE2 = 10,
    STAR2 = 20,
    SEL2 = 30,
    ATTR2 = 40,
    EATTR2 = 50,
    DEL2 = 60,
    QUE3 = 100,
    STAR3 = 200,
    NUM3 = 300,
    STR3 = 400,
    UNDEF = 1000,
    EXIT = 2000
};

int readSelectors(LinkedList* selectors) {
    int i = 0, stopParsing = 0;
    char checkValue, tmp[BUFFER];
    while (std::cin >> noskipws >> checkValue && !std::cin.eof()) {
        if (i != 0 && isspace(checkValue) && !isspace(tmp[i - 1])) {
            tmp[i] = ' ';
            i++;
        }
        else if (checkValue == '{' || checkValue == ',') {
            tmp[i] = '\0';
            if (strcmp(tmp, "") == 0) return PARSE;
            if (i != 0 && tmp[i - 1] == ' ') tmp[i - 1] = '\0';
            i = 0;
            SelectorNode* selector = new SelectorNode(tmp);
            selectors->AddLast(selector);
            if (checkValue == '{') return PARSE;
        }
        else if (checkValue == '?') {
            stopParsing++;
            if (stopParsing == 4) return END_OF_CSS;
        }
        else if (checkValue == '*') {
            stopParsing++;
            if (stopParsing == 4) return PARSE;
        }
        else if (checkValue == '\x1a') {
            return EXIT;
        }
        else if (!isspace(checkValue)) {
            tmp[i] = checkValue;
            i++;
        }
    }
    return EXIT;
}

void deleteDuplicate(LinkedList* attributes, char* pattern) {
    Node* tmp = attributes->FindBefore(pattern);
    if (tmp == nullptr) return;
    if (strcmp(attributes->GetHead()->GetKey(), pattern) == 0) {
        tmp = attributes->RemoveFirst(attributes->GetHead());
        attributes->SetHead(*tmp);
        return;
    }
    if (tmp->next == nullptr) return;
    Node* del;
    del = tmp->next;
    tmp->next = tmp->next->next;
    delete del;
    return;
}

int readAttributes(LinkedList* attributes) {
    int i = 0;
    char checkValue, tmp1[BUFFER], tmp2[BUFFER];
    while (std::cin >> noskipws >> checkValue && !std::cin.eof()) {
        if (i != 0 && isspace(checkValue) && !isspace(tmp1[i - 1])) {
            tmp1[i] = ' ';
            i++;
        }
        else if (checkValue == ':') {
            tmp1[i] = '\0';
            if (i != 0 && tmp1[i - 1] == ' ') tmp1[i - 1] = '\0';
            strcpy(tmp2, tmp1);
            i = 0;
            tmp1[i] = '\0';
        }
        else if (checkValue == ';' || checkValue == '}') {
            if (i == 0) return PARSE;
            tmp1[i] = '\0';
            if (tmp1[i - 1] == ' ') tmp1[i - 1] = '\0';
            deleteDuplicate(attributes, tmp2);
            AttributeNode* attribute = new AttributeNode(tmp2, tmp1);
            attributes->AddLast(attribute);
            if (checkValue == '}') return PARSE;
            i = 0;
            tmp1[i] = '\0';
            tmp2[i] = '\0';
        }
        else if (checkValue == '\x1a') {
            return EXIT;
        }
        else if (!isspace(checkValue)) {
            tmp1[i] = checkValue;
            i++;
        }
    }
    return EXIT;
}

int readCommand(Command* command) {
    int i = 0, j = 0, eof = 0;
    char checkValue, tmp[COMMAND_ARGS][BUFFER];
    while (!eof) {
        std::cin >> noskipws >> checkValue;
        if (std::cin.eof() && checkValue != '\n') eof = 1;
        if (j != 0 && isspace(checkValue) && !isspace(tmp[i][j - 1])) {
            tmp[i][j] = ' ';
            j++;
        }
        if (checkValue == '\n' || eof) {
            if (j == 0) continue;
            tmp[i][j] = '\0';
            if (j != 0 && tmp[i][j - 1] == ' ') tmp[i][j - 1] = '\0';
            i++;
            for (int k = 0; k < i; k++) {
                command->args[k] = new char[strlen(tmp[k])];
                strcpy(command->args[k], tmp[k]);
            }
            if (i == 1) {
                command->args[COMM_KEY_POS] = command->args[0];
                command->args[0] = nullptr;
                command->args[2] = nullptr;
            }
            return END_OF_CSS;
        }
        else if (checkValue == ',') {
            tmp[i][j] = '\0';
            i++; j = 0;
        }
        else if (checkValue == '\x1a') {
            return EXIT;
        }
        else if (!isspace(checkValue)) {
            if (i >= 3) return UNDEF;
            tmp[i][j] = checkValue;
            j++;
        }
    }
    return EXIT;
}

int interpretCommandSec1(char* commandStr) {
    if (commandStr[0] >= '0' && commandStr[0] <= '9') return NUM1;
    else return STR1;
}

int interpretCommandSec2(char* commandStr) {
    if (strcmp(commandStr, "?") == 0) return QUE2;
    else if (strcmp(commandStr, "****") == 0) return STAR2;
    else if (strcmp(commandStr, "EXIT") == 0) return EXIT;
    else if (strcmp(commandStr, "S") == 0) return SEL2;
    else if (strcmp(commandStr, "A") == 0) return ATTR2;
    else if (strcmp(commandStr, "E") == 0) return EATTR2;
    else if (strcmp(commandStr, "D") == 0) return DEL2;
    else return UNDEF;
}

int interpretCommandSec3(char* commandStr) {
    if (strcmp(commandStr, "?") == 0) return QUE3;
    else if (strcmp(commandStr, "*") == 0) return STAR3;
    else if (commandStr[0] >= '0' && commandStr[0] <= '9') return NUM3;
    else return STR3;
}

int interpretCommand(Command* command) {
    int result = 0;
    result += interpretCommandSec2(command->args[COMM_KEY_POS]);
    if (command->args[0] == nullptr) return result;
    else {
        result += interpretCommandSec1(command->args[0]);
        result += interpretCommandSec3(command->args[2]);
    }
    return result;
}

SectionNode* findSection(SectionNode* cssHead, int* nSect) {
    while (*nSect >= cssHead->usedCells) {
        *nSect -= cssHead->usedCells;
        if (cssHead->next == nullptr) return nullptr;
        cssHead = cssHead->next;
    }
    return cssHead;
}

void getNumberOfSections(SectionNode* cssHead, Command* command) {
    int nOfSects = 0;
    SectionNode* tmpCSS = cssHead;
    while (tmpCSS != nullptr) {
        nOfSects += tmpCSS->usedCells;
        tmpCSS = tmpCSS->next;
    }
    std::cout << *command << " == " << nOfSects << endl;
}

void getNumberOfSelectorsForSection(SectionNode* cssHead, Command* command) {
    int nOfSels = 0, nSect = atoi(command->args[0]) - 1;
    SectionNode* tmpCSS = (findSection(cssHead, &nSect));
    if (tmpCSS == nullptr) return;
    Node* tmpHead = tmpCSS->sections[nSect].selectors->GetHead();
    while (tmpHead != nullptr) {
        nOfSels++;
        tmpHead = tmpHead->next;
    }
    std::cout << *command << " == " << nOfSels << endl;
    return;
}

void getNumberOfAttributesForSection(SectionNode* cssHead, Command* command) {
    int nOfAttrs = 0, nSect = atoi(command->args[0]) - 1;
    SectionNode* tmpCSS = (findSection(cssHead, &nSect));
    if (tmpCSS == nullptr) return;
    Node* tmpHead = tmpCSS->sections[nSect].attributes->GetHead();
    while (tmpHead != nullptr) {
        nOfAttrs++;
        tmpHead = tmpHead->next;
    }
    std::cout << *command << " == " << nOfAttrs << endl;
    return;
}

void getSelectorForSection(SectionNode* cssHead, Command* command) {
    int nSect = atoi(command->args[0]) - 1;
    int nSel = atoi(command->args[2]) - 1;
    SectionNode* tmpCSS = (findSection(cssHead, &nSect));
    if (tmpCSS == nullptr) return;
    Node* tmpHead = tmpCSS->sections[nSect].selectors->GetHead();
    while (tmpHead != nullptr && nSel-- > 0) {
        tmpHead = tmpHead->next;
    }
    if (tmpHead == nullptr) return;
    std::cout << *command << " == " << tmpHead->GetSelector() << endl;
    return;
}

void getAttributeForSection(SectionNode* cssHead, Command* command) {
    int nSect = atoi(command->args[0]) - 1;
    SectionNode* tmpCSS = (findSection(cssHead, &nSect));
    if (tmpCSS == nullptr) return;
    Node* tmpHead = tmpCSS->sections[nSect].attributes->FindAttrNode(command->args[2]);
    if (tmpHead == nullptr) return;
    std::cout << *command << " == " << tmpHead->GetValue() << endl;
    return;
}

void getNumberOfSelectorsForAllSections(SectionNode* cssHead, Command* command) {
    int nOfSels = 0;
    SectionNode* tmpCSS = cssHead;
    Node* tmpHead;
    while (tmpCSS != nullptr) {
        for (int i = 0; i < tmpCSS->usedCells; i++) {
            tmpHead = tmpCSS->sections[i].selectors->FindSelNode(command->args[0]);
            if (tmpHead != nullptr) nOfSels++;
        }
        tmpCSS = tmpCSS->next;
    }
    std::cout << *command << " == " << nOfSels << endl;
    return;
}

void getNumberOfAttributesForAllSections(SectionNode* cssHead, Command* command) {
    int nOfAttrs = 0;
    SectionNode* tmpCSS = cssHead;
    Node* tmpHead;
    while (tmpCSS != nullptr) {
        for (int i = 0; i < tmpCSS->usedCells; i++) {
            tmpHead = tmpCSS->sections[i].attributes->FindAttrNode(command->args[0]);
            if (tmpHead != nullptr) nOfAttrs++;
        }
        tmpCSS = tmpCSS->next;
    }
    std::cout << *command << " == " << nOfAttrs << endl;
    return;
}

void getAttributeForSelector(SectionNode* cssHead, Command* command) {
    int i = 0;
    bool check = 0;
    SectionNode* tmpCSS = cssHead;
    while (tmpCSS->next != nullptr) {
        tmpCSS = tmpCSS->next;
    }
    Node* tmpHead;
    while (tmpCSS != nullptr) {
        for (i = tmpCSS->usedCells - 1; i >= 0; i--) {
            tmpHead = tmpCSS->sections[i].selectors->FindSelNode(command->args[0]);
            if (tmpHead != nullptr) {
                check = 1;
                break;
            };
        }
        if (check) break;
        tmpCSS = tmpCSS->previous;
    }
    if (!check) return;
    tmpHead = tmpCSS->sections[i].attributes->FindAttrNode(command->args[2]);
    if (tmpHead == nullptr) return;
    std::cout << *command << " == " << tmpHead->GetValue() << endl;
    return;
}

void moveIndex(SectionNode* cssHead, int nSect) {
    if (nSect == cssHead->usedCells) {
        return;
    }
    int i = nSect;
    for (i = nSect; i < cssHead->usedCells; i++) {
        Section tmp = cssHead->sections[i];
        cssHead->sections[i] = cssHead->sections[i + 1];
        cssHead->sections[i + 1] = tmp;
    }
    return;
}

int deleteSection(DoublyLinkedList* css, Command* command) {
    int nSect = atoi(command->args[0]) - 1;
    SectionNode* tmpCSS = (findSection(css->GetHead(), &nSect));
    if (tmpCSS == nullptr) return 0;
    delete tmpCSS->sections[nSect].selectors;
    delete tmpCSS->sections[nSect].attributes;
    tmpCSS->sections[nSect].selectors = nullptr;
    tmpCSS->sections[nSect].attributes = nullptr;
    tmpCSS->usedCells--;
    std::cout << *command << " == deleted" << endl;
    if (tmpCSS->usedCells == 0) css->RemoveNode(tmpCSS);
    moveIndex(tmpCSS, nSect);
    return 0;
}

int deleteAttributeForSelection(DoublyLinkedList* css, Command* command) {
    int nSect = atoi(command->args[0]) - 1;
    SectionNode* tmpCSS = (findSection(css->GetHead(), &nSect));
    if (tmpCSS == nullptr) return 0;
    if (tmpCSS->sections[nSect].attributes == nullptr) return 0;
    Node* tmpHead = tmpCSS->sections[nSect].attributes->FindBefore(command->args[2]);
    if (tmpHead == nullptr) return 0;
    if (strcmp(tmpCSS->sections[nSect].attributes->GetHead()->GetKey(), tmpHead->GetKey()) == 0) {
        if (strcmp(tmpHead->GetKey(), command->args[2]) != 0) return 0;
        tmpHead = tmpCSS->sections[nSect].attributes->RemoveFirst(tmpCSS->sections[nSect].attributes->GetHead());
        tmpCSS->sections[nSect].attributes->SetHead(*tmpHead);
    }
    else {
        Node* del;
        del = tmpHead->next;
        tmpHead->next = tmpHead->next->next;
        delete del;
    }
    std::cout << *command << " == deleted" << endl;
    if (tmpCSS->sections[nSect].attributes->GetHead() == nullptr) {
        delete tmpCSS->sections[nSect].selectors;
        delete tmpCSS->sections[nSect].attributes;
        tmpCSS->sections[nSect].selectors = nullptr;
        tmpCSS->sections[nSect].attributes = nullptr;
        tmpCSS->usedCells--;
        if (tmpCSS->usedCells == 0) css->RemoveNode(tmpCSS);
        moveIndex(tmpCSS, nSect);
    }
    return 0;
}

int main() {
    int parse = PARSE;
    DoublyLinkedList* css = new DoublyLinkedList();
    SectionNode* sections = new SectionNode();
    LinkedList* selectors;
    LinkedList* attributes;
    css->AddLast(sections);
    do {
        selectors = new LinkedList();
        attributes = new LinkedList();
        parse = readSelectors(selectors);
        if (parse == EXIT) break;
        if (parse != END_OF_CSS) {
            parse = readAttributes(attributes);
            if (parse == EXIT) break;
            sections->sections[sections->usedCells].selectors = selectors;
            sections->sections[sections->usedCells].attributes = attributes;
            sections->usedCells++;
            if (sections->usedCells == SIZE) {
                sections = new SectionNode();
                css->AddLast(sections);
            }
        }
        while (parse == END_OF_CSS) {
            Command* command = new Command();
            parse = readCommand(command);
            if (parse == EXIT) break;
            if (parse == UNDEF) {
                parse = END_OF_CSS;
                continue;
            }
            switch (interpretCommand(command)) {
            case QUE2:
                getNumberOfSections(css->GetHead(), command);
                break;
            case STAR2:
                parse = PARSE;
                if (css->GetHead() == nullptr) {
                    delete css;
                    css = new DoublyLinkedList();
                    sections = new SectionNode();
                    css->AddLast(sections);
                }
                break;
            case NUM1 + SEL2 + QUE3:
                getNumberOfSelectorsForSection(css->GetHead(), command);
                break;
            case NUM1 + ATTR2 + QUE3:
                getNumberOfAttributesForSection(css->GetHead(), command);
                break;
            case NUM1 + SEL2 + NUM3:
                getSelectorForSection(css->GetHead(), command);
                break;
            case NUM1 + ATTR2 + STR3:
                getAttributeForSection(css->GetHead(), command);
                break;
            case STR1 + SEL2 + QUE3:
                getNumberOfSelectorsForAllSections(css->GetHead(), command);
                break;
            case STR1 + ATTR2 + QUE3:
                getNumberOfAttributesForAllSections(css->GetHead(), command);
                break;
            case STR1 + EATTR2 + STR3:
                getAttributeForSelector(css->GetHead(), command);
                break;
            case NUM1 + DEL2 + STAR3:
                if (deleteSection(css, command)) {
                }
                break;
            case NUM1 + DEL2 + STR3:
                if (deleteAttributeForSelection(css, command)) {
                }
                break;
            case EXIT:
                parse = EXIT;
                break;
            }
        }
    } while (parse != EXIT);
    delete selectors;
    delete attributes;
    delete css;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file