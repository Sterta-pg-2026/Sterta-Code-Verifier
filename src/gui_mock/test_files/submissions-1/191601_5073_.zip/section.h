#pragma once
#include "linkedlist.h"

class Section {
public:
    LinkedList* selectors, * attributes;
    Section();
    Section(LinkedList* selectors, LinkedList* attributes);
    ~Section();
    Section& operator=(const Section& section);
};

std::ostream& operator<<(std::ostream& os, const Section& section);