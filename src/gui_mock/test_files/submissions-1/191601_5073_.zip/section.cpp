#include "section.h"

Section::Section() : selectors(nullptr), attributes(nullptr) {
}

Section::~Section() {
}

Section::Section(LinkedList* selectors, LinkedList* attributes) {
    this->selectors = selectors;
    this->attributes = attributes;
}

Section& Section::operator=(const Section& section) {
	Section tmp = section;
	selectors = tmp.selectors;
	attributes = tmp.attributes;
	return *this;
}

std::ostream& operator<<(std::ostream& os, const Section& section) {
    os << "\tSelectors:\n" << *section.selectors << "\tAttributes:\n" << *section.attributes << std::endl;
    return os;
}