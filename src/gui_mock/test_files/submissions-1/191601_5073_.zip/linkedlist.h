#pragma once
#include <iostream>
#include "node.h"

class LinkedList {
private:
    Node* head;
public:
    LinkedList();
    ~LinkedList();
    Node* GetHead();
    void SetHead(Node& newHead);
    void AddLast(Node* newNode);
    Node* RemoveFirst(Node* head);
    Node* RemoveBefore(Node* head, char* pattern);
    Node* FindSelNode(char* dataPattern);
    Node* FindAttrNode(char* dataPattern);
    Node* FindBefore(char* dataPattern);
};

std::ostream& operator<<(std::ostream& os, LinkedList& list);