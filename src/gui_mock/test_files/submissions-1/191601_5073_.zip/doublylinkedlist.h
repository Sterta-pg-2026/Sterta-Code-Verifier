#pragma once
#include "sectionnode.h"

class DoublyLinkedList {
private:
    SectionNode* head;
public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    SectionNode* GetHead();
    void SetHead(SectionNode& newHead);
    void AddLast(SectionNode* newNode);
    void RemoveNode(SectionNode* node);
};

std::ostream& operator<<(std::ostream& os, DoublyLinkedList& list);