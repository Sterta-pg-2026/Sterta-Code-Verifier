#include "sectionnode.h"

SectionNode::SectionNode() : next(nullptr), previous(nullptr), usedCells(0) {
}

SectionNode::~SectionNode() {
    for (int i = 0; i < usedCells; i++) {
        delete sections[i].selectors;
        delete sections[i].attributes;
    }
}

Section& SectionNode::operator[](std::size_t i) {
    return sections[i];
}

void SectionNode::PrintData(std::ostream& os) const {
    for (int i = 0; i < SIZE; i++) {
        if (sections[i].selectors == nullptr) continue;
        os << i << ":\n" << sections[i];
    }
    return;
}

std::ostream& operator<<(std::ostream& os, const SectionNode& section) {
    section.PrintData(os);
    return os;
}