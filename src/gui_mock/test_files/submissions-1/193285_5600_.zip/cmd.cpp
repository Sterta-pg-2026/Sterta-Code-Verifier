#include "cmd.h"

#define CASE_CHAR_DIGITS '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9'  

bool readCmd(List <String>& cmd)
{
    char buffer[100];
    while(1)
    {  
        if(scanf(" %100[^\n] ",buffer) == -1)
            break; 
        cmd.insertNode(buffer);

        if(scanf("%100[*]",buffer) == 1)
            return false;
    }
    return true;
}

void CmdData::reset()
{
    this->command.length = 0;
    this->data[0].length = 0;
    this->data[1].length = 0;
    this->data[2].length = 0;
}



void selectorCmd(List <Section>& list, CmdData command)
{
    switch(command.firstChar[2])
    {
        case '?':
            if(command.intData[0] == -1)
            {
                std::cout<<command.command << " == " << getSelectorAmmount(list, command.data[0]) << "\n";
                break;
            }
            if(list.getLength() < command.intData[0]){
                break;
            }
            //std::cout<<iter->data << "???\n";
            std::cout<<command.command << " == " << list.getIndex(command.intData[0]-1).selectors.getContentLength()<<"\n";
            break;
        case CASE_CHAR_DIGITS:
            if(list.getLength() < command.intData[0])
            {
                break;
            }
            if(list.getIndex(command.intData[0]-1).selectors.getContentLength() < command.intData[2])
            {
                break;
            }
            std::cout<<command.command << " == " << list.getIndex(command.intData[0]-1).selectors[command.intData[2]-1]<<"\n";
            break;
    }
}
void attributeCmd(List <Section>& list, CmdData command)
{
    switch(command.firstChar[2])
    {
        case '?':
            if(command.intData[0] == -1)
            {
                std::cout<<command.command << " == " << getAttributeAmmount(list, command.data[0]) << "\n";
                break;
            }

            if(list.getLength() < command.intData[0]){
                break;
            }
            std::cout<<command.command << " == " << list.getIndex(command.intData[0]-1).attributes.getContentLength()<<"\n";
            break;
        default:
            if(list.getLength() < command.intData[0]){
                break;
            }
            if(list.getIndex(command.intData[0]-1).attributes.getContentLength() < command.intData[2])
            {
                break;
            }
            String check = findValue(list.getIndex(command.intData[0]-1).attributes, command.data[2]);
            if(check == command.data[2])
                break;
            std::cout<<command.command << " == " << check<<"\n";
            break;
    }
}
void queryCmd(List <Section>& list, CmdData command)
{
    String check = findValueofSelector(list,command.data[0],command.data[2]);
    if(check == command.data[0])
        return;
    std::cout<<command.command << " == " << check<<"\n";    
}
void deleteCmd(List <Section>& list, CmdData command)
{
    if(list.getLength() < command.intData[0])
        return;
    if(command.firstChar[2] != '*')
    {
        if(deleteAttribute(list.getIndexRef(command.intData[0]-1).attributes, command.data[2]))
        {
            if(list.getIndex(command.intData[0]-1).attributes.getContentLength() == 0)
            {
                list.deleteIndex(command.intData[0]-1);
            }
            
            std::cout<<command.command << " == deleted\n";
        }
        return;
    }
    list.deleteIndex(command.intData[0]-1);
    std::cout<<command.command << " == deleted\n";
}



void processCmd(List <Section>& list, List <String>& cmd)
{
    for(auto iter=cmd.start; iter!=NULL; iter=iter->nextNode) //Iterate over command list
    {

        if(iter->data[0] == '?')
        {
            std::cout<<"? == "<<list.getLength()<<"\n";
            continue;
        }

        CmdData command;
        command.reset();

        parseCmd(iter->data, command); // Convert iterator data into string and intigers
        
        switch(command.firstChar[1])
        { 
            case 'S':
                selectorCmd(list, command);
                break;
            case 'A':
                attributeCmd(list, command);
                break;
            case 'E':
                queryCmd(list, command);
                break;
            case 'D':
                deleteCmd(list,command);
                break;

        }
    }
}

bool isWhite(char input)
{
    return input == ' ' || input == '\n' || input == '\r' || input == '\t';
}


String trim(const char input[]) 
{
    int start=0,end=strlen(input),index=0;

    while(index < end && isWhite(input[index]))
    {
        ++index;
        ++start;
    }
    index = end-1;
    while(index > start && isWhite(input[index]))
    {
        --index;
        --end;
    }
    String output;
    output.resize(end-start);
    for(int i=start, j=0 ; i<end ;++i, ++j)
    {
        output[j]=input[i];
    }

    return output;
}

String trim(String input)
{
    int start=0,end=input.length,index=0;

    while(index < end && isWhite(input[index]))
    {
        ++index;
        ++start;
    }
    index = end-1;
    while(index > start && isWhite(input[index]))
    {
        --index;
        --end;
    }
    String output;
    output.resize(end-start);
    for(int i=start, j=0 ; i<end ;++i, ++j)
    {
        output[j]=input[i];
    }

    return output;
}



void parseCmd(String cmd, CmdData &output)
{
    String buffer;
    cmd = trim(cmd);
    for(int i=0,z=0; i<cmd.length; ++i)
    {
        if(cmd[i] == ',') // If you find "," push to output strings
        {
            output.data[z] = buffer;
            output.firstChar[z] = output.data[z][0]; // Get first char of string
            if(output.firstChar[z] >= '0' && output.firstChar[z] <= '9') // If first char is a digit calculate an intiger value
                output.intData[z] = output.data[z].toInt(0,output.data[z].length);
            else
                output.intData[z] = -1;
            ++z;
            buffer.resize(0); //Reset buffer
            continue;
        }
        buffer.push(cmd[i]); //Add into buffer until u find ","
    }
    //There are only 2 "," so the end is processed seperately
    output.data[2] = buffer;
    output.firstChar[2] = output.data[2][0];

    if(output.firstChar[2] >= '0' && output.firstChar[2] <= '9')
        output.intData[2] = output.data[2].toInt(0,output.data[2].length);
    else
        output.intData[2] = -1;

    output.command = output.data[0] + "," + output.data[1] + "," + output.data[2]; // Conca strings into single command
}

String findValue(blockList <Attribute> list, String name)
{
    for(int i = list.getContentLength() -1 ; i >= 0;  --i)
    {
        if(list[i].name == name)
            return list[i].value;
    }
    return name;
}

bool deleteAttribute(blockList <Attribute>& list, String atr)
{
    for(int i = 0 ; i < list.getContentLength(); ++i)
    {
        if(list[i].name == atr)
        {
            list.removeIndex(i);
            return true;
        }

    }
    return false;
}

String findValueofSelector(List <Section> &list, String selector, String name)
{
    auto node = list.end;

    for(int index = 0; node != NULL; node = node->prevNode, ++index)
    {
        blockList <String> &selectors = node->data.selectors;
        int length = selectors.getContentLength();

        for(int i = length -1; i >= 0; --i)
        {
            if(selectors[i] == selector)
            {
                String check = findValue(node->data.attributes, name);
                //std::cout<<check <<" " <<name<<":\n";
                if(check == name)
                    continue;
                return check;
            }
        }
    }
    return selector;
}

int getAttributeAmmount(List <Section> &list, String atr)
{
    auto node = list.start;
    int output = 0;
    for(int index = 0; node != NULL; node = node->nextNode, ++index)
    {
        blockList <Attribute> &attributes = node->data.attributes;
        int length = attributes.getContentLength();

        for(int i = 0; i < length; i++)
        {
            //std::cout<<attributes[i].name<<" "<<atr<<"\n";
            if(attributes[i].name == atr)
                ++output;
        }
    }
    return output;
}

int getSelectorAmmount(List <Section> &list, String selector)
{
    auto node = list.end;
    int output = 0;
    for(int index = 0; node != NULL; node = node->prevNode, ++index)
    {
        blockList <String> &selectors = node->data.selectors;
        //if(selector == "h1")
        //    std::cout<<node->data.selectors;
        int length = selectors.getContentLength();

        for(int i = 0; i < length; i++)
        {
            if(selectors[i] == selector) {
                ++output;
                break;
            }
        }
    }
    return output;
}