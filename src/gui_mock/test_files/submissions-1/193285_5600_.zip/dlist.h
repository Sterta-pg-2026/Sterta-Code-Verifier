#pragma once
#include <iostream>

template <typename T> 
class Node 
{
    public:
        T data;
        Node<T> *nextNode;
        Node<T> *prevNode; 
        Node() : data(0)
        {
            nextNode = NULL;
            prevNode = NULL;
        };
        explicit Node(const T input) : data(input)
        {
            nextNode = NULL;
            prevNode = NULL;
        };
};

template <typename T> 
class List
{
    public:
        Node<T> *start;
        Node<T> *end;

        List() 
        { 
            start = NULL;  
            end = NULL;
        }
        void reset();
        void deleteIndex(const int index) ;
        void deleteNode(const T value) ;
        int findIndex(T value) const;
        Node<T>* findNode(const T value);
        void insertNode(T data);
        void printList() const;
        T getIndex(const int index) const;
        T& getIndexRef(const int index) const;
        int getLength() const;
        template <typename T2> 
        friend std::ostream& operator<<(std::ostream& out, const List<T2>& list);

};

template <typename T>
void List<T>::reset()
{
    Node<T> *rem, *p = end->prevNode;
    while (p->prevNode != NULL)
    {
        rem = p;
        p = p->prevNode;
        delete rem;
    }
    start = NULL;
    end = NULL;
}


template <typename T>
void List<T>::insertNode(T data)
{

    Node<T> *newNode = new Node(data);
    
    if(start == NULL)
    {
        start = newNode;
        end = newNode;
        return;
    }
    newNode->prevNode = end;
    end->nextNode = newNode;
    end = newNode;
};

template <typename T>
T List<T>::getIndex(const int index) const
{
    Node<T> *tempNode = start;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        return start->data; 
    }
    while(tempIndex != index)  
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }
    return tempNode->data;
}

template <typename T>
T& List<T>::getIndexRef(const int index) const
{
    Node<T> *tempNode = start;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        return start->data; 
    }
    while(tempIndex != index)
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }
    return tempNode->data;
}

template <typename T>
void List<T>::deleteIndex(const int index)
{
    Node<T> *tempNode = start;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        return;
    }

    if(index == 0)
    {
        Node<T> *remove = start;
        start = start->nextNode;
        if(start != NULL)
            start->prevNode = NULL;
        delete remove;
        return;
    }

    while(tempIndex != index)
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }

    tempNode->prevNode->nextNode = tempNode->nextNode;
    if(tempNode != end)
        tempNode->nextNode->prevNode = tempNode->prevNode;
    else
        end = tempNode->prevNode;
    delete tempNode;

};

template <typename T>
void List<T>::printList() const
{
    Node<T> *tempNode = start;

    if(tempNode == NULL)
    {
        return;
    }

    while(tempNode->nextNode != NULL)
    {
        std::cout<<tempNode->data<<" ";
        tempNode = tempNode->nextNode;
    }  
    std::cout<<tempNode->data<<"\n";
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const List<T>& list)
{
    out<<"\ndList: \n" ;
    Node<T> *tempNode = list.start;
    int index = 0;

    if(tempNode == NULL)
    {
        return out;
    }

    while(tempNode->nextNode != NULL)
    {
        out<<index<<": "<<tempNode->data<<"\n";
        ++index;
        tempNode = tempNode->nextNode;
    }  
    out<<index<<": "<<tempNode->data<<"\n\n";
    return out;
}


template <typename T>
int List<T>::getLength() const
{
    Node<T> *tempNode = start;
    int output = 0;

    if(tempNode == NULL)
    {
        return 0;
    }

    while(tempNode->nextNode != NULL)
    {
        ++output;
        tempNode = tempNode->nextNode;
    }  
    return output+1;
};

template <typename T>
int List<T>::findIndex(const T value) const
{
    Node<T> *tempNode = start;
    int tempIndex = 0, listLength = getLength(), output =-1;

    for(int i = 0; i < listLength; ++i )
    {
        if(tempNode->data == value)
        {
            output = i;
            break;
        }
        tempNode = tempNode->nextNode;
    }
    return output;

};

template <typename T>
Node<T>* List<T>::findNode(const T value)
{
    Node<T> *tempNode = start;

    while(tempNode->nextNode != NULL && tempNode->data != value)
        tempNode = tempNode->nextNode;  
        
    return tempNode;

};

template <typename T>
void List<T>::deleteNode(const T value)
{
    Node<T>* node = findNode(value);

    if(node == NULL)
        return;
    
    node->prevNode->nextNode = node->nextNode;
    if(node != end)
        node->nextNode->prevNode = node->prevNode;
    else
        end = node->prevNode;
    delete node;
};
