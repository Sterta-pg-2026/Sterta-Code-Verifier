#pragma once

#include <iostream>
#include <cstring>

class String {
    public:
        int length = 0;
        char* array = NULL;
        void resize(int size);
        char& operator[](int index);
        int toInt(int begin,int end) const;
        void push(char input);
        //friend std::ostream& operator<<(std::ostream& out, const String& str);
        //friend String operator+(const String& str1, const String& str2);
        String& operator+=(const String& string);
        String& operator=(const String& string);

        String();
        String(char* input);
        String(const char input[]);
        String(const String& input);
        String(String&& input);
};

std::ostream& operator<<(std::ostream& out, const String& str);
bool operator==(const String& str1, const String& str2);
bool operator==(const String& str1, const char* str2);
bool operator!=(const String& str1, const String& str2);
String operator+(const String& str1, const String& str2);
