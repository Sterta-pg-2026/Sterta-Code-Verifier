#pragma once
#include <iostream>

template <typename T> 
class Node 
{
    public:
        T data;
        Node<T> *nextNode;
        Node() {nextNode = NULL;};
        Node(T input) 
        {
            data = input;
            nextNode = NULL;
        };
};

template <typename T> 
class List
{
    private:
        Node<T> *start;
    public:
        List() { start = NULL; }
        void deleteIndex(int index);
        void deleteNode(T value);
        int findNode(T value);
        void insertNode(T data);
        void printList();
        T getIndex(int index);
        T& getIndexRef(int index);
        int getLength();
        template <typename T2> 
        friend std::ostream& operator<<(std::ostream& out, const List<T2>& list);

};

template <typename T>
void List<T>::insertNode(T data)
{
    Node<T> *newNode = new Node(data);

    Node<T> *tempNode = start;

    if(tempNode == NULL)
    {
        start = newNode;
        return;
    }

    while(tempNode->nextNode != NULL)
    {
        tempNode = tempNode->nextNode;
    }
    tempNode->nextNode = newNode;


};

template <typename T>
T List<T>::getIndex(int index)
{
    Node<T> *tempNode = start, *removeNode;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        T no;
        return no; 
    }
    while(tempIndex != index)
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }
    return tempNode->data;
}

template <typename T>
T& List<T>::getIndexRef(int index)
{
    Node<T> *tempNode = start, *removeNode;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        return start->data; 
    }
    while(tempIndex != index)
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }
    return tempNode->data;
}

template <typename T>
void List<T>::deleteIndex(int index)
{
    Node<T> *tempNode = start, *removeNode;
    int tempIndex = 0, listLength = getLength();

    if(index >= listLength)
    {
        return;
    }

    if(index == 0)
    {
        start = start->nextNode;
        return;
    }

    while(tempIndex != index - 1)
    {
        tempNode = tempNode->nextNode;
        ++tempIndex;
    }

    removeNode = tempNode->nextNode;
    tempNode->nextNode = removeNode->nextNode;
    delete removeNode;

};

template <typename T>
void List<T>::printList()
{
    Node<T> *tempNode = start;

    if(tempNode == NULL)
    {
        return;
    }

    while(tempNode->nextNode != NULL)
    {
        std::cout<<tempNode->data<<" ";
        tempNode = tempNode->nextNode;
    }  
    std::cout<<tempNode->data<<"\n";
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const List<T>& list)
{
    out<<"\n";
    Node<T> *tempNode = list.start;
    int index = 0;

    if(tempNode == NULL)
    {
        return out;
    }

    while(tempNode->nextNode != NULL)
    {
        out<<index<<": "<<tempNode->data<<"\n";
        ++index;
        tempNode = tempNode->nextNode;
    }  
    out<<index<<": "<<tempNode->data<<"\n";
    return out;
}


template <typename T>
int List<T>::getLength()
{
    Node<T> *tempNode = start;
    int output = 0;

    if(tempNode == NULL)
    {
        return 0;
    }

    while(tempNode->nextNode != NULL)
    {
        ++output;
        tempNode = tempNode->nextNode;
    }  
    return output+1;
};

template <typename T>
int List<T>::findNode(T value)
{
    Node<T> *tempNode = start;
    int tempIndex = 0, listLength = getLength(), output =-1;

    for(int i = 0; i < listLength; ++i )
    {
        if(tempNode->data == value)
        {
            output = i;
            break;
        }
        tempNode = tempNode->nextNode;
    }
    return output;

};

template <typename T>
void List<T>::deleteNode(T value)
{
    int node = findNode(value);

    if(node == -1)
        return;
    
    deleteIndex(node);
};
