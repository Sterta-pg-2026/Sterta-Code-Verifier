#include "css.h"
#include "cmd.h"

std::ostream& operator<<(std::ostream& out, const Attribute& atr)
{
    out<<atr.name<<": "<<atr.value;
    return out;
}


bool readSelectors(Section& section)
{
    char buffer[300];
    while(1)
    {
        while(scanf(" %300[^,{\n] ",buffer) == 1)  // Read to , or { or \n
        {
            section.selectors.push(trim(buffer));
        }
        if(scanf(" %300[,] ",buffer) != 1) // If it is a comma continue
            break;
    }
    if(scanf(" %300[{] ",buffer) != 1)  // If it doesnt end with { exit main
        return false;

    return true;
}

bool readContent(List <Section>& list, Section& section)
{
    char buffer[100];
    while(1)
    {  
        Attribute attr;
        while(scanf(" %300[^:;}] ",buffer) == 1) // Read until : or ; or }
        {
            attr.name = buffer;
        }
        if(scanf(" %300[:] ",buffer) != 1)  // If it is : continue
            break;   
        while(scanf(" %300[^;}] ",buffer) == 1) // Read until ; or {
        {
            //printf("3:  %s\n",buffer);
            attr.value = buffer;
        
            if(!checkDuplicateAttributes(section.attributes, attr))
                section.attributes.push(attr);
            
        }
        if(scanf(" %300[;] ",buffer) != 1) // If it is ; continue
            break;           
    }
    if(scanf(" %300[}] ",buffer) != 1) // If it doesnt end with } exit main
        return false;
    
    list.insertNode(section);

    return true;
}

bool readCss(List <Section> &list)
{
    char buffer[100];
    while(1)
    {
        Section section;
        if(!readSelectors(section))
            break;
    
        if(!readContent(list,section))
            break;
        //std::cout<<section.selectors<<section.attributes;
        if(scanf(" %300[?]",buffer) == 1)
            return false;
    }
    return true;
}


bool checkDuplicateAttributes(blockList <Attribute> &list, Attribute& base)
{
    for(int index = 0; index < list.getContentLength();  ++index)
    {
        if(list[index].name == base.name)
        {
            list[index].value = base.value;
            return true;
        }
    }
    return false;
}