#include <iostream>
#include "mstring.h"
#include "blocklist.h"
#include "css.h"
#include "cmd.h"

int main()
{
    List <Section> list;
    List <String> commands;

    while(!readCss(list)) // Read Css until EOF
    {
        if(readCmd(commands)) // After CSS input ends read commands
            break;
        processCmd(list,commands);
        commands.reset(); 
    }
    processCmd(list,commands); // if there are still commands left process them


    return 0;
}
