#pragma once

#include "mstring.h"
#include "blocklist.h"

class Attribute
{
    public:
        String name;
        String value;
};

class Section
{
    public:
        blockList <String> selectors;
        blockList <Attribute> attributes;
};

bool readSelectors(Section& section);
bool readContent(List <Section>& list, Section& section);

bool readCss(List <Section>& list);
bool checkDuplicateAttributes(blockList <Attribute> &list, Attribute& base);

std::ostream& operator<<(std::ostream& out, const Attribute& atr);