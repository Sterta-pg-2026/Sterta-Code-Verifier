#pragma once
#include <iostream>

#include "dlist.h"
#define BLOCK_SIZE 17

template <typename T>
class Block {
    public:
        T* content;
        int usedSize;
        int size;
};


template <typename T>
class blockList 
{
    private:
        int blocksize = BLOCK_SIZE;
        int size = 0;
    public:
        List<Block<T>> content;
        void deleteBlock(int index);
        void insertBlock(T block[], int iSize);
        void push(T data);
        void removeBlockIndex(int block, int index);
        void removeIndex(int index);
        int getLength() const;
        int getBlockSize() const;
        int getContentLength() const;
        blockList() 
        { 
        };
        explicit blockList(const int blocksize) : blocksize(blocksize)
        {
        };
        T& operator[](int index);  
        T& operator()(int block, int index);    
        template <typename T2> 
        friend std::ostream& operator<<(std::ostream& out, const blockList<T2>& list);


};

template <typename T>
int blockList<T>::getLength() const
{
    return size;
}   

template <typename T>
int blockList<T>::getContentLength() const
{
    if(size == 0)
        return 0;
    return size * blocksize - content.end->data.size + content.end->data.usedSize;
}

template <typename T>
int blockList<T>::getBlockSize() const
{
    return blocksize;
} 
template <typename T>
T& blockList<T>::operator[](int index)
{
    int findSize = blocksize, iter = 0;
    while(findSize <= index)
    {
        findSize += blocksize;
        ++iter;
    }
    
    return (content.getIndex(iter)).content[blocksize - (findSize-index)];
}   


template <typename T>
T& blockList<T>::operator()(int block, int index)
{
    return (content.getIndex(block)).content[index];
}   

template <typename T>
void blockList<T>::push(T data)
{
    if(size == 0)
    {
        T block[BLOCK_SIZE];
        insertBlock(block,0);
    }
    Block <T> endBlock = content.getIndex(size-1); 

    if(endBlock.usedSize == endBlock.size)
    {
        T block2[BLOCK_SIZE];
        insertBlock(block2,0);    
    }

    Block <T> &changeBlock = content.getIndexRef(size-1);
    changeBlock.content[changeBlock.usedSize] = data;
    changeBlock.usedSize++;
}   


template <typename T>
void blockList<T>::deleteBlock(int index)
{
    content.deleteIndex(index);
    size--;
}


template <typename T>
void blockList<T>::insertBlock(T block[], int iSize)
{
    int realSize = BLOCK_SIZE;
    while(realSize < iSize)
        realSize+=blocksize;
    Block<T> input;
    input.content = new T[realSize];
    for(int i=0; i<iSize; ++i)
        input.content[i] = block[i];
    input.size = realSize;
    input.usedSize = iSize;
    content.insertNode(input);
    size++;
}

template <typename T>
void blockList<T>::removeBlockIndex(int block, int index)
{
    Block<T> &cBlock = content.getIndexRef(block);
    for(int i = index ; i<cBlock.usedSize-1; ++i)
    {
        cBlock.content[i] = cBlock.content[i+1];
    }
    cBlock.usedSize--;
    if(cBlock.usedSize <= 0)
        this->deleteBlock(block);

}

template <typename T>
void blockList<T>::removeIndex(int index)
{
    int findSize = blocksize, iter = 0;
    while(findSize <= index)
    {
        findSize += blocksize;
        ++iter;
    }
    Block<T>& block = content.getIndexRef(iter);
    int begin = blocksize - findSize + index;

    for(int i = begin; i < block.usedSize && i < blocksize - 1 ; ++i)
    {
        block.content[i] = block.content[i+1];
    }

    block.usedSize--;
    if(block.usedSize==0)
    {
        content.deleteIndex(iter);
        --size;
    }

}


template <typename T>
std::ostream& operator<<(std::ostream& out, const blockList<T>& list)
{
    out<<"\nblockList: \n" ;
    for(int i=0; i < list.size; ++i)
    {
        Block<T> block = list.content.getIndex(i);
        out<<"Block: "<<i<<" Size: "<<block.size<<" uSize: "<<block.usedSize<<"\n";
        for(int j=0; j < block.usedSize; ++j)
        {
            out<<"  "<<j<<": "<<block.content[j]<<"\n";
        }
    }
    out<<"\n";
    return out;
}