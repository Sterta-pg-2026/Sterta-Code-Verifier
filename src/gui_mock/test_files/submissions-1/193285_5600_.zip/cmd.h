#include "css.h"
#include "mstring.h"

class CmdData
{
    public:
        String command; 
        String data[3]; 
        int intData[3];
        char firstChar[3];
        void reset();
};

bool readCmd(List <String>& cmd);
void parseCmd(String cmd, CmdData &output);
void processCmd(List <Section>& list, List <String>& cmd);

void selectorCmd(List <Section>& list, CmdData command);
void attributeCmd(List <Section>& list, CmdData command);
void deleteCmd(List <Section>& list, CmdData command);
void queryCmd(List <Section>& list, CmdData command);

String trim(const char input[]);
String trim(String input);

String findValue(blockList <Attribute> list, String name);
String findValueofSelector(List <Section> &list, String selector, String name);

int getAttributeAmmount(List <Section> &list, String atr);
int getSelectorAmmount(List <Section> &list, String selector);

bool deleteAttribute(blockList <Attribute>& list, String atr);
