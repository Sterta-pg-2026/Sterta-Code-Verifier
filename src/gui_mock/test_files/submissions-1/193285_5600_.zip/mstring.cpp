#include "mstring.h"

String::String()
{
    length = 0;
    array = NULL;
};

std::ostream& operator<<(std::ostream& out, const String& str)
{
    for(int i=0; i<str.length; ++i)
    {
        out<<str.array[i];
    }
    return out;
}

bool operator==(const String& str1, const String& str2)
{
    if(str1.length != str2.length)
        return false;
    for(int i = 0 ; i < str1.length ; ++i)
    {
        if(str1.array[i] != str2.array[i])
            return false;
    }
    return true;
}

bool operator!=(const String& str1, const String& str2)
{
    if(str1.length != str2.length)
        return true;
    for(int i = 0 ; i < str1.length ; ++i)
    {
        if(str1.array[i] != str2.array[i])
            return true;
    }
    return false;
}

bool operator==(const String& str1, const char* str2)
{
    for(int i = 0 ; i < str1.length ; ++i)
    {
        if(str1.array[i] != str2[i])
            return false;
        if(str2[i] == '\0')
            return false;
    }
    return true;
}


String operator+(const String& str1, const String& str2)
{
    int length = str1.length + str2.length;
    char* buffer = new char[length+1];
 
    // Copy the strings to buff[]
    int i=0;
    for(; i<str1.length ; ++i)
    {
        buffer[i] = str1.array[i];
    }
    for(int j=0; i < length; ++i,++j)
    {
        buffer[i] = str2.array[j];
    }
    buffer[i] = '\0';
    String output(buffer);

    delete[] buffer;


    return output;
}



String::String(char* input)
{
    length = strlen(input);
    array = new char[length];
    for(int i=0;i<length; ++i)
    {
        array[i] = input[i];
    }
}

String::String(const char input[])
{
    length = strlen(input);
    array = new char[length];
    for(int i=0;i<length; ++i)
    {
        array[i] = input[i];
    }
}

char& String::operator[](int index)
{
    return array[index];
}

String::String(const String& input)
{
    length = input.length;
    array = new char[length];
    for(int i=0;i<length; ++i)
    {
        array[i] = input.array[i];
    }
}

String::String(String&& input)
{
    length = input.length;
    array = input.array;
}

String& String::operator+=(const String& string)
{
    int newLength = length + string.length;
    char* newArray = new char[newLength];
    int i=0;
    for(; i<length ; ++i)
    {
        newArray[i] = array[i];
    }
    for(int j=0; i < newLength; ++i,++j)
    {
        newArray[i] = string.array[j];
    }
    char* remove = array;
    array = newArray;
    delete[] remove;

    length = newLength;
    return *this;
}

String& String::operator=(const String& string)
{
    if (&string == this)
    	return *this; 
    length = string.length;
    delete[] array;
    array = new char[length];
    for(int i=0 ;i<length; ++i)
    {
        array[i] = string.array[i];
    }
    return *this;
}

void String::push(char input)
{
    this->resize(this->length+1);
    this->array[this->length-1] = input;
}



void String::resize(int size)
{
    if(size == 0)
    {
        this->array = nullptr;
        this->length = 0;
        return;
    }
    char* buffer = new char[size];
    for(int i=0; i<length && i<size ; ++i)
    {
        buffer[i] = this->array[i];
    }
    this->length = size;
    if(array == nullptr)
    {
        array = buffer;
        return;
    }
    char* remove = array;
    array = buffer;
    length = size;
    delete[] remove;
}

int String::toInt(int begin, int end) const
{
    int output = 0;
    for(int i=begin; i<end; i++)
    {
        output*=10;
        output += array[i] - '0';
    }
    return output;
}