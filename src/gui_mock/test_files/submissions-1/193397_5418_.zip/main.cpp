#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <cmath>

#define COMMEND_LEN 5
#define T 19

using namespace std;


static int created = 0;
static int deleted = 0;

class MyString
{
private:
	char* text;
public:
	// MyString() : text(nullptr) { cout << "nowy obiekt konstruktor domyslny " << endl; }
	MyString(const char* chr)
	{
		/*text = nullptr;
		int len = strlen(str);
		text = new char[len + 1];
		if (len == 0)
		{
			text[0] = '\0';
		}
		else
		{
			strncpy(text, str, len + 1);
		}*/
		text = nullptr;
		if (chr == nullptr || chr[0] == '\0')
		{
			text = new char[1];
			//cout << "nowy obiekt konstruktor 1" << chr << endl; 
			text[0] = '\0';
		}
		else
		{
			int len = strlen(chr);
			text = new char[len + 1];
			//cout << "nowy obiekt konstruktor 2" << chr << endl;
			strncpy(text, chr, len + 1);
		}
		//created++;
		//cout << "+++ constructor created: " << created << " deleted:" << deleted << endl;
	}

	void print() const
	{
		cout << text;
	}

	int length() const
	{
		return strlen(text);
	}

	void append(const char* str)
	{
		if (text == nullptr) {
			assign(str);
		}
		else {
			int len1 = strlen(text);
			int len2 = strlen(str);
			char* newText = new char[len1 + len2 + 2];
			//cout << "nowy obiekt append1 " << str << endl;
			strcpy(newText, text);
			strcpy(newText + len1, str);
			if (text != nullptr)
			{
				//cout << "usuwanie obiektu append1 " << str << endl;
				delete[] text;
				text = nullptr;
			}
			text = newText;
		}
	}

	void append(char c)
	{
		if (text == nullptr)
		{
			char* newText = new char[2];
			//cout << "nowy obiekt append2.1 " << c << endl;
			newText[0] = c;
			newText[1] = '\0';
			text = newText;
		}
		else
		{
			int len = strlen(text);
			char* newText = new char[len + 2];
			//cout << "nowy obiekt append2.2 " << c << endl;
			strcpy(newText, text);
			newText[len] = c;
			newText[len + 1] = '\0';
			if (text != nullptr)
			{
				//cout << "usuwanie obiektu append2 " << c << endl;
				delete[] text;
				text = nullptr;
			}
			text = newText;
		}
	}

	void assign(const char* str)
	{
		if (str == nullptr || str[0] == '\0')
		{
			if (text != nullptr)
			{
				//cout << "usuwanie obiektu assign1.1 " << str << endl;
				delete[] text;
				text = nullptr;
			}
			text = new char[1];
			//cout << "tworzenie obiektu assign1.1 " << str << endl;
			text[0] = '\0';
		}
		else
		{
			int len = strlen(str);
			char* newText = new char[len + 1];
			//cout << "tworzenie obiektu assign1.2 " << str << endl;
			strcpy(newText, str);
			if (text != nullptr) {
				if (text != newText)
				{
					//cout << "usuwanie obiektu assign1.2 " << str << endl;
					delete[] text;
					text = nullptr;
				}
			}
			text = newText;
		}
	}

	MyString& assign(const MyString& other) {
		if (this == &other) {
			return *this;
		}
		if (text != nullptr)
		{
			//cout << "usuwanie obiektu assign2 " << endl;
			//other.print();
			delete[] text;
			text = nullptr;
		}
		int len = strlen(other.text);
		text = new char[len + 1];
		//cout << "tworzenie obiektu assign2 " << endl;
		//other.print();
		strcpy(text, other.text);
		return *this;
	}

	void add(const char* str)
	{
		//cout << "add char*" << endl;
		append(str);
	}

	void add(char c)
	{
		//cout << "add char" << endl;
		append(c);
	}

	char& at(int index)
	{
		if (index < 0 || index >= length())
		{
			throw std::out_of_range("Index out of range");
		}
		return text[index];
	}

	bool compare(const MyString& other) const
	{
		bool comp = strcmp(other.text, text);
		if (comp == false)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	~MyString()
	{
		if (text != nullptr)
		{
			//cout << "usuwanie obiektu destruktor " << endl;
			delete[] text;
			text = nullptr;
		}
		//created++;
		//deleted++;
		//cout << "--- destructor created: " << created << " deleted:" << deleted << endl;

	}
};

struct Selector
{
	MyString data;
	Selector* previous;
	Selector* next;
	Selector(MyString& strData) : data{ "" }
	{
		this->data.assign(strData);
		previous = NULL;
		next = NULL;
	}
};

struct Attribute
{
	MyString data;
	MyString value;
	Attribute* previous;
	Attribute* next;
	Attribute(MyString& strData, MyString& value) : data{ "" }, value{ "" }
	{
		this->data.assign(strData);
		this->value.assign(value);
		previous = NULL;
		next = NULL;
	}
};

class AttributesList
{
private:
	Attribute* first;
	Attribute* last;
public:
	AttributesList() : first(nullptr), last(nullptr) {}
	void insertAtTheEnd(MyString& strData, MyString& value)
	{
		Attribute* attribute = new Attribute(strData, value);
		if (first == NULL)
		{
			first = last = attribute;
		}
		else
		{
			attribute->previous = last;
			last->next = attribute;
			last = attribute;
		}
	}
	void insertAtBeggining(MyString& strData, MyString& value)
	{
		Attribute* attribute = new Attribute(strData, value);
		if (first == NULL)
		{
			first = last = attribute;
		}
		else
		{
			attribute->next = first;
			first->previous = attribute;
			first = attribute;
		}
	}
	Attribute* getFirst()
	{
		return this->first;
	}
	Attribute* getLast()
	{
		return this->last;
	}
};

class SelectorsList
{
private:
	Selector* first;
	Selector* last;
public:
	SelectorsList() : first(nullptr), last(nullptr) {}
	void insertAtTheEnd(MyString& strData)
	{
		Selector* selector = new Selector(strData);
		if (first == nullptr)
		{
			first = last = selector;
		}
		else
		{
			selector->previous = last;
			last->next = selector;
			last = selector;
		}
	}
	void insertAtBeggining(MyString strData)
	{
		Selector* selector = new Selector(strData);
		if (first == nullptr)
		{
			first = last = selector;
		}
		else
		{
			selector->next = first;
			first->previous = selector;
			first = selector;
		}
	}
	Selector* getFirst()
	{
		return this->first;
	}
	Selector* getLast()
	{
		return this->last;
	}
};

struct Section
{
	SelectorsList selectors;
	AttributesList attributes;
};

class twoWaySectionList
{
public:
	int counter = 0;
	Section arrOfSection[T];
	twoWaySectionList* first;
	twoWaySectionList* last;
	twoWaySectionList* next;
	twoWaySectionList* previous;

	twoWaySectionList() : first(nullptr), last(nullptr), next(nullptr), previous(nullptr) {}

	void insertAtTheEnd(MyString& selectors, MyString& attributes, MyString& values)
	{
		if (counter >= T && (next == nullptr || next == NULL))
		{
			if (last == nullptr)
			{
				last = new twoWaySectionList();
				next = last;
				last->previous = this;
				last->first = first;
			}
			else
			{
				last->next = new twoWaySectionList();
				last->next->previous = last;
				last->next->first = first;
				last = last->next;
			}
			next->insertAtTheEnd(selectors, attributes, values);
		}
		else if(next != nullptr)
		{
			next->insertAtTheEnd(selectors, attributes, values);
		}
		else
		{
			int sectionIndex = createNewSection();
			int i = 0;
			while (i < selectors.length())
			{
				MyString selectorStr = "";
				int index = 0;
				while (i < selectors.length() && selectors.at(i) != ',')
				{
					if (index == 0 && selectors.at(i) == ' ')
					{
						i++;
						index++;
						continue;
					}
					selectorStr.add(selectors.at(i));
					//tmp.print();
					index++;
					i++;
				}
				if (i == selectors.length() || selectors.at(i) == ',')
				{
					selectorStr.add('\0');
					//tmp.print();
					if (i != selectors.length())
					{
						i++;
					}
				}
				bool add = true;
				Selector* selector = arrOfSection[sectionIndex].selectors.getFirst();
				while (selector != nullptr)
				{
					if (selector->data.compare(selectorStr))
					{
						add = false;
					}
					selector = selector->next;
				}
				if (add == true)
				{
					int length = selectorStr.length();
					MyString selectorWithoutEndSpace = {""};
					if (selectorStr.at(length - 1) == ' ')
					{
						for (int k = 0; k < length - 1; k++)
						{
							selectorWithoutEndSpace.add(selectorStr.at(k));
						}
						arrOfSection[sectionIndex].selectors.insertAtTheEnd(selectorWithoutEndSpace);
					}
					else
					{
						arrOfSection[sectionIndex].selectors.insertAtTheEnd(selectorStr);
					}
				}
				else
				{
					add = true;
				}
			}
			i = 0;
			int j = 0;
			while (i < attributes.length() && j < values.length())
			{
				MyString attributeStr = "";
				MyString valueStr = "";
				int index = 0;
				int index2 = 0;
				while (i < attributes.length() && attributes.at(i) != ',')
				{
					if (index == 0 && attributes.at(i) == ' ')
					{
						i++;
						index++;
						continue;
					}
					attributeStr.add(attributes.at(i));
					//tmp2.print();
					index++;
					i++;
				}
				if (i == attributes.length() || attributes.at(i) == ',')
				{
					attributeStr.add('\0');
					//tmp2.print();
					if (i != attributes.length())
					{
						i++;
					}
				}
				while (j < values.length() && values.at(j) != ';')
				{
					if (index2 == 0 && values.at(j) == ' ')
					{
						j++;
						index2++;
						continue;
					}
					valueStr.add(values.at(j));
					//tmp3.print();
					index2++;
					j++;
				}
				if (j == values.length() || values.at(j) == ';')
				{
					valueStr.add('\0');
					//tmp3.print();
					if (j != values.length())
					{
						j++;
					}
				}
				Attribute* attributePtr = arrOfSection[sectionIndex].attributes.getFirst();
				while (attributePtr != nullptr)
				{
					if (attributes.compare(attributePtr->data))
					{
						attributePtr->value.assign(attributes);
						continue;
					}
					attributePtr = attributePtr->next;
				}
				int length2 = attributeStr.length();
				int length3 = valueStr.length();
				MyString attributeWithoutEndSpace = { "" };
				MyString valueWithoutEndSpace = { "" };
				if (attributeStr.at(length2 - 1) == ' ')
				{
					if (valueStr.at(length3 - 1) == ' ')
					{
						for (int k = 0; k < length2 - 1; k++)
						{
							attributeWithoutEndSpace.add(attributeStr.at(k));
						}
						for (int k = 0; k < length3 - 1; k++)
						{
							valueWithoutEndSpace.add(valueStr.at(k));
						}
						arrOfSection[sectionIndex].attributes.insertAtTheEnd(attributeWithoutEndSpace, valueWithoutEndSpace);
					}
					else
					{
						for (int k = 0; k < length2; k++)
						{
							attributeWithoutEndSpace.add(attributeStr.at(k));
						}
						arrOfSection[sectionIndex].attributes.insertAtTheEnd(attributeWithoutEndSpace, valueStr);
					}
				}
				else
				{
					if (valueStr.at(length3 - 1) == ' ')
					{
						for (int k = 0; k < length3 - 1; k++)
						{
							valueWithoutEndSpace.add(valueStr.at(k));
						}
						arrOfSection[sectionIndex].attributes.insertAtTheEnd(attributeStr, valueWithoutEndSpace);
					}
					else
					{
						arrOfSection[sectionIndex].attributes.insertAtTheEnd(attributeStr, valueStr);
					}
				}
			}
		}
	}
	int createNewSection()
	{
		arrOfSection[counter] = Section();
		return counter++;
	}
};

void countAttributes(MyString& command, twoWaySectionList& list)
{
	MyString tmp = { "" };
	int i = 0;
	int selectorNumber = 0;
	while (command.at(i) != ',')
	{
		int number = (int)command.at(i) - (int)'0';
		selectorNumber = selectorNumber * 10;
		selectorNumber += number;
		i++;
	}
	selectorNumber--;
	twoWaySectionList* currentBlock = list.first;
	while (selectorNumber >= currentBlock->counter)
	{
		selectorNumber -= currentBlock->counter;
		if (currentBlock->next != nullptr)
		{
			currentBlock = currentBlock->next;
		}
		else
		{
			currentBlock = currentBlock->next;
			break;
		}
	}
	if (currentBlock != nullptr)
	{
		int counter = 0;
		Attribute* currentAttribute = currentBlock->arrOfSection[selectorNumber].attributes.getFirst();
		if (currentAttribute != nullptr)
		{
			while (currentAttribute != nullptr)
			{
				counter++;
				currentAttribute = currentAttribute->next;
			}
			command.print();
			cout << " == " << counter << endl;
		}
	}
}

void countAttributeOccurance(MyString& command, twoWaySectionList& list)
{
	MyString attribute = { "" };
	int counter = 0;
	int i = 0;
	while (command.at(i) != ',')
	{
		attribute.add(command.at(i));
		i++;
	}
	twoWaySectionList* currentBlock = list.first;
	int j = 0;
	Attribute* currentAttribute = currentBlock->arrOfSection[j].attributes.getFirst();
	do
	{
		while (j < currentBlock->counter)
		{
			if (currentAttribute != nullptr)
			{
				while (currentAttribute != nullptr)
				{
					if (currentAttribute->data.compare(attribute))
					{
						counter++;
					}
					currentAttribute = currentAttribute->next;
				}
			}
			j++;
			currentAttribute = currentBlock->arrOfSection[j].attributes.getFirst();
		}
		currentBlock = currentBlock->next;
		j = 0;
		if (currentBlock != NULL)
		{
			currentAttribute = currentBlock->arrOfSection[j].attributes.getFirst();
		}
	} while (currentBlock != NULL);
	command.print();
	cout << " == " << counter << endl;
}

void printAttribute(MyString& command, twoWaySectionList& list)
{
	int length = command.length();
	MyString section = { "" };
	MyString attribute = { "" };
	int i = 0;
	int counter = 0;
	while (command.at(i) != ',')
	{
		section.append(command.at(i));
		i++;
	}
	int j = 4;

	while (j < length)
	{
		attribute.add(command.at(j));
		j++;
	}
	i += 3;
	int attributeNumber = 0;
	int length2 = section.length();
	int mnoznik = 0;
	int k = 0;
	while (k < length2)
	{
		int number = (int)section.at(k) - (int)'0';
		attributeNumber += number * (pow(10, mnoznik));
		mnoznik++;
		k++;
	}
	attributeNumber--;
	twoWaySectionList* currentBlock = list.first;
	int control = 0;
	while (attributeNumber > currentBlock->counter)
	{
		if (currentBlock->next == nullptr)
		{
			control = 1;
			break;
		}
		currentBlock = currentBlock->next;
		attributeNumber - currentBlock->counter;
	}
	Attribute* currentAttribute = currentBlock->arrOfSection[attributeNumber].attributes.getFirst();
	MyString value = { "" };
	if (currentAttribute != nullptr)
	{
		while (!attribute.compare(currentAttribute->data))
		{
			if (currentAttribute->next == nullptr)
			{
				control = 1;
				break;
			}
			currentAttribute = currentAttribute->next;
		}
		if (control == 0)
		{
			command.print();
			cout << " == ";
			currentAttribute->value.print();
			cout << endl;
		}
	}
}

void countSelectors(MyString& command, twoWaySectionList& list)
{
	MyString tmp = { "" };
	int i = 0;
	int selectorNumber = 0;
	while (command.at(i) != ',')
	{
		int number = (int)command.at(i) - (int)'0';
		selectorNumber = selectorNumber * 10;
		selectorNumber += number;
		i++;
	}
	selectorNumber--;
	twoWaySectionList* currentBlock = list.first;
	while (selectorNumber >= currentBlock->counter)
	{
		selectorNumber -= currentBlock->counter;
		if (currentBlock->next != nullptr)
		{
			currentBlock = currentBlock->next;
		}
		else
		{
			currentBlock = currentBlock->next;
			break;
		}
	}
	if (currentBlock != nullptr)
	{
		int counter = 0;
		Selector* currentSelector = currentBlock->arrOfSection[selectorNumber].selectors.getFirst();
		if (currentSelector != nullptr)
		{
			while (currentSelector != nullptr)
			{
				counter++;
				currentSelector = currentSelector->next;
			}
			command.print();
			cout << " == " << counter << endl;
		}
	}
}

void countSelectorOccurance(MyString& command, twoWaySectionList& list)
{
	MyString selector = { "" };
	int counter = 0;
	int i = 0;
	while (command.at(i) != ',')
	{
		selector.add(command.at(i));
		i++;
	}
	twoWaySectionList* currentBlock = list.first;
	int j = 0;
	Selector* currentSelector = currentBlock->arrOfSection[j].selectors.getFirst();
	do
	{
		while (j < currentBlock->counter)
		{
			if (currentSelector != nullptr)
			{
				while (currentSelector != nullptr)
				{
					if (currentSelector->data.compare(selector))
					{
						counter++;
					}
					currentSelector = currentSelector->next;
				}
			}
			j++;
			currentSelector = currentBlock->arrOfSection[j].selectors.getFirst();
		}
		currentBlock = currentBlock->next;
		j = 0;
		if (currentBlock != NULL)
		{
			currentSelector = currentBlock->arrOfSection[j].selectors.getFirst();
		}
	} while (currentBlock != NULL);
	command.print();
	cout << " == " << counter << endl;
}

void printSelector(MyString& command, twoWaySectionList& list)
{
	int length = command.length();
	MyString section = { "" };
	MyString selector = { "" };
	int i = 0;
	int counter = 0;
	while (command.at(i) != ',')
	{
		section.append(command.at(i));
		i++;
	}
	int sectionNumber = 0;
	int j = 0;
	int length2 = section.length();
	int mnoznik = 0;
	while (j < length2)
	{
		int number = (int)section.at(j) - (int)'0';
		sectionNumber += number * (pow(10, mnoznik));
		mnoznik++;
		j++;
	}
	sectionNumber--;
	i += 3;
	int selectorNumber = 0;
	mnoznik = 0;
	while (i < length)
	{
		int number = (int)command.at(i) - (int)'0';
		selectorNumber += number * (pow(10, mnoznik));
		mnoznik++;
		i++;
	}
	selectorNumber--;
	twoWaySectionList* currentBlock = list.first;
	int control = 0;
	while (sectionNumber > currentBlock->counter)
	{
		if (currentBlock->next == nullptr)
		{
			control = 1;
			break;
		}
		currentBlock = currentBlock->next;
		sectionNumber - currentBlock->counter;
	}
	Selector* currentSelector = currentBlock->arrOfSection[sectionNumber].selectors.getFirst();
	if (currentSelector != nullptr)
	{
		while (selectorNumber > 0)
		{
			if (currentSelector->next == nullptr)
			{
				control = 1;
				break;
			}
			currentSelector = currentSelector->next;
			selectorNumber--;
		}
		if (control == 0)
		{
			command.print();
			cout << " == ";
			currentSelector->data.print();
			cout << endl;
		}
	}
}

void listNumberOfAttributesFromSection(MyString& command, twoWaySectionList& list)
{
	int length = command.length();
	if (command.at(length - 1) == '?')
	{
		if (command.at(0) == '1' || command.at(0) == '2' || command.at(0) == '3' || command.at(0) == '4' || command.at(0) == '5' || command.at(0) == '6' || command.at(0) == '7' || command.at(0) == '8' || command.at(0) == '9')
		{
			countAttributes(command, list);
		}
		else
		{
			countAttributeOccurance(command, list);
		}
	}
	else
	{
		printAttribute(command, list);
	}
}

void listNumberOfSections(twoWaySectionList& list)
{

	int counter = 0;
	twoWaySectionList* blockList = &list;
	while (blockList->next != nullptr)
	{
		counter += blockList->counter;
		blockList = blockList->next;
	}
	counter += blockList->counter;
	cout << '?' << " == " << counter << endl;

}

void listNumberOfSelectorsFromSection(MyString& command, twoWaySectionList& list)
{
	int length = command.length();
	if (command.at(length - 1) == '?')
	{
		if (command.at(0) == '1' || command.at(0) == '2' || command.at(0) == '3' || command.at(0) == '4' || command.at(0) == '5' || command.at(0) == '6' || command.at(0) == '7' || command.at(0) == '8' || command.at(0) == '9')
		{
			countSelectors(command, list);
		}
		else
		{
			countSelectorOccurance(command, list);
		}
	}
	else
	{
		printSelector(command, list);
	}
}

void listAttributeValueForSelectotr(MyString& command, twoWaySectionList& list)
{
	MyString selector = { "" };
	MyString attribute = { "" };
	int i = 0;
	int length = command.length();
	while (command.at(i) != ',')
	{
		selector.append(command.at(i));
		i++;
	}
	i += 3;
	while (i < length)
	{
		attribute.append(command.at(i));
		i++;
	}
	twoWaySectionList* blockList = list.first;
	Selector* currentSelector = blockList->arrOfSection->selectors.getFirst();
	Selector* lastSelector = currentSelector;
	Attribute* currentAttribute = blockList->arrOfSection->attributes.getFirst();
	Attribute* lastAttribute = currentAttribute;
	Section* section = NULL;
	int j = 0;
	bool display = false;
	while (blockList != nullptr && j < blockList->counter)
	{
		bool find = false;
		while (currentSelector != nullptr)
		{
			if (currentSelector->data.compare(selector))
			{
				while (currentAttribute != nullptr)
				{
					if (currentAttribute->data.compare(attribute))
					{
						display = true;
						lastAttribute = currentAttribute;
						find = true;
						break;
					}
					currentAttribute = currentAttribute->next;
				}
			}
			if (find == true)
			{
				find = false;
				break;
			}
			currentSelector = currentSelector->next;
		}
		j++;
		if (j < blockList->counter)
		{
			currentSelector = blockList->arrOfSection[j].selectors.getFirst();
			currentAttribute = blockList->arrOfSection[j].attributes.getFirst();
		}
		else
		{
			j = 0;
			if (blockList->next != nullptr)
			{
				blockList = blockList->next;
				currentSelector = blockList->arrOfSection[j].selectors.getFirst();
				currentAttribute = blockList->arrOfSection[j].attributes.getFirst();
			}
			else 
			{
				break;
			}
		}
	}
	if (display == true)
	{
		command.print();
		cout << " == ";
		lastAttribute->value.print();
		cout << endl;
	}
}

void deleteCommand(MyString& command, twoWaySectionList& list)
{
	int length = command.length();
	int i = 0;
	int sectionNumber = 0;
	while (command.at(i) != ',')
	{
		int number = (int)command.at(i) - (int)'0';
		sectionNumber += number * (pow(10, i));
		i++;
	}
	twoWaySectionList* blockList = list.first;
	if (command.at(length - 1) == '*')
	{
		while (blockList != nullptr && sectionNumber > blockList->counter)
		{
			sectionNumber -= blockList->counter;
			blockList = blockList->next;
		}
		Attribute* attribute = blockList->arrOfSection[sectionNumber].attributes.getFirst();
		Selector* selector = blockList->arrOfSection[sectionNumber].selectors.getFirst();
		while (attribute != nullptr)
		{
			Attribute* ptr = attribute->next;
			delete attribute;
			attribute = ptr;
		}
		while (selector != nullptr)
		{
			Selector* ptr = selector->next;
			delete selector;
			selector = ptr;
		}
		blockList->counter--;
		for (; sectionNumber < blockList->counter; sectionNumber++)
		{
			Section tmp = blockList->arrOfSection[sectionNumber + 1];
			blockList->arrOfSection[sectionNumber + 1] = blockList->arrOfSection[sectionNumber];
			blockList->arrOfSection[sectionNumber] = tmp;
		}
		blockList->arrOfSection[sectionNumber] = Section();
	}
	else
	{
		MyString attributeSTR = { "" };
		i += 3;
		while (i < length)
		{
			attributeSTR.add(command.at(i));
			i++;
		}
		while (blockList != nullptr && sectionNumber > blockList->counter)
		{
			sectionNumber -= blockList->counter;
			blockList = blockList->next;
		}
		sectionNumber--;
		Attribute* attribute = blockList->arrOfSection[sectionNumber].attributes.getFirst();
		int k = 0;
		while (attribute != nullptr)
		{
			if (attribute->data.compare(attributeSTR))
			{
				break;
			}
			k++;
			attribute = attribute->next;
		}
		int control = 0;
		if (attribute->next == nullptr)
		{
			control = 1;
		}
		delete attribute;
		//Attribute* attribute2 = blockList->arrOfSection[sectionNumber].attributes.getFirst();
		if (attribute==nullptr || control == 1)
		{
			Selector* selector = blockList->arrOfSection[sectionNumber].selectors.getFirst();
			while (selector != nullptr)
			{
				Selector* ptr = selector->next;
				delete selector;
				selector = ptr;
			}
			blockList->arrOfSection[sectionNumber] = Section();
			blockList->counter--;
		}
	}	
	command.print();
	cout << " == deleted" << endl;
}

int main()
{
	twoWaySectionList blockList;
	blockList.first = &blockList;
	MyString cssText{ "" };
	bool command = false;
	bool commandEnd = false;
	char c;
	int length = 0;
	while (cin >> noskipws >> c)
	{
		if (c == '\r' || c == '\t')
		{
			continue;
		}
		if (c == EOF)
		{
			break;
		}
		length++;
		cssText.add(c);
	}
	length = cssText.length();
	MyString selectors = "";
	MyString attributes = "";
	MyString values = "";
	int counterS = 0;
	for (int i = 0; i < length; i++)
	{
		if (commandEnd == true)
		{
			i += 3;
			commandEnd = false;
		}
		int commandStartCounter = 0;
		if (i + 3 < cssText.length() && cssText.at(i) == '?' && cssText.at(i + 1) == '?' && cssText.at(i + 2) == '?' && cssText.at(i + 3) == '?')
		{
			command = true;
		}
		if (cssText.at(i) != '{' && cssText.at(i) != '?' && command == false && cssText.at(i) != '}')
		{
			if (cssText.at(i) != '\n' /* && cssText.at(i) != ' '*/ && cssText.at(i) != '\t')
			{
				if (cssText.at(i) == ' ' && cssText.at(i + 1) == '\n' && cssText.at(i + 2) == '{')
				{
					continue;
				}
				selectors.add(cssText.at(i));
				counterS++;
			}
		}
		int length2 = 0;
		if (cssText.at(i) == '{' && command == false)
		{
			i++;
			int counterA = 0;
			int counterV = 0;
			while (cssText.at(i) != '}')
			{
				if (cssText.at(i) == '\t')
				{
					i++;
					continue;
				}
				if (cssText.at(i) == '\n' && cssText.at(i + 1) == '\t' && cssText.at(i + 2) == '}')
				{
					break;
				}
				if (cssText.at(i) == '\n' && cssText.at(i + 1) == '}')
				{
					break;
				}
				while (cssText.at(i) != ':')
				{
					if (cssText.at(i) != '\n' && cssText.at(i) != '\t')
					{
						attributes.add(cssText.at(i));
						counterA++;
					}
					i++;
				}
				if (cssText.at(i) == ':')
				{
					attributes.add(',');
					counterA++;
					i++;
				}
				while (cssText.at(i) != ';')
				{
					if (cssText.at(i) != '\n' && cssText.at(i) != '\t')
					{
						values.add(cssText.at(i));
						counterV++;
					}
					i++;
				}
				if (cssText.at(i) == ';')
				{
					values.add(';');
					counterV++;
					i++;
				}
			}
			selectors.add('\0');
			attributes.add('\0');
			values.add('\0');
			//cout << "Wchodzimy do funkcji" << endl;
			blockList.insertAtTheEnd(selectors, attributes, values);
			selectors.assign("");
			attributes.assign("");
			values.assign("");
			counterS = 0;
			counterA = 0;
			counterV = 0;
		}
		if (command == true)
		{
			i += 4;
			for (; i < length; i++)
			{
				if (i + 3 < cssText.length() && (cssText.at(i) == '*' && cssText.at(i + 1) == '*' && cssText.at(i + 2) == '*' && cssText.at(i + 3) == '*'))
				{
					command = false;
					commandEnd = true;
					break;
				}
				else
				{
					int index = 0;
					MyString commandStr = { "" };
					while ((i + 3 < cssText.length() && (cssText.at(i) != '*' && cssText.at(i + 1) != '*' && cssText.at(i + 2) != '*' && cssText.at(i + 3) != '*')) || cssText.at(i) == '?')
					{
						if (i > length)
						{
							break;
						}
						while (i < cssText.length() && cssText.at(i) != '\n')
						{
							commandStr.add(cssText.at(i));
							i++;
							index++;
						}
						int checkingIndex = 0;
						while (checkingIndex < index + 1)
						{
							if (checkingIndex < commandStr.length() && commandStr.at(0) == '?')
							{
								listNumberOfSections(blockList);
								checkingIndex++;
							}
							if (checkingIndex < commandStr.length() && commandStr.at(checkingIndex) == ',')
							{
								switch (commandStr.at(checkingIndex + 1))
								{
								case 'A':
									listNumberOfAttributesFromSection(commandStr, blockList);
									break;
								case 'S':									
									listNumberOfSelectorsFromSection(commandStr, blockList);
									break;
								case 'E':
									listAttributeValueForSelectotr(commandStr, blockList);
									break;
								case 'D':
									deleteCommand(commandStr, blockList);
									break;
								default:
									break;
								}
							}
							checkingIndex++;
						}
						index = 0;
						commandStr.assign("");
						i++;
						if (i >= cssText.length())
						{
							break;
						}
					}
				}
			}
		}
	}
	return 0;
}
