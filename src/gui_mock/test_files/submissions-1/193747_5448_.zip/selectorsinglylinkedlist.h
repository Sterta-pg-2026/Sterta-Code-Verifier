#pragma once
#include "selector.h"

class SelectorSinglyLinkedList {
public:

    Selector* head;
    //number of nodes in the list
    int count;

    SelectorSinglyLinkedList() {
        this->head = nullptr;
        count = 0;
    }

    void addNode(Selector* selector) {
        if (head == nullptr) {
            head = selector;
        }
        else {
            Selector* currentSelector = head;

            while (currentSelector && currentSelector->next) {
                currentSelector = currentSelector->next;
            }
            currentSelector->next = selector;
        }
        count++;
    }

    void removeNode(Selector* node) {
        if (node == head) {
            head = head->next;
        }
        else {
            Selector* prev = head;
            while (prev->next != node) {
                prev = prev->next;
            }
            prev->next = node->next;
        }
        count--;
        delete node;
    }

    //returns whether the list is empty after the removal
    bool isListEmpty() {
        return count == 0;
    }
};