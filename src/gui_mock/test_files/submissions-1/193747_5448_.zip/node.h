#pragma once
#include "section.h"

#define T 8

struct Node {
    int count;
    Node* next;
    Node* prev;
    Section* array;

    Node() {
        next = nullptr;
        prev = nullptr;
        count = 0;
        array = new Section[T];
    }

    ~Node() {
        delete[] array;
    }

    bool isArrayFull() {
        return count == T;
    }

    void addSection(Section section) {
        array[count++] = section;
    }

    void removeSection(int sectionIndex) {
        int i = 0;
        while (sectionIndex + i + 1 < T) {
            array[sectionIndex + i] = array[sectionIndex + i + 1];
            i++;
        }
        count--;
    }
};