#include "mystring.h"
