#pragma once
#include <iostream>
#include "mystring.h"

class Selector {
public:

	MyString name;
	Selector* next;

	Selector(char* name) {
		this->name = MyString(name);
		this->next = nullptr;
	};
};