#pragma once
#include <iostream>

using namespace std;

class MyString {
private:
    //pointer to character array
    char* data;

public:
    //length of string
    int lengthOfString;

    //declaration myStrnCpy and myStrLen as static member functions
    static char* myStrnCpy(char* dest, const char* src, int n) {
        char* ret = dest;
        while (*src != '\0' && n > 0) {
            *dest++ = *src++;
            --n;
        }
        *dest = '\0';
        return ret;
    }
    static int myStrLen(const char* str) {
        const char* end = str;
        while (*end != '\0') {
            ++end;
        }
        return end - str;
    }

    //default constructor
    MyString() {
        data = NULL;
        lengthOfString = 0;
    }

    //constructor that takes a char array as input
    MyString(const char* str) {
        lengthOfString = 0;
        while (str[lengthOfString] != '\0') {
            lengthOfString++;
        }
        data = new char[lengthOfString + 1];
        for (int i = 0; i < lengthOfString; i++) {
            data[i] = str[i];
        }
        data[lengthOfString] = '\0';
    }

    //copy constructor
    MyString(const MyString& other) {
        lengthOfString = other.lengthOfString;
        data = new char[lengthOfString + 1];
        for (int i = 0; i < lengthOfString; i++) {
            data[i] = other.data[i];
        }
        data[lengthOfString] = '\0';
    }

    //destructor
    ~MyString() {
        delete[] data;
    }

    //returns length of string
    int size() const {
        return lengthOfString;
    }

    //allows string to be treated like an array
    char& operator[](int index) {
        return data[index];
    }

    //allows string to be treated like a const array
    const char& operator[](int index) const {
        return data[index];
    }

    //checks if 4 last chars are ????
    static bool startCommands(char* string, int lengthOfString) {
        return string[lengthOfString - 1] == '?' && string[lengthOfString - 2] == '?' && string[lengthOfString - 3] == '?' && string[lengthOfString - 4] == '?';
    }

    //reads css sections
    static char* dynamicCSSString() {
        int currentMaxSize = 1;
        char* string = new char[currentMaxSize];
        int lengthOfString = 0;

        char c;
        cin.get(c);

        //till we find ???? we are looping
        while (!startCommands(string, lengthOfString)) {
            //checking if array is full
            if (lengthOfString == currentMaxSize - 1) {
                //multiplying size of the array by 2
                currentMaxSize *= 2;
                char* newString = new char[currentMaxSize];
                for (int i = 0; i < lengthOfString; i++) {
                    newString[i] = string[i];
                }
                delete[] string;
                string = newString;
            }

            string[lengthOfString] = c;
            lengthOfString++;

            cin.get(c);
        }

        string[lengthOfString] = '\0';

        return string;
    }

    static void ignoreWhiteSpacesForAttributes(char* str) {
        //initialize the destination pointer to the beginning of the string
        char* dest = str;

        //loop until the end of the string is reached
        while (*str != '\0') {
            //check if the current character is not a whitespace character
            if (!isspace(*str)) {
                //copy the current character to the destination and advance the pointer
                *dest++ = *str;
            }
            //advance the source pointer to the next character
            str++;
        }

        //add the null terminator to the end of the new string
        *dest = '\0';
    }

    static void ignoreWhiteSpacesForSelectors(char* str) {
        int counter = 0;
        //initialize the destination pointer to the beginning of the string
        char* dest = str;

        //loop until the end of the string is reached
        while (*str != '\0') {
            //check if the current character is not a whitespace character
            if (!isspace(*str)) {
                //copy the current character to the destination and advance the pointer
                *dest++ = *str;
                counter++;
            }
            else if(counter > 0 && findFirstNonWhiteSpace(str) != '\0') {
                //copy the current character to the destination and advance the pointer
                *dest++ = *str;
            }
            //advance the source pointer to the next character
            str++;
        }

        //add the null terminator to the end of the new string
        *dest = '\0';
    }

    static char findFirstNonWhiteSpace(char* str) {
        int i = 0;
        //skipping whitespace characters
        while (isspace(str[i])) { 
            i++;
        }
        return str[i];
    }

    //returns the index of the first appearance of char c in the string; if c is not found, returns -1.
    int findIndex(char c) const {
        //pointer to the beginning of the string
        const char* p = data;
        //index of the current character being examined
        int index = 0;

        //iterate through the string until we find the target character or reach the end
        while (*p != '\0') {
            if (*p == c) {
                //found the character, return its index
                return index;
            }
            //move to the next character
            ++p;
            //increment the index
            ++index;
        }

        //if we reached this point, the character was not found
        return -1;
    }

    //splits the string into multiple substrings at the first appearance of char c, and returns the substrings as a dynamically allocated array of char*. The caller is responsible for deleting the array.
    char** split(char c, int& count) const {
        //pointer to the beginning of the string
        const char* p1 = data;
        const char* p2 = data;
        int lengthOfString = myStrLen(data);
        int numberOfSubstrings = 1;
        int i = 0;

        //counts the number of substrings by counting the number of occurrences of the target character
        for (int j = 0; j < lengthOfString; ++j) {
            if (data[j] == c && j < lengthOfString - 1) {
                ++numberOfSubstrings;
            }
        }

        //allocates an array of char* to hold the substrings
        char** result = new char* [numberOfSubstrings];

        //iterates through the string until we find the target character or reach the end
        while (*p1 != '\0') {
            if (*p1 == c) {
                //if this is the last sign in our string, we break
                if (*(p1 + 1) == '\0') break;
                //create a new substring from the beginning of the string up to the target character
                int length = p1 - p2;
                result[i] = new char[length + 1];
                myStrnCpy(result[i], p2, length);
                result[i][length] = '\0';
                ++i;
                //update the pointer to point to the character after the target character
                p2 = p1 + 1;
            }
            //move to the next character
            ++p1;
        }

        //add the final substring after the last occurrence of the target character
        int length = p1 - p2;
        result[i] = new char[length + 1];
        myStrnCpy(result[i], p2, length);
        result[i][length] = '\0';

        //update the count parameter to indicate the number of substrings
        count = numberOfSubstrings;

        //return the array of substrings
        return result;
    }

    //returns a new string that is a substring of the original string starting at the specified startIndex and ending at the character before the specified endIndex. The substring is returned as a dynamically allocated char*, and the caller is responsible for deleting it.
    char* substring(int startIndex, int endIndex) const {
        int length = endIndex - startIndex;
        char* result = new char[length + 1];
        myStrnCpy(result, data + startIndex, length);
        result[length] = '\0';
        return result;
    }

    void cutString(int startIndex, int endIndex) {
        int length = endIndex - startIndex;
        char* result = new char[length + 1];
        myStrnCpy(result, data + startIndex, length);
        delete[] data;
        result[length] = '\0';
        data = result;
    }

    static bool tryConvertToPositiveInteger(const char* str, unsigned int& result) {
        if (str == nullptr || *str == '\0') {
            // If the string is null or empty, the conversion is not possible
            return false;
        }

        result = 0;
        while (*str != '\0') {
            if (*str < '0' || *str > '9') {
                // If a non-digit character is encountered, the conversion is not possible
                return false;
            }
            result = result * 10 + (*str - '0');
            ++str;
        }

        // Conversion successful
        return true;
    }

    //allows strings to be assigned to each other
    MyString& operator=(const MyString& other) {
        if (this != &other) {
            delete[] data;
            lengthOfString = other.lengthOfString;
            data = new char[lengthOfString + 1];
            for (int i = 0; i < lengthOfString; i++) {
                data[i] = other.data[i];
            }
            data[lengthOfString] = '\0';
        }
        return *this;
    }

    //concatenates two strings
    friend MyString operator+(const MyString& s1, const MyString& s2) {
        MyString result;
        result.lengthOfString = s1.lengthOfString + s2.lengthOfString;
        result.data = new char[result.lengthOfString + 1];
        for (int i = 0; i < s1.lengthOfString; i++) {
            result.data[i] = s1.data[i];
        }
        for (int i = 0; i < s2.lengthOfString; i++) {
            result.data[s1.lengthOfString + i] = s2.data[i];
        }
        result.data[result.lengthOfString] = '\0';
        return result;
    }

    //compares two strings
    friend bool operator==(const MyString& s1, const MyString& s2) {
        if (s1.lengthOfString != s2.lengthOfString) {
            return false;
        }
        for (int i = 0; i < s1.lengthOfString; i++) {
            if (s1.data[i] != s2.data[i]) {
                return false;
            }
        }
        return true;
    }

    //compares two strings
    friend bool operator!=(const MyString& s1, const MyString& s2) {
        return !(s1 == s2);
    }

    //allows string to be printed to console
    friend ostream& operator<<(ostream& os, const MyString& s) {
        os << s.data;
        return os;
    }
};