#pragma once
#include <iostream>
#include "mystring.h"
#include "commands.h"


#define MAX_COMMAND_LENGTH 50 //maximum length of a command
using namespace std;

class CSSProcessor
{ 
public:

	static void processCSS(Commands commands) {
		DoublyLinkedList list;
		divideCSSToSections(commands, list);
	}
	//divides CSS to sections
	static void divideCSSToSections(Commands commands, DoublyLinkedList& sectionsList) {
		int i = 0;

		//creating object myString based on what I read in dynamicString
		MyString CSSInput = MyString(MyString::dynamicCSSString());

		int currentReadIndex = 0;
		int endingIndex = CSSInput.findIndex('{');

		while (endingIndex >= 0) {
			Section currentSection;
			SelectorSinglyLinkedList* selectorsList = new SelectorSinglyLinkedList();
			AttributeSinglyLinkedList* attributesList = new AttributeSinglyLinkedList();

			//adding selector and attributes to the section
			currentSection.selectorsList = selectorsList;
			currentSection.attributesList = attributesList;
			sectionsList.addSection(currentSection);

			char* selectorsGrouped = CSSInput.substring(currentReadIndex, endingIndex);
			int selectorsCount;
			char** selectorsSplit = MyString(selectorsGrouped).split(',', selectorsCount);

			for (int i = 0; i < selectorsCount; i++) {
				//calling static function
				MyString::ignoreWhiteSpacesForSelectors(selectorsSplit[i]);

				if (selectorsSplit[i][0] != '\0') {
					Selector* selector = new Selector(selectorsSplit[i]);
					selectorsList->addNode(selector);
				}

				delete[] selectorsSplit[i];
			}
			
			//free memory
			delete[] selectorsGrouped;
			delete[] selectorsSplit;

			currentReadIndex = endingIndex + 1;
			endingIndex = CSSInput.findIndex('}') - 1;

			char* attributesGrouped = CSSInput.substring(currentReadIndex, endingIndex);
			int attributesCount;
			char** attributesSplit = MyString(attributesGrouped).split(';', attributesCount);

			for (int i = 0; i < attributesCount; i++) {

				if (attributesSplit[i] == "") continue;
					int attributesPairCount;

				char** currentAttributesPair = MyString(attributesSplit[i]).split(':', attributesPairCount);
				MyString::ignoreWhiteSpacesForAttributes(currentAttributesPair[0]);
				delete[] attributesSplit[i];

				Attribute* attribute = new Attribute(currentAttributesPair[0], currentAttributesPair[1]);
				attributesList->addNode(attribute);
				//free memory
				for (int k = 0; k < attributesPairCount; k++) {
					delete[] currentAttributesPair[k];	
				}
				delete[] currentAttributesPair;
			}
			
			//free memory
			delete[] attributesGrouped;
			delete[] attributesSplit;

			//creating substring since first char that we have not analyzed yet (next section) to the end of the string
			CSSInput.cutString(endingIndex + 2, CSSInput.lengthOfString);
			currentReadIndex = 0;
			endingIndex = CSSInput.findIndex('{');
		}
		readAndRunCommands(commands, sectionsList);
	}

	static void readAndRunCommands(Commands commands, DoublyLinkedList& list) {
		streamsize maxSize = MAX_COMMAND_LENGTH;
		char currentLine[MAX_COMMAND_LENGTH];

		while (cin.getline(currentLine, maxSize)) {
			if (currentLine[0] == '\0') continue;

			if (MyString(currentLine) == MyString("****")) {
				divideCSSToSections(commands, list);
				continue;
			}
			runCommand(MyString(currentLine), commands, list);
		}
	}

	static void runCommand(MyString commandName, Commands commands, DoublyLinkedList& list) {
		if (commandName == MyString("?")) {
			cout << "? == " << commands.numberOfSections(list) << endl;
			return;
		}
		int argumentsCount;
		//argumentsCount should always be 3
		char** splitCommand = commandName.split(',', argumentsCount);
		char* firstParameter = splitCommand[0];
		char* secondParameter = splitCommand[1];
		char* thirdParameter = splitCommand[2];

		if (MyString(secondParameter) == MyString("A")) {
			unsigned int firstParameterNumber;

			if (MyString::tryConvertToPositiveInteger(firstParameter, firstParameterNumber)) {
				//i,A,?
				if (MyString(thirdParameter) == MyString("?")) {
					int numberOfAttributes = commands.numberOfAttributesForSection(firstParameterNumber, list);

					if (numberOfAttributes >= 0)
						cout << firstParameterNumber << ",A,? == " << numberOfAttributes << endl;
					
				}
				//i,A,n
				else {
					MyString attributeName = MyString(thirdParameter);
					MyString attributeValue = commands.valueOfTheAttribute(firstParameterNumber, attributeName, list);

					if (attributeValue != commands.errorString)
						cout << firstParameterNumber << ",A," << attributeName << " ==" << attributeValue << endl;
					
				}
			}
			//n,A,?
			else if (MyString(thirdParameter) == MyString("?")) {
				MyString attributeName = MyString(firstParameter);
				int numberOfAttributeOccurences = commands.numberOfAttributeOccurences(attributeName, list);

				if (numberOfAttributeOccurences >= 0)
					cout << attributeName << ",A,? == " << numberOfAttributeOccurences << endl;
				
			}
		}

		if (MyString(secondParameter) == MyString("S")) {
			unsigned int firstParameterNumber;
			unsigned int thirdParameterNumber;

			if (MyString::tryConvertToPositiveInteger(firstParameter, firstParameterNumber)) {
				//i,S,?
				if (MyString(thirdParameter) == MyString("?")) {
					int numberOfSelectors = commands.numberOfSelectorsForSection(firstParameterNumber, list);

					if (numberOfSelectors >= 0)
						cout << firstParameterNumber << ",S,? == " << numberOfSelectors << endl;
					
				}
				//i,S,j
				else if (MyString::tryConvertToPositiveInteger(thirdParameter, thirdParameterNumber)) {
					MyString selectorName = commands.jthSelectorForTheIthBlock(firstParameterNumber, thirdParameterNumber, list);

					if (selectorName != commands.errorString)
						cout << firstParameterNumber << ",S," << thirdParameterNumber << " == " << selectorName << endl;
					
				}
			}
			//z,S,?
			else if (MyString(thirdParameter) == MyString("?")) {
				MyString selectorName = MyString(firstParameter);
				int numberOfSelectorOccurences = commands.numberOfSelectorOccurences(selectorName, list);

				if (numberOfSelectorOccurences >= 0)
					cout << selectorName << ",S,? == " << numberOfSelectorOccurences << endl;
				
			}
		}
		//z,E,n
		if (MyString(secondParameter) == MyString("E")) {
			MyString selectorName = MyString(firstParameter);
			MyString attributeName = MyString(thirdParameter);

			MyString attributeValue = commands.valueOfTheAttributeForSelector(selectorName, attributeName, list);
			if (attributeValue != commands.errorString)
				cout << selectorName << ",E," << attributeName << " ==" << attributeValue << endl;
			
		}
		if (MyString(secondParameter) == MyString("D")) {
			unsigned int firstParameterNumber;
			//i,D,* || i,D,n
			if (MyString::tryConvertToPositiveInteger(firstParameter, firstParameterNumber)) {
				//i,D,*
				if (MyString(thirdParameter) == MyString("*")) {
					if (commands.removeTheSection(firstParameterNumber, list))
						cout << firstParameterNumber << ",D,* == deleted" << endl;
					
				}
				else {
					MyString attributeName = MyString(thirdParameter);
					if (commands.removeAttributeFromSection(firstParameterNumber, attributeName, list))
						cout << firstParameterNumber << ",D," << thirdParameter << " == deleted" << endl;
					
				}
			}
		}
		delete[] splitCommand;
	}
};