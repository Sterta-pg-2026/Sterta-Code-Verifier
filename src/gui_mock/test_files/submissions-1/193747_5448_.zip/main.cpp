#include<iostream>
#include "mystring.h"
#include "selector.h"
#include "attribute.h"
#include "selectorsinglylinkedlist.h"
#include "attributesinglylinkedlist.h"
#include "section.h"
#include "node.h"
#include "doublylinkedlist.h"
#include "cssprocessor.h"
#include "commands.h"

using namespace std;

int main()
{
	Node* head;
	Node* tail;
	Commands commands;
	
	CSSProcessor::processCSS(commands);

	return 0;
}