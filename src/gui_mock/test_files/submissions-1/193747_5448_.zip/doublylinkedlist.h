#pragma once
#include "node.h"


class DoublyLinkedList {
public:

    Node* head;
    Node* tail;
    int count;

    DoublyLinkedList() {
        this->head = nullptr;
        this->tail = nullptr;
        count = 0;
    }

    void addNode() {
        //allocating node memory
        Node* newNode = new Node();
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        count++;
    }

    void removeNode(Node* nodeToRemove) {
        if (nodeToRemove == nullptr) {
            return;
        }

        if (nodeToRemove->prev != nullptr) {
            nodeToRemove->prev->next = nodeToRemove->next;
        }
        else {
            head = nodeToRemove->next;
        }

        if (nodeToRemove->next != nullptr) {
            nodeToRemove->next->prev = nodeToRemove->prev;
        }
        else {
            tail = nodeToRemove->prev;
        }
        count--;
        delete nodeToRemove;
    }


    void printList() {
        Node* currentNode = head;
        while (currentNode != nullptr) {
            for (int i = 0; i < currentNode->count; i++)
                //cout << currentNode->array[i] << " ";
                currentNode = currentNode->next;
        }
        cout << endl;
    }

    void addSection(Section section) {
        //if array is full we're adding node
        if (tail == nullptr || tail->isArrayFull()) {
            addNode();
        }
        tail->addSection(section);
    }

    void removeSection(int sectionNumber) {
        int arrayIndex, nodeIndex;
        getIndicesForSectionNumber(sectionNumber, arrayIndex, nodeIndex);
        Node* currentNode = head;

        for (int i = 0; i < nodeIndex; i++) {
            currentNode = currentNode->next;
        }

        // if our current section is the last one we remove node
        if (currentNode->count == 1) {
            removeNode(currentNode);
        }
        else {
            currentNode->removeSection(arrayIndex);
        }
    }

    void getIndicesForSectionNumber(int sectionNumber, int& arrayIndex, int& nodeIndex) {
        Node* currentNode = head;
        int alreadySeenSections = 0;
        nodeIndex = 0;
        while (sectionNumber > alreadySeenSections + currentNode->count) {
            alreadySeenSections += currentNode->count;
            currentNode = currentNode->next;
            nodeIndex++;
        }
        arrayIndex = sectionNumber - 1 - alreadySeenSections;
    }
};