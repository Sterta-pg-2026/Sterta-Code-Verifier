#pragma once
#include "attribute.h"

class AttributeSinglyLinkedList {
public:

    Attribute* head;
    //number of nodes in the list
    int count;

    AttributeSinglyLinkedList() {
        this->head = nullptr;
        count = 0;
    }

    void addNode(Attribute* attribute) {
        if (head == nullptr) {
            head = attribute;
        }
        else {
            Attribute* currentAttribute = head;

            while (currentAttribute && currentAttribute->next) {
                currentAttribute = currentAttribute->next;
            }
            currentAttribute->next = attribute;
        }
        count++;
    }

    void removeNode(Attribute* node) {
        if (node == head) {
            head = head->next;
        }
        else {
            Attribute* prev = head;
            while (prev->next != node) {
                prev = prev->next;
            }
            prev->next = node->next;
        }
        count--;
        delete node;
    }

    //returns whether the list is empty after the removal
    bool isListEmpty() {
        return count == 0;
    }
};

