#pragma once
#include "selectorsinglylinkedlist.h"
#include "attributesinglylinkedlist.h"

struct Section {
    SelectorSinglyLinkedList* selectorsList;
    AttributeSinglyLinkedList* attributesList;
};