#pragma once
#include <iostream>
#include "mystring.h"

class Attribute {
public:

	MyString name;
	MyString value;
	Attribute* next;

	Attribute(char* name, char* value) {
		this->name = MyString(name);
		this->value = MyString(value);
		this->next = nullptr;
	};

	Attribute(MyString name, MyString value) {
		this->name = name;
		this->value = value;
		this->next = nullptr;
	};
};

