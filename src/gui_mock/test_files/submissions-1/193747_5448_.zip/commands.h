#pragma once
#include "doublylinkedlist.h"
#include "mystring.h"

class Commands
{
public:
    const MyString errorString = MyString("error");

    // ?
    int numberOfSections(DoublyLinkedList list) {
        int numberOfSections = 0;

        Node* currentNode = list.head;

        for (int i = 0; i < list.count; i++) {
            numberOfSections += currentNode->count;
            currentNode = currentNode->next;
        }
        return numberOfSections;
    }

    // i,S,?
    int numberOfSelectorsForSection(int sectionNumber, DoublyLinkedList list) {
        if (sectionNumber > numberOfSections(list)) return -1;

        Section currentSection = CommandsHelper::getSection(sectionNumber, list);

        return currentSection.selectorsList->count;
    }

    // i,A,?
    int numberOfAttributesForSection(int sectionNumber, DoublyLinkedList list) {
        if (sectionNumber > numberOfSections(list)) return -1;

        Section currentSection = CommandsHelper::getSection(sectionNumber, list);

        AttributeSinglyLinkedList uniqueAttributesList = CommandsHelper::getUniqueAttributesInTheSection(currentSection);

        return uniqueAttributesList.count;

    }

    // i,S,j
    MyString jthSelectorForTheIthBlock(int sectionNumber, int selectorNumber, DoublyLinkedList list) {
        if (sectionNumber > numberOfSections(list)) return errorString;
        if (selectorNumber > numberOfSelectorsForSection(sectionNumber, list)) return errorString;

        Section currentSection = CommandsHelper::getSection(sectionNumber, list);

        Selector* currentSelector = CommandsHelper::getSelector(selectorNumber, currentSection);

        return currentSelector->name;
    }

    // i,A,n
    MyString valueOfTheAttribute(int sectionNumber, MyString name, DoublyLinkedList list) {
        if (sectionNumber > numberOfSections(list)) return errorString;

        Section currentSection = CommandsHelper::getSection(sectionNumber, list);

        Attribute* currentAttribute = CommandsHelper::getAttribute(name, currentSection);

        return currentAttribute == NULL ? errorString : currentAttribute->value;
    }

    // n,A,?
    int numberOfAttributeOccurences(MyString name, DoublyLinkedList list) {
        int counter = 0;

        for (int i = 1; i <= numberOfSections(list); i++) {
            Section currentSection = CommandsHelper::getSection(i, list);

            if (CommandsHelper::isAttributeInTheSection(currentSection, name)) {
                counter++;
            }
        }
        return counter;
    }

    // z,S,?
    int numberOfSelectorOccurences(MyString name, DoublyLinkedList list) {
        int counter = 0;

        for (int i = 1; i <= numberOfSections(list); i++) {
            Section currentSection = CommandsHelper::getSection(i, list);

            if (CommandsHelper::isSelectorInTheSection(currentSection, name)) {
                counter++;
            }
        }
        return counter;
    }

    // z,E,n
    MyString valueOfTheAttributeForSelector(MyString selectorName, MyString attributeName, DoublyLinkedList list) {
        for (int i = numberOfSections(list); i >= 1; i--) {
            Section currentSection = CommandsHelper::getSection(i, list);

            if (CommandsHelper::isSelectorInTheSection(currentSection, selectorName) && CommandsHelper::isAttributeInTheSection(currentSection, attributeName)) {
                return CommandsHelper::attributeInTheSection(currentSection, attributeName)->value;
            }
        }
        return errorString;
    }

    // i,D,*
    bool removeTheSection(int sectionNumber, DoublyLinkedList& list) {
        if (sectionNumber > numberOfSections(list))
            return false;
        list.removeSection(sectionNumber);
        return true;
    }

    // i,D,n
    bool removeAttributeFromSection(int sectionNumber, MyString attributeName, DoublyLinkedList& list) {
        if (sectionNumber > numberOfSections(list))
            return false;
        Section section = CommandsHelper::getSection(sectionNumber, list);
        Attribute* attribute = CommandsHelper::getAttribute(attributeName, section);
        if (attribute == nullptr)
            return false;

        section.attributesList->removeNode(attribute);

        if (section.attributesList->isListEmpty())
            list.removeSection(sectionNumber);
        return true;
    }


    static class CommandsHelper
    {
    public:
        static Section getSection(int sectionNumber, DoublyLinkedList list) {
            int arrayIndex, nodeIndex;
            getIndicesForSectionNumber(sectionNumber, arrayIndex, nodeIndex, list);
            Node* currentNode = list.head;

            for (int i = 0; i < nodeIndex; i++) {
                currentNode = currentNode->next;
            }

            Section currentSection = currentNode->array[arrayIndex];

            return currentSection;
        }

        static Section getSectionReverse(int sectionNumber, DoublyLinkedList list) {
            int arrayIndex, nodeIndex;
            getIndicesForSectionNumber(sectionNumber, arrayIndex, nodeIndex, list);
            Node* currentNode = list.tail;

            for (int i = 0; i < nodeIndex; i++) {
                currentNode = currentNode->prev;
            }

            Section currentSection = currentNode->array[arrayIndex];

            return currentSection;
        }

        static Selector* getSelector(int selectorNumber, Section section) {
            Selector* currentSelector = section.selectorsList->head;

            for (int i = 0; i < selectorNumber - 1; i++) {
                currentSelector = currentSelector->next;
            }

            return currentSelector;
        }

        static Attribute* getAttribute(MyString name, Section section) {
            Attribute* currentAttribute = section.attributesList->head;
            Attribute* returnAttribute = nullptr;

            while (currentAttribute != NULL) {
                if (currentAttribute->name == name) {
                    returnAttribute = currentAttribute;
                }
                currentAttribute = currentAttribute->next;
            }

            return returnAttribute;
        }

        static bool isAttributeInTheSection(Section section, MyString attributesName) {
            Attribute* currentAttribute = section.attributesList->head;

            while (currentAttribute != NULL) {
                if (currentAttribute->name == attributesName) {
                    return true;
                }
                currentAttribute = currentAttribute->next;
            }
            return false;
        }

        static AttributeSinglyLinkedList getUniqueAttributesInTheSection(Section section) {
            Attribute* currentAttribute = section.attributesList->head;
            AttributeSinglyLinkedList uniqueAttributeList;

            while (currentAttribute != NULL) {
                Attribute* currentUniqueAttribute = uniqueAttributeList.head;

                bool inserted = false;

                while (currentUniqueAttribute) {
                    if (currentAttribute->name == currentUniqueAttribute->name) {
                        currentUniqueAttribute->value = currentAttribute->value;
                        inserted = true;
                    }
                    currentUniqueAttribute = currentUniqueAttribute->next;
                }
                if (!inserted) {
                    uniqueAttributeList.addNode(new Attribute(currentAttribute->name, currentAttribute->value));
                }
                currentAttribute = currentAttribute->next;
            }
            return uniqueAttributeList;
        }

        static bool isSelectorInTheSection(Section section, MyString selectorName) {
            Selector* currentSelector = section.selectorsList->head;

            while (currentSelector != NULL) {
                if (currentSelector->name == selectorName) {
                    return true;
                }
                currentSelector = currentSelector->next;
            }
            return false;
        }

        static Attribute* attributeInTheSection(Section section, MyString attributesName) {
            Attribute* currentAttribute = section.attributesList->head;

            while (currentAttribute != NULL) {
                if (currentAttribute->name == attributesName) {
                    return currentAttribute;
                }
                currentAttribute = currentAttribute->next;
            }
            return NULL;
        }

        static void getIndicesForSectionNumber(int sectionNumber, int& arrayIndex, int& nodeIndex, DoublyLinkedList list) {
            Node* currentNode = list.head;
            int alreadySeenSections = 0;
            nodeIndex = 0;

            while (sectionNumber > alreadySeenSections + currentNode->count) {
                alreadySeenSections += currentNode->count;
                currentNode = currentNode->next;
                nodeIndex++;
            }
            arrayIndex = sectionNumber - 1 - alreadySeenSections;
        }
    };
};