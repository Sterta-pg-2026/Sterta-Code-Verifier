#ifndef MainList_h
#define MainList_h
//#include "Projekt1_PAiSD.cpp"
#include "nodes.h"
#define CHAR_CAPACITY 30
#define T_CAPACITY 8
#define SPACE 32
#define POINT 46
#define NULL_VALUE '\0'
#define OPEN_KLAMRA 123
#define CLOSE_KLAMRA 125
#define COMMA 44
#define SEMICOLON 59
#define COLON 58
#define KOMENDY '????'

class List {
private:
	List* next;
	List* prev;
	Blok* arr;
	
public:
	int licznik;
	List* head;
	
	List();
	void add(Blok* blok);
	void PrintList();
	int getLicznikSekcji() { return this->licznik; }
	char* getSelector(int numerSekcji, int numerSelektoru);
	int getNumberOfSelecor(char* nameSelector);
	char* getValueOfatrybute(int numerSekcji, char* nameAtrybutu);
	int getLicznikSelektorow(int numerSekcji);
	int getLicznikAtrybutow(int numerSekcji);
	~List() {
		/*List* tmp = nullptr;t
		while (head) {
			tmp = head;
			head = head->next;
			delete tmp;
		}
		head = nullptr;*/
	}

};

#endif