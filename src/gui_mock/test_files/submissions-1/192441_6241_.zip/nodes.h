#ifndef Nodes_h
#define Nodes_h
#include <iostream>
//#include "MainList.h"
using namespace std;




struct NodeSelector {

	NodeSelector* next;
	NodeSelector* prev;
	char* selector;

	NodeSelector* head;
	int licznikSel;
	NodeSelector() : next(nullptr), prev(nullptr), head(nullptr), selector(nullptr), licznikSel(0) {}
	void AddNode(char* selec);
	int getLicznik() { return licznikSel; }
	char* getSelector(int numerSelektoru);

	friend ostream& operator<< (ostream& cout, const NodeSelector& obj) {
		NodeSelector* ptr = obj.head;
		cout << ptr->selector;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
			cout << ',' << ' ' << ptr->selector;
		}
		return cout;
	}
};

struct NodeValues {
	NodeValues* next;
	NodeValues* prev;
	NodeValues* head;
	char* value;
	NodeValues();
	void add(char* value);
};

struct NodeOfAtribute {
	NodeOfAtribute* next;
	NodeOfAtribute* prev;
	NodeOfAtribute* head;
	char* attributes;
	/*NodeValues* value;*/
	char* value;
	int licznikVal;
	int licznikAtrybutow = 0;
	NodeOfAtribute();
	int getLicznikAtrybutow() { return licznikAtrybutow; }
	char* getValue(char* nameAtrybuta);

	void AddNode(char* attributes, char* values);

	friend ostream& operator<< (ostream& cout, const NodeOfAtribute& obj) {
		NodeOfAtribute* ptr = new NodeOfAtribute();
		NodeValues* ptrV = new NodeValues();
		ptr = obj.head;
		/*ptrV = ptr->value->head;*/
		cout << ptr->attributes << ':';
		cout << ptr->value;
		/*cout << ptrV->value;
		while (ptrV->next != nullptr) {
			ptrV = ptrV->next;
			cout << ',' << ' ' << ptrV->value;
		}*/
		cout << ';' << endl;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
			/*ptrV = ptr->value->head;*/
			cout << ptr->attributes << ':';
			cout << ptr->value;
			/*cout << ptrV->value;*/
			/*while (ptrV->next != nullptr) {
				ptrV = ptrV->next;
				cout << ',' << ' ' << ptrV->value;
			}*/
			cout << ';' << endl;
		}
		return cout;
	}
};



struct Blok {
	NodeSelector* listS;
	NodeOfAtribute* listA;
	int licznikAtt;
	int licznikSel;
	int licznikVal;
	friend ostream& operator<< (ostream& cout, const Blok& obj) {
		cout << *obj.listS << '{' << endl << *obj.listA << '}' << endl;
		return cout;
	}
	//Blok() {
	///*	this->headS = nullptr;
	//	this->headA = nullptr;*/
	//	this->licznikAtt = 0;
	//	this->licznikSel = 0;
	//	this->licznikVal = 0;
	//}

	Blok(NodeSelector* listS = nullptr, NodeOfAtribute* listA = nullptr, char* selectors = nullptr,
		int licznikSel = 0, char* attributes = nullptr, int licznikAtt = 0,
		char* values = nullptr, int licznikVal = 0);

};

#endif