﻿#pragma warning(disable : 4996)
#include "mainlist.h"
#include "nodes.h"
#include <iostream>
#include <stdlib.h>

#define CHAR_CAPACITY 30
#define T_CAPACITY 8
#define SPACE 32
#define POINT 46
#define NULL_VALUE '\0'
#define OPEN_KLAMRA 123
#define CLOSE_KLAMRA 125
#define COMMA 44
#define SEMICOLON 59
#define COLON 58
#define KOMENDY_START '????'
#define KOMENDY_STOP '****'
#define QUESTION_MARK '?'

using namespace std;


void parser() {

}


char* findCenter(char* buffer) {
	char* tmp = new char[128];
	strcpy(tmp, buffer);
	int size = sizeof(tmp);
	for (int i = 0; i < size; i++) {
		/*if (tmp[i] == COMMA) {
			return tmp[i + 1];
		} */
		if (buffer[i] == COMMA) {
		return &buffer[i+1];
	}
	}
	return NULL;
}

int getLeftNumb(char* buffer) {
	char* tmp = new char[128];
	strcpy(tmp, buffer);
	int size = sizeof(tmp);
	for (int i = 0; i < size; i++) {
		if (tmp[i] == COMMA) {
			tmp[i] = NULL_VALUE;
			return atoi(tmp);
		}
	}
	return 0;
}

char* getLeftName(char* buffer) {
	char* tmp = new char[128];
	strcpy(tmp, buffer);
	int size = sizeof(tmp);
	for (int i = 0; i < size; i++) {
		if (tmp[i] == COMMA) {
			tmp[i] = NULL_VALUE;
			return tmp;
		}
	}
	return NULL;
}

int getRightNumb(char* buffer) {
	char* tmp = new char[128];
	strcpy(tmp, buffer);
	int size = sizeof(tmp);
	for (int i = size-1; i >= 0; i--) {
		if (tmp[i] == COMMA) {
			char* tmp2 = new char[sizeof(buffer) - size];
			for (int j = 0; j < sizeof(tmp2); j++) {
				tmp2[j] = tmp[size];
				size++;
			}

			return atoi(tmp2);
		}
	}
	return 0;
}

char* getRightName(char* buffer) {
	char* tmp = new char[128];
	strcpy(tmp, buffer);
	int size = sizeof(tmp);
	for (int i = size - 1; i >= 0; i--) {
		if (tmp[i] == COMMA) {
			char* tmp2 = new char[sizeof(buffer) - size];
			for (int j = 0; j < sizeof(tmp2); j++) {
				tmp2[j] = tmp[size];
				size++;
			}

			return tmp2;
		}
	}
	return NULL;
}



int main()
{
	List list;
	char ch;
	Blok* blok = new Blok;
	char* atrybut = nullptr;
	bool licznikZero;
	int licznikLit = 0;
	

	while (true) {
		licznikZero = false;
		cin >> ch;
		char buffer[128];

		buffer[licznikLit] = ch;		
		
		if (ch == OPEN_KLAMRA) {
			Blok* sekcja = new Blok;
			char* selector1 = new char[licznikLit];
			int j = 0;
			for (int i = 0; i < licznikLit; i++, j++) {
				if (buffer[i] == COMMA) {

					selector1[j] = NULL_VALUE;
					sekcja->listS->AddNode(selector1);
					selector1 = new char[licznikLit];
					j = 0;
					i++;
				}
				selector1[j] = buffer[i];
			}
			selector1[j] = NULL_VALUE;
			sekcja->listS->AddNode(selector1);
			blok = sekcja;
			licznikZero = true;
		}

		if (ch == COLON) {
			char* attr = new char[licznikLit];
			for (int i = 0; i < licznikLit; i++) {
				attr[i] = buffer[i];
			}
			attr[licznikLit] = NULL_VALUE;
			atrybut = attr;
			licznikZero = true;
		}

		if (ch == SEMICOLON) {
			NodeValues* values = new NodeValues;
			char* value = new char[licznikLit];
			int j = 0;
			for (int i = 0; i < licznikLit; i++, j++) {
				if (buffer[i] == COMMA) {
					value[j] = NULL_VALUE;
					values->add(value);
					value = new char[licznikLit];
					j = 0;
					i++;
				}
				if ((buffer[i] > 64 && buffer[i] < 91) && (buffer[i-1] > 96 && buffer[i-1] < 123)  ) {
					value[j] = SPACE;
					j++;
				}
				value[j] = buffer[i];
			}
			value[j] = NULL_VALUE;
			values->add(value);
			blok->listA->AddNode(atrybut, value);
			licznikZero = true; 
		}

		if (ch == CLOSE_KLAMRA) {
			list.add(blok);
			licznikZero = true;
		}


		if (licznikLit > 2 && buffer[licznikLit] == QUESTION_MARK && buffer[licznikLit - 1] == QUESTION_MARK &&
			buffer[licznikLit - 2] == QUESTION_MARK && buffer[licznikLit - 3] == QUESTION_MARK) {
			licznikLit = 0;

			bool newParameters = true;
			while (true) {
				licznikZero = false;
				if (newParameters) {
					cin >> buffer;
					newParameters = false;
				}
			

				if (*buffer == QUESTION_MARK) {
					cout << list.head->getLicznikSekcji() << endl;
					licznikZero = true;
				}
				
				if (buffer[licznikLit] == COMMA) {
					/*for (int i = 0; i < 3; i++) {
					licznikLit++;
					cin >> buffer[licznikLit];
					}*/
					
					
					switch (*(findCenter(buffer))) {
					case 'S':
						if (*(findCenter(buffer)+2) == QUESTION_MARK) {
							if (int(buffer[0]) > 47 && int(buffer[0]) < 58) {
								int numerSekcji = getLeftNumb(buffer);
								if (list.getLicznikSelektorow(numerSekcji) != NULL) {
									cout << "==" << list.getLicznikSelektorow(numerSekcji) << endl;
								}
								licznikZero = true;
							}
							else {
								buffer[licznikLit] = NULL_VALUE;
								cout << " == " << list.getNumberOfSelecor(buffer) << endl;
								licznikZero = true;
							}
							
						} else if (*(findCenter(buffer) + 2) > 47 && *(findCenter(buffer) + 2) < 58) {
							int numerSekcji = getLeftNumb(buffer);
							int numerSelektoru = getRightNumb(buffer);
							if (list.getSelector(numerSekcji, numerSelektoru) != NULL) {
								cout << list.getSelector(numerSekcji, numerSelektoru) << endl;
							}
							
							licznikZero = true;
						}
						break;
					case 'A':
						if (*(findCenter(buffer) + 2) == QUESTION_MARK) {
							if (*(findCenter(buffer) - 2) > 47 && *(findCenter(buffer) - 2) < 58) {
								int numerSekcji = getLeftNumb(buffer); 
								if (list.getLicznikAtrybutow(numerSekcji) != NULL) {
									cout << "==" << list.getLicznikAtrybutow(numerSekcji) << endl;
								}
								licznikZero = true;
							}
							else {
								buffer[licznikLit - 3] = NULL_VALUE;
								/*cout << " == " << list.getNumberOfSelecor(buffer);*/
								licznikZero = true;
							}

						}
						else {
							int numerSekcji = getLeftNumb(buffer);
							char* nazwaAtrybutu = getRightName(buffer);
							cout << list.getValueOfatrybute(numerSekcji, nazwaAtrybutu);
							licznikZero = true;
						}



						break;
					case 'E':



						break;
					case 'D':



						break;

					}
				}
				if (*buffer == KOMENDY_STOP) {
					break;
				}
				
				if (licznikZero) {
					licznikLit = 0;
					newParameters = true;
				}
				else {
					licznikLit++;
				}

			}

		}
		

		if (ch == POINT) {
			list.PrintList();
			break;
		}
		
		if (licznikZero) {
			licznikLit = 0;
		} else {
			licznikLit++;
		}
	}
	return 0;
}

