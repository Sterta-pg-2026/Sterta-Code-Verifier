#include "nodes.h"
#define SPACE ' '

using namespace std;


Blok::Blok(NodeSelector* listS, NodeOfAtribute* listA, char* selectors, int licznikSel, char* attributes, int licznikAtt, char* values, int licznikVal) {
	this->listA = new NodeOfAtribute();
	this->listS = new NodeSelector();
}


void NodeSelector::AddNode(char* selec) {

	if (head == nullptr) {
		NodeSelector* blo = new NodeSelector;
		blo->selector = selec;
		head = blo;

		cout << "Node Appended ad head node" << endl;
	}
	else {
		NodeSelector* n = new NodeSelector;
		NodeSelector* ptr = head;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		ptr->next = n;
		n->prev = ptr;
		n->selector = selec;
		cout << "Node appended to the end" << endl;
	}
	head->licznikSel++;
}

char* NodeSelector::getSelector(int numerSelektoru)
{
	NodeSelector* ptr = head;
	for (int i = 1; i < (numerSelektoru); i++) {
		if (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		else {
			return NULL;
		}
	}
	return ptr->selector;
}




NodeValues::NodeValues() {
	this->next = nullptr;
	this->prev = nullptr;
	this->head = nullptr;
	this->value = nullptr;
}

void NodeValues::add(char* value) {
	if (head == nullptr) {
		NodeValues* first = new NodeValues;
		first->value = value;
		head = first;
	}
	else {
		NodeValues* node = new NodeValues;
		NodeValues* ptr = head;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		node->value = value;
		ptr->next = node;
		node->prev = ptr;
	}
}



NodeOfAtribute::NodeOfAtribute() {
	this->next = nullptr;
	this->prev = nullptr;
	this->head = nullptr;
	this->attributes = 0;
	this->value = nullptr;
	/*this->value = new NodeValues();*/
	this->licznikAtrybutow = 0;
}

char* NodeOfAtribute::getValue(char* nameAtrybuta)
{
	NodeOfAtribute* ptr = head;
	while (true) {
		if (strcmp(ptr->attributes, nameAtrybuta) == 0 ) {
			return ptr->value;
		}
		if (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		else {
			return NULL;
		}
	}

	return NULL;
}

void NodeOfAtribute::AddNode(char* attributes, char* value) {

	if (head == nullptr) {
		NodeOfAtribute* blo = new NodeOfAtribute;
		blo->attributes = attributes;
		/*blo->value = values;*/
		blo->value = value;
		head = blo;
		cout << "Node Appended ad head node" << endl;
	}
	else {
		NodeOfAtribute* n = new NodeOfAtribute;
		NodeOfAtribute* ptr = head;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		ptr->next = n;
		n->prev = ptr;
		n->attributes = attributes;
		n->value = value;
		cout << "Node appended to the end" << endl;
	}
	this->licznikAtrybutow++;
}

