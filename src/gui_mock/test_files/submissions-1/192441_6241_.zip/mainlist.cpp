#include "mainlist.h"
#include "nodes.h"
#include <iostream>


List::List() {
	this->next = nullptr;
	this->prev = nullptr;
	this->arr = nullptr;

	this->head = nullptr;
	licznik = 0;
}

void List::add(Blok* blok) {
	List* current = new List;

	if (head == nullptr) {
		List* blo = new List;
		blo->arr = new Blok[T_CAPACITY];

		head = blo;
		current = head;
		cout << "Node Appended ad head node" << endl;
	}
	current = head;
	if (head->licznik % T_CAPACITY == 0 && head->licznik != 0) {
		List* n = new List;
		List* ptr = head;
		while (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		ptr->next = n;
		n->prev = ptr;
		n->arr = new Blok[T_CAPACITY];
		current = n;
		cout << "Node appended to the end" << endl;
	}

	current->arr[head->licznik % T_CAPACITY] = *blok;
	head->licznik++;
}

void List::PrintList() {
	List* ptr = head;
	int lim = head->licznik;
	if (ptr != nullptr) {
		while (ptr != nullptr) {
			for (int i = 0; i < T_CAPACITY; i++, lim--) {
				if (lim == 0) { break; }
				cout << ptr->arr[i] << endl;
			}
			if (ptr->next != nullptr) {
				ptr = ptr->next;
			}
		}
	}
}

char* List::getSelector(int numerSekcji, int numerSelektoru)
{
	List* ptr = head;
	for (int i = 0; i < (numerSekcji / T_CAPACITY); i++) { 
		if (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		else {
			return NULL;
		}
	}
	return ptr->arr[(numerSekcji % T_CAPACITY) - 1].listS->getSelector(numerSelektoru);
}

int List::getNumberOfSelecor(char* nameSelector)
{
	List* ptr = this->head;
	int licznik = 0;
	int liczbaSelektorow; 
	int liczbaSekcji = ptr->getLicznikSekcji();
	for (int i = 1; i <= (liczbaSekcji/T_CAPACITY) +1; i++) {
		
		for (int j = 0; j < liczbaSekcji%T_CAPACITY; j++) {
			liczbaSelektorow = ptr->arr[j].listS->head->getLicznik();
			for (int k = 1; k <= liczbaSelektorow; k++) {
				if (strcmp(ptr->arr[j].listS->getSelector(k), nameSelector) == 0) {
					licznik++;
				}
			}
		}
	}
	return licznik;
}

char* List::getValueOfatrybute(int numerSekcji, char* nameAtrybutu)
{
	List* ptr = head;
	for (int i = 0; i < (numerSekcji / T_CAPACITY); i++) {
		if (ptr->next != nullptr) {
			ptr = ptr->next;
		}
		else {
			return NULL;
		}
	} 
	
	return ptr->arr[(numerSekcji % T_CAPACITY) - 1].listA->getValue(nameAtrybutu);
}

int List::getLicznikSelektorow(int numerSekcji)
{
	List* ptr = this->head;
	if (numerSekcji >= 1) {
		for (int i = 0; i < (numerSekcji/T_CAPACITY); i++) {
			if (ptr->next != nullptr) {
				ptr = ptr->next;
			}
			else {
				return NULL;
			}
		}
		return ptr->arr[(numerSekcji % (T_CAPACITY)) - 1].listS->head->getLicznik();
	}
	return 0;
}

int List::getLicznikAtrybutow(int numerSekcji)
{
	List* ptr = this->head;
	if (numerSekcji >= 1) {
		for (int i = 0; i < (numerSekcji / T_CAPACITY); i++) {
			if (ptr->next != nullptr) {
				ptr = ptr->next;
			}
			else {
				return NULL;
			}
		}
		return ptr->arr[(numerSekcji % (T_CAPACITY)) - 1].listA->licznikAtrybutow;
	}
	return 0;
}
