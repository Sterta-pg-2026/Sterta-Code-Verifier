#include <iostream>
#include <cstring>

#include "section.h"

section::section()
{
	selectors = NULL;
	atr = NULL;
}

bool cmp(atributes atr1, atributes atr2)
{
	if (strcmp(atr1.atr, atr2.atr) == 0)
		return true;
	else
		return false;
}

bool cmp(char* char1, char* char2)
{
	if (strcmp(char1, char2) == 0)
		return true;
	else
		return false;
}
