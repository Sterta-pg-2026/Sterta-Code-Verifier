#pragma once

//****
void readCSSRule(List<section>** root);
//?
int numberOfSection(List<section>* root);
//i,S,?
int numberOfSelectorsAtSection(List<section>* root, int index);
//i,A,?
int numberOfAtributesAtSection(List<section>* root, int index);
//i,S,j
char* getSelectorFromSection(List<section>* root, int indexOfSelector, int indexOfSection);
//i,A,n
char* getValuesOfAtributeFromSection(List<section>* root, int index, char* atrName);
//n,A,?
int numberOfAllInstanceOfAtribute(List<section>* root, char* atrName);
//z,S,?
int numberOfAllInstanceOfSelectors(List<section>* root, char* Selector);
//z,E,n
char* getValueOfAtributeOfSelector(List<section>* root, char* Selector, char* atrName);
//i,D,*
bool deleteSection(List<section>** root, int index);
//i,D,n
bool deleteAtrFromSection(List<section>** root, int indexOfSection, char* atrName);
