#include<cstring>

#include "atributes.h"
#include "variables.h"

atributes::atributes()
{
	atr = new char[size_of_string];
	value = new char[size_of_string];
}
