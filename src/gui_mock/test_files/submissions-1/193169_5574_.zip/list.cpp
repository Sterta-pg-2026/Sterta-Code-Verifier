#include <iostream>

#include "list.h"
#include "section.h"

using namespace std;

template<typename T> List<T>::List()
{
	currentSize = 0;
	for (int i = 0; i < MAXSIZE; i++)
	{
		inUse[i] = false;
	}
}

template<typename T> List<T>::~List()
{
	List<T>* current = this;
	while (current != NULL)
	{
		List<T>* toDelete = current;
		current = current->next;
		delete toDelete;
	}
}

template<typename T>
void addNewNode(List<T>** root, T& data)
{
	if (*root == NULL)
	{
		List<T>* newNode = new List<T>();

		newNode->data[0] = data;
		newNode->inUse[0] = true;
		newNode->currentSize = 1;
		newNode->next = NULL;
		newNode->prev = NULL;
		*root = newNode;
	}
	else
	{
		List<T>* tmpNode = *root;
		while (tmpNode != NULL)
		{
			if (tmpNode->currentSize < MAXSIZE)
			{
				tmpNode->data[tmpNode->currentSize] = data;
				tmpNode->inUse[tmpNode->currentSize] = true;
				(tmpNode->currentSize)++;
				break;
			}
			else
			{
				if (tmpNode->next != NULL)
				{
					tmpNode = tmpNode->next;
				}
				else
				{
					List<T>* newNode = new List<T>();

					newNode->data[0] = data;
					newNode->inUse[0] = true;
					newNode->currentSize = 1;
					newNode->next = NULL;
					tmpNode->next = newNode;
					newNode->prev = tmpNode;
					break;
				}
			}
		}
	}

}

template<typename T>
bool printList(List<T>* root)
{
	while (root != NULL)
	{
		for (int i = 0; i < root->currentSize; i++)
		{
			if (root->inUse[i])
			{
				cout << root->data[i] << " ";
			}

		}
		root = root->next;
	}
	return true;
}

template<typename T>
bool deleteNode(List<T>** root, int index)
{
	if (root == NULL)
		return false;
	int current = 1;
	int position = 0;
	bool found = false;
	List<T>* tmpNode = *root;
	while (tmpNode != NULL && !found)
	{
		for (position = 0; position < tmpNode->currentSize; position++)
		{
			if (current == index && tmpNode->inUse[position])
			{
				tmpNode->inUse[position] = false;
				found = true;
				break;
			}
			if (tmpNode->inUse[position])
			{
				current++;
			}
		}

		if (current != index || position == tmpNode->currentSize)
			tmpNode = tmpNode->next;
	}

	if (found)
	{
		bool isFree = true;
		for (int i = 0; i < tmpNode->currentSize; i++)
		{
			if (tmpNode->inUse[i] == true)
			{
				isFree = false;
			}
		}

		if (isFree)
		{
			if (tmpNode->prev != NULL)
			{
				tmpNode->prev->next = tmpNode->next;
			}
			if (tmpNode->next != NULL)
			{
				tmpNode->next->prev = tmpNode->prev;
			}
		}

		
	}

	return found;
}

template<typename T>
T* getElementAtIndex(List<T>* root, int index)
{
	T* toReturn = new T;
	int current = 1;
	int position = 0;
	bool found = false;
	while (root != NULL && !found)
	{
		for (position = 0; position < root->currentSize; position++)
		{
			if (current == index && root->inUse[position])
			{
				*toReturn = root->data[position];
				found = true;
				break;
			}
			if (root->inUse[position])
			{
				current++;
			}
		}

		if (current != index || position == root->currentSize)
			root = root->next;
	}

	if (root == NULL)
		return NULL;
	else if (root->inUse[position])
		return toReturn;
	else
		throw 1;
}

template<typename T>
int getSize(List<T>* root)
{
	int size = 0;
	while (root != NULL)
	{
		for (int i = 0; i < root->currentSize; i++)
		{
			if (root->inUse[i])
			{
				size++;
			}

		}
		root = root->next;
	}
	return size;
}

template<typename T>
bool findByValue(List<T>* root, T* value)
{
	while (root != NULL)
	{
		for (int i = 0; i < root->currentSize; i++)
		{
			if (root->inUse[i])
			{
				if (cmp(*value, root->data[i]))
				{
					root->inUse[i]=false;
					return true;
				}
			}
		}
		root = root->next;
	}
	return false;
}
