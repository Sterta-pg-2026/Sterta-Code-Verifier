#pragma once

#include "list.h"
#include "atributes.h"

class section
{
public:
	List<char*>* selectors;
	List<atributes>* atr;
	
	section();
};

bool cmp(atributes atr1, atributes atr2);

bool cmp(char* char1, char* char2);
