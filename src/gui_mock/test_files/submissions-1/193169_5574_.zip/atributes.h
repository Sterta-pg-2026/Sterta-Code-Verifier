#pragma once

class atributes
{
public:
	char* atr;
	char* value;

	atributes();
};
