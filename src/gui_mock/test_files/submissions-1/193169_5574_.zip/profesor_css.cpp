#include <iostream>
#include <cstring>

#include "list.h"
#include "list.cpp"
#include "atributes.h"
#include "section.h"
#include "main.h"
#include "variables.h"

#pragma warning(disable : 4996)

using namespace std;

int main2()
{
	List<int>* root = NULL;
	//printList(root);
	for (int i = 0; i < 20; i++)
	{
		int aaa = i * 10 + 15;
		addNewNode(&root, aaa);
	}

	printList(root);
	cout << "\n" << getSize(root);
	cout << "\n\n";
	for (int i = 0; i < 8; i++)
		deleteNode(&root, 9);


	/*try { cout << getElementAtIndex(root, 20) << " "; }
	catch (const char* msg) { cout << msg; }*/

	for (int i = 0; i < 20; i++)
	{
		try {
			cout << *getElementAtIndex(root, i + 1) << " ";
		}
		catch (const char* msg) { cout << msg; }
	}
	/*try { cout << getElementAtIndex(root, 21) << " "; }
	catch (const char* msg) { cout << msg; }*/
	//cout << getElementAtIndex(root, 20);
	//cout<<root.getLast();
	//cout<<"Hello World";
	cout << '\n';
	return 0;
}

int main()
{
	List<section>* mainList = NULL;
	char option[size_of_string];
	readCSSRule(&mainList);
	while (cin.getline(option, size_of_string))
	{
		if (option[0] <= ' ')
		{
			while (cin.getline(option, size_of_string))
			{
				if (option[0] != '\0')
					break;
			}
			if (option[0] <= ' ')
				break;
		}
		if (strcmp(option, "?") == 0)
		{
			cout << "? == " << getSize(mainList) << endl;
			//podaj ilosc sekcji
		}
		else if (strcmp(option, "****") == 0)
		{
			//continue reading CSS
			readCSSRule(&mainList);
		}
		else
		{
			char* commend;
			char* par1 = NULL;
			char* par2 = NULL;
			char* token;
			int num;
			int num2;
			token = strtok(option, ",");
			num = atoi(token);
			par1 = token;
			token = strtok(NULL, ",");
			commend = token;
			token = strtok(NULL, ",");
			num2 = atoi(token);
			par2 = token;
			par2 = token;
			if (strcmp(commend, "S") == 0)
			{
				if (num2 != 0)
				{
					//wypisywania j-tego selektora dla i-tego bloku j: " << num << " i: " << num2 << '\n';
					char* odp = getSelectorFromSection(mainList, num2, num);
					if(odp!=NULL)
						cout << par1 << "," << commend << "," << par2 << " == " << odp << endl;
				}
				else if (num != 0)
				{
					//wypisywanie liczby selektorow dla sekcji i: " << num << '\n';
					int odp = 0;
					odp = numberOfSelectorsAtSection(mainList, num);
					if(odp!=-1)
						cout << par1 << "," << commend << "," << par2 << " == "
								<< odp << '\n';
				}
				else
				{
					//wypisywanie liczby wsytapien selektora z: " << par1 << '\n';
					int odp = 0;
					odp = numberOfAllInstanceOfSelectors(mainList, par1);
					cout << par1 << "," << commend << "," << par2 << " == "
						<< odp << endl;
				}
			}
			else if (strcmp(commend, "A") == 0)
			{
				if (num == 0)
				{
					//wypisz liczbe atrybutow n w calosci n: " << par1 << '\n';
					int odp = 0;
					odp = numberOfAllInstanceOfAtribute(mainList, par1);

					cout << par1 << "," << commend << "," << par2 << " == " <<
						odp << endl;
				}
				else if (strcmp(par2, "?") == 0)
				{
					int odp = 0;

					odp = numberOfAtributesAtSection(mainList, num);
					if (odp != -1)
						cout << par1 << "," << commend << "," << par2 << " == " << odp << endl;
				}
				else
				{
					char* odp = getValuesOfAtributeFromSection(mainList, num, par2);
					if(odp!=NULL)
					cout << par1 << "," << commend << "," << par2 << " == " <<
						odp << endl;
				}
			}
			else if (strcmp(commend, "D") == 0)
			{
				if (strcmp(par2, "*") == 0)
				{
					//usun i-ta sekcje i: " << num << '\n';
					if (deleteSection(&mainList, num) == true)
					{
						cout << par1 << "," << commend << "," << par2 << " == deleted\n";
					}
				}
				else
				{
					if (deleteAtrFromSection(&mainList, num, par2) == true)
					{
						cout << par1 << "," << commend << "," << par2 << " == deleted\n";
					}
				}
			}
			else
			{
				//wypisz wartosc atrybutu n dla selektora z: " << par1 << " n: " << par2 << '\n';
				char* odp = getValueOfAtributeOfSelector(mainList, par1, par2);
				if(odp!=NULL)
				cout << par1 << "," << commend << "," << par2 << " == "
					<< odp << endl;
			}
			//end of reading commands
		}
	}
	return 0;
}

void readCSSRule(List<section>** root)
{
	char input;
	char* buffer;
	bool reading = true;
	bool selectors = true;
	bool ratributes = false;
	int index;
	while (reading)
	{
		//new section
		section* newSection = new section;
		selectors = true;
		while (selectors)
		{
			index = 0;
			buffer = new char[size_of_string];
			input = getchar();
			while (input <= ' ' || input == ',' || input == '\n')
			{
				input = getchar();
			}
			while (input != ',' && input != '{')
			{
				if (index == 4)
				{
					buffer[4] = '\0';
					if (strcmp(buffer, "????") == 0)
					{
						delete[] buffer;
						return;
					}
				}
				buffer[index] = input;
				index++;
				input = getchar();
			}
			if (reading == false)
			{
				break;
			}
			while (buffer[index] <= ' ')
			{
				index--;
			}
			if (input == '{')
			{
				selectors = false;
			}
			buffer[index + 1] = '\0';
			if (index != 0)
			{
				findByValue(newSection->selectors, &buffer);
				addNewNode(&(newSection->selectors), buffer);
			}
		}
		//koniec wczytywania selektorow\nteraz beda selektory
		if (reading == false)
		{
			break;
		}
		ratributes = true;
		while (ratributes)
		{
			atributes* newPair = new atributes;
			index = 0;
			buffer = new char[size_of_string];
			input = getchar();
			while (input <= ' ')
			{
				input = getchar();
			}
			if (input == '}')
			{
				ratributes = false;
			}
			while (input <= ' ' || input == ';' || input == '\n')
			{
				input = getchar();
			}
			while (input != ':' && input != ' ')
			{
				buffer[index] = input;
				index++;
				input = getchar();
			}
			buffer[index] = '\0';
			//here is atrName
			newPair->atr = buffer;
			buffer = new char[size_of_string];
			while (input <= ' ' || input == ':' || input == '\n')
			{
				input = getchar();
			}
			index = 0;
			while (input != '}' && input != ';' && input != '\n')
			{
				buffer[index] = input;
				index++;
				input = getchar();
			}
			//here is atrValue
			buffer[index] = '\0';
			newPair->value = buffer;
			if (!findByValue(newSection->atr, newPair))
			{
				
			}
			addNewNode(&(newSection->atr), *newPair);
			while (input <= ' ' || input == '\n' || input == ';')
			{
				input = getchar();
			}
			if (input == '}')
			{
				ratributes = false;
			}
			while (input <= ' ')
			{
				input = getchar();
			}
			if (input == '}')
			{
				ratributes = false;
			}
			else
			{
				ungetc(input, stdin);
			}
		}
		addNewNode(root, *newSection);
	}
}

int numberOfSelectorsAtSection(List<section>* root, int index)
{
	
	section* current = getElementAtIndex(root, index);
	if (current != NULL)
		return getSize(current->selectors);
	else
		return -1;
	
}

int numberOfAtributesAtSection(List<section>* root, int index)
{
	section* current = getElementAtIndex(root, index);
	if (current != NULL)
		return getSize(current->atr);
	else
		return -1;
}

char* getSelectorFromSection(List<section>* root, int indexOfSelector, int indexOfSection)
{
	section* current = getElementAtIndex(root, indexOfSection);
	if (current != NULL)
	{
		char** odp = getElementAtIndex(current->selectors, indexOfSelector);
		if (odp != NULL)
			return *odp;
		else
			return NULL;
	}
	else
		return NULL;
}

char* getValuesOfAtributeFromSection(List<section>* root, int index, char* atrName)
{
	section* current = getElementAtIndex(root, index);
	if (current == NULL)
		return NULL;
	List<atributes>* atr = current->atr;
	int position = 0;
	while (atr != NULL)
	{
		for (position = 0; position < atr->currentSize; position++)
		{
			if (atr->inUse[position] == true)
			{
				if (strcmp(atr->data[position].atr, atrName) == 0)
				{
					return atr->data[position].value;
				}
			}
		}
		atr = atr->next;
	}
	return NULL;
}

int numberOfAllInstanceOfAtribute(List<section>* root, char* atrName)
{
	List<atributes>* atr = NULL;
	int instance = 0;
	int position = 0;
	while (root != NULL)
	{
		for (position = 0; position < root->currentSize; position++)
		{
			if (root->inUse[position] == true)
			{
				atr = root->data[position].atr;
				int inner = 0;
				while (atr != NULL)
				{
					for (inner = 0; inner < atr->currentSize; inner++)
					{
						if (atr->inUse[inner] == true)
						{
							if (strcmp(atr->data[inner].atr, atrName) == 0)
							{
								instance++;
							}
						}
					}
					atr = atr->next;
				}
			}
		}
		root = root->next;
	}
	return instance;
}

int numberOfAllInstanceOfSelectors(List<section>* root, char* Selector)
{
	int instance = 0;
	int position = 0;
	while (root != NULL)
	{
		for (position = 0; position < root->currentSize; position++)
		{
			if (root->inUse[position] == true)
			{
				int inner = 0;
				List<char*>* innerList = root->data[position].selectors;
				while (innerList != NULL)
				{
					for (inner = 0; inner < root->currentSize; inner++)
					{
						if (innerList->inUse[inner] == true)
						{
							if (strcmp(innerList->data[inner], Selector) == 0)
							{
								instance++;
							}
						}
					}
					innerList = innerList->next;
				}
			}
		}
		root = root->next;
	}
	return instance;
}

char* getValueOfAtributeOfSelector(List<section>* root, char* Selector, char* atrName)
{
	char* toReturn = NULL;
	int position = 0;
	int inner = 0;
	List<atributes>* atr = NULL;
	List<char*>* sel = NULL;
	bool found = false;
	while (root != NULL)
	{
		for (position = 0; position < root->currentSize; position++)
		{
			if (root->inUse[position] == true)
			{
				sel = root->data[position].selectors;
				found = false;
				while (sel != NULL && !found)
				{
					for (inner = 0; inner < sel->currentSize; inner++)
					{
						if (sel->inUse[inner] == true)
						{
							if (strcmp(sel->data[inner], Selector) == 0)
							{
								found = true;
							}
						}
					}
					sel = sel->next;
				}
				if (found)
				{
					atr = root->data[position].atr;
					while (atr != NULL)
					{

						for (inner = 0; inner < atr->currentSize; inner++)
						{
							if (atr->inUse[inner] == true)
							{
								if (strcmp(atr->data[inner].atr, atrName) == 0)
								{
									toReturn = atr->data[inner].value;
								}
							}
						}
						atr = atr->next;
					}
				}
			}
		}
		root = root->next;
	}
	if (toReturn == NULL)
		return NULL;
	else
		return toReturn;
}

bool deleteSection(List<section>** root, int index)
{
	return deleteNode(root, index);
}

bool deleteAtrFromSection(List<section>** root, int indexOfSection, char* atrName)
{
	int position;
	List<section>* tmpNode = *root;
	int current = 1;
	bool found = false;
	bool deleted = false;
	while (tmpNode != NULL && !found)
	{
		for (position = 0; position < tmpNode->currentSize; position++)
		{
			if (current == indexOfSection && tmpNode->inUse[position])
			{
				found = true;
				break;
			}
			if (tmpNode->inUse[position])
			{
				current++;
			}
		}

		if (current != indexOfSection || position == tmpNode->currentSize)
			tmpNode = tmpNode->next;
	}

	if (found)
	{
		List<atributes>* atr = tmpNode->data[position].atr;
		found = false;
		int inner;
		while (atr != NULL)
		{
			for (inner = 0; inner < atr->currentSize; inner++)
			{
				if (atr->inUse[inner])
				{
					if (strcmp(atr->data[inner].atr, atrName) == 0)
					{
						atr->inUse[inner] = false;
						deleted = true;
					}
					else
					{
						found = true;
					}
				}
			}
			atr = atr->next;
		}
		if (!found)
		{
			tmpNode->inUse[position] = false;

			bool isFree = true;
			for (int i = 0; i < tmpNode->currentSize; i++)
			{
				if (tmpNode->inUse[i] == true)
				{
					isFree = false;
				}
			}

			if (isFree)
			{
				if (tmpNode->prev != NULL)
				{
					tmpNode->prev->next = tmpNode->next;
				}
				if (tmpNode->next != NULL)
				{
					tmpNode->next->prev = tmpNode->prev;
				}
			}
		}
	}
	return deleted;
}
