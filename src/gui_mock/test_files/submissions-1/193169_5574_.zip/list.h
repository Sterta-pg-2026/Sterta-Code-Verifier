#pragma once 

#include "atributes.h"

const int MAXSIZE = 29;

template<typename T> 
class List {
public:
	List<T>* prev;
	List<T>* next;

	T data[MAXSIZE];
	bool inUse[MAXSIZE];
	int currentSize;

	List();
	~List();
};

template<typename T> void 
addNewNode(List<T>** root, T& data);

template<typename T> bool 
printList(List<T>* root);

template<typename T>
bool deleteNode(List<T>** root, int index);

template<typename T>
T* getElementAtIndex(List<T>* root, int index);

template<typename T>
int getSize(List<T>* root);

template<typename T>
bool findByValue(List<T>* root, T* value);
