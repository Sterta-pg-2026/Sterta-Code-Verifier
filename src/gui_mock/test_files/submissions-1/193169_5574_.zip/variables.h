#pragma once

const int size_of_string = 126;
