//
// Created by adamj on 24.03.2023.
//
#pragma once
#include "mylist.h"
#include "mystring.h"

class Parser {
private:
    int previous_string_length;
    int duplicate_index;
    String previous_string;
    String selector_name;
    String attribute_name;
    String attribute_value;
    String command;
    String ii;
    String jj;
    String nn;
    String zz;
    char operation;
    bool firstComma;
    bool parsing;
    bool IsBlock;
    bool isAttributeName;
    bool isDuplicate;
    struct Attribute {
        String name;
        String value;
    };
    Attribute attribute;
    struct Section {
        DoubleLinkedList<String> Selectors;
        DoubleLinkedList<Attribute> Attributes;
    };
    DoubleLinkedList<Section> Sections{};
    Section section;

public:
    Parser();
    void Parse(String& input);
    int NumOfSections();
    int NumOfSelectors(int index);
    int selectorOccursion(String& name);
    String* selectorName(int ii, int jj);
    int NumOfAttributes(int index);
    String* attributeName(int ii, String& name);
    int attributeOccursion(String& name);
    String* attributeValue(String& ii, String& jj);
    bool deleteSection(int ii);
    bool deleteAttribute(int ii, String& jj);
};