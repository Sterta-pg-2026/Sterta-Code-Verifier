#include <iostream>
#include "mylist.h"
#include "mystring.h"
#include "parser.h"
#include <cstdio>
using namespace std;


int main() {
    std::ios_base::sync_with_stdio(false); 
    std::cin.tie(NULL);
    Parser p;
    String string;
    char c = '\0';

    while(!cin.eof()) {
        c = getchar();
        if(c == EOF) break;
        if(c != '\n') {
            string.PushBack(c);
        }
        else {
            p.Parse(string);
            string.Clear();
        }
    }
    string.PushBack('\n');
    p.Parse(string);
    return 0;
}
