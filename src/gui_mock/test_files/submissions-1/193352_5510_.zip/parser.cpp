//
// Created by adamj on 24.03.2023.
//
#include "parser.h"
#include "mystring.h"
#include "mylist.h"
using namespace std;
 
Parser::Parser() {
    firstComma = true;
    parsing = true;
    IsBlock = false;
    isAttributeName = false;
    isDuplicate = false;
    //Section section;
}
 
int Parser::NumOfSections() {
    return Sections.GetSize();
}
 
int Parser::NumOfSelectors(int ii) {
    if(ii <= Sections.GetSize()) {
        return Sections[ii - 1].Selectors.GetSize();
    }
    else {
        return -1;
    }
}
 
String* Parser::selectorName(int ii, int jj) {
    if(ii <= Sections.GetSize()) {
        Section *pom;
        pom = &(Sections[ii - 1]);
        if(jj <= pom->Selectors.GetSize()) {
            return &(pom->Selectors[jj - 1]);
        }
        else {
            return nullptr;
        }
    }
    return nullptr;
}
 
int Parser::selectorOccursion(String &name) {
    int cnt = 0;
    DoubleLinkedList<Parser::Section>::ListElement_type *pom = Sections.head;
    while(pom != nullptr) {
        for(int i = 0; i < TAB_SIZE; i++) {
            if(pom->is_taken[i] == false) {
                continue;
            }
            else {
                for(int j = 0; j < pom->tab[i].Selectors.GetSize(); j++) {
                    if(pom->tab[i].Selectors[j] == name) {
                        cnt++;
                        break;
                    }
                }
            }
        }
        pom = pom->next;
    }
    return cnt;
}
 
int Parser::NumOfAttributes(int ii) {
    DoubleLinkedList<String> pom;
    if(ii <= Sections.GetSize()) {
        return Sections[ii -1].Attributes.GetSize();
    }
    return 0;
}
 
String* Parser::attributeName(int ii, String& name) {
    if(ii > Sections.GetSize()) {
        return nullptr;
    }
    String tmp;
    Section *pom;
    pom = &(Sections[ii - 1]);
    tmp.PushBack(' ');
    for(int i = 0; i < pom->Attributes.GetSize(); i++) {
        if(pom->Attributes[i].name == name) {
            return &(pom->Attributes[i].value);
        }
    }
    return nullptr;
 
}
 
int Parser::attributeOccursion(String &name) {
    int cnt = 0;
    DoubleLinkedList<Parser::Section>::ListElement_type *pom = Sections.head;
    while(pom != nullptr) {
        for(int i = 0; i < TAB_SIZE; i++) {
            if(pom->is_taken[i] == false) {
                continue;
            }
            else {
                for(int j = 0; j < pom->tab[i].Attributes.GetSize(); j++) {
                    if(pom->tab[i].Attributes[j].name == name) {
                        cnt++;
                        break;
                    }
                }
            }
        }
        pom = pom->next;
    }
    return cnt;
}
String* Parser::attributeValue(String &ii, String &jj) {
    DoubleLinkedList<Parser::Section>::ListElement_type *current_node = Sections.tail;
    DoubleLinkedList<String>::ListElement_type *current_selector;
    DoubleLinkedList<Attribute>::ListElement_type *current_attribute;
    while(current_node != nullptr) {
        for(int i = TAB_SIZE - 1; i >= 0; i--) {
            if(current_node->is_taken[i] != false) {
                current_selector = current_node->tab[i].Selectors.tail;
                while(current_selector != nullptr) {
                    for(int j = TAB_SIZE - 1; j >= 0; j--) {
                        if(current_selector->is_taken[j] != false) {
                            if(current_selector->tab[j] == ii) {
                                current_attribute = current_node->tab[i].Attributes.tail;
                                while(current_attribute != nullptr) {
                                    for(int k = TAB_SIZE - 1; k >= 0; k--) {
                                        if(current_attribute->is_taken[k] != false) {
                                            if(current_attribute->tab[k].name == jj) {
                                                return &(current_attribute->tab[k].value);
                                            }
                                        }
                                    }
                                    current_attribute = current_attribute->previous;
                                }
                            }
                        }
                    }
                    current_selector = current_selector->previous;
                }
            }
        }
        current_node = current_node->previous;
    }
    return nullptr;
}
 
bool Parser::deleteSection(int ii) {
    if(ii > Sections.GetSize()) {
        return false;
    }
    else {
        Sections.RemoveByIndex(ii - 1);
        return true;
    }
}
 
bool Parser::deleteAttribute(int ii, String &jj) {
    bool isDeleted = false;
    if(ii > Sections.GetSize())
        return false;
    Section* pom;
    pom = &(Sections[ii - 1]);
    for(int i = 0; i < pom->Attributes.GetSize(); i++) {
        if(pom->Attributes[i].name == jj) {
            pom->Attributes.RemoveByIndex(i);
            i--;
            isDeleted = true;
        }
    }
    if(pom->Attributes.GetSize() == 0) {
        Sections.RemoveByIndex(ii - 1);
    }
    if(isDeleted == true) {
        return true;
    }
    else{
        return false;
    }
}
 
void Parser::Parse(String &string) {
    int pom = 0;
    if(string == "????") {
        parsing = false;
        return;
    }
 
    if(parsing == true) {
        for(int i = 0; i < string.GetLength(); i++) {
            if(string[i] < ' ')
                continue;
            if(IsBlock == true) {
                if(string[i] == ':') {
                    attribute_name.RemoveBlankSpace();
                    for(int k = 0; k < section.Attributes.GetSize(); k++) {
                        if(section.Attributes[k].name == attribute_name) {
                            attribute_name.Clear();
                            duplicate_index = k;
                            isDuplicate = true;
                        }
                    }
                    if(isDuplicate == false) {
                        attribute.name = attribute_name;
                        attribute_name.Clear();
                    }
                    isAttributeName = false;
                }
                else if(string[i] == ';') {
                    attribute_value.RemoveBlankSpace();
                    if(isDuplicate == true) {
                        section.Attributes[duplicate_index].value = attribute_value;
                    }
                    else {
                        attribute.value = attribute_value;
                        section.Attributes.PushBack(attribute);
                    }
                    attribute_value.Clear();
                    isAttributeName = true;
                    isDuplicate = false;
                }
                else if(isAttributeName == true) {
                    if(string[i] != '{' && string[i] != '}') {
                        attribute_name.PushBack(string[i]);
                    }
                }
                else if(isAttributeName == false) {
                    if(string[i] != '{' && string[i] != '}') {
                        attribute_value.PushBack(string[i]);
                    }
                }
            }
            else if(string[i] == '{') {
                IsBlock = true;
                isAttributeName = true;
                section.Selectors = selector_name.Split(',');
                for(int nn = 0; nn < section.Selectors.GetSize(); nn++) {
                    section.Selectors[nn].RemoveBlankSpace();
                }
                selector_name.Clear();
            }
            else {
                if(string[i] == ';') {
                    selector_name.Clear();
                    return;
                }
                else {
                    selector_name.PushBack(string[i]);
                }
            }
            if(string[i] == '}') {
                IsBlock = false;
                Sections.PushBack(move(section));
                section.Selectors.Clear();
                section.Attributes.Clear();
            }
        }
        previous_string = string;
        previous_string_length = string.string_length;
    }
    else if(string == "****") parsing = true;
    else {
        for(int i = 0; i < string.GetLength(); i++) {
            if(string == "?") {
                cout << "? == " << NumOfSections() << endl;
                return;
            }
            else if(string[i] == ',' && firstComma == true) {
                if(string[i+1] != 'A' && string[i+1] != 'S' && string[i+1] != 'E' && string[i+1] != 'D') {
                    command.Clear();
                    return;
                }
                firstComma = false;
                ii = command;
                command.Clear();
            }
            else if(string[i] == ',' && firstComma == false) {
                operation = string[i-1];
                command.Clear();
            }
            else {
                command.PushBack(string[i]);
            }
        }
        jj = command;
        command.Clear();
        firstComma = true;
        if(ii.isNumber() == true && ii.string_length > 0) {
            int num = ii.StringToInt();
            switch(operation) {
                case 'S':
                    if(jj == "?") {
                        if(NumOfSelectors(num) == -1) {
                            return;
                        }
                        else {
                            cout << string << " == " << NumOfSelectors(num) << endl;
                        }
                    }
                    else if(jj.isNumber() == true) {
                        int num2 = jj.StringToInt();
                        if(selectorName(num, num2) == nullptr) {
                            return;
                        }
                        else {
                            cout << string << " == " << *(selectorName(num, num2)) << endl;
                        }
                    }
                    return;
                case 'A':
                    if(jj == "?") {
                        if(NumOfAttributes(num) == 0) {
                            return;
                        }
                        else {
                            cout << string << " == " << NumOfAttributes(num) << endl;
                        }
                    }
                    else if(jj.isNumber() != true) {
                        if(attributeName(num, jj) == nullptr){
                            return;
                        }
                        else {
                            cout << string << " == " << *(attributeName(num, jj)) << endl;
                        }
                    }
                    return;
                case 'D':
                    bool anwser = false;
                    if(jj == "*") {
                        anwser = deleteSection(num);
                    }
                    else {
                        anwser = deleteAttribute(num , jj);
                    }
                    if(anwser == true) {
                        cout << string << " == deleted" << endl;
                    }
                    return;
            }
        }
        else if(ii.string_length > 0){
            switch(operation) {
                case 'S':
                    if(jj == "?") {
                        cout << string << " == " << selectorOccursion(ii) << endl;
                    }
                    return;
                case 'A':
                    if(jj == "?") {
                        cout << string << " == " << attributeOccursion(ii) << endl;
                    }
                    return;
                case 'E':
                    if (attributeValue(ii, jj) == nullptr) {
                        return;
                    }
                    else {
                        cout << string << " == " << *(attributeValue(ii, jj)) << endl;
                    }
                    return;
            }
        }
    }
}