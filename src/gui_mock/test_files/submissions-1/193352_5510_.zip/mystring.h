//
// Created by adamj on 23.03.2023.
//
#pragma once
#include <iostream>
#include "mylist.h"

using namespace std;

class String {
public:
    char * data;
    int string_length;

    // Operators
    friend bool operator==(String& str1, const char* str2); //done
    friend bool operator==(const String& str1, const String& str2);
    friend ostream& operator<<(ostream& os, const String& str); // done
    String& operator=(const char *right); // done
    String& operator=(const String& _other);
    String& operator+=(const char right);
    char& operator[](int index);    // done
    const char& operator[](int index) const;

    // Constructors & destructor
    String();   // done
    String(const String& data);
    ~String();  // done

    // Functions
    void PushBack(char c);
    void Clear();
    void CopyString();
    void DeleteLast();
    void DeleteFirst();
    void RemoveBlankSpace();
    DoubleLinkedList<String> Split(char c);
    int GetLength();    // done
    int StringToInt();
    bool isNumber();
    // nalezy dodac konstruktor kopiujacy i operator kopiujacy
};
