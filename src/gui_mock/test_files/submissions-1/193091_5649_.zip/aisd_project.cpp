#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "datastructure.h"
#include <cstdio>

#define CONST_T 17

using std::cin;
using std::cout;

void ParseString(const MyString& _string, MyString& _string1, MyString& _string2, MyString& _string3) 
{
    int i;
    for (i = 0; i < _string.size && _string.data[i] != ',' && _string.data[i] != '\0'; i++)
    {
        _string1.addChar(_string.data[i]);
    }
    i++;
    for (i; i < _string.size && _string.data[i] != ',' && _string.data[i] != '\0'; i++)
    {
        _string2.addChar(_string.data[i]);
    }
    i++;
    for (i; i < _string.size && _string.data[i] != ',' && _string.data[i] != '\n' && _string.data[i] != '\0'; i++)
    {
        _string3.addChar(_string.data[i]);
    }
    _string1.removeExtremeWhitespace();
    _string2.removeExtremeWhitespace();
    _string3.removeExtremeWhitespace();
}

void exeISI(int _block, MyString _string, int _selector, DoublyLinkedList* AllNodes)
{
    Section* section = AllNodes->findSection(_block);
    if (section == nullptr) return;
    Selector* selector = section->findSelector(_selector);
    if (selector == nullptr) return;
    MyString resSelector = (selector->name);
    if (&resSelector == nullptr) return;
    if (resSelector.length() == 0) return;
    cout << _block << "," << _string.data << "," << _selector << " == " << resSelector.data << "\n";
}

void exeSSS(MyString _string1, MyString _string2, MyString _string3, DoublyLinkedList* AllNodes)
{
    if (strcmp(_string3.data, "?") == 0)
    {
        if (strcmp(_string2.data, "A") == 0)
        {
            int result = AllNodes->countAttributes(_string1);
            cout << _string1.data << "," << _string2.data << "," << _string3.data << " == " << result << "\n";
        }
        else if (strcmp(_string2.data, "S") == 0)
        {
            int result = AllNodes->countSelectors(_string1);
            cout << _string1.data << "," << _string2.data << "," << _string3.data << " == " << result << "\n";
        }
        else return;
    }
    else if(strcmp(_string2.data,"E") == 0)
    {
        Section* section = AllNodes->getLastSelector(_string3, _string1);
        if (section == nullptr) return;
        if (section->findAttributeByName(_string3) == nullptr) return;
        MyString result = section->findAttributeByName(_string3)->value;
        if (result.length() == 0) return;
        cout << _string1.data << "," << _string2.data << "," << _string3.data << " == " << result.data << "\n";
    }
}

void exeISS(int _int1, MyString _string2, MyString _string3, DoublyLinkedList* AllNodes)
{
    Section* section = AllNodes->findSection(_int1);
    if (section != nullptr)
    {
        if (strcmp(_string3.data, "*") == 0)
        {
            NodeSections* _node = AllNodes->findNodeWithSection(_int1);
            if (_node == nullptr) return;
            AllNodes->removeSection((_int1));
            if (_node->countTakenSections() == 0) AllNodes->removeNode(_int1);
            cout << _int1 << "," << _string2.data << "," << _string3.data << " == " << "deleted\n";
        }
        else if (strcmp(_string3.data, "?") == 0)
        {
            if (strcmp(_string2.data, "S") == 0) 
            {
                int result = 0;
                if (section->selectorsHead == nullptr) result=0;
                else result = section->countSelectors();
                
                cout << _int1 << "," << _string2.data << "," << _string3.data << " == " << result << "\n";
            }
            else if (strcmp(_string2.data, "A") == 0)
            {
                if (section->attributesHead == nullptr) return;
                int result = section->countAttributes();
                cout << _int1 << "," << _string2.data << "," << _string3.data << " == " << result << "\n";
            }
        }
        else if (strcmp(_string2.data, "D") == 0)
        {
            Attribute* tmp = section->findAttributeByName(_string3);
            if (tmp != nullptr)
                section->removeAttribute(tmp->index);
            else return;
            NodeSections* _node = AllNodes->findNodeWithSection(_int1);
            if (section->attributesHead==nullptr) AllNodes->removeSection(_int1);
            if (_node->countTakenSections() == 0) AllNodes->removeNode(_int1);
            cout << _int1 << "," << _string2.data << "," << _string3.data << " == " << "deleted\n";
        }
        else 
        {
            if (section == nullptr) return;
            Attribute* attribute = section->findAttributeByName(_string3);
            if (attribute == nullptr) return;
            attribute->value.removeExtremeWhitespace();
            cout << _int1 << "," << _string2.data << "," << _string3.data << " == " << attribute->value.data<<"\n";
        }
    }
}

int stoi(MyString _string)
{
    _string.removeExtremeWhitespace();
    int length = _string.length();
    int result = 0;
    int pow = 1;
    for (int i = length - 1; i >= 0; i--)
    {
        result += (_string.data[i] - '0') * pow;
        pow *= 10;
    }
    return result;
}

bool isNumber(MyString _string)
{
    _string.removeExtremeWhitespace();
    for (int i = 0; i < _string.length(); i++)
    {
        if ((_string.data[i] < '0' || _string.data[i] > '9') && _string.data[i] != '\0')
        {
            return false;
        }
    }
    return true;
}

bool commands(DoublyLinkedList* AllNodes)
{
    MyString _string = MyString();
    MyString _string1 = MyString();
    MyString _string2 = MyString();
    MyString _string3 = MyString();
    bool running = true;
    bool commandToExecute = true;
    int indexOfSecOrAtt = 0;
    bool eofEncountered = false;
    while (running)
    {
        _string = MyString();
        _string1 = MyString();
        _string2 = MyString();
        _string3 = MyString();
        commandToExecute = true;
        char _char = '0';
        while ((_char = getchar())!=EOF) 
        {
            if (_char == '\0' || _char=='\n') break;
            _string.addChar(_char);
        }
        if (feof(stdin)) 
        {
            eofEncountered = true;
            break; 
        }
       _string.removeExtremeWhitespace();
        
       if (_string.length()==0)
       {
           commandToExecute = false;
           continue;
       }
       else if (strcmp(_string.data, "?") == 0)
        {
            int count = 0;
            NodeSections* tmp = AllNodes->head;
            if (tmp == nullptr) return true;
            while(tmp!=nullptr)
            {
                count += tmp->countTakenSections();
                tmp = tmp -> next;
            }
            cout << "? == "<<count<< "\n";
            commandToExecute = false;
        }
       else if (strcmp(_string.data, "****") == 0)
       {
           running = false;
           commandToExecute = false;
           break;
       }
       else 
       {
            ParseString(_string, _string1, _string2, _string3);
       }
            
       if (commandToExecute) 
       {
           if (isNumber(_string1))
           {
               if (isNumber(_string3)) 
               {
                   int _int1 = stoi(_string1);
                   int _int3 = stoi(_string3);
                   exeISI(_int1, _string2, _int3, AllNodes);
               }
               else
               {
                   int _int1 = stoi(_string1);
                   exeISS(_int1, _string2, _string3, AllNodes);
               }
           }
           else if (!isNumber(_string1))
           {
               exeSSS(_string1, _string2, _string3, AllNodes);
           }
       }
    }
    if (eofEncountered) return false;
    else return true;
}

int main()
{
    DoublyLinkedList* AllNodes = new DoublyLinkedList();
    NodeSections* Node = new NodeSections();
    char _readChar = '\0';
    MyString _inputString = MyString();
    NodeSections* _freeNode = new NodeSections();
    Attribute* _attribute = new Attribute();
    Selector* _selector = new Selector();
    Section* _freeSection = new Section();
    bool eofEncountered = false;

    while (true)
    {
        Node = new NodeSections();
        AllNodes->appendTail(Node);
        while (AllNodes->isThereFreeSection()) 
        {
            _freeNode = AllNodes->findFreeNode();
            while (_freeNode->countTakenSections() <= CONST_T)
            {
                _freeSection = _freeNode->findFreeSection();
                if (_freeSection == nullptr) break;
                _inputString = MyString();
                while ((_readChar = getchar()))
                {
                    if (_readChar == '\n') continue;
                    if (_readChar == '?')
                    {
                        while (getchar() != '\n') { ; };
                        if (commands(AllNodes) == false) 
                        {
                            eofEncountered = true;
                            break;
                        }
                        else
                        {
                            eofEncountered = false;
                            break;
                        }
                    }
                    else if (_readChar == '{')
                    {        
                        _inputString.removeExtremeWhitespace();
                        if (_inputString.length() == 0) continue;
                        _selector->name = _inputString;
                        _freeSection->appendSelector(*_selector);
                        _selector = new Selector();
                        _inputString = MyString();
                        break;
                    }
                    else if (_readChar == ',')
                    {
                        _inputString.removeExtremeWhitespace();
                        if (_inputString.length() == 0) continue;
                        _selector->name = _inputString;
                        _freeSection->appendSelector(*_selector);
                        _selector = new Selector();
                        _inputString = MyString();
                    }
                    else _inputString.addChar(_readChar);

                    if (feof(stdin)) 
                    {
                        eofEncountered = true;
                        break;
                    }
                }
                if (eofEncountered) break;
                _inputString = MyString();
                bool alreadyAppended = false;
                while (_readChar = getchar())
                {
                    if (_readChar == '\n') continue;
                    else if (_readChar == '}')
                    {
                        if (!alreadyAppended) 
                        {
                            _inputString.removeExtremeWhitespace();
                            _attribute->value = _inputString;
                            _freeSection->appendAttribute(*_attribute);
                        }
                        _inputString = MyString();
                        _attribute = new Attribute();
                        break;
                    }
                    alreadyAppended = false;
                    if (_readChar == ':')
                    {
                        _inputString.removeExtremeWhitespace();
                        _attribute->property = _inputString;
                        _inputString = MyString();
                    }
                    else if (_readChar == ';')
                    {
                        _inputString.removeExtremeWhitespace();
                        _attribute->value = _inputString;
                        _freeSection->appendAttribute(*_attribute);
                        _inputString = MyString();
                        _attribute = new Attribute();
                        alreadyAppended = true; 
                    }
                    else  _inputString.addChar(_readChar);

                    if (feof(stdin)) 
                    {
                        eofEncountered = true;
                        break;
                    }
                }
                if (eofEncountered) break; 
            }
            if (eofEncountered) break; 
        }
        if (eofEncountered) break; 
    }
    return 0;
}