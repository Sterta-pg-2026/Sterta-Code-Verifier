#define _CRT_SECURE_NO_WARNINGS
#include "datastructure.h"
#include <malloc.h>
#include <iostream>
const int MAX_SELECTORS = 100;

void emptyArray(int* _array)
{
	for (int i = 0; i < 128; i++)
	{
		_array[i] = -1;
	}
}

Attribute::Attribute()
{
	index = 0;
	property = MyString();
	value = MyString();
	next = nullptr;
}

Attribute::Attribute(const Attribute& _attribute)
{
	index = _attribute.index;
	property = _attribute.property;
	value = _attribute.value;
	next = nullptr;
	if (_attribute.next != nullptr)
	{
		next = new Attribute(*_attribute.next);
	}
}

Attribute::~Attribute()
{
	delete next;
}

Selector::Selector()
{
	index = 0;
	name = MyString();
	next = nullptr;
}

Selector::Selector(const Selector& _selector)
{
	index = _selector.index;
	name = _selector.name;
	next = nullptr;
	if (_selector.next != nullptr) 
	{
		next = new Selector(*_selector.next);
	}
}

MyString::MyString()
{
	size = 0;
	capacity = 16;
	data = new char[capacity];
	data[0] = '\0';
}

MyString::MyString(const char* str) 
{
	size = 0;
	capacity = (int)strlen(str) + 1;
	data = new char[capacity];
	data[0] = '\0';
	for (int i = 0; i < capacity; i++) 
	{
		if (str[i] == '\0') {
			break;
		}

		addChar(str[i]);
	}
}

void MyString::addChar(char c)
{
	if ((int)c < 32) return;
	if (size + 1 >= capacity) 
	{
		resize(capacity * 2);
	}
	data[size] = c;
	size++;
	data[size] = '\0';
}

void MyString::resize(int new_capacity)
{
	int tmp = 0;
	if (size > new_capacity - 1) tmp = new_capacity;
	else tmp = size;
	char* new_data = new char[new_capacity];
	for (int i = 0; i < tmp; i++) 
	{
		new_data[i] = data[i];
	}
	data = new_data;
	capacity = new_capacity;
	data[size] = '\0';
}

int MyString::length()
{
	return size;
}

void MyString::removeExtremeWhitespace() 
{
	if (data == nullptr) 
	{
		size = 0;
		return;
	}

	int i = 0;
	while (i < size && isspace(data[i])) 
	{
		i++;
	}

	int j = size - 1;
	while (j >= i && isspace(data[j])) 
	{
		j--;
	}

	if (i == 0 && j == size - 1) 
	{
		return;
	}
	size = j - i + 1;
	memmove(data, data + i, size * sizeof(char));
	if (size < capacity / 4) 
	{
		resize(capacity / 2);
	}
	data[size] = '\0';
}

char MyString::operator[](int index) const 
{
	return data[index];
}

char& MyString::operator[](int index) 
{
	return data[index];
}

std::ostream& operator<<(std::ostream& os, const MyString& str)
{
	for (int i = 0; i < str.size; i++) 
	{
		os << str.data[i];
	}
	return os;
}

DoublyLinkedList::DoublyLinkedList()
{
	numberOfNodes = 0;
	head = nullptr;
	tail = nullptr;
}

DoublyLinkedList::~DoublyLinkedList()
{
	NodeSections* tmpPtr = head;
	while (tmpPtr != nullptr)
	{
		head = head->next;
		delete tmpPtr;
		tmpPtr = head;
	}
}

void DoublyLinkedList::appendTail(NodeSections* _node)
{
	if (head == nullptr && tail == nullptr)
	{
		_node->index = 0;
		head = _node;
		tail = _node;
	}
	else
	{
		NodeSections* tmpTail = tail;
		tail = _node;
		tmpTail->next = tail;
		tail->prev = tmpTail;
		tail->index = tmpTail->index + 1;
	}
	numberOfNodes++;
}

NodeSections* DoublyLinkedList::findNode(int nth)
{
	NodeSections* tmpPtr = head;
	if (tmpPtr == nullptr) return nullptr;
	int k = 1;
	while (tmpPtr != nullptr)
	{
		if (k == nth) return tmpPtr;
		tmpPtr = tmpPtr->next;
	}
	return tmpPtr;
}

NodeSections::NodeSections()
{
	index = 0;
	next = nullptr;
	prev = nullptr;
	for (int i = 0; i < CONST_T; i++)
	{
		sections[i].index = i;
	}
}

NodeSections::~NodeSections()
{
	for (int i = 0; i < CONST_T; i++)
	{
		if (sections[i].selectorsHead != nullptr)
		{
			delete sections[i].selectorsHead;
			sections[i].selectorsHead = nullptr;
		}
		if (sections[i].attributesHead != nullptr)
		{
			delete sections[i].attributesHead;
			sections[i].attributesHead = nullptr;
		}
	}
}

Section::Section()
{
	index = 0;
	numberOfSelectors = 0;
	numberOfAttributes = 0;
	selectorsHead = nullptr;
	attributesHead = nullptr;
}

Section::~Section()
{
	Attribute* currentAttribute = attributesHead;
	while (currentAttribute != nullptr)
	{
		Attribute* tmp = currentAttribute->next;
		delete currentAttribute;
		currentAttribute = tmp;
	}

	Selector* currentSelector = selectorsHead;
	while (currentSelector != nullptr)
	{
		Selector* tmp = currentSelector->next;
		delete currentSelector;
		currentSelector = tmp;
	}
}

void Section::removeAttribute(int _index, bool calledByDupFunc)
{
	Attribute* currentAttribute = attributesHead;
	Attribute* previousAttribute = nullptr;

	while (currentAttribute != nullptr && currentAttribute->index != _index) 
	{
		previousAttribute = currentAttribute;
		currentAttribute = currentAttribute->next;
	}
	if (currentAttribute != nullptr) 
	{
		if (previousAttribute == nullptr) 
		{
			attributesHead = currentAttribute->next;
		}
		else 
		{
			previousAttribute->next = currentAttribute->next;
		}
	}
	numberOfAttributes--;
	if (!calledByDupFunc)
	{
		Attribute* tmp = attributesHead;
		int i = 0;
		while (tmp != nullptr)
		{
			tmp->index = i;
			i++;
			tmp = tmp->next;
		}
	}
}

void Section::appendAttribute(Attribute _attribute)
{
	Attribute* newAttribute = new Attribute(_attribute);
	newAttribute->property.removeExtremeWhitespace();
	newAttribute->value.removeExtremeWhitespace();
	newAttribute->index = numberOfAttributes;

	if (attributesHead == nullptr)
	{
		attributesHead = newAttribute;
	}
	else
	{
		Attribute* tmpAttribute = attributesHead;
		while (tmpAttribute->next != nullptr)
		{
			tmpAttribute = tmpAttribute->next;
		}
		tmpAttribute->next = newAttribute;
	}
	numberOfAttributes++;
	this->removeDuplicateAttributes();
}

void Section::appendSelector(Selector _selector)
{
	Selector* newSelector = new Selector(_selector);
	newSelector->index = numberOfSelectors;
	newSelector->name.removeExtremeWhitespace();

	if (selectorsHead == nullptr)
	{
		selectorsHead = newSelector;
	}
	else
	{
		Selector* tmpSelector = selectorsHead;
		while (tmpSelector->next != nullptr)
		{
			tmpSelector = tmpSelector->next;
		}
		tmpSelector->next = newSelector;
	}
	numberOfSelectors++;
}

Selector* Section::findSelector(int nth)
{
	int k = 1;
	Selector* tmp = selectorsHead;
	while (tmp != nullptr)
	{
		if (nth == k) return tmp;
		k++;
		tmp = tmp->next;
	}
	return nullptr;

}

int DoublyLinkedList::countAttributes(MyString _string)
{
	NodeSections* firstNode = this->head;
	int result = 0;
	while(firstNode!=nullptr)
	{
		for (int j = 0; j < CONST_T; j++)
		{
			if ((firstNode->sections[j].isThereAttribute(_string)) == true) result++;
		}
		firstNode = firstNode->next;
	}
	return result;
}

bool Section::isThereAttribute(MyString _string)
{
	if (attributesHead == nullptr) return false;
	Attribute* tmp = attributesHead;

	while (tmp!= nullptr)
	{
		if (strcmp(_string.data, tmp->property.data) == 0) return true;
		tmp = tmp->next;
	}
	 return false;
}

bool Section::isThereSelector(MyString _string)
{
	if (selectorsHead == nullptr) return false;
	Selector* tmp = selectorsHead;

	while (tmp != nullptr)
	{
		if (strcmp(_string.data, tmp->name.data) == 0) return true;
		tmp = tmp->next;
	}
	return false;
}

int Section::countAttributes()
{
	int result = 0;
	Attribute* tmp = attributesHead;
	if (attributesHead == nullptr) return 0;

	while (tmp != nullptr)
	{
		if(tmp->property.length()>0) result++;
		tmp = tmp->next;
	}
	return result;
}

int DoublyLinkedList::countSelectors(MyString _string)
{
	NodeSections* firstNode = this->head;	
	int result = 0;

	while (firstNode!= nullptr)
	{
		for (int j = 0; j < CONST_T; j++)
		{
			result += firstNode->sections[j].countSelectors(_string);
		}
		firstNode = firstNode->next;
	}
	return result;
}

int Section::countSelectors(MyString _string)
{
	int result = 0;
	if (selectorsHead == nullptr) return 0;
	Selector* tmp = selectorsHead;

	while (tmp != nullptr)
	{
		if (strcmp(_string.data, tmp->name.data) == 0)
		{
			result++;
			break;
		}
		tmp = tmp->next;
	}
	return result;
}

int Section::countSelectors()
{
	int result = 0;
	if (selectorsHead == nullptr) return 0;
	Selector* tmp = selectorsHead;
	char seenSelectors[MAX_SELECTORS][100] = {};
	int numSeenSelectors = 0;

	while (tmp != nullptr)
	{
		bool isUnique = true;
		for (int i = 0; i < numSeenSelectors; i++) 
		{
			if (strcmp(tmp->name.data, seenSelectors[i]) == 0) 
			{
				isUnique = false;
				break;
			}
		}
		if (isUnique && strlen(tmp->name.data) > 0) 
		{
			result++;
			if (numSeenSelectors < MAX_SELECTORS) 
			{
				strcpy(seenSelectors[numSeenSelectors], tmp->name.data);
				numSeenSelectors++;
			}
		}
		tmp = tmp->next;
	}
	return result;
}

Section* DoublyLinkedList::getLastSelector(MyString attribute, MyString selector) {
	NodeSections* node = head;
	Section* result = nullptr;

	while (node != nullptr)
	{
		for (int i = 0; i < CONST_T; i++)
		{
			if (node->sections[i].isThereSelector(selector) && node->sections[i].isThereAttribute(attribute))
			{
				result = &(node->sections[i]);
			}
		}
		node = node->next;
	}
	return result;
}

MyString Section::valueOfProperty(MyString _string)
{ 
	MyString result = MyString();
	Attribute* tmp = attributesHead;

	while (tmp != nullptr) 
	{
		if (strcmp(tmp->property.data, _string.data)==0) return tmp->property;
		tmp = tmp->next;
	}
	return result;

}

Section* DoublyLinkedList::findFreeSection()
{
	NodeSections* firstNode = this->head;	

	while (firstNode != nullptr)
	{
		if (firstNode->countTakenSections() == CONST_T) continue;
		else 
		{
			for (int j = 0; j < CONST_T; j++)
			{
				if (firstNode->sections[j].attributesHead == nullptr) return &(firstNode->sections[j]);					
			}			
		}
		firstNode = firstNode->next;
	}
	return nullptr;
}

void DoublyLinkedList::removeSection(int nth)
{
	Section* section = findSection(nth);
	*(section) = Section();
}

Section* DoublyLinkedList::findSection(int nth)
{
	NodeSections* tmp = this->head;
	int k = 1;

	while (tmp != nullptr)
	{
		for (int i = 0; i < CONST_T; i++)
		{
			if (tmp->sections[i].attributesHead != nullptr || tmp->sections[i].selectorsHead!=nullptr)
			{
				if (k == nth) return &(tmp->sections[i]);
				k++;
			}

		}
		tmp = tmp->next;
	}
	return nullptr;
}

bool DoublyLinkedList::isThereFreeSection()
{
	NodeSections* firstNode = this->head;
	while(firstNode!=nullptr)
	{
		if ((firstNode->countTakenSections()) < CONST_T) return true;
		firstNode = firstNode->next;
	}
	return false;
}

NodeSections* DoublyLinkedList::findFreeNode()
{
	NodeSections* firstNode = this->head;
	while(firstNode!=nullptr)
	{
		if ((firstNode->countTakenSections()) < CONST_T) return firstNode;
		firstNode = firstNode->next;
	}
	return nullptr;
}

Section* NodeSections::findFreeSection()
{
	for (int i = 0; i < CONST_T; i++)
	{
		if (sections[i].attributesHead == nullptr) return &(sections[i]);
	}
	return nullptr;
}

int NodeSections::countTakenSections()
{
	int result = 0;
	for (int i = 0; i < CONST_T; i++)
	{
		if (sections[i].attributesHead != nullptr) { result++; };
	}
	return result;
}

Attribute* Section::findAttributeByName(MyString _string)
{
	Attribute* tmp = attributesHead;
	if (tmp == nullptr) return nullptr;
	Attribute* result = new Attribute();
	bool any = false;

	while(tmp!=nullptr)
	{
		if (strcmp(_string.data, tmp->property.data) == 0)
		{
			result = tmp;
			any = true;
		}
		tmp = tmp->next;
	}
	if (any) return result;
	else return nullptr;
}

void Section::removeDuplicateAttributes()
{
	int indexesToRemove[128] = { -1 };
	int i = 0;
	int counter = 0;
	Attribute* pIterator = attributesHead;
	Attribute* pSecIterator = attributesHead;

	while (pIterator != nullptr)
	{
		emptyArray(indexesToRemove);
		pSecIterator = attributesHead;
		counter = 0;
		while (pSecIterator != nullptr)
		{
			if (strcmp(pIterator->property.data, pSecIterator->property.data) == 0)
			{
				indexesToRemove[counter] = pSecIterator->index;
				counter++;
			}
			pSecIterator = pSecIterator->next;
		}
		pIterator = pIterator->next;
		if (counter > 1) 
		{
			for (int i = 0; i < counter - 1; i++)
			{
				if (indexesToRemove[i] != -1) removeAttribute(indexesToRemove[i], true);
			}
		}
	}
	Attribute* tmp = attributesHead;
	i = 0;
	while (tmp != nullptr)
	{
		tmp->index = i;
		i++;
		tmp = tmp->next;
	}
}

void DoublyLinkedList::removeNode(int nth)
{
	NodeSections* _node = findNodeWithSection(nth);
	if (_node == nullptr) return;
	if (_node->prev == nullptr)
	{
		head = _node->next;
		if (_node->next != nullptr)
			_node->next->prev = nullptr;
	}
	else if (_node->next == nullptr)
	{
		_node->prev->next = nullptr;
	}
	else
	{
		_node->prev->next = _node->next;
		_node->next->prev = _node->prev;
	}
	NodeSections* tmp = _node->next;
	while (tmp != nullptr)
	{
		tmp->index = tmp->index - 1;
		tmp = tmp->next;
	}
	delete _node;
}

void NodeSections::updateIndexes()
{
	int i = 1;
	int j = 0;
	while (j < CONST_T)
	{
		if (sections[i].attributesHead != nullptr)
		{
			sections[i].index = i;
			i++;
		}
		j++;
	}
}

NodeSections* DoublyLinkedList::findNodeWithSection(int nth)
{
	NodeSections* tmp = this->head;
	int k = 1;
	while (tmp != nullptr)
	{
		for (int i = 0; i < CONST_T; i++)
		{
			if (tmp->sections[i].attributesHead != nullptr || tmp->sections[i].selectorsHead != nullptr)
			{
				if (k == nth) return tmp;
				k++;
			}
		}
		tmp = tmp->next;
	}
	return nullptr;
}








