#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <ostream>
const unsigned int CONST_T = 17;

class MyString
{
public:
    MyString();
    MyString(const char* str);
    void resize(int new_capacity);
    void addChar(char c);
    void removeExtremeWhitespace();
    char operator[](int index) const;
    char& operator[](int index);
    int length();
    int size;
    int capacity;
    char* data;
};

class Attribute
{
public:
    int index;
    MyString property;
    MyString value;
    Attribute* next;
    Attribute();
    Attribute(const Attribute& _attribute);
    ~Attribute();
};

class Selector
{
public:
    int index;
    MyString name;
    Selector* next;
    Selector();
    Selector(const Selector& _selector);
};

class Section
{
public:
    Section();
    ~Section();
    int index;
    int numberOfSelectors;
    int numberOfAttributes;
    Selector *selectorsHead;
    Attribute *attributesHead;
    void appendAttribute(Attribute _attribute);
    void appendSelector(Selector _selector);
    Selector *findSelector(int nth);
    MyString valueOfProperty(MyString _property);
    bool isThereAttribute(MyString _string);
    bool isThereSelector(MyString _string);
    void removeDuplicateAttributes();
    void removeAttribute(int _index, bool calledByDupFunc=false);
    Attribute* findAttributeByName(MyString _string);
    int countSelectors(MyString _string);
    int countSelectors();
    int countAttributes();
};

class NodeSections
{
public:
    NodeSections();
    ~NodeSections();
     int index;
    Section sections[CONST_T];
    NodeSections *next;
    NodeSections *prev;
    Section* findFreeSection();
    int countTakenSections();
    void removeSection(int _index);
    void addAttributeAppliedToAll(Attribute _attribute);
    void updateIndexes();
};

class DoublyLinkedList
{
public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    int numberOfNodes;
    NodeSections *head;
    NodeSections *tail;
    void appendTail(NodeSections* _node);
    NodeSections *findNode(int nth);
    int countAttributes(MyString _string);
    int countSelectors(MyString _string);
    Section* getLastSelector(MyString _selector, MyString _attribute);
    Section* findFreeSection();
    Section* findSection(int nth);
    bool isThereFreeSection();
    NodeSections* findFreeNode();
    void removeNode(int _index);
    void removeSection(int nth);
    NodeSections* findNodeWithSection(int nth);
};
