#include "section.h"
#include "char_operations.h"

using namespace std;

Section::Section()
	: aSelector(nullptr), aAttribute(nullptr){
}

Section::~Section() {
	delete aSelector;
	delete aAttribute;
}


bool Section::isEmpty() const {
	if (aAttribute == nullptr) return true;
	return false;
}

void Section::Clear() {
	aSelector = nullptr;
	aAttribute = nullptr;
}

void Section::AddSelector(char* aSelectorName) {
	// zaczep nowy selektor na poczatek listy jesli jest pusta
	if (aSelector == nullptr) {
		// stworz nowy selektor
		Selector* newSelector = new Selector;
		MoveString(&(newSelector->name), aSelectorName);
		newSelector->next = nullptr;
		aSelector = newSelector;
	}
	else {
		Selector* aCurr = aSelector;
		while (aCurr->next != nullptr) {
			// zobacz czy wystepuje juz taki sam selektor w tej sekcji
			if (strcmp(aCurr->name, aSelectorName) == 0) return;
			aCurr = aCurr->next;
		}
		if (strcmp(aCurr->name, aSelectorName) == 0) return;
		Selector* newSelector = new Selector;
		MoveString(&(newSelector->name), aSelectorName);
		newSelector->next = nullptr;
		aCurr->next = newSelector;
	}
}

void Section::AddAttribute(char* aAttributeName, char* aAttributeValue) {
	// zaczep atrybut na poczatek listy jesli jest pusta
	if (aAttribute == nullptr) {
		// swtorz nowy atrybut
		Attribute* newAttribute = new Attribute;
		MoveString(&(newAttribute->name), aAttributeName);
		MoveString(&(newAttribute->value), aAttributeValue);
		newAttribute->next = nullptr;
		aAttribute = newAttribute;
	}
	else {
		Attribute* aCurr = aAttribute;
		while (aCurr->next != nullptr) {
			// jesli istnieje juz taki atrybut, podmien jego wartosc na nowa
			if (strcmp(aCurr->name, aAttributeName) == 0) {
				MoveString(&(aCurr->value), aAttributeValue);
				return;
			}
			aCurr = aCurr->next;
		}
		if (strcmp(aCurr->name, aAttributeName) == 0) {
			MoveString(&(aCurr->value), aAttributeValue);
			return;
		}
		Attribute* newAttribute = new Attribute;
		MoveString(&(newAttribute->name), aAttributeName);
		MoveString(&(newAttribute->value), aAttributeValue);
		newAttribute->next = nullptr;
		aCurr->next = newAttribute;
	}
}

int Section::DeleteAttribute(char* aAttributeName) {
	// jeli nie ma adnej sekcji
	if (aAttribute == nullptr) return 0;
	// usun pierwszy segment jesli posiada szukana wartosc
	if (strcmp(aAttribute->name, aAttributeName) == 0) {
		// jeeli wlasnie usuwany atrybut jest jedynym atrybutem sekcji
		if (aAttribute->next == nullptr) return 2;

		Attribute* tmp = aAttribute;
		aAttribute = aAttribute->next;
		delete tmp;
		return 1;
	}
	// przeszukaj liste i usun element szukany
	Attribute* aCurr = aAttribute;
	while (aCurr->next != nullptr) {
		if (strcmp(aCurr->next->name, aAttributeName) == 0) {
			Attribute* tmp = aCurr->next;
			aCurr->next = aCurr->next->next;
			delete tmp;
			return 1;
		}
		aCurr = aCurr->next;
	}
	// jesni nie zlaleziono atrybutu
	return 0;

}

int Section::NumOfSelectors() const {
	int result = 0;
	if (aSelector == nullptr) return result;
	Selector* aCurr = aSelector;
	while (aCurr != nullptr) {
		result++;
		aCurr = aCurr->next;
	}
	return result;
}

int Section::NumOfAttributes() const {
	int result = 0;
	if (aAttribute == nullptr) return result;
	Attribute* aCurr = aAttribute;
	while (aCurr != nullptr) {
		result++;
		aCurr = aCurr->next;
	}
	return result;
}

char* Section::GetSelector(int aSelectorId) {
	if (aSelector == nullptr) return NULL;
	int aCurrSelectorId = 0;
	Selector* aCurr = aSelector;
	while (aCurr != nullptr) {
		aCurrSelectorId++;
		if (aCurrSelectorId == aSelectorId) {
			return aCurr->name;
		}
		aCurr = aCurr->next;
	}
	return NULL;
}

char* Section::GetValue(char* aAttributeName) {
	if (aAttribute == nullptr) return NULL;
	Attribute* aCurr = aAttribute;
	while (aCurr != nullptr) {
		if (strcmp(aCurr->name, aAttributeName) == 0) return aCurr->value;
		aCurr = aCurr->next;
	}
	return NULL;
}

bool Section::hasAttribute(char* aAttributeName) const {
	if (aAttribute == nullptr) return false;
	Attribute* aCurr = aAttribute;
	while (aCurr != nullptr) {
		if (strcmp(aCurr->name, aAttributeName) == 0) return true;
		aCurr = aCurr->next;
	}
	return false;
}

bool Section::hasSelector(char* aSelectorName) const {
	if (aSelector == nullptr) return false;
	Selector* aCurr = aSelector;
	while (aCurr != nullptr) {
		if (strcmp(aCurr->name, aSelectorName) == 0) return true;
		aCurr = aCurr->next;
	}
	return false;
}

bool Section::isGlobal() const {
	if (aSelector == nullptr && aAttribute != nullptr) return true;
	return false;
}

