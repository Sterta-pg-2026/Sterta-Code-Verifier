#include "procesor.h"
using namespace std;
// Procesor::

Procesor::Procesor()
	:aBlock(nullptr) {
}

int Procesor::CountSections() const {
	int result = 0;
	if (aBlock == nullptr) return result;
	Block* aHead = aBlock;
	while (aHead != nullptr) {
		result += SECTION_ARR_SIZE - aHead->aSpotsLeft;
		aHead = aHead->next;
	}
	return result;
}
int Procesor::CountElements(int aSectionId, char aMode) const {
	int aCurrSectionId = 0;
	if (aBlock == nullptr) return -1;
	Block* aHead = aBlock;
	while (aHead != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aHead->aSectionArr[i].isEmpty()) {
				aCurrSectionId++;
				if (aCurrSectionId == aSectionId) {
					switch (aMode) {
					case 'S':
						return aHead->aSectionArr[i].NumOfSelectors();
					case 'A':
						return aHead->aSectionArr[i].NumOfAttributes();
					default: 
						return -1;
					}
				}
			}
		}
		aHead = aHead->next;
	}
	return -1;
}

void Procesor::AddBlock() {
	Block* newBlock = new Block;
	newBlock->aSpotsLeft = SECTION_ARR_SIZE;
	newBlock->aNewSectionIndex = 0;
	newBlock->aSectionArr = new Section[SECTION_ARR_SIZE];
	newBlock->next = nullptr;

	if (aBlock == nullptr) {
		newBlock->prev = nullptr;
		aBlock = newBlock;
		return;
	}

	Block* aCurr = aBlock;
	while (aCurr->next != nullptr) aCurr = aCurr->next;
	aCurr->next = newBlock;
	newBlock->prev = aCurr;
}

void Procesor::AddSectionToBlock(Section& aSection) {
	if (aBlock == nullptr) AddBlock();
	Block* aCurrBlock = aBlock;
	while (aCurrBlock->next != nullptr) aCurrBlock = aCurrBlock->next;
	if (aCurrBlock->aNewSectionIndex == SECTION_ARR_SIZE) {
		AddBlock();
		aCurrBlock = aCurrBlock->next;
	}
	aCurrBlock->aSectionArr[aCurrBlock->aNewSectionIndex++] = move(aSection);
	aSection.Clear();
	aCurrBlock->aSpotsLeft--;
}

char* Procesor::GetSelector(int aSectionId, int aSelectorId) {
	if (aBlock == nullptr) return NULL;
	Block* aCurr = aBlock;
	int aCurrSectionId = 0;
	while (aCurr != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurr->aSectionArr[i].isEmpty()) {
				aCurrSectionId++;
				if (aCurrSectionId == aSectionId) {
					return aCurr->aSectionArr[i].GetSelector(aSelectorId);
				}
			}
		}
		aCurr = aCurr->next;
	}
	return NULL;
}

char* Procesor::GetValue(int aSectionId, char* aAttributeName) {
	if (aBlock == nullptr) return NULL;
	Block* aCurr = aBlock;
	int aCurrSectionId = 0;
	while (aCurr != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurr->aSectionArr[i].isEmpty()) {
				aCurrSectionId++;
				if (aCurrSectionId == aSectionId && aCurr->aSectionArr[i].hasAttribute(aAttributeName)) {
					return aCurr->aSectionArr[i].GetValue(aAttributeName);
				}
			}
		}
		aCurr = aCurr->next;
	}
	return NULL;
}

int Procesor::CountSpecAttributes(char* aAttributeName) const {
	if (aBlock == nullptr) return -1;
	Block* aCurr = aBlock;
	int result = 0;
	while (aCurr != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurr->aSectionArr[i].isEmpty() || aCurr->aSectionArr[i].isGlobal()) {
				if (aCurr->aSectionArr[i].hasAttribute(aAttributeName)) {
					result++;
				}
			}
		}
		aCurr = aCurr->next;
	}
	return result;
}

int Procesor::CountSpecSelectors(char* aSelectorsName) const {
	if (aBlock == nullptr) return -1;
	Block* aCurr = aBlock;
	int result = 0;
	while (aCurr != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurr->aSectionArr[i].isEmpty()) {
				if (aCurr->aSectionArr[i].hasSelector(aSelectorsName)) {
					result++;
				}
			}
		}
		aCurr = aCurr->next;
	}
	return result;
}

char* Procesor::GetLatestValueForSelector(char* aSelectorsName, char* aAttributeName) {
	if (aBlock == nullptr) return NULL;
	Block* aCurr = aBlock;
	while (aCurr->next != nullptr) aCurr = aCurr->next;
	while (aCurr != nullptr) {
		for (int i = SECTION_ARR_SIZE - 1; i >= 0; i--) {
			if (!aCurr->aSectionArr[i].isEmpty()) {
				if (aCurr->aSectionArr[i].hasAttribute(aAttributeName) &&
					(aCurr->aSectionArr[i].isGlobal() || aCurr->aSectionArr[i].hasSelector(aSelectorsName))) {
					return aCurr->aSectionArr[i].GetValue(aAttributeName);
				}
				
			}
		}
		aCurr = aCurr->prev;
	}
	return NULL;
}

int Procesor::DeleteAttributeFromSection(int aSectionId, char* aAttributeName) {
	if (aBlock == nullptr) return 0;
	Block* aCurr = aBlock;
	int aCurrSectionId = 0;
	while (aCurr != nullptr) {
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurr->aSectionArr[i].isEmpty()) {
				aCurrSectionId++;
				if (aCurrSectionId == aSectionId) {
					if (aCurr->aSectionArr[i].hasAttribute(aAttributeName)) {
						switch (aCurr->aSectionArr[i].DeleteAttribute(aAttributeName)) {
						case 0:
							return 0;
						case 1:
							return 1;
						case 2:
							return this->DeleteSectionFromBlock(aSectionId);
						}
					}
					else return 0;
				}
			}
		}
		aCurr = aCurr->next;
	}
	return 0;
}

int Procesor::DeleteSectionFromBlock(int aSectionId) {
	// jeeli nie ma adnych blokw 
	if (aBlock == nullptr) return 0;
	int aCurrSectionId = 0, aCurrBlockId = 0;
	Block* aCurrBlock = aBlock;
	while (aCurrBlock != nullptr) {
		aCurrBlockId++;
		for (int i = 0; i < SECTION_ARR_SIZE; i++) {
			if (!aCurrBlock->aSectionArr[i].isEmpty()) {
				aCurrSectionId++;
				if (aCurrSectionId == aSectionId) {
					aCurrBlock->aSectionArr[i].Clear();
					aCurrBlock->aSpotsLeft++;
					// blok do usuniecia - wyczyszczono ostatnia sekcje
					if (aCurrBlock->aSpotsLeft == SECTION_ARR_SIZE) {
						return DeleteBlock(aCurrBlockId);
					}
					return 1;
				}
			}
		}
		aCurrBlock = aCurrBlock->next;
	}
	// nie znaleziono sekcji o podanym id
	return 0;
}

int Procesor::DeleteBlock(int aBlockId) {
	if (aBlock == nullptr) return 0;
	int aCurrBlockId = 0;
	Block* aBlockToRemove = aBlock;
	while (aBlockToRemove != nullptr && (++aCurrBlockId != aBlockId)) aBlockToRemove = aBlockToRemove->next;
	if (aBlockToRemove == nullptr) return 0;
	if (aBlockToRemove->prev == nullptr) aBlock = aBlockToRemove->next;
	else aBlockToRemove->prev->next = aBlockToRemove->next;
	if (aBlockToRemove->next != nullptr) aBlockToRemove->next->prev = aBlockToRemove->prev;
	delete aBlockToRemove;
	return 1;
}


Procesor::~Procesor() {
	delete aBlock;
}