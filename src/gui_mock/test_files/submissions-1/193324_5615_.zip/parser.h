#pragma once
#include "procesor.h"
#include "section.h"
#include "char_operations.h"

enum CommandId {
	COUNT_SECTIONS,
	COUNT_SELECTORS,
	COUNT_ATTRS,
	GET_SELECTOR,
	GET_VALUE,
	COUNT_SPEC_ATTR,
	COUNT_SPEC_SELECTOR,
	GET_LATEST_VALUE_FOR_SELECTOR,
	DELETE_SECTION_FROM_BLOCK,
	DELETE_ATTR_FROM_SECTION
};

class Parser {
private:
	char* strArr[2];
	Procesor p;
	Section s;
	bool ReadSelectors(int c);
	bool ReadAttributes();
public:
	Parser();
	bool ReadSection(int c);
	void HandleCommand(char aMode);
	bool ReadCommand(int c);
	void ExecuteCommand(int aCmdId, int* numArr, char aMode);
	~Parser();
};