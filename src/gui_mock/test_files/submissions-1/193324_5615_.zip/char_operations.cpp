#include "char_operations.h"
#include <math.h>

using namespace std;

void MoveString(char** dest, char* location) {
	size_t aNewLen = strlen(location) + 1; // plus 1 dla znaku NULL
	*(dest) = new char[aNewLen];
	// aSelectorName MUSI by zakoczony znakiem NULL
	memcpy(*(dest), location, aNewLen);
}

void ReduceWhiteSpaces(char* strArr, int* charIndx ) {
	(*charIndx)--;
	while (strArr[*charIndx] < ' ' || strArr[*charIndx] > 126 || strArr[*charIndx] == ' ')
		(*charIndx)--;
}

bool isNum(char c) {
	if (c >= '0' && c <= '9') return true;
	return false;
}

int StrToInt(char* aString) {
	int result = 0;
	size_t lenOfString = strlen(aString);
	size_t power = lenOfString - 1;
	for (unsigned int i = 0; i < lenOfString; power--, i++)
		result += (aString[i] - '0') * (int)pow(10, power);
	return result;
}