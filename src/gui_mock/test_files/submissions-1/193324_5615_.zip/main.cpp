﻿#include "parser.h"

using namespace std;

int main() {
	int c;
	Parser p;
	bool inCommand = false, inSection = true;
	while ((c = getchar()) != EOF) {
		if (c <= ' ' || c == ',') continue;
		if (inSection) {
			if (!p.ReadSection(c)) {
				inSection = false;
				inCommand = true;
			}
		}
		else if (inCommand) {
			if (!p.ReadCommand(c)) {
				inSection = true;
				inCommand = false;
			}
		}
	}
	return 0;
}