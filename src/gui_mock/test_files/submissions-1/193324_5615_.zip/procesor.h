#pragma once
#include "section.h"

constexpr int SECTION_ARR_SIZE = 8;

struct Block {
	int aSpotsLeft;
	int aNewSectionIndex;
	Section* aSectionArr;
	Block* next;
	Block* prev;
};

class Procesor {
private:
	Block* aBlock;
public:
	Procesor();
	void AddBlock();
	void AddSectionToBlock(Section& aSection);
	int DeleteBlock(int aBlockId);
	int CountSections() const;
	int CountElements(int aSectionId, char aMode) const;
	char* GetSelector(int aSectionId, int aSelectorId);
	char* GetValue(int aSectionId, char* aAttributeName);
	int CountSpecAttributes(char* aAttributeName) const;
	int CountSpecSelectors(char* aSelectorsName) const;
	char* GetLatestValueForSelector(char* aSelectorsName, char* aAttributeName);
	int DeleteSectionFromBlock(int aSectionId);
	int DeleteAttributeFromSection(int aSectionId, char* aAttributeName);
	~Procesor();
};