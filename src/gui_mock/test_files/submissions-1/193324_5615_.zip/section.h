#pragma once
#include <iostream>

struct Selector {
	char* name;
	Selector* next;
};

struct Attribute {
	char* name;
	char* value;
	Attribute* next;
};

class Section {
private:
	Selector* aSelector;
	Attribute* aAttribute;
public:
	Section();
	bool isEmpty() const;
	bool isGlobal() const;
	bool hasAttribute(char* aAttributeName) const;
	bool hasSelector(char* aSelectorName) const;
	void Clear();
	void AddSelector(char* aSelectorName);
	void AddAttribute(char* aAttributeName, char* aAttributeValue);
	int DeleteAttribute(char* aAttributeName);
	int NumOfSelectors() const;
	int NumOfAttributes() const;
	char* GetSelector(int aSelectorId);
	char* GetValue(char* aAttributeName);
	~Section();
};