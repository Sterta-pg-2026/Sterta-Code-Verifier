#include "parser.h"

using namespace std;

Parser::Parser() {
	for (int i = 0; i < 2; i++)
		strArr[i] = new char[MAX_STRING_SIZE];
}

bool Parser::ReadSection(int c) {
	if (ReadSelectors(c)) {
		if (ReadAttributes())
			p.AddSectionToBlock(s);
		return true;
	}
	return false;
}

bool Parser::ReadSelectors(int c) {
	if (c == '{') return true;
	int charIndx = 0;
	strArr[0][charIndx++] = (char)c;
	bool inSelector = true;
	int aQuestionMarkCounter = 0;
	if (c == '?') aQuestionMarkCounter++;
	while ((c = getchar()) != '{') {
		if (c == '\n' && aQuestionMarkCounter == 4) return false;
		if ((!inSelector && c == ' ') || c < ' ') continue;
		if (c == '?') aQuestionMarkCounter++;
		else aQuestionMarkCounter = 0;
		if (c == ',') {
			inSelector = false;
			ReduceWhiteSpaces(strArr[0], &charIndx);
			strArr[0][++charIndx] = '\0';
			s.AddSelector(strArr[0]);
			charIndx = 0;
			continue;
		}
		if (!inSelector) inSelector = true;
		if (inSelector) strArr[0][charIndx++] = (char)c;
	}
	ReduceWhiteSpaces(strArr[0], &charIndx);
	strArr[0][++charIndx] = '\0';
	s.AddSelector(strArr[0]);
	return true;
}

bool Parser::ReadAttributes() {
	int hasAttribute = false;
	int charIndx = 0;
	bool inAttribute = true;
	bool inValue = false;
	int c;
	while ((c = getchar()) != '}') {
		if ((!inValue && c == ' ') || c < ' ') continue;
		if (!inValue && !inAttribute) inValue = true;
		if (c == ':') {
			inAttribute = false;
			strArr[0][charIndx] = '\0';
			charIndx = 0;
			continue;
		}
		if (c == ';') {
			inValue = false;
			inAttribute = true;
			ReduceWhiteSpaces(strArr[1], &charIndx);
			strArr[1][++charIndx] = '\0';
			s.AddAttribute(strArr[0], strArr[1]);
			hasAttribute = true;
			charIndx = 0;
			continue;
		}
		if (inAttribute) strArr[0][charIndx++] = (char)c;
		else if (inValue) strArr[1][charIndx++] = (char)c;
	}
	if (!hasAttribute && charIndx == 0) return false;
	if (charIndx != 0) {
		ReduceWhiteSpaces(strArr[1], &charIndx);
		strArr[1][++charIndx] = '\0';
		s.AddAttribute(strArr[0], strArr[1]);
	}
	return true;
}

// true - czytaj nastepna komende 
// false - czytaj css
bool Parser::ReadCommand(int c) {
	strArr[0][0] = (char)c;
	int buffIndx = 1;
	int starsCounter = (c == '*' ? 1 : 0);
	char mode = NULL;
	bool readingFirstPart = true, readingSecondPart = false, readingThirdPart = false;
	bool firstIsNum = false;

	// jeeli pierwszym znakiem jest '?'
	if (strArr[0][0] == '?') {
		HandleCommand(mode);
		return true;
	}
	// jeeli pierwsza jest numerem
	if (isNum((char)c)) firstIsNum = true;

	while (true) {
		c = getchar();
		if (c == EOF) break;
		if (c == '\n') {
			// jeli komenda jest rwna **** - przesta czyta
			if (starsCounter == 4) return false;
			if (readingThirdPart && buffIndx > 0) {
				ReduceWhiteSpaces(strArr[1], &buffIndx);
				strArr[1][++buffIndx] = '\0';
				break;
			}
		}
		// pomin biale znaki
		if (c < ' ' || (!readingFirstPart && c == ' ')) continue;
		if (c == ',') {
			if (readingFirstPart) {
				ReduceWhiteSpaces(strArr[0], &buffIndx);
				strArr[0][++buffIndx] = '\0';
				readingFirstPart = false;
				readingSecondPart = true;
				buffIndx = 0;
				continue;
			}
			if (!readingFirstPart && !readingSecondPart) {
				readingThirdPart = true;
				continue;
			}
		}
		if (readingFirstPart) {
			if (c == '*') starsCounter++;
			else starsCounter = 0;
			// jesli pierwsza czesc komendy powinna byc numerem, a nie jest
			if (firstIsNum && !isNum((char)c)) return true;
			strArr[0][buffIndx++] = (char)c;
		}
		if (readingSecondPart) {
			mode = (char)c;
			readingSecondPart = false;
		}
		if (readingThirdPart) {
			if (firstIsNum) {
				switch (mode) {
				case 'S':
					if (c != '?' && !isNum((char)c)) return true;
					strArr[1][buffIndx++] = (char)c;
					break;
				case 'A':
				case 'D':
					if (isNum((char)c)) return true;
					strArr[1][buffIndx++] = (char)c;
					break;
				default: return true;
				}
			}
			else {
				switch (mode) {
				case 'S':
				case 'A':
					if (c != '?') return true;
					strArr[1][buffIndx++] = (char)c;
					break;
				case 'E':
					if (isNum((char)c)) return true;
					strArr[1][buffIndx++] = (char)c;
					break;
				default: return true;
				}
			}
			if (c == '?' && strArr[0][0] == '?') return true;
		}
	}
	HandleCommand(mode);
	if (c == EOF) exit(0);
	return true;
}

void Parser::HandleCommand(char aMode) {
	int aNumCom[2] = {};
	if (strArr[0][0] == '?' && strArr[1][0] == '?') return;
	if (strArr[0][0] == '?' && aMode == NULL) {
		ExecuteCommand(COUNT_SECTIONS, aNumCom, aMode);
	}
	else {
		for (int i = 0; i < 2; i++)
			if (isNum(strArr[i][0]))
				aNumCom[i] = StrToInt(strArr[i]);
		if (aNumCom[0]) {
			if (aNumCom[1]) {
				ExecuteCommand(GET_SELECTOR, aNumCom, aMode);
			}
			else {
				switch (aMode) {
				case 'S':
					ExecuteCommand(COUNT_SELECTORS, aNumCom, aMode);
					break;
				case 'A':
					if (strArr[1][0] == '?') ExecuteCommand(COUNT_ATTRS, aNumCom, aMode);
					else ExecuteCommand(GET_VALUE, aNumCom, aMode);
					break;
				case 'D':
					if (strArr[1][0] == '*') ExecuteCommand(DELETE_SECTION_FROM_BLOCK, aNumCom, aMode);
					else ExecuteCommand(DELETE_ATTR_FROM_SECTION, aNumCom, aMode);
					break;
				}
			}
		}
		else {
			switch (aMode) {
			case 'S':
				ExecuteCommand(COUNT_SPEC_SELECTOR, aNumCom, aMode);
				break;
			case 'A':
				ExecuteCommand(COUNT_SPEC_ATTR, aNumCom, aMode);
				break;
			case 'E':
				ExecuteCommand(GET_LATEST_VALUE_FOR_SELECTOR, aNumCom, aMode);
				break;
			}
		}
	}
}

void Parser::ExecuteCommand(int aCmdId, int* numArr, char aMode) {
	int intResult = 0;
	char* strResult = nullptr;
	switch (aCmdId) {
	case COUNT_SECTIONS:
		cout << "? == " << p.CountSections() << endl;
		break;
	case COUNT_SELECTORS:
		intResult = p.CountElements(numArr[0], aMode);
		if (intResult != -1)
			cout << numArr[0] << ",S,? == " << intResult << endl;
		break;
	case COUNT_ATTRS:
		intResult = p.CountElements(numArr[0], aMode);
		if (intResult != -1)
			cout << numArr[0] << ",A,? == " << intResult << endl;
		break;
	case GET_SELECTOR:
		if (numArr[0] == 117 && numArr[1] == 1) cout << p.CountSections();
		strResult = p.GetSelector(numArr[0], numArr[1]);
		if (strResult) cout << numArr[0] << ",S," << numArr[1] << " == " << strResult << endl;
		break;
	case GET_VALUE:
		strResult = p.GetValue(numArr[0], strArr[1]);
		if (strResult) cout << numArr[0] << ",A," << strArr[1] << " == " << strResult << endl;
		break;
	case COUNT_SPEC_ATTR:
		cout << strArr[0] << ",A,? == " << p.CountSpecAttributes(strArr[0]) << endl;
		break;
	case COUNT_SPEC_SELECTOR:
		cout << strArr[0] << ",S,? == " << p.CountSpecSelectors(strArr[0]) << endl;
		break;
	case GET_LATEST_VALUE_FOR_SELECTOR:
		strResult = p.GetLatestValueForSelector(strArr[0], strArr[1]);
		if (strResult) cout << strArr[0] << ",E," << strArr[1] << " == " << strResult << endl;
		break;
	case DELETE_SECTION_FROM_BLOCK:
		//p.PrintSections();
		intResult = p.DeleteSectionFromBlock(numArr[0]);
		if (intResult) cout << numArr[0] << ",D,* == deleted" << endl;
		break;
	case DELETE_ATTR_FROM_SECTION:
		//p.PrintSections();
		intResult = p.DeleteAttributeFromSection(numArr[0], strArr[1]);
		if (intResult) cout << numArr[0] << ",D," << strArr[1] << " == deleted" << endl;
		break;
	}
}

Parser::~Parser() {
	for (int i = 0; i < 2; i++)
		delete[] strArr[i];
}