#pragma once
#include <iostream>
constexpr int MAX_STRING_SIZE = 256;

// przenies char* do char* w strukturze (listy selektorow i atrybutow)
void MoveString(char** dest, char* location);
void ReduceWhiteSpaces(char* strArr, int* charIndx);
bool isNum(char c);
int StrToInt(char* aString);