#pragma once
#define  _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "mystring.h"

using namespace std;

MyString::MyString()
{
	s_data = nullptr;
	size = 0;
}

MyString::MyString(const char* input)
{
	//delete[] s_data;
	size = strlen(input);
	s_data = new char[size + 1];

	strcpy(s_data, input);
}


MyString::~MyString() {
	
}

char* MyString::getSData() const
{
	return s_data;
}

size_t MyString::getSize()
{
	return size;
}

void MyString::TextOut()
{
	char* counter = s_data;
	for (int i = 0; i < size; i++)
	{
		cout << *counter;
		counter++;
	}

}

MyString MyString::ExtractString(int start, int end)
{
	size_t new_size = end - start+1;
	char* n_data = new char[new_size+1];
	char* tmp = s_data + start;
	
	for (int i = 0; i < new_size; i++)
	{
		n_data[i] = tmp[i];
	}
	n_data[new_size] = '\0';
	MyString extracted(n_data);

	return extracted;
}

MyString& MyString::operator=(const MyString& right)
{
	if (this == &right)
		return *this;
	else
	{
		delete[] s_data;
		size = right.size;
		s_data = new char[size + 1];
		strcpy(s_data, right.s_data);
		return *this;
	}
}

MyString& MyString::operator=(const char* right)
{
	if (s_data == right)
		return *this;
	else
	{
		delete[] s_data;
		size = strlen(right);
		s_data = new char[size + 1];
		strcpy(s_data, right);
		return *this;
	}
}

MyString& MyString::operator+=(const MyString& right)
{
	char* tmp = new char[size + 1];
	strcpy(tmp, s_data);
	delete[] s_data;
	size += right.size;
	s_data = new char[size + 1];
	strcpy(s_data, tmp);
	strcat(s_data, right.s_data);
	delete[] tmp;
	return *this;

}

MyString& MyString::operator+=(const char* add)
{
	if (size)
	{
		char* tmp = new char[size + 1];
		strcpy(tmp, s_data);
		delete[] s_data;
		size += strlen(add);
		s_data = new char[size + 1];
		strcpy(s_data, tmp);
		strcat(s_data, add);
		delete[] tmp;
	}
	else
	{
		size = strlen(add);
		s_data = new char[size + 1];
		strcpy(s_data, add);
	}
	
	return *this;
}

MyString& MyString::operator+=(char* add)
{
	if (size)
	{
		char* tmp = new char[size + 1];
		strcpy(tmp, s_data);
		delete[] s_data;
		size += strlen(add);
		s_data = new char[size + 1];
		strcpy(s_data, tmp);
		strcat(s_data, add);
		delete[] tmp;
	}
	else
	{
		size = strlen(add);
		s_data = new char[size + 1];
		strcpy(s_data, add);
	}

	return *this;
}

bool MyString::operator==(MyString right)
{
	if (size != right.getSize())
		return false;
	for (int i = 0; i < size; i++)
	{
		if (s_data[i] != right.s_data[i])
			return false;
	}
	return true;
}

char MyString::operator[](int index)
{
	char* wanted = s_data + index;
	return *wanted;
}



ostream& operator<<(ostream& os, const MyString& str)
{
	os << str.getSData();
	return os;
}

