#pragma once
#include <iostream>
#include "node.h"
#include "mystring.h"

struct Block 
{
	Node* selector_list;
	Node* attribute_list;
};

struct Selector
{
	MyString selector;
};

struct Attribute
{
	MyString name;
	MyString value;
};
