#include <iostream>
#include "dnode.h"
#include "mystring.h"

using namespace std;


DNode::DNode() 
{
	counter = 0;
	next = nullptr;
	previous = nullptr;
}

DNode::DNode(Block data)
{
	this->data[0] = data;
	this->counter=1;
	next = nullptr;
	previous = nullptr;
}
void PrintList(DNode* firstNode)
{
	DNode* tmp = firstNode;
	while (tmp != nullptr)
	{
		for (int i = 0; i < tmp->counter; i++)
		{
			PrintList(tmp->data[i].selector_list);
			PrintList(tmp->data[i].attribute_list);
		}
		tmp = tmp->next;
	}
}
int GetListLenght(DNode* firstNode)
{
	int count = 0;
	DNode* tmp = firstNode;
	while (tmp != nullptr)
	{
		count++;
		tmp = tmp->next;
	}
	return count;
}

DNode* GetFirst(DNode* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	return firstNode;
}

DNode* GetLast(DNode* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	DNode* tmp = firstNode;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
	}
	return tmp;
}

DNode* AddFirst(DNode* firstNode, DNode* newNode) 
{
	newNode->previous = nullptr;
	newNode->next = firstNode;
	if (firstNode != nullptr) {
		firstNode->previous = newNode;
	}
	return newNode;
}

DNode* AddLast(DNode* firstNode, DNode* newNode) 
{
	DNode* last = GetLast(firstNode);
	newNode->previous = last;
	if (last == nullptr) {
		return newNode;
	}
	last->next = newNode;
	return firstNode;
}

