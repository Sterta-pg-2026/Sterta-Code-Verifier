#pragma once
#include <iostream>
#include <cstring>

using namespace std;

class MyString
{
public:
	char* s_data;
	size_t size;

	MyString();
	MyString(const char* input);
	~MyString();

	char* getSData() const;
	size_t getSize();
	void TextOut();
	MyString ExtractString(int start, int end);
	MyString& operator=(const MyString& right);
	MyString& operator=(const char* equal);
	MyString& operator+=(const MyString& right);
	MyString& operator+=(const char* add);
	MyString& operator+=(char* add);
	bool operator==(MyString right);
	char operator[](int index);
	
};
ostream& operator<<(ostream& os, const MyString& str);