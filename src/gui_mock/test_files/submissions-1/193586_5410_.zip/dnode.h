#pragma once
#include <iostream>
#include "block.h"
#define T 8
using namespace std;

class DNode
{
public:
	Block data[T];
	DNode* previous;
	DNode* next;
	int counter;

	DNode();
	DNode(Block data);
};

void PrintList(DNode* firstNode);
int GetListLenght(DNode* firstNode);
DNode* GetFirst(DNode* firstNode);
DNode* GetLast(DNode* firstNode);
DNode* AddFirst(DNode* firstNode, DNode* newNode);
DNode* AddLast(DNode* firstNode, DNode* newNode);
