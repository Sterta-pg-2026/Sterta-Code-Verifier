#pragma once
#include <iostream>
#include "mystring.h"

using namespace std;


class Node
{
public:
	MyString data;
	MyString value;
	Node* next;

	Node();
	Node(MyString data);
	Node(MyString data, MyString value);
};


void PrintList(Node* firstNode);
int GetListLenght(Node* firstNode);
Node* GetFirst(Node* firstNode);
Node* GetLast(Node* firstNode);
Node* AddFirst(Node* firstNode, Node* newNode);
Node* AddLast(Node* firstNode, Node* newNode);
Node* RemoveFirst(Node* firstNode);
Node* RemoveNode(Node* firstNode, Node* nodeToRemove);
Node* RemoveLast(Node* firstNode);
Node* FindNode(Node* firstNode, MyString dataPattern, int size);
Node* FindNodeByName(Node* firstNode, MyString dataPattern);
Node* FindNodeByIndex(Node* firstNode, int index);

