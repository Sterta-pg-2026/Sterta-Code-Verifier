#include <iostream>
#include "node.h"
#include "mystring.h"

using namespace std;


Node::Node() {
	data = "";
	next = nullptr;
}

Node::Node(MyString data)
{
	this->data = data;
}

Node::Node(MyString data, MyString value)
{
	this->data = data;
	this->value = value;
}
void PrintList(Node* firstNode)
{
	Node* tmp = firstNode;
	while (tmp != nullptr)
	{
		cout << tmp->data << endl;
		tmp = tmp->next;
	}
}

int GetListLenght(Node* firstNode)
{
	int count = 0;
	Node* tmp = firstNode;
	while (tmp != nullptr)
	{
		count=count+1;
		tmp = tmp->next;
	}
	return count;
}

Node* GetFirst(Node* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	return firstNode;
}

Node* GetLast(Node* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	Node* tmp = firstNode;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
	}
	return tmp;
}

Node* AddFirst(Node* firstNode, Node* newNode) {
	newNode->next = firstNode;
	return newNode;
}

Node* AddLast(Node* firstNode, Node* newNode) {
	newNode->next = nullptr;
	if (firstNode == nullptr) {
		return newNode;
	}
	Node* tmp = firstNode;
	while (tmp->next != nullptr) {
		tmp = tmp->next;
	}
	tmp->next = newNode;
	return firstNode;
}

Node* RemoveFirst(Node* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	delete firstNode;
	return firstNode->next;
}

Node* RemoveNode(Node* firstNode, Node* nodeToRemove)
{
	if (nodeToRemove == nullptr)
	{
		return firstNode;
	}

	if (nodeToRemove == firstNode)
	{
		Node* newFirst = nodeToRemove->next;
		delete nodeToRemove;
		nodeToRemove = nullptr;
		return newFirst;
	}

	Node* currentNode = firstNode;
	Node* prevNode = nullptr;

	while (currentNode != nullptr)
	{
		if (currentNode == nodeToRemove)
		{
			prevNode->next = currentNode->next;
			delete currentNode;
			currentNode = nullptr;
			break;
		}

		prevNode = currentNode;
		currentNode = currentNode->next;
	}

	return firstNode;
}

Node* RemoveLast(Node* firstNode) {
	if (firstNode == nullptr) {
		return nullptr;
	}
	if (firstNode->next == nullptr) {
		return nullptr;
	}
	Node* tmp = firstNode;
	while (tmp->next->next != nullptr) {
		tmp = tmp->next;
	}
	tmp->next = nullptr;
	return firstNode;
}

Node* FindNode(Node* firstNode, MyString dataPattern, int size)
{
	Node* tmp = firstNode;
	while (tmp != nullptr)
	{
		MyString extracted = tmp->data.ExtractString(0, size - 1);
		if (size == 0 && tmp->data == dataPattern)
			return tmp;
		else if (size > 0 && extracted == dataPattern)
			return tmp;
		tmp = tmp->next;
	}
	return nullptr;
}

Node* FindNodeByName(Node* firstNode, MyString dataPattern)
{
	Node* tmp = firstNode;
	while (tmp != nullptr)
	{
		if (tmp->data == dataPattern)
			return tmp;
		tmp = tmp->next;
	}
	return nullptr;
}

Node* FindNodeByIndex(Node* firstNode, int index)
{
	Node* tmp = firstNode;
	if (tmp == nullptr)
		return tmp;
	for (int i = 0; i < index; i++)
		if (tmp->next != nullptr)
			tmp = tmp->next;
		else
			return nullptr;

	return tmp;
}
