#include <iostream>
#include <cstdio>
#include "node.h"
#include "dnode.h"
#include "mystring.h"

#define start_cs "????" //cs - command section
#define resume_css "****"
#define num_css_section "?"

using namespace std;

bool CheckIfStartOfCS(char* command, int iteration)
{
	if (command == nullptr || iteration == 1 && strlen(command) < 4)
		return false;
	if (*command == '?')
	{
		if (iteration == 4)
			return true;
		return CheckIfStartOfCS(++command, ++iteration);
	}
	return false;
}

int ConvertStringToInt(MyString text)
{
	int number = 0;
	int m = 1;
	for (int i = text.getSize() - 1; i >= 0; i--)
	{
		number += (text[i] - '0') * m;
		m *= 10;
	}

	return number;
}

bool IsNumber(MyString text)
{
	for (int i = 0; i < text.getSize(); i++)
	{
		if (text[i] < '0' || text[i]>'9')
			return false;
	}
	return true;
}

MyString* CutCommand(MyString command)
{
	int firstComma;
	bool foundOne = false;
	MyString firstA("");
	MyString secondA("");
	MyString thirdA("");
	for (int i = 0; i < command.getSize(); i++)
	{
		if (command[i] == ',' && !foundOne)
		{
			firstComma = i;
			firstA = command.ExtractString(0, i - 1);
			foundOne = true;
		}
		else if (command[i] == ',' && foundOne)
		{
			secondA = command.ExtractString(firstComma + 1, i - 1);
			thirdA = command.ExtractString(i + 1, command.getSize() - 1);
			break;
		}
	}
	MyString arg_array[3];
	arg_array[0] = firstA;
	arg_array[1] = secondA;
	arg_array[2] = thirdA;

	return arg_array;
}

bool ExecuteCommand(DNode* section_list, MyString command)
{
	if (command == "?")
	{
		int num_of_sections = 0;
		DNode* tmp = section_list;
		while (tmp != nullptr)
		{
			num_of_sections += tmp->counter;
			tmp = tmp->next;
		}
		cout << "? == " << num_of_sections << endl;
		return false;
	}

	if (command == "****")
	{
		return true;
	}

	MyString* cut = CutCommand(command);
	MyString one = cut[0];
	MyString two = cut[1];
	MyString three = cut[2];

	if (IsNumber(one) && two == "S" && three == "?")
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		if (tmp != nullptr && indexInNode < tmp->counter)
		{
			int lenght = GetListLenght(tmp->data[indexInNode].selector_list);
			cout << command << " == " << lenght << endl;
		}

		return false;
	}

	if (IsNumber(one) && two == "A" && three == "?")
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		if (tmp != nullptr && indexInNode < tmp->counter)
		{
			int lenght = GetListLenght(tmp->data[indexInNode].attribute_list);
			cout << command << " == " << lenght << endl;
		}
		return false;
	}

	if (IsNumber(one) && two == "S" && IsNumber(three))
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int secondaryIndex = ConvertStringToInt(three) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		if (tmp != nullptr && FindNodeByIndex(tmp->data[indexInNode].selector_list, secondaryIndex) != nullptr)
			cout << command << " == " << FindNodeByIndex(tmp->data[indexInNode].selector_list, secondaryIndex)->data << endl;
		return false;
	}

	if (IsNumber(one) && two == "A" && !IsNumber(three))
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		if (tmp != nullptr && FindNodeByName(tmp->data[indexInNode].attribute_list, three) != nullptr)
			cout << command << " == " << FindNodeByName(tmp->data[indexInNode].attribute_list, three)->value << endl;
		return false;
	}

	if (!IsNumber(one) && two == "A" && three == "?")
	{
		int count = 0;
		DNode* tmp = section_list;
		Node* tmpA;
		while (tmp != nullptr)
		{
			for (int i = 0; i < tmp->counter; i++)
			{
				tmpA = tmp->data[i].attribute_list;
				while (tmpA != nullptr)
				{
					MyString tmpStr(tmpA->data);
					if (one == tmpStr)
						count++;
					tmpA = tmpA->next;
				}
			}
			tmp = tmp->next;
		}
		
		cout << command << " == " << count << endl;
		return false;
	}

	if (!IsNumber(one) && two == "S" && three == "?")
	{
		int count = 0;
		DNode* tmp = section_list;
		Node* tmpA;
		while(tmp != nullptr)
		{
			for (int i = 0; i < tmp->counter; i++)
			{
				tmpA = tmp->data[i].selector_list;
				while (tmpA != nullptr)
				{
					MyString tmpStr(tmpA->data);
					if (one == tmpStr)
						count++;
					tmpA = tmpA->next;
				}
			}
			tmp = tmp->next;
		}
		cout << command << " == " << count << endl;
		return false;
	}

	if (IsNumber(one) && two == "D" && three == "*")
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		delete tmp->data[indexInNode].attribute_list;
		delete tmp->data[indexInNode].selector_list;
		tmp->data[indexInNode].attribute_list = nullptr;
		tmp->data[indexInNode].selector_list = nullptr;
		tmp->counter--;

		while (true)
		{
			if (indexInNode + 1 > tmp->counter)
				if (tmp->next != nullptr)
				{
					tmp = tmp->next;
					indexInNode = 0;
				}
				else
				{
					tmp->data[indexInNode - 1].attribute_list = nullptr;
					tmp->data[indexInNode - 1].selector_list = nullptr;
					break;
				}

			if (tmp->data[indexInNode + 1].attribute_list != nullptr && tmp->data[indexInNode + 1].selector_list != nullptr)
				tmp->data[indexInNode] = tmp->data[indexInNode + 1];

			indexInNode++;
		}



		cout << command << " == deleted" << endl;
		return false;
	}

	if (IsNumber(one) && two == "D" && !IsNumber(three))
	{
		int selectorIndex = ConvertStringToInt(one) - 1;
		int nodeskip = selectorIndex / T;
		int indexInNode = selectorIndex % T;
		DNode* tmp = section_list;
		for (int i = 0; i < nodeskip; i++)
		{
			if (tmp == nullptr)
				break;
			tmp = tmp->next;
		}
		Node* found = FindNodeByName(tmp->data[indexInNode].attribute_list, three);
		if (tmp != nullptr && found != nullptr)
		{
			if (found == (tmp->data[indexInNode].attribute_list))
			{
				RemoveFirst(tmp->data[indexInNode].attribute_list);
				tmp->data[indexInNode].attribute_list = nullptr;
			}
			else
				RemoveNode(tmp->data[indexInNode].attribute_list, found);
		}

		if (tmp != nullptr && tmp->data[indexInNode].attribute_list == nullptr)
		{
			delete tmp->data[indexInNode].selector_list;
			tmp->data[indexInNode].selector_list = nullptr;
			tmp->counter--;

			while (true)
			{
				if (indexInNode + 1 > tmp->counter)
					if (tmp->next != nullptr)
					{
						tmp = tmp->next;
						indexInNode = 0;
					}
					else
					{
						tmp->data[indexInNode - 1].attribute_list = nullptr;
						tmp->data[indexInNode - 1].selector_list = nullptr;
						break;
					}

				if (tmp->data[indexInNode + 1].attribute_list != nullptr && tmp->data[indexInNode + 1].selector_list != nullptr)
					tmp->data[indexInNode] = tmp->data[indexInNode + 1];

				indexInNode++;
			}
		}
		cout << command << " == deleted" << endl;
		return false;
	}

	if (!IsNumber(one) && two == "E" && !IsNumber(three))
	{
		DNode* tmpL = GetLast(section_list);
		int arrayIndex = tmpL->counter - 1;
		MyString wantedValue;
		while (tmpL != nullptr)
		{
			while (arrayIndex >= 0)
			{
				Node* tmpS = tmpL->data[arrayIndex].selector_list;
				if (tmpS->data == one)
				{
					while (tmpL->data[arrayIndex].attribute_list != nullptr)
					{
						if (tmpL->data[arrayIndex].attribute_list->data == three)
						{
							if (!(tmpL->data[arrayIndex].attribute_list->value == ""))
							{
								wantedValue = tmpL->data[arrayIndex].attribute_list->value;
								cout << command << " == " << wantedValue << endl;
								return false;
							}
							else
							{
								cout << "Value is NULL" << endl;
								return false;
							}
						}
					}
				}
				arrayIndex--;
			}
			tmpL = tmpL->previous;
			if (tmpL != nullptr)
			{
				arrayIndex = tmpL->counter - 1;
			}
		}
	}


	return false;

}

void DeleteSpace(MyString* text)
{
	bool q = false;
	char kurde = (*text)[text->getSize()-1];
	while (!q)
	{
		if ((*text)[0] == ' ' || (*text)[0] == 32 || (*text)[0]=='\t')
		{
			MyString tmp = text->ExtractString(1, text->getSize());
			*text = tmp;
		}
		else if ((*text)[text->getSize()-1] == ' ' || (*text)[text->getSize()-1] == '\t' || (*text)[text->getSize()-1] == 32)
		{
			MyString tmp = text->ExtractString(0, text->getSize() - 2);
			*text = tmp;
		}
		else
		{
			q = true;
		}
	}
	

}

Block ParseCSS(MyString CSS)
{
	MyString attribute_group;
	MyString selector_group;

	Node* attribute_list = nullptr;
	Node* selector_list = nullptr;
	int sel_start_pos = 0;
	for (int pos = 0; pos < CSS.getSize(); pos++)
	{
		if (CSS[pos] == '{')
		{
			for (int poss = pos; poss < CSS.getSize(); poss++)
				if (CSS[poss] == '}')
				{
					//ATRYBUT
					attribute_group = CSS.ExtractString(pos + 1, poss - 1);//ekstrakcja atrybutow w nawiasach klamrowych
					DeleteSpace(&attribute_group);
					int at_start_pos = 0;
					for (int atr_pos = at_start_pos; atr_pos < attribute_group.getSize(); atr_pos++)//ekstrakcja pojedynczego atrybutu
					{
						if (attribute_group[atr_pos] == ';' || (attribute_group[atr_pos - 1] != ';' && atr_pos == attribute_group.getSize() - 1))
						{
							MyString attribute(attribute_group.ExtractString(at_start_pos, atr_pos - 1));
							DeleteSpace(&attribute);
							MyString property("");
							MyString value("");
							bool correct = false;
							Node* sameProperty = nullptr;
							for (int check_pos = 0; check_pos < attribute.getSize(); check_pos++)
							{
								if (attribute[check_pos] == ':')
								{
									property = attribute.ExtractString(0, check_pos - 1);
									value = attribute.ExtractString(check_pos + 1, attribute.getSize());
									DeleteSpace(&property);
									DeleteSpace(&value);
									sameProperty = FindNode(attribute_list, property, property.getSize());
									correct = true;
									break;
								}
							}
							if (!correct)
							{
								cout << "CSS JEST SYNTAKTYCZNIE NIEPOPRAWNY ";
								//return;
							}
							DeleteSpace(&attribute);
							if (sameProperty == nullptr)
							{
								Node* newAttribute = new Node(property, value);
								attribute_list = AddLast(attribute_list, newAttribute);
							}
							else
							{
								sameProperty->value = value;
								sameProperty = nullptr;
							}
							at_start_pos = atr_pos + 1;
						}
					}

					//SELEKTOR
					selector_group = CSS.ExtractString(sel_start_pos, pos - 1);//ekstrakcja selektorow
					sel_start_pos = 0;
					for (int sel_pos = 0; sel_pos <= selector_group.getSize(); sel_pos++)
					{
						if (selector_group[sel_pos] == ',' || sel_pos == selector_group.getSize())
						{
							MyString selector(selector_group.ExtractString(sel_start_pos, sel_pos - 1));
							sel_start_pos = sel_pos + 1;

							DeleteSpace(&selector);
							Node* newSelector = new Node(selector);
							selector_list = AddLast(selector_list, newSelector);
						}
					}
					pos = poss;
					sel_start_pos = poss + 2;
					break;
				}

		}

	}

	Block section;
	section.attribute_list = attribute_list;
	section.selector_list = selector_list;

	return section;
}

DNode* PutIntoLists(MyString input, DNode* firstNode)
{
	int ext_start = 0;
	for (int i = 0; i < input.getSize(); i++)
	{
		if (input[i] == '}')
		{
			bool q = false;
			MyString section = input.ExtractString(ext_start, i);
			Block block_section = ParseCSS(section);
			DNode* tmp = firstNode;
			while (!q)
			{
				if (tmp == nullptr)
				{
					DNode* newNode = new DNode(block_section);
					firstNode = AddLast(firstNode, newNode);
					tmp = newNode;
					q = true;
				}
				else if (tmp->counter < T)
				{
					tmp->data[tmp->counter] = block_section;
					tmp->counter++;
					q = true;
				}
				else if (tmp->next != nullptr)
				{
					tmp = tmp->next;
				}
				else if (tmp->next == nullptr)
				{
					DNode* newNode = new DNode(block_section);
					firstNode = AddLast(firstNode, newNode);
					q = true;
				}
			}
			ext_start = i + 1;

		}


	}
	return firstNode;
}

int main()
{

	char section[100];
	DNode* section_list = nullptr;
	bool q;
	bool exit = false;
	while (!exit)
	{
		MyString CSS;
		q = false;
		while (!q && !exit)
		{
			char* line;
			line = fgets(section, 100, stdin);
			if (line == nullptr)
			{
				exit = true;
				break;
			}

			line[strcspn(line, "\n")] = 0;
			if (CheckIfStartOfCS(line, 1))
			{
				q = true;
				break;
			}
			CSS += line;
			CSS += " ";
		}
		if (!exit)
			section_list = PutIntoLists(CSS, section_list);

		q = false;
		while (!q && !exit)
		{
			char* line;
			line = fgets(section, 100, stdin);
			if (line == nullptr)
			{
				exit = true;
				break;
			}
			line[strcspn(line, "\n")] = 0;
			MyString command = line;
			q = ExecuteCommand(section_list, command);
		}
	}

}