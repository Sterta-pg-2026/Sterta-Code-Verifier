#pragma once
#include "string.h"
#include "listsection.h"

void Scommand(String* arg1, String* arg3, ListSection* listSection, String* input);
void Acommand(String* arg1, String* arg3, ListSection* listSection, String* input);
void Ecommand(String* arg1, String* arg3, ListSection* listSection, String* input);
void Dcommand(String* arg1, String* arg3, ListSection* listSection, String* input);
