#ifndef CSS_H
#define CSS_H
#pragma once

#include "baseclass.h"
#include "data.h"

class CSS : public BaseClass
{
public:
	CSS(Document *document);
	~CSS();
	void ProcessCSS(char *css);
	void log(char const *msg);

private:
	char *tokenStringSelector;
	char tokenStringAttribute[BUFFER_SIZE_TOKEN_STRING];
	char tokenStringAttributes[BUFFER_SIZE_TOKEN_STRING];

	char tokenStringValue[BUFFER_SIZE_TOKEN_STRING];

	char tokenString[BUFFER_SIZE_TOKEN_STRING];
	char *tokenStringPtr;

	Document *document;

	int ProcessCSSToToken(char *css);
	void ProcessSelectors();
	void ProcessAttributeAndValue();
	void ProcessAttributeValue();
	//
	void DeleteWhiteSpacesFirstAndLast(char *ptr);
	//
	void AddSection();
	void AddSelectorToSection();
	void AddAttributeToSection();
};

CSS::CSS(Document *document)
{
	this->document = document;

	tokenStringSelector = NULL;
	tokenStringValue[0] = '\0';
	tokenStringAttribute[0] = '\0';
	tokenStringAttributes[0] = '\0';
	tokenString[0] = '\0';
	tokenStringPtr = NULL;
};
CSS::~CSS()
{
}

void CSS::log(char const *msg)
{
	if (DEBUG_CSS)
		cout << msg << endl;
}

void CSS::ProcessCSS(char *css)
{
	log("CSS::ProcessCSS");

	//	cout << css << endl;
	//	cout << endl;

	AddSection();
	ProcessCSSToToken(css);
};

int CSS::ProcessCSSToToken(char *css)
{
	log("CSS::ProcessCSSToToken");

	char korektor[] = "{}";

	int count = 0;
	int k = 0;
	while (css[k] != '\0' && css[k] != '{')
	{

		tokenString[count] = css[k];
		count++;
		k++;
	}
	tokenString[count] = '\0';
	k++;
	count = 0;
	while (css[k] != '\0' && css[k] != '}')
	{

		tokenString[count] = css[k];
		count++;
		k++;
	}
	tokenString[count] = '\0';

	tokenStringPtr = strtok(css, korektor);
	ProcessSelectors();
	ProcessAttributeAndValue();

	return 0;
};

void CSS::ProcessSelectors()
{

	log("CSS::ProcessSelectors");

	char korektor[] = ",";

	tokenStringSelector = strtok(tokenStringPtr, korektor);
	while (tokenStringSelector != NULL)
	{
		AddSelectorToSection();

		tokenStringSelector = strtok(NULL, korektor);
	}
};
void CSS::ProcessAttributeAndValue()
{
	log("CSS::ProcessAttribute");

	int k = 0;
	int t = 0;

	while (tokenString[k] != '\0')
	{
		while (tokenString[k] != ';')
		{
			tokenStringAttributes[t] = tokenString[k];
			t++;
			k++;
		}

		tokenStringAttributes[t] = '\0';
		ProcessAttributeValue();
		t = 0;
		k++;
	}
};
void CSS::ProcessAttributeValue()
{

	int i = 0;
	int j = 0;
	while (tokenStringAttributes[i] != '\0')
	{
		while (tokenStringAttributes[i] != ':')
		{
			tokenStringAttribute[j] = tokenStringAttributes[i];
			i++;
			j++;
		}
		tokenStringAttribute[j] = '\0';
		j = 0;
		i++;
		while (tokenStringAttributes[i] != ';' && tokenStringAttributes[i] != '\0')
		{
			tokenStringValue[j] = tokenStringAttributes[i];
			i++;
			j++;
		}
		tokenStringValue[j] = '\0';
		AddAttributeToSection();
	}
};

void CSS::AddSection()
{
	document->addSection();
};
void CSS::AddSelectorToSection()
{
	DeleteWhiteSpacesFirstAndLast(tokenStringSelector);

	document->addSelector(tokenStringSelector);
};

void CSS::AddAttributeToSection()
{
	DeleteWhiteSpacesFirstAndLast(tokenStringAttribute);
	DeleteWhiteSpacesFirstAndLast(tokenStringValue);

	document->addAttribute(tokenStringAttribute, tokenStringValue);
};

void CSS::DeleteWhiteSpacesFirstAndLast(char *ptr)
{
	int i = 0;
	int len = 0;
	while (ptr[i] != '\0')
	{
		i++;
		len++;
	}

	while (ptr[len] == ' ' || ptr[len] == '\t' || ptr[len] == '\0')
	{
		ptr[len] = '\0';
		len--;
	}
	int j = 0;

	while (ptr[0] == ' ' || ptr[j] == '\t')
	{
		while (ptr[j] != '\0')
		{

			ptr[j] = ptr[j + 1];
			j++;
		}
		j = 0;
	}
}
#endif