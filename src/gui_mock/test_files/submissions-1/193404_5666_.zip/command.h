#ifndef COMMAND_H
#define COMMAND_H
#pragma once

#include "baseclass.h"
#include "data.h"

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "constants.h"

using namespace std;

class Command : public BaseClass
{
public:
    Command(Document *document);
    ~Command();
    int ProcessCommand(char *command);
    void log(char const *msg);

private:
    char part1[COMMAND_BUFFER_SIZE];
    char part2[COMMAND_BUFFER_SIZE];
    char part3[COMMAND_BUFFER_SIZE];
    int part1Lenght = 0;
    int part2Lenght = 0;
    int part3Lenght = 0;
    int answear = 0;

    int ProcessCommandToToken(char *command);
    void CheckCommandType();
    // Commands
    int GetNumberOfSections();
    int GetSelectorInSection(int i, int j);
    int GetValueOfAttributeFromSelector(char *z, char *n);
    int GetNumberOfSelectors(char *z);
    int GetNumberOfSelctorsInSection(int i);
    int GetNumberOfAttributesInSection(int i);
    int GetAttributeInSectionWithName(int i, char *n);
    int GetNumberOfAttributes(char *n);
    int DeleteAttribute(int i, char *n);
    int DeleteSection(int i);

    int PrintAnswer();

    Document *document;
};

Command::Command(Document *document)
{
    this->document = document;

    part1[0] = '\0';
    part2[0] = '\0';
    part3[0] = '\0';
}

Command::~Command()
{
}

void Command::log(char const *msg)
{
    if (DEBUG_COMMAND)
        cout << msg << endl;
}

int Command::ProcessCommand(char *command)
{

    if (strcmp(command, "\0") != 0)
    {
        ProcessCommandToToken(command);
        CheckCommandType();
        PrintAnswer();
    }
    return 0;
};

void Command::CheckCommandType() // check command and activate right process
{
    if (strcmp(part1, "?") == 0) // ?
    {
        GetNumberOfSections();
    }
    else
    {
        if (strcmp(part2, "A") == 0)
        {
            if (strcmp(part3, "?") == 0)
            {
                if (atoi(part1) == 0)
                {
                    GetNumberOfAttributes(part1);
                }
                else
                {
                    GetNumberOfAttributesInSection(atoi(part1));
                }
            }
            else
            {
                GetAttributeInSectionWithName(atoi(part1), part3);
            }
        }
        else if (strcmp(part2, "S") == 0)
        {

            if (strcmp(part3, "?") == 0)
            {
                if (atoi(part1) == 0)
                {
                    GetNumberOfSelectors(part1);
                }
                else
                {
                    GetNumberOfSelctorsInSection(atoi(part1));
                }
            }
            else
            {
                GetSelectorInSection(atoi(part1), atoi(part3));
            }
        }
        else if (strcmp(part2, "D") == 0)
        {
            if (strcmp(part3, "*") == 0)
            {
                DeleteSection(atoi(part1));
            }
            else
            {
                DeleteAttribute(atoi(part1), part3);
            }
        }
        else if (strcmp(part2, "E") == 0)
        {
            GetValueOfAttributeFromSelector(part1, part3);
        }
    }
};

int Command::ProcessCommandToToken(char *command)
{
    if (strcmp(command, "\0") == 0) // empty line
    {
        part1[0] = '\n';
        part1[1] = '\0';
        part2[0] = '\0';
        part3[0] = '\0';

        part1Lenght = 1;
        part2Lenght = 0;
        part3Lenght = 0;
    }
    else if (strcmp(command, "?") == 0) // command "?"
    {
        part1[0] = '?';
        part1[1] = '\0';
        part2[0] = '\0';
        part3[0] = '\0';

        part1Lenght = 1;
        part2Lenght = 0;
        part3Lenght = 0;
    }
    else // divide command into 3 parts
    {

        int j = 0;
        int i = 0;
        while (command[i] != ',')
        {
            part1[j] = command[i];
            i++;
            j++;
        }
        part1Lenght = j;
        part1[j] = '\0';
        i++;
        j = 0;
        while (command[i] != ',')
        {
            part2[j] = command[i];
            i++;
            j++;
        }
        part2Lenght = j;
        part2[j] = '\0';

        i++;
        j = 0;

        while (command[i] != '\n' && command[i] != '\0')
        {
            part3[j] = command[i];
            i++;
            j++;
        }
        part3Lenght = j;
        part3[j] = '\0';
    }
    return part1Lenght + part2Lenght + part3Lenght;
}

// Commands
int Command::GetNumberOfSections()
{
    // log("GetNumberOfSections");
    answear = document->GetNumberOfSections();
    return document->GetNumberOfSections();
};

int Command::GetNumberOfSelctorsInSection(int i)
{
    // i,S,?
    answear = document->GetNumberOfSelctorsInSection(i);
    return document->GetNumberOfSelctorsInSection(i);
};

int Command::GetNumberOfAttributesInSection(int i)
{
    // i,A,?
    log("GetNumberOfAttributesInSection");
    answear = document->GetNumberOfAttributesInSection(i);
    return document->GetNumberOfAttributesInSection(i);
};

int Command::GetSelectorInSection(int i, int j)
{
    // i,S,j
    log("GetSelectorInSection");
    answear = document->GetSelectorInSection(i, j);
    return 0;
};

int Command::GetAttributeInSectionWithName(int i, char *n)
{
    log("GetAttributeInSectionWithName");
    answear = document->GetAttributeInSectionWithName(i, n);
    // i,A,n
    return 0;
};

int Command::GetNumberOfAttributes(char *n)
{
    answear = document->GetNumberOfAttributes(n);
    // n,A,?
    return 0;
};

int Command::GetNumberOfSelectors(char *z)
{
    // z,S,?
    answear = document->GetNumberOfSelectors(z);

    return 0;
};

int Command::GetValueOfAttributeFromSelector(char *z, char *n)
{
    // z,E,n

    log("GetValueOfAttributeFromSelector");
    answear = document->GetValueOfAttributeFromSelector(z, n);

    return 0;
}

int Command::DeleteSection(int i)
{
    log("DeleteSection");
    answear = document->DeleteSection(i);

    return 0;
}

int Command::DeleteAttribute(int i, char *n)
{
    answear = document->DeleteAttribute(i, n);
    return 0;
}

int Command::PrintAnswer() // print
{

    if (strcmp(part1, "?") == 0)
    {
        cout << part1 << " == " << GetNumberOfSections() << endl;
    }
    else
    {
        if (answear != -1)
        {
            cout << part1 << ",";
            cout << part2 << ",";
            cout << part3;
            cout << " == ";
            cout << document->answere << endl;
        }
        else
        {
            if (DEBUG)
            {
                cout << part1 << ",";
                cout << part2 << ",";
                cout << part3;
                cout << " == ";
                cout << "na" << endl;
            }
        }
    }
    return 0;
};

#endif