#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "constants.h"
#include "inputprocessor.h"

using namespace std;

int main()
{
    InputProcessor MyInputProcessor;
    MyInputProcessor.GetInput();
    // MyInputProcessor.document->printSection();
    //  MyInputProcessor.document->PrintAll();

    return 0;
}