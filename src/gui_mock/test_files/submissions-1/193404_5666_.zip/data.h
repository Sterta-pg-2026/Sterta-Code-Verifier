
#ifndef DATA_H
#define DATA_H
#pragma once

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "constants.h"
#include "dataparts.h"

using namespace std;

class Document : public BaseData
{

public:
    Document();
    ~Document();
    void addSection();
    void addSelector(char *selector);
    void addAttribute(char *attribute, char *value);
    int GetNumberOfSelctorsInSection(int i);
    int GetNumberOfAttributesInSection(int i);
    int GetNumberOfSections();
    void PrintAll();
    int GetSelectorInSection(int i, int j);
    int GetSelectorInSectionWithName(int i, char *n);
    int GetAttributeInSectionWithName(int i, char *n);
    int GetNumberOfAttributes(char *n);
    int GetNumberOfSelectors(char *z);
    int GetValueOfAttributeFromSelector(char *z, char *n);
    int DeleteSection(int i);
    int DeleteAttribute(int i, char *n);

    void printSection();

    char answere[BUFFER_SIZE_SECTION];

private:
    Sections *sections;
    Sections *currentSections;
    Sections *sectionsFirsts;
    Sections *sectionsLasts;

    int numberOfSections = 0;
    int sectionNumber = 0;
    int currentSectionNumber = 0;
    int currentSectionsNumber = 0;
    int currentSectionsArrayNumber = 0;

    void addSectionArray();
};

Document::Document()
{
    log("Document::Document");
    sections = NULL;
    currentSections = NULL;
    sectionsFirsts = NULL;
    sectionsLasts = NULL;
    answere[0] = '\0';
}

Document::~Document()
{
    log("Document::~Document");
}
void Document::addSectionArray()
{
    if (!sectionsFirsts)
    {
        sectionsFirsts = new Sections;
        currentSections = sectionsFirsts;
        sectionsFirsts->head = NULL;

        sectionsFirsts->tail = NULL;
        sectionsLasts = sectionsFirsts;
    }
    else
    {
        if (sectionsLasts->sectionNumber == SELECTOR_SIZE_T)
        {
            Sections *newSections = new Sections;
            sectionsLasts->head = newSections;
            newSections->tail = sectionsLasts;
            sectionsLasts = newSections;
        }
    }
    currentSectionsArrayNumber++;
};

void Document::addSection()
{
    if (!sectionsFirsts || sectionsLasts->sectionNumber == SELECTOR_SIZE_T)
    {
        addSectionArray();
    }
    sectionsLasts->addSection();
    numberOfSections++;
};

void Document::addSelector(char *selector)
{
    log("Document::addSelector");
    //   cout << selector << " " << sectionsLasts << endl;
    sectionsLasts->sections[sectionsLasts->sectionNumber - 1]->addSelector(selector);
}

void Document::addAttribute(char *attribute, char *value)
{
    log("Document::addAttribute");
    // cout << attribute << endl;
    // cout << value << endl;

    sectionsLasts->sections[sectionsLasts->sectionNumber - 1]
        ->addAttribute(attribute, value);
}

int Document::GetNumberOfSections()
{
    sprintf(answere, "%d", numberOfSections);
    return numberOfSections;
}

int Document::GetNumberOfSelctorsInSection(int i)
{
    Sections *temp_sections = sectionsFirsts;
    int j = 0;
    if (i > numberOfSections)
    {
        return -1;
    }
    while (i != 1)
    {
        if (temp_sections->sections[j])
        {
            i--;
        }
        j++;

        if (j == SELECTOR_SIZE_T)
        {
            j = 0;
            temp_sections = temp_sections->head;
        }
    }
    while (!temp_sections->sections[j])
    {
        j++;

        if (j == SELECTOR_SIZE_T)
        {
            j = 0;
            temp_sections = temp_sections->head;
        }
    }
    sprintf(answere, "%d", temp_sections->sections[j]->numberOfSelectors);

    return temp_sections->sections[j]->numberOfSelectors;
}

int Document::GetSelectorInSection(int i, int j)
{
    Sections *temp_sections = sectionsFirsts;
    int k = 0;
    if (i > numberOfSections)
    {
        return -1;
    }
    while (i != 1)
    {
        if (temp_sections->sections[k])
        {
            i--;
        }
        k++;

        if (k == SELECTOR_SIZE_T)
        {
            k = 0;
            temp_sections = temp_sections->head;
        }
    }
    while (!temp_sections->sections[k])
    {
        k++;

        if (k == SELECTOR_SIZE_T)
        {
            k = 0;
            temp_sections = temp_sections->head;
        }
    }

    if (j > temp_sections->sections[k]->numberOfSelectors)
    {
        return -1;
    }
    while (j != 1)
    {
        temp_sections->sections[k]->selectorsFirst = temp_sections->sections[k]->selectorsFirst->head;
        j--;
        if (temp_sections->sections[k]->selectorsFirst == NULL)
        {
            return -1;
        }
    }
    strcpy(answere, temp_sections->sections[k]->selectorsFirst->value);
    return 0;
}
int Document::GetNumberOfAttributesInSection(int i)
{
    Sections *temp_sections = sectionsFirsts;
    int j = 0;
    if (i > numberOfSections)
    {
        return -1;
    }
    while (i != 1)
    {

        if (temp_sections->sections[j])
        {
            i--;
        }
        j++;
        if (j == SELECTOR_SIZE_T)
        {
            j = 0;
            temp_sections = temp_sections->head;
        }
    }
    while (temp_sections->sections[j] == NULL)
    {
        j++;
        if (j == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            j = 0;
        }
    }
    sprintf(answere, "%d", temp_sections->sections[j]->numberOfAttributes);
    return temp_sections->sections[j]->numberOfAttributes;
}

// unused
int Document::GetSelectorInSectionWithName(int i, char *n)
{
    Sections *temp_sections = sectionsFirsts;
    int k = 0;
    if (i > numberOfSections)
    {
        return -1;
    }
    while (i != 1)
    {

        if (temp_sections->sections[k])
        {
            i--;
        }
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            k = 0;
            temp_sections = temp_sections->head;
        }
    }
    while (temp_sections->sections[k] == NULL)
    {
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            k = 0;
        }
    }
    while (temp_sections->sections[k]->attributesFirst != NULL)
    {
        if (strcmp(n, temp_sections->sections[k]->attributesFirst->attribute) == 0)
        {
            strcpy(answere, temp_sections->sections[k]->selectorsFirst->value);

            cout << temp_sections->sections[k]->attributesFirst->value << endl;
            return 0;
        }
        temp_sections->sections[k]->attributesFirst = temp_sections->sections[k]->attributesFirst->head;
        if (temp_sections->sections[k]->attributesFirst == NULL)
        {
            return -1;
        }
    }

    return -1;
}

int Document::GetAttributeInSectionWithName(int i, char *n)
{
    Sections *temp_sections = sectionsFirsts;
    int j = 0;
    if (i > numberOfSections)
    {
        return -1;
    }
    while (i != 1)
    {

        if (temp_sections->sections[j])
        {
            i--;
        }
        j++;
        if (j == SELECTOR_SIZE_T)
        {
            j = 0;
            temp_sections = temp_sections->head;
        }
    }
    while (temp_sections->sections[j] == NULL)
    {
        j++;
        if (j == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            j = 0;
        }
    }

    while (temp_sections->sections[j]->attributesFirst != NULL)
    {
        if (strcmp(n, temp_sections->sections[j]->attributesFirst->attribute) == 0)
        {
            strcpy(answere, temp_sections->sections[j]->attributesFirst->value);
            return 0;
        }
        temp_sections->sections[j]->attributesFirst = temp_sections->sections[j]->attributesFirst->head;
        if (temp_sections->sections[j]->attributesFirst == NULL)
        {
            return -1;
        }
    }

    return -1;
}

int Document::GetNumberOfAttributes(char *n)
{
    int count = 0;

    Sections *tmp = sectionsLasts;

    int k = SELECTOR_SIZE_T - 1;
    while (tmp)
    {
        while (tmp->sections[k] == NULL)
        {
            k--;
            if (k < 0)
            {
                k = SELECTOR_SIZE_T - 1;
                tmp = tmp->tail;
            }
        }
        while (tmp->sections[k]->attributesFirst)
        {
            // cout << "attribute: " << tmp->sections[k]->attributesFirst->value << ", n:" << n << endl;

            if (strcmp(tmp->sections[k]->attributesFirst->attribute, n) == 0)
            {
                count++;
                break;
            }
            else
            {
                tmp->sections[k]->attributesFirst = tmp->sections[k]->attributesFirst->head;
            }
        }

        k--;
        if (k < 0)
        {
            k = SELECTOR_SIZE_T - 1;
            tmp = tmp->tail;
        }
    }
    sprintf(answere, "%d", count);
    return count;
}
int Document::GetNumberOfSelectors(char *z)
{
    int count = 0;

    Sections *tmp = sectionsLasts;

    int k = SELECTOR_SIZE_T - 1;
    while (tmp)
    {
        while (tmp->sections[k] == NULL)
        {
            k--;
            if (k < 0)
            {
                k = SELECTOR_SIZE_T - 1;
                tmp = tmp->tail;
            }
        }
        while (tmp->sections[k]->selectorsFirst)
        {
            //  cout << "selector: " << tmp->sections[k]->selectorsFirst->value << ", z:" << z << endl;

            if (strcmp(tmp->sections[k]->selectorsFirst->value, z) == 0)
            {
                count++;
            }
            tmp->sections[k]->selectorsFirst = tmp->sections[k]->selectorsFirst->head;
        }

        k--;
        if (k < 0)
        {
            k = SELECTOR_SIZE_T - 1;
            tmp = tmp->tail;
        }
    }
    sprintf(answere, "%d", count);
    return count;
}
int Document::GetValueOfAttributeFromSelector(char *z, char *n)
{
    Sections *tmp = sectionsLasts;
    int k = SELECTOR_SIZE_T - 1;
    while (tmp)
    {
        while (tmp->sections[k] == NULL)
        {
            k--;
            if (k < 0)
            {
                k = SELECTOR_SIZE_T - 1;
                tmp = tmp->tail;
            }
        }
        while (tmp->sections[k]->selectorsLast)
        {
            //  cout << "selector: " << tmp->sections[k]->selectorsLast->value << ", z:" << z << endl;

            if (strcmp(tmp->sections[k]->selectorsLast->value, z) == 0)
            {
                //    cout << "||||||||||selector: " << tmp->sections[k]->selectorsLast->value << ", z:" << z << endl;

                while (tmp->sections[k]->attributesLast != NULL)
                {

                    //   cout << "attribute: " << tmp->sections[k]->attributesLast->attribute << ", n:" << n << endl;
                    if (strcmp(tmp->sections[k]->attributesLast->attribute, n) == 0)
                    {
                        //        cout << "||attribute: " << tmp->sections[k]->attributesLast->attribute << ", n:" << n << endl;

                        strcpy(answere, tmp->sections[k]->attributesLast->value);
                        return 0;
                    }
                    else
                    {
                        tmp->sections[k]->attributesLast = tmp->sections[k]->attributesLast->tail;
                    }
                }
            }
            tmp->sections[k]->selectorsLast = tmp->sections[k]->selectorsLast->tail;
        }
        k--;
        if (k < 0)
        {
            k = SELECTOR_SIZE_T - 1;
            tmp = tmp->tail;
        }
    }
    return -1;
}
int Document::DeleteSection(int i)
{
    Sections *temp_sections = sectionsFirsts;
    if (i > numberOfSections)
    {
        return -1;
    }
    int k = 0;

    while (i != 1)
    {
        if (temp_sections->sections[k])
        {
            i--;
        }
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            k = 0;
        }
    }
    while (temp_sections->sections[k] == NULL)
    {
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            k = 0;
        }
    }
    delete temp_sections->sections[k];
    temp_sections->sections[k] = NULL;

    numberOfSections--;

    strcpy(answere, "deleted");
    return 0;
}
int Document::DeleteAttribute(int i, char *n)
{
    Sections *temp_sections = sectionsFirsts;
    if (i > numberOfSections)
    {
        return -1;
    }
    int k = 0;

    while (i != 1)
    {
        if (temp_sections->sections[k])
        {
            i--;
        }
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            k = 0;
        }
    }
    while (temp_sections->sections[k] == NULL)
    {
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            temp_sections = temp_sections->head;
            k = 0;
        }
    }

    while (temp_sections->sections[k]->attributesFirst != NULL)
    {

        if (strcmp(temp_sections->sections[k]->attributesFirst->attribute, n) == 0)
        {
            temp_sections->sections[k]->numberOfAttributes--;
            if (temp_sections->sections[k]->numberOfAttributes == 0)
            {
                delete temp_sections->sections[k];
                numberOfSections--;
                strcpy(answere, "deleted");
                return 0;
            }
            else
            {
                Attribute *tmp_attr;
                tmp_attr = temp_sections->sections[k]->attributesFirst->head;
                temp_sections->sections[k]->attributesFirst = temp_sections->sections[k]->attributesFirst->tail;
                delete temp_sections->sections[k]->attributesFirst->head;
                temp_sections->sections[k]->attributesFirst->head = tmp_attr;
                strcpy(answere, "deleted");
                return 0;
            }
        }
        temp_sections->sections[k]->attributesFirst = temp_sections->sections[k]->attributesFirst->head;
    }

    return -1;
}

void Document::PrintAll()
{
    int i = 1;
    int t = 0;
    Sections *tmp = sectionsFirsts;
    cout << endl;

    while (t < numberOfSections && tmp)
    {
        if (t == SELECTOR_SIZE_T)
        {
            tmp = tmp->head;
            t = 0;
        }
        if (tmp)
        {
            cout << i << " " << endl;
            while (tmp->sections[t]->selectorsFirst)
            {
                cout << tmp->sections[t]->selectorsFirst->value << "\t";
                tmp->sections[t]->selectorsFirst = tmp->sections[t]->selectorsFirst->head;
            }
            cout << endl;

            while (tmp->sections[t]->attributesFirst)
            {
                cout << "|" << tmp->sections[t]->attributesFirst->attribute << "|\t";
                cout << "|" << tmp->sections[t]->attributesFirst->value << "|\t" << endl;

                tmp->sections[t]->attributesFirst = tmp->sections[t]->attributesFirst->head;
            }
            cout << endl;
        }
        t++;
        i++;
    }
};

void Document::printSection()
{

    int i = 1;
    int k = 0;
    Sections *tmp = sectionsFirsts;

    while (tmp && i <= numberOfSections)
    {
        if (tmp->sections[k] != NULL)
        {
            cout << i << endl
                 << tmp->sections[k] << " |  " << tmp << "  _  " << k << endl;
        }

        i++;
        k++;
        if (k == SELECTOR_SIZE_T)
        {
            tmp = tmp->head;
            k = 0;
        }
    }

    cout << endl
         << endl
         << numberOfSections;
}

#endif