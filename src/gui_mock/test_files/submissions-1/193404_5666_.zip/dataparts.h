#ifndef DATA_PARTS_H
#define DATA_PARTS_H
#pragma once

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "constants.h"
#include "dataparts.h"

using namespace std;

class BaseData
{

public:
    BaseData();
    ~BaseData();
    void log(char const *msg);
};

BaseData::BaseData()
{
}

BaseData::~BaseData()
{
}

void BaseData::log(char const *msg)
{
    if (DEBUG_DATA)
        cout << msg << endl;
}

struct Selector
{
    char value[VALUE_BUFFER_SIZE];
    Selector *head = NULL;
    Selector *tail = NULL;
} typedef Selector;

struct Attribute
{
    char attribute[VALUE_BUFFER_SIZE];
    char value[VALUE_BUFFER_SIZE];
    Attribute *head = NULL;
    Attribute *tail = NULL;
} typedef Attribute;

class Section : public BaseData
{

public:
    Section();
    ~Section();
    void addSelector(char *selector);
    void addAttribute(char *attribute, char *aValue);
    Section *head;
    Section *tail;

    int numberOfSelectors = 0;
    int numberOfAttributes = 0;
    Selector *selectorsFirst;
    Attribute *attributesFirst;
    Selector *selectorsLast;
    Attribute *attributesLast;

    char value[VALUE_BUFFER_SIZE];
    int sectionNumber = 0;
    //  int currentSelector = 0;
};

Section::Section()
{
    //    log("Section::Section");
    head = NULL;
    tail = NULL;
    selectorsFirst = NULL;
    selectorsLast = NULL;
    attributesFirst = NULL;
    attributesLast = NULL;
    numberOfSelectors = 0;
    numberOfAttributes = 0;
    value[0] = '\0';
}

Section::~Section()
{
    log("Section::~Section");
}
void Section::addSelector(char *selector)
{
    if (!selectorsFirst)
    {
        Selector *newSelector = new Selector;
        newSelector->head = NULL;
        newSelector->tail = NULL;
        strcpy(newSelector->value, selector);
        selectorsFirst = newSelector;

        selectorsLast = selectorsFirst;
    }
    else
    {
        Selector *newSelector = new Selector;
        newSelector->head = NULL;
        newSelector->tail = selectorsLast;

        strcpy(newSelector->value, selector);
        selectorsLast->head = newSelector;
        selectorsLast = newSelector;
    }
    numberOfSelectors++;

    log("Section::addSelector");
};
void Section::addAttribute(char *attribute, char *aValue)
{

    if (!attributesFirst)
    {
        attributesFirst = new Attribute;
        strcpy(attributesFirst->attribute, attribute);
        strcpy(attributesFirst->value, aValue);

        attributesLast = attributesFirst;
    }
    else
    {
        Attribute *newAttribute = new Attribute;
        newAttribute->head = NULL;
        strcpy(newAttribute->attribute, attribute);
        strcpy(newAttribute->value, aValue);

        attributesLast->head = newAttribute;
        attributesLast = newAttribute;
    }
    numberOfAttributes++;
    log("Section::addAttribute");
};

class Sections : public BaseData
{

public:
    Sections();
    ~Sections();

    Sections *head;
    Sections *tail;
    Section *sections[SELECTOR_SIZE_T];
    int sectionNumber = 0;
    void addSection();
};
Sections::Sections()
{
    head = NULL;
    tail = NULL;
    for (int i = 0; i < SELECTOR_SIZE_T; i++)
    {
        sections[i] = NULL;
    }
};
void Sections::addSection()
{
    sections[sectionNumber] = new Section;
    sectionNumber++;
};
Sections ::~Sections(){};
#endif