#ifndef INPUTPROCESSOR_H
#define INPUTPROCESSOR_H
#pragma once

#include "baseclass.h"
#include "css.h"
#include "command.h"

#include <iostream>
#include <string.h>

using namespace std;

class InputProcessor : public BaseClass
{
private:
    char bufferPtrLine[BUFFER_SIZE_LINE];

    char bufferPtrSection[BUFFER_SIZE_SECTION];
    int mode;

public:
    Document *document;
    Command *command;
    CSS *css;

    InputProcessor();
    ~InputProcessor();
    int GetInput();
    int PrintInput();
    int GetMode() const;

private:
    void ChangeMode();
    int ProcessLine();
    int CheckForSection();
    bool CheckForChangeModeLine();
    void ProcessCSS();
    void ProcessCommand();
    void log(char const *msg);
};

void InputProcessor::log(char const *msg)
{
    if (DEBUG_INPUT_PROCESSOR)
        cout << msg << endl;
}

InputProcessor::InputProcessor()
{
    log("InputProcessor::InputProcessor");

    mode = CSSMode;
    bufferPtrLine[0] = '\0';
    bufferPtrSection[0] = '\0';
    document = new Document;
    command = new Command(document);
    css = new CSS(document);
}

InputProcessor::~InputProcessor()
{
    log("InputProcessor::~InputProcessor");
    delete document;
    delete command;
    delete css;
}

int InputProcessor::GetInput() // get input from file/user
{
    log("InputProcessor::GetInput");

    while (cin.getline(bufferPtrLine, BUFFER_SIZE_LINE))
    {
        ProcessLine();
    };

    return 0;
};
int InputProcessor::PrintInput() // print input line
{
    if (DEBUG_INPUT_PROCESSOR)
        cout << bufferPtrLine << endl;
    cout << endl;

    return 0;
};

void InputProcessor::ChangeMode() // change modes between command and css processor
{
    log("InputProcessor::ChangeMode");

    if (mode == CommandsMode)
    {
        log("InputProcessor::ChangeMode: from CommandsMode to CSSMode");
        mode = CSSMode;
    }
    else if (mode == CSSMode)
    {
        log("InputProcessor::ChangeMode: from CSSMode to CommandsMode");
        mode = CommandsMode;
    }
    else
        return;
};

int InputProcessor::GetMode() const // getter (unused)
{
    return mode;
};

int InputProcessor::ProcessLine() // procces input line
{

    log("InputProcessor::ProcessLine");

    if (CheckForChangeModeLine())
    {
    }
    else if (mode == CSSMode)
    {
        ProcessCSS();
    }
    else if (mode == CommandsMode)
    {
        ProcessCommand();
    }
    CheckForChangeModeLine();
    return 1;
};

void InputProcessor::ProcessCSS() // add line to section buffer, if section is colsed start css processing
{
    strcat(bufferPtrSection, bufferPtrLine);
    // cout << bufferPtrSection << endl;
    if (strchr(bufferPtrLine, '}') != NULL)
    {
        css->ProcessCSS(bufferPtrSection);
        bufferPtrSection[0] = '\0';
    }
};

void InputProcessor::ProcessCommand() // process command
{

    log("InputProcessor::ProcessCommand");

    command->ProcessCommand(bufferPtrLine);
    bufferPtrSection[0] = '\0';
};

bool InputProcessor::CheckForChangeModeLine() // chech for change mode
{
    log("InputProcessor::CheckForChangeModeLine");
    if (mode == CSSMode && strcmp(bufferPtrLine, START_COMMANDS_LINE) == 0)
    {
        ChangeMode();
        return true;
    }
    else if (mode == CommandsMode && strcmp(bufferPtrLine, START_CSS_LINE) == 0)
    {
        ChangeMode();
        return true;
    }
    else
    {
        return false;
    }
};

#endif