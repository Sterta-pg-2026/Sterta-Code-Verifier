#ifndef BASECLASS_H
#define BASECLASS_H
#pragma once

class BaseClass
{
public:
    BaseClass();
    ~BaseClass();

private:
};
BaseClass::BaseClass()
{
}

BaseClass::~BaseClass()
{
}

#endif