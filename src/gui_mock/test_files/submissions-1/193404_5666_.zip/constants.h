#ifndef CONSTANTS_H
#define CONSTANTS_H
#pragma once

//

#define DEBUG false
#define DEBUG_INPUT_PROCESSOR false
#define DEBUG_DATA false
#define DEBUG_CSS false
#define DEBUG_COMMAND false

#define BUFFER_SIZE_LINE 256
#define BUFFER_COMMAND_SIZE_LINE 32

#define NUMBER_OF_COMMAS 2

#define SELECTOR_SIZE_T 8

#define VALUE_BUFFER_SIZE 128
#define COMMAND_BUFFER_SIZE 64
#define BUFFER_SIZE_SECTION 512
#define BUFFER_SIZE_TOKEN_STRING 256

#define START_COMMANDS_LINE "????"
#define START_CSS_LINE "****"

enum
{
    CSSMode,
    CommandsMode,
    SelectorMode,
    AttributeMode,
};

#endif // CONSTANTS_H