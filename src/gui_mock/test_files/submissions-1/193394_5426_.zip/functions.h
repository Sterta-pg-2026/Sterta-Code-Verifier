#pragma once

void remove_extreme_whitespace(char* str);

struct List* createListNode();

void addListNode(struct List** head, struct List* newNode);

struct Attribute* createAttributeNode(char* name, char* value);

void addAttributeNode(struct Attribute** head, struct Attribute* newNode);

struct Selector* createSelectorNode(char* selectorName);

void addSelectorNode(struct Selector** head, struct Selector* newNode);

void read_selector(char* arr, char temp, struct Data* data);

void read_attribute(char* arr, char* name, char* value, char temp, struct Data* data);

void match_pattern(const char* input, struct Data data, struct Data* data_r);

void number_of_selectors(struct List* list, int section_number, int max_number_in);

void number_of_attributes(struct List* list, int section_number, int max_number_in);

void print_selector_name(struct List* list, int section_number, int selector_index, int max_number_in);

void value_of_attribute(struct List* list, int section_number, char* attribute_name, int max_number_in);

void count_attribute(struct List* list, char* attribute_name);

void count_selectors(struct List* list, char* selector_name);

void find_last_matching_attribute(struct List* list, char* sel_name, char* att_name);

void delete_section(struct List* head, int section_num, Data* data);

void freeAttributeList(struct Attribute* head);

void freeSelectorList(struct Selector* head);

void delete_attribute(struct List* head, int section_num, char* attr_name);

void no_attribute_delete(struct List* head, int section_num, Data* data);

void free_empty_block(struct List* node, Data* data);

void search_for_empty(struct List* node, Data* data);

bool selector_exists(Selector* head, char* name);

char* my_fgets(char* str, int n, FILE* stream);