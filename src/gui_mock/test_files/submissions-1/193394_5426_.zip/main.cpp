#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define SIZE 8
#define TEXT_SIZE 200


struct Attribute {
    char name[TEXT_SIZE];
    char value[TEXT_SIZE];
    struct Attribute* next;
    struct Attribute* prev;
};

struct Selector {
    char name[TEXT_SIZE];
    struct Selector* next;
    struct Selector* prev;
};

struct Section {
    int number;
    struct Selector* selectors;
    struct Attribute* attributes;
};

struct List {
    int in;
    struct Section section_arr[SIZE];
    struct List* next;
    struct List* prev;
};

struct Data {
    struct List* head = NULL;
    struct Selector* sel_head = NULL;
    struct Attribute* att_head = NULL;
    int i = 0;
    bool create_listNode = true;
    int current_section = 0;
    int section_number = 1;
    bool reading_selector = true, reading_attribute = false;
    bool r_att_name = true, r_att_val = false;
    bool want_to_read_value = false;
    int question_mark_count = 0;
    bool commands = false;
};

#include "functions.h"

void remove_extreme_whitespace(char* str) {
    int i;
    int len = strlen(str);
    int space = 0;

    // usuwa biale znaki z przodu
    while (isspace((unsigned char)str[space])) {
        space++;
    }
    if (space > 0) {
        memmove(str, str + space, len - space + 1);
        len -= space;
    }

    // usuwa biale znaki z tylu
    i = len - 1;
    while (i >= 0 && isspace((unsigned char)str[i])) {
        i--;
    }
    str[i + 1] = '\0';
}

char* my_fgets(char* str, int n, FILE* stream) {
    int c, i = 0;

    while ((c = fgetc(stream)) != EOF && i < n - 1) {
        str[i++] = c;
        if (c == 0x0D || c == 0x0A) { // koniec jak jest CR albo LF
            break;
        }
    }

    str[i] = '\0';

    if (i == 0 && c == EOF) {
        return NULL;
    }

    return str;
}

struct List* createListNode() {
    struct List* newNode = (struct List*)malloc(sizeof(struct List));
    int i;
    for (i = 0; i < SIZE; i++) {
        newNode->section_arr[i].selectors = NULL;
        newNode->section_arr[i].attributes = NULL;
        newNode->section_arr[i].number = NULL;
    }
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

void addListNode(struct List** head, struct List* newNode) {
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    struct List* lastNode = *head;
    while (lastNode->next != NULL) {
        lastNode = lastNode->next;
    }
    lastNode->next = newNode;
    newNode->prev = lastNode;
}

struct Attribute* createAttributeNode(char* name, char* value) {
    struct Attribute* newNode = (struct Attribute*)malloc(sizeof(struct Attribute));
    strcpy(newNode->name, name);
    strcpy(newNode->value, value);
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

void addAttributeNode(struct Attribute** head, struct Attribute* newNode) {
    if (*head == NULL) {
        *head = newNode;
    }
    else {
        struct Attribute* lastNode = *head;
        while (lastNode->next != NULL) {
            lastNode = lastNode->next;
        }
        lastNode->next = newNode;
        newNode->prev = lastNode;
    }
}

struct Selector* createSelectorNode(char* selectorName) {
    struct Selector* newNode = (struct Selector*)malloc(sizeof(struct Selector));
    strcpy(newNode->name, selectorName);
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

void addSelectorNode(struct Selector** head, struct Selector* newNode) {
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    struct Selector* lastNode = *head;
    while (lastNode->next != NULL) {
        lastNode = lastNode->next;
    }
    lastNode->next = newNode;
    newNode->prev = lastNode;
}

void read_selector(char* arr, char temp, struct Data* data) {
    switch (temp) {
    case ',': {
        arr[data->i] = '\0';
        data->i = 0;
        remove_extreme_whitespace(arr);

        if (!selector_exists(data->sel_head, arr)) {
            Selector* newNode = createSelectorNode(arr);
            addSelectorNode(&data->sel_head, newNode);
        }
        struct List* curr = data->head;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->section_arr[data->current_section].selectors = data->sel_head;
    }
            break;
    case '{': {
        arr[data->i] = '\0';
        data->i = 0;
        remove_extreme_whitespace(arr);

        if (!selector_exists(data->sel_head, arr)) {
            if (strcmp(arr, "\0") != 0) {
                Selector* newNode = createSelectorNode(arr);
                addSelectorNode(&data->sel_head, newNode);
            }
        }

        struct List* curr = data->head;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->section_arr[data->current_section].number = data->section_number;
        curr->section_arr[data->current_section].selectors = data->sel_head;
        data->reading_attribute = true;
        data->reading_selector = false;
        data->sel_head = NULL;
    }
            break;
    default:
        arr[data->i++] = temp;
        break;
    }
}

bool selector_exists(Selector* head, char* name) {
    Selector* curr = head;
    while (curr != NULL) {
        if (strcmp(curr->name, name) == 0) {
            return true;
        }
        curr = curr->next;
    }
    return false;
}

void read_attribute(char* arr, char* name, char* value, char temp, struct Data* data) {
    if (data->r_att_name == true) {
        if (!isspace(temp)) {
            switch (temp) {
            case '\n':
                break;
            case '}':
                break;
            case '{':
                break;
            case ':':
                arr[data->i] = '\0';
                data->i = 0;
                strcpy(name, arr);
                data->r_att_name = false;
                data->want_to_read_value = true;
                break;
            default:
                arr[data->i++] = temp;
                break;
            }
        }
    }
    else if (data->want_to_read_value == true) {
        switch (temp) {
        case ' ':
            break;
        case '\n':
            break;
        default:
            data->r_att_val = true;
            data->want_to_read_value = false;
            break;
        }
    }
    if (data->r_att_val == true && data->want_to_read_value == false) {
        switch (temp) {
        case '\n':
            break;
        case '}':
            break;
        case ';': {
            arr[data->i] = '\0';
            data->i = 0;
            strcpy(value, arr);
            Attribute* attribute_ptr = data->att_head;
            while (attribute_ptr != NULL) {
                if (strcmp(attribute_ptr->name, name) == 0) {
                    strcpy(attribute_ptr->value, value);
                    break;
                }
                attribute_ptr = attribute_ptr->next;
            }
            if (attribute_ptr == NULL) {
                Attribute* newNode = createAttributeNode(name, value);
                addAttributeNode(&data->att_head, newNode);
            }
            struct List* curr = data->head;
            while (curr->next != NULL) {
                curr = curr->next;
            }
            curr->section_arr[data->current_section].attributes = data->att_head;
            curr->in = data->current_section;
            data->r_att_name = true;
            data->r_att_val = false;
        }    break;
        default:
            arr[data->i++] = temp;
            break;
        }
    }
    if (temp == '}') {
        data->reading_attribute = false;
        data->reading_selector = true;
        data->current_section++;
        data->section_number++;
        data->r_att_name = true;
        data->r_att_val = false;
        data->att_head = NULL;
        data->sel_head = NULL;
        if (data->current_section == SIZE) {
            data->create_listNode = true;
            data->current_section %= SIZE;
        }
    }
}

void match_pattern(const char* input, struct Data data, struct Data* data_r) {
    int num1, num2;
    char c1, c2;
    char arr1[TEXT_SIZE], arr2[TEXT_SIZE];
    if (sscanf(input, "%d,%c,%c", &num1, &c1, &c2) == 3 && c1 == 'S' && c2 == '?') {
        number_of_selectors(data.head, num1, data.section_number);
    }
    else if (sscanf(input, "%c", &c1) == 1 && c1 == '?') {
        printf("? == %d\n", data.section_number - 1);
    }
    else if (sscanf(input, "%d,%c,%c", &num1, &c1, &c2) == 3 && c1 == 'A' && c2 == '?') {
        number_of_attributes(data.head, num1, data.section_number);
    }
    else if (sscanf(input, "%d,%c,%d", &num1, &c1, &num2) == 3 && c1 == 'S') {
        print_selector_name(data.head, num1, num2, data.section_number);
    }
    else if (sscanf(input, "%d,%c,%s", &num1, &c1, arr1) == 3 && c1 == 'A') {
        value_of_attribute(data.head, num1, arr1, data.section_number);
    }
    else if (sscanf(input, "%[^,],%c,%c", arr1, &c1, &c2) == 3 && c1 == 'A' && c2 == '?') {
        count_attribute(data.head, arr1);
    }
    else if (sscanf(input, "%[^,],%c,%c", arr1, &c1, &c2) == 3 && c1 == 'S' && c2 == '?') {
        count_selectors(data.head, arr1);
    }
    else if (sscanf(input, "%[^,],%c,%s", arr1, &c1, arr2) == 3 && c1 == 'E') {
        find_last_matching_attribute(data.head, arr1, arr2);
    }
    else if (sscanf(input, "%d,%c,%c", &num1, &c1, &c2) == 3 && c1 == 'D' && c2 == '*') {
        delete_section(data.head, num1, data_r);
    }
    else if (sscanf(input, "%d,%c,%s", &num1, &c1, arr1) == 3 && c1 == 'D') {
        delete_attribute(data.head, num1, arr1);
        no_attribute_delete(data.head, num1, data_r);
    }

    else if (strcmp(input, "****") == 0) {
        data_r->commands = false;
        data_r->sel_head = NULL;
        data_r->att_head = NULL;
        data_r->i = 0;
        data_r->reading_selector = true;
        data_r->reading_attribute = false;
        data_r->r_att_name = true;
        data_r->r_att_val = false;
        data_r->want_to_read_value = false;
        data_r->question_mark_count = 0;
    }
}

void number_of_selectors(struct List* list, int section_number, int max_number_in) {
    if (section_number > max_number_in - 1) {
        return;
    }
    struct List* list_ptr = list;
    struct Section* section_ptr = list->section_arr;
    while (list_ptr != NULL) {
        for (int i = 0; i < SIZE; i++) {
            if (section_ptr->number == section_number) {
                // petla liczaca selektoroy wlasciwej sekcji
                int count = 0;
                struct Selector* selector_ptr = section_ptr->selectors;
                while (selector_ptr != NULL) {
                    count++;
                    selector_ptr = selector_ptr->next;
                }
                printf("%d,S,? == %d\n", section_number, count);
                return;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
        section_ptr = list_ptr->section_arr;
    }
}

void number_of_attributes(struct List* list, int section_number, int max_number_in) {
    if (section_number > max_number_in - 1) {
        return;
    }
    struct List* list_ptr = list;
    struct Section* section_ptr = list->section_arr;
    while (list_ptr != NULL) {
        for (int i = 0; i < SIZE; i++) {
            if (section_ptr->number == section_number) {
                // szukanie wlasciwej sekcji i w niej liczenie atrybutow
                int count = 0;
                struct Attribute* attribute_ptr = section_ptr->attributes;
                while (attribute_ptr != NULL) {
                    count++;
                    attribute_ptr = attribute_ptr->next;
                }
                printf("%d,A,? == %d\n", section_number, count);
                return;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
        section_ptr = list_ptr->section_arr;
    }
}

void print_selector_name(struct List* list, int section_number, int selector_index, int max_number_in) {
    if (section_number > max_number_in - 1) {
        return;
    }
    struct List* list_ptr = list;
    struct Section* section_ptr = list->section_arr;
    while (list_ptr != NULL) {
        for (int i = 0; i < SIZE; i++) {
            if (section_ptr->number == section_number) {
                // znajdowanie selektora we wlasciwej sekcji po indeksie
                struct Selector* selector_ptr = section_ptr->selectors;
                for (int j = 0; j < selector_index - 1 && selector_ptr != NULL; j++) {
                    selector_ptr = selector_ptr->next;
                }
                if (selector_ptr != NULL) {
                    printf("%d,S,%d == %s\n", section_number, selector_index, selector_ptr->name);
                }
                return;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
        section_ptr = list_ptr->section_arr;
    }
}

void value_of_attribute(struct List* list, int section_number, char* attribute_name, int max_number_in) {
    if (section_number > max_number_in - 1) {
        return;
    }
    struct List* list_ptr = list;
    struct Section* section_ptr = list->section_arr;
    while (list_ptr != NULL) {
        for (int i = 0; i < SIZE; i++) {
            if (section_ptr->number == section_number) {
                // szukanie w sekcji atrybutu po nazwie i zwracanie jego value
                struct Attribute* attribute_ptr = section_ptr->attributes;
                while (attribute_ptr != NULL) {
                    if (strcmp(attribute_ptr->name, attribute_name) == 0) {
                        printf("%d,A,%s == %s\n", section_number, attribute_name, attribute_ptr->value);
                        return;
                    }
                    attribute_ptr = attribute_ptr->next;
                }
                return;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
        section_ptr = list_ptr->section_arr;
    }
}

void count_attribute(struct List* list, char* attribute_name) {
    int count = 0;
    // po calej liscie sprawdzenie ile jest atr o attr_name
    struct List* list_ptr = list;
    while (list_ptr != NULL) {
        struct Section* section_ptr = list_ptr->section_arr;
        for (int i = 0; i < SIZE; i++) {
            struct Attribute* attr_ptr = section_ptr->attributes;
            while (attr_ptr != NULL) {
                if (strcmp(attr_ptr->name, attribute_name) == 0) {
                    count++;
                }
                attr_ptr = attr_ptr->next;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
    }
    printf("%s,A,? == %d\n", attribute_name, count);
}

void count_selectors(struct List* list, char* selector_name) {
    int count = 0;
    // liczenie selektorow o sel_name
    struct List* list_ptr = list;
    while (list_ptr != NULL) {
        struct Section* section_ptr = list_ptr->section_arr;
        for (int i = 0; i < SIZE; i++) {
            struct Selector* selector_ptr = section_ptr->selectors;
            while (selector_ptr != NULL) {
                if (strcmp(selector_ptr->name, selector_name) == 0) {
                    count++;
                }
                selector_ptr = selector_ptr->next;
            }
            section_ptr++;
        }
        list_ptr = list_ptr->next;
    }
    printf("%s,S,? == %d\n", selector_name, count);
}

void find_last_matching_attribute(struct List* list, char* sel_name, char* att_name) {
    struct List* list_ptr = list;
    // sprawdzanie od konca czy jest selektor z danym atrybutem w sekcji
    while (list_ptr->next != NULL) {
        list_ptr = list_ptr->next;
    }
    while (list_ptr != NULL) {
        for (int i = SIZE - 1; i >= 0; i--) {
            struct Selector* sel_ptr = list_ptr->section_arr[i].selectors;
            while (sel_ptr != NULL) {
                if (strcmp(sel_ptr->name, sel_name) == 0) {
                    struct Attribute* att_ptr = list_ptr->section_arr[i].attributes;
                    while (att_ptr != NULL) {
                        if (strcmp(att_ptr->name, att_name) == 0) {
                            printf("%s,E,%s == %s\n", sel_name, att_name, att_ptr->value);
                            return;
                        }
                        att_ptr = att_ptr->next;
                    }
                }
                sel_ptr = sel_ptr->next;
            }
        }
        list_ptr = list_ptr->prev;
    }
}

void delete_section(struct List* head, int section_num, Data* data) {
    struct List* curr = head;
    bool zmniejsz_o_jeden_nastepne = false;
    while (curr != NULL) {
        struct Section* section_arr = curr->section_arr;
        for (int i = 0; i < SIZE; i++) {
            if (section_arr[i].number == section_num) {

                freeAttributeList(section_arr[i].attributes);
                freeSelectorList(section_arr[i].selectors);
                section_arr[i].number = NULL;
                section_arr[i].selectors = NULL;
                section_arr[i].attributes = NULL;
                zmniejsz_o_jeden_nastepne = true;
                data->section_number--;
                curr->in--;
                printf("%d,D,* == deleted\n", section_num);
            }
            if (zmniejsz_o_jeden_nastepne == true && section_arr[i].attributes != NULL) {
                section_arr[i].number--;
            }
        }
        curr = curr->next;
    }
}

void freeAttributeList(struct Attribute* head) {
    struct Attribute* curr = head;
    struct Attribute* temp;
    while (curr != NULL) {
        temp = curr;
        curr = curr->next;
        free(temp);
    }
}

void freeSelectorList(struct Selector* head) {
    struct Selector* curr = head;
    struct Selector* temp;
    while (curr != NULL) {
        temp = curr;
        curr = curr->next;
        free(temp);
    }
}

void delete_attribute(struct List* head, int section_num, char* attr_name) {
    struct List* curr = head;
    while (curr != NULL) {
        struct Section* section_arr = curr->section_arr;
        for (int i = 0; i < SIZE; i++) {
            if (section_arr[i].number == section_num) {
                struct Attribute* attribute_ptr = section_arr[i].attributes;
                while (attribute_ptr != NULL) {
                    if (strcmp(attribute_ptr->name, attr_name) == 0) {
                        if (attribute_ptr->prev != NULL) {
                            attribute_ptr->prev->next = attribute_ptr->next;
                        }
                        else {
                            section_arr[i].attributes = attribute_ptr->next;
                        }
                        if (attribute_ptr->next != NULL) {
                            attribute_ptr->next->prev = attribute_ptr->prev;
                        }
                        free(attribute_ptr);
                        printf("%d,D,%s == deleted\n", section_num, attr_name);
                        return;
                    }
                    attribute_ptr = attribute_ptr->next;
                }
            }
        }
        curr = curr->next;
    }
}

void no_attribute_delete(struct List* head, int section_num, Data* data) {
    struct List* curr = head;
    bool zmniejsz_o_jeden_nastepne = false;
    while (curr != NULL) {
        struct Section* section_arr = curr->section_arr;
        for (int i = 0; i < SIZE; i++) {
            if (section_arr[i].number == section_num && section_arr[i].attributes == NULL) {
                // usuwanie sekcji jak nie ma atrybutow
                freeAttributeList(section_arr[i].attributes);
                freeSelectorList(section_arr[i].selectors);
                section_arr[i].number = NULL;
                section_arr[i].selectors = NULL;
                section_arr[i].attributes = NULL;
                zmniejsz_o_jeden_nastepne = true;
                data->section_number--;
                curr->in--;
            }
            if (zmniejsz_o_jeden_nastepne == true && section_arr[i].attributes != NULL) {
                section_arr[i].number--;
            }
        }
        curr = curr->next;
    }
}

void free_empty_block(struct List* node, Data* data) {

    if (node->prev != NULL) {
        node->prev->next = node->next;
    }
    if (node->next != NULL) {
        node->next->prev = node->prev;
    }
    if (node->next != NULL && node->prev == NULL) {
        data->head = node->next;
    }
    if (node->next == NULL) {
        data->create_listNode = true;
        data->current_section = 0;
    }
    free(node);
}

void search_for_empty(struct List* node, Data* data) {
    List* current = node;
    while (current != NULL) {
        if (current->in == -1) {
            free_empty_block(current, data);
            return;
        }
        current = current->next;
    }
}



int main() {
    char temp;
    char arr[TEXT_SIZE];
    char att_name[TEXT_SIZE];
    char att_value[TEXT_SIZE];
    int len;
    Data data;
    bool continue_loop = true;

    while (continue_loop) {

        if (data.commands == false) {
            temp = getchar();
            if (temp == EOF) { continue_loop = false; }
            if (!isspace(temp) && data.create_listNode == true) {
                List* newNode = createListNode();
                addListNode(&data.head, newNode);
                data.create_listNode = false;
            }
            if (data.reading_selector == true) {
                read_selector(arr, temp, &data);
            }
            if (data.reading_attribute == true) {
                read_attribute(arr, att_name, att_value, temp, &data);
            }

            if (temp == '?' && data.question_mark_count < 3) {
                data.question_mark_count++;
            }
            else if (temp == '?' && data.question_mark_count == 3) {
                data.commands = true;
                memset(arr, '\0', sizeof(arr));
                data.question_mark_count = 0;
            }
            else {
                data.question_mark_count = 0;
            }
        }
        if (data.commands == true) {

            match_pattern(arr, data, &data);
            search_for_empty(data.head, &data);

            if (data.commands == true) {
                if (my_fgets(arr, TEXT_SIZE, stdin) == NULL && feof(stdin)) {
                    continue_loop = false;
                }
                else {
                    len = strlen(arr);
                    if (len > 0 && arr[len - 1] == '\n') {
                        arr[len - 1] = '\0';
                    }
                }
            }
        }


    }
}
