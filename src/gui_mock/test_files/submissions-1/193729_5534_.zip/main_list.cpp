#include"attribute_list.cpp"
using namespace std;

class Section {
public:
    Selector_list* selector_list;
    Attribute_list* attribute_list;

    Section()
    {
        selector_list = NULL;
        attribute_list = NULL;
    }
};

const int block_size = 11;

class Main_node {
public:
    Section section[block_size];
    Main_node* next;
    Main_node* prev;

    Main_node()
    {
        next = NULL;
        prev = NULL;
    }
};



class Main_list {
public:
    Main_node* head;
    int node_number;


    Main_list()
    {
        head = NULL;
        node_number = 0;
    }

    void insertSelector(const Strin& selector, int tab_position)
    {
        if ((node_number + 1) * block_size < tab_position)
        {
            cout << "position too high" << endl;
            return;
        }

        if (node_number * block_size <= tab_position)
        {
            this->newNode();
        }

        Main_node* temp1 = head;
        int index = tab_position % block_size;
        for (int i = 0; i < tab_position / block_size; i++)
        {
            temp1 = temp1->next;
        }

        if (temp1->section[index].selector_list == NULL)
        {
            Selector_list* new_list = new Selector_list;
            temp1->section[index].selector_list = new_list;
        }

        temp1->section[index].selector_list->insertNode(selector);

    }

    void insertAttribute(const Strin& attribute, const Strin& value, int tab_position)
    {
        if ((node_number + 1) * block_size < tab_position)
        {
            cout << "position too high" << endl;
            return;
        }

        if (node_number * block_size <= tab_position)
        {
            this->newNode();
        }

        Main_node* temp1 = head;
        int index = tab_position % block_size;
        for (int i = 0; i < tab_position / block_size; i++)
        {
            temp1 = temp1->next;
        }

        if (temp1->section[index].attribute_list == NULL)
        {
            Attribute_list* new_list = new Attribute_list;
            temp1->section[index].attribute_list = new_list;
        }

        temp1->section[index].attribute_list->insertNode(attribute, value);

    }

    void newNode()
    {
        Main_node* new_node = new Main_node;

        //Assign as head if list is empty
        if (head == NULL)
        {
            head = new_node;
            return;
        }

        //travel to the end of list
        Main_node* temp1 = head;
        while (temp1->next != NULL)
        {
            temp1 = temp1->next;
        }

        // Insert as the last node
        temp1->next = new_node;
        new_node->prev = temp1;
        node_number++;
    }

    int getSectionAmmount()
    {
        int ammount = 0;
        Main_node* temp1 = head;

        while (temp1 != NULL)
        {
            for (int i = 0; i < block_size; i++)
            {
                if (temp1->section[i].attribute_list != NULL)
                {
                    ammount++;
                }
            }
            temp1 = temp1->next;
        }

        return ammount;
    }

    int getSelectorAmmount(int tab_position)
    {
        if ((node_number) * block_size < tab_position)
        {
            //cout << "position too high" << endl;
            return -1;
        }

        Main_node* temp1 = head;
        int index = 0;
        int position = 0;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
                position++;
            }
            index++;
            position++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > (node_number) * block_size)
            {
                return -1;
            }
        }
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;

            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > (node_number) * block_size)
            {
                return -1;
            }
        }



        if (temp1->section[index].attribute_list == nullptr)
        {
            return -1;
        }

        return temp1->section[index].selector_list->getAmmount();
    }

    int getSelectorAmmount(Strin selector_name)
    {
        Main_node* temp1 = head;
        int number = 0;
        for (int i = 0; i < node_number; i++)
        {
            for (int j = 0; j < block_size; j++)
            {
                if (temp1->section[j].selector_list != NULL)
                    number += temp1->section[j].selector_list->getAmmount(selector_name);
            }
            temp1 = temp1->next;
        }

        return number;
    }

    Strin getSelector(int tab_position, int selector_position)
    {
        if ((node_number) * block_size < tab_position)
        {
            //cout << "position too high" << endl;
            return "";
        }

        Main_node* temp1 = head;
        int index = 0;
        int position = 0;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
                position++;
            }
            index++;
            position++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > (node_number) * block_size)
            {
                return "";
            }
        }
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;

            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > (node_number) * block_size)
            {
                return "";
            }
        }



        if (temp1->section[index].attribute_list == NULL)
        {
            return "";
        }

        return temp1->section[index].selector_list->getSelector(selector_position);
    }

    int getAttributeAmmount(int tab_position)
    {
        Main_node* temp1 = head;
        int index = 0;
        int position = 0;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
                position++;
            }
            index++;
            position++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > node_number * block_size)
            {
                return -1;
            }
        }

        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;

            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > (node_number) * block_size)
            {
                return -1;
            }
        }


        if (temp1->section[index].attribute_list == nullptr)
        {
            return -1;
        }

        return temp1->section[index].attribute_list->getAmmount();
    }

    int getAttributeAmmount(Strin attribute_name)
    {
        Main_node* temp1 = head;
        int number = 0;
        for (int i = 0; i < node_number; i++)
        {
            for (int j = 0; j < block_size; j++)
            {
                if (temp1->section[j].attribute_list != NULL)
                    number += temp1->section[j].attribute_list->getAmmount(attribute_name);
            }
            temp1 = temp1->next;
        }

        return number;
    }

    Strin getValue(int tab_position, Strin attribute_name)
    {
        if ((node_number + 1) * block_size < tab_position)
        {
            //cout << "position too high" << endl;
            return "";
        }

        Main_node* temp1 = head;
        int index = 0;
        int position = 0;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
                position++;
            }
            index++;
            position++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
            if (position > node_number * block_size)
            {
                return "";
            }
        }

        if (temp1->section[index].attribute_list == NULL)
        {
            index++;
            position++;
        }
        if (index >= block_size)
        {
            temp1 = temp1->next;
            index -= block_size;
        }
        if (position > (node_number) * block_size)
        {
            return "";
        }

        if (temp1->section[index].attribute_list == nullptr)
        {
            return "";
        }

        return temp1->section[index].attribute_list->getValue(attribute_name);
    }

    Strin getValue(Strin selector_name, Strin attribute_name)
    {
        Main_node* temp1 = head;
        int number = 0;
        Strin value_returned = "";
        for (int i = 0; i < node_number; i++)
        {
            for (int j = 0; j < block_size; j++)
            {
                if (temp1->section[j].selector_list != NULL)
                {
                    number = temp1->section[j].selector_list->getAmmount(selector_name);
                    if (number != 0)
                    {
                        value_returned = temp1->section[j].attribute_list->getValue(attribute_name);
                    }
                }
            }
            temp1 = temp1->next;
        }

        return value_returned;
    }

    bool deleteSection(int tab_position, int* attributes, int* selectors)
    {
        bool empty = true;
        bool deleted = false;
        static int highest = 0;
        if (node_number * block_size < tab_position)
        {
            //cout << "position too high";
            return false;
        }

        Main_node* temp1 = head;
        int index = 0;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
            }
            index++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
        }
        if (temp1->section[index].attribute_list == NULL)
        {
            index++;
        }
        if (index >= block_size)
        {
            temp1 = temp1->next;
            index -= block_size;
        }

        if (temp1->section[index].selector_list != NULL)
        {
            delete temp1->section[index].selector_list;
            temp1->section[index].selector_list = NULL;
            deleted = true;
        }
        if (temp1->section[index].attribute_list != NULL)
        {
            delete temp1->section[index].attribute_list;
            temp1->section[index].attribute_list = NULL;
            deleted = true;
        }

        if (index > highest)
        {
            highest = index;
        }

        for (int i = 0; i < block_size; i++)
        {
            if (temp1->section[i].attribute_list != NULL)
            {
                empty = false;
            }
        }
        if (empty)
        {
            if (temp1->next != NULL)
            {
                *attributes -= block_size;
                *selectors -= block_size;
                highest = 0;
            }
            else
            {
                *attributes -= (highest + 1);
                *selectors -= (highest + 1);
            }
            this->deleteNode(tab_position / block_size);
        }
        return deleted;
    }

    bool deleteAttribute(int tab_position, Strin attribute_name, int* attributes, int* selectors)
    {
        if (node_number * block_size < tab_position)
        {
            //cout << "position too high";
            return false;
        }

        Main_node* temp1 = head;
        int index = 0;
        int deleted = false;
        while (temp1->section[index].attribute_list == NULL)
        {
            index++;
        }
        for (int i = 0; i < tab_position; i++)
        {

            if (temp1->section[index].attribute_list == NULL)
            {
                index++;
            }
            index++;
            if (index >= block_size)
            {
                temp1 = temp1->next;
                index -= block_size;
            }
        }

        if (temp1->section[index].attribute_list == NULL)
        {
            index++;
        }
        if (index >= block_size)
        {
            temp1 = temp1->next;
            index -= block_size;
        }


        if (temp1->section[index].attribute_list != NULL)
        {
            deleted = temp1->section[index].attribute_list->deleteNode(attribute_name);

            if (temp1->section[index].attribute_list->head == NULL)
            {
                this->deleteSection(tab_position, attributes, selectors);
            }
            return deleted;
        }
        return false;
    }

    void deleteNode(int node_position)
    {
        node_position++;
        Main_node* temp1 = head;
        Main_node* temp2 = NULL;
        Main_node* temp3 = NULL;
        int list_lenght = 0;

        if (head == NULL)
        {
            cout << "List empty." << endl;
            return;
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //Is the element to be deleten in the list
        if (list_lenght < node_position)
        {
            cout << "Element doesn't exist" << endl;
            return;
        }
        //reset 1st node
        temp1 = head;
        node_number--;
        //deleting the head
        if (node_position == 1)
        {
            //new head
            head = head->next;
            head->prev = NULL;
            delete temp1;
            return;
        }

        //find the node to delete
        while (node_position-- > 1)
        {
            temp2 = temp1;
            temp1 = temp1->next;
            temp3 = temp1->next;
        }

        //update the pointers
        temp2->next = temp1->next;
        temp3->prev = temp1->prev;

        delete temp1;
    }
};
