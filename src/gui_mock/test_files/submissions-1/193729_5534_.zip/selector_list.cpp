#include <iostream>
#include "strin.cpp"
using namespace std;


class Selector_node {
public:
    Strin selector;
    Selector_node* next;
    Selector_node* prev;

    Selector_node()
    {
        selector = "";
        next = NULL;
        prev = NULL;
    }

    Selector_node(const Strin& selector)
    {
        this->selector = selector;
        this->next = NULL;
        prev = NULL;
    }


};


class Selector_list {
    

public:
    Selector_node* head;

    Selector_list() 
    { 
        head = NULL; 
    }

    void insertNode(const Strin& selector)
    {
        Selector_node* new_node = new Selector_node(selector);

        //Assign as head if list is empty
        if (head == NULL)
        {
            head = new_node;
            return;
        }

        //travel to the end of list
        Selector_node* temp1 = head;
        while (temp1->next != NULL)
        {
            //check if attribute already exists and update value
            if (temp1->selector == selector)
            {
                return;
            }
            temp1 = temp1->next;
        }
        if (temp1->selector == selector)
        {
            return;
        }

        // Insert as the last node
        temp1->next = new_node;
        new_node->prev = temp1;
    }

    void insertNode(const Strin& selector, int node_position)
    {
        Selector_node* new_node = new Selector_node(selector);
        Selector_node* temp1 = head;
        Selector_node* temp2 = NULL;
        int list_lenght = 0;

        //length of the list.
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }
        //reset 1st node
        temp1 = head;

        //check if it's possible to add a node in the desired location
        if (list_lenght + 1 < node_position)
        {
            cout << "position too large" << endl;
            return;
        }

        if (node_position == 1)
        {
            new_node->next = head;
            head = new_node;
            return;
        }

        //travel to the desired location
        while (node_position-- > 2)
        {
            temp1 = temp1->next;
        }
        temp2 = temp1->next;

        // Insert as the last node
        new_node->next = temp2;
        temp2->prev = new_node;
        temp1->next = new_node;
        new_node->prev = temp1;
    }

    void printList()
    {
        Selector_node* temp1 = head;

        // Check if list is empty
        if (head == NULL) 
        {
            cout << "List empty" << endl;
            return;
        }

        //travel the list printing every node
        while (temp1 != NULL)
        {
            temp1->selector.print();
            temp1 = temp1->next;
        }
    }

    void printListNode(int node_position)
    {
        Selector_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL) 
        {
            cout << "List empty" << endl;
            return;
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //check if it's possible to print node in the desired location
        if (list_lenght < node_position)
        {
            cout << "position too large" << endl;
            return;
        }

        //travel the list to the desired node
        while (node_position-- > 1)
        {
            temp1 = temp1->next;
        }
        temp1->selector.print();
    }

    Strin getSelector(int node_position)
    {
        if (this == NULL)
        {
            return "";
        }
        Selector_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL)
        {
            //cout << "List empty" << endl;
            return "";
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //check if it's possible to print node in the desired location
        if (list_lenght < node_position)
        {
            //cout << "position too large" << endl;
            return "";
        }

        temp1 = head;

        //travel the list to the desired node
        while (node_position-- > 1)
        {
            temp1 = temp1->next;
        }
        return temp1->selector;
    }

    int getAmmount()
    {
        if (this == NULL)
        {
            return 0;
        }
        Selector_node* temp1 = head;
        int ammount = 0;
        while (temp1 != NULL) 
        {
            ammount++;
            temp1 = temp1->next;
        }
        return ammount;
    }

    int getAmmount(Strin selector_name)
    {
        Selector_node* temp1 = head;
        int ammount = 0;
        while (temp1 != NULL)
        {
            if (temp1->selector == selector_name)
                ammount++;
            temp1 = temp1->next;
        }
        return ammount;
    }

    void deleteNode(int node_position)
    {
        Selector_node* temp1 = head;
        Selector_node* temp2 = NULL;
        Selector_node* temp3 = NULL;
        int list_lenght = 0;

        if (head == NULL)
        {
            cout << "List empty." << endl;
            return;
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //Is the element to be deleten in the list
        if (list_lenght < node_position)
        {
            cout << "Element doesn't exist" << endl;
            return;
        }

        temp1 = head;

        //deleting the head
        if (node_position == 1)
        {
            //new head
            head = head->next;
            head->prev = NULL;
            delete temp1;
            return;
        }

        //find the node to delete
        while (node_position-- > 1)
        {
            temp2 = temp1;
            temp1 = temp1->next;
            temp3 = temp1->next;
        }

        //update the pointers
        temp2->next = temp1->next;
        temp3->prev = temp1->prev;

        delete temp1;
    }

    ~Selector_list()
    {
        Selector_node* tmp1 = nullptr;
        while (head != nullptr)
        {
            tmp1 = head;
            head = head->next;
            delete tmp1;
        }
    }
};
