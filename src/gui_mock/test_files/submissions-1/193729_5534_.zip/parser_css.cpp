#include "main_list.cpp"
#include <iostream>
using namespace std;

void saveSelector(Main_list& list, int* saving_place, char current, Strin& buffer, int& selectors)
{
    if (current != '{' && current != ',' && current != '\n')
    {
        buffer.push(current);
    }
    else if (current == ',')
    {
        list.insertSelector(buffer, selectors);
        buffer = "";

    }
    else if (current == '{')
    {
        buffer.popSpaces();
        if (selectors < 0)
            selectors = 0;
        if (buffer != "")
        {
            list.insertSelector(buffer, selectors);
        }
        buffer = "";
        selectors++;
        *saving_place = 2;

    }
}

void saveAttribute(Main_list& list, int* saving_place, char current, Strin& buffer, Strin& attribute1, int& attributes)
{
    if (current != ':' && current != '}' && current != '\n')
    {
        buffer.push(current);
    }
    else if (current == ':')
    {
        buffer.popSpaces();
        attribute1 = buffer;
        buffer = "";
        *saving_place = 3;
    }
    else if (current == '}')
    {
        buffer = "";
        if (attributes < 0)
            attributes = 0;
        attributes++;
        *saving_place = 1;

    }
}

void saveValue(Main_list& list, int* saving_place, char current, Strin& buffer, Strin& attribute1, int& attributes)
{
    if (current != '}' && current != ';' && current != '\n')
    {
        buffer.push(current);
    }
    else if (current == ';')
    {
        if (attributes < 0)
        {
            attributes = 0;
        }
        list.insertAttribute(attribute1, buffer, attributes);
        buffer = "";
        *saving_place = 2;
    }
    else if (current == '}')
    {
        if (attributes < 0)
        {
            attributes = 0;
        }
        buffer.popSpaces();
        list.insertAttribute(attribute1, buffer, attributes);
        attribute1 = "";
        buffer = "";
        attributes++;
        *saving_place = 1;
    }
}

void saveToList(Main_list& list, char current, bool* saving, bool* commands, int* attributes, int* selectors)
{
    static int counter = 0;
    static Strin buffer;
    static Strin attribute1;
    static int saving_place = 1; //1 - selector, 2 - attribute, 3 - value;

    if (buffer == "" && (isspace(current) || current == '\n'))
    {
        return;
    }

    if (current == '?')
    {
        counter++;
    }
    else
    {
        counter = 0;
    }

    if (saving_place == 1)
    {
        saveSelector(list, &saving_place, current, buffer, *selectors);
    }
    else if (saving_place == 2)
    {
        saveAttribute(list, &saving_place, current, buffer, attribute1, *attributes);
    }
    else if (saving_place == 3)
    {
        saveValue(list, &saving_place, current, buffer, attribute1, *attributes);
    }

    if (counter == 4)
    {
        buffer = "";
        *saving = false;
        *commands = true;
    }

}

void execute(Strin part[], Main_list& list, int* attributes, int* selectors)
{
    if (part[0] == "?")
    {
        cout << "? == " << list.getSectionAmmount() << endl;
    }
    else if (part[1] == "S")
    {
        if (part[2] == "?")
        {
            if (part[0].isNumber())
            {
                if (list.getSelectorAmmount(part[0].getNumber() - 1) != -1)
                    cout << part[0].getNumber() << ",S,? == " << list.getSelectorAmmount(part[0].getNumber() - 1) << endl;
            }
            else
            {
                int number = 0;
                number += list.getSelectorAmmount(part[0]);
                part[0].print();
                cout << ",S,? == " << number << endl;
            }
        }
        else
        {
            if (list.getSelector(part[0].getNumber() - 1, part[2].getNumber()) != "")
            {
                cout << part[0].getNumber() << ",S," << part[2].getNumber() << " == ";
                list.getSelector(part[0].getNumber() - 1, part[2].getNumber()).print();
                cout << endl;
            }
        }
    }
    else if (part[1] == "A")
    {
        if (part[2] == "?")
        {
            if (part[0].isNumber())
            {
                if (list.getAttributeAmmount(part[0].getNumber() - 1) != -1)
                    cout << part[0].getNumber() << ",A,? == " << list.getAttributeAmmount(part[0].getNumber() - 1) << endl;
            }
            else
            {
                int number = 0;
                number += list.getAttributeAmmount(part[0]);
                part[0].print();
                cout << ",A,? == " << number << endl;
            }
        }
        else
        {
            if (list.getValue(part[0].getNumber() - 1, part[2]) != "")
            {
                cout << part[0].getNumber() << ",A,";
                part[2].print();
                cout << " == ";
                list.getValue(part[0].getNumber() - 1, part[2]).print();
                cout << endl;
            }
        }
    }
    else if (part[1] == "E")
    {
        if (list.getValue(part[0], part[2]) != "")
        {
            part[0].print();
            cout << ",E,";
            part[2].print();
            cout << " == ";
            list.getValue(part[0], part[2]).print();
            cout << endl;
        }
    }
    else if (part[1] == "D")
    {
        if (part[2] == "*")
        {
            if (list.deleteSection(part[0].getNumber() - 1, attributes, selectors))
            {
                cout << part[0].getNumber() << ",D,* == deleted" << endl;
            }
        }
        else
        {
            if (list.deleteAttribute(part[0].getNumber() - 1, part[2], attributes, selectors))
            {
                cout << part[0].getNumber() << ",D,";
                part[2].print();
                cout << " == deleted" << endl;
            }
        }
    }
}

void executeCommands(Main_list& list, char current, bool* saving, bool* commands, int* attributes, int* selectors)
{
    static int index = 0;
    static Strin part[3];
    static int counter = 0;
    static bool exec = false;

    if (current == '*')
    {
        counter++;
    }
    else
    {
        counter = 0;
    }

    if (current == '\n')
    {
        if (exec == true)
        {
            part[0].popSpaces();
            part[1].popSpaces();
            part[2].popSpaces();
            execute(part, list, attributes, selectors);
        }
        index = 0;
        part[0] = "";
        part[1] = "";
        part[2] = "";
        exec = true;
    }
    else if (current == ',')
    {
        index++;
    }
    else if (index < 3)
    {
        part[index].push(current);
    }

    if (index > 3)
    {
        exec = false;
    }

    if (counter == 4)
    {
        part[0] = "";
        part[1] = "";
        part[2] = "";
        *saving = true;
        *commands = false;
    }

}

int main()
{
    bool commands = false;
    bool saving = true;
    Main_list list;
    char current;
    int attributes = 0;
    int selectors = 0;
    while (cin.get(current))
    {
        if (saving == true)
        {
            saveToList(list, current, &saving, &commands, &attributes, &selectors);
            continue;
        }

        if (commands == true)
            executeCommands(list, current, &saving, &commands, &attributes, &selectors);
    }

    current = '\n';
    executeCommands(list, current, &saving, &commands, &attributes, &selectors);
}
