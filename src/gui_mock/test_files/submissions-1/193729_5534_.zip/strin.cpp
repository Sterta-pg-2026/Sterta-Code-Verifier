#include <iostream>
using namespace std;

class Strin {
	friend ostream& operator<<(ostream& ostr, char& right);
	char* letters;
	size_t capacity;
	size_t holding;
public:
	Strin()
	{
		letters = new char[1];
		capacity = 1;
		holding = 0;
		//cout << this << "konstrukcja" << endl;
	}

	Strin(const char* data)
	{
		letters = new char[1];
		capacity = 1;
		holding = 0;
		int size = strlen(data);
		for (int i = 0; i < size; i++)
		{
			this->push(data[i]);
		}
		//cout << this << "konstrukcja" << endl;
	}

	Strin(const Strin& v)
	{
		letters = new char[v.capacity];
		capacity = v.capacity;
		holding = v.holding;

		for (int i = 0; i < holding; i++)
		{
			letters[i] = v.letters[i];
		}
	}

	char& operator[](size_t i)
	{
		return letters[i];
	}

	Strin& operator=(const Strin& v)
	{
		letters = new char[v.capacity];
		capacity = v.capacity;
		holding = v.holding;

		for (int i = 0; i < holding; i++)
		{
			letters[i] = v.letters[i];
		}
		return *this;
	}

	//comparing 2 strins
	bool operator==(const Strin& v)
	{
		if (holding != v.holding)
		{
			return false;
		}

		for (int i = 0; i < holding; i++)
		{
			if (letters[i] != v.letters[i])
			{
				return false;
			}
		}
		return true;
	}

	bool operator!=(const Strin& v)
	{
		if (holding != v.holding)
		{
			return true;
		}

		for (int i = 0; i < holding; i++)
		{
			if (letters[i] != v.letters[i])
			{
				return true;
			}
		}
		return false;
	}

	//adding new data to a strin
	void push(char data)
	{
		if (holding == capacity)
		{
			char* temporary = new char[2 * capacity];

			for (int i = 0; i < holding; i++)
			{
				temporary[i] = letters[i];
			}
			capacity = capacity * 2;
			delete[] letters;
			letters = temporary;
		}
		letters[holding] = data;
		holding++;
	}

	void pop()
	{
		letters[holding - 1] = '\0';
		holding--;
	}

	void popSpaces()
	{
		if (letters[holding - 1] > 0)
		{
			while (isspace(letters[holding - 1]) || letters[holding - 1] == '\n')
			{
				this->pop();
			}
		}
	}

	char getLast()
	{
		return letters[holding - 1];
	}

	bool isNumber()
	{
		for (int i = 0; i < holding; i++)
		{
			if (letters[i] > '9' || letters[i] < '0')
			{
				return false;
			}
		}
		return true;
	}

	int getNumber()
	{
		int number = 0;
		int multiplier = 1;
		for (int i = 0; i < holding; i++)
		{
			number += (letters[holding - i - 1] - 48) * multiplier;
			multiplier *= 10;
		}
		return number;
	}

	void push(const char* data)
	{
		int size = strlen(data);
		for (int i = 0; i < size; i++)
		{
			this->push(data[i]);
		}
	}

	void push(Strin& data)
	{
		int size = data.holding;
		for (int i = 0; i < size; i++)
		{
			this->push(data[i]);
		}
	}

	void print()
	{
		for (int i = 0; i < holding; i++)
		{
			cout << letters[i];
		}
	}

	~Strin()
	{
		//cout << this << "destrukcja" << endl;
		if (letters != nullptr)
		{
			delete[] letters;
		}
		
	}
};