#include "selector_list.cpp"
using namespace std;

class Attribute_node {
public:
    Strin attribute;
    Strin value;
    Attribute_node* next;
    Attribute_node* prev;

    Attribute_node()
    {
        attribute = "";
        value = "";
        next = NULL;
        prev = NULL;
    }

    Attribute_node(const Strin& attribute, const Strin& value)
    {
        this->attribute = attribute;
        this->value = value;
        this->next = NULL;
        prev = NULL;
    }


};


class Attribute_list {
    

public:
    Attribute_node* head;

    Attribute_list()
    {
        head = NULL;
    }

    void insertNode(const Strin& attribute, const Strin& value)
    {
        Attribute_node* new_node = new Attribute_node(attribute, value);

        //Assign as head if list is empty
        if (head == NULL)
        {
            head = new_node;
            return;
        }

        //travel to the end of list
        Attribute_node* temp1 = head;
        while (temp1->next != NULL)
        {
            //check if attribute already exists and update value
            if (temp1->attribute == attribute)
            {
                temp1->value = value;
                return;
            }
            temp1 = temp1->next;
        }
        if (temp1->attribute == attribute)
        {
            temp1->value = value;
            return;
        }

        // Insert as the last node
        temp1->next = new_node;
        new_node->prev = temp1;
    }

    void insertNode(const Strin& attribute, const Strin& value, int node_position)
    {
        Attribute_node* new_node = new Attribute_node(attribute, value);
        Attribute_node* temp1 = head;
        Attribute_node* temp2 = NULL;
        int list_lenght = 0;

        //length of the list.
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }
        //reset 1st node
        temp1 = head;

        //check if it's possible to add a node in the desired location
        if (list_lenght + 1 < node_position)
        {
            cout << "position too large" << endl;
            return;
        }

        if (node_position == 1)
        {
            new_node->next = head;
            head = new_node;
            return;
        }

        //travel to the desired location
        while (node_position-- > 2)
        {
            temp1 = temp1->next;
        }
        temp2 = temp1->next;


        // Insert as the last node
        new_node->next = temp2;
        temp2->prev = new_node;
        temp1->next = new_node;
        new_node->prev = temp1;
    }

    void printList()
    {
        Attribute_node* temp1 = head;

        // Check if list is empty
        if (head == NULL)
        {
            cout << "List empty" << endl;
            return;
        }

        //travel the list printing every node
        while (temp1 != nullptr) {
            temp1->attribute.print();
            cout << ": ";
            temp1->value.print();
            temp1 = temp1->next;
        }
    }

    void printListNode(int node_position)
    {
        Attribute_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL)
        {
            cout << "List empty" << endl;
            return;
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //check if it's possible to print node in the desired location
        if (list_lenght < node_position)
        {
            cout << "position too large" << endl;
            return;
        }

        //travel the list to the desired node
        while (node_position-- > 1)
        {
            temp1 = temp1->next;
        }
        temp1->attribute.print();
        cout << ": ";
        temp1->value.print();
    }

    Strin getAttribute(int node_position)
    {
        Attribute_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL)
        {
            cout << "List empty" << endl;
            return "";
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //check if it's possible to print node in the desired location
        if (list_lenght < node_position)
        {
            cout << "position too large" << endl;
            return "";
        }

        //travel the list to the desired node
        while (node_position-- > 1)
        {
            temp1 = temp1->next;
        }
        return temp1->attribute;
    }

    Strin getValue(int node_position)
    {
        Attribute_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL)
        {
            cout << "List empty" << endl;
            return "";
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //check if it's possible to print node in the desired location
        if (list_lenght < node_position)
        {
            cout << "position too large" << endl;
            return "";
        }

        //travel the list to the desired node
        while (node_position-- > 1)
        {
            temp1 = temp1->next;
        }
        return temp1->value;
    }

    Strin getValue(Strin attribute_name)
    {
        Attribute_node* temp1 = head;
        int list_lenght = 0;

        // Check if list is empty
        if (head == NULL)
        {
            //cout << "List empty" << endl;
            return "";
        }


        while (temp1 != NULL)
        {
            if (temp1->attribute == attribute_name)
            {
                return temp1->value;
            }
            temp1 = temp1->next;
        }

        return "";
    }

    int getAmmount()
    {
        Attribute_node* temp1 = head;
        int ammount = 0;
        while (temp1 != NULL)
        {
            ammount++;
            temp1 = temp1->next;
        }
        return ammount;
    }

    int getAmmount(Strin attribute_name)
    {
        Attribute_node* temp1 = head;
        int ammount = 0;
        while (temp1 != NULL)
        {
            if (temp1->attribute == attribute_name)
                ammount++;
            temp1 = temp1->next;
        }
        return ammount;
    }

    void deleteNode(int node_position)
    {
        Attribute_node* temp1 = head;
        Attribute_node* temp2 = NULL;
        Attribute_node* temp3 = NULL;
        int list_lenght = 0;

        if (head == NULL)
        {
            cout << "List empty." << endl;
            return;
        }

        //length of the list
        while (temp1 != NULL)
        {
            temp1 = temp1->next;
            list_lenght++;
        }

        //Is the element to be deleten in the list
        if (list_lenght < node_position)
        {
            cout << "Element doesn't exist" << endl;
            return;
        }
        //reset 1st node
        temp1 = head;

        //deleting the head
        if (node_position == 1)
        {
            //new head
            head = head->next;
            if (head != NULL)
                head->prev = NULL;
            delete temp1;
            return;
        }

        //find the node to delete
        while (node_position-- > 1)
        {
            temp2 = temp1;
            temp1 = temp1->next;
            temp3 = temp1->next;
        }

        //update the pointers
        temp2->next = temp1->next;
        temp3->prev = temp1->prev;

        delete temp1;
    }

    bool deleteNode(Strin attribute_name)
    {
        Attribute_node* temp1 = head;
        int ammount = 1;
        while (temp1 != NULL)
        {
            if (temp1->attribute == attribute_name)
            {
                deleteNode(ammount);
                return true;
            }
            temp1 = temp1->next;
            ammount++;
        }
        return false;
    }

    ~Attribute_list()
    {
        Attribute_node* tmp1 = nullptr;
        while (head != nullptr)
        {
            tmp1 = head;
            head = head->next;
            delete tmp1;
        }
    }
};
