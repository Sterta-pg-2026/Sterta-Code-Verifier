
#include <stdio.h>
#include <stdlib.h>

#define T 8
#define STRLEN 8

#define NULLC '\0'
#define ENDL '\n'
#define NOINDEX -1

#define COMMANDSTART "????"
#define COMMANDEND "****"

#define COMMANDSECTIONCOUNT '?'
#define COMMANDSELECTORS 'S'
#define COMMANDATTRIBUTES 'A'
#define COMMANDSEARCH 'E'
#define COMMANDDELETE 'D'
#define COMMANDNOARG '?'
#define COMMANDNOARG2 '*'

#define ZEROCHAR '0'

#define STARTBRACKET '{'
#define ENDBRACKET '}'
#define SELECTORSEPARATOR ','
#define ATTRIBUTENAMEVALSEPARATOR ':'
#define ATTRIBUTESEPARATOR ';'
#define SPACE ' '
#define TABULATOR '\t'
#define ESCAPECHAR '\r'
#define COMMANDARGSSEPARATOR ','
#define COMMANDRESULTSEPERATOR " == "

#define NUMBASE 10

#define DELETENOTIFICATION "deleted"

class Str;

// is a node of doubly linked list, has an array of T block elements
class BlockHolder;
class Block;

// both single linked list, with Str name
class Attr;
class Selector;

void swap(Str &left, Str &right);
void swap(int &first, int &second);
void swap(char *&first, char *&second);
void swap(char &left, char &right);

char movechar(char toPushBack = NULLC);
bool skip(char toSkip);
bool isWhiteSpace(char ch);
void skipWhitespace();
void readTill(Str &buffor, char endChar, char endChar2 = NULLC);

void readSelectors(Block &block);
void readAttributes(Block &block);
int readBlocks(BlockHolder *&head, BlockHolder *&tail, int blockCount);

char readCommand(Str &arg1, Str &arg2);
bool readAndExecuteCommands(BlockHolder *&head, BlockHolder *&tail, int &blockCount);
void executeCommand(BlockHolder *&head, BlockHolder *&tail, int &blockCount, char command, const Str &arg1, const Str &arg2);
void sCommands(BlockHolder *pHead, int blockCount, const Str &arg1, const Str &arg2);
void eCommands(BlockHolder *pTail, int blockCount, const Str &arg1, const Str &arg2);
void aCommands(BlockHolder *pHead, int blockCount, const Str &arg1, const Str &arg2);
void dCommands(BlockHolder *&pHead, BlockHolder *&pTail, int &blockCount, const Str &arg1, Str &arg2);

BlockHolder *getTail(BlockHolder *head);
bool findBlockHolder(BlockHolder *&currentBlockHolder, int &index);
void chainDeleteBlockHolders(BlockHolder *head);

void print(const Str &toPrint, char ending = NULLC);
void print(int toPrint, char ending = NULLC);
void print(char toPrint, char ending = NULLC);

void printResult(const Str &arg1, char commandType, const Str &arg2, const Str &result);
void printResult(const Str &arg1, char commandType, const Str &arg2, int resultInt );

// getchar but can ungetch char if it is passed as argument

class Str
{

public:
    char *charList;
    // reservedSize includes NULLC (minimum is 1), if 0 no memory has been allocated
    int reservedSize;

    Str()
    {
        this->reservedSize = 0;
        this->charList = nullptr;
    }

    Str(const Str &old)
    {
        this->reservedSize = old.reservedSize;
        if (this->reservedSize != 0)
        {
            this->charList = (char *)malloc(this->reservedSize);
            old.copyTo(this->charList);
        }
        else
        {
            this->charList = nullptr;
        }
    }

    Str(Str &&old)
    {
        this->reservedSize = old.reservedSize;
        this->charList = old.charList;
    }

    Str(char *&&old)
    {
        this->charList = (char *)malloc(32);
        int i = 0;
        while (old[i] != NULLC)
        {
            this->reservedSize = 32;
            this->charList[i] = old[i];
            i++;
        }
        this->charList[i] = NULLC;
    }

    Str(const char text[])
    {
        this->reservedSize = 0;
        this->charList = nullptr;

        for (int i = 0; text[i] != NULLC; i++)
        {
            (*this) += text[i];
        }
    }

    Str(int number)
    {
        this->reservedSize = 0;
        this->charList = nullptr;
        if (number == 0)
        {
            (*this) += ZEROCHAR;
        }

        while (number > 0)
        {
            (*this) += ZEROCHAR + (number % NUMBASE);
            number /= NUMBASE;
        }

        int len = (*this).length() - 1;
        int i = 0;

        while (i <= len - i)
        {
            swap((*this)[i], (*this)[len - i]);
            i++;
        }
    }

    Str &operator=(const Str &right)
    {
        Str tmp(right);
        swap(*this, tmp);
        return *this;
    }

    Str &operator=(Str &&right)
    {
        Str tmp(right);
        swap(*this, tmp);
        return *this;
    }

    int length() const
    {
        if (this->reservedSize == 0)
        {
            return 0;
        }
        int i = 0;
        while (this->charList[i] != NULLC)
        {
            i++;
        }
        return i;
    }

    void stripEnd()
    {
        int len = this->length();
        int i = len - 1;
        if (len <= 0)
        {
            return;
        }
        while (isWhiteSpace(this->charList[i]))
        {
            this->charList[i] = NULLC;
            i--;
            if (i < this->reservedSize - STRLEN - 1)
            {
                this->reservedSize -= STRLEN;
                this->charList = (char *)realloc(this->charList, this->reservedSize);
            }
        }
    }

    bool isEmpty() const
    {
        return (this->reservedSize == 0);
    }

    void copyTo(char *newCopy) const
    {
        if (this->isEmpty())
        {
            return;
        }
        int i;
        for (i = 0; this->charList[i] != NULLC; i++)
        {
            newCopy[i] = this->charList[i];
        }
        newCopy[i] = NULLC;
    }

    bool isInt() const
    {
        if (this->isEmpty())
        {
            return false;
        }
        for (int i = 0; this->charList[i] != NULLC; i++)
        {
            if (this->charList[i] > NUMBASE - 1 + ZEROCHAR || this->charList[i] < ZEROCHAR)
            {
                return false;
            }
        }
        return true;
    }

    bool isStr() const
    {
        return (!isInt() && !isEmpty());
    }

    int toInt() const
    {
        int result = 0;
        for (int i = 0; i < this->length(); i++)
        {
            result *= NUMBASE;
            result += this->charList[i] - ZEROCHAR;
        }
        return result;
    }

    void erase()
    {
        this->~Str();
        this->charList = nullptr;
        this->reservedSize = 0;
    }

    Str &operator+=(char ch)
    {
        if (this->reservedSize == 0)
        {
            this->reservedSize = STRLEN;
            this->charList = (char *)malloc(reservedSize);
            this->charList[0] = NULLC;
        }
        else if (this->length() + 2 > this->reservedSize)
        {
            this->reservedSize += STRLEN;
            char *tmp = (char *)realloc(this->charList, this->reservedSize);
            this->charList = tmp;
        }

        this->charList[this->length() + 1] = NULLC;
        this->charList[this->length()] = ch;

        return *this;
    }

    char &operator[](int index)
    {
        return this->charList[index];
    }

    char operator[](int index) const
    {
        return this->charList[index];
    }

    bool operator==(const Str &right) const
    {
        int len = this->length();
        if (len != right.length())
        {
            return false;
        }
        for (int i = 0; i < len; i++)
        {
            if (this->charList[i] != right.charList[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator==(char *&&right) const
    {
        int charLen = 0;
        for (charLen = 0; right[charLen] != NULLC; charLen++)
            ;
        int len = this->length();
        if (len != charLen)
        {
            return false;
        }
        for (int i = 0; i < len; i++)
        {
            if (this->charList[i] != right[i])
            {
                return false;
            }
        }
        return true;
    }

    ~Str()
    {
        if (this->charList != nullptr)
        {
            free(this->charList);
            this->charList = nullptr;
        }
    }
};

class Selector
{
public:
    Str name;
    Selector *next;

    Selector(Selector *next = nullptr)
    {
        this->name = Str();
        this->next = next;
    }

    void killChildren()
    {
        if (this->next != nullptr)
        {
            this->next->killChildren();
        }
        delete (this->next);
    }

    // destroying requires pointer to previous selector, so it is handled by Block class
    ~Selector()
    {
    }
};

class Attr
{
public:
    Str name;
    Str value;
    Attr *next;

    Attr(Attr *next = nullptr)
    {
        this->name = Str();
        this->value = Str();
        this->next = next;
    }

    Attr(const Attr &right)
    {
        this->name = right.name;
        this->value = right.value;
        this->next = right.next;
    }

    Attr(Attr &&right)
    {
        this->name = right.name;
        this->value = right.value;
        this->next = right.next;
    }

    Attr &operator=(const Attr &right)
    {
        Attr tmp(right);
        swapWith(tmp);

        return *this;
    }

    Attr &operator=(Attr &&right)
    {
        Attr tmp(right);
        swapWith(tmp);

        return *this;
    }

    void swapWith(Attr &right)
    {
        swap(this->name, right.name);
        Attr *tmp = this->next;
        this->next = right.next;
        right.next = tmp;
    }

    void killChildren()
    {
        if (this->next != nullptr)
        {
            this->next->killChildren();
        }
        delete (this->next);
        this->next = nullptr;
    }

    // destroying requires pointer to previous Attr, so it is handled by Block class
    ~Attr()
    {
    }
};

class Block
{
public:
    Selector *selectorHead;
    Selector *selectorTail;
    Attr *attributeHead;
    Attr *attributeTail;

    Block(Selector *selectors = nullptr, Attr *attributes = nullptr)
    {
        this->selectorHead = selectors;
        this->attributeHead = attributes;
        this->selectorTail = selectors;
        this->attributeTail = attributes;
    }

    void addSelector(Selector *newSelector)
    {
        if (this->selectorHead == nullptr)
        {
            this->selectorTail = newSelector;
            this->selectorHead = newSelector;
        }
        else
        {
            this->selectorTail->next = newSelector;
            this->selectorTail = newSelector;
        }
    }

    int countSelectors()
    {
        Selector *tmp = (this->selectorHead);
        int i;
        for (i = 0; tmp != nullptr; i++)
        {
            tmp = tmp->next;
        }
        return i;
    }

    // selector with given index must exist
    // very inefficent in for loops
    Selector &getSelector(int index)
    {
        Selector *tmp = this->selectorHead;
        while (index-- != 0)
        {
            tmp = tmp->next;
        }
        return *tmp;
    }

    Selector *searchForSelector(const Str &val) const
    {
        Selector *currentSelector = this->selectorHead;
        while (currentSelector != nullptr)
        {
            if (currentSelector->name == val)
            {
                return currentSelector;
            }
            currentSelector = currentSelector->next;
        }
        return nullptr;
    }

    bool removeSelector(Selector *prevToRemove)
    {
        Selector *toRemove;
        if (prevToRemove != nullptr)
        {
            toRemove = prevToRemove->next;
            prevToRemove->next = toRemove->next;
        }
        else
        {
            if (this->selectorHead == nullptr)
            {
                return true;
            }
            else
            {
                toRemove = this->selectorHead;
                this->selectorHead = toRemove->next;
            }
            if (this->selectorTail == toRemove)
            {
                this->selectorTail = prevToRemove;
            }
        }

        delete toRemove;
        return true;
    }

    int removeDuplicateSelectors(Str toRemove)
    {
        int removed = 0;
        Selector *currentSelector = this->selectorHead;
        Selector *prevSelector = nullptr;
        Selector *lastFoundSelector = nullptr;
        Selector *prevToFoundSelector = nullptr;

        while (currentSelector != nullptr)
        {
            if (currentSelector->name == toRemove)
            {
                if (lastFoundSelector != nullptr)
                {
                    // this is removal of repeating (therefore not last) argument in a block, so block will never neeed to be deleted here
                    this->removeSelector(prevToFoundSelector);
                    removed++;
                }
                lastFoundSelector = currentSelector;
                prevToFoundSelector = prevSelector;
            }
            prevSelector = currentSelector;
            currentSelector = currentSelector->next;
        }
        return removed;
    }

    void addAttribute(Attr *newAttr)
    {
        if (this->attributeHead == nullptr)
        {
            this->attributeTail = newAttr;
            this->attributeHead = newAttr;
        }
        else
        {
            this->attributeTail->next = newAttr;
            this->attributeTail = newAttr;
        }
    }

    int countAttributes() const
    {
        Attr *tmp = (this->attributeHead);
        int i;
        for (i = 0; tmp != nullptr; i++)
        {
            tmp = tmp->next;
        }
        return i;
    }

    // attribute with given index must exist
    // very inefficent in for loops
    Attr &getAttr(int index)
    {
        Attr *tmp = this->attributeHead;
        while (index-- != 0)
        {
            tmp = tmp->next;
        }
        return *tmp;
    }

    Attr *searchForAttr(const Str &val) const
    {
        Attr *currentAttr = this->attributeHead;
        while (currentAttr != nullptr)
        {
            if (currentAttr->name == val)
            {
                return currentAttr;
            }
            currentAttr = currentAttr->next;
        }
        return nullptr;
    }

    // to remove first (attributeHead), pass nullptr
    bool removeAttr(Attr *prevToRemove)
    {
        Attr *toRemove;
        if (prevToRemove != nullptr)
        {
            toRemove = prevToRemove->next;
            prevToRemove->next = prevToRemove->next->next;
        }
        else
        {
            if (this->attributeHead == nullptr)
            {
                return false;
            }
            toRemove = this->attributeHead;
            this->attributeHead = this->attributeHead->next;
        }
        if (this->attributeTail == toRemove)
        {
            // check if there are any nodes left
            if (this->attributeHead != nullptr)
            {
                this->attributeTail = prevToRemove;
            }
            // if that was the last attribute, entire block is pointless, so it should be deleted
            else
            {
                this->attributeTail = nullptr;
                this->~Block();
            }
        }

        delete toRemove;
        return true;
    }

    // removes all attributes with this name, except for the last one
    // returns number of removals
    int removeDuplicateAttr(Str toRemove)
    {
        int removed = 0;

        Attr *currentAttr = this->attributeHead;
        Attr *prevAttr = nullptr;
        Attr *lastFoundAttr = nullptr;
        Attr *prevToFoundAttr = nullptr;

        while (currentAttr != nullptr)
        {
            if (currentAttr->name == toRemove)
            {
                if (lastFoundAttr != nullptr)
                {
                    // this is removal of repeating (therefore not last) argument in a block, so block will never neeed to be deleted here
                    this->removeAttr(prevToFoundAttr);
                    removed++;
                }
                lastFoundAttr = currentAttr;
                prevToFoundAttr = prevAttr;
            }
            prevAttr = currentAttr;
            currentAttr = currentAttr->next;
        }
        return removed;
    }

    bool isEmpty() const
    {
        if (this->attributeHead == nullptr)
        {
            return true;
        }
        return false;
    }

    ~Block()
    {
        if (this->attributeHead != nullptr)
        {
            this->attributeHead->killChildren();
            delete attributeHead;
        }

        if (this->selectorHead != nullptr)
        {
            this->selectorHead->killChildren();
            delete selectorHead;
        }

        // destructor creates hollow object, pointers need to be zeroed so that isEmpty() will consider object hollow

        this->attributeHead = nullptr;
        this->attributeTail = nullptr;
        this->selectorHead = nullptr;
        this->selectorTail = nullptr;
    }
};

class BlockHolder
{
public:
    Block *blocks;
    BlockHolder *next;
    BlockHolder *prev;
    int lastBlock;

    BlockHolder(BlockHolder *prev = nullptr)
    {

        this->prev = prev;
        this->next = nullptr;

        if (prev != nullptr)
        {
            prev->next = this;
        }
        this->blocks = new Block[T];
        this->lastBlock = 0;
    }

    // will add new block in first empty slot
    // if no argument is passed will return pointer to first empty slot
    Block *addBlock(Block *newBlock = nullptr)
    {
        if (newBlock == nullptr)
        {
            newBlock = new Block;
        }
        if (this->next == nullptr)
        {

            if (this->lastBlock != T)
            {
                blocks[this->lastBlock] = *newBlock;
                this->lastBlock++;
                return this->blocks + this->lastBlock - 1;
            }
            this->next = new BlockHolder(this);
        }
        return this->next->addBlock(newBlock);
    }

    int countBlocks()
    {
        int blockCount = 0;
        for (int i = 0; i < T; i++)
        {
            if (!(blocks[i].isEmpty()))
            {
                blockCount++;
            }
        }
        return blockCount;
    }

    // iterator function using less advanced syntax
    Block *nextBlock(bool reset = false)
    {
        static BlockHolder *currentNode;
        static int blockIndex;

        if (reset)
        {
            blockIndex = 0;
            currentNode = this;
            return nullptr;
        }

        if (currentNode == nullptr)
        {
            return nullptr;
        }

        if (currentNode->blocks[blockIndex].isEmpty())
        {
            blockIndex++;
            return nextBlock();
        }

        if (blockIndex == T)
        {
            blockIndex = 0;
            currentNode = currentNode->next;
        }
        if (currentNode == nullptr)
        {
            return nullptr;
        }
        return currentNode->blocks + blockIndex++;
    }

    Block *prevBlock(bool reset = false)
    {
        static BlockHolder *currentNode;
        static int blockIndex;

        if (reset)
        {
            blockIndex = T - 1;
            currentNode = this;
        }

        if (currentNode == nullptr)
        {
            return nullptr;
        }

        if (blockIndex < 0)
        {
            blockIndex = T - 1;
            currentNode = currentNode->prev;
        }
        if (currentNode == nullptr)
        {
            return nullptr;
        }
        return currentNode->blocks + blockIndex--;
    }

    BlockHolder *removeEmptyNodes()
    {
        BlockHolder *newHead = nullptr;
        if (this->next != nullptr)
        {
            newHead = this->next->removeEmptyNodes();
        }
        if (this->countBlocks() == 0)
        {
            delete this;
            return newHead;
        }
        else
        {
            return this;
        }
    }

    // returns reference to block. can jump to another nodes, skips empty blocks
    // block with specified index must exist;
    // accepts negative indices (due to lack of -0, all are moved by -1)
    Block &operator[](int index)
    {
        if (index >= 0)
        {
            for (int i = 0; i < T; i++)
            {
                if (!(this->blocks)[i].isEmpty())
                {
                    index--;
                    if (index < 0)
                    {
                        return (this->blocks)[i];
                    }
                }
            };
            return (*(this->next))[index];
        }
        else
        {
            // move by 1
            index = -index - 1;

            for (int i = T - 1; i >= 0; i--)
            {
                if (!(this->blocks)[i].isEmpty())
                {
                    index--;
                    if (index < 0)
                    {
                        return (this->blocks)[i];
                    }
                }
            };
            return (*(this->prev))[-index];
        }
    }

    void tryDelete(BlockHolder *&pHead, BlockHolder *&pTail)
    {
        if (this->countBlocks() == 0)
        {
            if (this->prev == nullptr)
            {
                pHead = this->next;
            }
            if (this->next == nullptr)
            {
                pTail = this->prev;
            }
            delete this;
        }
    }

    ~BlockHolder()
    {
        delete[] (this->blocks);
        if (this->prev != nullptr)
        {
            this->prev->next = this->next;
        }

        if (this->next != nullptr)
        {
            this->next->prev = this->prev;
        }
    }
};

int main()
{
    BlockHolder *head = nullptr;
    BlockHolder *tail;
    int blockCount = 0;
    bool endOfFile = false;
    while (!endOfFile)
    {
        if (head == nullptr)
        {
            head = new BlockHolder;
        }

        blockCount = readBlocks(head, tail, blockCount);
        endOfFile = readAndExecuteCommands(head, tail, blockCount);
    }
    chainDeleteBlockHolders(head);

    return 0;
}

void swap(Str &left, Str &right)
{
    swap((left).reservedSize, right.reservedSize);
    swap((left).charList, right.charList);
}

void swap(int &first, int &second)
{
    int tmp = first;
    first = second;
    second = tmp;
}

void swap(char *&first, char *&second)
{
    char *tmp = first;
    first = second;
    second = tmp;
}

void swap(char &left, char &right)
{
    char tmp = left;
    left = right;
    right = tmp;
}

char movechar(char toPushBack)
{
    static char buffer[STRLEN];
    static int bufferLen = 0;
    if (toPushBack == NULLC)
    {
        if (bufferLen == 0)
        {
            return (char)getchar();
        }
        return buffer[--bufferLen];
    }
    buffer[bufferLen] = toPushBack;
    bufferLen++;
    return NULLC;
}

// returns true if skipped char
bool skip(char toSkip)
{
    char ch = movechar();
    if (ch == toSkip)
    {
        return true;
    }
    movechar(ch);
    return false;
}

bool isWhiteSpace(char ch)
{
    return ch == SPACE || ch == TABULATOR || ch == ENDL || ch == ESCAPECHAR;
}

void print(const Str &toPrint, char ending)
{
    int len = toPrint.length();
    for (int i = 0; i < len; i++)
    {
        putchar(toPrint[i]);
    }
    if (ending != NULLC)
    {
        putchar(ending);
    }
}

void print(int toPrint, char ending)
{
    print(Str(toPrint), ending);
}

void print(char toPrint, char ending)
{
    putchar(toPrint);
    if (ending != NULLC)
    {
        putchar(ending);
    }
}

void printResult(const Str &arg1, char commandType, const Str &arg2, const Str &result)
{
    if (commandType != COMMANDSECTIONCOUNT)
    {
        print(arg1, COMMANDARGSSEPARATOR);
        print(commandType, COMMANDARGSSEPARATOR);
        if (arg2.isEmpty())
        {
            print(COMMANDNOARG);
        }
        else
        {
            print(arg2);
        }
    }
    else
    {
        print(COMMANDSECTIONCOUNT);
    }

    print(Str(COMMANDRESULTSEPERATOR));
    print(result, ENDL);
}

void printResult(const Str &arg1, char commandType, const Str &arg2, int resultInt)
{
    printResult(arg1, commandType, arg2, Str(resultInt));
}

void readTill(Str &buffor, char endChar, char endChar2)
{
    char ch = movechar();
    while (ch != endChar && ch != endChar2)
    {
        buffor += ch;
        ch = movechar();
    }
    movechar(ch);
}

void skipWhitespace()
{
    char ch = movechar();
    while (isWhiteSpace(ch))
    {
        ch = movechar();
    }
    movechar(ch);
}

// after execution text left in ostream does not have STARTBRACKET
void readSelectors(Block &block)
{
    skipWhitespace();

    while (true)
    {
        Selector *newSelector = new Selector;
        Str &selectorName = newSelector->name;
        readTill(selectorName, SELECTORSEPARATOR, STARTBRACKET);
        selectorName.stripEnd();
        block.removeDuplicateSelectors(selectorName);

        if (selectorName.length() > 0)
        {

            block.addSelector(newSelector);
        }

        skipWhitespace();

        if (skip(STARTBRACKET))
        {
            break;
        }
        skip(SELECTORSEPARATOR);

        skipWhitespace();
    }
}

// ends on ENDBRACKET (it is included)
void readAttributes(Block &block)
{
    skipWhitespace();
    while (true)
    {
        block.addAttribute(new Attr);
        Str &attrName = block.attributeTail->name;
        Str &attrValue = block.attributeTail->value;

        readTill(attrName, ATTRIBUTENAMEVALSEPARATOR);
        attrName.stripEnd();
        block.removeDuplicateAttr(attrName);
        skip(ATTRIBUTENAMEVALSEPARATOR);
        skipWhitespace();

        readTill(attrValue, ATTRIBUTESEPARATOR, ENDBRACKET);
        skip(ATTRIBUTESEPARATOR);
        attrValue.stripEnd();
        skip(ATTRIBUTENAMEVALSEPARATOR);
        skipWhitespace();

        if (skip(ENDBRACKET))
        {
            break;
        }
        skipWhitespace();
    }
}

// reads blocks and COMMANDSTART
// returns number of blocks read
int readBlocks(BlockHolder *&head, BlockHolder *&tail, int blockCount)
{
    skipWhitespace();

    int i = 0;
    int j = 0;
    Block *block;
    while (true)
    {
        block = head->addBlock();
        readSelectors(*block);
        readAttributes(*block);

        skipWhitespace();
        i++;

        while (skip(COMMANDSTART[j]))
        {
            j++;
            if (COMMANDSTART[j] == NULLC)
            {
                tail = getTail(head);
                return i + blockCount;
            }
        }
        while (j > 0)
        {
            movechar(COMMANDSTART[j]);
            j--;
        }
    }
}

// reads command type and arguments
// returns command type or null if NULLC or EOF is reached
char readCommand(Str &arg1, Str &arg2)
{
    arg1.erase();
    arg2.erase();
    skipWhitespace();

    if (skip(COMMANDSECTIONCOUNT))
    {
        return COMMANDSECTIONCOUNT;
    }

    else if (skip(NULLC) || skip(EOF))
    {
        return EOF;
    }

    int j = 0;
    while (skip(COMMANDEND[j]))
    {
        j++;
        if (COMMANDEND[j] == NULLC)
        {
            return COMMANDEND[0];
        }
    }
    j--;
    while (j > 0)
    {
        movechar(COMMANDEND[j]);
    }

    readTill(arg1, COMMANDARGSSEPARATOR);
    skip(COMMANDARGSSEPARATOR);

    char commandType = movechar();
    skip(COMMANDARGSSEPARATOR);

    if (skip(COMMANDNOARG) || skip(COMMANDNOARG2))
    {
        return commandType;
    }
    readTill(arg2, ENDL);
    return commandType;
}

bool readAndExecuteCommands(BlockHolder *&head, BlockHolder *&tail, int &blockCount)
{
    Str arg1, arg2;
    char commandType = NULLC;
    while (commandType != COMMANDEND[0])
    {
        commandType = readCommand(arg1, arg2);
        executeCommand(head, tail, blockCount, commandType, arg1, arg2);

        if (commandType == EOF)
        {
            return true;
        }
    }
    return false;
}

BlockHolder *getTail(BlockHolder *head)
{
    BlockHolder *tail = head;

    if (tail == nullptr)
    {
        return nullptr;
    }

    while (tail->next != nullptr)
    {
        tail = tail->next;
    }
    return tail;
}

// finds blockHolder containing block with index. both references are changed
// to pointer to blockHolder with specified block, and index of specified block in blocks array of BlockHolder
bool findBlockHolder(BlockHolder *&currentBlockHolder, int &index)
{
    int blockIndex = 0;
    while (currentBlockHolder != nullptr && index >= 0)
    {

        for (int j = 0; j < T && index >= 0; j++)
        {
            if (!(currentBlockHolder->blocks[j].isEmpty()))
            {
                index--;
            }
            blockIndex = j;
        }

        if (index >= 0)
        {
            currentBlockHolder = currentBlockHolder->next;
        }
    }
    if (currentBlockHolder == nullptr)
    {
        return false;
    }
    index = blockIndex;
    return true;
}

void sCommands(BlockHolder *pHead, int blockCount, const Str &arg1, const Str &arg2)
{
    BlockHolder &head = *pHead;
    if (arg1.isInt() && arg2.isEmpty())
    {
        int i = arg1.toInt() - 1;
        if (i < blockCount)
        {
            printResult(arg1, COMMANDSELECTORS, arg2, head[i].countSelectors());
        }
        return;
    }

    else if (arg1.isInt() && arg2.isInt())
    {
        int i = arg1.toInt() - 1;
        int j = arg2.toInt() - 1;
        if (i < blockCount)
        {
            Block &iBlock = head[i];
            if (j < iBlock.countSelectors())
            {
                printResult(arg1, COMMANDSELECTORS, arg2, iBlock.getSelector(j).name);
            }
        }
    }
    else if (arg1.isStr() && arg2.isEmpty())
    {
        int selectorsFound = 0;
        Block *currentBlock, *prevBlock;
        head.nextBlock(true);

        // pointer assinged to currentBlock will be treated as a condition in while
        // loop will end when head.nextBlock() returns nullptr
        while (currentBlock = head.nextBlock())
        {
            if (currentBlock->searchForSelector(arg1) != nullptr)
            {
                selectorsFound++;
            }
            prevBlock = currentBlock;
        }
        printResult(arg1, COMMANDSELECTORS, arg2, selectorsFound);
    }
}

void aCommands(BlockHolder *pHead, int blockCount, const Str &arg1, const Str &arg2)
{
    BlockHolder &head = *pHead;

    if (arg1.isInt() && arg2.isEmpty())
    {
        int i = arg1.toInt() - 1;
        if (i < blockCount)
        {
            printResult(arg1, COMMANDATTRIBUTES, arg2, head[i].countAttributes());
        }
    }
    else if (arg1.isInt() && arg2.isStr())
    {
        int i = arg1.toInt() - 1;
        Attr *foundAttr;
        if (i < blockCount)
        {
            foundAttr = head[i].searchForAttr(arg2);
            if (foundAttr != nullptr)
            {
                printResult(arg1, COMMANDATTRIBUTES, arg2, foundAttr->value);
            }
        }
    }
    else if (arg1.isStr() && arg2.isEmpty())
    {
        int attrFoundCount = 0;

        Block *currentBlock;
        Attr *foundAttr;

        head.nextBlock(true);
        // pointer assinged to currentBlock will be treated as a condition in while
        // loop will end when head.nextBlock() returns nullptr
        while (currentBlock = head.nextBlock())
        {
            Block &iBlock = *currentBlock;
            foundAttr = iBlock.searchForAttr(arg1);
            if (foundAttr != nullptr)
            {
                attrFoundCount++;
            }
        }
        printResult(arg1, COMMANDATTRIBUTES, arg2, attrFoundCount);
    }
}

void eCommands(BlockHolder *pTail, int blockCount, const Str &arg1, const Str &arg2)
{
    if (arg1.isStr() && arg2.isStr())
    {
        BlockHolder &tail = *pTail;
        Block *currentBlock;
        Selector *pSelector;
        Attr *foundAttr;

        for (int i = -1; i > -blockCount; i--)
            tail.prevBlock(true);
        while (currentBlock = tail.prevBlock())
        {
            Block &iBlock = *currentBlock;
            pSelector = iBlock.selectorHead;

            while (pSelector != nullptr)
            {
                if (pSelector->name == arg1)
                {
                    foundAttr = iBlock.searchForAttr(arg2);
                    if (foundAttr != nullptr)
                    {
                        printResult(arg1, COMMANDSEARCH, arg2, foundAttr->value);
                        return;
                    }
                }
                pSelector = pSelector->next;
            }
        }
    }
}

void dCommands(BlockHolder *&pHead, BlockHolder *&pTail, int &blockCount, const Str &arg1, const Str &arg2)
{
    BlockHolder *currentBlockHolder = pHead;
    Str attrName;

    if (arg1.isInt() && arg2.isStr())
    {
        int blockIndex = arg1.toInt() - 1;

        if (!findBlockHolder(currentBlockHolder, blockIndex))
        {
            return;
        }

        Block &block = currentBlockHolder->blocks[blockIndex];
        Attr *currentAttr = block.attributeHead;
        Attr *prevAttr = nullptr;

        if (block.searchForAttr(arg2) == nullptr)
        {
            return;
        }

        while (currentAttr != nullptr)
        {
            if (currentAttr->name == arg2)
            {
                block.removeAttr(prevAttr);
                break;
            }
            prevAttr = currentAttr;
            currentAttr = currentAttr->next;
        }

        if (block.isEmpty())
        {
            blockCount--;
        }
        attrName = arg2;
    }
    else if (arg1.isInt() && arg2.isEmpty())
    {
        int blockIndex = arg1.toInt() - 1;

        if (!findBlockHolder(currentBlockHolder, blockIndex))
        {
            return;
        }
        currentBlockHolder->blocks[blockIndex].~Block(); // after delete head[i] calling head[i].isEmpty() may result in segmentation fault
        blockCount--;
        attrName += COMMANDNOARG2;
    }
    currentBlockHolder->tryDelete(pHead, pTail);
    printResult(arg1, COMMANDDELETE, attrName, Str(DELETENOTIFICATION));
}

void executeCommand(BlockHolder *&head, BlockHolder *&tail, int &blockCount, char command, const Str &arg1, const Str &arg2)
{
    switch (command)
    {
    case COMMANDSELECTORS:
        sCommands(head, blockCount, arg1, arg2);
        break;
    case COMMANDATTRIBUTES:
        aCommands(head, blockCount, arg1, arg2);
        break;
    case COMMANDSEARCH:
        eCommands(tail, blockCount, arg1, arg2);
        break;
    case COMMANDDELETE:
        dCommands(head, tail, blockCount, arg1, arg2);
        break;
    case COMMANDSECTIONCOUNT:
        printResult(arg1, COMMANDSECTIONCOUNT, arg2, blockCount);
        break;
    default:
        break;
    }
}

void chainDeleteBlockHolders(BlockHolder *head)
{
    if (head == nullptr)
    {
        return;
    }
    chainDeleteBlockHolders(head->next);
    delete head;
}