﻿

//
// inclusion of compile-time variables
// and libraries
//



#include "css-parser.h"
using namespace std;



//
// declarations of data structures 
//



class Selectors {
public:
	char* name;
	Selectors* next;
};

class Attributes {
public:
	char* name;
	char* value;
	Attributes* next;
};

class Section {
public:
	Selectors* selectors = nullptr;
	Attributes* attributes = nullptr;
};

class Node {
public:
	int count = 0;
	Section* sections[T];
	Node* next = nullptr;
	Node* prev = nullptr;

	Node() {
		for (int i = 0; i < T; i++) {
			this->sections[i] = nullptr;
		}
	}
};



//
// default-type utility functions
//



bool compareStrings(const char* arr1, const char* arr2) {
	if (strcmp(arr1, arr2) == 0) {
		return true;
	}
	else {
		return false;
	}
}



bool isInt(char a) {
	if ((a >= '0') && (a <= '9')) {
		return true;
	}

	return false;
}



bool isMutableToInt(char* buffer) {
	size_t len = strlen(buffer);

	for (int i = 0; i < len; i++) {
		if (!isInt(buffer[i])) {
			return false;
		}
	}

	return true;
}



int countCommas(char* buffer) {
	int sum = 0;

	for (int i = 0; i < STRING_LENGTH; i++) {
		if (buffer[i] == '\0') {
			return sum;
		}

		if (buffer[i] == ASCII_COMMA) {
			sum++;
		}
	}

	return sum;
}



//
// strictly selector related functions
//



void append(Selectors** head, char* new_name) {
	Selectors* new_element = new Selectors();

	new_element->name = new_name;
	new_element->next = nullptr;

	if (*head == nullptr) { 
		*head = new_element;
		return;
	}

	Selectors* last = *head;

	while (last->next != nullptr) {
		last = last->next;
	}

	last->next = new_element;
	return;
}



void deleteSelectors(Selectors** head) {
	Selectors* current = (*head);
	Selectors* next = nullptr;

	while (current != nullptr) {
		next = current->next;
		free(current);
		current = next;
	}

	(*head) = nullptr;
}



bool hasSelector(Selectors** head, char* name) {
	Selectors* temp = (*head);

	while (temp != nullptr) {
		if (compareStrings(temp->name, name)) {
			return true;
		}

		temp = temp->next;
	}

	return false;
}



//
// strictly attribute related functions
//



bool hasAttribute(Attributes** head, char* name) {
	Attributes* temp = (*head);

	while (temp != nullptr) {
		if (compareStrings(temp->name, name)) {
			return true;
		}

		temp = temp->next;
	}

	return false;
}



void overwriteAttribute(Attributes** head, char* name, char* value) {
	Attributes* temp = (*head);

	while (temp != nullptr) {
		if (compareStrings(temp->name, name)) {
			temp->value = value;
			return;
		}

		temp = temp->next;
	}

	return;
}



void append(Attributes **head, char* new_name, char* new_value) {
	Attributes* new_element = new Attributes();

	new_element->name = new_name;
	new_element->value = new_value;
	new_element->next = nullptr;

	if (*head == nullptr) {
		*head = new_element;
		return;
	}

	Attributes* last = *head;

	while (last->next != nullptr) {
		last = last->next;
	}

	last->next = new_element;
	return;
}

void deleteAttributes(Attributes** head) {
	Attributes* current = (*head);
	Attributes* next = nullptr;

	while (current != nullptr) {
		next = current->next;
		free(current);
		current = next;
	}

	(*head) = nullptr;
}

int removeAttributeFromList(Attributes** head, char* attributeName) {
	Attributes* temp = (*head);
	Attributes* prev = nullptr;

	if ((temp != nullptr) && (compareStrings(temp->name, attributeName))) {
		(*head) = temp->next;

		free(temp);
		return SUCCESSFUL_DELETION;
	}
	else {
		while ((temp != nullptr) && (!compareStrings(temp->name, attributeName))) {
			prev = temp;
			temp = temp->next;
		}

		if (temp == nullptr) {
			return UNSUCCESSFUL_DELETION;
		}

		prev->next = temp->next;

		free(temp);

		return SUCCESSFUL_DELETION;
	}
}



void addNewAttribute(Attributes** attributes, char* name, char* value) {
	if (attributes != nullptr && name != nullptr && value != nullptr) {
		if (hasAttribute(attributes, name)) {
			overwriteAttribute(attributes, name, value);
		}
		else {
			append(attributes, name, value);
		}
	}
}



void addNewSelector(Selectors** selectors, char* name) {
	if (selectors != nullptr && name != nullptr) {
		if (hasSelector(selectors, name)) {
			return;
		}
		else {
			append(selectors, name);
		}
	}
}



//
// strictly node related functions
// 



bool isNodeFree(Node** head) {
	if ((*head)->count < T) {
		return true;
	}

	return false;
}



int getFreeSectionIndex(Node** head) {
	for (int i = 0; i < T; i++) {
		if ((*head)->sections[i] == nullptr) {
			return i;
		}
	}

	return -1;
}



Section** getSectionByIndex(Node **head, int index) {
	int counter = 0;
	Node* temp = (*head);

	if (temp != nullptr) {
		do {
			for (int i = 0; i < T; i++) {
				if (temp->sections[i] != nullptr) {
					counter++;
				}

				if (counter == index) {
					return &(temp->sections[i]);
				}
			}

			temp = temp->next;
		} while (temp != (*head));
	}

	return nullptr;
}



Node** getNodeByIndex(Node** head, int index) {
	if (head != nullptr) {
		Node* temp = (*head);

		for (int i = 0; i < index; i++) {
			if (temp != nullptr && (temp->next != (*head))) {
				temp = temp->next;
			}
		}

		return &(temp);
	}
	else {
		return head;
	}
}



//
// wide-scope / non-default-type utility functions
//


void addToFreeNode(Node** head, Selectors* temp_selectors, Attributes* temp_attributes) {
	int freeSlot = getFreeSectionIndex(head);

	Section* freeSection = new Section();

	freeSection->attributes = temp_attributes;
	freeSection->selectors = temp_selectors;
	(*head)->count++;
	(*head)->sections[freeSlot] = freeSection;
}

void initializeEmptyNodeHead(Node** head) {
	Node* new_node = new Node();
	new_node->next = new_node;
	new_node->prev = new_node;
	(*head) = new_node;
}

void addEmptyNode(Node** head) {
	if ((*head) == nullptr) {
		initializeEmptyNodeHead(head);
		return;
	}

	Node* last = (*head)->prev;

	Node* new_node = new Node();
	new_node->next = (*head);

	(*head)->prev = new_node;

	new_node->prev = last;

	last->next = new_node;
}

void addToFirstFreeSection(Node **head, Selectors* temp_selectors, Attributes *temp_attributes) {
	if ((*head) == nullptr) {
		initializeEmptyNodeHead(head);
	}

	if (isNodeFree(head)) {
		addToFreeNode(head, temp_selectors, temp_attributes);
		return;
	}
	else {
		Node* temp = (*head);

		while (temp->next != (*head)) {
			temp = temp->next;
			if (isNodeFree(&(temp))) {
				addToFreeNode(&(temp), temp_selectors, temp_attributes);
				return;
			}
		}

		addEmptyNode(head);

		addToFirstFreeSection(head, temp_selectors, temp_attributes);
	}
}

int getSectionCount(Node **head) {
	int count = 0;

	Node* temp = (*head);

	if (temp != nullptr) {
		count += temp->count;

		while (temp->next != (*head)) {
			temp = temp->next;
			count += temp->count;
		}
	}
	

	return count;
}

int actualSectionIndex(Node** head, int potentialSectionIndex) {
	int counter = 0;

	if (head != nullptr) {
		if ((*head) != nullptr) {
			for (int i = 0; i < T; i++) {
				if ((*head)->sections[i] != nullptr) {
					counter++;
				}

				if (counter == (potentialSectionIndex + 1)) {
					return i;
				}
			}
		}
	}

	return counter;
}

void handlePossiblyEmptyNode(Node **head, Node **toDeleteFrom) {
	if ((*toDeleteFrom)->count == 0) {
		Node* temp = (*toDeleteFrom);

		if ((temp == (*head)) && ((*toDeleteFrom)->prev == (*head))) {
			(*head) = nullptr;
			free(temp);
			return;
		}

		if ((*toDeleteFrom) == (*head)) {
			(*toDeleteFrom)->prev = (*head)->prev;

			(*head) = (*head)->next;

			(*toDeleteFrom)->prev->next = (*head);
			(*head)->prev = (*toDeleteFrom)->prev;

			free(temp);
		}
		else if (temp->next == (*head)) {
			(*toDeleteFrom)->prev->next = (*head);
			(*head)->prev = (*toDeleteFrom)->prev;
			free(temp);
		}
		else {
			Node* newTemp = temp->next;

			(*toDeleteFrom)->prev->next = newTemp;
			newTemp->prev = (*toDeleteFrom)->prev;
			free(temp);
		}
	}
}



bool doesSectionHaveAttributeForSelector(Section **head, char* attributeName, char* selectorName, char* buffer) {
	Selectors* temp = (*head)->selectors;

	bool doesHave = false;

	while (temp != nullptr) {
		if (compareStrings(temp->name, selectorName)) {
			doesHave = true;
			break;
		}

		temp = temp->next;
	}

	bool toReturn = false;

	if (doesHave) {
		Attributes* aTemp = (*head)->attributes;

		while (aTemp != nullptr) {
			if (compareStrings(aTemp->name, attributeName)) {
				cout << buffer << " == " << aTemp->value << endl;
				toReturn = true;
				break;
			}

			aTemp = aTemp->next;
		}
	}

	return toReturn;
}



bool doesNodeHaveAttributeForSelector(Node **head, char* attributeName, char* selectorName, char* buffer) {
	for (int i = (T - 1); i >= 0; i--) {
		if ((*head)->sections[i] != nullptr) {
			if (doesSectionHaveAttributeForSelector(&((*head)->sections[i]), attributeName, selectorName, buffer)) {
				return true;
			}
		}
	}

	return false;
}



int numberOfSelectorsForIndex(Node** head, int index) {
	Section** target = getSectionByIndex(head, index);
	int sum = 0;

	if (target == nullptr) {
		return -1;
	}

	Selectors* temp = (*target)->selectors;

	while (temp != nullptr) {
		sum++;
		temp = temp->next;
	}

	return sum;
}



int numberOfAttributesForIndex(Node** head, int index) {
	Section** target = getSectionByIndex(head, index);
	int sum = 0;

	if (target == nullptr) {
		return -1;
	}

	Attributes* temp = (*target)->attributes;

	while (temp != nullptr) {
		sum++;
		temp = temp->next;
	}

	return sum;
}



int selectorCountPerNode(Node** head, char* select) {
	Node* temp = (*head);
	int sum = 0;

	for (int i = 0; i < T; i++) {
		if (temp->sections[i] != nullptr) {
			Selectors* tempSelector = temp->sections[i]->selectors;

			if (tempSelector != nullptr) {
				if (compareStrings(tempSelector->name, select)) {
					sum++;
					continue;
				}

				while (tempSelector->next != nullptr) {
					tempSelector = tempSelector->next;
					if (compareStrings(tempSelector->name, select)) {
						sum++;
						break;
					}
				}
			}
		}
	}

	return sum;
}



int attributeCountPerNode(Node** head, char* attribute) {
	Node* temp = (*head);
	int sum = 0;

	for (int i = 0; i < T; i++) {
		if (temp->sections[i] != nullptr) {
			Attributes* tempSelector = temp->sections[i]->attributes;

			if (compareStrings(tempSelector->name, attribute)) {
				sum++;
			}

			while (tempSelector->next != nullptr) {
				tempSelector = tempSelector->next;
				if (compareStrings(tempSelector->name, attribute)) {
					sum++;
				}
			}
		}
	}

	return sum;
}



//
// functions directly interfacing with the query interpreter
//



int getAttributeOccurenceCount(Node** head, char* attribute) {
	Node* temp = (*head);
	int sum = 0;

	if (temp != nullptr) {
		sum += attributeCountPerNode((&temp), attribute);

		while (temp->next != (*head)) {
			temp = temp->next;

			sum += attributeCountPerNode((&temp), attribute);
		}
	}

	return sum;
}



void attributeValueBySectionIndex(Node** head, int index, char* attribute, char* buffer) {
	Section** target = getSectionByIndex(head, index);

	if ((*target) != nullptr) {
		Attributes* temp = (*target)->attributes;

		while (temp != nullptr) {
			if (compareStrings(temp->name, attribute)) {
				cout << buffer << " == " << temp->value << endl;
				return;
			}

			temp = temp->next;
		}
	}
}



int deleteAttributeFromSectionByName(Node** head, int sectionIndex, char* attributeName) {
	int nodeIndex = (sectionIndex - 1) / T;
	int potentialSectionIndex = (sectionIndex - 1) % T;

	Node** toDeleteFrom = getNodeByIndex(head, nodeIndex);

	int actSectionIndex = actualSectionIndex(toDeleteFrom, potentialSectionIndex);

	int toReturn = UNSUCCESSFUL_DELETION;

	if ((*toDeleteFrom)->sections[actSectionIndex] != nullptr) {
		toReturn = removeAttributeFromList(&((*toDeleteFrom)->sections[actSectionIndex]->attributes), attributeName);

		if ((*toDeleteFrom)->sections[actSectionIndex]->attributes == nullptr) {
			deleteSelectors(&((*toDeleteFrom)->sections[actSectionIndex]->selectors));

			Section* temp = (*toDeleteFrom)->sections[actSectionIndex];
			free(temp);
			(*toDeleteFrom)->sections[actSectionIndex] = nullptr;

			(*toDeleteFrom)->count--;

			handlePossiblyEmptyNode(head, toDeleteFrom);
		}
	}

	return toReturn;
}



int deleteWholeSection(Node** head, int index) {
	int nodeIndex = (index - 1) / T;
	int potentialSectionIndex = (index - 1) % T;

	Node** toDeleteFrom = getNodeByIndex(head, nodeIndex);

	int sectionIndex = actualSectionIndex(toDeleteFrom, potentialSectionIndex);

	if ((*toDeleteFrom) != nullptr) {


		if ((*toDeleteFrom)->sections[sectionIndex] != nullptr) {
			deleteAttributes(&((*toDeleteFrom)->sections[sectionIndex]->attributes));
			deleteSelectors(&((*toDeleteFrom)->sections[sectionIndex]->selectors));

			free((*toDeleteFrom)->sections[sectionIndex]);

			(*toDeleteFrom)->count--;
			(*toDeleteFrom)->sections[sectionIndex] = nullptr;

			handlePossiblyEmptyNode(head, toDeleteFrom);

			return SUCCESSFUL_DELETION;
		}
		else {
			return UNSUCCESSFUL_DELETION;
		}
	}

	return UNSUCCESSFUL_DELETION;
}



void lastAttributeValueFromSelector(Node** head, char* attributeName, char* selectorName, char* buffer) {
	Node* temp = (*head);

	if (temp == nullptr) {
		return;
	}
	else {
		temp = temp->prev;

		while (temp->prev != (*head)) {
			if (doesNodeHaveAttributeForSelector(&temp, attributeName, selectorName, buffer)) {
				return;
			}

			temp = temp->prev;
		}

		if (doesNodeHaveAttributeForSelector(&temp, attributeName, selectorName, buffer)) {
			return;
		}

		doesNodeHaveAttributeForSelector(&(temp->prev), attributeName, selectorName, buffer);
	}
}



int getSelectorOccurenceCount(Node** head, char* select) {
	Node* temp = (*head);
	int sum = 0;

	if (temp != nullptr) {
		sum += selectorCountPerNode((&temp), select);

		while (temp->next != (*head)) {
			temp = temp->next;

			sum += selectorCountPerNode((&temp), select);
		}
	}

	return sum;
}



void getSelectorFromSection(Node** head, int sectionIndex, int selectorIndex, char* buffer) {
	if (sectionIndex == 29) {
		cout << "";
	}

	Section** target = getSectionByIndex(head, sectionIndex);

	if (target != nullptr) {
		Selectors* temp = (*target)->selectors;

		for (int i = 0; i < (selectorIndex - 1); i++) {
			if (temp != nullptr) {
				temp = temp->next;
			}
			else {
				return;
			}
		}

		if (temp == nullptr) {
			return;
		}

		cout << buffer << " == " << temp->name << endl;
	}
}



void getNumberOfSelectorsForIndex(Node** head, int index, char* buffer) {
	int number = numberOfSelectorsForIndex(head, index);

	if (number >= 0) {
		cout << buffer << " == " << number << endl;
	}
}



void getNumberOfAttributesForIndex(Node** head, int index, char* buffer) {
	int number = numberOfAttributesForIndex(head, index);

	if (number >= 0) {
		cout << buffer << " == " << number << endl;
	}
}



//
// query interpreter
// 



void interpretQuery(char* buffer, Node** head) {
	if (compareStrings(buffer, "?")) {
		cout << buffer << " == " << getSectionCount(head) << endl;
		return;
	}

	if (countCommas(buffer) != 2) {
		return;
	}

	char* outputBuffer = new char[STRING_LENGTH];
	strcpy(outputBuffer, buffer);
	
	char* first_token = buffer;
	char* second_token;
	char* third_token;
	int token_count = 1;

	for (int i = 0; i < STRING_LENGTH; i++) {
		if ((buffer[i] == ASCII_COMMA) && (token_count == 1)) {
			buffer[i] = '\0';
			second_token = &buffer[i + 1];
			token_count++;
		}

		if ((buffer[i] == ASCII_COMMA) && (token_count == 2)) {
			buffer[i] = '\0';
			third_token = &buffer[i + 1];
			break;
		}
	}

	if (compareStrings(second_token, "S")) {
		if (isMutableToInt(first_token)) {
			if (compareStrings(third_token, "?")) {
				getNumberOfSelectorsForIndex(head, atoi(first_token), outputBuffer);
			}
			else {
				getSelectorFromSection(head, atoi(first_token), atoi(third_token), outputBuffer);
			}
		}
		else {
			cout << outputBuffer << " == " << getSelectorOccurenceCount(head, first_token) << endl;
		}
	}
	else if (compareStrings(second_token, "E")) {
		lastAttributeValueFromSelector(head, third_token, first_token, outputBuffer);
	}
	else if (compareStrings(second_token, "D")) {
		if (compareStrings(third_token, "*")) {
			if (deleteWholeSection(head, atoi(first_token)) == SUCCESSFUL_DELETION) {
				cout << outputBuffer << " == deleted" << endl;
			}
		}
		else {
			if (deleteAttributeFromSectionByName(head, atoi(first_token), third_token) == SUCCESSFUL_DELETION) {
				cout << outputBuffer << " == deleted" << endl;
			}
		}
	}
	else if (compareStrings(second_token, "A")) {
		if (isMutableToInt(first_token)) {
			if (compareStrings(third_token, "?")) {
				getNumberOfAttributesForIndex(head, atoi(first_token), outputBuffer);
			}
			else {
				attributeValueBySectionIndex(head, atoi(first_token), third_token, outputBuffer);
			}
		}
		else {
			cout << outputBuffer << " == " << getAttributeOccurenceCount(head, first_token) << endl;
		}
	}
}



//
// main function, where it all begins
//



int main()
{
	char *buffer = new char[STRING_LENGTH];
	Node* head = nullptr;
	Selectors* temp_selectors = nullptr;
	Attributes* temp_attributes = nullptr;
	int mode = SELECTOR_MODE;

	char* new_data = NULL;
	char* new_name = NULL;

	while (cin.getline(buffer, STRING_LENGTH)) {
		if (compareStrings(buffer, QUERY_COMMAND)) {
			mode = QUERY_MODE;
			continue;
		}

		if (compareStrings(buffer, CSS_COMMAND)) {
			mode = SELECTOR_MODE;
			continue;
		}

		if (compareStrings(buffer, "")) {
			continue;
		}

		if (mode == QUERY_MODE) {
			interpretQuery(buffer, &head);
			continue;
		}

		
		

		for (int i = 0; i < STRING_LENGTH; i++) {
			if (buffer[i] == '  ') {
				buffer[i] = '\0';
				continue;
			}

			if (buffer[i] == '\0' && i > 0) {
				if (buffer[i - 1] == ASCII_SPACE) {
					buffer[i - 1] = '\0';
				}
			}

			if (buffer[i] <= 32) {
				continue;
			}

			if ((mode == SELECTOR_MODE) && (buffer[i] == ASCII_COMMA)) {
				addNewSelector(&temp_selectors, new_data);
				new_data = NULL;
				buffer[i] = '\0';

				if (buffer[i + 1] == ASCII_SPACE) {
					buffer[i + 1] = '\0';
				}

				continue;
			}

			// colon
			if ((mode == ATTRIBUTE_MODE) && (buffer[i] == ASCII_COLON)) {
				new_name = new_data;
				new_data = NULL;
				buffer[i] = '\0';

				if (buffer[i + 1] == ASCII_SPACE) {
					buffer[i + 1] = '\0';
				}

				continue;
			}

			// semi-colon
			if ((mode == ATTRIBUTE_MODE) && (buffer[i] == ASCII_SEMICOLON)) {
				addNewAttribute((&temp_attributes), new_name, new_data);
				new_name = NULL;
				new_data = NULL;
				buffer[i] = '\0';

				continue;
			}

			// opening brace
			if ((mode == SELECTOR_MODE) && (buffer[i] == ASCII_OPENBRACE)) {
				mode = ATTRIBUTE_MODE;

				buffer[i] = '\0';

				if (new_data != NULL) {
					addNewSelector(&temp_selectors, new_data);
				}

				new_name = NULL;
				new_data = NULL;

				

				if (i >= 1) {
					if (buffer[i - 1] == ASCII_SPACE) {
						buffer[i - 1] = '\0';
					}
				}

				continue;
			}

			// closing brace
			if ((mode == ATTRIBUTE_MODE) && (buffer[i] == ASCII_CLOSE_BRACE)) {
				mode = SELECTOR_MODE;

				if (new_name != NULL || new_data != NULL) {
					addNewAttribute((&temp_attributes), new_name, new_data);

					new_name = NULL;
					new_data = NULL;
				}

				addToFirstFreeSection(&head, temp_selectors, temp_attributes);

				temp_selectors = nullptr;
				temp_attributes = nullptr;

				if (i >= 1) {
					if (buffer[i - 1] == ASCII_SPACE) {
						buffer[i - 1] = '\0';
					}
				}

				continue;
			}

			if (new_data == NULL) {
				new_data = &buffer[i];
			}
		}

		buffer = new char[STRING_LENGTH];
	}

	



	return 0;
}
