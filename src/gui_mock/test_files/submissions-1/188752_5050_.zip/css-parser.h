﻿#pragma once

#include <iostream>
#include <string.h>

#define T 8

#define STRING_LENGTH 256



#define SELECTOR_MODE 0
#define ATTRIBUTE_MODE 1
#define QUERY_MODE 2

#define QUERY_COMMAND "????"
#define CSS_COMMAND "****"

#define ASCII_COMMA 44
#define ASCII_COLON 58
#define ASCII_SEMICOLON 59
#define ASCII_OPENBRACE 123
#define ASCII_CLOSE_BRACE 125
#define ASCII_SPACE 32

#define SUCCESSFUL_DELETION 1
#define UNSUCCESSFUL_DELETION 0
