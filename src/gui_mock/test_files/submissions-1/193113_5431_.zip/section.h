#pragma once
#include"listi.h"
#include"lists.h"
class Section {
public:
	ListSelektor selelektory;
	ListAtrybutow atrybuty;
	Section();
	Section(ListSelektor, ListAtrybutow);
	Mystring Find(Mystring atr, Mystring sel);
	~Section();
};