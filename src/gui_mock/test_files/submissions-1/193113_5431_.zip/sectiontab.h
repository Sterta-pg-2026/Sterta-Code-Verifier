#pragma once
#include"section.h"
const int T = 17;
class SectionTab {
private:
public:
	Section sectab[T];
	int licznikzaj = 0;
	SectionTab();
	int Sectionadd(Section);
	~SectionTab();
};
