#define _CRT_SECURE_NO_WARNINGS
#ifndef MAP_H
#define MAP_H

#include "linkedlist.h"
#include <iostream>
#include <string.h>

using namespace std;

struct Pair{
    char name[30];
    char value[100];
    Pair(){
        strcpy(name, "unknown");
        strcpy(value, "unknown");
    }
    Pair(const char* _name, const char* _value){
        strcpy(name, _name);
        strcpy(value, _value);
    }
    friend ostream& operator<<(ostream& out, const Pair& aPair)
    {
        out << "name: " << aPair.name << " value: " << aPair.value;
        return out;
    }
};


class Map
{
    LinkedList<Pair> _attributes;
public:
    Map();
    void Add(const char* _name, const char* _value);
    int Count() const {return _attributes.size();}
    Pair& operator[](int idx);
    const Pair& operator[](int idx) const;
    virtual ~Map();
};

#endif // MAP_H
