#define _CRT_SECURE_NO_WARNINGS
#include "common_lib.h"
#include "css_parser.h"
#include <string.h>
#include <iostream>

using namespace std;

CSS_Parser::CSS_Parser(const char *fileName)
{
    N = getSizeOfFile1(fileName);
    S = new char[N+1];
    FileToStr(fileName, S);
    cout << S << endl;
    Parse();
}

void CSS_Parser::Parse()
{
    char *s = new char[N+1];
    strcpy(s, S);

    int pos = indexOf(s, '{');
    while (pos != -1){
        //get list of selectors names
        char *buf = new char[pos+1];
        strncpy(buf, s, pos);        buf[pos] = 0;
        removeSymbolsFromStr(s, 0, pos);

        LinkedList<Name> names;
        char* selectorName = strtok(buf, " ,");
        while (selectorName){
            Name sel_name; //struct
            strcpy(sel_name.name, selectorName);
            names.push_back(sel_name);
            selectorName = strtok(NULL, " ,");
        }
        delete[] buf;


        //get selectors attributes {...}
        int pos1 = indexOf(s, '{');
        int pos2 = indexOf(s, '}');
        char *declarations = new char[pos2+1];
        strncpy(declarations, s+pos1+1, pos2-pos1-1);
        declarations[pos2-pos1-1] = 0;
        removeSymbolsFromStr(s, 0, pos2+1);

        //Selector tmp;
        allTrim(declarations);
        char* declaration = strtok(declarations, ";");
        while (declaration){
            allTrim(declaration);
            //cout << declaration << endl;

            int pos3 = indexOf(declaration, ':');

            char attr_name[50];
            strncpy(attr_name, declaration, pos3);  attr_name[pos3] = 0;

            char attr_value[500];
            strcpy(attr_value, declaration+pos3+1);

            cout <<"==>" << attr_name << " " << attr_value << endl;

            declaration = strtok(NULL, ";");
        }

        delete[] declarations;

        //removeSymbolsFromStr(s, 0, pos2+1);

        pos = indexOf(s, '{');
    }

    delete[] s;
}

CSS_Parser::~CSS_Parser()
{
    //dtor
}
