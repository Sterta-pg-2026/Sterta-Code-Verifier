#include "map.h"
#include <string.h>

Map::Map()
{
    //ctor
}

void Map::Add(const char* _name, const char* _value){
    int n = _attributes.size();
    int pos = -1;
    for (int i=0; i<n; i++){
        Pair p = _attributes[i];
        if (strcmp(_name, p.name)==0){
            pos = i;
            break;
        }
    }

    if (pos != -1){
        strcpy(_attributes[pos].value, _value);
    } else {
        Pair p(_name, _value);
      //  cout << p << endl;
        _attributes.push_back(p);
    }
}

Pair& Map::operator[](int idx){
    return _attributes[idx];
}

const Pair& Map::operator[](int idx)const {
    return _attributes[idx];
}

Map::~Map()
{
    //dtor
}
