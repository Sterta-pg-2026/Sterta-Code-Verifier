#ifndef COMMON_LIB_H_INCLUDED
#define COMMON_LIB_H_INCLUDED

struct Name{
    char name[50];
};

int getSizeOfFile1(const char* fileName);
int FileToStr(const char* fileName, char *S);
void CtrlSymbolsToSpaces(char* S);
int indexOf(const char* S, char c);
void removeSymbolByPos(char* S, int pos);
void removeSymbolsFromStr(char* S, int startPos, int count);
void leftTrim(char* S);
void rightTrim(char* S);
void allTrim(char* S);

#endif // COMMON_LIB_H_INCLUDED
