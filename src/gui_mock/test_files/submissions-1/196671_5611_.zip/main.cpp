#include "map.h"
#include "selector.h"
#include "linkedlist.h"
#include "common_lib.h"
#include "css_parser.h"
#include <iostream>

using namespace std;

int main()
{
    //CSS_Parser("C:/Users/Public/abs.css"); cout << endl;
   /* Selector s1("h1");
    s1.AddAttr("min-width", "780px");
    s1.AddAttr("margin", "0");
    s1.AddAttr("padding", "0");
    s1.AddAttr("font-family", "\"Trebuchet MS\", \"Lucida Grande\", Arial");
    s1.AddAttr("font-size", "85%");
    s1.AddAttr("margin", "5");
    s1.AddAttr("color", "#666666");
    cout << s1 << endl;*/

    return 0;
}
