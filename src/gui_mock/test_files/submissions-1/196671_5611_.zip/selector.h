#ifndef SELECTOR_H
#define SELECTOR_H
#include "map.h"

class Selector
{
    char name[50];
    Map attributes;
public:
    Selector();
    Selector(const char* _name);
    int Count() const {return attributes.Count();}
    void AddAttr(const char* _name, const char* _value);
    virtual ~Selector();

    friend ostream& operator<<(ostream& out, const Selector& selector){
        out << "Selector name: " << selector.name << endl;
        int n = selector.attributes.Count();
        for (int i=0; i<n; i++){
            out << selector.attributes[i] << endl;
        }
        return out;
    }
};

#endif // SELECTOR_H
