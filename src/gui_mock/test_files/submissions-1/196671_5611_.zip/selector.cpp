#include "selector.h"
#include <string.h>

Selector::Selector()
{
    strcpy(name, "noname");
}

Selector::Selector(const char* _name){
    strcpy(name, _name);
}

void Selector::AddAttr(const char* _name, const char* _value){
    attributes.Add(_name, _value);
}

Selector::~Selector()
{
    //dtor
}
