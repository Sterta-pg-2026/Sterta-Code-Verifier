#ifndef CSS_PARSER_H
#define CSS_PARSER_H
#include "linkedlist.h"
#include "selector.h"

class CSS_Parser
{
    char* S;
    int N;
    LinkedList<Selector> selectors;
    void Parse();
public:
    CSS_Parser(const char *fileName);

    virtual ~CSS_Parser();
};

#endif // CSS_PARSER_H
