#define _CRT_SECURE_NO_WARNINGS
#include "common_lib.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <iostream>

using namespace std;

int getSizeOfFile1(const char* filename) {
    FILE* file;
    char input[100];
    file = fopen("output.txt", "w");

    printf("Enter your input:\n");
    while (fgets(input, sizeof(input), stdin) != NULL) {
        fprintf(file, "%s", input);
    }

    // Close file
    fclose(file);
    printf("Saved successfully.\n");
    return 0;
}
 
//int getSizeOfFile(const char* fileName){
//    FILE* F = fopen(fileName, "rb");
//    if (!F) {
//        cout << " File not found: " << fileName << endl;
//        return -1;
//    }
//    fseek(F, 0, SEEK_END);
//    int len = ftell(F);
//    fclose(F);
//    return len;
//}


int FileToStr(const char* fileName, char *S){
    FILE* F = fopen(fileName, "rt");
    if (!F) {
        cout << " File not found: " << fileName << endl;
        return 0;
    }

    int j=0;
    while(true){
        int c = fgetc(F);
        if (c == EOF) break;
        S[j++] = c;
    }
    S[j] = 0;
    CtrlSymbolsToSpaces(S);
    fclose(F);
    return 0;
}

void CtrlSymbolsToSpaces(char* S){
    int n = strlen(S);
    for (int i=0; i<n; i++){
        if (0<=S[i] && S[i]<32){
            S[i] = 32;
        }
    }
}

int indexOf(const char* S, char c){
    int n = strlen(S);
    for (int i=0; i<n; i++){
        if (S[i]==c) return i;
    }
    return -1;
}

void removeSymbolByPos(char* S, int pos){
    int n = strlen(S);
    for (int i=pos; i<n; i++){
        S[i] = S[i+1];
    }
}

void removeSymbolsFromStr(char* S, int startPos, int count){
    for (int i=0; i<count; i++){
        removeSymbolByPos(S, startPos);
    }
}

void leftTrim(char* S){
    int len = strlen(S);
    while (len>0 && S[0]==32){
        removeSymbolsFromStr(S, 0, 1);
        len--;
    }
}

void rightTrim(char* S){
    int len = strlen(S);
    while (len>0 && S[len-1]==32){
        removeSymbolsFromStr(S, len-1, 1);
        len--;
    }
}

void allTrim(char* S){
    rightTrim(S);
    leftTrim(S);
}














