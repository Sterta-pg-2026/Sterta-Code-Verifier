#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "read_css.h"

int main() { operateFunctions(); return 0; }