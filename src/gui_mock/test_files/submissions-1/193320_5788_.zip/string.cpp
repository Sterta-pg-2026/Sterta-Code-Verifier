#define _CRT_SECURE_NO_WARNINGS
#include "string.h"

String::String() {
    data = new char[1];
    data[0] = '\0';
}

String::String(const char* str) {
    size_t len = strlen(str);
    data = new char[len + 1];
    strcpy(data, str);
}

String::String(const char* str, int len) {
    data = new char[len + 1];
    memcpy(data, str, len);
}

String::String(const String& other) {
    size_t len = strlen(other.data);
    data = new char[len + 1];
    strcpy(data, other.data);
}

String::~String() {
    delete[] data;
}

size_t String::size() const {
    return strlen(data);
}

void String::setNewText(const char* text, int length)
{
    delete data;
    data = new char[length + 1];
    memcpy(data, text, length);
    data[length] = 0;
}

const char* String::c_str() const {
    return data;
}

