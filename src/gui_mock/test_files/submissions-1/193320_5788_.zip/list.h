#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include "string.h"

const int myNumb = 17;

using namespace std;
template<typename T>class Node {
private:
    T data[myNumb];
    Node<T>* next;
    Node<T>* prev;
    int size;
    template<typename U>friend class List;
    template<typename U>friend class Wsk;
public:
    Node(T item) {
        this->next = NULL;
        this->prev = NULL;
        size = 1;
        data[0] = item;
    }
    bool full() const
    {
        return size == myNumb;
    }
    bool empty() const
    {
        return size == 0;
    }
    void add(T item)
    {
        data[size++] = item;
    }
    void remove(int index)
    {
        for (int i = index; i < size - 1; i++)
        {
            data[i] = data[i + 1];
        }
        size--;
    }
};

template<typename T> class Wsk {

    int indexNode;
    Node<T>* node;
public:
    void moveNext()
    {
        indexNode++;
        if (indexNode == node->size)
        {
            node = node->next;
            indexNode = 0;
        }
    }
    void moveBack()
    {
        indexNode--;
        if (indexNode < 0)
        {
            node = node->prev;
            if (node != NULL)
            {
                indexNode = node->size - 1;
            }
            else
            {
                indexNode = 0;
            }

        }
    }

    bool empty() const
    {
        return node == NULL;
    }
    T getValue() const
    {
        return node->data[indexNode];
    }
    T* getValueWsk()
    {
        return &(node->data[indexNode]);
    }

    template<typename U>friend class List;
};

template<typename T>class List {
private:
    Node<T>* head;
    Node<T>* tail;
    int size;
public:
    List();
    ~List();
    void addBack(T item);
    int length() const;
    bool remove(int index);
    bool remove(Wsk<T> wsk);
int search(int index, Node<T>*& node);

    int SearchElementIndex(T searchValue);
    T* SearchElement(T searchValue);
    Wsk<T> SearchElementToIterator(T searchValue);
    T* get(int index);
    Wsk<T> getIterator(int index);
    Wsk<T> getBegin() const;
    Wsk<T> getEnd() const;
    void removeAll();
private:
    bool remove(int nodeIndex, Node<T>* node);

};