#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class Section;

template<typename T>class List;

class String
{
private:
    char* data;

public:
    String();
    String(const char* str);
    String(const String& other);
    String(const char* str, int len);
    ~String();
    size_t size() const;
    const char* c_str() const;
    void setNewText(const char* text, int length);

    friend void operateFunctions();
    friend void sortCSS(String& myCSS, List<Section> &mySections, int size);
    
    String& operator=(const String& str) {
        if (this != &str) {
            delete[] data;
            size_t len = strlen(str.data);
            data = new char[len + 1];
            strcpy(data, str.data);
        }
        return *this;
    }

    String operator+(const char& str) const {
        char* temp = new char[strlen(data) + 2];
        strcpy(temp, data);
        temp[strlen(data)] = str;
        temp[strlen(data) + 1] = '\0';
        String result(temp);
        delete[] temp;
        return result;
    }

    String operator+(const String& str) const {
        char* temp = new char[strlen(data) + strlen(str.data) + 1];
        strcpy(temp, data);
        strcat(temp, str.data);
        String result(temp);
        delete[] temp;
        return result;
    }

    bool operator==(const String& str) const {
        return !strcmp(data, str.data);
    }
};