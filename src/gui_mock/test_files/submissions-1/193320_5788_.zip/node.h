#pragma once
#include <iostream>
using namespace std;

class Node
{
public:
	int data;
	Node* prev;
	Node* next;

};

