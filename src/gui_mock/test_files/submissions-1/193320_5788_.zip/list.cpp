#include "list.h"

template<typename T>
List<T>::List() {
    this->head = NULL;
    this->tail = NULL;
    size = 0;
}

template<typename T>
List<T>::~List() {
    this->head = NULL;
    this->tail = NULL;
    size = 0;
}

template<typename T>
int List<T>::SearchElementIndex(T searchValue) {
    int index = 0;
    for (Wsk<T> i = getBegin(); !i.empty(); i.moveNext())
    {
        if (i.getValue() == searchValue)
        {
            return index;
        }
        index++;
    }
    return INT_MAX;
}

template<typename T>
T* List<T>::SearchElement(T searchValue) {
    for (Wsk<T> i = getBegin(); !i.empty(); i.moveNext())
    {
        if (i.getValue() == searchValue)
        {
            return i.getValueWsk();
        }
    }
    return NULL;
}

template<typename T>
Wsk<T> List<T>::SearchElementToIterator(T searchValue) {
    for (Wsk<T> i = getBegin(); !i.empty(); i.moveNext())
    {
        if (i.getValue() == searchValue)
        {
            return i;
        }
    }
    return getBegin().moveBack();
}

template<typename T>
Wsk<T> List<T>::getBegin() const
{
    Wsk<T> wsk;
    wsk.indexNode = 0;
    wsk.node = head;
    return wsk;
}

template<typename T>
Wsk<T> List<T>::getEnd() const
{
    Wsk<T> wsk;
    wsk.indexNode = tail->size - 1;
    wsk.node = tail;
    return wsk;
}

template<typename T>
void List<T>::addBack(T item) {
    size++;

    if (head == NULL) {
        head = new Node<T>(item);
        tail = head;
        return;
    }
    else if (!tail->full()) {
        tail->add(item);
    }
    else
    {
        Node<T>* temp = new Node<T>(item);
        tail->next = temp;
        temp->prev = tail;
        tail = temp;
    }
}

template<typename T>
int List<T>::length() const {
    return size;
}

template<typename T>
int List<T>::search(int index, Node<T>*& node)
{
    node = head;
    while (node != NULL)
    {
        if (index < node->size)
        {
            return index;
        }
        else
        {
            index = index - node->size;
            node = node->next;
        }
    }
    return index;
}

template<typename T>
bool List<T>::remove(Wsk<T> wsk) {

    return remove(wsk.indexNode, wsk.node);
}

template<typename T>
bool List<T>::remove(int index) {
    if (head == NULL) {
        return false;
    }
    if (index >= length() * myNumb || index < 0) {
        return false;
    }
    else {
        Node<T>* temp = NULL;
        int nodeIndex = search(index, temp);
        return remove(nodeIndex, temp);
    }
}

template<typename T>
bool List<T>::remove(int nodeIndex, Node<T>* node)
{
    if (head == NULL) {
        return false;
    }
    
    if (node == NULL)
    {
        return false;
    }

    if (node->size > 1)
    {
        node->remove(nodeIndex);
    }
    else if (head == tail)
    {
        delete head;
        head = NULL;
        tail = NULL;
    }
    else if (node == head)
    {
        head = head->next;
        head->prev = NULL;
        delete node;
    }
    else if (node == tail)
    {
        tail = tail->prev;
        tail->next = NULL;
        delete node;
    }
    else
    {
        Node<T>* before = node->prev;
        Node<T>* after = node->next;
        delete node;
        before->next = after;
        after->prev = before;
    }
    size--;
    return true;
}

template<typename T>
T* List<T>::get(int index) {
    if (head == NULL || index >= length() * myNumb || index < 0) {
        throw "Index invalid";
    }
    else {
        Node<T>* temp = NULL;
        int nodeIndex = search(index, temp);
        if (temp == NULL)
        {
            return NULL;
        }
        return &temp->data[nodeIndex];
    }
}

template<typename T>
Wsk<T> List<T>::getIterator(int index)
{
    if (head == NULL || index >= length() * myNumb || index < 0) {
        throw "Index invalid";
    }
    else {
        Node<T>* temp = NULL;
        int nodeIndex = search(index, temp);
        if (temp == NULL)
        {
            Wsk<T> empty = getEnd();
            empty.moveNext();
            return empty;
        }
        Wsk<T> wsk;
        wsk.indexNode = nodeIndex;
        wsk.node = temp;
        return wsk;
    }

}

template<typename T>
void  List<T>::removeAll()
{
    tail = NULL;
    size = 0;
    Node<T>* temp;
    while (head != NULL)
    {
        temp = head;
        head = head->next;
        delete temp;
    }
}