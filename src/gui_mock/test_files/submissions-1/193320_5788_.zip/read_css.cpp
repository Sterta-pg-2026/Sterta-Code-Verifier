#define _CRT_SECURE_NO_WARNINGS
#include "read_css.h"

void operateFunctions() {
    char* myCSSTab = new char[10000];
    char getSymbol;
    char order[64];
    for (int i = 0; i < 64; i++)
        order[i] = '@';
    int size = 0;
    List<Section> cssSection;
    int test1 = 0, test2 = 0, test3 = 0, test4 = 0, test5 = 0, i = 0, numSections;
    while ((getSymbol = getchar()) != EOF) {
        if (test1 < 4) {
            if (getSymbol == '?')
                test1++;
            else
                test1 = 0;
            if (getSymbol == ':') {
                test3 = 1;
                test4 = 0;
            }
            if (getSymbol == ';' ) {
                test4 = 1;
                test3 = 0;
            }
            if ((test3 == 1 && test4 == 0) || test5 == 1) {
                myCSSTab[size] = getSymbol;
                size++;
            }
            else {
                if (getSymbol != ' ' && getSymbol != '\f' && getSymbol != '\n' && getSymbol != '\r' && getSymbol != '\t' && getSymbol != '\v')
                {
                    myCSSTab[size] = getSymbol;
                    size++;
                }
            }
            test2 = 0;
        }
        else {
            if (test2 == 0) {
                size -= 4;
                String myCSS(myCSSTab, size);
                sortCSS(myCSS, cssSection, size);
                test2 = 1;
            }
            if (getSymbol != '\n') {
                char temp = getSymbol;
                order[i] = temp;
                i++;
            }
            else {
                order[i + 1] = '\n';
                serviceOrders(cssSection, order);
                for (int j = 0; j < 64; j++)
                    order[j] = '@';
                i = 0;
            }
            if (i > 3)
                if (order[i - 4] == '*' && order[i - 3] == '*' && order[i - 2] == '*' && order[i - 1] == '*') {
                    test1 = i = 0;
                    for (int i = 0; i < 64; i++)
                        order[i] = '@';
                    size = 0;
                }
        }
    }
    delete[] myCSSTab;
}

void readTextToChar(char* myCSS, int& index, int size, String& text, char stop1, char stop2=0)
{
    int startIndex = index;
    int length = 0;
    for (; index < size; index++)
    {
        if (myCSS[index] != stop1 && myCSS[index]!=stop2)
        {
            length++;
        }
        else
        {
            break; 
        }
    }
    text.setNewText(myCSS + startIndex, length);
}

void readSection(char* myCSS, int& index, int size, Section& section)
{
    while (myCSS[index] != '{')
    {
        String selector;
        readTextToChar(myCSS, index, size, selector, '{',',');
        section.selectors.addBack(selector);

        if (myCSS[index] == ',')
        {
            index++;
        }
    }
    index++;

    int iterator = 0;
    bool isduplicated;
    while (myCSS[index] != '}')
    {
        String attribute;
        readTextToChar(myCSS, index, size, attribute, ':');
        iterator = 0;
        isduplicated = false;

        for (Wsk<String> wsk = section.attributes.getBegin(); !wsk.empty(); wsk.moveNext())
        {
            if (*wsk.getValueWsk() == attribute)
            {
                isduplicated = true;
                break;
            }
            iterator++;
        }
     
        if (!isduplicated)
        {
            section.attributes.addBack(attribute);
        }
        
        index++;
        String value;
        readTextToChar(myCSS, index, size, value, ';','}');
        
        if (isduplicated)
        {
            section.values.get(iterator)->setNewText(value.c_str(),value.size());
        }
        else
        {
            section.values.addBack(value);
        }
        
        if (myCSS[index] != '}')
        {
            index++;
        }
    }
}

void sortCSS(String& myCSS, List<Section> &mySections, int size) {
    for (int i = 0; i < size; i++)
    {
        Section section;
        readSection(myCSS.data, i, size, section);
        mySections.addBack(section);
        char pom = myCSS.data[i];
    }

}

String charToString(int max, int min, char a[]) {
    String str;
    for (int i = min; i < max + 1; i++) {
        if (a[i] == '@' || a[i] == ',')
            return str;
        str = str + a[i];
    }
    return str;
}

bool isIntiger(char a[], int max, int min) {
    if (min != 0) {
        max = min;
        for (; ; max++)
            if (!(a[max] < 58 && a[max] > 47))
                break;
    }
    for (int i = min; i < max; i++) {
        if (!(a[i] < 58 && a[i] > 47))
            return false;
    }
    return true;
}

int intoInt(int max, int min, char a[]) {
    int number = 0;
    for (int i = min; i < max; i++) {
        number += (int)((a[i] - 48) * pow(10, max - i - 1));
    }
    return number;
}

int intoInt2(int min, char a[]) {
    int i = min;
    for (; ; i++)
        if (!(a[i] < 58 && a[i] > 47))
            break;
    return intoInt(i, min, a);
}

void serviceOrders(List<Section>& cssSection, char order[]) {
    if (order[0] == '?') {
        cout << "? == " << cssSection.length() << endl;
    }
    else  if (order[0] == 'X')
    {

        for (int i = 0; i < cssSection.length(); i++) {

            cout << endl << "SELECTORS:" << endl;
            for (int j = 0; j < cssSection.get(i)->selectors.length(); j++)
                cout << cssSection.get(i)->selectors.get(j)->c_str() << " ";

            cout << endl << "ATTRIBUTES:" << endl;
            for (int j = 0; j < cssSection.get(i)->attributes.length(); j++)
                cout << cssSection.get(i)->attributes.get(j)->c_str() << " ";

            cout << endl << "VALUES:" << endl;
            for (int j = 0; j < cssSection.get(i)->values.length(); j++)
                cout << cssSection.get(i)->values.get(j)->c_str() << " ";
        }
        cout << endl;

    }
    else {
        int i = 0;
        for (i; i < 64; i++) {
            if (order[i] == ',')
                break;
        }
        if (isIntiger(order, i, 0) && order[i + 1] == 'S' && order[i + 3] == '?') {
            int ii = intoInt(i, 0, order);
            if (cssSection.length() != 0 && cssSection.length() > ii - 1 && ii - 1 >= 0)
                cout << ii << ",S,? == " << cssSection.get(ii - 1)->selectors.length() << endl;
        }
        else if (isIntiger(order, i, 0) && order[i + 1] == 'A' && order[i + 3] == '?') {
            int ii = intoInt(i, 0, order);
            if (cssSection.length() != 0 && cssSection.length() > ii - 1 && ii - 1 >= 0)
                cout << ii << ",A,? == " << cssSection.get(ii - 1)->attributes.length() << endl;
        }
        else if (order[i + 1] == 'S' && isIntiger(order, i, 0) && isIntiger(order, 64, i + 3)) {
            int ii = intoInt(i, 0, order);
            int jj = intoInt2(i + 3, order);
            if ((cssSection.length() != 0 && cssSection.length() > ii - 1 && ii - 1 >= 0) && (cssSection.get(ii - 1)->selectors.length() != 0 && cssSection.get(ii - 1)->selectors.length() > jj - 1 && jj - 1 >= 0))
                cout << ii << ",S," << jj << " == " << cssSection.get(ii - 1)->selectors.get(jj - 1)->c_str() << endl;
        }
        else if (isIntiger(order, i, 0) && order[i + 1] == 'A') {
            int ii = intoInt(i, 0, order);
            String atr = charToString(64, i + 3, order);
            if (cssSection.length() != 0 && cssSection.length() >= ii - 1 && ii - 1 >= 0) {
                int newIndex = cssSection.get(ii - 1)->attributes.SearchElementIndex(atr);
                if (newIndex != INT_MAX)
                    cout << ii << ",A," << atr.c_str() << " == " << cssSection.get(ii - 1)->values.get(newIndex)->c_str() << endl;
            }
        }
        else if (order[i + 1] == 'A' && order[i + 3] == '?') {
            String atr = charToString(i, 0, order);
            int test = 0;
            for (int i = 0; i < cssSection.length(); i++) {
                if (cssSection.get(i)->attributes.SearchElementIndex(atr) != INT_MAX)
                    test++;
            }
            cout << atr.c_str() << ",A,? == " << test << endl;
        }
        else if (order[i + 1] == 'S' && order[i + 3] == '?') {
            String sel = charToString(i, 0, order);
            int test = 0;
            for (int i = 0; i < cssSection.length(); i++) {
                if (cssSection.get(i)->selectors.SearchElementIndex(sel) != INT_MAX)
                    test++;
            }
            cout << sel.c_str() << ",S,? == " << test << endl;
        }
        else if (order[i + 1] == 'E') {
            String sel = charToString(i, 0, order);
            String atr = charToString(64, i + 3, order);

            for (Wsk<Section> sectionWsk = cssSection.getEnd(); !sectionWsk.empty(); sectionWsk.moveBack())
            {
                List<String>* selectors = &(sectionWsk.getValueWsk()->selectors);
                for (Wsk<String> selectorWsk = selectors->getBegin(); !selectorWsk.empty(); selectorWsk.moveNext())
                {
                    if (*selectorWsk.getValueWsk() == sel)
                    {
                        List<String>* attributes = &(sectionWsk.getValueWsk()->attributes);
                        int counter = 0;
                        for (Wsk<String> attributesWsk = attributes->getEnd(); !attributesWsk.empty(); attributesWsk.moveBack())
                        {
                            if (*attributesWsk.getValueWsk() == atr)
                            {
                                int secionValuesLength = sectionWsk.getValueWsk()->values.length();
                                String* value = sectionWsk.getValueWsk()->values.get(secionValuesLength - 1 - counter);
                                cout << sel.c_str() << ",E," << atr.c_str() << " == " << value->c_str() << endl;
                                return;
                            }
                            counter++;
                        }
                    }
                }

            }
        }
        else if (order[i + 1] == 'D' && order[i + 3] == '*') {
            int ii = intoInt(i, 0, order);
            if (cssSection.remove(ii - 1))
            {
                cout << ii << ",D,* == deleted" << endl;
            }
        }
        else if (order[i + 1] == 'D') {
            int ii = intoInt(i, 0, order);
            String atr = charToString(64, i + 3, order);
            if (cssSection.length() != 0 && cssSection.length() > ii - 1 && ii - 1 >= 0) {
                Wsk<Section> cssSectionWsk = cssSection.getIterator(ii - 1);
                Section* section = cssSectionWsk.getValueWsk();
                
                int newIndex = section->attributes.SearchElementIndex(atr);
                if (newIndex != INT_MAX) {
                    if (section->values.remove(newIndex) && section->attributes.remove(newIndex))
                    {
                        cout << ii << ",D," << atr.c_str() << " == deleted" << endl;
                    }
                    if (section->values.length() == 0)
                    {
                        cssSection.remove(cssSectionWsk);
                    }
                }
            }
        }
    }
}