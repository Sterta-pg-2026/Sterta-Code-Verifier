#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cmath>
#include "string.h"
#include "list.h"
#include "list.cpp"
using namespace std;

class Section {
public:
    List<String> selectors;
    List<String> attributes;
    List<String> values;
    Section() = default;
};

void operateFunctions();
bool isIntiger(char a[], int max, int min);
int intoInt(int max, int min, char a[]);
int intoInt2(int min, char a[]);
String charToString(int max, int min, char a[]);
void serviceOrders(List<Section>& cssSection, char order[]);
void sortCSS(String& myCSS, List<Section> &mySections, int size);