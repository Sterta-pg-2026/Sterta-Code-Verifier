#pragma once
#define ARRAY_SIZE 8
#include <iostream>
#include "string.h"
#include "list.cpp"