#pragma once
#include "includes.h"

class Selectors {
public:
	String* selectorsList;
	unsigned int occupiedCells;

	Selectors();
	Selectors(const Selectors& other);
	~Selectors();

	void push_back(const String& str);

	Selectors& operator = (const Selectors& other);
};