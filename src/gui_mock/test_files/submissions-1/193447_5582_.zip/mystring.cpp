#pragma once
#include "mystring.h"

 std::istream& mygetline(std::istream& is, MyString& str, char delim) {
    // Clear the contents of the MyString object
    str.clear();

    char c;
    while (is.get(c) && c != delim) {
        str.push_back(c);
    }
    return is;
}

MyString::MyString() {
    m_data = new char[1];
    m_data[0] = '\0';
    m_size = 0;
}

MyString::MyString(const char* str) {
    m_size = std::strlen(str);
    m_data = new char[m_size + 1];
    strcpy_s(m_data, m_size + 1, str);
}

MyString::MyString(const MyString& other) {
    m_size = other.m_size;
    m_data = new char[m_size + 1];
    strcpy_s(m_data, m_size + 1, other.m_data);
}

MyString::~MyString() {
    delete[] m_data;
}

MyString&MyString:: operator=(const MyString& other) {
    if (this != &other) {
        delete[] m_data;
        m_size = other.m_size;
        m_data = new char[m_size + 1];
        strcpy_s(m_data, m_size + 1, other.m_data);
    }
    return *this;
}

 const char* MyString::c_str() const {
    return m_data;
}

 size_t MyString::size() const {
    return m_size;
}

bool MyString::operator==(const MyString& other) const {
    if (m_size != other.m_size)
        return false;
    return strcmp(m_data, other.m_data) == 0;
}

MyString MyString::operator+(const MyString& other) const {
    MyString result;
    result.m_size = m_size + other.m_size;
    result.m_data = new char[result.m_size + 1];
    strcpy_s(result.m_data, result.m_size + 1, m_data);
    strcat_s(result.m_data, result.m_size + 1, other.m_data);
    return result;
}

MyString MyString::operator+=(const MyString& other) {
    size_t new_size = m_size + other.m_size;
    char* new_data = new char[new_size + 1];
    strcpy_s(new_data, new_size + 1, m_data);
    strcat_s(new_data, new_size + 1, other.m_data);
    delete[] m_data;
    m_data = new_data;
    m_size = new_size;
    return *this;
}

MyString MyString::operator+=(char c) {
    size_t new_length = m_size + 1;
    char* new_data = new char[new_length + 1];
    strcpy_s(new_data, new_length + 1, m_data);
    new_data[new_length - 1] = c;
    new_data[new_length] = '\0';
    delete[] m_data;
    m_data = new_data;
    m_size = new_length - 1;
    return *this;
}

 std::ostream& operator<<(std::ostream& os, const MyString& str) {
    return os << str.m_data;
}

 std::istream& operator>>(std::istream& is, MyString& str)
{
    char buffer[4096];
    is.getline(buffer, 4096);
    str = buffer;
    return is;
}


 bool MyString::empty() const {
    return m_size == 0;
}
 void  MyString::clear() {
    delete[] m_data;
    m_data = nullptr;
    m_size = 0;
}

 void  MyString::push_back(char c) {
    const size_t new_size = m_size + 1;
    char* new_data = new char[new_size + 1];
    memcpy_s(new_data, new_size + 1, m_data, m_size);
    new_data[m_size] = c;
    new_data[new_size] = '\0';
    delete[] m_data;
    m_data = new_data;
    m_size = new_size;
}

const char& MyString::operator[](size_t index) const {
    return m_data[index];
}
char& MyString::operator[](size_t index) {
    return m_data[index];
}

int  MyString::CompareTo(const MyString& other) const {
    size_t size1 = size();
    size_t size2 = other.size();
    size_t minSize = std::min(size1, size2);

    for (size_t i = 0; i < minSize; i++) {
        if (m_data[i] < other.m_data[i]) {
            return -1;
        }
        else if (m_data[i] > other.m_data[i]) {
            return 1;
        }
    }

    if (size1 < size2) {
        return -1;
    }
    else if (size1 > size2) {
        return 1;
    }
    else {
        return 0;
    }
}


