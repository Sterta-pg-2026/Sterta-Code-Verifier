﻿#include "Node.h"

Node::Node() {
    prev = nullptr;
    next = nullptr;
}

Node::Node(MyString d) {
    data = d;
    prev = nullptr;
    next = nullptr;
}

void Node::push(Node** head_ref, MyString new_data) {
    Node* new_node = new Node(new_data);

    new_node->next = *head_ref;
    new_node->prev = nullptr;

    if (*head_ref != nullptr) {
        (*head_ref)->prev = new_node;
    }

    *head_ref = new_node;
}

void Node::insertAfter(Node* prev_node, MyString new_data) {
    if (prev_node == nullptr) {
        std::cout << "The given previous node cannot be null." << std::endl;
        return;
    }

    Node* new_node = new Node(new_data);

    new_node->next = prev_node->next;
    prev_node->next = new_node;
    new_node->prev = prev_node;

    if (new_node->next != nullptr) {
        new_node->next->prev = new_node;
    }
}

void Node::append(Node** head_ref, MyString new_data) {
    Node* new_node = new Node(new_data);
    Node* last = *head_ref;

    if (*head_ref == nullptr) {
        new_node->prev = nullptr;
        *head_ref = new_node;
        return;
    }

    while (last->next != nullptr) {
        last = last->next;
    }

    last->next = new_node;
    new_node->prev = last;
}

void Node::printList(Node* node) {
    Node* last = nullptr;
    std::cout << "Traversal in forward direction: ";
    while (node != nullptr) {
        std::cout << node->data << " ";
        last = node;
        node = node->next;
    }

    std::cout << std::endl << "Traversal in reverse direction: ";
    while (last != nullptr) {
        std::cout << last->data << " ";
        last = last->prev;
    }

    std::cout << std::endl;
}

