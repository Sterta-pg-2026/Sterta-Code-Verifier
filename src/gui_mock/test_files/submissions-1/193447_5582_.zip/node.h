#pragma once

#include "mystring.h"

class Node {
public:
    Node* prev;
    MyString data;
    Node* next;

    Node();
    Node(MyString d);

    void push(Node** head_ref, MyString new_data);
    void insertAfter(Node* prev_node, MyString new_data);
    void append(Node** head_ref, MyString new_data);
    void printList(Node* node);
};
