﻿#pragma once
#include "cssparser.h"


int main()
{
	MyString a;
	Node cos;
	CSSParser parser;

	Node* listaSelektorow = new Node();

	parser.Parse();
	cos.printList(listaSelektorow);

	return 0;
}
