#include "cssparser.h"

Selector::Selector(const MyString& s) : selector(s) {}

void Selector::AddAttribute(const MyString& key, const MyString& value) {
    attributes.push_back(std::make_pair(key, value));
}

bool Selector::operator<(const Selector& other) const {
    return selector.CompareTo(other.selector) < 0;
}

void CSSParser::Parse() {
    MyString input;
    std::vector<Selector> selectors;

    while (mygetline(std::cin, input, ';')) {
        if (input.empty()) {
            continue;
        }

        std::vector<MyString> tokens = Tokenize(input);
        if (tokens.size() == 0) {
            continue;
        }

        Selector selector(tokens[0]);
        for (size_t i = 1; i < tokens.size(); i++) {
            std::vector<MyString> attribute_tokens = Tokenize(tokens[i], ':');
            if (attribute_tokens.size() == 2) {
                selector.AddAttribute(attribute_tokens[0], attribute_tokens[1]);
            }
        }
        selectors.push_back(selector);
    }

    std::sort(selectors.begin(), selectors.end());
    for (const Selector& selector : selectors) {
        std::cout << selector.selector << std::endl;
        for (const auto& attribute : selector.attributes) {
            std::cout << "  " << attribute.first << ": " << attribute.second << std::endl;
        }
    }
}

std::vector<MyString> CSSParser::Tokenize(const MyString& input, char delimiter) {
    std::vector<MyString> tokens;
    MyString token;
    for (size_t i = 0; i < input.size(); i++) {
        if (input[i] == delimiter) {
            tokens.push_back(token);
            token = "";
        }
        else {
            token += input[i];
        }
    }
    if (!token.empty()) {
        tokens.push_back(token);
    }
    return tokens;
}
