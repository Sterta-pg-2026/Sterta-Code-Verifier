#pragma once

#include <unordered_map>
#include "mystring.h"
#include "node.h"


class Selector {
public:
    MyString selector;
    std::vector<std::pair<MyString, MyString>> attributes;

    Selector(const MyString& s);


    void AddAttribute(const MyString& key, const MyString& value);

    bool operator<(const Selector& other) const;
};

class CSSParser {
public:
    void Parse();

private:
    std::vector<MyString> Tokenize(const MyString& input, char delimiter = ' ');

    std::vector<Selector> m_selectors;
};





