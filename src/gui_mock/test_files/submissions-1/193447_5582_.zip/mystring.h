#pragma once

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>


class MyString {
private:
    char* m_data;
    size_t m_size;

    friend std::istream& mygetline(std::istream& is, MyString& str, char delim);
public:
    MyString();
    MyString(const char* str);
    MyString(const MyString& other);
    ~MyString();

    MyString& operator=(const MyString& other);

     const char* c_str() const;
     size_t size() const;
    bool operator==(const MyString& other) const;
    MyString operator+(const MyString& other) const;
    MyString operator+=(const MyString& other);
    MyString operator+=(char c);
    friend std::ostream& operator<<(std::ostream& os, const MyString& str);
    friend std::istream& operator>>(std::istream& is, MyString& str);
    char& operator[](size_t index);
     bool empty() const;
     void clear();
    void push_back(char c);
    const char& operator[](size_t index) const;
    int CompareTo(const MyString& other) const;
};

