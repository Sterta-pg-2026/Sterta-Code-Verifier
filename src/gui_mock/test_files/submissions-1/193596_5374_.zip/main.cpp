import <iostream>;

int main(){
return 0;
}