#include <iostream>
#include "str.h"

#define NULL_CHAR 0

using namespace std;

int get_len(const char* x)
{
    int length = 0;
    int i = 0;
    while (x[i] != NULL_CHAR)
    {
        length++;
        i++;
    }
    return length;
}

Str::Str()
{
    length = 0;
    string = new char[1];
    string[0] = NULL_CHAR;
}

Str::~Str()
{
    delete[] this->string;
}


Str::Str(const char* x)
{
    this->string = nullptr;
    length = get_len(x);
    string = new char[length + 1];
    copy(x, x + length, string);
    string[length] = NULL_CHAR;
}

Str::Str(const Str& other)
{
    length = other.length;
    this->string = new char[length + 1];
    copy(other.string, other.string + length, this->string);
    this->string[length] = NULL_CHAR;
}
void Str::print(ostream& out) const
{
    out << string;
}

ostream& operator << (ostream& os, const Str& s)
{
    s.print(os);
    return os;
}

Str& Str::operator=(const char* other)
{
    if (string != nullptr)
    {
        delete[] string;
    }

    length = get_len(other);
    string = new char[length + 1];
    copy(other, other + length, string);
    string[length] = NULL_CHAR;
    return *this;
}

Str& Str::operator=(const Str& other)
{
    if (this != &other) {

        delete[] string;

        length = other.length;
        string = new char[length + 1];
        copy(other.string, other.string + length, string);
        string[length] = NULL_CHAR;
    }
    return *this;
}


bool Str::operator==(const Str& other) const
{
    if (this->length != other.length)
    {
        return false;
    }
    for (int i = 0;i < other.length; i++)
    {
        if (this->string[i] != other.string[i])
        {
            return false;
        }
    }
    return true;
}
bool Str::operator==(const char other[]) const
{
    if (this->length != get_len(other))
    {
        return false;
    }
    for (int i = 0;i < this->length; i++)
    {
        if (this->string[i] != other[i])
        {
            return false;
        }
    }
    return true;
}

char Str::operator[](int index) const
{
    if (index >= this->length)
    {
        return NULL;
    }
    return this->string[index];
}