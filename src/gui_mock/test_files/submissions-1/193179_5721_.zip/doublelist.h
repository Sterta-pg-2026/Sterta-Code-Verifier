#pragma once
#include "singlelist.h"

#define NODE_ARRAY_SIZE 8
//predifined number of slots for css blocks inside one node


struct DoubleListNode
{
    CssBlock sections[NODE_ARRAY_SIZE];
    int taken;
    DoubleListNode* prev;
    DoubleListNode* next;
};

class DoubleList
{
    DoubleListNode* head;
    DoubleListNode* tail;
public:
    DoubleList();

    ~DoubleList();

    CssBlock* search_for_free_block();
    //return address to free valid block

    CssBlock* search_for_block(int index);
    //return address of cs block based on its index

    DoubleListNode* search_for_node();

    int count_selector_app(Str selector_search) const;
    //return number of picked selector inside whole list

    int count_attribute_app(Str attribute_search) const;
    //return number of picked attribute inside whole list

    void add_next_node();
    //adds next node at the end of the list and sets it to tail

    bool rm_this_block(int index) const;
    //remove block and decrement taken variable in approperiate node

    static bool rm_attr_from_block(Str attribute_delete, AttributeList* attributes);
    //removes attribute from the list

    void rm_this_node(DoubleListNode* current) const;
    //removes whole node (removing head or tail is not possible - list has to have at least two nodes)

    Str last_attr_app_for_selector(Str selector_for_search, Str attribute_for_search) const;
    //returns value of last apperance of picked attribute

    unsigned int count_blocks() const;
    //counts all css blocks inside list
};