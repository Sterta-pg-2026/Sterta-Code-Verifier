#pragma once
#include <iostream>
using namespace std;

int get_len(const char* x);
//return length of char table

class Str
{
private:
    char* string;
    int length;

protected:
    void print(ostream& out) const;
    friend ostream& operator << (ostream& os, const Str& s);
public:

    Str();
    ~Str();

    Str(const char* x);
    Str(const Str& other);

    Str& operator=(const char* other);
    Str& operator=(const Str& other);

    bool operator==(const Str& other) const;
    bool operator==(const char other[]) const;

    char operator[](int index) const;
    //overided oparator[] makes it possible to access 
    //particular index of string variable inside str object
};
