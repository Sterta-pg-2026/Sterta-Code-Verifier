#include "doublelist.h"
#include <iostream>

using namespace std;


DoubleList::DoubleList()
{
    this->head = new DoubleListNode;
    this->tail = new DoubleListNode;

    this->head->taken = 0;
    this->tail->taken = 0;

    this->head->prev = nullptr;
    this->tail->prev = head;
    this->head->next = tail;
    this->tail->next = nullptr;
}

DoubleList::~DoubleList()
{
    DoubleListNode* current = head;
    DoubleListNode* next;
    while (current->next != nullptr)
    {
        next = current->next;
        delete current;
        current = next;
    }
}

void DoubleList::add_next_node()
{
    DoubleListNode* x = new DoubleListNode;

    x->next = nullptr;
    x->prev = nullptr;
    x->taken = 0;
    tail->next = x;
    x->prev = tail;
    tail = x;
}

CssBlock* DoubleList::search_for_free_block()
{
    DoubleListNode* current = tail;
    if (current->taken == NODE_ARRAY_SIZE)
    {
        add_next_node();
        current = current->next;
        return &current->sections[0];
    }
    else if (current->taken == 0)
    {
        return &current->sections[0];
    }
    else
    {
        if (current->sections[NODE_ARRAY_SIZE - 1].attributes.get_head()->next != nullptr)
        {
            add_next_node();
            current = current->next;
            return &current->sections[0];
        }
        else
        {
            for (int i = NODE_ARRAY_SIZE - 1;i >= 0;i--)
            {
                if (current->sections[i].attributes.get_head()->next != nullptr)
                {
                    return &current->sections[i + 1];
                }
            }
        }
    }
    return NULL;
}

DoubleListNode* DoubleList::search_for_node()
{
    return tail;
}

unsigned int DoubleList::count_blocks() const
{
    unsigned int num_of_blocks = 0;
    DoubleListNode* current = head->next;

    while (current != nullptr)
    {
        num_of_blocks += current->taken;
        current = current->next;
    }
    return num_of_blocks;
}

CssBlock* DoubleList::search_for_block(int index)
{
    DoubleListNode* current = head->next;
    while (index > current->taken)
    {
        if (current->next == nullptr) { return NULL; }
        index -= current->taken;
        current = current->next;
    }
    int count = 0;
    index--;


    for (int j = 0; j < NODE_ARRAY_SIZE;j++)
    {
        if (current->sections[j].attributes.get_head()->next != nullptr)
        {
            if (count == index)
            {
                return &(current->sections[j]);
            }
            count++;
        }
    }
    return NULL;
}

int DoubleList::count_selector_app(Str selector_search) const
{
    DoubleListNode* current = head->next;

    int meter = 0;

    while (current != nullptr)
    {
        int index = 0;
        while (index < NODE_ARRAY_SIZE)
        {
            meter += current->sections[index].selectors.search_for_selector_num(selector_search);
            index++;
        }
        current = current->next;
    }
    return meter;
}

int DoubleList::count_attribute_app(Str attribute_search) const
{
    DoubleListNode* current = head->next;

    int meter = 0;
    while (current != nullptr)
    {
        int index = 0;
        while (index < NODE_ARRAY_SIZE)
        {
            meter += current->sections[index].attributes.search_for_attribute_num(attribute_search);
            index++;
        }
        current = current->next;
    }
    return meter;
}

Str DoubleList::last_attr_app_for_selector(Str selector_for_search, Str attribute_for_search) const
{
    DoubleListNode* current = tail;
    while (current != head)
    {
        int index = NODE_ARRAY_SIZE-1;
        while (index >= 0)
        {
            if (current->sections[index].selectors.search_for_selector_num(selector_for_search))
            {
                AttributeList* current_attr = &current->sections[index].attributes;
                return current_attr->search_for_attribute(attribute_for_search);
            }
            index--;
        }
        current = current->prev;
    }
    return "";
}

bool DoubleList::rm_this_block(int index) const
{
    DoubleListNode* current = head->next;
    while (index > current->taken)
    {
        if (current->next == nullptr) { return 0; }
        index -= current->taken;
        current = current->next;
    }
    int count = 0;
    index--;

    int j = 0;
    for (j; j < NODE_ARRAY_SIZE;j++)
    {
        if (current->sections[j].attributes.get_head()->next != nullptr
            || current->sections[j].selectors.get_head()->next != nullptr)
        {
            if (count == index)
            {
                break;
            }
            count++;
        }
    }

    CssBlock* to_delete = &current->sections[j];

    if (to_delete == nullptr || (&to_delete->attributes == nullptr)) { return false; }

    if (current->taken > 0 && j < NODE_ARRAY_SIZE)
    {
        to_delete->attributes.clear_list();
        to_delete->selectors.clear_list();
        current->taken--;
    }

    if (current->taken == 0)
    {
        rm_this_node(current);
    }
    return 1;
}

void DoubleList::rm_this_node(DoubleListNode* current) const
{
    if (current == tail) { return; }
    if (current == nullptr) { return; }

    if (current->next != nullptr)
    {
        current->next->prev = current->prev;
    }
    if (current->prev != nullptr)
    {
        current->prev->next = current->next;
    }

    delete current;
}

bool DoubleList::rm_attr_from_block(Str attribute_delete, AttributeList* attributes)
{
    if (attributes->get_head() == nullptr) { return 0; }
    AttributeNode* current = attributes->get_head();
    while (current->next != nullptr)
    {
        if (current->next->name == attribute_delete)
        {
            AttributeNode* x = current->next;
            current->next = current->next->next;
            x->name.~Str();
            x->value.~Str();
            x->next = nullptr;
            return 1;
        }
        current = current->next;
    }
    return 0;
}