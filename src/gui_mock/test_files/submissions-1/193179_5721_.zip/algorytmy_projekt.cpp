#include <iostream>
#include <cstdlib>

#include "singlelist.h"
#include "doublelist.h"
#include "str.h"

#define BUFFER_SIZE 200

#define _0_CHAR 48
#define _9_CHAR 57
#define _QUESTION_CHAR 63

#define COMMA_ASCII 44
#define OPEN_BRACKET 123
#define CLOSE_BRACKET 125
#define NULL_CHAR 0
#define SPACE_CHAR 32
#define TAB_CHAR 9
#define COLON_CHAR 58
#define SEMICOLON_CHAR 59

#define VER_TAB_CHAR 11
#define FORM_FEED_CHAR 12
#define CARRIAGE_RETURN_CHAR 13


const Str start_of_commands = "????";   //str responsible for ending css input section/ starting command section
const Str end_of_commands = "****";     //str responsible for ending commmand section/ starting css input section
const Str num_of_blocks = "?";

const Str selectors_comm = "S";
const Str attribute_comm = "A";
const Str delete_comm = "D";
const Str last_app_comm = "E";
//above const Strs represent different types of possible commands

const Str empty_str = "";
const Str star_str = "*";

using namespace std;

void read_css(char buffer[], char small_buffer[], DoubleList* container);
//most general function responsible for proccessing css input

int input_selectors(char buffer[], char small_buffer[], SelectorList* selectors);
void input_attributes(char buffer[], char small_buffer[], AttributeList* attributes, int i);
//above functions communitate by passing current index to enable situation
//in which selectors and atttributes are not in the separate lines

void read_commands(char buffer[], char small_buffer[], DoubleList* container);
//puts commands into table of 3 Str and then calls approperiate functions to execute the command

Str* parse_command(char buffer[], char small_buffer[], Str command[]);
//responsible for parsing input in command sections and putting it into table so taht it can be proccessed further

void handle_selector_comm(Str command[], DoubleList* container);
void handle_attribute_comm(Str command[], DoubleList* container);
void handle_delete_comm(Str command[], DoubleList* container);
void handle_last_app_comm(Str command[], DoubleList* container);
//4 above functions handles different types of commands depending on uuser input

void clear_buffer(char buffer[]);
//sets first char in the buffer to NULL_CHAR to prevent reading some unpredictable data

int str_to_int(Str string);
//converts number stored in Str object to int

void rm_spaces_before(int* i, char buffer[]);
void rm_spaces_after(int* k, char small_buffer[]);
//functions used to parse commands, attributes and selectors from user input 
//(they omit spaces and other unexpected characters)


int main()
{
    DoubleList container;

    char buffer[BUFFER_SIZE];
    char small_buffer[BUFFER_SIZE / 2];
    //used while reading input to prevent extra coping of str

    while (true)        //infinite loop is used to enable user to enter as much input as he wants 
    {                    //(program is terminated when there is no more input to read)     

        read_css(buffer, small_buffer, &container);
        clear_buffer(buffer);

        read_commands(buffer, small_buffer, &container);
        clear_buffer(buffer);
    }
    return 0;
}

void read_commands(char buffer[], char small_buffer[], DoubleList* container)
{
    while (!(end_of_commands == buffer))
    {
        cin.getline(buffer, BUFFER_SIZE);

        if (!cin) { exit(0); }
        if (end_of_commands == buffer) { return; }

        if (num_of_blocks == buffer)
        {
            cout << num_of_blocks << " == " << container->count_blocks() << endl;
        }
        else
        {
            Str command[3];
            parse_command(buffer, small_buffer, command);

            //based on str stored in command table picks proper command type and relevant calls function
            if (command[1] == selectors_comm)
            {
                handle_selector_comm(command, container);
            }
            else if (command[1] == attribute_comm)
            {
                handle_attribute_comm(command, container);
            }
            else if (command[1] == delete_comm)
            {
                handle_delete_comm(command, container);
            }
            else if (command[1] == last_app_comm)
            {
                handle_last_app_comm(command, container);
            }
        }
        clear_buffer(buffer);
    }

}

void handle_selector_comm(Str command[], DoubleList* container)
{
    if (command[0][0] >= _0_CHAR && command[0][0] <= _9_CHAR)
    {
        CssBlock* current = container->search_for_block(str_to_int(command[0]));
        if (current == NULL) { return; }
        //depending on user input picks right block and assign it to current variable

        if ((command[2][0] >= _0_CHAR) && (command[2][0] <= _9_CHAR))
        {
            Str selector = current->selectors.get_selector(str_to_int(command[2]));
            if (selector == empty_str) { return; }

            cout << command[0] << "," << command[1] << "," << command[2]
                << " == " << selector << endl;
        }
        else if (command[2][0] == _QUESTION_CHAR)
        {
            int num_of_selectors = current->selectors.count_selectors();

            cout << command[0] << "," << selectors_comm << ","
                << char(_QUESTION_CHAR) << " == " << num_of_selectors << endl;
        }
    }
    else
    {
        cout << command[0] << "," << command[1] << ","
            << command[2] << " == " << container->count_selector_app(command[0]) << endl;
    }
}

void handle_attribute_comm(Str command[], DoubleList* container)
{
    if (command[0][0] >= _0_CHAR && command[0][0] <= _9_CHAR)
    {
        CssBlock* current = container->search_for_block(str_to_int(command[0]));
        if (current == NULL) { return; }
        //depending on user input picks right block and assign it to current variable

        if (command[2][0] == _QUESTION_CHAR)
        {
            cout << command[0] << "," << command[1] << ","
                << command[2] << " == " << current->attributes.count_attributes() << endl;
        }
        else
        {
            Str attr_value = current->attributes.search_for_attribute(command[2]);
            if (!(attr_value == empty_str))
            {
                cout << command[0] << "," << command[1] << ","
                    << command[2] << " == " << current->attributes.search_for_attribute(command[2]) << endl;
            }
        }
    }
    else
    {
        cout << command[0] << "," << command[1]
            << "," << command[2] << " == " << container->count_attribute_app(command[0]) << endl;
    }
}

void handle_last_app_comm(Str command[], DoubleList* container)
{
    Str last_app = container->last_attr_app_for_selector(command[0], command[2]);
    if (!(last_app == empty_str))
    {
        cout << command[0] << "," << command[1] << ","
            << command[2] << " == " << last_app << endl;
    }
}

void handle_delete_comm(Str command[], DoubleList* container)
{
    if (command[2] == star_str)
    {
        if (container->rm_this_block(str_to_int(command[0])))
        {
            cout << command[0] << "," << command[1] << "," << command[2];
            cout << " == deleted";
        }
        cout << endl;
    }
    else
    {
        CssBlock* current = container->search_for_block(str_to_int(command[0]));
        if (current == nullptr) { return; }

        if (container->rm_attr_from_block(command[2], &current->attributes))
        {
            cout << command[0] << "," << command[1] << "," << command[2];
            cout << " == deleted" << endl;
        }
        if (current->attributes.get_head()->next == nullptr)
        {
            container->rm_this_block(str_to_int(command[0]));
        }
    }
}

Str* parse_command(char buffer[], char small_buffer[], Str command[])
{
    int i = 0;
    for (int j = 0; j < 3;j++)
    {
        rm_spaces_before(&i, buffer);
        int k = 0;
        while (buffer[i] != COMMA_ASCII && buffer[i] != NULL_CHAR)
        {
            small_buffer[k] = buffer[i];
            i++;
            k++;
        }

        rm_spaces_after(&k, small_buffer);
        small_buffer[k] = NULL_CHAR;

        if (k != 0)
        {
            command[j] = small_buffer;
        }
        if (buffer[i] != NULL_CHAR) { i++; }
    }
    return command;
}
void read_css(char buffer[], char small_buffer[], DoubleList* container)
{
    while (!(start_of_commands == buffer))
    {
        CssBlock* block = container->search_for_free_block();
        int cursor = 0;

        cursor = input_selectors(buffer, small_buffer, &block->selectors);
        input_attributes(buffer, small_buffer, &block->attributes, cursor);

        //cursor variable indicate where input_selectors 
        //stopped while reading input and gives that information to input_attributes

        if (block->attributes.get_head()->next != nullptr) { container->search_for_node()->taken++; }

        while (buffer[0] == NULL_CHAR)
        {
            cin.getline(buffer, BUFFER_SIZE);
            if (!cin) { exit(0); }
        }
    }
}

int input_selectors(char buffer[], char small_buffer[], SelectorList* selectors)
{
    while (true)
    {
        cin.getline(buffer, BUFFER_SIZE);
        if (!cin) { exit(0); }

        if (start_of_commands == buffer) { return 0; }

        int i = 0;
        while ((buffer[i] != NULL_CHAR) && i < BUFFER_SIZE) {

            rm_spaces_before(&i, buffer);

            int k = 0;

            while (buffer[i] != COMMA_ASCII && buffer[i] != OPEN_BRACKET && buffer[i] != NULL_CHAR)
            {
                small_buffer[k] = buffer[i];
                k++;
                i++;
            }
            small_buffer[k] = NULL_CHAR;

            rm_spaces_after(&k, small_buffer);

            if (k != 0)
            {
                (*selectors).insert_end(small_buffer);
            }

            if (buffer[i] == OPEN_BRACKET)
            {
                i++;
                rm_spaces_before(&i, buffer);
                return i;
            }
            if (buffer[i] != NULL_CHAR) { i++; }
            rm_spaces_before(&i, buffer);
        }
    }
}

void input_attributes(char buffer[], char small_buffer[], AttributeList* attributes, int i)
{
    int j = 0;
    while ((buffer[i] != CLOSE_BRACKET) && (buffer[i - 1] != CLOSE_BRACKET))
    {
        if (start_of_commands == buffer) { return; }
        if (j == 0) { j++; }
        else
        {
            cin.getline(buffer, BUFFER_SIZE);
            if (!cin) { exit(0); }
            i = 0;
        }

        while (buffer[i] != NULL_CHAR && buffer[i] != CLOSE_BRACKET)
        {

            rm_spaces_before(&i, buffer);

            int k = 0;
            while (buffer[i] != COLON_CHAR && buffer[i] != NULL_CHAR)
            {
                if (buffer[i] == CLOSE_BRACKET)
                {
                    i++;
                    return;
                }
                small_buffer[k] = buffer[i];
                k++;
                i++;
            }
            i++;
            small_buffer[k] = NULL_CHAR;

            rm_spaces_after(&k, small_buffer);

            if (k != 0)
            {
                Str tmp = small_buffer;
                attributes->rm_node_by_name(tmp);
                (*attributes).insert_name_end(small_buffer);
            }
            //above if statemant is responsible for removing repetitions of the same 
            //attribute inside one css block 


            rm_spaces_before(&i, buffer);

            k = 0;
            while (buffer[i] != SEMICOLON_CHAR && buffer[i] != CLOSE_BRACKET && buffer[i] != NULL_CHAR)
            {
                small_buffer[k] = buffer[i];
                k++;
                i++;
            }
            small_buffer[k] = NULL_CHAR;

            rm_spaces_after(&k, small_buffer);

            if (k != 0)
            {
                (*attributes).insert_value_end(small_buffer);
            }
            i++;
            rm_spaces_before(&i, buffer);
        }
    }
}

void rm_spaces_before(int* i, char buffer[])
{
    while ((buffer[(*i)] == SPACE_CHAR) || (buffer[(*i)] == TAB_CHAR)
        || (buffer[(*i)] == FORM_FEED_CHAR) || (buffer[(*i)] == VER_TAB_CHAR)
        || (buffer[(*i)] == CARRIAGE_RETURN_CHAR))
    {
        (*i)++;
    }
}

void rm_spaces_after(int* k, char small_buffer[])
{
    while ((small_buffer[(*k - 1)] == SPACE_CHAR) || (small_buffer[(*k - 1)] == TAB_CHAR)
        || (small_buffer[(*k - 1)] == FORM_FEED_CHAR) || (small_buffer[(*k - 1)] == VER_TAB_CHAR)
        || (small_buffer[(*k - 1)] == CARRIAGE_RETURN_CHAR))
    {
        small_buffer[(*k) - 1] = NULL_CHAR;
        (*k)--;
    }
}

void clear_buffer(char buffer[])
{
    buffer[0] = NULL_CHAR;
}

int str_to_int(Str string)
{
    int value = 0;
    int i = 0;
    while (string[i] != NULL_CHAR)
    {
        value *= 10;
        value += (string[i] - _0_CHAR);
        i++;
    }
    return value;
}