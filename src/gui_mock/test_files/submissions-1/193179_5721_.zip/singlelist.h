#pragma once
#include <iostream>
#include "str.h"

using namespace std;

struct SelectorNode
{
    Str data;
    SelectorNode* next;
};

struct AttributeNode
{
    Str name;
    Str value;
    AttributeNode* next;
};

class SelectorList
{
private:
    SelectorNode* head;
public:

    SelectorList();
    ~SelectorList();

    int count_selectors() const;
    //count all selectors within the list

    Str get_selector(int index) const;
    //return selector name based on index

    bool search_for_selector_num(Str selector_search) const;
    //indicades whether selector is in side list

    void clear_list();
    //remove all data from list and sets head -> next = nullptr

    void insert_end(Str data) const;

    SelectorNode* get_head();
};

class AttributeList
{
private:
    AttributeNode* head;
public:

    AttributeList();
    ~AttributeList();

    void insert_name_end(Str name) const;
    void insert_value_end(Str value) const;

    bool rm_node_by_name(Str name) const;
    //used while checking for previous occuring of particular attribute

    int count_attributes() const;
    //returns number of attributes in the list

    Str search_for_attribute(Str name_search) const;
    //returns value of attribute of name name_search

    bool search_for_attribute_num(Str attribute_search) const;
    //indicades whether atribute is in side list

    void clear_list();
    //remove all data from list and sets head -> next = nullptr

    AttributeNode* get_head();
};

struct CssBlock
{
    AttributeList attributes;
    SelectorList selectors;
};
//structure representing one block of css (selectors with attrbiutes names and values)