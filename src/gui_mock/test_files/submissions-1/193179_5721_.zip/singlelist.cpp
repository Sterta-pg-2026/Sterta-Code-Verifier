#include "singlelist.h"
#include <iostream>

using namespace std;

const Str head_default_value = "head";
const Str empty_str = "";

//Selector List

SelectorList::SelectorList()
{
    head = new SelectorNode;
    head->next = nullptr;
    head->data = head_default_value;

}

SelectorList::~SelectorList()
{
    SelectorNode* current = head;
    SelectorNode* next;
    while (current->next != nullptr)
    {
        next = current->next;
        delete current;
        current = next;
    }
}

void SelectorList::insert_end(Str data) const
{
    SelectorNode* current = head;
    SelectorNode* x = new SelectorNode;
    x->data = data;
    while (current->next != nullptr)
    {
        current = current->next;
    }
    current->next = x;
    x->next = nullptr;
}

SelectorNode* SelectorList::get_head()
{
    return head;
}

int SelectorList::count_selectors() const
{
    int meter = 0;
    SelectorNode* current = head->next;
    while (current != nullptr)
    {
        meter++;
        current = current->next;
    }
    return meter;
}

Str SelectorList::get_selector(int index) const
{
    int i = 1;
    if (head->next == nullptr) { return empty_str; }
    SelectorNode* current = head->next;
    while (i < index)
    {
        if (current->next == nullptr) { return empty_str; }
        current = current->next;
        i++;
    }
    return current->data;
}


bool SelectorList::search_for_selector_num(Str selector_search) const
{
    SelectorNode* current = head->next;
    while (current != nullptr)
    {
        if (current->data == selector_search) { return 1; }
        current = current->next;
    }
    return 0;
}

void SelectorList::clear_list()
{
    if (head == nullptr) { return; }
    SelectorNode* current = head->next;
    while (current != nullptr)
    {
        SelectorNode* tmp = current->next;
        delete current;
        current = tmp;
    }
    head->next = nullptr;
}

//AttributeList

AttributeList::AttributeList()
{
    head = new AttributeNode;
    head->next = nullptr;
    head->name = head_default_value;
    head->value = head_default_value;
}

AttributeList::~AttributeList()
{
    AttributeNode* current = head;
    AttributeNode* next;
    while (current->next != nullptr)
    {
        next = current->next;
        delete current;
        current = next;
    }
}

void AttributeList::insert_name_end(Str name) const
{
    AttributeNode* current = head;
    AttributeNode* x = new AttributeNode;
    x->name = name;
    while (current->next != nullptr)
    {
        current = current->next;
    }
    current->next = x;
    x->next = nullptr;
}

void AttributeList::insert_value_end(Str value) const
{
    AttributeNode* current = head;

    while (current->next != nullptr)
    {
        current = current->next;
    }

    current->value = value;
}

AttributeNode* AttributeList::get_head()
{
    return head;
}

int AttributeList::count_attributes() const
{
    int meter = 0;
    AttributeNode* current = head->next;
    while (current != nullptr)
    {
        meter++;
        current = current->next;
    }
    return meter;
}

Str AttributeList::search_for_attribute(Str name_search) const
{
    if (head->next == nullptr) { return empty_str; }
    AttributeNode* current = head->next;
    while (current != nullptr)
    {
        if (current->name == name_search)
        {
            return current->value;
        }
        current = current->next;
    }
    return empty_str;
}

bool AttributeList::search_for_attribute_num(Str attribute_search) const
{
    AttributeNode* current = head->next;
    while (current != nullptr)
    {
        if (current->name == attribute_search) { return 1; }
        current = current->next;
    }
    return 0;
}

bool AttributeList::rm_node_by_name(Str name) const
{
    if (this->head->next == nullptr) { return 0; }
    AttributeNode* current = head;
    while (current->next != nullptr)
    {
        if (current->next->name == name)
        {
            AttributeNode* tmp = current->next;
            current->next = current->next->next;

            delete tmp;
            return 1;
        }
        current = current->next;
    }
    return 0;
}

void AttributeList::clear_list()
{
    if (head == nullptr) { return; }
    AttributeNode* current = head->next;
    while (current != nullptr)
    {
        AttributeNode* tmp = current->next;

        delete current;
        current = tmp;
    }
    head->next = nullptr;
}