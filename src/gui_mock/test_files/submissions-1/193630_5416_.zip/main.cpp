#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
using namespace std;

#define DEFAULT_TMP_SIZE 25
#define CHAR_TO_INT 48
#define T 8
#define PRINT 1
#define DO_NOT_PRINT 0
#define WHITE_SPACE_CHARACTERS 32
#define GET_IN_COMMANDS_LOOP 4
#define DEFAULT_MARKER_SIZE 3
#define DEFAULT_SELECTOR_NUMBER_SIZE 3
#define AVOID_WHITESPACE_CHAR 0
#define START_INSERTING 1
#define REPEAT_OF_ATTRIBUTE 1
#define NORMAL_STATE 0
#define CHECK_IF_TO_INSERT_ATTRIBUTE_WITHOUTH_SEMICOLON 1

struct Attributes {
	Attributes* previous;
	Attributes* next;
	char* attributesArray;
	char* propertiesArray;
};

struct Selectors {
	Selectors* previous;
	Selectors* next;
	char* selectorsArray;
};

struct Section {
	Selectors* selectors;
	Selectors* selectorsHead;
	Selectors* selectorsTail;

	Attributes* attributes;
	Attributes* attributesHead;
	Attributes* attributesTail;
};

struct Block {
	Section sectionBlock[T];
	int sectionCounter;
	Block* previous;
	Block* next;
};

void cleanAndPrepareTheTMP(char*& TMP, int& length, char* buffer, int end, int begginning) {
	int j = 0, z = 0;
	length = 0;
	delete[] TMP;
	TMP = new char[end - begginning + 5];
	memset(TMP, NULL, end - begginning);
	while (buffer[begginning + j] <= WHITE_SPACE_CHARACTERS) {
		j++;
	}
	while (buffer[end - z - 1] <= WHITE_SPACE_CHARACTERS) {
		z++;
	}
	for (int i = 0; begginning + i + j < end - z; i++) {
		if ((buffer[begginning + i + j] != '\n') && (buffer[begginning + i + j] != '\t')) {
			TMP[length] = buffer[begginning + i + j];
			length++;
		}
	}
	TMP[length] = '\0';
}

void reallocTmp(char*& tmp, int& n) {

	char* TMP = new char[n];
	memset(TMP, NULL, n);
	strcpy(TMP, tmp);

	n += DEFAULT_TMP_SIZE;
	delete[] tmp;
	tmp = new char[n];

	memset(tmp, NULL, n);
	strcpy(tmp, TMP);

	delete[] TMP;
}

void checkForNewLineSign(char* buffer, int& end, int& begginning) {
	while (buffer[end] == '\n') {
		begginning = end + 1;
		end = begginning;
	}
}

void setPositionOfEndAndBeginning(int& end, int& begginning) {
	begginning = end + 1;
	end = begginning;
}

void initializeAttributes(Block** block) {
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes = new Attributes;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->previous = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->next = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->attributesArray = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->propertiesArray = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesHead = (*block)->sectionBlock[(*block)->sectionCounter - 1].attributes;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail = (*block)->sectionBlock[(*block)->sectionCounter - 1].attributes;
}

void initializeSelectors(Block** block) {
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors = new Selectors;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->previous = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->next = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->selectorsArray = nullptr;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsHead = (*block)->sectionBlock[(*block)->sectionCounter - 1].selectors;
	(*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsTail = (*block)->sectionBlock[(*block)->sectionCounter - 1].selectors;
}

void initializeBlock(Block** block, Block** head, Block** tail) {
	*block = new Block;
	(*block)->sectionCounter = 1;
	(*block)->previous = nullptr;
	(*block)->next = nullptr;
	*tail = *block;
	*head = *block;

	initializeSelectors(block);
	initializeAttributes(block);
}

void insertBlock(Block** tail) {
	Block* newNode = new Block;
	newNode->previous = *tail;
	newNode->next = nullptr;
	newNode->sectionCounter = 1;
	(*tail)->next = newNode;
	*tail = newNode;

	initializeSelectors(&newNode);
	initializeAttributes(&newNode);
}

void insertSelector(Block** block, char* selector, int length) {
	while ((*block)->next != nullptr) {
		(*block) = (*block)->next;
	}
	if ((*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsTail->selectorsArray != nullptr) {
		Selectors* newNode = new Selectors;
		newNode->selectorsArray = new char[length];
		for (int i = 0; i < length; i++) {
			newNode->selectorsArray[i] = selector[i];
		}
		newNode->selectorsArray[length] = '\0';

		newNode->previous = (*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsTail;
		newNode->next = nullptr;
		(*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsTail->next = newNode;
		(*block)->sectionBlock[(*block)->sectionCounter - 1].selectorsTail = newNode;

	}
	else {
		(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->selectorsArray = new char[length];
		for (int i = 0; i < length; i++) {
			(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->selectorsArray[i] = selector[i];
		}
		(*block)->sectionBlock[(*block)->sectionCounter - 1].selectors->selectorsArray[length] = '\0';
	}
}

bool checkIfAttributeAlreadyInserted(Block block, char* attribute) {
	Block traverser = block;
	while ((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next != nullptr) {
		if (strcmp((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->attributesArray, attribute) == 0) {
			return false;
		}
		if ((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next != nullptr) {
			(&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead = (&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next;
		}
		if (strcmp((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->attributesArray, attribute) == 0) {
			return false;
		}
	}
	return true;
}

bool insertAttribute(Block** block, char* attribute, int length) {
	while ((*block)->next != nullptr) {
		(*block) = (*block)->next;
	}
	if (checkIfAttributeAlreadyInserted(**block, attribute) == true) {
		if ((*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail->attributesArray != nullptr) {
			Attributes* newNode = new Attributes;
			newNode->attributesArray = new char[length];
			for (int i = 0; i < length; i++) {
				newNode->attributesArray[i] = attribute[i];
			}
			newNode->attributesArray[length] = '\0';
			newNode->previous = (*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail;
			newNode->next = nullptr;
			(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail->next = newNode;
			(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail = newNode;
			return true;
		}
		else {
			(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->attributesArray = new char[length];
			for (int i = 0; i < length; i++) {
				(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->attributesArray[i] = attribute[i];
			}
			(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->attributesArray[length] = '\0';
			return true;
		}
	}
	return false;
}

void insertPropertie(Block** block, char* propertie, int length) {
	while ((*block)->next != nullptr) {
		(*block) = (*block)->next;
	}
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail->propertiesArray = new char[length];
	for (int i = 0; i < length; i++) {
		(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail->propertiesArray[i] = propertie[i];
	}
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributesTail->propertiesArray[length] = '\0';
}

Attributes* returnPositionOfAttribute(Block block, char* attribute) {
	Block traverser = block;
	while ((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next != nullptr) {
		if (strcmp((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->attributesArray, attribute) == 0) {
			return (&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead;
		}
		if ((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next != nullptr) {
			(&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead = (&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->next;
		}
		if (strcmp((&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead->attributesArray, attribute) == 0) {
			return (&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead;
		}
	}
	return (&traverser)->sectionBlock[(&traverser)->sectionCounter - 1].attributesHead;
}

void overwritePropertie(Block** block, char* propertie, char* attribute, int length) {
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes = returnPositionOfAttribute(**block, attribute);
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->propertiesArray = new char[length];
	for (int i = 0; i < length; i++) {
		(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->propertiesArray[i] = propertie[i];
	}
	(*block)->sectionBlock[(*block)->sectionCounter - 1].attributes->propertiesArray[length] = '\0';
}

void countSections(Block head) {
	Block traverser = head;
	int sectionsNumber = 0;
	while ((&traverser) != nullptr) {
		sectionsNumber += (&traverser)->sectionCounter;
		if ((&traverser)->next == nullptr) {
			break;
		}
		traverser = *(traverser.next);
	}
	std::cout << "? == " << sectionsNumber << endl;
}

void countAttributes(Block head, int sectionNumber) {
	Block traverser = head;
	int i = 1;
	int sectionNumberToPrint = sectionNumber;

	while (((&traverser)->next != nullptr) && ((i * T) < sectionNumber)) {
		traverser = *(traverser.next);
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	if ((sectionNumber <= (&traverser)->sectionCounter) && (sectionNumber > 0)) {
		if ((&traverser)->sectionBlock[sectionNumber - 1].attributesHead == (&traverser)->sectionBlock[sectionNumber - 1].attributesTail) {
			i = 1;
		}
		else {
			while ((&traverser)->sectionBlock[sectionNumber - 1].attributesHead->next != nullptr) {
				if (i == 0) {
					i = 1;
				}
				(&traverser)->sectionBlock[sectionNumber - 1].attributesHead = (&traverser)->sectionBlock[sectionNumber - 1].attributesHead->next;
				i++;
			}
		}
		cout << sectionNumberToPrint << ",A,? == " << i << endl;
	}
}

void countSelectors(Block head, int sectionNumber) {
	Block traverser = head;
	int i = 1;
	int sectionNumberToPrint = sectionNumber;

	while (((&traverser)->next != nullptr) && ((i * T) < sectionNumber)) {
		traverser = *(traverser.next);
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	if ((sectionNumber <= (&traverser)->sectionCounter) && (sectionNumber > 0) && ((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->selectorsArray[0] != '\0')) {
		if ((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->selectorsArray != nullptr) {
			i = 1;
		}

		while ((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->next != nullptr) {
			(&traverser)->sectionBlock[sectionNumber - 1].selectorsHead = (&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->next;
			i++;
		}
		cout << sectionNumberToPrint << ",S,? == " << i << endl;
	}
	else if ((sectionNumber <= (&traverser)->sectionCounter) && (sectionNumber > 0)) {
		cout << sectionNumberToPrint << ",S,? == 0" << endl;
	}
}

void findSelector(Block head, int sectionNumber, int selectorNumber) {
	Block traverser = head;
	int i = 1;
	int sectionNumberToPrint = sectionNumber;

	while (((&traverser)->next != nullptr) && ((i * T) < sectionNumber)) {
		traverser = *(traverser.next);
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	if ((sectionNumber <= (&traverser)->sectionCounter) && (sectionNumber > 0)) {
		if ((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->selectorsArray != nullptr) {
			i = 1;
		}
		while (((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->next != nullptr) && (i < selectorNumber)) {
			(&traverser)->sectionBlock[sectionNumber - 1].selectorsHead = (&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->next;
			i++;
		}
	}
	if ((i == selectorNumber) && ((&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->selectorsArray[0] != '\0')) {
		std::cout << sectionNumberToPrint << ",S," << selectorNumber << " == " << (&traverser)->sectionBlock[sectionNumber - 1].selectorsHead->selectorsArray << endl;
	}
}

void findPropertie(Block head, int sectionNumber, char* attribute) {
	Block traverser = head;
	int sectionNumberToPrint = sectionNumber;
	int i = 1;
	while (((&traverser)->next != nullptr) && ((i * T) < sectionNumber)) {
		traverser = *(traverser.next);
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	if ((sectionNumber <= (&traverser)->sectionCounter) && (sectionNumber > 0)) {
		while ((&traverser)->sectionBlock[sectionNumber - 1].attributesTail->previous != nullptr) {
			if (strcmp((&traverser)->sectionBlock[sectionNumber - 1].attributesTail->attributesArray, attribute) == 0) {
				std::cout << sectionNumberToPrint << ",A," << attribute << " == " << (&traverser)->sectionBlock[sectionNumber - 1].attributesTail->propertiesArray << endl;
				i++;
				break;
			}
			(&traverser)->sectionBlock[sectionNumber - 1].attributesTail = (&traverser)->sectionBlock[sectionNumber - 1].attributesTail->previous;
		}
		if ((strcmp((&traverser)->sectionBlock[sectionNumber - 1].attributesTail->attributesArray, attribute) == 0) && (i == 0)) {
			std::cout << sectionNumberToPrint << ",A," << attribute << " == " << (&traverser)->sectionBlock[sectionNumber - 1].attributesTail->propertiesArray << endl;
		}
	}
}

void countAttributeInstances(Block head, char* attribute) {
	Block traverser = head;
	int counter = 0, controler = 0;
	do {
		for (int i = 0; i < (&traverser)->sectionCounter; i++) {
			while ((&traverser)->sectionBlock[i].attributesHead->next != nullptr) {
				if (strcmp((&traverser)->sectionBlock[i].attributesHead->attributesArray, attribute) == 0) {
					counter++;
					controler++;
				}
				if (controler == 1) {
					break;
				}
				(&traverser)->sectionBlock[i].attributesHead = (&traverser)->sectionBlock[i].attributesHead->next;
			}
			if (controler == 1) {
				controler = 0;
				continue;
			}
			if (strcmp((&traverser)->sectionBlock[i].attributesHead->attributesArray, attribute) == 0) {
				counter++;
			}
		}
		if ((&traverser)->next == nullptr) {
			break;
		}
		traverser = *(traverser.next);

	} while (&traverser != nullptr);

	std::cout << attribute << ",A,? == " << counter << endl;
}

void countSelectorInstances(Block head, char* selector) {
	Block traverser = head;
	int counter = 0, controler = 0;
	do {
		for (int i = 0; i < (&traverser)->sectionCounter; i++) {
			if ((&traverser)->sectionBlock[i].selectorsHead != nullptr) {
				while ((&traverser)->sectionBlock[i].selectorsHead->next != nullptr) {
					if (strcmp((&traverser)->sectionBlock[i].selectorsHead->selectorsArray, selector) == 0) {
						counter++;
						controler = 1;
						break;
					}
					(&traverser)->sectionBlock[i].selectorsHead = (&traverser)->sectionBlock[i].selectorsHead->next;
				}
				if ((strcmp((&traverser)->sectionBlock[i].selectorsHead->selectorsArray, selector) == 0) && (controler == 0)) {
					counter++;
				}
				else {
					controler = 0;
				}
			}
			else {
				break;
			}
		}
		if ((&traverser)->next == nullptr) {
			break;
		}
		traverser = *(traverser.next);
	} while ((&traverser) != nullptr);


	std::cout << selector << ",S,? == " << counter << endl;
}

bool checkIfPropertieWasFound(Block traverser, int counter, char* attribute, char* selector) {
	if (strcmp((&traverser)->sectionBlock[counter - 1].attributesTail->attributesArray, attribute) == 0) {
		std::cout << selector << ",E," << attribute << " == " << (&traverser)->sectionBlock[counter - 1].attributesTail->propertiesArray << endl;
		return true;
	}
	return false;
}

void findSelectorsPropertie(Block tail, char* selector, char* attribute) {
	Block traverser = tail;
	int counter = (&traverser)->sectionCounter, controler = 0;
	do {
		for (counter; counter > 0; counter--) {
			while ((&traverser)->sectionBlock[counter - 1].selectorsTail->previous != nullptr) {
				if (strcmp((&traverser)->sectionBlock[counter - 1].selectorsTail->selectorsArray, selector) == 0) {
					while ((&traverser)->sectionBlock[counter - 1].attributesTail->previous != nullptr) {
						if (checkIfPropertieWasFound(traverser, counter, attribute, selector) == true) {
							return;
						}
						(&traverser)->sectionBlock[counter - 1].attributesTail = (&traverser)->sectionBlock[counter - 1].attributesTail->previous;
					}
					if (checkIfPropertieWasFound(traverser, counter, attribute, selector) == true) {
						return;
					}
				}
				else {
					(&traverser)->sectionBlock[counter - 1].selectorsTail = (&traverser)->sectionBlock[counter - 1].selectorsTail->previous;
				}
			}
			if (strcmp((&traverser)->sectionBlock[counter - 1].selectorsTail->selectorsArray, selector) == 0) {
				while ((&traverser)->sectionBlock[counter - 1].attributesTail->previous != nullptr) {
					if (checkIfPropertieWasFound(traverser, counter, attribute, selector) == true) {
						return;
					}
					(&traverser)->sectionBlock[counter - 1].attributesTail = (&traverser)->sectionBlock[counter - 1].attributesTail->previous;
				}
				if (checkIfPropertieWasFound(traverser, counter, attribute, selector) == true) {
					return;
				}
			}
		}
		if ((&traverser)->previous != nullptr) {
			traverser = *(traverser.previous);
			counter = (&traverser)->sectionCounter;
		}
		else {
			break;
		}
	} while (true);
}

void deleteSection(Block** block, int sectionNumber) {
	if ((*block)->sectionBlock[sectionNumber - 1].attributesHead != (*block)->sectionBlock[sectionNumber - 1].attributesTail) {
		delete (*block)->sectionBlock[sectionNumber - 1].attributesTail;
	}
	if ((*block)->sectionBlock[sectionNumber - 1].selectorsHead != (*block)->sectionBlock[sectionNumber - 1].selectorsTail) {
		delete (*block)->sectionBlock[sectionNumber - 1].selectorsTail;
	}
	delete (*block)->sectionBlock[sectionNumber - 1].selectorsHead;
	delete (*block)->sectionBlock[sectionNumber - 1].attributesHead;
}

void nullSection(Block** block, int sectionNumber) {
	(*block)->sectionBlock[sectionNumber - 1].selectors = nullptr;
	(*block)->sectionBlock[sectionNumber - 1].selectorsHead = nullptr;
	(*block)->sectionBlock[sectionNumber - 1].selectorsTail = nullptr;
	(*block)->sectionBlock[sectionNumber - 1].attributes = nullptr;
	(*block)->sectionBlock[sectionNumber - 1].attributesHead = nullptr;
	(*block)->sectionBlock[sectionNumber - 1].attributesTail = nullptr;
}

void deleteSection(Block** block, Block** head, Block** tail, int sectionNumber, int printControler) {
	int i = 1;
	int sectionNumberToPrint = sectionNumber;
	*block = *head;
	while (((*block)->next != nullptr) && ((i * T) < sectionNumber)) {
		*block = (*block)->next;
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	if (sectionNumber <= (*block)->sectionCounter) {
		Section tmp = (*block)->sectionBlock[sectionNumber - 1];
		for (int i = 0; sectionNumber + i < (*block)->sectionCounter; i++) {
			(*block)->sectionBlock[sectionNumber - 1 + i] = (*block)->sectionBlock[sectionNumber + i];
		}
		while ((*block)->next != nullptr) {
			(*block)->sectionBlock[(*block)->sectionCounter - 1] = (*block)->next->sectionBlock[0];
			(*block) = (*block)->next;
			for (int i = 0; i + 1 < (*block)->sectionCounter; i++) {
				(*block)->sectionBlock[i] = (*block)->sectionBlock[i + 1];
			}
		}
		(*block)->sectionBlock[(*block)->sectionCounter - 1] = tmp;
		deleteSection(block, (*block)->sectionCounter);
		nullSection(block, (*block)->sectionCounter);
		(*block)->sectionCounter--;
		if ((*block)->sectionCounter == 0) {
			if (((*block)->next != nullptr) && ((*block)->previous != nullptr)) {
				(*block)->next->previous = (*block)->previous;
				(*block)->previous->next = (*block)->next;
				Block* tmp = (*block)->previous;
				delete (*block);
				(*block) = nullptr;
				(*block) = tmp;
			}
			else if ((*block)->next != nullptr) {
				(*block)->next->previous = nullptr;
				Block* tmp = (*block)->next;
				delete (*block);
				(*block) = nullptr;
				(*block) = tmp;
				(*head) = (*block);
			}
			else if ((*block)->previous != nullptr) {
				(*block)->previous->next = nullptr;
				Block* tmp = (*block)->previous;
				delete (*block);
				(*block) = nullptr;
				(*block) = tmp;
				(*tail) = (*block);
			}
		}
		if (printControler == PRINT) {
			std::cout << sectionNumberToPrint << ",D,* == deleted" << endl;
		}
	}
}

bool checkIfAttributeWasFound(Block** block, Block** head, Block** tail, int sectionNumber, int sectionNumberToPrint, char* attribute) {
	if ((strcmp((*block)->sectionBlock[sectionNumber - 1].attributes->attributesArray, attribute) == 0) && ((*block)->sectionBlock[sectionNumber - 1].attributes != nullptr)) {
		if (((*block)->sectionBlock[sectionNumber - 1].attributes->next != nullptr) && ((*block)->sectionBlock[sectionNumber - 1].attributes->previous != nullptr)) {
			(*block)->sectionBlock[sectionNumber - 1].attributes->next->previous = (*block)->sectionBlock[sectionNumber - 1].attributes->previous;
			(*block)->sectionBlock[sectionNumber - 1].attributes->previous->next = (*block)->sectionBlock[sectionNumber - 1].attributes->next;
			Attributes* tmp = (*block)->sectionBlock[sectionNumber - 1].attributes->previous;
			delete (*block)->sectionBlock[sectionNumber - 1].attributes;
			(*block)->sectionBlock[sectionNumber - 1].attributes = nullptr;
			(*block)->sectionBlock[sectionNumber - 1].attributes = tmp;
			std::cout << sectionNumberToPrint << ",D," << attribute << " == deleted" << endl;
			return true;
		}
		else if ((*block)->sectionBlock[sectionNumber - 1].attributes->next != nullptr) {
			(*block)->sectionBlock[sectionNumber - 1].attributes->next->previous = nullptr;
			Attributes* tmp = (*block)->sectionBlock[sectionNumber - 1].attributes->next;
			delete (*block)->sectionBlock[sectionNumber - 1].attributes;
			(*block)->sectionBlock[sectionNumber - 1].attributes = nullptr;
			(*block)->sectionBlock[sectionNumber - 1].attributes = tmp;
			(*block)->sectionBlock[sectionNumber - 1].attributesHead = (*block)->sectionBlock[sectionNumber - 1].attributes;
			std::cout << sectionNumberToPrint << ",D," << attribute << " == deleted" << endl;
			return true;
		}
		else if ((*block)->sectionBlock[sectionNumber - 1].attributes->previous != nullptr) {
			(*block)->sectionBlock[sectionNumber - 1].attributes->previous->next = nullptr;
			Attributes* tmp = (*block)->sectionBlock[sectionNumber - 1].attributes->previous;
			delete (*block)->sectionBlock[sectionNumber - 1].attributes;
			(*block)->sectionBlock[sectionNumber - 1].attributes = nullptr;
			(*block)->sectionBlock[sectionNumber - 1].attributes = tmp;
			(*block)->sectionBlock[sectionNumber - 1].attributesTail = (*block)->sectionBlock[sectionNumber - 1].attributes;
			std::cout << sectionNumberToPrint << ",D," << attribute << " == deleted" << endl;
			return true;
		}
		else {
			deleteSection(block, head, tail, sectionNumberToPrint, DO_NOT_PRINT);
			std::cout << sectionNumberToPrint << ",D," << attribute << " == deleted" << endl;
			return true;
		}
	}
	return false;
}

void deleteAttribute(Block** block, Block** head, Block** tail, int sectionNumber, char* attribute) {
	int i = 1;
	int sectionNumberToPrint = sectionNumber;
	*block = *head;
	while (((*block)->next != nullptr) && ((i * T) < sectionNumber)) {
		*block = (*block)->next;
		i++;
	}
	i -= 1;
	sectionNumber -= (i * T);
	i = 0;
	(*block)->sectionBlock[sectionNumber - 1].attributes = (*block)->sectionBlock[sectionNumber - 1].attributesHead;

	if ((sectionNumber <= (*block)->sectionCounter) && (sectionNumber > 0)) {
		while ((*block)->sectionBlock[sectionNumber - 1].attributes->next != nullptr) {
			if (checkIfAttributeWasFound(block, head, tail, sectionNumber, sectionNumberToPrint, attribute) == true) {
				break;
			}
			(*block)->sectionBlock[sectionNumber - 1].attributes = (*block)->sectionBlock[sectionNumber - 1].attributes->next;
		}
		checkIfAttributeWasFound(block, head, tail, sectionNumber, sectionNumberToPrint, attribute);
	}
}

int main(void) {
	char* buffer = new char[DEFAULT_TMP_SIZE], marker[DEFAULT_MARKER_SIZE], selectorNumber[DEFAULT_SELECTOR_NUMBER_SIZE];
	char sign = '\0';
	char* TMP = new char[DEFAULT_TMP_SIZE];
	char* attributeRepeat = new char[1];
	int n = DEFAULT_TMP_SIZE, lastAttributeControler = 0, end = 0, begginning = 0, commandsControler = 0, i = 0,
		commaControler = 0, propertieControler = 0, length = 0, loadControler = 0;

	Block* block, * head, * tail;
	initializeBlock(&block, &head, &tail);

	memset(buffer, NULL, DEFAULT_TMP_SIZE);
	memset(TMP, NULL, DEFAULT_TMP_SIZE);


	while (cin.get(sign)) {
		if (i == n - 1) {
			reallocTmp(buffer, n);
		}
		if ((sign > WHITE_SPACE_CHARACTERS) && (loadControler == AVOID_WHITESPACE_CHAR)) {
			buffer[i] = sign;
			i++;
			loadControler = START_INSERTING;
		}
		else if ((sign != '\t') && (loadControler == START_INSERTING)) {
			buffer[i] = sign;
			i++;
		}
		if (sign == '?') {
			commandsControler++;
		}
		if (commandsControler == GET_IN_COMMANDS_LOOP) {
			memset(buffer, NULL, n);
			end = 0;
			commandsControler = 0;
			while ((commandsControler < GET_IN_COMMANDS_LOOP) && (cin.get(sign))) {
				memset(buffer, NULL, end);
				i = 0;
				end = 0;
				commaControler = 0;
				loadControler = AVOID_WHITESPACE_CHAR;
				if (sign > WHITE_SPACE_CHARACTERS) {
					buffer[end] = sign;
					end++;
				}
				while ((cin.get(sign)) && (sign != '\n')) {
					if ((sign > WHITE_SPACE_CHARACTERS) && (loadControler == AVOID_WHITESPACE_CHAR)) {
						buffer[end] = sign;
						end++;
						loadControler = START_INSERTING;
						if (sign == ',') {
							commaControler++;
						}
					}
					else if ((sign != '\t') && (loadControler == START_INSERTING)) {
						buffer[end] = sign;
						end++;
						if (sign == ',') {
							commaControler++;
						}
					}
				}
				switch (buffer[i]) {
				case '?':
					countSections(*head);
					break;
				case '*':
					for (int i = 0; i < end; i++) {
						if (buffer[i] == '*') {
							commandsControler++;
						}
					}
					break;
				default:
					if (commaControler == 2) {
						if (isdigit(buffer[i]) != 0) {
							i = 0;
							memset(marker, NULL, DEFAULT_MARKER_SIZE);
							while (buffer[i] != ',') {
								marker[i] = buffer[i];
								i++;
							}
							i++;
							switch (buffer[i]) {
							case 'A':
								i += 2;
								if (buffer[i] == '?') {
									countAttributes(*head, atoi(marker));
								}
								else {
									char* attribute = new char[end - i + 1];
									for (int j = 0; j < end - i; j++) {
										attribute[j] = buffer[i + j];
									}
									attribute[end - i] = '\0';
									findPropertie(*head, atoi(marker), attribute);
									delete[] attribute;
								}
								break;
							case 'S':
								i += 2;
								if (buffer[i] == '?') {
									countSelectors(*head, atoi(marker));
								}
								else {
									memset(selectorNumber, NULL, DEFAULT_SELECTOR_NUMBER_SIZE);
									for (int j = 0; j < end - i; j++) {
										selectorNumber[j] = buffer[i + j];
									}
									findSelector(*head, atoi(marker), atoi(selectorNumber));
								}
								break;
							case 'D':
								i += 2;
								if (buffer[i] == '*') {
									deleteSection(&block, &head, &tail, atoi(marker), PRINT);
								}
								else {
									char* attribute = new char[end - i + 1];
									for (int j = 0; j < end - i; j++) {
										attribute[j] = buffer[i + j];
									}
									attribute[end - i] = '\0';
									deleteAttribute(&block, &head, &tail, atoi(marker), attribute);
									delete[] attribute;
								}
								break;
							}
						}
						else {
							i = 0;
							char* tmp = new char[end - i + 1];
							while (buffer[i] != ',') {
								tmp[i] = buffer[i];
								i++;
							}
							tmp[i] = '\0';
							i++;
							switch (buffer[i]) {
							case 'A':
								i += 2;
								if (buffer[i] == '?') {
									countAttributeInstances(*head, tmp);
								}
								delete[] tmp;
								break;
							case 'S':
								i += 2;
								if (buffer[i] == '?') {
									countSelectorInstances(*head, tmp);
								}
								delete[] tmp;
								break;
							case 'E':
								i += 2;
								char* attribute = new char[end - begginning - i + 1];
								for (int j = 0; j < end - begginning - i; j++) {
									attribute[j] = buffer[begginning + i + j];
								}
								attribute[end - i] = '\0';
								findSelectorsPropertie(*tail, tmp, attribute);
								delete[] attribute;
								delete[] tmp;
								break;
							}
						}
					}
					break;
				}
			}
			commandsControler = NORMAL_STATE;
			end = 0;
			memset(buffer, NULL, n);
		}
		if (sign == '}') {
			
			while (end < i) {
				if (tail->sectionBlock[0].attributes != nullptr) {
					if (tail->sectionCounter == T) {
						insertBlock(&tail);
					}
					else if (tail->sectionBlock[0].attributes->attributesArray != nullptr) {
						tail->sectionCounter++;
						block = tail;
						initializeSelectors(&block);
						initializeAttributes(&block);
					}
				}
				else if (tail->sectionCounter == 0) {
					tail->sectionCounter++;
					block = tail;
					initializeSelectors(&block);
					initializeAttributes(&block);
				}
				while (buffer[end] != '{') {	//selectors loop
					if (buffer[end] == ',') {
						cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
						insertSelector(&block, TMP, length);
						setPositionOfEndAndBeginning(end, begginning);
					}
					else {
						end++;
					}
				}
				if (end > 0) {
					cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
					insertSelector(&block, TMP, length);
					setPositionOfEndAndBeginning(end, begginning);
				}
				checkForNewLineSign(buffer, end, begginning);
				while (buffer[end] != '}') {	//atributes loop
					if (buffer[end] == ':') {
						cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
						if (insertAttribute(&block, TMP, length) == false) {
							propertieControler = REPEAT_OF_ATTRIBUTE;
							attributeRepeat = new char[length + 5];
							for (int i = 0; i < length; i++) {
								attributeRepeat[i] = TMP[i];
							}
							attributeRepeat[length] = '\0';
						}
						setPositionOfEndAndBeginning(end, begginning);
						lastAttributeControler = CHECK_IF_TO_INSERT_ATTRIBUTE_WITHOUTH_SEMICOLON;
					}
					else if (buffer[end] == ';') {
						if (propertieControler == NORMAL_STATE) {
							cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
							insertPropertie(&block, TMP, length);
						}
						else if (propertieControler == REPEAT_OF_ATTRIBUTE) {
							propertieControler = NORMAL_STATE;
							cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
							overwritePropertie(&block, TMP, attributeRepeat, length);
						}
						setPositionOfEndAndBeginning(end, begginning);
						checkForNewLineSign(buffer, end, begginning);
					}
					else {
						end++;
					}
				}
				checkForNewLineSign(buffer, end, begginning);
				if ((lastAttributeControler == CHECK_IF_TO_INSERT_ATTRIBUTE_WITHOUTH_SEMICOLON) && (begginning != end)) {
					lastAttributeControler = NORMAL_STATE;
					if (propertieControler == NORMAL_STATE) {
						cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);    //scanning for last attribute value without ";"
						insertPropertie(&block, TMP, length);
					}
					else if (propertieControler == REPEAT_OF_ATTRIBUTE) {
						propertieControler = NORMAL_STATE;
						cleanAndPrepareTheTMP(TMP, length, buffer, end, begginning);
						overwritePropertie(&block, TMP, attributeRepeat, length);
					}
					setPositionOfEndAndBeginning(end, begginning);
				}
				checkForNewLineSign(buffer, end, begginning);
				setPositionOfEndAndBeginning(end, begginning);
				memset(buffer, NULL, n);
				i = 0;
				end = 0;
				begginning = 0;
				loadControler = AVOID_WHITESPACE_CHAR;
			}
		}
	}

	delete[] attributeRepeat;
	delete[] TMP;
	delete[] buffer;
	delete head;
	return 0;
}

