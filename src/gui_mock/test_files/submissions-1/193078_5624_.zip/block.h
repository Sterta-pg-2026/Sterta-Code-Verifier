#pragma once
#include "sekcja.h"

#define T 8

class Block
{
private:
	int id = 0;
	int size = 0;
public:
	Sekcja tab[T];
	int GetId();
	void SetId(int i);
	int GetSize();
	void SetSize(int i);
};

