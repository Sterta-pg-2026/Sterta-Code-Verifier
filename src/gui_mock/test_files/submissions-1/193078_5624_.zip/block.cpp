#include "block.h"

int Block::GetId()
{
	return id;
}

void Block::SetId(int i)
{
	this->id = i;
}

int Block::GetSize()
{
	return size;
}

void Block::SetSize(int i)
{
	this->size = i;
}