#pragma once
#include <iostream>
#include <string.h>

class MyString {
protected:
	friend std::ostream& operator<<(std::ostream& out, const MyString& string);

public:
	char* buff;
	MyString();
	MyString(const char* str); //with pointer
	MyString(const MyString& str); //copy
	MyString(char c);
	~MyString();

	void operator= (const MyString& str);
	void operator= (const MyString&& str);
	void operator+= (const MyString& str);
	void operator+= (char c);
	bool operator== (const MyString& str);
	MyString operator+ (const MyString& str);

	int getSize();
	
};