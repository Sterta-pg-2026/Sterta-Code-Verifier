#pragma once
#include <iostream>
#include "mystring.h"

class Atrybut
{
public:
	bool deleted = 0;
	MyString atrybut;
	MyString value;
};

