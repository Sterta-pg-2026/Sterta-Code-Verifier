#include <iostream>
#include "mystring.h"
#include "doublylinkedlist.h"
#include "atrybut.h"
#include "sekcja.h"
#include "block.h"
#include <math.h>

int strToInt(MyString liczba)
{
	int i = 0;
	int size = (liczba.getSize() - 1);

	for (int j = 0; j < liczba.getSize(); j++)
	{
		i += (liczba.buff[j] - '0') * pow(10, size-j);
	}

	return i;
}

int LiczbaSekcji(DoublyLinkedList<Block> Lista)
{
	int result = 0;
	for (int i = 0; i < Lista.GetListLen(); i++)
	{
		result += Lista.GetAtPos(i)->data.GetSize();
	}
	return result;
}

Sekcja ZnajdzSekcje(int n, DoublyLinkedList<Block> Lista)
{
	Sekcja fail = {};
	fail.fail = 1;
	Node<Block>* tmp = Lista.GetFirst();
	if (tmp == nullptr || n > LiczbaSekcji(Lista))
	{
		return fail;
	}
	while (n >= tmp->data.GetSize())
	{
		n -= tmp->data.GetSize();
		tmp = tmp->next;
	}
	for (int i = 0; i < n; i++)
	{
		if (tmp->data.tab[i].deleted)
			n++;
	}
	return tmp->data.tab[n];
}

//Sekcja ZnajdzSekcje(int n, DoublyLinkedList<Block> Lista) //check
//{
//	n--;
//	int i = 0, sum1 = 0, sum2 = Lista.GetAtPos(0)->data.GetSize();//GetAtPos(?)
//	Sekcja a = {};
//
//	for (i = 1; i < Lista.GetListLen(); i++)
//	{
//		if (n >= sum2)
//			break;
//		sum1 = sum2;
//		sum2 += Lista.GetAtPos(i)->data.GetSize();
//	}
//
//	if (i + 1 <= Lista.GetListLen())
//		return Lista.GetAtPos(i + 1)->data.tab[sum2 - sum1];
//	else
//		return a;
//}

MyString jSelektor_iSekcja(int i, int j, DoublyLinkedList<Block> Lista)
{
	Sekcja s = ZnajdzSekcje(i, Lista);
	MyString str = "FAIL";
	if (s.fail == 1)
		return str;
	else
		return s.ListaSelektor.GetAtPos(j)->data;
}

int LiczbaSelektor_iSekcja(int i, DoublyLinkedList<Block> Lista)
{
	Sekcja s = ZnajdzSekcje(i, Lista);
	if (s.fail == 1)
		return 0;
	else
		return s.ListaSelektor.GetListLen();
}

int LiczbaAtrybut_iSekcja(int i, DoublyLinkedList<Block> Lista)
{
	Sekcja s = ZnajdzSekcje(i, Lista);
	if (s.fail == 1)
		return 0;
	else
		return s.ListaAtrybut.GetListLen();
}

MyString WartoscAtrybut_iSekcja(MyString str, int i, DoublyLinkedList<Block> Lista)
{
	MyString result = "";
	for (int j = 0; j < ZnajdzSekcje(i, Lista).ListaAtrybut.GetListLen(); j++)
	{
		if (ZnajdzSekcje(i, Lista).ListaAtrybut.GetAtPos(j)->data.atrybut == str)
			result = ZnajdzSekcje(i, Lista).ListaAtrybut.GetAtPos(j)->data.value;
	}
	return result;
}

MyString Usun_iSekcja(int i, DoublyLinkedList<Block>& Lista)
{
	Sekcja s = ZnajdzSekcje(i, Lista);

	if (s.ListaAtrybut.GetListLen() > 0) {
		s.deleted = 1;
		return "deleted";
	}

	/*if (s.deleted == 1)
		return "deleted";*/

	return "FAIL";
}

MyString UsunAtrybut_iSekcja(MyString str, int i, DoublyLinkedList<Block>& Lista)
{
	Sekcja s = ZnajdzSekcje(i, Lista);

	if (s.ListaAtrybut.GetListLen() > 0 && s.deleted == 0)
		for (int j = 0; j < s.ListaAtrybut.GetListLen(); j++)
		{
			if (s.ListaAtrybut.GetAtPos(j)->data.atrybut == str && s.ListaAtrybut.GetAtPos(j)->data.deleted == 0)
				s.ListaAtrybut.GetAtPos(j)->data.deleted = 1;
		}

	if (s.deleted == 1)
		return "deleted";
	else
		return "FAIL";
}

int LiczbaSelektor(MyString str, DoublyLinkedList<Block> Lista)
{
	int result = 0;
	for (int i = 0; i < Lista.GetListLen(); i++)
	{
		for (int j = 0; j < Lista.GetAtPos(i)->data.GetSize(); j++)
		{
			for (int k = 0; k < Lista.GetAtPos(i)->data.tab[j].ListaSelektor.GetListLen(); k++)
			{
				if (str == Lista.GetAtPos(i)->data.tab[j].ListaSelektor.GetAtPos(k)->data)
					result++;
			}
		}
	}
	return result;
}

int LiczbaAtrybut(MyString str, DoublyLinkedList<Block> Lista)
{
	int result = 0;
	for (int i = 0; i < Lista.GetListLen(); i++)
	{
		for (int j = 0; j < Lista.GetAtPos(i)->data.GetSize(); j++)
		{
			for (int k = 0; k < Lista.GetAtPos(i)->data.tab[j].ListaAtrybut.GetListLen(); k++)
			{
				if (str == Lista.GetAtPos(i)->data.tab[j].ListaAtrybut.GetAtPos(k)->data.atrybut)
					result++;
			}
		}
	}
	return result;
}

MyString WartoscAtrybut_Selektor(MyString str, MyString str2, DoublyLinkedList<Block> Lista)
{
	MyString result = "";
	for (int i = 0; i < Lista.GetListLen(); i++)
	{
		for (int j = 0; j < Lista.GetAtPos(i)->data.GetSize(); j++)
		{
			for (int k = 0; k < Lista.GetAtPos(i)->data.tab[j].ListaAtrybut.GetListLen(); k++)
			{
				if (str2 == Lista.GetAtPos(i)->data.tab[j].ListaSelektor.GetAtPos(k)->data)
					if (str == Lista.GetAtPos(i)->data.tab[j].ListaAtrybut.GetAtPos(k)->data.atrybut)
						result = Lista.GetAtPos(i)->data.tab[j].ListaAtrybut.GetAtPos(k)->data.value;
			}
		}
	}
	return result;
}

void Komendy_Liczba(char c, DoublyLinkedList<Block>& Lista, MyString& komenda)
{
	MyString liczba;
	liczba += c;
	c = getchar();
	komenda += c;
	while (c != ',')
	{
		liczba += c;
		c = getchar();
		komenda += c;
	}
	int i = strToInt(liczba);

	c = getchar();
	komenda += c;
	if (c == 'S')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
		{
			c = getchar();
			komenda += c;
			if (c >= '0' && c <= '9')
			{
				MyString liczba;
				liczba += c;
				c = getchar();
				komenda += c;
				while (c != EOF && c!='\n')
				{
					liczba += c;
					c = getchar();
					komenda += c;
				}
				int j = strToInt(liczba);
				std::cout << komenda << " == " << jSelektor_iSekcja(i, j, Lista) << '\n';
			}
			else if (c == '?')
				std::cout << komenda << " == " << LiczbaSelektor_iSekcja(i, Lista) << '\n';
		}
	}
	else if (c == 'A')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
		{
			c = getchar();
			komenda += c;
			if (c == '?')
				std::cout << komenda << " == " << LiczbaAtrybut_iSekcja(i, Lista) << '\n';
			else
			{
				MyString str;
				str += c;
				c = getchar();
				komenda += c;
				while (c != EOF && c!='\n')
				{
					str += c;
					c = getchar();
					komenda += c;
				}
				std::cout << komenda << " == " << WartoscAtrybut_iSekcja(str, i, Lista) << '\n';
			}
		}
	}
	else if (c == 'D')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
		{
			c = getchar();
			komenda += c;
			if (c == '*')
				std::cout << komenda << " == " << Usun_iSekcja(i, Lista) << '\n';
			else
			{
				MyString str;
				str += c;
				c = getchar();
				komenda += c;
				while (c != EOF && c!='\n')
				{
					str += c;
					c = getchar();
					komenda += c;
				}
				std::cout << komenda << " == " << UsunAtrybut_iSekcja(str, i, Lista) << '\n';
			}

		}
	}
}

void Komendy_String(char c, DoublyLinkedList<Block> Lista, MyString& komenda)
{

	MyString str;
	str += c;
	c = getchar();
	komenda += c;
	while (c != ',')
	{
		str += c;
		c = getchar();
		komenda += c;
	}
	c = getchar();
	komenda += c;
	if (c == 'S')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
		{
			c = getchar();
			komenda += c;
			if (c == '?')
				std::cout << komenda << " == " << LiczbaSelektor(str, Lista) << '\n';
		}
	}
	else if (c == 'A')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
			if (c == '?')
				std::cout << komenda << " == " << LiczbaAtrybut(str, Lista) << '\n';
	}
	else if (c == 'E')
	{
		c = getchar();
		komenda += c;
		if (c == ',')
		{
			MyString str2;
			str2 += c;
			c = getchar();
			komenda += c;
			while (c != EOF)
			{
				str2 += c;
				c = getchar();
				komenda += c;
			}
			std::cout << komenda << " == " << WartoscAtrybut_Selektor(str, str2, Lista) << '\n';
		}
	}
}

void Komendy(DoublyLinkedList<Block>& Lista)
{
	MyString komenda;
	char c = getchar();
	if (c == '\n')
		c = getchar();
	komenda += c;
	while (c != '*')
	{
		if (c == '\n')
			c = getchar();

		if (c == '?')
		{
			std::cout << komenda << " == " << LiczbaSekcji(Lista)<<'\n';
		}

		else if (c >= '1' && c <= '9')
			Komendy_Liczba(c, Lista, komenda);

		else
			Komendy_String(c, Lista, komenda);

		komenda = "";
		c = getchar();
	}


}

void DodajSelektor(Block& b, DoublyLinkedList<MyString>& ListaSelektory, MyString str)
{
	Sekcja sekcja[T];
	Node<MyString>* selektor = new Node<MyString>;
	selektor->data = str;
	ListaSelektory.AddLast(selektor);
	sekcja[b.GetId()].ListaSelektor = ListaSelektory;
	b.tab[b.GetId()] = sekcja[b.GetId()];
}

void DodajAtrybut(Block& b, DoublyLinkedList<Atrybut>& ListaAtrybuty, MyString str, MyString value)
{
	Sekcja sekcja[T];
	Node<Atrybut>* atrybut = new Node<Atrybut>;
	atrybut->data.atrybut = str;
	atrybut->data.value = value;
	ListaAtrybuty.AddLast(atrybut);
	sekcja[b.GetId()].ListaAtrybut = ListaAtrybuty;
	b.tab[b.GetId()] = sekcja[b.GetId()];
}

void Atrybuty(Block& b, DoublyLinkedList<Atrybut>& ListaAtrybuty)
{
	MyString str="", value="";
	char c = getchar();
	while (c != '}')
	{
		while (c != ':')
		{
			if(c!='\n')
				str += c;
			c = getchar();
		}

		while (c != ';' && c != '}')
		{
			value += c;
			c = getchar();
		}
		DodajAtrybut(b, ListaAtrybuty, str, value);
		str = "";
		value = "";
		if(c==';')
			c = getchar();
	}
	DodajAtrybut(b, ListaAtrybuty, str, value);
	str = "";
	value = "";
	b.SetSize(b.GetSize() + 1);
}

int main()
{
	char c;
	MyString str;
	DoublyLinkedList<Block> Lista;
	DoublyLinkedList<MyString> ListaSelektory;
	DoublyLinkedList<Atrybut> ListaAtrybuty;
	Block b = {};
	Node<Block>* block = new Node<Block>;
	block->data = b;

	c = getchar();
	while (c != EOF)
	{
		if (c == '*' || c=='\n')
			c = getchar();
		
		if (c == '?')
		{
			c = getchar();
			if (c == '?')
			{
				c = getchar();
				if (c == '?')
				{
					c = getchar();
					if (c == '?')
						Komendy(Lista);
				}
			}
		}
		else if (c == '{')
		{
			str = "";
			DodajSelektor(b, ListaSelektory, str);
			Atrybuty(b, ListaAtrybuty);
		}
		else
		{
			while (c != '{')
			{
				while (c != ',' && c != '{')
				{
					str += c;
					c = getchar();
				}
				DodajSelektor(b, ListaSelektory, str);
				str = "";
			}
			DodajSelektor(b, ListaSelektory, str);
			str = "";

			Atrybuty(b, ListaAtrybuty);
		}

		if (b.GetId() == T)
		{
			b.SetId(0);
			Lista.AddLast(block);
			delete[] block;
			Node<Block>* block = new Node<Block>;
		}
		c = getchar();
	}

	return 0;
}