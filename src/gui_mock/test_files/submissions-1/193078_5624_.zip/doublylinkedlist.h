#pragma once
#include <iostream>

template<typename type>
struct Node {
	type data;
	Node* next = nullptr;
	Node* prev = nullptr;
};

template <typename type>
class DoublyLinkedList {
private:
	Node<type>* FirstNode = nullptr;
public:


	void PrintList()
	{
		Node<type>* tmp = FirstNode;
		while (tmp != nullptr)
		{
			std::cout << tmp->data;
			tmp = tmp->next;
		}
	}

	int GetListLen()
	{
		int cnt = 0;
		Node<type>* tmp = FirstNode;
		while (tmp != nullptr)
		{
			cnt++;
			tmp = tmp->next;
		}
		return cnt;
	}

	Node<type>* GetFirst()
	{
		return FirstNode;
	}

	Node<type>* GetLast()
	{
		if (FirstNode == nullptr)
			return nullptr;
		Node<type>* tmp = FirstNode;
		while (tmp->next != nullptr)
		{
			tmp = tmp->next;
		}
		return tmp;
	}

	void AddFirst(Node<type>* newNode)
	{
		newNode->prev = nullptr;
		newNode->next = FirstNode;
		if (FirstNode != nullptr)
			FirstNode->prev = newNode;
	}

	void AddLast(Node<type>* newNode)
	{
		Node<type>* last = GetLast();
		newNode->prev = last;
		if (last != nullptr)
		{
			last->next = newNode;
		}
	}

	void RemoveNode(Node<type>* node)
	{
		if (node == nullptr)
			return;
		if (node->next != nullptr)
			node->next->prev = node->prev;
		if (node->prev == nullptr)
			return;
		node->prev->next = node->next;
	}

	void RemoveFirst()
	{
		RemoveNode(FirstNode);
	}

	void RemoveLast()
	{
		Node<type>* last = GetLast();
		RemoveNode(last);
	}

	/*Node<type>* FindNode(type dataPattern)
	{
		Node<type>* tmp = FirstNode;
		while (tmp != nullptr)
		{
			if (tmp->data == dataPattern)
				return tmp;
			tmp = tmp->next;
		}
		return nullptr;
	}*/

	Node<type>* GetAtPos(int pos)
	{
		Node<type>* tmp = FirstNode;
		while (tmp != nullptr)
		{
			if (pos == 0)
				return tmp;
			pos--;
			tmp = tmp->next;
		}
		return 0;
	}

	void InsertAfter(Node<type>* newNode, Node<type>* node)
	{
		if (node == nullptr)
			return;
		newNode->next = node->next;
		newNode->prev = node;
		if (node->next != nullptr)
			node->next->prev = newNode;
		node->next = newNode;
	}

	void RemoveAfter(Node<type>* node)
	{
		if (node == nullptr)
			return;
		if (node->next == nullptr)
			return;
		node->next = node->next->next;
		if (node->next != nullptr)
			node->next->prev = node;
	}

	void InsertBefore(Node<type>* newNode, Node<type>* node)
	{
		if (node == nullptr)
			return;
		newNode->next = node;
		newNode->prev = node->prev;
		node->prev = newNode;
		if (newNode->prev == nullptr)
			return;
		newNode->prev->next = newNode;
	}
	

};