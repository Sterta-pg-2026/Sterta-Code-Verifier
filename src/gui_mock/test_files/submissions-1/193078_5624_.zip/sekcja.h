#pragma once
#include "doublylinkedlist.h"
#include "mystring.h"
#include "atrybut.h"

class Sekcja
{
public:
	bool fail = 0;
	bool deleted = 0;
	DoublyLinkedList<MyString> ListaSelektor;
	DoublyLinkedList<Atrybut> ListaAtrybut;
};

