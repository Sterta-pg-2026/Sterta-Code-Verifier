#define _CRT_SECURE_NO_WARNINGS

#include "mystring.h"


MyString::MyString() : buff{ nullptr }
{
	buff = new char[1];
	buff[0] = '\0';
}

MyString::MyString(char c)
{
	buff = new char[2];
	buff[0] = c;
	buff[1] = '\0';
}

MyString::MyString(const char* str)
{
	if (str == nullptr)
	{
		buff = new char[1];
		buff[0] = '\0';
	}
	else
	{
		buff = new char[strlen(str) + 1];
		strcpy(buff, str);
		buff[strlen(str)] = '\0';
	}
}

MyString::MyString(const MyString& str)
{
	if (str.buff == nullptr)
	{
		buff = new char[1];
		buff[0] = '\0';
	}
	else
	{
		buff = new char[strlen(str.buff) + 1];
		strcpy(buff, str.buff);
		buff[strlen(str.buff)] = '\0';
	}
}

MyString::~MyString()
{
	delete buff;
}

int MyString::getSize()
{
	return strlen(buff);
}

std::ostream& operator<<(std::ostream& out, const MyString& string)
{
	out << string.buff;
	return out;
}

void MyString::operator= (const MyString& str)
{
	int size = 0;
	while (str.buff[size] != '\0')
		size++;

	delete[] buff;
	buff = new char[size + 1];
	for (int i = 0; i < size; i++)
		buff[i] = str.buff[i];
	buff[size] = '\0';
}

void MyString::operator= (const MyString&& str)
{
	int size = 0;
	while (str.buff[size] != '\0')
		size++;

	delete[] buff;
	buff = new char[size + 1];
	for (int i = 0; i < size; i++)
		buff[i] = str.buff[i];
	buff[size] = '\0';
}

void MyString::operator+= (const MyString& str)
{
	MyString tmp(buff);
	//delete[] buff;
	buff = new char[strlen(tmp.buff) + strlen(str.buff) + 1];

	for (int i = 0; i < strlen(tmp.buff); i++)
		buff[i] = tmp.buff[i];
	for (int i = 0; i < strlen(str.buff); i++)
		buff[i + strlen(tmp.buff)] = str.buff[i];

	buff[strlen(tmp.buff) + strlen(str.buff)] = '\0';
}

void MyString::operator+= (char c)
{
	if (buff == nullptr)
	{
		buff = new char[2];
		buff[0] = c;
		buff[1] = '\0';
	}
	else
	{
		MyString tmp(buff);
		delete[] buff;
		buff = new char[strlen(tmp.buff) + 2];

		for (int i = 0; i < strlen(tmp.buff); i++)
			buff[i] = tmp.buff[i];

		buff[strlen(tmp.buff)] = c;

		buff[strlen(tmp.buff) + 1] = '\0';
	}
}

MyString MyString::operator+ (const MyString& str)
{
	MyString tmp(buff);
	tmp += str;
	return tmp;
}

bool MyString::operator== (const MyString& str)
{
	if (getSize() != strlen(str.buff))
		return false;

	for (int i = 0; i < getSize(); i++)
	{
		if (buff[i] != str.buff[i])
			return false;
	}

	return true;
}

