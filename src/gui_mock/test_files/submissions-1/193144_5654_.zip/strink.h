#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>

using namespace std;

class strink
{
private:
	char* data;
	int size;
public:
	strink();
	strink(const char* str);
	strink(const strink& other);
	friend ostream& operator<<(ostream& os, const strink& str);
	friend istream& operator>>(istream& is, strink& str);
	bool operator==(const strink& other) const;
	bool operator!=(const strink& other) const;
	char& operator[](int index);
	strink& operator=(const strink& other);
};