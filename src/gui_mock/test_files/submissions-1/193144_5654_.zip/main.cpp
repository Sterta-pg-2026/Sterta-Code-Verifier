#include <iostream>
#include "strink.h"
#include "list.h"
#include "list2.h"
#include "list3.h"

using namespace std;

int main()
{
    list3 sections;
    strink input;
    strink input2;
    bool commands = 0;

    strink* atr123 = new strink[30];
    strink* val123 = new strink[30];
    int global = 0;

    char c;
    int i = 0;
    int j = 0;
    int k = 0;
    int counter = 0;
    int cyfra = 0;
    int cyfra2 = 0;
    int cyfra3 = 0;

    char* tab = new char[100];
    for (int i = 0; i < 100; i++)
    {
        tab[i] = NULL;
    }
    char* tab2 = new char[100];
    for (int i = 0; i < 100; i++)
    {
        tab2[i] = NULL;
    }

    while (1)
    {
        sections.addnode_tail();
        while (1)
        {
            if ((c = getchar()) == EOF)
            {
                return 0;
            }
            if (c == ',')
            {
                sections.tmp->sel.addnode_tail(tab);
                for (int i = 0; i < 100; i++)
                {
                    tab[i] = NULL;
                }
                i = 0;
                c = getchar();
                if (c == 32)
                {
                    c = 128;
                }
            }
            if (c != '{' && c != ',' && c >= 32 && c < 128)
            {

                tab[i] = c;
                i++;
            }
            if (c == '{')
            {
                if (tab[i - 1] <= ' ')
                {
                    tab[i - 1] = '\0';
                }
                if (tab[0] != NULL && tab[1] != NULL)
                {
                    sections.tmp->sel.addnode_tail(tab);
                }
                else
                {
                    sections.tmp->sel.addnode_tail("remek");
                    sections.tmp->sel.counter = 0;
                }
                for (int i = 0; i < 100; i++)
                {
                    tab[i] = NULL;
                }
                i = 0;
                break;
            }
        }
        while (1)
        {
            std::cin >> c;
            if (c == ':')
            {
                c = getchar();
                i = 0;
                if (c != ' ')
                {
                    tab2[i] = c;
                    i++;
                }
                while (1)
                {
                    c = getchar();
                    if (c != ';' && c != '}')
                    {
                        tab2[i] = c;
                        i++;
                    }
                    if (c == ';' || c == '}')
                    {
                        break;
                    }
                }
                sections.tmp->att_val.addnode_tail(tab, tab2);
                i = 0;
                for (int i = 0; i < 100; i++)
                {
                    tab[i] = NULL;
                }
                for (int i = 0; i < 100; i++)
                {
                    tab2[i] = NULL;
                }
            }
            if (c == '}')
            {
                break;
            }
            if (c != ';' && c != '}')
            {
                tab[i] = c;
                i++;
            }
        }
        std::cin >> c;
        i = 0;
        if (c != '?')
        {
            tab[i] = c;
            i++;
        }
        if (c == '?')
        {
            tab[0] = c;
            for (int j = 1; j < 4; j++)
            {
                std::cin >> c;
                tab[j] = c;
            }
            if (tab[0] == '?' && tab[1] == '?' && tab[2] == '?' && tab[3] == '?')
            {
                commands = 1;
            }
            i = 0;
            for (int i = 0; i < 100; i++)
            {
                tab[i] = NULL;
            }
        }
        while (commands == 1)
        {
            std::cin >> c;
            if (cin.eof())
            {
                return 0;
            }
            if (c == '?')
            {
                std::cout << "? == " << sections.counter << endl;
            }
            else if (c == '*')
            {
                tab[0] = c;
                for (int j = 1; j < 4; j++)
                {
                    std::cin >> c;
                    tab[j] = c;
                }
                if (tab[0] == '*' && tab[1] == '*' && tab[2] == '*' && tab[3] == '*')
                {
                    i = 0;
                    for (int i = 0; i < 100; i++)
                    {
                        tab[i] = NULL;
                    }
                    commands = 0;
                    break;
                }
                i = 0;
                for (int i = 0; i < 100; i++)
                {
                    tab[i] = NULL;
                }
            }
            else if (c == '!')
            {
                sections.tmp = sections.head;
                sections.tmp->sel.printlist();
                sections.tmp->att_val.printlist();
                std::cout << "***" << endl;

                while (sections.tmp = sections.tmp->next)
                {
                    sections.tmp->sel.printlist();
                    sections.tmp->att_val.printlist();
                    std::cout << "***" << endl;
                }
            }
            else if (c >= '0' && c <= '9')
            {
                for (int i = 0; i < 100; i++)
                {
                    tab2[i] = NULL;
                }
                i = 0;
                j = 0;
                k = 10;
                tab2[i] = c;
                i = 1;
                cyfra2 = 0;
                while (c != ',')
                {
                    std::cin >> c;
                    tab2[i] = c;
                    i++;
                    k = k * 10;
                }
                cyfra2 = NULL;
                for (int a = 0; a < i; a++)
                {
                    cyfra2 = cyfra2 + (tab2[a] - '0') * k;
                    k = k / 10;
                }
                cyfra2 = cyfra2 / 10;
                cyfra2 = cyfra2 + 4;
                cyfra2 = cyfra2 / 10;
                for (int i = 0; i < 100; i++)
                {
                    tab2[i] = NULL;
                }
                i = 0;
                j = 0;
                k = 0;
                //OLD INPUT OF NUMBERS
                //cyfra2 = c - '0';
                //std::cin >> c;
                std::cin >> c;
                if (c == 'S')
                {
                    std::cin >> c;
                    std::cin >> c;
                    if (c == '?')
                    {
                        sections.tmp = sections.head;
                        if (cyfra2 <= sections.counter)
                        {
                            cyfra2--;
                            while (j != cyfra2)
                            {
                                sections.tmp = sections.tmp->next;
                                j++;
                            }
                            cyfra2++;
                            j = 0;
                            std::cout << cyfra2 << ",S,? == " << sections.tmp->sel.counter << endl;
                            cyfra2 = 0;
                        }
                    }
                    else
                    {
                        /* for (int i = 0; i < 100; i++)
                         {
                             tab2[i] = NULL;
                         }
                         i = 0;
                         j = 0;
                         k = 10;
                         tab2[i] = c;
                         i = 1;
                         cyfra = 0;
                         while (i != 3)
                         {
                             c = getchar();
                             if (c == '13')
                             {
                                 break;
                             }
                             tab2[i] = c;
                             i++;
                             k = k * 10;
                         }
                         cyfra = NULL;
                         for (int a = 0; a < i; a++)
                         {
                             cyfra = cyfra + (tab2[a] - '0') * k;
                             k = k / 10;
                         }
                         cyfra = cyfra / 10;
                         cyfra = cyfra + 4;
                         cyfra = cyfra / 10;
                         for (int i = 0; i < 100; i++)
                         {
                             tab2[i] = NULL;
                         }
                         i = 0;
                         j = 0;
                         k = 0;*/
                         //OLD INPUT OF NUMBERS
                        cyfra = c - '0';
                        sections.tmp = sections.head;
                        if (cyfra2 <= sections.counter)
                        {
                            cyfra2--;
                            while (j != cyfra2)
                            {
                                sections.tmp = sections.tmp->next;
                                j++;
                            }
                            cyfra2++;
                            j = 0;
                        }
                        sections.tmp->sel.tmp = sections.tmp->sel.head;
                        if (cyfra != 0 && cyfra <= sections.tmp->sel.counter && cyfra2 <= sections.counter)
                        {
                            cyfra--;
                            while (cyfra != j)
                            {
                                sections.tmp->sel.tmp = sections.tmp->sel.tmp->next;
                                j++;
                            }
                            cyfra++;
                            if (sections.tmp->sel.counter != 0)
                            {
                                std::cout << cyfra2 << ",S," << cyfra << " == " << sections.tmp->sel.tmp->data << endl;
                            }
                        }
                        i = 0;
                        j = 0;
                        k = 0;
                        cyfra = 0;
                        cyfra2 = 0;
                        cyfra3 = 0;
                    }
                }
                else if (c == 'A')
                {
                    std::cin >> c;
                    std::cin >> c;
                    if (c == '?')
                    {
                        sections.tmp = sections.head;
                        if (cyfra2 <= sections.counter)
                        {
                            cyfra2--;
                            while (j != cyfra2)
                            {
                                sections.tmp = sections.tmp->next;
                                j++;
                            }
                            cyfra2++;
                            j = 0;
                            std::cout << cyfra2 << ",A,? == " << sections.tmp->att_val.counter << endl;
                            cyfra2 = 0;
                        }
                    }
                    else
                    {
                        j = 0;
                        tab[j] = c;
                        j++;
                        while (1)
                        {
                            cin >> tab[j];
                            j++;
                            if (std::cin.peek() == '\n')
                            {
                                break;
                            }
                            tab[j] = '\0';
                        }
                        input2 = tab;
                        for (int i = 0; i < 100; i++)
                        {
                            tab[i] = NULL;
                        }
                        j = 0;
                        sections.tmp = sections.head;
                        if (cyfra2 <= sections.counter)
                        {
                            cyfra2--;
                            while (j != cyfra2)
                            {
                                sections.tmp = sections.tmp->next;
                                j++;
                            }
                            cyfra2++;
                        }
                        j = 0;
                        sections.tmp->att_val.tmp = sections.tmp->att_val.head;
                        while (1)
                        {
                            if (j > sections.tmp->att_val.counter || cyfra2 > sections.counter)
                            {
                                break;
                            }
                            if (sections.tmp->att_val.tmp->atrybut == input2)
                            {
                                std::cout << cyfra2 << ",A," << input2 << " == " << sections.tmp->att_val.tmp->wartosc << std::endl;
                                break;
                            }
                            if (sections.tmp->att_val.tmp->next == nullptr)
                            {
                                break;
                            }
                            sections.tmp->att_val.tmp = sections.tmp->att_val.tmp->next;
                            j++;
                        }
                        input = "";
                        j = 0;
                    }
                }
                else if (c == 'D')
                {
                    std::cin >> c;
                    std::cin >> c;
                    if (c == '*' && sections.counter >= cyfra2)
                    {
                        sections.deletenode_number(cyfra2);
                        std::cout << cyfra2 << ",D,* == deleted" << endl;
                    }
                    else if (c != '*')
                    {
                        tab[0] = c;
                        j = 1;
                        while (1)
                        {
                            cin >> tab[j];
                            j++;
                            if (std::cin.peek() == '\n')
                            {
                                break;
                            }
                            tab[j] = '\0';
                        }
                        input = tab;
                        k = 1;
                        sections.tmp = sections.head;
                        if (cyfra2 <= sections.counter)
                        {
                            while (1)
                            {
                                if (k == cyfra2)
                                {
                                    break;
                                }
                                sections.tmp = sections.tmp->next;
                                k++;
                            }
                        }
                        j = 1;
                        if (sections.counter != 0)
                        {
                            sections.tmp->att_val.tmp = sections.tmp->att_val.head;
                        }
                        else
                        {
                            goto exit;
                        }
                        if (cyfra2 > sections.counter)
                        {
                            goto exit;
                        }
                        while (1)
                        {
                            if (j > sections.tmp->att_val.counter || cyfra2 > sections.counter)
                            {
                                break;
                            }
                            if (sections.tmp->att_val.tmp->atrybut == input && sections.tmp->att_val.counter != 0)
                            {
                                std::cout << cyfra2 << ",D," << input << " == deleted" << endl;
                                if (sections.tmp->att_val.counter == 1)
                                {
                                    sections.tmp->att_val.deletenode_number(1);
                                    sections.deletenode_number(cyfra2);
                                }
                                else if (sections.tmp->att_val.counter > 1)
                                {
                                    sections.tmp->att_val.deletenode_number(j);
                                }
                                else if (sections.tmp->att_val.counter == 0)
                                {
                                    sections.deletenode_number(j + 1);
                                }
                                break;
                            }
                            if (sections.tmp->att_val.tmp->next == nullptr)
                            {
                                break;
                            }
                            if (sections.tmp->att_val.counter > 1)
                            {
                                sections.tmp->att_val.tmp = sections.tmp->att_val.tmp->next;
                            }
                            else
                            {
                            exit:
                                break;
                            }
                            j++;
                        }
                        input = "";
                        j = 0;
                        k = 0;
                        for (int i = 0; i < 100; i++)
                        {
                            tab[i] = NULL;
                        }
                    }
                }
            }
            else if (c != '?')
            {
                i = 0;
                tab[i] = c;
                i = 1;
                while (c != ',')
                {
                    //std::cin >> c;
                    c = getchar();
                    if (c != ',')
                    {
                        tab[i] = c;
                    }
                    i++;
                }
                i = 0;
                input = tab;
                for (int i = 0; i < 100; i++)
                {
                    tab[i] = NULL;
                }
                c = getchar();
                //std::cin >> c;
                if (c == ' ')
                {
                    c = getchar();
                    while (c != '?')
                    {
                        c = getchar();
                    }
                }
                if (c == 'A')
                {
                    std::cin >> c;
                    std::cin >> c;
                    if (c != '?')
                    {
                        break;
                    }
                    sections.tmp = sections.head;
                    sections.tmp->att_val.tmp = sections.tmp->att_val.head;
                    for (int i = 0; i < sections.counter; i++)
                    {
                        for (int j = 0; j < sections.tmp->att_val.counter; j++)
                        {
                            if (sections.tmp->att_val.tmp->atrybut == input)
                            {
                                counter++;
                            }
                            if (sections.tmp->att_val.tmp->next != nullptr)
                            {
                                sections.tmp->att_val.tmp = sections.tmp->att_val.tmp->next;
                            }
                        }
                        if (sections.tmp->next != nullptr)
                        {
                            sections.tmp = sections.tmp->next;
                            sections.tmp->att_val.tmp = sections.tmp->att_val.head;
                        }
                    }
                    std::cout << input << ",A,? == " << counter << endl;
                    counter = 0;
                    input = "";
                }
                else if (c == 'S')
                {
                    std::cin >> c;
                    std::cin >> c;
                    if (c != '?')
                    {
                        break;
                    }
                    sections.tmp = sections.head;
                    sections.tmp->sel.tmp = sections.tmp->sel.head;
                    for (int i = 0; i < sections.counter; i++)
                    {
                        for (int j = 0; j < sections.tmp->sel.counter; j++)
                        {
                            if (sections.tmp->sel.tmp->data == input)
                            {
                                counter++;
                            }
                            if (sections.tmp->sel.tmp->next != nullptr)
                            {
                                sections.tmp->sel.tmp = sections.tmp->sel.tmp->next;
                            }
                        }
                        if (sections.tmp->next != nullptr)
                        {
                            sections.tmp = sections.tmp->next;
                            sections.tmp->sel.tmp = sections.tmp->sel.head;
                        }
                    }
                    std::cout << input << ",S,? == " << counter << endl;
                    counter = 0;
                    input = "";
                }
                else if (c == 'E')
                {
                    std::cin >> c;
                    std::cin >> input2;
                    sections.tmp = sections.tail;
                    sections.tmp->sel.tmp = sections.tmp->sel.head;
                    while (i <= sections.counter)
                    {
                        while (j <= sections.tmp->sel.counter)
                        {
                            if (sections.tmp->sel.tmp->data == input)
                            {
                                break;
                            }
                            if (sections.tmp->sel.tmp->next == nullptr)
                            {
                                break;
                            }
                            if (sections.tmp->sel.tmp->next != nullptr)
                            {
                                sections.tmp->sel.tmp = sections.tmp->sel.tmp->next;
                            }
                            j++;
                        }
                        j = 0;
                        if (sections.tmp->sel.tmp->data == input)
                        {
                            break;
                        }
                        i++;
                        if (sections.tmp->prev == nullptr)
                        {
                            break;
                        }
                        if (sections.tmp->prev != nullptr)
                        {
                            sections.tmp = sections.tmp->prev;
                            sections.tmp->sel.tmp = sections.tmp->sel.head;
                        }
                    }
                    i = 0;
                    j = 0;
                    sections.tmp->att_val.tmp = sections.tmp->att_val.head;
                    while (j <= sections.tmp->att_val.counter)
                    {
                        if (sections.tmp->att_val.tmp->atrybut == input2)
                        {
                            break;
                        }
                        if (sections.tmp->att_val.tmp->next == nullptr)
                        {
                            break;
                        }
                        if (sections.tmp->att_val.tmp->next != nullptr)
                        {
                            sections.tmp->att_val.tmp = sections.tmp->att_val.tmp->next;
                        }
                        j++;
                    }
                    if (sections.tmp->att_val.tmp->atrybut == input2 && sections.tmp->sel.tmp->data == input)
                    {
                        std::cout << input << ",E," << input2 << " == " << sections.tmp->att_val.tmp->wartosc << endl;
                    }
                    counter = 0;
                    i = 0;
                    j = 0;
                    k = 0;
                    input = "";
                    input2 = "";
                }                
            }            
        }
    }
    return 0;
}
