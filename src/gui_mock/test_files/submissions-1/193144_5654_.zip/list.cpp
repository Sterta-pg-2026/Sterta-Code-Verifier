#include <iostream>
#include "strink.h"
#include "list.h"

    list::list()
    {
        head = nullptr;
        tail = nullptr;
        counter = 0;
    }

    list::~list()
    {
        node* current = head;
        counter = 0;
        while (current != nullptr)
        {
            node* tmp = current;
            current = current->next;
            delete tmp;
        }
    }

    void list::addnode_tail(strink data)
    {
        if (head != nullptr)
        {
            node* temp = head;
            while (1)
            {
                if (data == temp->data)
                {
                    return;
                }
                if (temp->next == nullptr)
                {
                    break;
                }
                temp = temp->next;
            }
        }
        node* nodee = new node();
        nodee->data = data;
        nodee->next = nullptr;
        nodee->prev = nullptr;
        counter++;
        if (head == nullptr)
        {
            head = nodee;
            tail = nodee;
        }
        else
        {
            tail->next = nodee;
            nodee->prev = tail;
            tail = nodee;
        }
    }

    void list::deletenode_tail()
    {
        node* tmp;
        tmp = head;
        if (head == nullptr)
        {
            return;
        }
        while (tmp->next->next != nullptr)
        {
            tmp = tmp->next;
        }
        delete tmp->next;
        tail = tmp;
        tmp->next = nullptr;
        counter--;
    }

    void list::addnode_head(strink data)
    {
        node* nodee = new node();
        nodee->data = data;
        nodee->next = head;
        nodee->prev = nullptr;
        head = nodee;
        head->next->prev = head;
        counter++;
    }

    void list::deletenode_head()
    {
        node* tmp;
        tmp = head;
        if (head == nullptr)
        {
            return;
        }
        head = tmp->next;
        head->prev = nullptr;
        delete tmp;
        counter--;
    }

    void list::addnode_number(strink data, int number)
    {
        if (head == nullptr)
        {
            addnode_head(data);
        }
        node* nodee = new node();
        nodee->data = data;
        node* tmp;
        tmp = head;
        int cnt = 2;
        while (cnt != number)
        {
            tmp = tmp->next;
            cnt++;
        }
        tmp->next->prev = nodee;
        nodee->next = tmp->next;
        tmp->next = nodee;
        nodee->prev = tmp;
        counter++;
    }

    void list::deletenode_number(int number)
    {
        node* tmp;
        tmp = head;
        int cnt = 2;
        while (cnt != number)
        {
            tmp = tmp->next;
            cnt++;
        }
        node* tmp2 = tmp->next->next;
        delete tmp->next;
        tmp->next = tmp2;
        tmp->next->prev = tmp;
        counter--;
    }

    void list::printlist()
    {
        node* current = head;
        while (current != nullptr)
        {
            std::cout << current->data << std::endl;
            current = current->next;
        }
    }