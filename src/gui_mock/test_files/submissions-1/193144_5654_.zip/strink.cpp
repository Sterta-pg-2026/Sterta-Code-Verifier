#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "strink.h"

using namespace std;

strink::strink()
{
	char* data = new char[1];
	*data = '\0';
	size = 0;
}

strink::strink(const strink& other)
{
	size = other.size;
	data = new char[size + 1];
	strcpy(data, other.data);
}

ostream& operator<<(ostream& os, const strink& str)
{
	os << str.data;
	return os;
}

istream& operator>>(istream& is, strink& str)
{
	char buffer[4096];
	is.getline(buffer, 4096);
	str = buffer;
	return is;
}

bool strink::operator==(const strink& other) const
{
	return strcmp(data, other.data) == 0;
}

bool strink::operator!=(const strink& other) const
{
	return strcmp(data, other.data) != 0;
}

char& strink::operator[](int index)
{
	return data[index];
}

strink& strink::operator=(const strink& other)
{
	size = other.size;
	data = new char[size];
	int a = 0;
	for (a = 0; a < size; ++a)
	{
		data[a] = other.data[a];
	}
	data[a] = '\0';
	return *this;
}

strink::strink(const char* str)
{
	size = 0;
	while (str[size] != '\0') {
		++size;
	}
	data = new char[size];
	int i = 0;
	for (i = 0; i < size; ++i) {
		data[i] = str[i];
	}
	data[i] = '\0';
}