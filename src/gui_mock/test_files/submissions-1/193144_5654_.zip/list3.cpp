#include <iostream>
#include "strink.h"
#include "list.h"
#include "list2.h"
#include "list3.h"

    list3::list3()
    {
        node3* head = nullptr;
        node3* tail = nullptr;
        counter = 0;
    }

    void list3::addnode_tail()
    {
        node3* nodee = new node3();
        nodee->next = nullptr;
        nodee->prev = nullptr;
        if (head == nullptr)
        {
            head = nodee;
            tail = nodee;
            tmp = tail;
        }
        else
        {
            tail->next = nodee;
            nodee->prev = tail;
            tail = nodee;
            tmp = tail;
        }
        counter++;
    }

    void list3::deletenode_number(int number)
    {
        int cnt = 1;
        node3* current = head;
        while (current != nullptr)
        {
            if (cnt == number)
            {
                if (current == head)
                {
                    head = current->next;
                }
                else
                {
                    current->prev->next = current->next;
                }
                if (current == tail)
                {
                    tail = current->prev;
                }
                else
                {
                    current->next->prev = current->prev;
                }
                delete current;
                counter--;
                return;
            }
            number--;
            current = current->next;
        }
    }