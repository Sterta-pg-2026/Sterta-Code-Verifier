#pragma once
#include <iostream>
#include "strink.h"

struct node
{
    strink data;
    node* next = nullptr;
    node* prev = nullptr;
};

class list
{
public:
    node* tmp;
    node* head;
    node* tail;
public:
    int counter = 0;
    list();
    ~list();
    void addnode_tail(strink data);
    void deletenode_tail();
    void addnode_head(strink data);
    void deletenode_head();
    void addnode_number(strink data, int number);
    void deletenode_number(int number);
    void printlist();
};
