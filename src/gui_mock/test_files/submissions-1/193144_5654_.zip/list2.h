#pragma once
#include <iostream>
#include "strink.h"

struct node2
{
    strink atrybut;
    strink wartosc;
    node2* next = nullptr;
    node2* prev = nullptr;
};

class list2
{
public:
    node2* tmp;
    node2* head;
    node2* tail;
public:
    int counter = 0;
    list2();
    ~list2();
    void addnode_tail(strink atrybut, strink wartosc);
    void deletenode_tail();
    void addnode_head(strink atrybut, strink wartosc);
    void deletenode_head();
    void addnode_number(strink atrybut, strink wartosc, int number);
    void deletenode_number(int number);
    void printnode(int number);
    void printlist();
};