#include <iostream>
#include "strink.h"
#include "list2.h"

    list2::list2()
    {
        head = nullptr;
        tail = nullptr;
        counter = 0;
    }

    list2::~list2()
    {
        node2* current = head;
        counter = 0;
        while (current != nullptr)
        {
            node2* tmp = current;
            current = current->next;
            delete tmp;
        }
    }

    void list2::addnode_tail(strink atrybut, strink wartosc)
    {
        if (head != nullptr)
        {
            node2* temp = head;
            while (1)
            {
                if (atrybut == temp->atrybut)
                {
                    temp->wartosc = wartosc;
                    return;
                }
                if (temp->next == nullptr)
                {
                    break;
                }
                temp = temp->next;
            }
        }
        node2* nodee2 = new node2();
        nodee2->atrybut = atrybut;
        nodee2->wartosc = wartosc;
        nodee2->next = nullptr;
        nodee2->prev = nullptr;
        counter++;
        if (head == nullptr)
        {
            head = nodee2;
            head->next = tail;
        }
        else if (tail == nullptr)
        {
            tail = nodee2;
            head->next = tail;
        }
        else
        {
            tail->next = nodee2;
            nodee2->prev = tail;
            tail = nodee2;
        }
    }

    void list2::deletenode_tail()
    {
        node2* tmp;
        tmp = head;
        if (head == nullptr)
        {
            return;
        }
        while (tmp->next->next != nullptr)
        {
            tmp = tmp->next;
        }
        delete tmp->next;
        tail = tmp;
        tmp->next = nullptr;
        counter--;
    }

    void list2::addnode_head(strink atrybut, strink wartosc)
    {
        node2* nodee2 = new node2();
        nodee2->atrybut = atrybut;
        nodee2->wartosc = wartosc;
        nodee2->next = head;
        nodee2->prev = nullptr;
        head = nodee2;
        head->next->prev = head;
        counter++;
    }

    void list2::deletenode_head()
    {
        node2* tmp;
        tmp = head;
        if (head == nullptr)
        {
            return;
        }
        head = tmp->next;
        head->prev = nullptr;
        delete tmp;
        counter--;
    }

    void list2::addnode_number(strink atrybut, strink wartosc, int number)
    {
        if (head == nullptr)
        {
            addnode_head(atrybut, wartosc);
        }
        node2* nodee2 = new node2();
        nodee2->atrybut = atrybut;
        nodee2->wartosc = wartosc;
        node2* tmp;
        tmp = head;
        int cnt = 2;
        while (cnt != number)
        {
            tmp = tmp->next;
            cnt++;
        }
        tmp->next->prev = nodee2;
        nodee2->next = tmp->next;
        tmp->next = nodee2;
        nodee2->prev = tmp;
        counter++;
    }

    void list2::deletenode_number(int number)
    {
        int cnt = 1;
        node2* current = head;
        while (current != nullptr)
        {
            if (cnt == number)
            {
                if (current == head)
                {
                    if (head->next == nullptr)
                    {
                        head = nullptr;
                        tail = nullptr;
                        counter--;
                        return;
                    }
                    head = current->next;
                }
                else
                {
                    current->prev->next = current->next;
                }
                if (current == tail)
                {
                    tail = current->prev;
                }
                else
                {
                    current->next->prev = current->prev;
                }
                delete current;
                counter--;
                return;
            }
            number--;
            current = current->next;
        }
    }

    void list2::printnode(int number)
    {
        node2* tmp;
        tmp = head;
        int cnt = 2;
        while (cnt != number)
        {
            tmp = tmp->next;
            cnt++;
        }
        std::cout << tmp->atrybut;
    }

    void list2::printlist()
    {
        node2* current = head;
        while (current != nullptr)
        {
            std::cout << current->atrybut << std::endl;
            std::cout << current->wartosc << std::endl;
            current = current->next;
        }
    }