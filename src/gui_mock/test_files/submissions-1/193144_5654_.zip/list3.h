#pragma once
#include <iostream>
#include "strink.h"
#include "list2.h"
#include "list3.h"

struct node3
{
    list sel;
    list2 att_val;
    node3* next = nullptr;
    node3* prev = nullptr;
};

class list3
{
public:
    node3* head = nullptr;
    node3* tail = nullptr;
    node3* tmp = tail;
public:
    int counter = 0;
    list3();
    void addnode_tail();
    void deletenode_number(int number);
};
