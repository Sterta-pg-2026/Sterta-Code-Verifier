#pragma once
#include <cstring>
#include <ostream>

class String {
    char* charArray = nullptr;
    int length = 0;
    int capacity = 0;

    friend bool operator==(const String& left, const String& right);
    friend bool operator==(const String& left, const char* right);
    friend std::ostream& operator<<(std::ostream& os, const String& str);

  public:
    String() = default;
    String(const String& other);
    explicit String(const char* chars);

    String& operator=(const String& right);
    String& operator=(const char* right);
    String& operator+=(char right);

    void trim();
    int toNumber() const;
    bool isNumeric() const;

    int getLength() const;
    const char* getChars() const;

    ~String();
};
