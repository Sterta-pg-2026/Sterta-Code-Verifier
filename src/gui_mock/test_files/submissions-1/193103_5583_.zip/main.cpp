#include "main.hpp"
using namespace std;

int main() {
    ParsingMode mode = ParsingMode::SELECTOR;
    List<CSSRule> stylesheet;
    IteratorStore iteratorStore;

    char ch;
    while (cin >> noskipws >> ch) {
        switch (mode) {
        case ParsingMode::SELECTOR:
            parseSelector(ch, stylesheet, mode, iteratorStore);
            break;
        case ParsingMode::ATTRIBUTE_NAME:
            parseAttributeName(ch, mode, iteratorStore);
            break;
        case ParsingMode::ATTRIBUTE_VALUE:
            parseAttributeValue(ch, mode, iteratorStore);
            break;
        case ParsingMode::COMMAND:
            parseCommand(ch, stylesheet, mode, iteratorStore);
            break;
        }
    }
}