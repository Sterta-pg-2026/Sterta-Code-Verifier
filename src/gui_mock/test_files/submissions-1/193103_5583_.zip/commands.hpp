#pragma once
#include "csstypes.hpp"
#include "list.hpp"
#include "mystring.hpp"
#include "parse.hpp"

void ruleCount(List<CSSRule>& stylesheet);
void selectorCountInRule(List<CSSRule>& stylesheet, int ruleIndex);
void attributeCountInRule(List<CSSRule>& stylesheet, int ruleIndex);
void selectorInRule(List<CSSRule>& stylesheet, int ruleIndex,
                    int selectorIndex);
void attributeValueInRule(List<CSSRule>& stylesheet, int ruleIndex,
                          const String& attributeName);
void attributeCountInStylesheet(List<CSSRule>& stylesheet,
                                const String& attributeName);
void selectorCountInStylesheet(List<CSSRule>& stylesheet, const String& selectorName);
void attributeValueForSelector(List<CSSRule>& stylesheet, const String& selectorName,
                               const String& attributeName);
void deleteRule(List<CSSRule>& stylesheet, int ruleIndex);
void deleteAttributeInRule(List<CSSRule>& stylesheet, int ruleIndex,
                           const String& attributeName);
