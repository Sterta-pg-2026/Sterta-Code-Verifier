#pragma once
#include "csstypes.hpp"
#include "list.hpp"
#include "mystring.hpp"
#include <iostream>

enum class ParsingMode { SELECTOR, ATTRIBUTE_NAME, ATTRIBUTE_VALUE, COMMAND };

struct IteratorStore {
    CSSRule* rule = nullptr;
    String* selector = nullptr;
    Attribute* attribute = nullptr;
};

void parseSelector(char ch, List<CSSRule>& stylesheet, ParsingMode& mode,
                   IteratorStore& iteratorStore);

void parseAttributeName(char ch, ParsingMode& mode,
                        IteratorStore& iteratorStore);

void parseAttributeValue(char ch, ParsingMode& mode,
                         IteratorStore& iteratorStore);

void parseCommand(char ch, List<CSSRule>& stylesheet, ParsingMode& mode,
                  IteratorStore& iteratorStore);
