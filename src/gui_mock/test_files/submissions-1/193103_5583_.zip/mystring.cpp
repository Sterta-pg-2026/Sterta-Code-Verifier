#include "mystring.hpp"
#include <stdexcept>
#include <iostream>
using namespace std;

String::String(const char* chars) {
    if (chars == nullptr) {
        return;
    }

    int sizeWithoutNullChar = strlen(chars);
    length = sizeWithoutNullChar + 1;
    capacity = sizeWithoutNullChar + 1;
    charArray = new char[capacity];
    if (strlen(chars) == 0) {
        charArray[0] = '\0';
        return;
    }

    strcpy(charArray, chars);
    charArray[length - 1] = '\0';
}

String::String(const String& other) : length(other.length), capacity(other.length) {
    if (other.charArray == nullptr) {
        charArray = nullptr;
    } else {
        charArray = new char[capacity];
        strcpy(charArray, other.charArray);
        charArray[length - 1] = '\0';
    }
}

String& String::operator=(const String& right) {
    if (&right == this) return *this;

    delete[] charArray;
    charArray = nullptr;

    if (right.charArray == nullptr) {
        charArray = nullptr;
        length = 0;
        capacity = 0;
        return *this;
    }

    int sizeWithoutNullChar = right.getLength();
    length = sizeWithoutNullChar + 1;
    capacity = sizeWithoutNullChar + 1;
    charArray = new char[capacity];
    strcpy(charArray, right.charArray);
    charArray[length - 1] = '\0';

    return *this;
}

String& String::operator=(const char* right) {
    if (right == nullptr) {
        delete[] charArray;
        charArray = nullptr;
        length = 0;
        capacity = 0;
        return *this;
    }

    int sizeWithoutNullChar = strlen(right);
    length = sizeWithoutNullChar + 1;
    if (capacity < length) {
        capacity = length;
        delete[] charArray;
        charArray = new char[capacity];
    }
    strcpy(charArray, right);
    charArray[length - 1] = '\0';

    return *this;
}

String& String::operator+=(char right) {
    if (charArray == nullptr) {
        length = 1;
        capacity = 2;
        charArray = new char[capacity];
    }

    length++;
    if (capacity < length) {
        while (capacity < length) {
            capacity = capacity * 2;
        }
        char* tmpChars = new char[capacity];
        strcpy(tmpChars, charArray);
        delete[] charArray;
        charArray = tmpChars;
    }

    charArray[length - 2] = right;
    charArray[length - 1] = '\0';
    return *this;
}

bool operator==(const String& left, const String& right) {
    const char* leftChars = left.getChars();
    const char* rightChars = right.getChars();
    if (leftChars == nullptr && rightChars == nullptr) return true;
    else if (leftChars == nullptr || rightChars == nullptr) return false;

    return strcmp(left.getChars(), right.getChars()) == 0;
}

void String::trim() {
    if (charArray == nullptr)
        return;

    int whitespaceLeft = 0;
    for (int i = 0; i < length; i++) {
        if (charArray[i] != ' ')
            break;
        whitespaceLeft++;
    }
    int whitespaceRight = 0;
    for (int i = length - 2; i >= 0; i--) {
        if (charArray[i] != ' ')
            break;
        whitespaceRight++;
    }

    charArray[length - 1 - whitespaceRight] = '\0';
    length = length - whitespaceLeft - whitespaceRight;
    capacity = length;
    char* tmpChars = new char[capacity];
    strcpy(tmpChars, charArray + whitespaceLeft);
    delete[] charArray;
    charArray = tmpChars;
}

int String::toNumber() const {
    int result = 0;
    int factor = 1;
    for (int i = length - 2; i >= 0; i--) {
        if (charArray[i] < '0' || charArray[i] > '9')
            throw invalid_argument("String to number conversion failed");
        int digit = charArray[i] - 48;
        result += factor * digit;
        factor *= 10;
    }

    return result;
}

bool String::isNumeric() const {
    bool result = true;
    if (length > 10) return false;

    for (int i = 0; i < length - 1; i++) {
        if (charArray[i] < '0' || charArray[i] > '9') {
            result = false;
            break;
        }
    }

    // check for zero, because command indexes start at 1
    if (charArray[0] == '0') result = false;

    return result;
}

int String::getLength() const {
    // omit the null char
    return length - 1;
}

const char* String::getChars() const { return charArray; }

std::ostream& operator<<(std::ostream& os, const String& str) {
    os << str.charArray;
    return os;
}

String::~String() {
    delete[] charArray;
    charArray = nullptr;
}
bool operator==(const String& left, const char* right) {
    if (left.getChars() == nullptr && right == nullptr) return true;
    else if (left.getChars() == nullptr || right == nullptr) return false;

    return strcmp(left.getChars(), right) == 0;
}
