#include "csstypes.hpp"

bool operator==(const Attribute& left, const Attribute& right) {
    return left.name == right.name;
}

std::ostream& operator<<(std::ostream& os, const CSSRule& rule) {
    size_t i = 0;
    for (const String& selector : rule.selectors) {
        os << selector;
        if (i < rule.selectors.getLength() - 1)
            os << ", ";
        i++;
    }

    os << " {\n";
    for (const Attribute& attribute : rule.attributes) {
        os << " " << attribute.name << ": " << attribute.value << ";\n";
    }
    os << "}";

    return os;
}
