#pragma once
#include "mystring.hpp"
#include <iostream>
#include <stdexcept>

const int LIST_ARRAY_SIZE = 4;

template <typename T> class List {
    struct Node {
        T values[LIST_ARRAY_SIZE];
        bool used[LIST_ARRAY_SIZE]{};
        int usedCount = 0;
        int lastUsedIndex = -1;
        Node* next = nullptr;
        Node* prev = nullptr;
    };

    int length = 0;
    Node* head = nullptr;
    Node* tail = nullptr;

  public:
    [[nodiscard]] int getLength() const { return length; }

    T* add(const T& newValue) {
        length++;
        if (head == nullptr) {
            Node* newNode = new Node();
            head = newNode;
            tail = newNode;
        }

        // Node* currentNode = tail;
        // int freeIndex;
        // for (freeIndex = LIST_ARRAY_SIZE - 1; freeIndex >= 0; freeIndex--) {
        //     if (currentNode->used[freeIndex])
        //         break;
        // }
        // if (freeIndex != LIST_ARRAY_SIZE - 1) {
        //     freeIndex++;
        // } else {
        //     Node* newTail = new Node();
        //     newTail->prev = tail;
        //     tail->next = newTail;
        //     currentNode = newTail;
        //     tail = newTail;
        //     freeIndex = 0;
        // }
        Node* currentNode = tail;
        int freeIndex;
        if (currentNode->lastUsedIndex != LIST_ARRAY_SIZE - 1)
            freeIndex = currentNode->lastUsedIndex + 1;
        else {
            Node* newTail = new Node();
            newTail->prev = tail;
            tail->next = newTail;
            currentNode = newTail;
            tail = newTail;
            freeIndex = 0;
        }

        currentNode->usedCount++;
        currentNode->used[freeIndex] = true;
        currentNode->values[freeIndex] = newValue;
        currentNode->lastUsedIndex = freeIndex;
        return &(currentNode->values[freeIndex]);
    }

    void deleteAtIndex(int index) {
        if (index >= length || index < 0) {
            throw std::length_error("index out of bounds del");
        }

        Node* currentNode = head;
        int lengthLeft = index + 1;

        while (lengthLeft - 1 >= currentNode->usedCount &&
               currentNode != nullptr) {
            lengthLeft -= currentNode->usedCount;
            currentNode = currentNode->next;
        }

        int i = 0;
        for (i = 0; i < LIST_ARRAY_SIZE; i++) {
            if (currentNode->used[i]) {
                lengthLeft--;
            }

            if (lengthLeft <= 0)
                break;
        }

        currentNode->usedCount--;
        currentNode->used[i] = false;
        currentNode->values[i] = T();
        length--;

        // remove nodes if vacant
        if (currentNode->usedCount == 0) {
            if (currentNode == head) {
                if (currentNode == tail) {
                    head = nullptr;
                    tail = nullptr;
                    delete currentNode;
                } else {
                    head = head->next;
                    head->prev = nullptr;
                    delete currentNode;
                }
            } else if (currentNode == tail) {
                tail = tail->prev;
                tail->next = nullptr;
                delete currentNode;
            } else {
                currentNode->prev->next = currentNode->next;
                currentNode->next->prev = currentNode->prev;
                delete currentNode;
            }
        }
    }

    T& operator[](int index) {
        if (index >= length || index < 0 || head == nullptr) {
            throw std::length_error("index out of bounds");
        }

        Node* currentNode = head;
        int lengthLeft = index + 1;

        while (lengthLeft - 1 >= currentNode->usedCount &&
               currentNode != nullptr) {
            lengthLeft -= currentNode->usedCount;
            currentNode = currentNode->next;
        }

        int i = 0;
        for (i = 0; i < LIST_ARRAY_SIZE; i++) {
            if (currentNode->used[i]) {
                lengthLeft--;
            }

            if (lengthLeft <= 0)
                break;
        }

        return currentNode->values[i];
    }

    const T& operator[](int index) const {
        if (index >= length || index < 0 || head == nullptr) {
            throw std::length_error("index out of bounds");
        }

        Node* currentNode = head;
        int lengthLeft = index + 1;

        while (lengthLeft - 1 >= currentNode->usedCount &&
               currentNode != nullptr) {
            lengthLeft -= currentNode->usedCount;
            currentNode = currentNode->next;
        }

        int i = 0;
        for (i = 0; i < LIST_ARRAY_SIZE; i++) {
            if (currentNode->used[i]) {
                lengthLeft--;
            }

            if (lengthLeft <= 0)
                break;
        }

        return currentNode->values[i];
    }

    void removeDuplicates() {
        bool* toBeRemoved = new bool[length];
        for (int i = 0; i < length; i++)
            toBeRemoved[i] = false;

        for (int i = length - 1; i >= 0; i--) {
            if (toBeRemoved[i])
                continue;
            for (int j = 0; j < length; j++) {
                if (i == j)
                    continue;
                if ((*this)[i] == (*this)[j]) {
                    toBeRemoved[j] = true;
                }
            }
        }

        int elementCount = length;
        int removed = 0;
        for (int i = 0; i < elementCount; i++) {
            if (toBeRemoved[i]) {
                deleteAtIndex(i - removed);
                removed++;
            }
        }

        delete[] toBeRemoved;
    }

    class Iterator {
      public:
        Iterator(Node* currentNode, int index)
            : currentNode(currentNode), currentIndex(index) {}
        T& operator*() { return currentNode->values[currentIndex]; }
        Iterator& operator++() {
            int index;
            for (index = currentIndex + 1; index < LIST_ARRAY_SIZE; index++) {
                if (currentNode->used[index])
                    break;
            }
            if (index < LIST_ARRAY_SIZE) {
                currentIndex = index;
            } else {
                currentNode = currentNode->next;
                currentIndex = 0;
                if (currentNode == nullptr)
                    return *this;

                int nextIndex;
                for (nextIndex = 0; nextIndex < LIST_ARRAY_SIZE; nextIndex++) {
                    if (currentNode->used[nextIndex])
                        break;
                }
                currentIndex = nextIndex;
            }

            return *this;
        }
        bool operator!=(const Iterator& other) {
            return currentNode != other.currentNode ||
                   currentIndex != other.currentIndex;
        }

      private:
        Node* currentNode;
        int currentIndex = 0;
    };

    Iterator begin() const {
        if (head == nullptr) {
            return Iterator(nullptr, 0);
        }

        int index;
        for (index = 0; index < LIST_ARRAY_SIZE; index++) {
            if (head->used[index])
                break;
        }
        return Iterator(head, index);
    }

    Iterator end() const { return Iterator(nullptr, 0); }

    ~List() {
        if (head == nullptr)
            return;

        Node* currentNode = head;
        while (currentNode != nullptr) {
            Node* tmp = currentNode;
            currentNode = currentNode->next;
            delete tmp;
        }
    }
};