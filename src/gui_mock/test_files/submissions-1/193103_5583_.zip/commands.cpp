#include "commands.hpp"
#include <iostream>
using namespace std;

void ruleCount(List<CSSRule>& stylesheet) {

    cout << "? == " << stylesheet.getLength() << endl;
}
void selectorCountInRule(List<CSSRule>& stylesheet, int ruleIndex) {
    if (ruleIndex >= stylesheet.getLength())
        return;
    cout << ruleIndex + 1
         << ",S,? == " << stylesheet[ruleIndex].selectors.getLength() << endl;
}
void attributeCountInRule(List<CSSRule>& stylesheet, int ruleIndex) {
    if (ruleIndex >= stylesheet.getLength())
        return;
    cout << ruleIndex + 1
         << ",A,? == " << stylesheet[ruleIndex].attributes.getLength() << endl;
}
void selectorInRule(List<CSSRule>& stylesheet, int ruleIndex,
                    int selectorIndex) {
    if (ruleIndex >= stylesheet.getLength())
        return;
    const CSSRule& rule = stylesheet[ruleIndex];
    if (selectorIndex >= rule.selectors.getLength())
        return;

    cout << ruleIndex + 1 << ",S," << selectorIndex + 1
         << " == " << rule.selectors[selectorIndex] << endl;
}
void attributeValueInRule(List<CSSRule>& stylesheet, int ruleIndex,
                          const String& attributeName) {
    if (ruleIndex >= stylesheet.getLength())
        return;

    for (const Attribute& attribute : stylesheet[ruleIndex].attributes) {
        if (attribute.name == attributeName) {
            cout << ruleIndex + 1 << ",A," << attributeName
                 << " == " << attribute.value << endl;
            break;
        }
    }
}
void attributeCountInStylesheet(List<CSSRule>& stylesheet,
                                const String& attributeName) {
    int count = 0;
    for (const CSSRule& rule : stylesheet) {
        for (const Attribute& attribute : rule.attributes) {
            if (attribute.name == attributeName) {
                count++;
                break;
            }
        }
    }

    cout << attributeName << ",A,? == " << count << endl;
}
void selectorCountInStylesheet(List<CSSRule>& stylesheet,
                               const String& selectorName) {
    int count = 0;
    for (const CSSRule& rule : stylesheet) {
        for (const String& selector : rule.selectors) {
            if (selector == selectorName)
                count++;
        }
    }

    cout << selectorName << ",S,? == " << count << endl;
}
void attributeValueForSelector(List<CSSRule>& stylesheet,
                               const String& selectorName,
                               const String& attributeName) {
    String value("");
    for (const CSSRule& rule : stylesheet) {
        bool containsSelector = false;
        for (const String& selector : rule.selectors) {
            if (selector == selectorName) {
                containsSelector = true;
                break;
            }
        }

        if (!containsSelector)
            continue;
        for (const Attribute& attribute : rule.attributes) {
            if (attribute.name == attributeName) {
                value = attribute.value;
            }
        }
    }

    if (!(value == "")) {
        cout << selectorName << ",E," << attributeName << " == " << value
             << endl;
    }
}
void deleteRule(List<CSSRule>& stylesheet, int ruleIndex) {
    if (ruleIndex >= stylesheet.getLength())
        return;

    stylesheet.deleteAtIndex(ruleIndex);
    cout << ruleIndex + 1 << ",D,* == deleted" << endl;
}
void deleteAttributeInRule(List<CSSRule>& stylesheet, int ruleIndex,
                           const String& attributeName) {
    if (ruleIndex >= stylesheet.getLength())
        return;
    CSSRule& rule = stylesheet[ruleIndex];

    bool deleted = false;
    int i = 0;
    for (const Attribute& attribute : rule.attributes) {
        if (attribute.name == attributeName) {
            rule.attributes.deleteAtIndex(i);
            deleted = true;
            break;
        }
        i++;
    }
    if (rule.attributes.getLength() == 0) {
        stylesheet.deleteAtIndex(ruleIndex);
    }

    if (deleted)
        cout << ruleIndex + 1 << ",D," << attributeName << " == deleted"
             << endl;
}
