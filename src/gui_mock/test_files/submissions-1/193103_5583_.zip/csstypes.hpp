#pragma once
#include "list.hpp"
#include "mystring.hpp"
#include <iostream>

struct Attribute {
    String name;
    String value;
};
bool operator==(const Attribute& left, const Attribute& right);

struct CSSRule {
    List<String> selectors;
    List<Attribute> attributes;
};
std::ostream& operator<<(std::ostream& os, const CSSRule& rule);
