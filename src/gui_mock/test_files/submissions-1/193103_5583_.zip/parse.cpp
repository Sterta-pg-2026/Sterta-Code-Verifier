#include "parse.hpp"
#include "commands.hpp"
using namespace std;

void parseSelector(char ch, List<CSSRule>& stylesheet, ParsingMode& mode,
                   IteratorStore& iteratorStore) {
    static bool startedParsingRule = false;
    static bool parsingSelector = false;
    static unsigned int commandCharCount = 0;

    bool isCharPartOfAName = ch >= ' ' && ch <= '~' && ch != ',' && ch != '{' && ch != '?';

    if (!startedParsingRule && (isCharPartOfAName || ch == '{')) {
        iteratorStore.rule = stylesheet.add({});
        startedParsingRule = true;
    }

    if (!parsingSelector && isCharPartOfAName) {
        iteratorStore.selector = iteratorStore.rule->selectors.add(String(""));
        parsingSelector = true;
    }

    if (isCharPartOfAName) {
        (*iteratorStore.selector) += ch;
    } else if (ch == ',') {
        iteratorStore.selector->trim();
        parsingSelector = false;
    } else if (ch == '{') {
        if (iteratorStore.rule->selectors.getLength() > 0) {
            iteratorStore.selector->trim();
            iteratorStore.rule->selectors.removeDuplicates();
        }
        parsingSelector = false;
        startedParsingRule = false;
        commandCharCount = 0;
        mode = ParsingMode::ATTRIBUTE_NAME;
    } else if (ch == '?') {
        commandCharCount++;
        if (commandCharCount == 4) {
            startedParsingRule = false;
            parsingSelector = false;
            commandCharCount = 0;
            mode = ParsingMode::COMMAND;
        }
    }
}

void parseAttributeName(char ch, ParsingMode& mode,
                        IteratorStore& iteratorStore) {
    static bool startedParsing = false;
    bool isCharPartOfAName =
        ch == '-' || (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z');

    if (!startedParsing && isCharPartOfAName) {
        iteratorStore.attribute = iteratorStore.rule->attributes.add({});
        startedParsing = true;
    }

    if (isCharPartOfAName) {
        iteratorStore.attribute->name += ch;
    } else if (ch == ':') {
        startedParsing = false;
        mode = ParsingMode::ATTRIBUTE_VALUE;
    } else if (ch == '}') {
        startedParsing = false;
        iteratorStore.rule->attributes.removeDuplicates();
        iteratorStore.attribute = nullptr;
        iteratorStore.selector = nullptr;
        mode = ParsingMode::SELECTOR;
    }
}

void parseAttributeValue(char ch, ParsingMode& mode,
                         IteratorStore& iteratorStore) {
    if (ch != '\n' && ch != ';' && ch != '}') {
        iteratorStore.attribute->value += ch;
    } else if (ch == ';') {
        iteratorStore.attribute->value.trim();
        mode = ParsingMode::ATTRIBUTE_NAME;
    } else if (ch == '}') {
        iteratorStore.attribute->value.trim();
        (*iteratorStore.rule).attributes.removeDuplicates();
        iteratorStore.attribute = nullptr;
        iteratorStore.selector = nullptr;
        mode = ParsingMode::SELECTOR;
    }
}

void parseCommand(char ch, List<CSSRule>& stylesheet, ParsingMode& mode,
                  IteratorStore& iteratorStore) {
    static unsigned int selectorCharCount = 0;
    static String arguments[3];
    static int argumentIndex = 0;

    if (ch == '*' && argumentIndex == 0) {
        selectorCharCount++;
        if (selectorCharCount == 4) {
            selectorCharCount = 0;
            mode = ParsingMode::SELECTOR;
        }
        return;
    }

    if (ch == ',') {
        argumentIndex++;
        return;
    }

    if ((ch == '\n' && argumentIndex == 2)) {
        argumentIndex++;
    }

    if (argumentIndex == 0 && ch == '?') {
        ruleCount(stylesheet);
        return;
    }

    if (argumentIndex <= 2 && ch != '\n') {
        arguments[argumentIndex] += ch;
        return;
    }

    if (argumentIndex == 3) {
        argumentIndex = 0;
        arguments[0].trim();
        arguments[1].trim();
        arguments[2].trim();

        // clang-format off
        if (
            arguments[0].isNumeric() &&
            arguments[1] == "S" &&
            arguments[2] == "?"
        )
            selectorCountInRule(stylesheet, arguments[0].toNumber() - 1);
        else if (
            arguments[0].isNumeric() &&
            arguments[1] == "A" &&
            arguments[2] == "?"
        )
            attributeCountInRule(stylesheet, arguments[0].toNumber() - 1);
        else if (
            arguments[0].isNumeric() &&
            arguments[1] == "S" &&
            arguments[2].isNumeric()
        )
            selectorInRule(stylesheet, arguments[0].toNumber() - 1, arguments[2].toNumber() - 1);
        else if (
            arguments[0].isNumeric() &&
            arguments[1] == "A"
        )
            attributeValueInRule(stylesheet, arguments[0].toNumber() - 1, arguments[2]);
        else if (
            arguments[1] == "A" &&
            arguments[2] == "?"
        )
            attributeCountInStylesheet(stylesheet, arguments[0]);
        else if (
            arguments[1] == "S" &&
            arguments[2] == "?"
        )
            selectorCountInStylesheet(stylesheet, arguments[0]);
        else if (
            arguments[1] == "E"
        )
            attributeValueForSelector(stylesheet, arguments[0], arguments[2]);
        else if (
            arguments[1] == "D" &&
            arguments[2] == "*"
        )
            deleteRule(stylesheet, arguments[0].toNumber() - 1);
        else if (
            arguments[1] == "D"
        )
            deleteAttributeInRule(stylesheet, arguments[0].toNumber() - 1, arguments[2]);
        // clang-format on

        arguments[0] = "";
        arguments[1] = "";
        arguments[2] = "";
    }
}
