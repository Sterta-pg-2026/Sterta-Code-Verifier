#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <stdio.h>


#define CSS_READ 0
#define CMD_READ 1
#define ROZMIAR_LINII 128
#define MNOZNIK_BUFORA 3096
#define CZYTAJ_SELEKTOR 0
#define CZYTAJ_ATRYBUT 1
#define CZYTAJ_ATRYBUT_W 2

using namespace std;


template <typename T>
class lista
{
    struct node
    {
        char* key;
        T data;
        node* prev;
        node* next;
        node(T t, node* p, node* n) : data(t), prev(p), next(n) {
            key = new char[ROZMIAR_LINII];
        }
    };
    node* head;
    node* tail;
public:
    int count = 0;

    lista() : head(NULL), tail(NULL) {}

    bool empty() const { return (!head || !tail); }
    operator bool() const { return !empty(); }
    void push_back(T, char *key);
    void push_front(T, char* key);
    T* get_element(int index);
    T* get_element(char* key);
    T* get_tail();
    T pop_back();
    T pop_front();
    bool pop(int index);
    bool pop(char *key);

    ~lista()
    {
        while (head)
        {
            node* temp(head);
            head = head->next;
            delete temp;
        }
    }

    
};

template <typename T>
void lista<T>::push_back(T data, char* key)
{
    tail = new node(data, tail, NULL);
    tail->key = key;
    count++;
    if (tail->prev)
        tail->prev->next = tail;

    if (empty())
        head = tail;
}

template <typename T>
void lista<T>::push_front(T data, char* key)
{
    head = new node(data, NULL, head);
    head->key = key;
    count++;
    if (head->next)
        head->next->prev = head;

    if (empty())
        tail = head;
}

template<typename T>
T lista<T>::pop_back()
{
    if (empty())
        throw("lista : lista pusta");
    node* temp(tail);
    T data(tail->data);
    tail = tail->prev;

    if (tail)
        tail->next = NULL;
    else
        head = NULL;

    delete temp;
    count--;
    return data;
}

template<typename T>
T lista<T>::pop_front()
{
    if (empty())
        throw("lista : lista pusta");
    node* temp(head);
    T data(head->data);
    head = head->next;

    if (head)
        head->prev = NULL;
    else
        tail = NULL;

    delete temp;
    count--;
    return data;
}

template<typename T>
T* lista<T>::get_element(int index)
{
    if (index > count || index <= 0) {
        //throw("lista : indeks poza zakresem");        
        return NULL;
    }
    if (empty())
        //throw("lista : lista pusta");
        return NULL;
    
    node* current = head;
    node* current2 = tail;

    int fi = 1;
    int li = count;

    while (fi <= li) {
        if (fi == index)
        {
            T* data(&current->data);
            return data;
        }
        if (li == index)
        {
            T* data(&current2->data);
            return data;
        }
        fi++;
        li--;
        
        current = current->next;
        current2 = current2->prev;
    }

    return NULL;
}

template<typename T>
T* lista<T>::get_tail()
{
    if (empty())
        //throw("lista : lista pusta");
        return NULL;

    node* current = tail;
    T* data(&current->data);
    return data;
}

template<typename T>
T* lista<T>::get_element(char* key)
{
    if (empty())
        //throw("lista : lista pusta");
        return NULL;
    node* current = head;
    node* current2 = tail;

    int fi = 0;
    int li = count;

    while (fi <= li) {
        if (strcmp(current->key, key) == 0)
        {
            T* data(&current->data);
            return data;
        }
        if (strcmp(current2->key, key) == 0)
        {
            T* data(&current2->data);
            return data;
        }
        fi++;
        li--;
        
        current = current->next;
        current2 = current2->prev;
    }
    return NULL;
}

template<typename T>
bool lista<T>::pop(int index)
{
    if (index > count || index <= 0) {
        return false;
    }
    if (empty())
        return false;

    if (index == 1)
    {
        pop_front();
        return true;
    }

    if (index == count)
    {
        pop_back();
        return true;
    }

    node* current = head;
    node* current2 = tail;
    int fi = 1;
    int li = count;
    
    while (fi <= li) {
        
        if (fi == index) {
            node* prev = current->prev;
            //    if (prev != NULL)
            prev->next = current->next;
            current->next->prev = prev;
            count--;
            delete current;
            return true;
        }
        else if (li == index) {
            node* nxt = current2->next;
            //    if (prev != NULL)
            nxt->prev = current2->prev;
            current2->prev->next = nxt;
            count--;
            delete current2;
            return true;
        }
        current = current->next;
        current2 = current2->prev;
        fi++;
        li--;
    }

    

    return false;
}
template<typename T>
bool lista<T>::pop(char *key)
{
    if (empty())
        return false;

    if (strcmp(head->key, key) == 0)
    {
        pop_front();
        return true;
    }

    if (strcmp(tail->key, key) == 0)
    {
        pop_back();
        return true;
    }

    node* current = head;

    for (int i = 1; i < count; i++) {
        if (strcmp(current->key, key) == 0)
            break;
        current = current->next;
    }

    if (strcmp(current->key, key) == 0)
    {
        node* prev = current->prev;
        //    if (prev != NULL)
        prev->next = current->next;
        current->next->prev = prev;
        count--;
        delete current;
        return true;
    }
    return false;
}

class wystapienie_elementu
{
public:
//    lista<char*> *wartosci;
    int ilosc_wystapien;

    wystapienie_elementu()
    {
        ilosc_wystapien = 0;
    };
};


class atrybut
{
public:
    char *klucz;
    char *wartosc;
    atrybut()
    {
        klucz = new char[ROZMIAR_LINII];
        wartosc = new char[ROZMIAR_LINII];
        strcpy(klucz, "");
        strcpy(wartosc, "");
    };
};

class sekcja
{
public:
    lista<char*> *lista_selektorow;
    lista<atrybut> *lista_atrybutow;
    sekcja()
    {
        lista_selektorow = new lista<char*>();
        lista_atrybutow = new lista<atrybut>();
    }
};

int readflag = CZYTAJ_SELEKTOR;
sekcja* pewnasekcja; 
atrybut* attr;

void parsuj_bufor(char* bufor, lista<sekcja>* lista_sekcji, lista<wystapienie_elementu> *lwa, lista<wystapienie_elementu> *lws)
{
    char* tmp = new char[ROZMIAR_LINII];
    
    int idx = 0;
    char sekc[] = "sekcja";
    int length = (int)strlen(bufor);
    for (int i = 0; i < length; i++)
    {
        if (bufor[i] == '\t')
            continue;

        if (idx == 0 && bufor[i] <= ' ' && (readflag == CZYTAJ_SELEKTOR || readflag == CZYTAJ_ATRYBUT || readflag == CZYTAJ_ATRYBUT_W))
            continue;

        tmp[idx] = bufor[i];
        idx++;

        switch(bufor[i])
        {
        case '{':
            {
                if (idx > 1 && readflag == CZYTAJ_SELEKTOR)
                {
                    tmp[idx-1] = '\0';
                    for (int jj = idx - 2; jj > 0; jj--)
                    {
                        if (tmp[jj] <= ' ' || tmp[jj] == '\t')
                            tmp[jj] = '\0';
                        else
                        {
                            break;
                        }
                    }
                    char** sel = pewnasekcja->lista_selektorow->get_element(tmp);
                    if (sel == NULL)
                    {
                        pewnasekcja->lista_selektorow->push_back(tmp, tmp);
                        wystapienie_elementu* wyst_sel = lws->get_element(tmp);
                        if (wyst_sel == NULL)
                        {
                            wyst_sel = new wystapienie_elementu();
                            wyst_sel->ilosc_wystapien = 1;
                            lws->push_back(*wyst_sel, tmp);
                        }
                        else
                        {
                            int ilosc_wystapien = wyst_sel->ilosc_wystapien + 1;
                            wyst_sel->ilosc_wystapien = ilosc_wystapien;
                        }
                    }

                    idx = 0;
                    tmp = new char[ROZMIAR_LINII];
                }
                readflag = CZYTAJ_ATRYBUT;
            }
            break;
        case '}':
            {
                if (idx > 1)
                {
                    tmp[idx - 1] = '\0';
                    for (int jj = idx-2; jj > 0; jj--)
                    {
                        if (tmp[jj] <= ' ' || tmp[jj] == '\t')
                            tmp[jj] = '\0';
                        else
                        {
                            break;
                        }
                    }
                    attr->wartosc = tmp;

                    atrybut* tempatrybut = pewnasekcja->lista_atrybutow->get_element(attr->klucz);
                    if (tempatrybut == NULL) {
                        pewnasekcja->lista_atrybutow->push_back(*attr, attr->klucz);
                        wystapienie_elementu* wa = lwa->get_element(attr->klucz);
                        if (wa == NULL)
                        {
                            wa = new wystapienie_elementu();
                            wa->ilosc_wystapien = 1;
                            lwa->push_back(*wa, attr->klucz);
                        }
                        else
                        {
                            wa->ilosc_wystapien++;
                        }
                    }
                    else {
                        tempatrybut->wartosc = attr->wartosc;
                    }
                    attr = new atrybut();
                }
                lista_sekcji->push_back(*pewnasekcja, sekc);
                pewnasekcja = new sekcja();
                readflag = CZYTAJ_SELEKTOR;
                idx = 0;
                tmp = new char[ROZMIAR_LINII];
            }
            break;
        case ',':
            {
                if (readflag == CZYTAJ_SELEKTOR)
                {
                    tmp[idx - 1] = '\0';
                    char** sel = pewnasekcja->lista_selektorow->get_element(tmp);
                    if (sel == NULL)
                    {
                        pewnasekcja->lista_selektorow->push_back(tmp, tmp);
                        wystapienie_elementu *wyst_sel = lws->get_element(tmp);
                        if (wyst_sel == NULL)
                        {
                            wyst_sel = new wystapienie_elementu();
                            wyst_sel->ilosc_wystapien = 1;
                            lws->push_back(*wyst_sel, tmp);
                        }
                        else
                        {
                            int ilosc_wystapien = wyst_sel->ilosc_wystapien + 1;
                            wyst_sel->ilosc_wystapien = ilosc_wystapien;
                        }
                    }
                    idx = 0;
                    tmp = new char[ROZMIAR_LINII];
                }
            }
            break;
        case ':':
            if (readflag == CZYTAJ_ATRYBUT)
            {
                tmp[idx - 1] = '\0';
                attr->klucz = tmp;
                idx = 0;
                tmp = new char[ROZMIAR_LINII];
                readflag = CZYTAJ_ATRYBUT_W;
            }
            break;
        case ';':
            {
                if (readflag == CZYTAJ_ATRYBUT_W)
                {
                    tmp[idx - 1] = '\0';
                    attr->wartosc = tmp;
                    atrybut* tempatrybut = pewnasekcja->lista_atrybutow->get_element(attr->klucz);
                    if (tempatrybut == NULL) {
                        pewnasekcja->lista_atrybutow->push_back(*attr, attr->klucz);
                        wystapienie_elementu* wa = lwa->get_element(attr->klucz);
                        if (wa == NULL)
                        {
                            wa = new wystapienie_elementu();
                            wa->ilosc_wystapien = 1;
                            lwa->push_back(*wa, attr->klucz);
                        }
                        else
                        {
                            wa->ilosc_wystapien++;
                        }
                    }
                    else {
                        tempatrybut->wartosc = attr->wartosc;
                    }
                    attr = new atrybut();
                    idx = 0;
                    tmp = new char[ROZMIAR_LINII];
                    readflag = CZYTAJ_ATRYBUT;
                }
            }
            break;
        }
    }
    
    if (idx > 0)
    {
//        tmp[idx] = '\0';
        switch (readflag)
        {
        case CZYTAJ_ATRYBUT_W:
            {
                tmp[idx] = '\0';
                attr->wartosc = tmp;
                atrybut* tempatrybut = pewnasekcja->lista_atrybutow->get_element(attr->klucz);
                if (tempatrybut == NULL) {
                    pewnasekcja->lista_atrybutow->push_back(*attr, attr->klucz);
                    wystapienie_elementu* wa = lwa->get_element(attr->klucz);
                    if (wa == NULL)
                    {
                        wa = new wystapienie_elementu();
                        wa->ilosc_wystapien = 1;
                        lwa->push_back(*wa, attr->klucz);
                    }
                    else
                    {
                        wa->ilosc_wystapien++;
                    }
                }
                else {
                    tempatrybut->wartosc = attr->wartosc;
                }
                attr = new atrybut();
                idx = 0;
                tmp = new char[ROZMIAR_LINII];
                readflag = CZYTAJ_ATRYBUT;
            }
            break;
        case CZYTAJ_SELEKTOR:
            {
                tmp[idx] = '\0';
                char** sel = pewnasekcja->lista_selektorow->get_element(tmp);
                if (sel == NULL)
                {
                    pewnasekcja->lista_selektorow->push_back(tmp, tmp);
                    wystapienie_elementu* wyst_sel = lws->get_element(tmp);
                    if (wyst_sel == NULL)
                    {
                        wyst_sel = new wystapienie_elementu();
                        wyst_sel->ilosc_wystapien = 1;
                        lws->push_back(*wyst_sel, tmp);
                    }
                    else
                    {
                        int ilosc_wystapien = wyst_sel->ilosc_wystapien + 1;
                        wyst_sel->ilosc_wystapien = ilosc_wystapien;
                    }
                }
                idx = 0;
                tmp = new char[ROZMIAR_LINII];
            }
            break;
        }
    }    
}

int isNumber(char* s) {
    for (int i = 0; i < (int)strlen(s); i++) {
        if (!isdigit(s[i])) {
            return 0;
        }
    }
    return 1;
}

void command_process(char* command, lista<sekcja>* lista_sekcji, lista<wystapienie_elementu>* lwa, lista<wystapienie_elementu>* lws) {
    char cmd[3][ROZMIAR_LINII];
    int p = 0;
    strcpy(cmd[0], "");
    strcpy(cmd[1], "");
    strcpy(cmd[2], "");
    for (int i = 0; i < (int)strlen(command); i++) {
        
        if (command[i] != ',') {
            strncat(cmd[p], &command[i], 1);
        }
        else {
            p++;
        }     
    }
    // Obsługa komend A, S, E, D - szukanie elementu

    switch (cmd[1][0]) {        
        case 'S':
        {
            if (isNumber(cmd[0]) && isNumber(cmd[2]))
            {
                int nrSekcji = atoi(cmd[0]);
                int nrSelektora = atoi(cmd[2]);
                sekcja* s1 = lista_sekcji->get_element(nrSekcji);
                if (s1!= NULL)
                {
                    char** d = s1->lista_selektorow->get_element(nrSelektora);
                    if (d != NULL)
                    {
                        cout << command << " == " << *d << endl;
                    }
                }
            }

            if (isNumber(cmd[0]) && strcmp(cmd[2], "?") == 0)
            {
                int nrSekcji = atoi(cmd[0]);
                sekcja* s1 = lista_sekcji->get_element(nrSekcji);
                if (s1 != NULL)
                {
                    int d = (s1->lista_selektorow)->count;
                    cout << command << " == " << d << endl;
                }
            }
            
            if (!isNumber(cmd[0]))
            {
                int liczbaWystapien = 0;
                wystapienie_elementu*wyst = lws->get_element(cmd[0]);
                if (wyst != NULL)
                    liczbaWystapien = wyst->ilosc_wystapien;
                cout << command << " == " << liczbaWystapien << endl;
            }
            break;
        };
        case 'A':
        {
            if (isNumber(cmd[0]) && strcmp(cmd[2], "?") == 0)
            {
                int nrSekcji = atoi(cmd[0]);
                sekcja* s1 = lista_sekcji->get_element(nrSekcji);
                if (s1 != NULL)
                {
                    int d = (s1->lista_atrybutow)->count;
                    cout << command << " == " << d << endl;
                }
            } else if (isNumber(cmd[0]) && !isNumber(cmd[2]))
            {
                int nrSekcji = atoi(cmd[0]);
                sekcja* s1 = lista_sekcji->get_element(nrSekcji);
                atrybut* attrb = s1->lista_atrybutow->get_element(cmd[2]);
                if (attrb != NULL)
                {
                    cout << command << " == " << attrb->wartosc << endl;
                }
            }

            if (!isNumber(cmd[0]))
            {
                int liczbaWystapien = 0;
                wystapienie_elementu* wyst = lwa->get_element(cmd[0]);
                if (wyst != NULL)
                    liczbaWystapien = wyst->ilosc_wystapien;

                cout << command << " == " << liczbaWystapien << endl;
            }
            break;
        }
        case 'E':
        {
            if (!isNumber(cmd[0]) && !isNumber(cmd[2]))
            {
                int liczbaSekcji = lista_sekcji->count;
                for (int i = liczbaSekcji; i >= 1; i--)
                {
                    sekcja* s1 = lista_sekcji->get_element(i);
                    char** d = s1->lista_selektorow->get_element(cmd[0]);
                    if (d != NULL)
                    {
                        atrybut* attrb = s1->lista_atrybutow->get_element(cmd[2]);
                        if (attrb != NULL)
                        {
                            cout << command << " == " << attrb->wartosc << endl;
                            break;
                        }
                    }
                }
            }
            break;
        }
        case 'D':
            if (strcmp(cmd[2], "*") == 0) {
                //i,D,*
                int nrSekcji = atoi(cmd[0]);
                sekcja *s1 = lista_sekcji->get_element(nrSekcji);
                if (s1 != NULL)
                {
                    lista<char*>* ls = s1->lista_selektorow;
                    int ii = 1;
                    while (ii <= ls->count)
                    {
                        char** d = s1->lista_selektorow->get_element(ii);
                        if (d != NULL)
                        {
                            wystapienie_elementu* ws = lws->get_element(*d);
                            ws->ilosc_wystapien--;
                        }
                        ii++;
                    }

                    lista<atrybut>* la = s1->lista_atrybutow;

                    ii = 1;
                    while (ii <= la->count)
                    {
                        atrybut* attrb = s1->lista_atrybutow->get_element(ii);
                        if (attrb != NULL)
                        {
                            wystapienie_elementu* wa = lwa->get_element(attrb->klucz);
                            if (wa != NULL)
                            {
                                wa->ilosc_wystapien--;
                            }
                        }
                        ii++;
                    }

                    bool deleted = lista_sekcji->pop(nrSekcji);
                    if (deleted) {
                        cout << command << " == deleted" << endl;
                    }
                }
            }
            else {
                //i,D,n

                int nrSekcji = atoi(cmd[0]);
                sekcja* s1 = lista_sekcji->get_element(nrSekcji);
                if (s1 != NULL) {
                    atrybut* attrb = s1->lista_atrybutow->get_element(cmd[2]);
                    if (attrb != NULL)
                    {
                        wystapienie_elementu *wa = lwa->get_element(cmd[2]);
                        if (wa != NULL)
                        {
                            wa->ilosc_wystapien--;
                        }
                    }
                    bool deleted = s1->lista_atrybutow->pop(cmd[2]);

                    int d = (s1->lista_atrybutow)->count;
                    if (d == 0) 
                    {
                        lista<char*> *ls = s1->lista_selektorow;
                        int ii = 1;
                        while (ii <= ls->count)
                        {
                            char** ss = s1->lista_selektorow->get_element(ii);
                            if (ss != NULL)
                            {
                                wystapienie_elementu *ws = lws->get_element(*ss);
                                ws->ilosc_wystapien--;
                            }
                            ii++;
                        }
                        lista_sekcji->pop(atoi(cmd[0]));
                        cout << command << " == deleted" << endl;
                    }
                    else if (deleted)
                    {
                        cout << command << " == deleted" << endl;
                    }
                }
            }
            break;
    }

}

int main()
{
    lista<sekcja>* lista_sekcji = new lista<sekcja>();
    lista<wystapienie_elementu> *lwa = new lista<wystapienie_elementu>();
    lista<wystapienie_elementu> *lws = new lista<wystapienie_elementu>();

    pewnasekcja = new sekcja();
    attr = new atrybut();
    char linia[ROZMIAR_LINII];
    int mode = CSS_READ;
    linia[0] = '\0';
    bool work = true;
    while (fgets(linia, sizeof(linia), stdin) != NULL)
    {
        int length = (int)strlen(linia);

        for (int jj = length - 1; jj >= 0; jj--)
        {
            if (linia[jj] <= ' ' || linia[jj] == '\t' || linia[jj] == '\n')
                linia[jj] = '\0';
            else
            {
                break;
            }
        }

        if (mode == CSS_READ) {
            if (strcmp(linia, "????") == 0) {
                mode = CMD_READ;
            }
            else
                parsuj_bufor(linia, lista_sekcji, lwa, lws);
        }
        else {
            if (strcmp(linia, "****") == 0) {
                mode = CSS_READ;
                linia[0] = '\0';
            }
            else if (strcmp(linia, "?") == 0) {
                cout << "? == " << lista_sekcji->count << endl;
            }
            else {
                command_process(linia, lista_sekcji,lwa, lws);
            }
        }
    } 
}

