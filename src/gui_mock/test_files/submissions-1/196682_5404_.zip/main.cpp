#include <iostream>
#include <cstdio>

class Wezel
{
	void *dan = nullptr;
	Wezel *nast = nullptr;
	Wezel* poprz = nullptr;
public:
	Wezel(void* dan)
	{
		this->dan = dan;
		nast = nullptr;
		poprz = nullptr;
	}
	~Wezel()
	{
		dan = nullptr;
		nast = nullptr;
		poprz = nullptr;
	}
	void setNast(Wezel* nast_wezel)
	{
		this->nast = nast_wezel;
	}
	void setPoprz(Wezel* poprz_wezel)
	{
		this->poprz = poprz_wezel;
	}
	Wezel *getNast()
	{
		return nast;
	}
	Wezel *getPoprz()
	{
		return poprz;
	}
	void *getDan()
	{
		return dan;
	}
};

class List
{
	Wezel* glowa;
	Wezel* ogon;
	int rozm;

public:
	List()
	{
		glowa = nullptr;
		ogon = nullptr;
		rozm = 0;
	}
	void umzprzod(void* dan)
	{
		Wezel* new_wezel = new Wezel(dan);
		if (glowa == nullptr)
		{
			glowa = new_wezel;
			ogon = new_wezel;
		}
		else
		{
			ogon->setPoprz(new_wezel);
			new_wezel->setNast(ogon);
			ogon = new_wezel;
		}
		rozm++;
	}
	void umztylu(void* dan)
	{
		Wezel* new_wezel = new Wezel(dan);
		if (glowa == nullptr)
		{
			glowa = new_wezel;
			ogon = new_wezel;
		}
		else
		{
			ogon->setNast(new_wezel);
			new_wezel->setPoprz(ogon);
			ogon = new_wezel;
		}
		rozm++;
	}
	void zmzprzod()
	{
		if (glowa == nullptr)
		{
			return;
		}
		else if (glowa == ogon)
		{
			glowa = nullptr;
			ogon = nullptr;
		}
		else
		{
			Wezel* new_glowa = glowa->getNast();
			glowa = new_glowa;
			glowa->setPoprz(nullptr);
		}
		rozm--;
	}
	void zmztylu()
	{
		if (glowa == nullptr)
		{
			return;
		}
		else if (glowa == ogon)
		{
			glowa = nullptr;
			ogon = nullptr;
		}
		else
		{
			Wezel* new_ogon = ogon->getPoprz();
			ogon = new_ogon;
			ogon->setNast(nullptr);
		}
		rozm--;
	}
	void wstaw(int numer, void* dan)
	{
		if (numer < 0 || numer > rozm)
		{
			return;
		}
		else if (numer == 0)
		{
			umzprzod(dan);
		}
		else if (numer == rozm)
		{
			umztylu(dan);
		}
		else
		{
			Wezel *new_wezel = new Wezel(dan);
			Wezel *teraz = glowa;
			for (int i = 0; i < numer; i++)
			{
				teraz = teraz->getNast();
			}
			Wezel* poprz = teraz->getPoprz();
			poprz->setNast(new_wezel);
			new_wezel->setPoprz(poprz);
			new_wezel->setNast(teraz);
			teraz->setPoprz(new_wezel);
			rozm++;
		}
	}
	Wezel *getGlowa()
	{
		return glowa;
	}
	Wezel *getOgon()
	{
		return ogon;
	}
	void wymaz(int numer)
	{
		if (numer < 0 || numer >= rozm)
		{
			return;
		}
		else if (numer == 0)
		{
			zmzprzod();
		}
		else if (numer == rozm - 1)
		{
			zmztylu();
		}
		else
		{
			Wezel *teraz = glowa;
			for (int i = 0; i < numer; i++)
			{
				teraz = teraz->getNast();
			}
			Wezel *poprz = teraz->getPoprz();
			Wezel *nast = teraz->getNast();
			poprz->setNast(nast);
			nast->setPoprz(poprz);
			delete teraz;
			rozm--;
		}
	}
	int getRozm()
	{
		return rozm;
	}
	void *operator[](int numer)
	{
		if (numer < 0 || numer >= rozm)
		{
			throw std::out_of_range("Numer jest po za zakresem");
		}
		else
		{
			if (numer < rozm / 2)
			{
				Wezel* teraz = glowa;
				for (int i = 0; i < numer; i++)
				{
					teraz = teraz->getNast();
					teraz->getDan();
				}
				return teraz->getDan();
			}
			else
			{
				Wezel* teraz = ogon;
				for (int i = rozm - 1; i > numer; i--)
				{
					teraz = teraz->getPoprz();
				}
				return teraz->getDan();
			}
		}
	}
};

class Kod
{
	char* kod = nullptr;
	int rozm = 0;
public:
	Kod()
	{
		kod = new char[1];
		kod[0] = '\0';
		rozm = 0;
	}
	Kod(char* kod)
	{
		int i = 0;
		while (kod[i] != '\0')
		{
			i++;
		}
		if (this->kod != nullptr)
		{
			delete[] this->kod;
		}
		this->kod = new char[1 + 1];
		for (int j = 0; j < i; j++)
		{
			this->kod[j] = kod[j];
		}
		this->kod[i] = '\0';
		rozm = i;
	}
	Kod(const Kod& other)
	{
		if (this->kod != nullptr)
		{
			delete[] this->kod;
		}
		this->kod = new char[other.rozm + 1];
		for (int i = 0; i < other.rozm; i++)
		{
			this->kod[i] = other.kod[i];
		}
		this->kod[other.rozm] = '\0';
		this->rozm = other.rozm;
	}
	Kod(const char m)
	{
		if (this->kod != nullptr)
		{
			delete[] this->kod;
		}
		kod = new char[2];
		kod[0] = m;
		kod[1] = '\0';
		rozm = 1;
	}
	~Kod()
	{
		if (this->kod != nullptr)
		{
			delete[] this->kod;
		}
	}
	Kod operator+(const Kod& other)
	{
		Kod wynik;
		wynik.rozm = this->rozm + other.rozm;
		wynik.kod = new char[wynik.rozm + 1];
		for (int i = 0; i < this->rozm; i++)
		{
			wynik.kod[i] = this->kod[i];
		}
		for (int i = 0; i < other.rozm; i++)
		{
			wynik.kod[this->rozm + i] = other.kod[i];
		}
		wynik.kod[wynik.rozm] = '\0';
		return wynik;
	}
	Kod& operator+=(const Kod& other)
	{
		*this = *this + other;
		return *this;
	}
	Kod& operator=(const Kod& other)
	{
		if (this->kod)
		{
			delete this->kod;
		}
		this->rozm = other.rozm;
		this->kod = new char[this->rozm + 1];
		for (int i = 0; i < this->rozm; i++)
		{
			this->kod[i] = other.kod[i];
		}
		this->kod[this->rozm] = '\0';
		return *this;
	}
	Kod &operator=(Kod &&other)
	{
		if (this->kod)
		{
			delete this->kod;
		}
		this->rozm = other.rozm;
		this->kod = other.kod;
		other.kod = nullptr;
		return *this;
	}
	Kod& operator=(const char* other)
	{
		if (this->kod != nullptr)
		{
			delete[] this->kod;
		}
		int i = 0;
		while (other[i] != '\0')
		{
			i++;
		}
		this->kod = new char[i + 1];
		for (int j = 0; j < i; j++)
		{
			this->kod[j] = other[j];
		}
		this->kod[i] = '\0';
		this->rozm = i;
		return *this;
	}
	bool operator==(const Kod& other)
	{
		if (this->rozm != other.rozm)
		{
			return false;
		}
		for (int i = 0; i < this->rozm; i++)
		{
			if (this->kod[i] != other.kod[i])
			{
				return false;
			}
		}
		return true;
	}
	bool operator!=(const Kod& other)
	{
		return !(*this == other);
	}
	bool operator==(const char* other)
	{
		int i = 0;
		while (other[i] != '\0')
		{
			i++;
		}
		if (this->rozm != i)
		{
			return false;
		}
		for (int j = 0; j < this->rozm; j++)
		{
			if (this->kod[j] != other[j])
			{
				return false;
			}
		}
		return true;
	}
	void mal(bool new_line = true)
	{
		std::cout << kod;
		if (new_line)
		{
			std::cout << std::endl;
		}
	}
	bool skan()
	{
		delete[] kod;
		this->kod = new char[150];
		fgets(this->kod, 150, stdin);
		if (this->kod[0] == '\n')
		{
			return false;
		}
		int i = 0;
		while (this->kod[i] != '\n')
		{
			i++;
		}
		this->rozm = i;
		this->kod[i] = '\0';
		return true;
	}
	Kod do_koda()
	{
		Kod wynik;
		wynik.rozm= this->rozm;
		wynik.kod = new char[wynik.rozm + 1];
		for (int i = 0; i < this->rozm; i++)
		{
			wynik.kod[i] = this->kod[i];
		}
		wynik.kod[wynik.rozm] = '\0';
		return wynik;
	}
	List dziel(char symbol)
	{
		List wynik = List();
		Kod* tmp = new Kod();
		for (int i = 0; i <= this->rozm; i++)
		{
			if (this->kod[i] == symbol or i == this->rozm)
			{
				if (tmp->rozm == 0)
				{
					continue;
				}
				wynik.umztylu(tmp);
				tmp = new Kod();
			}
			else
			{
				*tmp += this->kod[i];
			}
		}
		delete tmp;
		return wynik;
	}
	char otrzym_symbol(int numer)
	{
		if (numer >= 0 && numer < this->rozm)
			return this->kod[numer];
		else if (numer < 0 && numer >= -this->rozm)
			return this->kod[this->rozm + numer];
		else
			return '\0';
	}
	void pas()
	{
		int i = 0;
		while (this->kod[i] <= ' ' and i < this->rozm)
		{
			i++;
		}
		int j = this->rozm - 1;
		while (this->kod[j] <= ' ' and j >= 0)
		{
			j--;
		}
		if (i == 0 and j == this->rozm - 1)
		{
			return;
		}
		Kod tmp;
		for (int k = i; k <= j; k++)
		{
			tmp += this->kod[k];
		}
		*this = std::move(tmp);
	}
	void usun_symbol(char symbol)
	{

		Kod tmp;
		for (int i = 0; i < this->rozm; i++)
		{
			if (this->kod[i] != symbol)
			{
				tmp += this->kod[i];
			}
		}
		*this = std::move(tmp);
	}

	int policz(char symbol)
	{
		int wynik = 0, i = 0;
		while (this->kod[i] != '\0')
		{
			if (this->kod[i] == symbol)
			{
				wynik++;
			}
			i++;
		}
		return wynik;
	}
	int getRozm()
	{
		return this->rozm;
	}

	int do_licz()
	{
		int result = 0;
		for (int i = 0; i < this->rozm; i++)
		{
			result *= 10;
			result += this->kod[i] - '0';
		}
		return result;
	}

	bool czy_numer()
	{
		for (int i = 0; i < this->rozm; i++)
		{
			if (this->kod[i] < '0' or this->kod[i] > '9')
			{
				return false;
			}
		}
		return true;
	}
};

struct Wlasnosc
{
	Kod nazw = Kod();
	Kod znacz = Kod();
};

class KodCss
{
	List selektory;
	List wlasnosci;

public:
	KodCss()
	{
		selektory = List();
		wlasnosci = List();
	}
	~KodCss()
	{
		for (int i = 0; i < this->wlasnosci.getRozm(); i++)
		{
			delete (Wlasnosc*)this->wlasnosci[i];
		}
	}
	void dodaj_selektor(Kod* selektor)
	{
		this->selektory.umztylu(selektor);
	}
	void dodaj_wlasnosci(const Kod* nazw, const Kod* znacz)
	{
		Wlasnosc* tmp = new Wlasnosc();
		tmp->znacz = *znacz;
		tmp->nazw = *nazw;
		this->wlasnosci.umztylu(tmp);
	}
	void usun_wlasnosci(Kod nazw)
	{
		for (int i = 0; i < this->wlasnosci.getRozm(); i++)
		{
			if (((Wlasnosc*)this->wlasnosci[i])->nazw == nazw)
			{
				this->wlasnosci.wymaz(i);
				return;
			}
		}
	}
	List get_selektory()
	{
		return selektory;
	}
	List get_wlasnosci()
	{
		return wlasnosci;
	}
	void mal()
	{
		std::cout << "Selectors: ";
		for (int i = 0; i < this->selektory.getRozm(); i++)
		{
			((Kod*)this->selektory[i])->mal();
		}
		std::cout << "Properties: " << std::endl;
		for (int i = 0; i < this->wlasnosci.getRozm(); i++)
		{
			((Wlasnosc*)this->wlasnosci[i])->nazw.mal(false);
			std::cout << ": ";
			((Wlasnosc*)this->wlasnosci[i])->znacz.mal();
		}
	}
};

void analiz_selektory(Kod kod, KodCss* css)
{
	List dzielony_kod = kod.dziel(',');
	for (int i = 0; i < dzielony_kod.getRozm(); i++)
	{
		int j;
		((Kod*)dzielony_kod[i])->usun_symbol('{');
		((Kod*)dzielony_kod[i])->pas();
		Kod tmp = ((Kod*)dzielony_kod[i])->do_koda();
		for (j = 0; j < css->get_selektory().getRozm(); j++)
		{
			if (tmp == ((Kod*)css->get_selektory()[j])->do_koda())
				break;
		}
		if (j < css->get_selektory().getRozm())
			continue;
		css->dodaj_selektor((Kod*)dzielony_kod[i]);
	}
}

void analiz_wlasnosci(Kod kod, KodCss* css)
{
	if (kod.policz('{'))
	{
		kod.usun_symbol('{');
	}
	if (kod.policz('}'))
	{
		kod.usun_symbol('}');
	}
	if (kod.otrzym_symbol(-1) != ';')
	{
		kod += ';';
	}
	if (kod.policz(';') > 1)
	{
		List dzielony_kod = kod.dziel(';');
		for (int i = 0; i < dzielony_kod.getRozm(); i++)
		{
			analiz_wlasnosci(((Kod*)dzielony_kod[i])->do_koda(), css);
		}
		return;
	}
	List dzielony_kod = kod.dziel(':');
	if (dzielony_kod.getRozm() != 2)
		return;

	((Kod*)dzielony_kod[1])->usun_symbol(';');
	((Kod*)dzielony_kod[0])->pas();
	((Kod*)dzielony_kod[1])->pas();
	for (int i = 0; i < css->get_wlasnosci().getRozm(); i++)
	{
		if (((Wlasnosc*)css->get_wlasnosci()[i])->nazw == ((Kod*)dzielony_kod[0])->do_koda())
		{
			((Wlasnosc*)css->get_wlasnosci()[i])->znacz = ((Kod*)dzielony_kod[1])->do_koda();
			return;
		}
	}
	css->dodaj_wlasnosci((Kod*)dzielony_kod[0], (Kod*)dzielony_kod[1]);
}

void AnalizCss(List& listcss)
{
	Kod wejsc = Kod();
	KodCss* teraz_wezel = new KodCss();
	Kod teraz_selektory = Kod();
	Kod teraz_wlasnosci = Kod();
	bool otwarty = false;
	while (true)
	{
		wejsc = Kod();
		wejsc.skan();
		if (wejsc == "????")
			return;

		if (wejsc.policz('}'))
		{
			if (wejsc != '}')
			{
				if (otwarty)
					teraz_wlasnosci += wejsc;
				else
				{
					List dzielony_kod = wejsc.dziel('{');
					if (dzielony_kod.getRozm() == 2)
					{
						teraz_selektory += ((Kod*)dzielony_kod[0])->do_koda();
						teraz_wlasnosci += ((Kod*)dzielony_kod[1])->do_koda();
					}
					else
					{
						teraz_wlasnosci += wejsc.do_koda();
					}
				}
			}
			analiz_selektory(teraz_selektory, teraz_wezel);
			analiz_wlasnosci(teraz_wlasnosci, teraz_wezel);
			listcss.umztylu(teraz_wezel);
			otwarty = false;
			teraz_wezel = new KodCss();
			teraz_wlasnosci = Kod();
			teraz_selektory = Kod();
			continue;
		}
		else if (otwarty)
		{
			teraz_wlasnosci += wejsc;
		}
		else if (wejsc.policz('{'))
		{
			if (wejsc != '{')
			{
				teraz_selektory += wejsc;
			}
			otwarty = true;
		}
		else
		{
			teraz_selektory += wejsc;
		}
	}
}

int get_selektory_sum(List& listcss, int numer)
{
	try
	{
		return ((KodCss*)listcss[numer - 1])->get_selektory().getRozm();
	}
	catch (const std::exception& e)
	{
		return -1;
	}
}

int get_wlasnosci_sum(List& listcss, int numer)
{
	try
	{
		return ((KodCss*)listcss[numer - 1])->get_wlasnosci().getRozm();
	}
	catch (const std::exception& e)
	{
		return -1;
	}
}

int policz_selektory_sum(Kod selektor, List& listcss)
{
	int wynik = 0;
	for (int i = 0; i < listcss.getRozm(); i++)
	{
		List selektory = ((KodCss*)listcss[i])->get_selektory();
		for (int j = 0; j < selektory.getRozm(); j++)
		{
			if (selektor == *((Kod*)selektory[j]))
			{
				wynik++;
			}
		}
	}
	return wynik;
}

int policz_wlasnisci_sum(Kod wlasnosc, List& listcss)
{
	int wynik = 0;
	for (int i = 0; i < listcss.getRozm(); i++)
	{
		List wlasnosci = ((KodCss*)listcss[i])->get_wlasnosci();
		for (int j = 0; j < wlasnosci.getRozm(); j++)
		{
			if (wlasnosc == ((Wlasnosc *)wlasnosci[j])->nazw.do_koda())
			{
				wynik++;
			}
		}
	}
	return wynik;
}

void mal_selektor(List& listcss, int blok_num, int selektor_num)
{
	try
	{
		List selektory = ((KodCss*)listcss[blok_num - 1])->get_selektory();
		Kod selektor = ((Kod*)selektory[selektor_num - 1])->do_koda();
		std::cout << blok_num << ",S," << selektor_num << " == ";
		selektor.mal();
	}
	catch (const std::exception& e)
	{}
}

void mal_wlasnosc(List& listcss, int blok_num, Kod wlasnosc_nazw)
{
	try
	{
		List wlasnosci = ((KodCss*)listcss[blok_num - 1])->get_wlasnosci();
		for (int i = 0; i < wlasnosci.getRozm(); i++)
		{
			if (wlasnosc_nazw == ((Wlasnosc*)wlasnosci[i])->nazw)
			{
				std::cout << blok_num << ",A,";
				wlasnosc_nazw.mal(false);
				std::cout << " == ";
				((Wlasnosc*)wlasnosci[i])->znacz.mal();
			}
		}
	}
	catch (const std::exception& e)
	{}
}

void mal_ostatn_wlasnosc_znazcz(List& listcss, Kod wlasnosc_nazw, Kod selektor_nazw)
{
	try
	{
		for (int i = listcss.getRozm() - 1; i >= 0; i--)
		{
			List wlasnosci = ((KodCss*)listcss[i])->get_wlasnosci();
			for (int j = 0; j < wlasnosci.getRozm(); j++)
			{
				if (wlasnosc_nazw == ((Wlasnosc*)wlasnosci[j])->nazw)
				{
					List selektory = ((KodCss*)listcss[i])->get_selektory();
					for (int k = 0; k < selektory.getRozm(); k++)
					{
						if (selektor_nazw == ((Kod*)selektory[k])->do_koda())
						{
							selektor_nazw.mal(false);
							std::cout << ",E,";
							wlasnosc_nazw.mal(false);
							std::cout << " == ";
							((Wlasnosc*)wlasnosci[j])->znacz.mal();
							return;
						}
					}
				}
			}
		}
	}
	catch (const std::exception& e)
	{}
}

void komanda_S(List& listcss, List dziel_kom)
{
	if (((Kod*)dziel_kom[2])->do_koda() == "?")
	{
		if (((Kod*)dziel_kom[0])->czy_numer())
		{
			int numer = ((Kod *)dziel_kom[0])->do_licz();
			int sum = get_selektory_sum(listcss, numer);
			if (sum != -1)
			{
				std::cout << numer << ",S,? == " << sum << std::endl;
			}
		}
		else
		{
			Kod selektor = ((Kod*)dziel_kom[0])->do_koda();
			try
			{
				int sum = policz_selektory_sum(selektor, listcss);
				selektor.mal(false);
				std::cout << ",S,? == " << sum << std::endl;
			}
			catch (const std::exception& e)
			{}
		}
	}
	else
	{
		int blok_num = ((Kod*)dziel_kom[0])->do_licz();
		int selektor_num = ((Kod*)dziel_kom[2])->do_licz();
		mal_selektor(listcss, blok_num, selektor_num);
	}
}

void komanda_A(List& listcss, List dzile_kom)
{
	if (((Kod*)dzile_kom[2])->do_koda() == "?")
	{
		if (((Kod*)dzile_kom[0])->czy_numer())
		{
			int numer = ((Kod*)dzile_kom[0])->do_licz();
			try
			{
				int sum = get_wlasnosci_sum(listcss, numer);
				if (sum != -1)
					std::cout << numer << ",A,? == " << sum << std::endl;
			}
			catch (const std::exception& e)
			{}
		}
		else
		{
			Kod selektor = ((Kod*)dzile_kom[0])->do_koda();
			try
			{
				int sum = policz_wlasnisci_sum(selektor, listcss);
				selektor.mal(false);
				std::cout << ",A,? == " << sum << std::endl;
			}
			catch (const std::exception& e)
			{}
		}
	}
	else
	{
		int blok_num = ((Kod*)dzile_kom[0])->do_licz();
		Kod wlsnosc_nazw = ((Kod*)dzile_kom[2])->do_koda();
		mal_wlasnosc(listcss, blok_num, wlsnosc_nazw);
	}
}

void komanda_E(List& listcss, List dziel_kom)
{
	Kod selektor_nazw = ((Kod*)dziel_kom[0])->do_koda();
	Kod wlasnosc_nazw = ((Kod*)dziel_kom[2])->do_koda();
	mal_ostatn_wlasnosc_znazcz(listcss, wlasnosc_nazw, selektor_nazw);
}

void komanda_D(List& listcss, List dziel_kom)
{
	int numer = ((Kod*)dziel_kom[0])->do_licz();
	if (((Kod*)dziel_kom[2])->do_koda() == "*")
	{
		if (numer > 0 && numer <= listcss.getRozm())
		{
			listcss.wymaz(numer - 1);
			std::cout << numer << ",D,* == deleted" << std::endl;
		}
	}
	else
	{
		int blok_num = ((Kod*)dziel_kom[0])->do_licz();
		Kod wlasnosc_nazw = ((Kod*)dziel_kom[2])->do_koda();
		try
		{
			List wlasnosci = ((KodCss*)listcss[blok_num - 1])->get_wlasnosci();
			for (int i = 0; i < wlasnosci.getRozm(); i++)
			{
				if (wlasnosc_nazw == ((Wlasnosc*)wlasnosci[i])->nazw)
				{
					((KodCss*)listcss[blok_num - 1])->usun_wlasnosci(wlasnosc_nazw);
					std::cout << blok_num << ",D,";
					wlasnosc_nazw.mal(false);
					std::cout << " == deleted" << std::endl;
					if (((KodCss*)listcss[blok_num - 1])->get_wlasnosci().getRozm() == 0)
						listcss.wymaz(blok_num - 1);
					return;
				}
			}
		}
		catch (const std::exception& e)
		{}
	}
}

int main(int, char**)
{
	std::ios::sync_with_stdio(false);
	List list = List();
	AnalizCss(list);
	char kom[100];
	Kod komanda;
	while (std::cin.getline(kom, 100))
	{
		komanda = std::move(kom);
		if (komanda == "****")
		{
			AnalizCss(list);
		}
		else if (komanda == "?")
		{
			std::cout << "? == " << list.getRozm() << std::endl;
		}
		else if (komanda == "P")
		{
			for (int i = 0; i < list.getRozm(); i++)
			{
				std::cout << i << std::endl;
				((KodCss*)list[i])->mal();
				std::cout << std::endl;
			}
		}
		else
		{
			List dzile_kom = komanda.dziel(',');
			if (dzile_kom.getRozm() != 3)
			{
				continue;
			}
			if (((Kod*)dzile_kom[1])->do_koda() == "S")
			{
				komanda_S(list, dzile_kom);
			}
			else if (((Kod*)dzile_kom[1])->do_koda() == "A")
			{
				komanda_A(list, dzile_kom);
			}
			else if (((Kod*)dzile_kom[1])->do_koda() == "E")
			{
				komanda_E(list, dzile_kom);
			}
			else if (((Kod*)dzile_kom[1])->do_koda() == "D")
			{
				komanda_D(list, dzile_kom);
			}
		}
	}
	return 0;
}