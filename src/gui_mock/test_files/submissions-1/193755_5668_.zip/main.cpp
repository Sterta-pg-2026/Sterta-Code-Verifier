#include <iostream>
#include <conio.h>
#include "mystring.h"
#include "atrybut.h"
#include "selektor.h"
#include "sekcje.h"
#include "blok.h"

int main()
{
    using namespace std;
    char a;
    int i = 0, j = 0, z = 0;

    sekcje* tempSekcja = new sekcje;
    myString* slowo = new myString;
    
    slowo->dodaj_znak('c');
    slowo->dodaj_znak('o');
    slowo->dodaj_znak('l');
    slowo->dodaj_znak('o');
    slowo->dodaj_znak('r');



    bool isSelektor = true;
    while (j == 0) {

        selektory* tempSelektor = new selektory;
        atrybuty* tempAtrybut = new atrybuty;
        i = 0;

        while (i == 0) {

            myString* tempSlowo = new myString;

            while (cin >> a) {

                if (a == ':' && isSelektor == false) {

                    z = tempAtrybut->sprawdz_czy_wystapil(tempSlowo);
                    if (z != 0)break;
                    tempAtrybut->dodaj_atrybut(tempSlowo);
                    //i = 1;
                    break;
                }

                if (a == ';' && isSelektor == false) {

                    if (z != 0) {

                        tempAtrybut->podmien_wartosc(tempSlowo, z);
                        z = 0;
                    }
                    else {
                        tempAtrybut->dodaj_wartosc(tempSlowo);
                    }
                    //i = 1;
                    break;
                }

                if (a == ',' && isSelektor == true) {
                    tempSelektor->dodaj_selektor(tempSlowo);
                    //i = 1;
                    break;
                }

                if (a == '{') {
                    tempSelektor->dodaj_selektor(tempSlowo);
                    isSelektor = false;
                    //i = 1;
                    break;
                }

                if (a == '}') {
                    //tempSelektor->dodaj_selektor(tempSlowo);
                    isSelektor = true;
                    i = 1;

                    break;
                }

                if (a == '.') {

                    i = 1;
                    j = 1;
                    break;
                }
                tempSlowo->dodaj_znak(a);

            }
        }
        if (j == 1)break;
        tempSekcja->dodaj_sekcje(tempAtrybut, tempSelektor);
    }


    tempSekcja->wyswietl_sekcje();
    cout << "----------\n" ;
    tempSekcja->podaj_liczbe_sekcji();
    cout << "----------\n" ;
    tempSekcja->podaj_atrybuty_sekcji(1);
    cout << "----------\n" ;
    tempSekcja->podaj_selektory_sekcji(1);
    cout << "----------\n";
    tempSekcja->selektor_sekcji(1, 1);
    cout << "----------\n";
    cout << "----------\n";
    cout << "----------\n";
    tempSekcja->wypisz_wystopienia_atrybutu(slowo);
    cout << "----------\n";




    return(0);
}