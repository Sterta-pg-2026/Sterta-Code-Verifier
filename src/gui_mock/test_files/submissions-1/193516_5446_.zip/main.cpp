#include <iostream>
#include "string.h"

#define SIZE_T 8

struct Selector {
    myString str;
    Selector *next_selector = nullptr;
};

struct Attribute {
    myString attribute_name;
    myString attribute_value;
    Attribute *next_attribute = nullptr;
};

struct Section {
    Selector *head_selector = nullptr;
    Attribute *head_attribute = nullptr;
};

struct Node {
    Node *prev_node = nullptr;
    Node *next_node = nullptr;
    Section *section_array[SIZE_T] {nullptr};
};

struct List {
    Node *head_node = nullptr;
    Node *tail_node = nullptr;
};

List list;
Node* new_node = new Node;
Section* new_section = new Section;
Selector* new_selector = new Selector;
Attribute* new_attribute = new Attribute;

bool read_code = true;
bool read_selector = true;
bool read_attribute = false;
bool read_attribute_name = true;
bool if_semicolon_at_the_end = true;

void handle_code(char curr_char, myString* temp_str) {

    auto add_selector = [&]() {
        if (new_selector->str.return_length() < 1) {
            return;
        } else if(new_section->head_selector == nullptr) {
            new_section->head_selector = new_selector;
        } else {
            Selector* c_selector = new_section->head_selector;
            for(; c_selector->next_selector != nullptr; c_selector = c_selector->next_selector);
            c_selector->next_selector = new_selector;
        }
    };

    auto add_attribute = [&]() {
        if (new_section->head_attribute == nullptr) { // check for head attribute
            new_section->head_attribute = new_attribute;
        } else {
            Attribute* c_attribute = new_section->head_attribute;
            for(; c_attribute->next_attribute != nullptr; c_attribute = c_attribute->next_attribute);
            c_attribute->next_attribute = new_attribute;
        }
    };

    auto add_section = [&]() {
        if (list.head_node == nullptr) {
            Node* new_node = new Node;
            new_node->section_array[0] = new_section;
            list.head_node = new_node;
            list.tail_node = new_node;
            return;
        } else if (list.tail_node == nullptr || list.tail_node->section_array[7] != nullptr) {
            Node* new_node = new Node;
            list.head_node = new_node;
            list.tail_node = new_node;
            new_node->section_array[0] = new_section;
            return;
        } else if (list.tail_node != nullptr && list.tail_node->section_array[7] == nullptr) {
            int i = 0;
            while (i < SIZE_T) {
                if (list.tail_node->section_array[i] == nullptr) {
                    list.tail_node->section_array[i] = new_section;
                    return;
                }
                ++i;
            }
        }
    };

    switch (curr_char) {
        case ',':
            if (read_selector == true){
                new_selector->str = *temp_str;
                // remove white characters
                add_selector();
                new_selector = new Selector;
                temp_str->clear_string();
            } else if (read_attribute && !read_attribute_name) {
                temp_str->add_char(curr_char);
            }
            break;

        case '{':
            if (read_selector){
                new_selector->str = *temp_str;
                // remove white characters
                add_selector();
                new_selector = new Selector;
                temp_str->clear_string();
                read_selector = false;
                read_attribute = true;
                read_attribute_name = true;
            }
            break;

        case '}':
            if (!if_semicolon_at_the_end) {
                new_attribute->attribute_value = *temp_str;
                add_attribute();
            }
            add_section();
            new_section = new Section;
            new_selector = new Selector;
            new_attribute = new Attribute;
            temp_str->clear_string();
            read_selector = true;
            read_attribute = false;
            read_attribute_name = true;
            //check if attribute was added
            break;

        case ':':
            if (read_attribute) {
                new_attribute->attribute_name = *temp_str;
                temp_str->clear_string();
                read_attribute_name = false;
                if_semicolon_at_the_end = false;
            }
            else if(read_selector) {
                temp_str->add_char(curr_char);
            }
            break;

        case ';':
            if (read_attribute) {
                new_attribute->attribute_value = *temp_str;
                add_attribute();
                new_attribute = new Attribute;
                temp_str->clear_string();
                read_attribute_name = true;
                if_semicolon_at_the_end = true;
            } else if (read_selector) {
                temp_str->add_char(curr_char);
            }
            break;

        case '\t':
            break;

        case '\n':
            break;

        default:
            temp_str->add_char(curr_char);
            break;
    }

}

void handle_commands(char curr_char, myString* temp_str) {
    ;
}

int main() {
    myString temp_str;

    char curr_char = '\0';
    while ((curr_char = getchar()) != EOF) {
        if (curr_char == '?' || curr_char == '*') {
            char c1 = getchar();
            char c2 = getchar();
            char c3 = getchar();
            if (c1 == c2 == c3 && c1 == '?') {
                read_code = false;
            } else if (c1 == c2 == c3 && c1 == '*') {
                read_code = true;
            } else {
                if (read_code) {
                    handle_code(c1, &temp_str);
                    handle_code(c2, &temp_str);
                    handle_code(c3, &temp_str);
                } else {
                    ;
                }
            }
        } else if (read_code) {
            handle_code(curr_char, &temp_str);
        } else if (!read_code) {
            handle_commands(curr_char, &temp_str);
        }

    }
    delete new_selector;
    delete new_attribute;
    delete new_section;
    delete new_node;


    return 0;

}

