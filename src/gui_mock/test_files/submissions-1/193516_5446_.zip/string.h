
#pragma once
#include <iostream>
#include <cstring>

class myString {
private:
    int length;
    char *str = nullptr;

public:
    myString();
    myString& add_char(char c);
    int return_length();
    void clear_string();
    myString& operator=(myString& c_str);
    friend std::ostream& operator<<(std::ostream& os, const myString& str);
};

myString::myString() {
    length = 0;
    str = new char[1];
    str[0] = '\0';
}


myString& myString::add_char(char c) {
    char* new_str = new char[length + 2];
    if(str != nullptr) {
        int i = 0;
        while (i<length) {
            new_str[i] = str[i];
            i++;
        }
        delete[] str;
    }
    new_str[length] = c;
    new_str[length + 1] = '\0';
    str = new_str;
    length++;
    return *this;
}

int myString::return_length() {
    return length;
}

void myString::clear_string() {
    if(str != nullptr) {
        delete[] str;
        str = nullptr;
        length = 0;
    }
}

myString& myString::operator=(myString& c_str) {
    if(this != &c_str) {
        char* new_str = new char[c_str.length + 1];
        int i = 0;
        while (i<c_str.length+1) {
            new_str[i] = c_str.str[i];
            i++;
        }
        delete[] str;
        str = new_str;
        length = c_str.length;
    }
    return *this;
}

std::ostream& operator<<(std::ostream& os, const myString& str) {
    os << str.str;
    return os;
}