//
//  MainList.cpp
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#include "mainlist.h"
#include "list.h"
#include "selectorlist.h"
#include "attributelist.h"


MainList::MainList() {
	this->prev = nullptr;
	this->next = nullptr;
	this->emptySlots = T;
}


void MainList::AddSection(SelectorList* list1, AttributeList* list2, int* sectionHighestNumber) {
	MainList* tmp = this;
	if (emptySlots == 0) {
		if (tmp->next == nullptr) {
			MainList* newNode = new MainList();
			
			tmp = (MainList*)tmp->AddLast(this, newNode);

			newNode->sections[FIRST_SLOT].sList = list1;
			newNode->sections[FIRST_SLOT].aList = list2;
			newNode->sections[FIRST_SLOT].sectionNumber = ++*sectionHighestNumber;
			newNode->emptySlots--;
		}
		else {
			((MainList*)(tmp->next))->AddSection(list1, list2, sectionHighestNumber);
		}
	}
	else {
		int freeSpot = LookForSpot(tmp->sections);

		tmp->sections[freeSpot].sList = list1;
		tmp->sections[freeSpot].aList = list2;
		tmp->sections[freeSpot].sectionNumber = ++*sectionHighestNumber;
		tmp->emptySlots--;
	}
}

int MainList::LookForSpot(Section array[T]) {
	for (int i = 0; i < T; i++) {
		if (array[i].sectionNumber == EMPTY_SECTION_SLOT_NUMBER) {
			return i;
		}
	}
	return NULL;
}


MainList::~MainList() {
	for (int i = 0; i < T; i++) {
		if (sections[i].sectionNumber != EMPTY_SECTION_SLOT_NUMBER) {
			delete &sections[i];
		}
	}
}