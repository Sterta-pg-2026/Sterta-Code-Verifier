#pragma once
#include "constants.h"

struct Data {
    int sectionHighestNumber = 0;
    char textBuffer[TEXT_BUFFER_SIZE];
    int current_counting = ATTR_NAME;
    int element_length = 0;
    int prev_el_index = 0;
    int current_position = 0;
    bool break_or_not = false;
};