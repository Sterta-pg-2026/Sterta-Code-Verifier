//
//  SelectorList.h
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#ifndef SelectorList_h
#define SelectorList_h

#include "list.h"

class SelectorList: public List {
    public:
        char* selector;
        
        SelectorList(char* selector);
        char* getSelector();
        ~SelectorList();
};



#endif /* SelectorList_h */
