//
//  AttributeList.cpp
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#include "attributelist.h"
#include <cstdlib>
#include <string.h>

AttributeList::AttributeList(char* name, char* value){
    this->name = name;
    this->value = value;
}

AttributeList* AttributeList::FindNodeWithName(char* attr_name) {
    AttributeList* tmp = this;
    while (tmp != nullptr) {
        if (strcmp(tmp->name, attr_name) == EQUAL) {
            return tmp;
        }
        tmp = (AttributeList*)tmp->next;
    }
    return nullptr;
}

char* AttributeList::getName(){
    return this->name;
}
char* AttributeList::getValue(){
    return this->value;
}

AttributeList::~AttributeList() {
    delete[] name;
    delete[] value;
}