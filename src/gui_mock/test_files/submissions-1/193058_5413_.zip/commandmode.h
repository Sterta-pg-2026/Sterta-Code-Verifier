#ifndef CommandMode_h
#define CommandMode_h

#include "mainlist.h"
#include "data.h"



char* FindSelectorBySelectorNumber(SelectorList* selectorList, int selectorNumber);

//czy w danej liscie selektorow istnieje podany selektor
bool DoesSelectorExist(SelectorList* selectorList, char* selector);

//zwraca wartosc ostatniego wystapienia danego atrybutu w liscie
char* FindAttributeValue(AttributeList* attributeList, char* attr_name);

Section* FindSection(MainList* mainList, int sectionNumber, MainList* found_selection_parent_return);

char* FindAttributeValueForSelector(MainList* mainList, char* selector, char* attr_name);

int CountSelectors(SelectorList* selectorList);

int CountSelectors(SelectorList* selectorList, char* selector);

int CountSelector(MainList* mainList, char* selector);

int CountAttributes(AttributeList* attributeList);

int CountAttributes(AttributeList* attributeList, char* attr_name);

int CountAttribute(MainList* mainList, char* attr_name);

void PrintAnswer(char* command, int answer);

void PrintAnswer(char* command, char* answer);

void PrintAnswer(char* command, const char* answer);

int GetFirstArgumentInInt(char* command, int element_length, int right_border);

char* GetFirstArgumentInChar(char* command, int element_length, int right_border);

int GetThirdArgumentInInt(char* command, int first_comma_position, int prev_element_length);

char* GetThirdArgumentInChar(char* command, int first_comma_position, int prev_element_length);

void GetNewCommandLine(Data* data);

void GetNewCommandLine(Data* data, int* index);

void EnterCommandMode(MainList* mainList, Data* data);


#endif /* CommandMode_h */