#include <iostream>
#include <cstdio>
#include "constants.h"
#include "mainlist.h"
#include "list.h"
#include "selectorlist.h"
#include "attributelist.h"
#include "data.h"
#include "functions.h"
#include "commandmode.h"

using namespace std;



int main() {
    
    MainList mainList;
    Data data;
    SelectorList* selectorList = nullptr;
    AttributeList* attributeList = nullptr;
    char* attr_name = nullptr;
    char* attr_value = nullptr;


    fgets(data.textBuffer, TEXT_BUFFER_SIZE, stdin);
    do {
        if(data.current_position != 0) {
            for (int i = data.current_position; i < TEXT_BUFFER_SIZE; i++) {
                if (!isspace(data.textBuffer[i])) {
                    data.current_position = i;
                    break;
                }
                else if (data.textBuffer[i] == '\n' || data.textBuffer[i] == '\r' || data.textBuffer[i] == '\0') {
                    fgets(data.textBuffer, TEXT_BUFFER_SIZE, stdin);
                    i = -1;
                    data.current_position = 0;
                    data.element_length = 0;
                    data.prev_el_index = 0;
                }
            }
        }

        //przejscie do trybu komend
        if (data.textBuffer[data.current_position] == '?' && data.textBuffer[data.current_position + 1] == '?') {
            EnterCommandMode(&mainList, &data);
            fgets(data.textBuffer, TEXT_BUFFER_SIZE, stdin);
            data.current_position = 0;
            data.element_length = 0;
            data.prev_el_index = 0;
        }
        else {
            selectorList = EnterSelectorMode(selectorList, &data);

            attributeList = EnterAttributeMode(attributeList, &data);

            mainList.AddSection(selectorList, attributeList, &data.sectionHighestNumber);
            selectorList = nullptr;
            attributeList = nullptr;
        }

    } while (data.textBuffer != NULL && !feof(stdin));

	return 0;
}
