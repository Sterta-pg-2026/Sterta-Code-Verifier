#ifndef functions_h
#define functions_h
#include "mainlist.h"
#include "data.h"

char* RewriteWord(char textBuffer[TEXT_BUFFER_SIZE], int current_position, int prev_el_index, int element_length);

SelectorList* AddSelectorToTheList(SelectorList* selectorList, char* selector);

AttributeList* AddAttributeToTheList(AttributeList* attributeList, char* name, char* value);

void CheckBorderSpaces(char* text, int* left_border, int right_border, int* element_length);

void ProcessAndSaveSelector(SelectorList* selectorList, Data* data, int right_border);

char* EnterAttributeNameMode(Data* data, int* index);

char* ProcessAttributeValue(Data* data, int* index);

AttributeList* EnterAttributeValueMode(Data* data, int* index, AttributeList* attributeList, char* attr_name);

AttributeList* EnterAttributeMode(AttributeList* attributeList, Data* data);

SelectorList* EnterSelectorMode(SelectorList* selectorList, Data* data);
#endif /* functions_h */