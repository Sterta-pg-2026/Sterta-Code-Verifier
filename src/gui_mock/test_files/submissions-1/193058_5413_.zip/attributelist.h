//
//  AttributeList.h
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#ifndef AttributeList_h
#define AttributeList_h

#include "list.h"

class AttributeList : public List {
    public:
        char* name;
        char* value;

        AttributeList(char* name, char* value);
        AttributeList* FindNodeWithName(char* attr_name);
        char* getName();
        char* getValue();
        ~AttributeList();
};

#endif /* AttributeList_h */
