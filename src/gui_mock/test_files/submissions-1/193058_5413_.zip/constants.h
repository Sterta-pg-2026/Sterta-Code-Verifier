#ifndef Constants_h
#define Constants_h

#define T 8
#define EMPTY_SECTION_SLOT_NUMBER 0
#define FIRST_SLOT 0
#define TEXT_BUFFER_SIZE 128
#define ATTR_NAME 0
#define ATTR_VALUE 1
#define FIRST_SELECTOR_NUMBER 1
#define FIRST_CHARACTER_SPOT 0
#define DELETED_INFO "deleted"

#define EQUAL 0


#endif /* Constants_h */