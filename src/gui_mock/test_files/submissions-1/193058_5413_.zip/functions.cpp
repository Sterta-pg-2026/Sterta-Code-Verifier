#include <iostream>
#include "list.h"
#include "mainlist.h"
#include "selectorlist.h"
#include "data.h"
using namespace std;




char* RewriteWord(char textBuffer[TEXT_BUFFER_SIZE], int right_border, int prev_el_index, int element_length) {
    char* word = new char[element_length];
    for (int j = prev_el_index, k = 0; j < right_border; j++, k++) {
        word[k] = textBuffer[j];
    }
    word[element_length] = '\0';
    return word;
}




SelectorList* AddSelectorToTheList(SelectorList* selectorList, char* selector) {
    if (selectorList == nullptr) {
        selectorList = new SelectorList(selector);
    }
    else {
        selectorList = (SelectorList*)selectorList->AddLast(selectorList, new SelectorList(selector));
    }
    return selectorList;
}


AttributeList* AddAttributeToTheList(AttributeList* attributeList, char* name, char* value) {
    if (attributeList == nullptr) {
        attributeList = new AttributeList(name, value);
    }
    else {
        attributeList = (AttributeList*)attributeList->AddLast(attributeList, new AttributeList(name, value));
    }
    return attributeList;
}


void CheckBorderSpaces(char* text, int* left_border, int right_border, int* element_length) {
    for (int j = *left_border; isspace(text[j]); j++) {
        (*element_length)--;
        (*left_border)++;
    }
    for (int j = 0; isspace(text[right_border - 1 - j]); j++) {
        (*element_length)--;
    }
}


SelectorList* ProcessAndSaveSelector(SelectorList* selectorList, Data* data, int right_border) {
    CheckBorderSpaces(data->textBuffer, &data->prev_el_index, right_border, &data->element_length);
    char* selector = RewriteWord(data->textBuffer, right_border, data->prev_el_index, data->element_length);
    selectorList = AddSelectorToTheList(selectorList, selector);
    return selectorList;
}


SelectorList* EnterSelectorMode(SelectorList* selectorList, Data* data) {
    char* selector;
    for (int i = data->current_position; i < TEXT_BUFFER_SIZE; i++) {
        //jak po selektorach jest enter to juz nie bedzie wiecej selektorow w tej sekcji
        //jednak moe byc linijka tylko z enterem bez selektorow wiec wtedy ja pomijamy
        if (data->textBuffer[i] == '\n' || data->textBuffer[i] == '\r' || data->textBuffer[i] == '\0') {
            //sprawdzanie spacji 
            //1. normalnie
            //2. na wypadek dlugosci > 0 zlozonej ze spacji
            CheckBorderSpaces(data->textBuffer, &data->prev_el_index, i, &data->element_length);
            if (data->element_length > 0) {
                selector = RewriteWord(data->textBuffer, i, data->prev_el_index, data->element_length);
                selectorList = AddSelectorToTheList(selectorList, selector);

                fgets(data->textBuffer, TEXT_BUFFER_SIZE, stdin);
                i = 0;
                while (data->textBuffer[i] != '{') {
                    i++;
                }
                data->element_length = 0;
                data->prev_el_index = i + 1;
                data->current_position = i + 1;
                break;
            }
            else {
                fgets(data->textBuffer, TEXT_BUFFER_SIZE, stdin);
                i = -1;
                data->element_length = 0;
                data->current_position = 0;
                data->prev_el_index = 0;
            }
        }
        else if (data->textBuffer[i] == ',' || data->textBuffer[i] == '{') {
            selectorList = ProcessAndSaveSelector(selectorList, data, i);

            data->element_length = 0;
            data->prev_el_index = i + 1;

            if (data->textBuffer[i] == '{') {
                data->current_position = i + 1;
                break;
            }
        }
        else {
            data->element_length++;
        }
    }
    return selectorList;
}


char* EnterAttributeNameMode(Data* data, int* index) {
    if (data->textBuffer[*index] == '\n' || data->textBuffer[*index] == '\r' || data->textBuffer[*index] == '\0') {
        fgets(data->textBuffer, TEXT_BUFFER_SIZE, stdin);
        *index = 0;
        data->current_position = 0;
        data->prev_el_index = 0;
        data->element_length = 0;
    }

    if (data->textBuffer[*index] == ':') {
        CheckBorderSpaces(data->textBuffer, &data->prev_el_index, *index, &data->element_length);
        char* attr_name = RewriteWord(data->textBuffer, *index, data->prev_el_index, data->element_length);

        data->element_length = 0;
        data->prev_el_index = *index + 1;
        data->current_counting = ATTR_VALUE;
        return attr_name;
    }
    //po sredniku znowu szukana jest nazwa atrybutu 
    //tutaj jest pokazany przypadek konca sekcji po sredniku
    else if (data->textBuffer[*index] == '}') {
        data->element_length = 0;
        data->prev_el_index = *index + 1;
        data->current_position = *index + 1;
        data->break_or_not = true;
        return nullptr;
    }
    else {
        data->element_length++;
        return nullptr;
    }
}

char* ProcessAttributeValue(Data* data, int* index) {
    CheckBorderSpaces(data->textBuffer, &data->prev_el_index, *index, &data->element_length);
    char* attr_value = RewriteWord(data->textBuffer, *index, data->prev_el_index, data->element_length);
    //na nastepny raz resetujemy do ATTR_NAME
    data->current_counting = ATTR_NAME;
    return attr_value;
}


AttributeList* EnterAttributeValueMode(Data* data, int* index, AttributeList* attributeList, char* attr_name) {
    char* attr_value;
    if (data->textBuffer[*index] == '\n' || data->textBuffer[*index] == '\r' || data->textBuffer[*index] == '\0') {
        attr_value = ProcessAttributeValue(data, index);
        attributeList = AddAttributeToTheList(attributeList, attr_name, attr_value);

        fgets(data->textBuffer, TEXT_BUFFER_SIZE, stdin);
        *index = 0;
        while (data->textBuffer[*index] != '}') {
            (*index)++;
        }

        data->element_length = 0;
        data->prev_el_index = *index + 1;
        data->current_position = *index + 1;
        //break;
        data->break_or_not = true;
    }
    else if (data->textBuffer[*index] == ';') {
        attr_value = ProcessAttributeValue(data, index);
        attributeList = AddAttributeToTheList(attributeList, attr_name, attr_value);

        data->element_length = 0;
        data->prev_el_index = *index + 1;
    }
    else if (data->textBuffer[*index] == '}') {
        attr_value = ProcessAttributeValue(data, index);
        attributeList = AddAttributeToTheList(attributeList, attr_name, attr_value);

        data->element_length = 0;
        data->prev_el_index = *index + 1;
        data->current_position = *index + 1;
        //break;
        data->break_or_not = true;
    }
    else {
        data->element_length++;
    }
    return attributeList;
}

AttributeList* EnterAttributeMode(AttributeList* attributeList, Data* data) {
    char* attr_name = nullptr;
    char* attr_value = nullptr;

    //wczytanie atrybutow i ich wartosci
    for (int i = data->current_position; i < TEXT_BUFFER_SIZE; i++) {
        if (data->current_counting == ATTR_NAME) {
            attr_name = EnterAttributeNameMode(data, &i);
            if (data->break_or_not == true) {
                data->break_or_not = false;
                break;
            }
        }
        else {
            attributeList = EnterAttributeValueMode(data, &i, attributeList, attr_name);
            if (data->break_or_not == true) {
                data->break_or_not = false;
                break;
            }
        }

    }
    return attributeList;
}