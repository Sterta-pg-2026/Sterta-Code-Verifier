#include "section.h"
#include "selectorlist.h"
#include "attributelist.h"
#include "list.h"





Section::~Section(){
	SelectorList* tmp1 = (SelectorList*)this->sList->next;
	SelectorList* tmp2;
	while (tmp1 != nullptr){
		tmp2 = (SelectorList*)tmp1->next;
		delete tmp1;
		tmp1 = tmp2;
	} 

	AttributeList* tmp3 = (AttributeList*)this->aList->next;
	AttributeList* tmp4;
	while (tmp3 != nullptr) {
		tmp4 = (AttributeList*)tmp3->next;
		delete tmp3;
		tmp3 = tmp4;
	} 

	this->sectionNumber = 0;
}
