//
//  Section.h
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#ifndef Section_h
#define Section_h

#include "selectorlist.h"
#include "attributelist.h"

class Section {
    public: 
        int sectionNumber = 0;
        SelectorList* sList;
        AttributeList* aList;

        ~Section();
};

#endif /* Section_h */
