//
//  MainList.h
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#ifndef MainList_h
#define MainList_h
#include "list.h"
#include "section.h"

class MainList: public List {
    public:
        Section sections[T];
        int emptySlots;
        
        MainList();
        void AddSection(SelectorList* list1, AttributeList* list2, int* sectionHighestNumber);
        int LookForSpot(Section array[T]);
        ~MainList();
};

#endif /* MainList_h */
