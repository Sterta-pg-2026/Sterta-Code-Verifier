//
//  SelectorList.cpp
//  CSS tool
//
//  Created by Bartłomiej Kruszyński on 31/03/2023.
//

#include <stdio.h>
#include "selectorlist.h"

SelectorList::SelectorList(char* selector){
    this->selector = selector;
}

char* SelectorList::getSelector() {
    return this->selector;
}



SelectorList::~SelectorList(){
    delete[] selector;
}
