#include <iostream>
#include "list.h"
#include "mainlist.h"
#include "selectorlist.h"
#include "data.h"
#include "functions.h"
#include <cstdlib>
using namespace std;









char* FindSelectorBySelectorNumber(SelectorList* selectorList, int selectorNumber) {
    if (strcmp(selectorList->getSelector(),"") == EQUAL) {
        return nullptr;
    }
    else {
        SelectorList* tmp = (SelectorList*)selectorList;
        for (int i = 1; i < selectorNumber; i++) {
            if (tmp->next == nullptr) {
                //brak takiego numeru 
                return nullptr;
            }
            tmp = (SelectorList*)tmp->next;
        }
        return tmp->getSelector();
    }
}

//czy w danej liscie selektorow istnieje podany selektor
bool DoesSelectorExist(SelectorList* selectorList, char* selector) {
    //atrybuty stosowane do wszystkiego, wiec jest tam tez "wirtualny" char* selector
    if (strcmp(selectorList->getSelector(), "") == EQUAL) {
        return true;
    }
    else {
        SelectorList* tmp = selectorList;
        while (tmp != nullptr) {
            if (strcmp(tmp->getSelector(), selector) == EQUAL) {
                return true;
            }
            tmp = (SelectorList*)tmp->next;
        }
        return false;
    }
}

//zwraca wartosc ostatniego wystapienia danego atrybutu w liscie
char* FindAttributeValue(AttributeList* attributeList, char* attr_name) {
    char* tmp_attr_name = nullptr;
    AttributeList* tmp = attributeList;
    while (tmp != nullptr) {
        if (strcmp(tmp->getName(), attr_name) == EQUAL) {
            tmp_attr_name = tmp->getValue();
        }
        tmp = (AttributeList*)tmp->next;
    }
    return tmp_attr_name;
}


Section* FindSection(MainList* mainList, int sectionNumber, MainList* found_selection_parent_return) {
    for (int i = 0; i < T; i++) {
        if (mainList->sections[i].sectionNumber == sectionNumber) {
            found_selection_parent_return = mainList;
            return &mainList->sections[i];
        }
    }
    if (mainList->next != nullptr) {
        //jak nie bedzie w pierwszej sekcji to szukamy w nastepnych
        found_selection_parent_return = nullptr;
        return FindSection((MainList*)mainList->next, sectionNumber, found_selection_parent_return);
    }
    else {
        found_selection_parent_return = nullptr;
        return nullptr;
    }
}


char* FindAttributeValueForSelector(MainList* mainList, char* selector, char* attr_name) {
    MainList* tmp;
    tmp = mainList;
    
    char* attr_value = nullptr;
    for (int i = 0; i < T; i++) {
        if (tmp->sections[i].sectionNumber != 0) {
            if (DoesSelectorExist(tmp->sections[i].sList, selector)) {
                attr_value = FindAttributeValue(tmp->sections[i].aList, attr_name);
            }
        }
    }

    if (attr_value != nullptr) {
        return attr_value;
    }

    if (tmp->next != nullptr) {
        return attr_value = FindAttributeValueForSelector((MainList*)tmp->next, selector, attr_name);
    }
    else {
        return attr_value;
    }
}




int CountSelectors(SelectorList* selectorList) {
    SelectorList* tmp = selectorList;
    int i = 0;
    while (tmp != nullptr) {
        i++;
        tmp = (SelectorList*)tmp->next;
    }
    return i;
}

int CountSelectors(SelectorList* selectorList, char* selector) {
    SelectorList* tmp = selectorList;
    int i = 0;
    while (tmp != nullptr) {
        if (strcmp(tmp->getSelector(), selector) == EQUAL) {
            i++;
        }
        tmp = (SelectorList*)tmp->next;
    }
    return i;
}

int CountSelector(MainList* mainList, char* selector) {
    int number = 0;
    Section* tmp;
    for (int i = 0; i < T; i++) {
        tmp = &mainList->sections[i];
        if (tmp->sectionNumber != EMPTY_SECTION_SLOT_NUMBER) {
            number += CountSelectors(tmp->sList, selector);
        }
    }

    //jak jest nastepny mainlist to dodajemy wystapienia z niego
    if (mainList->next != nullptr) {
        return number += CountSelector((MainList*)mainList->next, selector);
    }
    //w przeciwnym wypadku zwracamy to co policzylismy w 1 mainliscie
    else {
        return number;
    }
}

int CountAttributes(AttributeList* attributeList) {
    AttributeList* tmp = attributeList;
    int i = 0;
    while (tmp != nullptr) {
        i++;
        tmp = (AttributeList*)tmp->next;
    }
    return i;
}

int CountAttributes(AttributeList* attributeList, char* attr_name) {
    AttributeList* tmp = attributeList;
    int i = 0;
    while (tmp != nullptr) {
        if (strcmp(tmp->getName(), attr_name) == EQUAL) {
            i++;
            return i;
        }
        tmp = (AttributeList*)tmp->next;
    }
    return i;
}

int CountAttribute(MainList* mainList, char* attr_name) {
    int number = 0;
    Section* tmp;
    for (int i = 0; i < T; i++) {
        tmp = &mainList->sections[i];
        if (tmp->sectionNumber != EMPTY_SECTION_SLOT_NUMBER) {
            number += CountAttributes(tmp->aList, attr_name);
        }
    }

    //jak jest nastepny mainlist to dodajemy wystapienia z niego
    if (mainList->next != nullptr) {
        return number += CountAttribute((MainList*)mainList->next, attr_name);
    }
    //w przeciwnym wypadku zwracamy to co policzylismy w 1 mainliscie
    else {
        return number;
    }
}

void PrintAnswer(char* command, int answer) {
    int len = strlen(command);
    command[len - 1] = '\0';
    printf("%s == %d\n", command, answer);
}

void PrintAnswer(char* command, char* answer) {
    int len = strlen(command);
    command[len - 1] = '\0';
    printf("%s == %s\n", command, answer);
}

void PrintAnswer(char* command, const char* answer) {
    int len = strlen(command);
    command[len - 1] = '\0';
    printf("%s == %s\n", command, answer);
}

char* GetFirstArgumentInChar(char* command, int element_length, int right_border) {
    return RewriteWord(command, right_border+1, FIRST_CHARACTER_SPOT, element_length+1);
}

int GetFirstArgumentInInt(char* command, int element_length, int right_border) {
    return atoi(GetFirstArgumentInChar(command, element_length, right_border));
}
char* GetThirdArgumentInChar(char* command, int first_comma_position, int prev_element_length) {
    //+3 bo chcemy miejsce po drugim przecinku
    //+1 bo first_comman_position jest liczone od zera
    int prev_el_index = first_comma_position + 3;
    //-1 poniewaz nie chcemy entera na koncu 
    int right_border = strlen(command) - 1;
    int element_length = strlen(command) - prev_el_index - 1;
    return RewriteWord(command, right_border, prev_el_index, element_length);
}

int GetThirdArgumentInInt(char* command, int first_comma_position, int prev_element_length) {
    return atoi(GetThirdArgumentInChar(command, first_comma_position, prev_element_length));
}

void GetNewCommandLine(Data* data) {
    fgets(data->textBuffer, TEXT_BUFFER_SIZE, stdin);
    data->prev_el_index = 0;
    data->element_length = 0;
}

void GetNewCommandLine(Data* data, int* index) {
    GetNewCommandLine(data);
    *index = 0;
}


void ReduceSectionNumbers(MainList* mainList, int prev_section_number) {
    Section* tmp;
    for (int i = 0; i < T; i++) {
        tmp = &mainList->sections[i];
        if (tmp->sectionNumber != EMPTY_SECTION_SLOT_NUMBER && tmp->sectionNumber > prev_section_number) {
            tmp->sectionNumber--;
        }
    }

    if (mainList->next != nullptr) {
        ReduceSectionNumbers((MainList*)mainList->next, prev_section_number);
    }
}

void DeleteSection(Data* data, int* index, Section* section, MainList* mainList, MainList* mainList_tmp) {
    if (section != nullptr){
        int old_section_number = section->sectionNumber;
        ReduceSectionNumbers(mainList, old_section_number);
        delete section;
        mainList_tmp->emptySlots++;
        if (mainList_tmp->emptySlots == T) {
            mainList = (MainList*)mainList->RemoveNode(mainList, mainList_tmp);
        }
    }
}

void EnterCommandMode(MainList* mainList, Data* data) {
    char* tmp;
    char* z_string;
    char* n_string;
    int i_number = 0;
    int j_number = 0;
    int prev_section_number = 0;
    Section* section = nullptr;
    AttributeList* attr = nullptr;
    AttributeList* attr2 = nullptr;
    MainList* mainList_tmp = nullptr;

    GetNewCommandLine(data);

    for (int i = data->current_position; i < TEXT_BUFFER_SIZE; i++) {
        if (data->textBuffer[i] == '\n' || data->textBuffer[i] == '\r' || data->textBuffer[i] == '\0') {
            //kiedy jest pusta linijka to ja pomijamy
            GetNewCommandLine(data, &i);
        }

        if (data->textBuffer[0] == '*' && data->textBuffer[1] == '*') {
            GetNewCommandLine(data);
            return;
        }
        else if (data->textBuffer[0] == '?'){
            cout << "? == " << data->sectionHighestNumber << endl;
            GetNewCommandLine(data, &i);
        }
        else if (data->textBuffer[i] == ',') {
            if (data->textBuffer[i + 1] == 'S') {
                //i,S
                if (data->textBuffer[0] >= '0' && data->textBuffer[0] <= '9') {
                    i_number = GetFirstArgumentInInt(data->textBuffer, data->element_length, i);
                    Section* section = FindSection(mainList, i_number, mainList_tmp);
                    if (section != nullptr) {
                        //i,S,?
                        if (data->textBuffer[i + 3] == '?') {
                            //wypisz liczbe selektorow dla sekcji nr i
                            PrintAnswer(data->textBuffer, CountSelectors(section->sList));
                        }
                        //i,S,j
                        else {
                            j_number = GetThirdArgumentInInt(data->textBuffer, i, data->element_length);
                            tmp = FindSelectorBySelectorNumber(section->sList, j_number);
                            if (tmp != nullptr) {
                                PrintAnswer(data->textBuffer, tmp);
                            }
                        }
                    }
                }
                //z,S,?
                else {
                    z_string = GetFirstArgumentInChar(data->textBuffer, data->element_length, i);
                    PrintAnswer(data->textBuffer, CountSelector(mainList, z_string));
                }
            }
            else if (data->textBuffer[i + 1] == 'A') {
                //i,A
                if (data->textBuffer[0] >= '0' && data->textBuffer[0] <= '9') {
                    i_number = GetFirstArgumentInInt(data->textBuffer, data->element_length, i);
                    section = FindSection(mainList, i_number, mainList_tmp);
                    if (section != nullptr) {
                        //i,A,?
                        if (data->textBuffer[i + 3] == '?') {
                            PrintAnswer(data->textBuffer, CountAttributes(section->aList));
                        }
                        //i,A,n
                        else {
                            n_string = GetThirdArgumentInChar(data->textBuffer, i, data->element_length);
                            tmp = FindAttributeValue(section->aList, n_string);
                            if (tmp != nullptr) {
                                PrintAnswer(data->textBuffer, tmp);
                            }
                        }
                    }
                }
                //n,A,?
                else {
                    n_string = GetFirstArgumentInChar(data->textBuffer, data->element_length, i);
                    PrintAnswer(data->textBuffer, CountAttribute(mainList, n_string));
                }
            }
            //z,E,n
            else if (data->textBuffer[i + 1] == 'E') {
                z_string = GetFirstArgumentInChar(data->textBuffer, data->element_length, i);
                n_string = GetThirdArgumentInChar(data->textBuffer, i, data->element_length);
                tmp = FindAttributeValueForSelector(mainList, z_string, n_string);
                if (tmp != nullptr) {
                    PrintAnswer(data->textBuffer, tmp);
                }
            }
            //i,D
            else {
                i_number = GetFirstArgumentInInt(data->textBuffer, data->element_length, i);
                section = FindSection(mainList, i_number, mainList_tmp);
                //i,D,*
                if (section != nullptr) {
                    if (data->textBuffer[i + 3] == '*') {
                        DeleteSection(data, &i, section, mainList, mainList_tmp);
                        PrintAnswer(data->textBuffer, DELETED_INFO);
                    }
                    //i,D,n
                    else {
                        n_string = GetThirdArgumentInChar(data->textBuffer, i, data->element_length);
                        attr2 = section->aList;
                        while (attr2 != nullptr) {
                            attr = attr2->FindNodeWithName(n_string);
                            if (attr != nullptr) {
                                (attr->prev)->next = (AttributeList*)attr->next;
                                (attr->next)->prev = (AttributeList*)attr->prev;
                                attr2 = (AttributeList*)attr->next;
                                delete attr;
                            }
                        }
                        if (section->aList == nullptr) {
                            DeleteSection(data, &i, section, mainList, mainList_tmp);
                        }
                    }
                }
                
            }



            GetNewCommandLine(data, &i);
        }
        else {
            data->element_length++;
        }
    }
}
