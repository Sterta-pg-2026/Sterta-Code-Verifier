#include "list.h"


List* List::GetLast(List* firstNode){
    if(firstNode == nullptr){
        return nullptr;
    }
    List* tmp = firstNode;
    
    while(tmp->next != nullptr){
        tmp = tmp->next;
    }
    return tmp;
}

List* List::AddLast(List* firstNode, List* newNode){
    List* last = GetLast(firstNode);
    
    if(last == nullptr){
        newNode->prev = nullptr;
        newNode->next = nullptr;
        return newNode;
    }
    else {
        newNode->prev = last;
        last->next = newNode;
    }
    return firstNode;
}

List* List::AddFirst(List* firstNode, List* newNode){
    newNode->next = firstNode;
    newNode->prev = nullptr;
    if(firstNode != nullptr){
        firstNode->prev = newNode;
    }
    return newNode;
}

List* List::RemoveNode(List* firstNode, List* node){
    if (node == nullptr) {
        return firstNode;
    }
    if(node->next == nullptr && node->prev == nullptr && node == firstNode){
        //firstnode == node
        //ostatni node
        delete node;
        return nullptr;
    }
    if(node->prev == nullptr){
        (node->next)->prev = nullptr;
        List* tmp = node->next;
        delete node;
        return tmp;
    }
    if (node->next != nullptr) {
        (node->next)->prev = node->prev;
    }
    (node->prev)->next = node->next;
    delete node;
    return firstNode;
}

List* List::RemoveFirst(List* firstNode){
    return RemoveNode(firstNode, firstNode);
}

List* List::RemoveLast(List* firstNode){
    List* last = GetLast(firstNode);
    return RemoveNode(firstNode, last);
}
