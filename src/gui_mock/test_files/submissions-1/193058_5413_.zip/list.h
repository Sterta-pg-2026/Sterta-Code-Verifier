#pragma once

#include "constants.h"
#include <stddef.h>

class List {
    public:
        List* prev;
        List* next;
    

        List* GetLast(List* firstNode);
            
        List* AddLast(List* firstNode, List* newNode);
        
        List* AddFirst(List* firstNode, List* newNode);
        
        List* RemoveNode(List* firstNode, List* node);
        
        List* RemoveFirst(List* firstNode);
        
        List* RemoveLast(List* firstNode);
    
};


































