#include "parser.h"
#include <iostream>

int main()
{
	char command;
	Parser* parser = new Parser();
	while (cin.get(command))
	{
		parser->Parse(command);
	}
	delete parser;
}