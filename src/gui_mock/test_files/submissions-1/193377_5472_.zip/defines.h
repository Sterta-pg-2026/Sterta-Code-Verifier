#pragma once
#define T 17
#define BUFFER_SIZE 128