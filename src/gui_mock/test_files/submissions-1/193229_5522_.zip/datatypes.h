#pragma once
#include "list2d.h"


const int T = 3;
#include "attribute.h"
#include "selector.h"
#include "section.h"







