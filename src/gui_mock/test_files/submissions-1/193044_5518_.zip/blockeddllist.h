#pragma once

#include <utility>
#include <exception>

#define BLOCK_SIZE 29

template<typename T>
class BlockedDLListNode {
public:
    explicit BlockedDLListNode(T&& value, BlockedDLListNode<T>* prev = nullptr, BlockedDLListNode<T>* next = nullptr) {
        this->arr[0] = value;
        this->taken = 1;
        this->prev = prev;
        this->next = next;
        this->exists[0] = true;
        for (int i = 1; i < BLOCK_SIZE; ++i) {
            this->exists[i] = false;
        }
    }
    bool HasSpace() const {
        return this->taken < BLOCK_SIZE;
    }
    bool IsEmpty() const {
        return deleted == BLOCK_SIZE;
    }
    void AddValue(T&& value) {
        arr[taken] = std::move(value);
        exists[taken] = true;
        taken++;
    }
    T* GetAt(size_t index) {
        if (index >= BLOCK_SIZE) {
            throw std::exception("Index is larger than block size");
        }
        if (index >= taken + 1) {
            throw std::exception("Index is larger than number of elements in block");
        }
        if (!exists[index]) {
            throw std::exception("Cannot directly access removed element");
        }
        return &arr[index];
    }
    T* GetAtPosition(size_t pos) {
        size_t counter = 0;
        for (int i = 0; i < BLOCK_SIZE; ++i) {
            if (exists[i]) {
                counter++;
            }

            if (exists[i] && counter == pos) {
                return &arr[i];
            }
        }
        return nullptr;
    }
    void RemoveAt(size_t index) {
        if (index >= BLOCK_SIZE) {
            throw std::exception("Index is larger than block size");
        }

        if (index >= taken + 1) {
            throw std::exception("Index is larger than number of elements in block");
        }

        exists[index] = false;
        deleted++;
    }
    bool RemoveAtPosition(size_t pos) {
        size_t counter = 0;
        for (int i = 0; i < BLOCK_SIZE; ++i) {
            if (exists[i]) {
                counter++;
            }

            if (exists[i] && counter == pos) {
                RemoveAt(i);
                return true;
            }
        }
        return false;
    }
    bool Exists(size_t index) const {
        if (index >= BLOCK_SIZE) {
            throw std::exception("Index is larger than block size");
        }

        return exists[index];
    }
    T* GetLast() {
        for (int i = BLOCK_SIZE - 1; i >= 0; --i) {
            if (exists[i]) {
                return &arr[i];
            }
        }
        return nullptr;
    }
    size_t GetNumberOfItems() const {
        size_t counter = 0;
        for (int i = 0; i < BLOCK_SIZE; ++i) {
            if (exists[i]) {
                counter++;
            }
        }
        return counter;
    }
    T arr[BLOCK_SIZE];
    bool exists[BLOCK_SIZE];
    size_t taken = 0;
    size_t deleted = 0;
    BlockedDLListNode<T>* next;
    BlockedDLListNode<T>* prev;
};

template<typename T>
class BlockedDLList {
public:
    BlockedDLList() {
        this->head = nullptr;
        this->bottom = nullptr;
        this->numberOfItems = 0;
        this->length = 0;
    }
    BlockedDLList(const BlockedDLList& list) : BlockedDLList() {
        BlockedDLListNode<T>* current = list.head;
        while (current != nullptr) {
            for (int i = 0; i < BLOCK_SIZE; ++i) {
                if (current->exists[i]) {
                    AddAtBack(std::move(current->arr[i]));
                }
            }
            current = current->next;
        }
    }
    BlockedDLList(BlockedDLList&& list) noexcept {
        this->head = std::exchange(list.head, nullptr);
        this->bottom = std::exchange(list.bottom, nullptr);
        this->length = std::exchange(list.length, 0);
        this->numberOfItems = std::exchange(list.numberOfItems, 0);
    }
    BlockedDLList& operator=(const BlockedDLList& list) {
        BlockedDLList tmp(list);
        std::swap(*this, tmp);
        return *this;
    }
    BlockedDLList& operator=(BlockedDLList&& list) noexcept {
        std::swap(this->head, list.head);
        std::swap(this->bottom, list.bottom);
        return *this;
    }
    ~BlockedDLList() {
        BlockedDLListNode<T>* current = bottom;
        while(current != nullptr) {
            BlockedDLListNode<T>* tmp = current->prev;
            delete current;
            current = tmp;
        }
    }
    void AddAtBack(T&& element) {
        numberOfItems++;
        length++;

        if (head == nullptr) {
            head = new BlockedDLListNode<T>(std::move(element));
            bottom = head;
            return;
        }

        if (bottom->HasSpace()) {
            bottom->AddValue(std::move(element));
            return;
        }

        bottom->next = new BlockedDLListNode<T>(std::move(element), bottom);
        bottom = bottom->next;
    }
    T* GetLast() {
        return bottom->GetLast();
    }
    T* GetAt(size_t index) const {
        size_t numberOfBlocksToSkip = index / BLOCK_SIZE;
        BlockedDLListNode<T>* current;
        current = head;
        for (size_t i = 0; i < numberOfBlocksToSkip; ++i) {
            if (current->next == nullptr) {
                return nullptr;
            }
            current = current->next;
        }

        if (current->Exists(index % BLOCK_SIZE)) {
            return current->GetAt(index % BLOCK_SIZE);
        }

        return nullptr;
    }
    T* GetAtPosition(size_t pos) {
        BlockedDLListNode<T>* current = head;
        size_t skippedElements = 0;
        while(current != nullptr) {
            if(skippedElements + current->GetNumberOfItems() >= pos) {
                return current->GetAtPosition(pos - skippedElements);
            }else {
                skippedElements += current->GetNumberOfItems();
                current = current->next;
            }
        }
        return nullptr;
    }
    void RemoveAt(size_t index) {
        size_t numberOfBlocksToSkip = index / BLOCK_SIZE;
        BlockedDLListNode<T>* current = head;

        for (size_t i = 0; i < numberOfBlocksToSkip; ++i) {
            if (current->next == nullptr) {
                throw std::exception("Element could not be found.");
            }
            current = current->next;
        }

        current->RemoveAt(index % BLOCK_SIZE);
        numberOfItems--;

        if (current->IsEmpty()) {
            BlockedDLListNode<T>* parent = current->prev;
            BlockedDLListNode<T>* child = current->next;
            if (head == current && child != nullptr) {
                head = child;
            }
            if (parent != nullptr) {
                parent->next = child;
            }
            if (child != nullptr) {
                child->prev = parent;
            }
            if (bottom == current && child != nullptr) {
                bottom = child;
            }
            if (bottom == current && child == nullptr) {
                bottom = parent;
            }
        }
    }
    bool RemoveAtPosition(size_t pos) {
        BlockedDLListNode<T>* current = head;
        size_t skippedElements = 0;
        while(current != nullptr) {
            if(skippedElements + current->GetNumberOfItems() >= pos) {
                if (current->RemoveAtPosition(pos - skippedElements)) {
                    numberOfItems--;
                    return true;
                }else {
                    return false;
                }
            }else {
                skippedElements += current->GetNumberOfItems();
                current = current->next;
            }
        }
        return false;
    }
    size_t GetLength() const {
        return this->length;
    }
    size_t GetNumberOfItems() const {
        return this->numberOfItems;
    }
private:
    BlockedDLListNode<T>* head;
    BlockedDLListNode<T>* bottom;
    size_t numberOfItems;
    size_t length;
};

