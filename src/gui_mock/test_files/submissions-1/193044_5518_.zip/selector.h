#pragma once

#include "string.h"

class Selector {
public:
    Selector();
    explicit Selector(const char* source);
    Selector(const char* source, size_t length);
    bool Equals(const String& str) const;
    bool Equals(const Selector& other) const;
    friend std::ostream& operator<<(std::ostream& os, const Selector& selector);
private:
    String value;
};