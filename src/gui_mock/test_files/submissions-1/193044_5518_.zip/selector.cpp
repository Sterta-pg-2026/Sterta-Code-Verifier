#include "selector.h"

Selector::Selector() = default;

Selector::Selector(const char *source) {
    this->value = String::GetTrimmed(source, strlen(source));
}

Selector::Selector(const char *source, size_t length) {
    this->value = String::GetTrimmed(source, length);
}

std::ostream& operator<<(std::ostream &os, const Selector &selector) {
    os << selector.value;
    return os;
}

bool Selector::Equals(const String &str) const {
    return this->value.Equals(str);
}

bool Selector::Equals(const Selector &other) const {
    return this->value.Equals(other.value);
}
