#pragma once

#include "string.h"

class Attribute {
public:
    Attribute();
    Attribute(const char* property, const char* value);
    Attribute(const char* source, size_t length);
    bool NameEquals(const String& str) const;
    friend std::ostream& operator<<(std::ostream& os, const Attribute& atr);
    String property;
    String value;
};
