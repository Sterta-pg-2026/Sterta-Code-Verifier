#pragma once

enum ParserMode {
    SelectorInsertion,
    AttributeInsertion,
    Query
};