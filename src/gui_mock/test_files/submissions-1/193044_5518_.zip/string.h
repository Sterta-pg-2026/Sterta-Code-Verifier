#pragma once

#include <iostream>

class String {
public:
    String();
    explicit String(const char* source, size_t length);
    explicit String(const char* source, size_t length, size_t skip);
    String(const String& str);
    String(String&& str) noexcept;
    explicit String(const char *string);
    String& operator=(const String& str);
    String& operator=(String&& str) noexcept;
    bool Equals(const String& other) const;
    bool Equals(const char* other) const;
    int ToInt() const;
    bool IsInt() const;
    bool IsEmpty() const;
    String GetFirstPart() const;
    String GetLastPart() const;
    char GetMode() const;
    friend std::ostream& operator<<(std::ostream& os, const String& str);
    ~String();
    static String GetTrimmed(const char* source, size_t length, size_t skip = 0);
private:
    char* arr;
    size_t len;
};
