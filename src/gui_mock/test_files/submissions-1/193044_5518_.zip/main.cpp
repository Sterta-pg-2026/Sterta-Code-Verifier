#include <iostream>
#include "parser.h"

int main()
{
    std::ios_base::sync_with_stdio(false);

    Parser parser = Parser();
    parser.Execute();
}
