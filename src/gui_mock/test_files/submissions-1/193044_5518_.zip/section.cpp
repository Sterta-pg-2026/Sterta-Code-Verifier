#include "section.h"
#include "blockeddllist.h"

Section::Section() {
    this->selectors = BlockedDLList<Selector>();
    this->attributes = BlockedDLList<Attribute>();
}

void Section::AddAttribute(Attribute&& attribute) {
    for (int i = 0; i < this->attributes.GetLength(); ++i) {
        Attribute* atr = this->attributes.GetAt(i);
        if (atr != nullptr && atr->NameEquals(attribute.property)) {
            this->attributes.RemoveAt(i);
        }
    }
    this->attributes.AddAtBack(std::move(attribute));
}

void Section::AddSelector(Selector&& selector) {
    for (int i = 0; i < this->selectors.GetLength(); ++i) {
        Selector* sel = this->selectors.GetAt(i);
        if (sel != nullptr && sel->Equals(selector)) {
            return;
        }
    }
    this->selectors.AddAtBack(std::move(selector));
}

size_t Section::GetNumberOfSelectors() const {
    return this->selectors.GetNumberOfItems();
}

size_t Section::GetNumberOfSelectors(const String& string) const {
    size_t sum = 0;
    for (int i = 0; i < this->selectors.GetLength(); ++i) {
        Selector* sel = this->selectors.GetAt(i);
        if (sel != nullptr && sel->Equals(string)) {
            sum++;
        }
    }
    return sum;
}

Selector* Section::GetSelectorAtPosition(size_t i) {
    return selectors.GetAtPosition(i);
}

size_t Section::GetNumberOfAttributes() const {
    return this->attributes.GetNumberOfItems();
}

size_t Section::GetNumberOfAttributes(const String& string) const {
    size_t sum = 0;
    for (int i = 0; i < this->attributes.GetLength(); ++i) {
        Attribute* atr = this->attributes.GetAt(i);
        if (atr != nullptr && atr->NameEquals(string)) {
            sum++;
        }
    }
    return sum;
}

String* Section::GetAttributeValue(const String &string) {
    for (int i = 0; i < this->attributes.GetLength(); ++i) {
        Attribute* atr = this->attributes.GetAt(i);
        if (atr != nullptr && atr->NameEquals(string)) {
            return &atr->value;
        }
    }
    return nullptr;
}

bool Section::ContainsSelector(const String& string) const {
    for (int i = 0; i < this->selectors.GetLength(); ++i) {
        Selector* sel = this->selectors.GetAt(i);
        if (sel != nullptr && sel->Equals(string)) {
            return true;
        }
    }
    return false;
}

bool Section::RemoveAttribute(const String &string) {
    for (int i = 0; i < this->attributes.GetLength(); ++i) {
        Attribute* atr = this->attributes.GetAt(i);
        if (atr != nullptr && atr->NameEquals(string)) {
            this->attributes.RemoveAt(i);
            return true;
        }
    }
    return false;
}

bool Section::IsEmpty() const {
    return this->attributes.GetNumberOfItems() == 0;
}
