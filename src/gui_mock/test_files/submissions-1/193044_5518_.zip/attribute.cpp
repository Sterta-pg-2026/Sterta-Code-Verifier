#include "attribute.h"

Attribute::Attribute() = default;

Attribute::Attribute(const char *property, const char *value) {
    this->property = String(property);
    this->value = String(value);
}

Attribute::Attribute(const char *source, size_t length) {
    for (size_t i = 0; i < length; i++) {
        if (source[i] == ':') {
            this->property = String::GetTrimmed(source, i, 0);
            this->value = String::GetTrimmed(source, length, i + 1);
            break;
        }
    }
}

std::ostream& operator<<(std::ostream &os, const Attribute &atr) {
    os << atr.property << " : " << atr.value;
    return os;
}

bool Attribute::NameEquals(const String &str) const {
    return this->property.Equals(str);
}
