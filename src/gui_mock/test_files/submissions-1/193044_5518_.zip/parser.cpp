#include "parser.h"
#include "string.h"
#include "attribute.h"
#include "selector.h"
#include "section.h"

#define BUFFER_SIZE 1024

Parser::Parser() {
    this->buffer = new char[BUFFER_SIZE];
    this->bufferPos = 0;
    this->mode = SelectorInsertion;
    this->continuousSequence = 0;
    this->sections = BlockedDLList<Section>();
}

Parser::Parser(Parser&& other) noexcept {
    this->buffer = std::exchange(other.buffer, nullptr);
    this->bufferPos = std::exchange(other.bufferPos, 0);
    this->continuousSequence = std::exchange(other.continuousSequence, 0);
    this->mode = std::exchange(other.mode, SelectorInsertion);
    this->sections = std::exchange(other.sections, BlockedDLList<Section>());
}

void Parser::Execute() {
    sections.AddAtBack(Section());
    Section* currentSection = sections.GetLast();
    while(std::cin.get(this->buffer[bufferPos++])) {
        char c = GetLastCharacter();

        if (IsWhitespace(c)) {
            RemoveLastCharacter();
            continue;
        }

        CheckIfSequenceIsContinuous();

        if (ShouldChangeModeToQuery()) {
            this->mode = Query;
            ResetBuffer();
            continue;
        }

        if (ShouldChangeModeToSelectorInsertion()) {
            this->mode = SelectorInsertion;
            ResetBuffer();
            continue;
        }

        if (mode == SelectorInsertion && c == ';') {
            ResetBuffer();
            continue;
        }

        if (mode == SelectorInsertion && (c == ',' || c == '{')) {
            if (this->IsBufferPending()) {
                currentSection->AddSelector(Selector(buffer, bufferPos - 1));
                ResetBuffer();
            }
        }

        if (mode == SelectorInsertion && c == '{') {
            this->mode = AttributeInsertion;
            ResetBuffer();
        }

        if (mode == AttributeInsertion && (c == ';' || c == '}') && bufferPos != 1) {
            currentSection->AddAttribute(Attribute(buffer, bufferPos - 1));
            ResetBuffer();
        }

        if (mode == AttributeInsertion && c == '}') {
            sections.AddAtBack(Section());
            currentSection = sections.GetLast();
            this->mode = SelectorInsertion;
            ResetBuffer();
        }

        if (mode == Query && c == '\n' && bufferPos <= 1) {
            RemoveLastCharacter();
            continue;
        }

        if (mode == Query && c == '\n') {
            this->HandleQuery();
        }
    }
    if (mode == Query && this->IsBufferPending()) {
        HandleQuery();
    }
}

void Parser::HandleQuery() {
    String command = String(buffer, bufferPos - 1);
    if (command.Equals("?")) {
        std::cout << command << " == " << sections.GetNumberOfItems() - 1 << std::endl;
        ResetBuffer();
        return;
    }

    if (command.IsEmpty()) {
        ResetBuffer();
        return;
    }

    char commandMode = command.GetMode();
    String firstPart = command.GetFirstPart();
    String lastPart = command.GetLastPart();

    if (commandMode == 'S') {
        if (lastPart.Equals("?") && firstPart.IsInt()) {
            int i = firstPart.ToInt();
            if (sections.GetLength() >= i + 1) {
                std::cout << command << " == " << sections.GetAtPosition(i)->GetNumberOfSelectors() << std::endl;
            }
        }else if (lastPart.Equals("?")) {
            size_t sum = 0;
            for (int i = 0; i < sections.GetLength() - 1; ++i) {
                Section* sec = sections.GetAt(i);
                if (sec != nullptr) {
                    sum += sec->GetNumberOfSelectors(firstPart);
                }
            }
            std::cout << command << " == " << sum << std::endl;
        }else {
            int i = firstPart.ToInt();
            int j = lastPart.ToInt();
            Section* s = sections.GetAtPosition(i);
            if (s != nullptr) {
                Selector* sel = s->GetSelectorAtPosition(j);
                if (sel != nullptr) {
                    std::cout << command << " == " << *(sel) << std::endl;
                }
            }
        }
    }else if (commandMode == 'A') {
        if (lastPart.Equals("?") && firstPart.IsInt()) {
            int i = firstPart.ToInt();
            Section* s = sections.GetAtPosition(i);
            if (s != nullptr && !s->IsEmpty()) {
                std::cout << command << " == " << s->GetNumberOfAttributes() << std::endl;
            }
        }else if (lastPart.Equals("?")) {
            size_t sum = 0;
            for (int i = 0; i < sections.GetLength() - 1; ++i) {
                Section* s = sections.GetAt(i);
                if (s != nullptr) {
                    sum += s->GetNumberOfAttributes(firstPart);
                }
            }
            std::cout << command << " == " << sum << std::endl;
        }else {
            int i = firstPart.ToInt();
            Section* s = sections.GetAtPosition(i);
            if (s != nullptr) {
                String* str = s->GetAttributeValue(lastPart);
                if (str != nullptr) {
                    std::cout << command << " == " << *(str) << std::endl;
                }
            }
        }
    }else if (commandMode == 'E') {
        for (long long i = sections.GetLength() - 1; i >= 0; i--) {
            Section* s = sections.GetAt(i);
            if (s != nullptr && s->ContainsSelector(firstPart)) {
                String* str = s->GetAttributeValue(lastPart);
                if (str != nullptr) {
                    std::cout << command << " == " << *(str) << std::endl;
                    break;
                }
            }
        }
    }else if (commandMode == 'D') {
        if (lastPart.Equals("*")) {
            int i = firstPart.ToInt();
            if ((long long)sections.GetNumberOfItems() - 1 >= i) {
                if (sections.RemoveAtPosition(i)) {
                    std::cout << command << " == deleted" << std::endl;
                }
            }
        }else {
            int i = firstPart.ToInt();
            if ((long long)sections.GetNumberOfItems() - 1 >= i) {
                Section* section = sections.GetAtPosition(i);
                if (section->RemoveAttribute(lastPart)) {
                    if (section->IsEmpty()) {
                        sections.RemoveAtPosition(i);
                    }
                    std::cout << command << " == deleted" << std::endl;
                }
            }
        }
    }
    ResetBuffer();
}

char Parser::GetLastCharacter() const {
    return this->buffer[bufferPos - 1];
}

bool Parser::IsWhitespace(char c) const {
    if (c < ' ' && c != '\n' && c != '\t') {
        return true;
    }

    if (c == ' ') {
        return false;
    }

    if (this->mode == Query && c == '\n') {
        return false;
    }

    if (c == '\n' || c == '\t') {
        return true;
    }

    return false;
}

void Parser::RemoveLastCharacter() {
    bufferPos--;
}

void Parser::ResetBuffer() {
    bufferPos = 0;
}

void Parser::CheckIfSequenceIsContinuous() {
    if (bufferPos > 0 && buffer[bufferPos - 2] == buffer[bufferPos - 1]) {
        continuousSequence++;
    }else {
        continuousSequence = 1;
    }
}

bool Parser::ShouldChangeModeToQuery() const {
    return mode == SelectorInsertion && continuousSequence >= 4 && GetLastCharacter() == '?';
}

bool Parser::ShouldChangeModeToSelectorInsertion() const {
    return mode == Query && continuousSequence >= 4 && GetLastCharacter() == '*';
}

bool Parser::IsBufferPending() const {
    return bufferPos > 1;
}
