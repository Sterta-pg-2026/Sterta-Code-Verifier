#pragma once

#include "selector.h"
#include "attribute.h"
#include "blockeddllist.h"

class Section {
public:
    Section();
    void AddSelector(Selector&& selector);
    void AddAttribute(Attribute&& attribute);
    size_t GetNumberOfSelectors() const;
    size_t GetNumberOfSelectors(const String& string) const;
    Selector* GetSelectorAtPosition(size_t i);
    size_t GetNumberOfAttributes() const;
    size_t GetNumberOfAttributes(const String& string) const;
    String* GetAttributeValue(const String& string);
    bool ContainsSelector(const String& string) const;
    bool RemoveAttribute(const String& string);
    bool IsEmpty() const;
private:
    BlockedDLList<Selector> selectors;
    BlockedDLList<Attribute> attributes;
};
