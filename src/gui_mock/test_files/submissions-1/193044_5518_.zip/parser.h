#pragma once

#include <iostream>
#include "parsermode.h"
#include "section.h"

class Parser {
public:
    Parser();
    Parser(Parser&& other) noexcept;
    void Execute();
private:
    char* buffer;
    size_t bufferPos;
    ParserMode mode;
    size_t continuousSequence;
    BlockedDLList<Section> sections;
    void HandleQuery();
    bool IsBufferPending() const;
    bool IsWhitespace(char c) const;
    char GetLastCharacter() const;
    void RemoveLastCharacter();
    void ResetBuffer();
    void CheckIfSequenceIsContinuous();
    bool ShouldChangeModeToQuery() const;
    bool ShouldChangeModeToSelectorInsertion() const;
};
