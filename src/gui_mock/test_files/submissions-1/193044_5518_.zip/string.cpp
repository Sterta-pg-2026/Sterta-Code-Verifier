#include "string.h"

String::String() {
    this->arr = new char[1] { '\0' };
    this->len = 0;
}

String::String(const char *source, size_t length) {
    this->len = length;
    this->arr = new char[this->len + 1];
    for (size_t i = 0; i < length; i++) {
        this->arr[i] = source[i];
    }
    this->arr[length] = '\0';
}

String::String(const char *source, size_t length, size_t skip) {
    this->len = length - skip;
    this->arr = new char[this->len + 1];
    for (size_t i = 0; i < this->len; i++) {
        this->arr[i] = source[skip + i];
    }
    this->arr[this->len] = '\0';
}

String::String(const char* string) {
    this->len = strlen(string);
    this->arr = new char[this->len + 2];
    strcpy_s(this->arr, this->len + 1, string);
}

std::ostream& operator<<(std::ostream& os, const String& str) {
    for (size_t i = 0; i < str.len; i++) {
        os << str.arr[i];
    }
    return os;
}

String::~String() {
    delete[] arr;
}

String String::GetTrimmed(const char *source, size_t length, size_t skip) {
    size_t from = 0;
    size_t to = length - 1;

    for (size_t i = skip; i < length; i++) {
        if (source[i] != ' ') {
            from = i;
            break;
        }
    }

    for (size_t i = length-1; i >= from; i--) {
        if (source[i] != ' ') {
            to = i + 1;
            break;
        }
    }

    return String(source, to, from);
}

String::String(const String& str) {
    this->len = str.len;
    this->arr = new char[this->len + 1];
    for (size_t i = 0; i < this->len; ++i) {
        this->arr[i] = str.arr[i];
    }
    this->arr[this->len] = '\0';
}

String::String(String&& str) noexcept {
    this->len = std::exchange(str.len, 0);
    this->arr = std::exchange(str.arr, nullptr);
}

String& String::operator=(const String& str) {
    String tmp(str);
    std::swap(*this, tmp);
    return *this;
}

String& String::operator=(String&& str) noexcept {
    std::swap(this->len, str.len);
    std::swap(this->arr, str.arr);
    return *this;
}

bool String::Equals(const String &other) const {
    if (len != other.len) {
        return false;
    }

    for (int i = 0; i < len; ++i) {
        if (arr[i] != other.arr[i]) {
            return false;
        }
    }

    return true;
}

bool String::Equals(const char *other) const {
    if (len != strlen(other)) {
        return false;
    }

    for (int i = 0; i < len; ++i) {
        if (arr[i] != other[i]) {
            return false;
        }
    }

    return true;
}

int String::ToInt() const {
    return atoi(arr);
}

bool String::IsInt() const {
    for (int i = 0; i < len; ++i) {
        if (arr[i] < 48 || arr[i] > 57) {
            return false;
        }
    }
    return true;
}

String String::GetFirstPart() const {
    for (int i = 0; i < len; ++i) {
        if (arr[i] == ',') {
            return String(arr, i);
        }
    }
    throw std::exception("String::GetFirstPart()  failed");
}

char String::GetMode() const {
    int counter = 0;
    for (int i = 0; i < len; ++i) {
        if (arr[i] == ',' && counter < 2) {
            counter++;
        }
        if (arr[i] == ',' && counter == 2) {
            return arr[i-1];
        }
    }
    throw std::exception("String::GetMode() failed");
}

String String::GetLastPart() const {
    int counter = 0;
    for (int i = 0; i < len; ++i) {
        if (arr[i] == ',' && counter < 1) {
            counter++;
            continue;
        }
        if (arr[i] == ',' && counter == 1) {
            return String(arr, len, i + 1);
        }
    }
    throw std::exception("String::GetLastPart()  failed");
}

bool String::IsEmpty() const {
    for (int i = 0; i < len; ++i) {
        if (arr[i] != ' ' && arr[i] != '\n' && arr[i] != '\t') {
            return false;
        }
    }
    return true;
}