#pragma once
#include <iostream>
#include "atrybut.h"
#include "string.h"
using namespace std;

class NodeA {
public:
    Atrybut atrybut;
    NodeA* next;
    NodeA* prev;
    NodeA(const String& nazwa, const String& value) {
        atrybut.name = nazwa;
        atrybut.value = value;
        next = nullptr;
        prev = nullptr;
    }
};

class Atrybuty {
public:
    NodeA* head;
   Atrybuty() {
        head = nullptr;
    }

   bool repeat(String nazwa)
   {
       NodeA* temp = head;
       while (temp != nullptr)
       {
           if (temp->atrybut.name == nazwa)
               return true;
           temp = temp->next;
       }
       return false;
   }

    void insert(String nazwa, String v) 
    {
        if (repeat(nazwa))
        {
            NodeA* temp = head;
            while (temp != nullptr)
            {
                if (temp->atrybut.name == nazwa)
                {
                    temp->atrybut.value = temp->atrybut.value + ", " + v;
                    return;
                }
                    
                temp = temp->next;
            }
        }
        else
        {
            NodeA* newNode = new NodeA(nazwa, v);
            if (head == nullptr)
            {
                head = newNode;
                return;
            }
            NodeA* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }

    void printList() {
        NodeA* temp = head;
        while (temp != nullptr) {
            cout << temp->atrybut.name << " " << temp->atrybut.value << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};
