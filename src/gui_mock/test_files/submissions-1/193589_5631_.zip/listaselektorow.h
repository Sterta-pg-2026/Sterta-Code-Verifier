#pragma once
#include <iostream>
#include "selektor.h"
#include "string.h"
using namespace std;

class NodeS {
public:
    Selektor selektor;
    NodeS* next;
    NodeS* prev;
    NodeS(String name) {
        selektor.name = name;
        next = nullptr;
        prev = nullptr;
    }
};

class Selektory {
public:
    NodeS* head;
    Selektory() {
        head = nullptr;
    }

    bool repeat(String nazwa)
    {
        NodeS* temp = head;
        while (temp != nullptr)
        {
            if (temp->selektor.name == nazwa)
                return true;
            temp = temp->next;
        }
        return false;
    } 

    void insert(String name) 
    {
        if (repeat(name))
        {
            NodeS* temp = head;
            while (temp != nullptr)
            {
                if (temp->selektor.name == name)
                {
                    return;
                }

                temp = temp->next;
            }
        }
        else
        {
            NodeS* newNode = new NodeS(name);
            if (head == nullptr) 
            {
                head = newNode;
                return;
            }
            NodeS* temp = head;
            while (temp->next != nullptr) 
            {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }

    void printList() {
        NodeS* temp = head;
        while (temp != nullptr) {
            cout << temp->selektor.name << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};
