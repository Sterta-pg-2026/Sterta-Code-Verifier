#pragma once
#include <iostream>
#include "sekcja.h"
#include "string.h"
#define T 8
using namespace std;

class NodeSekcja {
public:
    Sekcja* sekcja;
    NodeSekcja* next;
    NodeSekcja* prev;
    NodeSekcja()
    {
        next = nullptr;
        prev = nullptr;
        sekcja = new Sekcja[T];
    }

    void insertSelector(String name, int index) {
        sekcja[index].insertSelector(name);
    }
    void insertAttribute(String name, String value, int index) {
        sekcja[index].insertAttribute(name, value);
    }
};

class listaSekcji 
{
private:
    NodeSekcja* tail;
    NodeSekcja* head;
public:

    NodeSekcja& getBack()
    {
        return *tail;
    }

    void addSekcja()
    {
        NodeSekcja* newNode = new NodeSekcja();
        if (head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    listaSekcji() 
    {
       // NodeSekcja sekcja[T];
        head = nullptr;
        tail = nullptr;
        
    }

    

    void printList()
    {
        NodeSekcja* temp = head;
        Sekcja* tempSekcja;
        tempSekcja = new Sekcja[T];
        while (temp != nullptr) 
        {
            for (int i = 0; i < T; i++)
            {
                if (temp->sekcja[i].selektory.head != tempSekcja[i].selektory.head)
                {
                    temp->sekcja[i].printList();
                    temp->sekcja[i].selektory.head->next;
                }
                else if (temp->sekcja[i].atrybuty.head != tempSekcja[i].atrybuty.head)
                {
                    temp->sekcja[i].printList();
                    temp->sekcja[i].atrybuty.head->next;
                }//if (temp->sekcja != tempSekcja) 
                else
                    break;
            }
            temp = temp->next;
        }
        cout << endl;
    }

    NodeSekcja* getNodeAtIndex(int index) {
        NodeSekcja* current = head;
        int count = 0;
        while (current != nullptr) {
            if (count == index) {
                return current;
            }
            count++;
            current = current->next;
        }
        return nullptr;
    }

    String getAtrributeValue(int numer, String name)
    {
        NodeSekcja* current = head;
        String attributeValue;
        if (current != nullptr)
        {
            if (numer / T != 0 && numer != T)
            {
                for (int i = 0; i < numer / T; i++)
                {
                    current = current->next;
                }
            }
            if (numer == T)
                numer = T - 1;
            else
                numer = numer - (T * (numer / T));
            if (current->sekcja[numer - 1].atrybuty.head != nullptr)
            {
                NodeA* attributeNode = current->sekcja[numer - 1].atrybuty.head;
                while (attributeNode != nullptr)
                {
                    if (attributeNode->atrybut.name == name)
                    {
                        attributeValue = attributeNode->atrybut.value;
                        return attributeValue;
                    }
                    attributeNode = attributeNode->next;
                }
            }
            return "";
        }
        return "";
    }





    int ileSekcji()
    {
        NodeSekcja* current = head;
        Sekcja* tempSekcja;
        tempSekcja = new Sekcja[T];
        int count = 0;
        while (current != nullptr) {
            for (int i = 0; i < T; i++)
            {
                if (current->sekcja[i].selektory.head != tempSekcja[i].selektory.head)
                {
                    count++;
                    current->sekcja[i].selektory.head->next;
                }
                else if (current->sekcja[i].atrybuty.head != tempSekcja[i].atrybuty.head)
                {
                    count++;
                    current->sekcja[i].atrybuty.head->next;
                }
                else
                    break;
            }
            current = current->next;
        }
        return count;
    }

    int ileSelektorow(int numer)
    {
        NodeSekcja* current = head;
        int ileSelektorow = 0;
        if (current != nullptr) 
        {
            if (numer / T != 0 && numer != T)
            {
                for (int i = 0; i < numer / T; i++)
                {
                    current = current->next;
                }
            }
            if (numer == T)
                numer = T - 1;
            else
                numer = numer - (T * (numer / T));
            if (current != nullptr)
            {
                NodeS* temp = current->sekcja[numer - 1].selektory.head;
                if (temp != nullptr)
                {
                    while (temp != nullptr)
                    {
                        ileSelektorow++;
                        temp = temp->next;
                    }
                    return ileSelektorow;
                }
                else
                    return -1;
                    
            }
            else
                return -1;
        }
        else
            return -1;
       
    }

    String jakiSelektorowDlaSekcji(int nrSekcji, int nrSelektora)
    {
        NodeSekcja* current = head;
        int count = 0;
        if (current != nullptr)
        {
            if (nrSekcji / T != 0 && nrSekcji != T)
            {
                for (int i = 0; i < nrSekcji / T; i++)
                {
                    current = current->next;
                }
            }
            if (nrSekcji == T)
                nrSekcji = T - 1;
            //else
            //    numer = numer - (T * (numer / T));
            NodeS* temp = current->sekcja[nrSekcji - 1].selektory.head;
            if (temp != nullptr)
            {
                while (temp != nullptr)
                {
                    if (count == nrSelektora - 1)
                        return temp->selektor.name;
                    count++;
                    temp = temp->next;
                    
                }
                return " ";
            }
            else
                return " ";
        }
        else
            return " ";
    }

    int ileAtrybutow(int numer)
    {
        NodeSekcja* current = head;
        int count = 0;
        int ileAtrybutow = 0;
        if (current != nullptr)
        {
            if (numer / T != 0 && numer != T)
            {
                for (int i = 0; i < numer / T; i++)
                {
                    current = current->next;
                }
            }
            if (numer == T)
                numer = T - 1;
            else
                numer = numer - (T * (numer / T));
            NodeA* temp = current->sekcja[numer - 1].atrybuty.head;
            if (temp != nullptr)
            {
                while (temp != nullptr)
                {
                    ileAtrybutow++;
                    temp = temp->next;
                }
            }
            else 
                return -1;
        }
        else 
            return -1;
        return ileAtrybutow;
    }

    int ileAtrybutowPoNazwie(String nazwa)
    {
        NodeSekcja* current = head;
        int count = 0;
        if (nazwa == "")
            return 0;
        while (current != nullptr) {
            for (int i = 0; i < T; i++)
            {
                NodeA* atrybut = current->sekcja[i].atrybuty.head;
                while (atrybut != nullptr)
                {
                    if (atrybut->atrybut.name == nazwa)
                    {
                        count++;
                    }
                    atrybut = atrybut->next;
                }
            }
            current = current->next;
        }
        return count;
    }

    int ileSelektorowPoNazwie(String nazwa)
    {
        NodeSekcja* current = head;
        int count = 0;
        if (nazwa == "")
            return 0;
        while (current != nullptr) {
            for (int i = 0; i < T; i++)
            {
                NodeS* selektor = current->sekcja[i].selektory.head;
                while (selektor != nullptr)
                {
                    if (selektor->selektor.name == nazwa)
                    {
                        count++;
                    }
                    selektor = selektor->next;
                }
            }
            current = current->next;
        }
        return count;
    }

    String getAtrributeValueForSelector(String nazwaSelektora, String nazwaAtrybutu)
    {
        NodeSekcja* current = head;
        String value = "";
        if (nazwaSelektora == "")
            return "";
        if (nazwaAtrybutu == "")
            return "";
        while (current != nullptr) 
        {
            for (int i = 0; i < T; i++)
            {
                NodeSekcja* temp = current;
                
                while (temp->sekcja[i].selektory.head != nullptr && temp->sekcja[i].atrybuty.head != nullptr)
                {
                    if (temp->sekcja[i].selektory.head->selektor.name == nazwaSelektora)
                    {
                        if (temp->sekcja[i].atrybuty.head->atrybut.name == nazwaAtrybutu)
                         {
                            value = temp->sekcja[i].atrybuty.head->atrybut.value;
                            
                         }
                    }
                    temp->sekcja[i].selektory.head = temp->sekcja[i].selektory.head->next;
                }
            }
            current = current->next;
        }
        return value;
    }


    void deleteNode(int index)
    {
        NodeSekcja* current = head;

        if (index == 0)
        {
            head = head->next;
            if (head != nullptr)
            {
                head->prev = nullptr;
            }
            else
            {
                tail = nullptr;
            }

            delete current;
            return;
        }

        int i = 0;
        while (current && i < index)
        {
            current = current->next;
            i++;
        }

        if (!current)
        {
            std::cerr << "Error: Invalid index\n";
            return;
        }

        current->prev->next = current->next;

        if (current->next)
        {
            current->next->prev = current->prev;
        }
        else
        {
            tail = current->prev;
        }

        delete current;
    }

    /*
   ~listaSekcji()
    {
        NodeSekcja* temp = head;
        while (temp != nullptr) {
            temp = temp->next;
            delete head;
        }
    }
    */
};
