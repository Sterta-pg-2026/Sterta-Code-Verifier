#pragma once
#include <iostream>
#include "listaatrybutow.h"
#include "listaselektorow.h"

class Sekcja {
public:
	Selektory selektory;
	Atrybuty atrybuty;

	void insertSelector(String name)
	{
		selektory.insert(name);
	}
	void insertAttribute(String name, String value)
	{
		atrybuty.insert(name, value);
	}

	void printList() {
		cout << "selektory: \n";
		selektory.printList();
		cout << "atrybuty: \n";
		atrybuty.printList();
	}
};

