#include <iostream>
#include <conio.h>
#include "string.h"
//#include "Sekcja.h"
#include "listasekcji.h"
//#include "ListaSelektorow.h"
//#include "ListaAtrybutow.h"



#define T 8
using namespace std;

int main() 
{
    listaSekcji sekcje;
    sekcje.addSekcja();
    
    //Selektory selektory;
    //Atrybuty atrybuty;
    char znak = '0';
    char temp_znak;
    String napis("");
    String temp_napis = "";
    String pom_napis = "";
    bool sel = 1;
    bool komendy = 0;
    bool czyNowy = 1;
    int index = 0;
    String nrSekcji("");
   



    while (znak != EOF)
    {
        znak = char(getchar());
        temp_znak = znak;
        

        if (znak != ',' && znak != '{' && znak >= ' ' && znak != '}' && znak != ':' && znak != ';' && komendy == 0 && temp_znak != ':') //usuwaj tylko skrajne spacje
        {
            napis += znak;
        }
        
        if (komendy == 0)
        {
            if (sel == 1)
            {
                if (znak == ',')
                {
                    sekcje.getBack().insertSelector(napis, index);
                    napis = "";
                }
                if (znak == '{')
                {
                    sekcje.getBack().insertSelector(napis, index);
                    napis = "";
                    sel = 0;
                }
            }
            else if (znak == '}')
            {
                sel = 1;
                napis = "";
                index++;
                if (index == T - 1)
                {
                    sekcje.addSekcja();
                    index = 0;
                }
                    
            }
            else if (sel == 0)
            {
                if (znak == ':')
                {
                    temp_napis = napis;
                    napis = "";
                }
                else if (znak == ';')
                {
                    sekcje.getBack().insertAttribute(temp_napis, napis, index);
                    //sekcje.getBack().sekcja->atrybuty.printList();
                    napis = "";
                    temp_napis = "";
                }
                else if (znak == ',')
                {
                    sekcje.getBack().insertAttribute(temp_napis, napis, index);
                    napis = "";
                }
            }
        }
        else //komendy 1
        {



            if (znak != ',' && znak != '{' && znak > ' ' && znak != '}' && znak != ':' && znak != ';') //usuwaj tylko skrajne spacje
            {
                if (napis == "A" || napis == "S" || napis == "E")
                {
                    temp_napis += znak;
                }
                else if (znak >= '0' && znak <= '9' && napis == "")
                {
                    nrSekcji += znak;
                    //cout << nrSekcji;
                }
                else
                    napis += znak;
            }
            else if (znak == ',' && nrSekcji == "" && pom_napis == "" && temp_napis == "")
            {
                pom_napis = napis;


                napis = "";

            }
            /* cout << pom_napis;
             cout << napis;*/
           // cout << nrSekcji << ", napis: " << napis << ", temp_napis: " << temp_napis << ", pom_napis: " << pom_napis;


            if (napis == "?")
            {
                cout << "? == " << sekcje.ileSekcji() << endl;
                napis = "";
            }
            else if (napis == "****")
            {
                komendy = 0;
                napis = "";
            }
            else if (napis == "S" && temp_napis == "?")
            {
                if (pom_napis == "" && nrSekcji != "")
                {
                    if (sekcje.ileSelektorow(nrSekcji.toInt(nrSekcji)) != -1)
                        cout << nrSekcji << ",S,? == " << sekcje.ileSelektorow(nrSekcji.toInt(nrSekcji)) << endl;
                }
                else
                {
                    cout << pom_napis << ",S,? == " << sekcje.ileSelektorowPoNazwie(pom_napis) << endl;
                }


                nrSekcji = "";
                napis = "";
                temp_napis = "";
                pom_napis = "";
            }
            else if (napis == "S" && temp_napis != "?" && temp_napis != "") //&& znak == 13)
            {
                if (sekcje.jakiSelektorowDlaSekcji(nrSekcji.toInt(nrSekcji), temp_napis.toInt(temp_napis)) != " ")
                    cout << nrSekcji << ",S," << temp_napis << " == " << sekcje.jakiSelektorowDlaSekcji(nrSekcji.toInt(nrSekcji), temp_napis.toInt(temp_napis)) << endl;
                nrSekcji = "";
                napis = "";
                temp_napis = "";
            }
            else if (napis == "A" && temp_napis == "?")
            {
                //cout << "cok";
                if (pom_napis == "")
                {
                    if (sekcje.ileAtrybutow(nrSekcji.toInt(nrSekcji)) != -1)
                        cout << nrSekcji << ",A,? == " << sekcje.ileAtrybutow(nrSekcji.toInt(nrSekcji)) << endl; //dodaj warunek dla nieisteniejacych zeby byl skip

                }
                else
                {
                    cout << pom_napis << ",A,? == " << sekcje.ileAtrybutowPoNazwie(pom_napis) << endl;
                }
                   

                nrSekcji = "";
                napis = "";
                temp_napis = "";
                pom_napis = "";
            }
            else if (napis == "A" && temp_napis != "?" && temp_napis != "" && znak == '\n')
            {
                cout << nrSekcji << ",A," << temp_napis << " ==" << sekcje.getAtrributeValue(nrSekcji.toInt(nrSekcji), temp_napis) << endl; //<< " == "; //
                napis = "";
                nrSekcji = "";
                temp_napis = "";
            }
            else if (napis == "E" && znak == '\n')
            {
               //if(sekcje.getAtrributeValueForSelector(pom_napis, temp_napis) != "")
                    cout << pom_napis << ",E," << temp_napis << " ==" << sekcje.getAtrributeValueForSelector(pom_napis, temp_napis) << endl; //<< " == "; //
                napis = "";
                pom_napis = "";
                temp_napis = "";
            }

        }
        if (napis == "????")
        {
            komendy = 1;
            napis = "";
        }
        //cout << komendy;
    }
   // cout << endl;
   // cout << nrSekcji << ", napis: " << napis << ", temp_napis: " << temp_napis << ", pom_napis: " << pom_napis << endl;
   // sekcje.printList();
   // cout << endl;
    
    
    //selektory.printList();
    

    /*
    String s2("Hello, World!"); // tworzymy nowy napis na podstawie tablicy znaków
    cout << "s2 = \"" << s2 << "\"\n";

    String s3(s2); // tworzymy kopiê napisu s2
    std::cout << "s3 = \"" << s3 << "\"\n";

   
   List list;
   list.insert(1);
   list.insert(2);
   list.insert(3);
   list.printList();
   */
    
    return 0;
}
