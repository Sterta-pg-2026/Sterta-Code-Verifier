#pragma once
#include <iostream>
#include "string.h"

struct Selektor {
	String name;
};