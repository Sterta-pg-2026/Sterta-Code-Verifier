#pragma once
#include <iostream>
#include "string.h"

struct Atrybut {
	String name;
	String value; //string?
};