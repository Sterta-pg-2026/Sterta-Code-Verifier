#include "block.h"

void Block::AddSection(Section& new_section)
{
		sections[block_fullness] = new_section;
		block_fullness++;
		if (block_fullness == L) is_full = true;
		else is_full = false;
		new_section.is_empty = false;
}

void Block::DeleteSection(Section & section)
{
	section.selectors.list_of_selectors.DeleteList();
	section.attributes.list_of_attributes.DeleteList();
	section.is_empty = true;
	how_many_left_to_be_empty--;
}

Section& Block::ReturnSection(int index)
{
	int counter = 0;
	for (int i = 0; i < L; i++)
	{
		if (sections[i].is_empty == false)
		{
			counter++;
		}
		if (counter == index) return sections[i];
	}
	return sections[0]; 
}

int Block::ReturnBlockFullness()
{
	return block_fullness;
}

void Block::DecreaseBlockFullness()
{
	block_fullness--;
}

unsigned long long Block::ReturnHowManyToBeEmpty()
{
	return how_many_left_to_be_empty;
}

bool Block::RemoveNodeIsNecessary()
{
	if (how_many_left_to_be_empty == 0) return true;
	else return false;
}

void Block::PrintBlock()
{
	for (int i = 0; i < L; i++)
	{
		if (sections[i].is_empty == false)
		{
			std::cout << "OTO SEKCJA:" << endl;
			sections[i].PrintSection();
			std::cout << endl;
		}
	}
}

bool Block::IsFull()
{
	if (is_full == true) return true;
	else return false;
}