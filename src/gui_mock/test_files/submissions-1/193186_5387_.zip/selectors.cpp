#include "selectors.h"

void Selectors::AddSelector(String name)
{
	list_of_selectors.AddNode(name);
}

void Selectors::Print()
{
	list_of_selectors.PrintList();
}

