#pragma once

#include <iostream>

#include "selectors.h"
#include "attributes.h"

class Section
{
	friend class Block;
	friend class MainList;

public:
	Selectors selectors;
	Attributes attributes;
	bool is_empty=false;
public:
	void PrintSection();
};

