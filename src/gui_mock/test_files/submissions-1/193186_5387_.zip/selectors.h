#pragma once

#include <iostream>

#include "list.h"

class Selectors
{
	friend class Section;
	friend class Block;
	friend class MainList;
public:
	List<String> list_of_selectors;
public:
	void AddSelector(String name);
	void Print();
};

