#include <iostream>

#include "list.h"
#include "string.h"
#include "mainlist.h"
#include "css_parsing.h"

using namespace std;

int main()
{
    CSS_Parsing start;
    start.Parse();

    return 0;
}