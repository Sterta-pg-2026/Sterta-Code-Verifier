#pragma once

#include <iostream>

#define L 8

#include "section.h"

class Block
{
	friend class Section;
private:
	Section sections[L];
	int block_fullness=0;
	bool is_full;
	int how_many_left_to_be_empty = L;
public:
	void AddSection(Section& new_section);
	void DeleteSection(Section& new_section);
	Section& ReturnSection(int index);
	int ReturnBlockFullness();
	void DecreaseBlockFullness();
	unsigned long long ReturnHowManyToBeEmpty();
	bool RemoveNodeIsNecessary();
	void PrintBlock();
	bool IsFull();
};

