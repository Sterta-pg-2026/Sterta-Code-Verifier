#pragma once

#include <iostream>

#include "list.h"

class Attributes
{
	friend class Section;
	friend class Block;
	friend class MainList;

public:

	struct attribute_struct
	{
		String Name;
		String Value;
	};

	List<attribute_struct> list_of_attributes;

public:
	void AddAttribute(String name, String value);
	void PrintAttributes();
	String GetName(Node<attribute_struct> * node);
	String GetValue(Node<attribute_struct>* node);
	void AddOrChangeAttribute(String name, String change);
};

