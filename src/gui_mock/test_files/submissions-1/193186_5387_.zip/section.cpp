#include "section.h"

void Section::PrintSection()
{
	cout << "Selektor:" << endl;
	selectors.list_of_selectors.PrintList();
	cout << "Atrubut:" << endl;
	attributes.PrintAttributes();
}
 