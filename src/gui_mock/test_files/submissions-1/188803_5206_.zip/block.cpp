#include "block.h"

Block::Block() : permamentlyTaken(false)
{
}
