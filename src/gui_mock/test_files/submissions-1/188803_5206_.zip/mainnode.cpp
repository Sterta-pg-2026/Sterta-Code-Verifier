#include "mainnode.h"

MainNode::MainNode() : next(nullptr), previous(nullptr), takenSpots(0), blockArray()
{
}
