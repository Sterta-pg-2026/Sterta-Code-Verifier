#pragma once
#include "list.h"

//reading functions used in CSS mode
void ReadSelectors(SelectorNode** selectors);
void ReadAttributes(AttributeNode** attributes);
Section* ReadSection();
bool ReadBlock(DLLBlockNode* block);

//Functions used for commands
const DynamicCharArray* FindAttributeValue(DLLBlockNode* block, int section_num, DynamicCharArray& attribute_name_);
const SelectorNode* FindSelector(DLLBlockNode* block, int section_num, int selector_num);
const DynamicCharArray* FindLastAttributeValue(DLLBlockNode* block, DynamicCharArray& selector_name_, DynamicCharArray& attribute_name_);
int CountByName(DLLBlockNode* block, DynamicCharArray& name, int mode);
int Counter(int i, DLLBlockNode* block, int mode);
void DeleteIfDuplicate(SelectorNode* &head, DynamicCharArray& selector_name_);
void DeleteIfDuplicate(AttributeNode*& head, DynamicCharArray& attribute_name_);
int CountSections(DLLBlockNode* block);