#include <iostream>
#include "dynamicchararray.h"
#include "list.h"
#include "functions.h"
#include "listtemplates.h"

/*TODO:
* dzia�anie przy braku selektor�w
* memory leaks
*/


int main() {

	enum {CSS, COMMAND};
	int mode = CSS;

	enum {SELECTOR_MODE, ATTRIBUTE_MODE};

	DLLBlockNode* blocks = new DLLBlockNode();



	while (!std::cin.eof()) {
		if (mode == CSS) {
			DLLBlockNode* last = GetLast<DLLBlockNode>(blocks);
			if (last->IsFull()) {
				DLLBlockNode* new_node = new DLLBlockNode();
				blocks = AddLastDLL(blocks, new_node);
				last = GetLast<DLLBlockNode>(blocks);
			}
			if (!ReadBlock(last))
				mode = COMMAND;
		}

		DynamicCharArray input;

		if (mode == COMMAND) {					

			char ch;
			std::cin >> ch;

			if (std::cin.eof())
				break;

			if (ch == '?')						
				std::cout << "? == " << CountSections(blocks) <<  "\n";	//? command

			else if (ch >= '0' && ch <= '9') {						
				int ch_num = 0;
				int i = 1;
				while (ch != ',') {				//for multi-digit numbers
					ch_num *= 10;
					ch_num += ((int)ch - '0');	
					std::cin >> ch;
				}
				std::cin >> ch;
				if (ch == 'S') {
					std::cin.get();				//comma handling
					std::cin >> ch;

					if (ch == '?') {			
						int result = Counter(ch_num - 1, blocks, SELECTOR_MODE);	//i,S,? command
						if (result != -1)		//-1 is returned if there is no i-th section 
							std::cout << ch_num << ",S,? == " << result << "\n";
					}
					else if (ch >= '0' && ch <= '9') {	
						int ch_num_2 = 0;
						while (ch >= '0' && ch <= '9') {				//for multi-digit numbers
							ch_num_2 *= 10;
							ch_num_2 += ((int)ch - '0');
							ch = std::cin.get();
						}

						const SelectorNode* result = FindSelector(blocks, ch_num - 1, ch_num_2 - 1);	//i,S,j command
						if(result != nullptr)
							std::cout << ch_num << ",S," << ch_num_2 << " == " <<  *result << "\n";
					}
				}
				else if (ch == 'A') {
					std::cin.get();				//comma handling
					std::cin >> ch;
					if (ch == '?') {
						int result = Counter(ch_num - 1, blocks, ATTRIBUTE_MODE);		//i,A,? command
						if(result != -1)		//-1 is returned if there is no i-th section 
							std::cout << ch_num << ",A,? == " << Counter(ch_num - 1, blocks, ATTRIBUTE_MODE) << "\n";
					}
					else {
						while (ch != '\n') {
							input.PushBack(ch);
							ch = std::cin.get();
						}

						const DynamicCharArray* result = FindAttributeValue(blocks, ch_num - 1, input);		//i,A,n command

						if(result != nullptr)
							std::cout << ch_num << ",A," << input << " == " << *result << "\n";
						input.Erase();
					}
				}

				else if (ch == 'D') {
					std::cin.get();				//comma handling
					std::cin >> ch;
					if (ch == '*') {
						if(DeleteSection(blocks, ch_num - 1))		//i,D,* command				
							std::cout << ch_num << ",D,* == deleted\n";
					}
					else {
						while (ch != '\n') {
							input.PushBack(ch);
							ch = std::cin.get();
						}
						
						if(DeleteAttribute(blocks, ch_num - 1, input))		//i,D,n command	
							std::cout << ch_num << ",D," << input << " == deleted\n";
						input.Erase(); 
					}
				}
			}

			else if (ch == '*') {					//**** command
				std::cin.get();								
				std::cin.get();
				std::cin.get();

				mode = CSS;
			}

			else {
				while (ch != ',') {
					input.PushBack(ch);
					ch = std::cin.get();
				}
				std::cin >> ch;
				if (ch == 'A') {
					std::cin.get();				// comma handling
					std::cin >> ch;
					if (ch == '?') {
						int result = CountByName(blocks, input, ATTRIBUTE_MODE);			//n,A,? command
						std::cout << input << ",A,? == " << result << "\n";
						input.Erase();
					}
				}
				else if (ch == 'S') {
					std::cin.get();				// comma handling
					std::cin >> ch;
					if (ch == '?') {
						int result = CountByName(blocks, input, SELECTOR_MODE);				//z,S,? command
						std::cout << input << ",S,? == " << result << "\n";
						input.Erase();
					}
				}

				else if (ch == 'E') {
					std::cin.get();				// comma handling
					DynamicCharArray input2;
					std::cin >> ch;
					while (ch != '\n') {
						input2.PushBack(ch);
						ch = std::cin.get();
					}

					const DynamicCharArray* result = FindLastAttributeValue(blocks, input, input2);		//z,E,n command
					if (result != nullptr)
						std::cout << input << ",E," << input2 << " == " << *result << "\n";
					input.Erase();
					input2.Erase();
				}

				else {
					input.Erase();
					while (ch != '\n')
						ch = std::cin.get();
				}
			}
		}
	}
	
	const DLLBlockNode* temp = blocks;
	while (temp != nullptr) {
		const DLLBlockNode* temp_next = temp->GetNext();
		delete temp;
		temp = temp_next;
	}
	return 0;
}