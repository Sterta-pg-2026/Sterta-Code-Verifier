#include "list.h"
#include "functions.h"
#include "listtemplates.h"


template <typename T>
SLLNode<T>::SLLNode()
{
	next = nullptr;
}


DLLBlockNode::DLLBlockNode()
{	
	prev = nullptr;
	section_array = new Section[T];
	free_space = T;
}

bool DLLBlockNode::AddSection(Section& section)
{
	for (int i = 0; i < T; i++) {
		if (section_array[i].selector_list == nullptr) {

			section_array[i] = section;							
			free_space--;
			return true;
		}
	}
	return false;
}

bool DLLBlockNode::IsFull()
{
	return free_space == 0;
}

int DLLBlockNode::GetSpace()
{
	return free_space;
}

void DLLBlockNode::AliginLeft() {										
	for (int i = 0; i < T - 1; i++) {
		if (section_array[i].GetSelectorList() == nullptr
			&& section_array[i + 1].GetSelectorList() != nullptr) {
			for (int j = i; j < T - 1; j++) {
				section_array[j].attribute_list = section_array[j + 1].attribute_list;

				section_array[j].selector_list = section_array[j + 1].selector_list;

			}
			section_array[T - 1].selector_list = nullptr;
			section_array[T - 1].attribute_list = nullptr;
		}
	}
}

DLLBlockNode::~DLLBlockNode()
{
	delete[] section_array;
}





SelectorNode::SelectorNode(DynamicCharArray& selector_name)
{
	this->selector_name = selector_name;			
}

AttributeNode::AttributeNode(DynamicCharArray att_name, DynamicCharArray att_val) 
	: attribute_name(att_name), attribute_value(att_val)
{
}



std::ostream& operator<<(std::ostream& os,const SelectorNode& selector)
{
	std::cout << selector.selector_name;
	return os;
}

std::ostream& operator<<(std::ostream& os,const AttributeNode& attribute)
{
	std::cout << attribute.attribute_name << " has value " << attribute.attribute_value;
	return os;
}

std::ostream& operator<<(std::ostream& os, const DLLBlockNode& block)
{
	for (int i = 0; i < T; i++) {
		os << "[" << i << "]: " << block.section_array[i];
	}
	return os;
}

std::ostream& operator<<(std::ostream& os,const Section& section)
{
	os << "\nselectors:\n";
	if (section.selector_list != nullptr)
		DisplayList(section.selector_list);
	os << "\nattributes:\n";
	if(section.attribute_list != nullptr)
		DisplayList(section.attribute_list);
	return os;
}

Section::Section(SelectorNode* selector_list, AttributeNode* attribute_list) : 
	selector_list(selector_list), attribute_list(attribute_list)
{
}

Section::Section() : 
	selector_list(nullptr), attribute_list(nullptr)
{
	
}

Section::~Section()
{
	const SelectorNode* tmp_sel = selector_list;
	while (tmp_sel != nullptr) {
		const SelectorNode* tmp_sel_next = tmp_sel->GetNext();
		delete tmp_sel;
		tmp_sel = tmp_sel_next;

	}

	const AttributeNode* tmp_att = attribute_list;
	while (tmp_att != nullptr) {
		const AttributeNode* tmp_att_next = tmp_att->GetNext();
		delete tmp_att;
		tmp_att = tmp_att_next;

	}

}



