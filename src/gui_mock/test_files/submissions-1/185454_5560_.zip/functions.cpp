#include "functions.h"
#include "list.h"
#include "dynamicchararray.h"
#include "listtemplates.h"

/*TODO:
* dzialanie dla braku selektorow
*/

void ReadSelectors(SelectorNode** selectors) {
	DynamicCharArray input;

	char ch = '\0';
	while (ch != '{') {

		ch = std::cin.get();

		if (ch == '?')											//beginning of ???? command
			return;

		if (std::cin.eof())
			return;
		
		input.PushBack(ch);

		if (ch == ',' || ch == '{') {
			input.PopBack();
			while (input.GetSize() != 0 && (int)input.GetLast() < 33)		//removing whitespace characters
				input.PopBack();
			while (input.GetSize() != 0 && input.GetFirst() < 33)
				input.PopFirst();

			DeleteIfDuplicate(*selectors, input);
			*selectors = AddLast<SelectorNode>(*selectors, new SelectorNode(input));
			input.Erase();
		}
	}
}

void ReadAttributes(AttributeNode** attributes) {

	DynamicCharArray input;
	DynamicCharArray att_name;
	DynamicCharArray att_val;

	char ch = '\0';

	while (ch != '}') {
		std::cin >> ch;

		if (ch == '}')
			break;

		while (ch != ':') {
			input.PushBack(ch);
			std::cin >> ch;
		}
		
		while (input.GetSize() != 0 && (int)input.GetLast() < 33)		//removing whitespace characters
			input.PopBack();
		while (input.GetSize() != 0 && input.GetFirst() < 33)
			input.PopFirst();

		att_name = input;
		input.Erase();
		
		ch = std::cin.get();
		if (ch != ' ')
			input.PushBack(ch);

		while (ch != ';' && ch != '}') {
			ch = std::cin.get();
			input.PushBack(ch);
		}

		input.PopBack();

		while (input.GetSize() != 0 && (int)input.GetLast() < 33)		//removing whitespace characters
			input.PopBack();
		while (input.GetSize() != 0 && input.GetFirst() < 33)
			input.PopFirst();

		att_val = input;
		input.Erase();
		DeleteIfDuplicate(*attributes, att_name);
		*attributes = AddLast(*attributes, new AttributeNode(att_name, att_val));
	}
}



Section* ReadSection() {
	SelectorNode* selectors = nullptr;
	AttributeNode* attributes = nullptr;
	ReadSelectors(&selectors);
	if (selectors == nullptr) {
		if (std::cin.eof())
			return nullptr;
		else if (std::cin.get() == '?') {
			std::cin.get();
			std::cin.get();
			std::cin.get();
			return nullptr;
		}

	}
	ReadAttributes(&attributes);
	return new Section(selectors, attributes);
}

bool ReadBlock(DLLBlockNode* block) {
	while (!std::cin.eof()) {
		if (block->IsFull())
			return true;

		Section* section = ReadSection();

		if (section == nullptr && !std::cin.eof())				//returns false when mode is changed to COMMAND mode
			return false;

		if (section == nullptr || !block->AddSection(*section)){		
			return true;
		}
		
	}
	return true;
}

int CountSections(DLLBlockNode* block) {
	int result = 0;

	const DLLBlockNode* tmp = block;
	while (tmp != nullptr) {
		for (int i = 0; i < T; i++)
			if (tmp->GetSectionArray()[i].GetSelectorList() != nullptr)
				result++;
		tmp = tmp->GetNext();
	}
	
	return result;
}


int Counter(int i, DLLBlockNode* block, int mode) {					
	int c = 0;

	const DLLBlockNode* tmp = block;

	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {
			if (mode == 0) {																			//case: counting selectors 
				if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr && c == i) {					
					int result = 0;
					const SelectorNode* tmp_sel = tmp->GetSectionArray()[j].GetSelectorList();
					while (tmp_sel != nullptr) {
						if (tmp_sel->GetSelectorName().GetSize() != 0) {								//lack of selectors is treated as a one selector 
							result++;																	//with the size equal to zero 
						}
						tmp_sel = tmp_sel->GetNext();
					}
					return result;
				}

				if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr) {			
					c++;
				}
			}
			else if (mode == 1) {																	//case: counting attributes
				if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr && c == i)
					return CountNodes(tmp->GetSectionArray()[j].GetAttributeList());
				else if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr)
					c++;
			}
		}
		tmp = tmp->GetNext();
	}

	return -1;						
}

void DeleteIfDuplicate(SelectorNode* &head, DynamicCharArray& selector_name_)
{	
	SelectorNode* tmp_sel = head;
	if (head == nullptr)								//no action required for an empty list
		return;

	if (head != nullptr && (head)->GetSelectorName() == selector_name_) {		//removing first element if it is a duplicate
		head = head->next;
	}

	while (tmp_sel != nullptr && (tmp_sel)->GetNext() != nullptr) {				//removing any other element if it is a duplicate
		if ((tmp_sel)->GetNext()->GetSelectorName() == selector_name_) {
			(tmp_sel)->next = (tmp_sel)->next->next;
		}
		tmp_sel = (tmp_sel)->next;
	}

}

void DeleteIfDuplicate(AttributeNode* &head, DynamicCharArray& attribute_name_) {
	AttributeNode* tmp_att = head;

	if (head == nullptr)								//no action required for an empty list
		return;	

	if (head != nullptr && *(head->GetAttributeName()) == attribute_name_) {		//removing first element if it is a duplicate
		head = head->next;
	}

	while (tmp_att != nullptr && tmp_att->GetNext() != nullptr) {				//removing any other element if it is a duplicate
		if (*(tmp_att->GetNext()->GetAttributeName()) == attribute_name_) {
			tmp_att->next = tmp_att->next->next;
		}
		tmp_att = tmp_att->next;
	}
}


const SelectorNode* FindSelector(DLLBlockNode* block, int section_num, int selector_num) {
	int section_counter = 0;

	const DLLBlockNode* tmp = block;

	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {
			if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr && section_counter == section_num) {
				int selector_counter = 0;
				const SelectorNode* tmp_sel = tmp->GetSectionArray()[j].GetSelectorList();
				while (tmp_sel != nullptr && selector_counter != selector_num) {
					tmp_sel = tmp_sel->GetNext();
					selector_counter++;
				}
				if(tmp_sel == nullptr || tmp_sel->GetSelectorName().GetSize() != 0)			//meaning that j-th selector is not found OR there are no selectors
					return tmp_sel;															//(lack of selectors is treated as a one empty selector with size equal to 0)

			}

			if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr)				
				section_counter++;
		}
		tmp = tmp->GetNext();
	}

	return nullptr;
}

const DynamicCharArray* FindAttributeValue(DLLBlockNode* block, int section_num, DynamicCharArray& attribute_name_) {
	int c = 0;

	const DLLBlockNode* tmp = block;
	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {
			if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr && c == section_num) {

				const AttributeNode* tmp_att = tmp->GetSectionArray()[j].GetAttributeList();
				while (tmp_att != nullptr && *(tmp_att->GetAttributeName()) != attribute_name_) {
					tmp_att = tmp_att->GetNext();
				
				}
				if(tmp_att != nullptr)
					return tmp_att->GetAttributeValue();
			}
			 

			if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr)				
				c++;
		}
		tmp = tmp->GetNext();
	}

	return nullptr;
}

int CountByName(DLLBlockNode* block, DynamicCharArray& name, int mode) {
	int result = 0;
	const DLLBlockNode* tmp = block;
	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {
			if (mode == 0) {									//case:counting selectors
				const SelectorNode* tmp_sel = tmp->GetSectionArray()[j].GetSelectorList();
				while (tmp_sel != nullptr) {
					if (tmp_sel->GetSelectorName() == name)
						result++;
					tmp_sel = tmp_sel->GetNext();
				}
			}
			else if (mode == 1) {								//case:counting attributes
				if (tmp->GetSectionArray()[j].GetSelectorList() != nullptr) {
					const AttributeNode* tmp_att = tmp->GetSectionArray()[j].GetAttributeList();
					while (tmp_att != nullptr) {
						if (*(tmp_att->GetAttributeName()) == name) {
							result++;
						}
						tmp_att = tmp_att->GetNext();
					}
				}
			}
		}

		tmp = tmp->GetNext();
	}

	return result;
}

const DynamicCharArray* FindLastAttributeValue(DLLBlockNode* block, DynamicCharArray& selector_name_, DynamicCharArray& attribute_name_) {
	const DLLBlockNode* tmp = GetLast(block);
	while (tmp != nullptr) {
		for (int j = T - 1; j >= 0; j--) {
			const SelectorNode* tmp_sel = tmp->GetSectionArray()[j].GetSelectorList();
			while(tmp_sel != nullptr) {
				if (tmp_sel->GetSelectorName() == selector_name_) {
					const AttributeNode* tmp_att = tmp->GetSectionArray()[j].GetAttributeList();			
					while (tmp_att != nullptr && *(tmp_att->GetAttributeName()) != attribute_name_) {
						tmp_att = tmp_att->GetNext();
					}
					if (tmp_att != nullptr)												
						return tmp_att->GetAttributeValue();
				}
				tmp_sel = tmp_sel->GetNext();
			}
		}
		tmp = tmp->GetPrev();
	}

	return nullptr;
}

bool DeleteSection(DLLBlockNode* block, int i) {
	int c = 0;

	DLLBlockNode* tmp = block;

	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {
			if (tmp->section_array[j].selector_list != nullptr && c == i) {
				
				const SelectorNode* sel_to_delete = tmp->section_array[j].selector_list;				

				while (sel_to_delete != nullptr) {
					const SelectorNode* tmp_sel_next = sel_to_delete->GetNext();
					delete sel_to_delete;
					sel_to_delete = tmp_sel_next;
				}

				tmp->section_array[j].selector_list = nullptr;

				const AttributeNode* att_to_delete = tmp->section_array[j].attribute_list;

				while (att_to_delete != nullptr) {
					const AttributeNode* tmp_att_next = att_to_delete->GetNext();
					delete att_to_delete;
					att_to_delete = tmp_att_next;
				}

				tmp->section_array[j].attribute_list = nullptr;

				tmp->AliginLeft();							
				tmp->free_space++;
				return true;
			}
		if (tmp->section_array[j].selector_list != nullptr)				
				c++;
		}
		tmp = tmp->next;
	}
	return false;
}



bool DeleteAttribute(DLLBlockNode* block, int i, DynamicCharArray& attribute_name_) {
	int c = 0;

	DLLBlockNode* tmp = block;
	AttributeNode* temp;


	while (tmp != nullptr) {
		for (int j = 0; j < T; j++) {

			if (tmp->section_array[j].selector_list != nullptr && c == i) {
				AttributeNode* tmp_att = tmp->section_array[j].attribute_list;
				if (*(tmp_att->GetAttributeName()) == attribute_name_) {

					temp = tmp->section_array[j].attribute_list;
					tmp->section_array[j].attribute_list = tmp->section_array[j].attribute_list->next;


					if (tmp->section_array[j].attribute_list == nullptr) {

						const SelectorNode* sel_to_delete = tmp->section_array[j].selector_list;
						while (sel_to_delete != nullptr) {
							const SelectorNode* tmp_sel_next = sel_to_delete->GetNext();
							delete sel_to_delete;
							sel_to_delete = tmp_sel_next;
						}

						tmp->section_array[j].selector_list = nullptr;

						tmp->AliginLeft();
						tmp->free_space++;
					}

					delete temp;
					return true;;
				}
				while (tmp_att->next != nullptr) {
					if (*(tmp_att->next->GetAttributeName()) == attribute_name_) {
						temp = tmp_att->next;
						tmp_att->next = tmp_att->next->next;					
						if (tmp->section_array[j].attribute_list == nullptr) {

							const SelectorNode* sel_to_delete = tmp->section_array[j].selector_list;
							while (sel_to_delete != nullptr) {
								const SelectorNode* tmp_sel_next = sel_to_delete->GetNext();
								delete sel_to_delete;
								sel_to_delete = tmp_sel_next;
							}

							tmp->section_array[j].selector_list = nullptr;

							tmp->AliginLeft();
							tmp->free_space++;
						}
						delete temp;
						return true;
					}
					tmp_att = tmp_att->next;
				}
			}
			if (tmp->section_array[j].selector_list != nullptr)				
				c++;
		}
		tmp = tmp->next;
	}
	return false;
}
