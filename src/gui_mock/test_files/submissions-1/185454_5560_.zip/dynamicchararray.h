#pragma once
#pragma once
#include <iostream>

class DynamicCharArray {
private:
	char* array;
	size_t size;
	size_t capacity;
public:
	DynamicCharArray();
	DynamicCharArray(const DynamicCharArray& dynamic_array);
	DynamicCharArray& operator=(const DynamicCharArray& dynamic_array);
	void PushBack(char ch);
	void Erase();
	char PopBack();
	char GetLast() const;
	char GetFirst() const;
	char PopFirst();
	size_t GetSize() const;
	friend std::ostream& operator<<(std::ostream& os, const DynamicCharArray& dynamic_array);
	bool operator==(const DynamicCharArray& char_array) const;
	bool operator!=(const DynamicCharArray& char_array) const;
	~DynamicCharArray();

};