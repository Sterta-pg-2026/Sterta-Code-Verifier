#pragma once
#include <iostream>
#include "list.h"


template <typename T>
T* GetLast(T* head) {
	if (head == nullptr)
		return nullptr;
	T* tmp = head;
	while (tmp->next != nullptr)
		tmp = tmp->next;		
	return tmp;
}

template <typename T>
T* AddLast(T* head, T* new_node)
{
	if (head == nullptr) {
		head = new_node;
	}

	else {
		T* last = GetLast<T>(head);
		last->next = new_node;
	}

	return head;
}

template <typename T>
T* AddLastDLL(T* head, T* new_node)
{
	T* last = GetLast(head);
	new_node->prev = last;
	if (head == nullptr) {
		head = new_node;
	}

	else {
		T* last = GetLast<T>(head);
		last->next = new_node;
	}
	return head;
}

template <typename T>
void DisplayList(T* head) {
	T* tmp = head;
	while (tmp != nullptr) {
		std::cout << *tmp; 
		tmp = tmp->next;
	}
}

template <typename T>
int CountNodes(T* head) {	
	T* tmp = head;
	int result = 0;

	while (tmp != nullptr) {
		result++;
		tmp = tmp->next;
	}

	return result;
}


