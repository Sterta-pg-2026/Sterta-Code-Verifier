#pragma once
#pragma once
#include "dynamicchararray.h"


const int T = 17;			

template <typename T>
class SLLNode {
protected:				
	T* next;

public:
	SLLNode();

	const T* GetNext() const { return next; }

	template <typename T>
	friend T* GetLast(T* head);

	template <typename T>
	friend T* AddLast(T* head, T* new_node);

	template <typename T>
	friend void DisplayList(T* head);

	template <typename T>
	friend int CountNodes(T* head);
};


class DLLBlockNode;



class SelectorNode : public SLLNode<SelectorNode> {
private:
	DynamicCharArray selector_name;				

public:
	SelectorNode(DynamicCharArray& selector_name);

	const DynamicCharArray GetSelectorName() const { return selector_name; }

	friend std::ostream& operator<<(std::ostream& os, const SelectorNode& selector);		//for testing
	friend void DeleteIfDuplicate(SelectorNode* &head, DynamicCharArray& selector_name_);
	
};

class AttributeNode : public SLLNode<AttributeNode> {
private:
	DynamicCharArray attribute_name;	
	DynamicCharArray attribute_value;

public:
	AttributeNode(DynamicCharArray att_name, DynamicCharArray att_val);

	const DynamicCharArray* GetAttributeName() const { return &attribute_name; }
	const DynamicCharArray* GetAttributeValue() const { return &attribute_value; }

			

	friend void DeleteIfDuplicate(AttributeNode*& head, DynamicCharArray& attribute_name_);
	friend std::ostream& operator<<(std::ostream& os,const AttributeNode& attribute);		//for testing
	friend bool DeleteAttribute(DLLBlockNode* block, int i, DynamicCharArray& attribute_name_);
}
;

class Section {
private:
	SelectorNode* selector_list;
	AttributeNode* attribute_list;

public:
	Section(SelectorNode* selector_list, AttributeNode* attribute_list);
	Section();

	const SelectorNode* GetSelectorList() const { return selector_list; }
	const AttributeNode* GetAttributeList() const { return attribute_list; }

	~Section();

	friend class DLLBlockNode;
	friend std::ostream& operator<<(std::ostream& os,const Section& section);
	friend bool DeleteSection(DLLBlockNode* block, int i);
	friend bool DeleteAttribute(DLLBlockNode* block, int i, DynamicCharArray& attribute_name_);

};

class DLLBlockNode : public SLLNode<DLLBlockNode> {
private:
	DLLBlockNode* prev;
	Section* section_array;
	size_t free_space;

public:
	DLLBlockNode();
	const Section* GetSectionArray() const { return section_array; }

	const DLLBlockNode* GetPrev() const { return prev; }
	int GetSpace();

	bool AddSection(Section& section);
	bool IsFull();
	
	void AliginLeft();

	~DLLBlockNode();

	template <typename T>
	friend T* AddLastDLL(T* head, T* new_node);
	friend bool DeleteAttribute(DLLBlockNode* block, int i, DynamicCharArray& attribute_name_);
	friend bool DeleteSection(DLLBlockNode* block, int i);
	friend std::ostream& operator<<(std::ostream& os,const DLLBlockNode& section);

};

