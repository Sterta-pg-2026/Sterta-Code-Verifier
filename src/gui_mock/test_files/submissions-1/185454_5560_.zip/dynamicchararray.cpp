#include "dynamicchararray.h"


DynamicCharArray::DynamicCharArray()
{
	size = 0;
	capacity = 10;
	array = new char[capacity];
	for (int i = 0; i < capacity; i++)
		array[i] = '\0';
}

DynamicCharArray::DynamicCharArray(const DynamicCharArray& dynamic_array)
{
	capacity = dynamic_array.capacity;
	size = dynamic_array.size;
	array = new char[capacity];
	for (int i = 0; i < size; i++)
		array[i] = dynamic_array.array[i];
	for (int i = size; i < capacity; i++)
		array[i] = '\0';
}

DynamicCharArray& DynamicCharArray::operator=(const DynamicCharArray& dynamic_array)
{
	delete[] array;
	capacity = dynamic_array.capacity;
	size = dynamic_array.size;
	array = new char[capacity];
	for (int i = 0; i < size; i++)
		array[i] = dynamic_array.array[i];
	for (int i = size; i < capacity; i++)
		array[i] = '\0';
	return *this;

}

void DynamicCharArray::PushBack(char ch)
{
	if (size == capacity) {
		capacity *= 2;
		char* new_array = new char[capacity];
		for (int i = 0; i < size; i++)
				new_array[i] = array[i];
		for (int i = size; i < capacity; i++)
			new_array[i] = '\0';
		delete[] array;
		array = new_array;
	}
	array[size] = ch;
	size++;
}

void DynamicCharArray::Erase()
{
	size = 0;
	for (int i = 0; i < capacity; i++)
		array[i] = '\0';
}

char DynamicCharArray::PopBack()
{
	if (size > 0) {
		char last_element = array[size - 1];
		array[size - 1] = '\0';
		size--;
		return last_element;
	}
	return '\0';
}

char DynamicCharArray::GetLast() const
{
	if(size > 0)
		return array[size- 1] ;
	return '\0';
}

char DynamicCharArray::GetFirst() const
{
	if (size > 0)
		return array[0];
	return '\0';
}

char DynamicCharArray::PopFirst()
{
	if (size > 0) {
		char first_element = array[0];
		for (int i = 0; i < size - 1; i++)
			array[i] = array[i + 1];
		array[size - 1] = '\0';
		size--;
		return first_element;;
	}
	return '\0';
}

size_t DynamicCharArray::GetSize() const
{
	return size;
}

bool DynamicCharArray::operator==(const DynamicCharArray& char_array) const
{
	if(size != char_array.size)
		return false;

	for (int i = 0; i < size; i++) {
		if (array[i] != char_array.array[i])
			return false;
	}

	return true;

}

bool DynamicCharArray::operator!=(const DynamicCharArray& char_array) const
{
	return !(*this == char_array);
}

DynamicCharArray::~DynamicCharArray()
{
	delete[] array;
}

std::ostream& operator<<(std::ostream& os,const DynamicCharArray& dynamic_array)
{
	if(dynamic_array.array != nullptr)
		for(int i = 0; i < dynamic_array.size; i++)
			os << dynamic_array.array[i];
	return os;
}
