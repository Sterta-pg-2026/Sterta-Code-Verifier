#pragma once
#include "string.h"
#include "list.h"
#include "atribute.h"
class Section
{
public:
	List<String>* selectors;
	List<Atribute>* atributs;
	Section();
	~Section();
};

