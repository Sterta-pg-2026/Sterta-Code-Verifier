#pragma once
#include "string.h"
class Atribute
{
public:
	String name;
	String value;
	Atribute(String value);
	void print();
	~Atribute();
	bool operator==(const Atribute&);
};

