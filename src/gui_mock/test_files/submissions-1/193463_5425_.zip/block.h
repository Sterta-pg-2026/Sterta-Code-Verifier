#pragma once
#define BLOCKSIZE 17
#include "section.h"

class Block
{
public:
	Block* next;
	Block* prev;
	Section* tab[BLOCKSIZE];
	int ocupied;

	Block(Block* prev);
	~Block();
	int firstFree()const;
	void remove(int id);
	void addSection();
};

