#pragma once
struct AttrElement {
	AttrElement* next = nullptr;
	MyString prop = "";
	MyString value = "";
};

class AttrList {
public:
	AttrElement* head = nullptr;
	
	AttrList();
	~AttrList();
	int Size() const;
	void print_list() const;
	void push_back(MyString& prop, MyString& value);
	void pop_front();
	void remove(AttrElement* elem);

	//--- CMD Section
	// i,A,n
	MyString get_attr_value_by_prop(MyString prop)const;
	// n,A,?
	int attr_name_num(MyString prop)const;
	int attr_name_num_2_list(MyString prop, AttrList* TmpAttrList)const;
	// search duplicate
	bool attr_duplicate_by_prop_value(MyString prop, MyString value, int attr_id)const;
	bool attr_duplicate_by_prop(MyString prop, int attr_id)const;
	int get_attrs_num_without_duplicates() const;

	// DELETE
	// i,D,n
	bool remove_attr_value_by_prop(MyString prop);
};

AttrList::AttrList() {
	head = NULL;
}

AttrList::~AttrList() {
	while (head) {
		pop_front();
	}
}

int AttrList::Size() const {
	int count = 0;
	AttrElement* elem = head;
	while (elem) {
		count++;
		elem = elem->next;
	}
	return count;
}

int AttrList::get_attrs_num_without_duplicates() const {
	int count = 0;
	int i = 1;
	AttrElement* elem = head;
	while (elem) {
		if (attr_duplicate_by_prop(elem->prop, i++) == false)count++;
		elem = elem->next;
	}
	return count;
}

void AttrList::print_list() const {
	AttrElement* elem = head;

	printf("Number of attr elements : %d\n", Size());
	for (int i = 1; elem; elem = elem->next, i++) {
		printf("%d: ", i);
		elem->prop.Print();
		printf(" => ");
		elem->value.Print();
		printf("\n");
	}
}

void AttrList::push_back(MyString& prop, MyString& value) { // adds an element at the end
	AttrElement* p_elem, * elem;

	elem = new AttrElement;
	elem->next = NULL;
	elem->prop = prop;
	elem->value = value;
	p_elem = head;
	if (p_elem) {
		while (p_elem->next) {
			p_elem = p_elem->next;
		}
		p_elem->next = elem;
	}
	else {
		head = elem;
	}
}

void AttrList::pop_front() { // extracts the first element
	AttrElement* elem = head;

	if (elem) {
		head = elem->next;
		delete elem;
		elem = NULL;
	}
}

void AttrList::remove(AttrElement* elem) {
	AttrElement* p_elem;

	if (head == elem) pop_front();

	else {
		p_elem = head;
		while (p_elem->next != elem) p_elem = p_elem->next;

		p_elem->next = elem->next;
		delete elem;
		elem = NULL;
	}
}

//---- CMD Section

bool AttrList::remove_attr_value_by_prop(MyString prop) {
	AttrElement* elem = head;
	int ret = false;
	int size = this->Size();

	for (int i = 0; elem && i <= size; elem = elem->next, i++) {
		if (elem->prop == prop)
		{
			if (i == size) break; // we ran out of attributes => stop recursion
			remove(elem);
			remove_attr_value_by_prop(prop); // recursively call the function for deletin all the attributes
			ret = true;
			break;
		}
	}
	return ret;
}

MyString AttrList::get_attr_value_by_prop(MyString prop) const {
	AttrElement* elem = head;
	MyString ret = "";
	for (; elem; elem = elem->next) {
		// no return here, because we need the last attribute
		if (elem->prop == prop) ret = elem->value;
	}
	return ret;
}

int AttrList::attr_name_num_2_list(MyString prop, AttrList* TmpAttrList) const {
	AttrElement* elem = head;
	int count = 0;

	for (int i = 1; elem; elem = elem->next, i++) {
		if (elem->prop == prop)
		{
			TmpAttrList->push_back(elem->prop, elem->value);
			count++;
		}
	}
	return count;
}

int AttrList::attr_name_num(MyString prop)const {
	AttrElement* elem = head;

	for (int i = 1; elem; elem = elem->next, i++) {
		// we need to know if there is incoming inside the selector, it does not matter if it is rewritten or not
		if (elem->prop == prop) return 1;
	}
	return 0;
}


// search duplicate
bool AttrList::attr_duplicate_by_prop_value(MyString prop, MyString value, int attr_id) const {
	AttrElement* elem = head;

	for (int i = 1; elem && i < attr_id; elem = elem->next, i++) {
		if (elem->prop == prop && elem->value == value) return true;
	}
	return false;
}

// search duplicate
bool AttrList::attr_duplicate_by_prop(MyString prop, int attr_id) const {
	AttrElement* elem = head;

	for (int i = 1; elem && i < attr_id; elem = elem->next, i++) {
		if (elem->prop == prop) return true;
	}
	return false;
}
