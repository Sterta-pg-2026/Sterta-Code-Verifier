#pragma once
struct SplitElement { 
    SplitElement* next = nullptr; // points to the next node in the list
    MyString s_elem = "";
};

class SplitList {
public:
    SplitElement* head;

    SplitList();
    ~SplitList();
    int Size() const;
    void print_list() const;
    void push_back(MyString& s_elem);
    MyString pop_front();
};

SplitList::SplitList() {
    head = NULL; // initializing a linked list
}

SplitList::~SplitList() {
    while (head) {
        pop_front();
    }
}

int SplitList::Size() const{
    int cnt = 0;
    SplitElement* elem = head;
    while (elem) {
        cnt++;
        elem = elem->next; // updating the pointer to point to the next element
    }
    return cnt; // count
}

void SplitList::print_list() const {
    SplitElement* elem = head;

    printf("Number of split elements : %d\n", Size());
    for (int i = 1; elem; elem = elem->next, i++) {
        printf("%d: ", i);
        elem->s_elem.Print();
        printf("\n");
    }
}

void SplitList::push_back(MyString& s_elem) { // adds an element at the end
    SplitElement *p_elem, *elem;
    elem = new SplitElement;
    elem->next = NULL;      
    elem->s_elem = s_elem;
    p_elem = head;
    if (p_elem) {
        while (p_elem->next) {
            p_elem = p_elem->next;
        }
        p_elem->next = elem;
    }
    else {
        head = elem;
    }
}

MyString SplitList::pop_front() { // extracts the first element
    SplitElement* elem = head;
    MyString ret;
    if (elem) {
        head = elem->next;
        ret = elem->s_elem;
        delete elem;
        return ret;
    }
    return "";
}
