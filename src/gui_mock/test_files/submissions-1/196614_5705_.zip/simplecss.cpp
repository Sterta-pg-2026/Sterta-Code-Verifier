﻿//#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
//#include <chrono>
using namespace std;

#include "define.h"

#include "mystring.h"
#include "attr.h"
#include "selector.h"
#include "split.h"
#include "cssnode.h"

#include "str.h"
#include "css.h"
#include "cmd.h"

int main()
{
	// may be the stage of reading CSS or commands -- CMD
	int iStage = STAGE_READ_CSS;
	CSSNodeList* cssNodeList = new CSSNodeList;
	MyString cssWS = ""; // will store the css string without whitespaces
	while (true)
	{
		switch (iStage)
		{
		case STAGE_READ_CSS:
			cssWS = readCSS(iStage);
			ParceCSS(cssNodeList, cssWS);
			break;
		case STAGE_READ_CMD:
			readCMD(cssNodeList, iStage);
			break;
		}
		if (feof(FILE_IN))
		{
			break;
		}
	}
	return 0;
}
