#pragma once
void copy_string(char* dst, char* src)
{
	while (*src != '\0') *dst++ = *src++;
	*dst = '\0';
}

// trimming the whitespaces from both sides
void TrimLR(MyString& in)
{
	MyString tmp = "";
	tmp.TrimL(in);
	in.TrimR(tmp);
}

// cleaning the string from all the whitespace characters
void CleanStrWS(MyString& in)
{
	MyString tmp = in;
	in.setWS(tmp);
}

// a function combining 2 previous ones
void CleanStrAll(MyString& in)
{
	CleanStrWS(in);
	TrimLR(in);
}

// splitting of the string dependent on the separator
int MyStringSplit(MyString& str, SplitList* splitList, char cSeparator)
{
	int count = 0;

	int start = 0;
	int end = str.Find(cSeparator);
	MyString str2List = "";
	MyString tmp = "";
	MyString tmp1 = "";
	while (end != -1)
	{
		tmp = str.SubStr(start, end - start);
		TrimLR(tmp);
		// add the selected parts to the list 
		if (tmp.Length())
		{
			splitList->push_back(tmp);
			count++;
		}
		str = str.Erase(end - start + 1);
		end = str.Find(cSeparator);
	}
	TrimLR(str);
	// if there is anything after the last selector, then also add it to the list
	if (str.Length())
	{
		splitList->push_back(str);
		count++;
	}
	return count;
}
