#pragma once
class MyString
{
public:
	MyString()
	{
		str = nullptr;
		length = 0;
	}

	MyString(const char* str)
	{
		length = MyStrLen(str);
		this->str = new char[length + 1];

		for (int i = 0; i < length; i++)
			this->str[i] = str[i];

		this->str[length] = '\0';
	}

	~MyString()
	{
		delete[] this->str;
		this->str = nullptr;
	}

	MyString(const MyString& other)
	{
		length = MyStrLen(other.str);
		this->str = new char[length + 1];

		for (int i = 0; i < length; i++)
			this->str[i] = other.str[i];

		this->str[length] = '\0';
	}

	// analogue of strcpy and length calculating
	const MyString& operator=(const MyString& other)
	{
		if (this->str != nullptr)
			delete[] str;

		length = MyStrLen(other.str);
		this->str = new char[length + 1];

		for (int i = 0; i < length; i++)
			this->str[i] = other.str[i];

		this->str[length] = '\0';

		return *this;
	}

	// analogue of strcut
	MyString operator + (const MyString& other)
	{
		MyString newStr;

		int thisLength = MyStrLen(this->str);
		int otherLength = MyStrLen(other.str);

		newStr.length = thisLength + otherLength;

		newStr.str = new char[thisLength + otherLength + 1];

		int i = 0;
		for (; i < thisLength; i++)
			newStr.str[i] = this->str[i];

		for (int j = 0; j < otherLength; j++, i++)
			newStr.str[i] = other.str[j];

		newStr.str[thisLength + otherLength] = '\0';

		return newStr;
	}

	int MyStrLen(const char* ptr) {
		const char* start = ptr;
		while (*ptr) ptr++;
		return (int)(ptr - start);
	}

	int Length() const
	{
		return length;
	}

	void Print()
	{
		printf("%s", str);
	}
	void PrintN()
	{
		printf("%s\n", str);
	}

	bool operator == (const MyString& other) const {
		if (this->length != other.length)
			return false;

		for (int i = 0; i < this->length; i++)
			if (this->str[i] != other.str[i])
				return false;

		return true;
	}

	// inspired by strcnp
	bool operator != (const MyString& other)
	{
		return !(this->operator==(other));
	}

	// returns indexed element
	char& operator [] (int index)
	{
		return this->str[index];
	}

	int Find(const char c) const {
		for (int i = 0; i < this->length; i++)
			if (this->str[i] == c) return i;
		return -1;
	}

	bool isSpace(char c) {
		return c == ' ';
	}

	bool isFNRTV(char c) {
		return c == '\f' || c == '\n' || c == '\r' || c == '\t' || c == '\v';
	}

	bool isDigit(char c) {
		return c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9';
	}

	// checking if the string is positive integer
	bool isInteger() {
		if (this->str == nullptr || !*this->str)
			return false;
		char* tmp_ptr = this->str;
		while (*this->str) {
			if (!isDigit(*this->str))
			{
				this->str = tmp_ptr;
				return false;
			}
			++this->str;
		}
		this->str = tmp_ptr;
		return true;
	}

	// does not checks if the value is positive int inside the function,
	// hence string should be checked or emptied
	int Str2Int()
	{
		char* tmp_ptr = this->str;
		int num = 0;

		for (; *this->str; this->str++)
			num = (num * 10) + (*this->str - 48);

		this->str = tmp_ptr;
		return num;
	}
	// analogue of strncpy
	char* strNcopy(char* dst, const char* src, size_t num) {
		size_t i;
		for (i = 0; i < num && src[i] != '\0'; i++) dst[i] = src[i];
		while (i < num) dst[i++] = '\0';
		return dst;
	}

	// analogue of substr
	MyString SubStr(const int start, const int len) {
		if (start < 0 || start > this->length || len < 0 || start + len > this->length)
			return MyString("");

		char* substrData = new char[len + 1];
		strNcopy(substrData, this->str + start, len);
		substrData[len] = '\0';
		MyString ret(substrData);
		delete[] substrData;
		return ret;
	}

	MyString Erase(const int start) {
		if (start < 0 || start >= this->length) {
			return MyString("");
		}
		return MyString(this->str + start);
	}

	// sets a string cleaned from the whitespace characters
	MyString& setWS(const MyString& other)
	{
		if (this->str != nullptr)
			delete[] str;
		int rm_len = 0;
		length = MyStrLen(other.str);
		this->str = new char[length + 1];

		for (int i = 0, j = 0; i < length; i++)
		{
			if (!isFNRTV(other.str[i]))
				this->str[j++] = other.str[i];
			else
				rm_len++;
		}
		this->str[length - rm_len] = '\0';
		return *this;
	}

	// trim the whitespaces on the left 
	MyString& TrimL(const MyString& other)
	{
		if (this->str != nullptr)
			delete[] str;
		int rm_len = 0;
		length = MyStrLen(other.str);
		this->str = new char[length + 1];
		bool indFirstSpace = true;

		for (int i = 0, j = 0; i < length; i++)
		{
			if (indFirstSpace == true && !isSpace(other.str[i]))
				indFirstSpace = false;

			if (!indFirstSpace)
				this->str[j++] = other.str[i];
			else
				rm_len++;
		}
		length = length - rm_len;
		this->str[length] = '\0';

		return *this;
	}

	// trim the whitespaces on the right
	MyString& TrimR(const MyString& other)
	{
		if (this->str != nullptr)
			delete[] str;
		int rm_len = 0;
		length = MyStrLen(other.str);
		this->str = new char[length + 1];
		bool indFirstSpace = true;
		for (int i = length - 1; i >= 0; i--)
		{
			if (indFirstSpace == true && isSpace(other.str[i]))
			{
				rm_len++;
			}
			else
			{
				indFirstSpace = false;
				this->str[i] = other.str[i];
			}
		}
		length = length - rm_len;
		this->str[length] = '\0';

		return *this;
	}

private:
	char* str;
	int length;

};
