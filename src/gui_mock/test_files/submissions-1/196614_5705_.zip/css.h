#pragma once

// checking for "exiting" from reading CSS - ????
bool isExitCMD(char* ret, size_t pos)
{
	if (
		ret[pos] == '?' &&
		ret[pos - 1] == '?' &&
		ret[pos - 2] == '?' &&
		ret[pos - 3] == '?'
		)
		return true;

	return false;
}

// read file symbol by symbol
void GetFile(int& iStage, MyString& msGetData)
{
	int c;
	// size of the allocated buffer 
	size_t size = GET_FILE_CHAR_BUFFER_SIZE;
	// current size of the buffer
	size_t pos = 0;
	char* ret = (char*)malloc(size);
	if (ret == NULL) return;

	ret[0] = '\0';
	c = fgetc(FILE_IN);
	while (c != EOF)
	{
		ret[pos] = (char)c;

		// checking for "exiting" - ????
		if (isExitCMD(ret, pos))
		{
			ret[pos - 3] = '\0';
			iStage = STAGE_READ_CMD;
			msGetData = ret;
			return;
		}

		// checking for "}"
		// if block is closed with a paranthese, give it to parser
		if (ret[pos] == '}')
		{
			ret[pos + 1] = '\0';
			msGetData = ret;
			return;
		}

		// if buffer is full, change its size
		if (++pos == size)
		{
			size += GET_FILE_CHAR_BUFFER_SIZE;
			char* tmp = (char*)realloc(ret, size);
			if (!tmp)
			{
				perror("realloc");
				msGetData = ret;
				return;
			}
			ret = tmp;
		}
		c = fgetc(FILE_IN);
	}

	free(ret);
	ret = nullptr;
	return;
}

MyString readCSS(int& iStage)
{
	MyString msWSData = ""; // the string !cleaned! from white spaces
	MyString msGetData = ""; // the string we get as an input, is to be cleaned
	// read the data from the file stream
	GetFile(iStage, msGetData);
	// clean the string from the whitespaces
	msWSData.setWS(msGetData);
	return msWSData;
}

void CSS2Block(CSSNodeList* cssNodeList, SplitList* splitListSelectors, SplitList* splitListAttrs)
{
	// temporary list in which we put parsed attributes
	SplitList* splitListPropVal = new SplitList;
	// target attribute list
	AttrList* attrList = new AttrList;
	// target selectors list
	SelectorList* selectorList = new SelectorList;

	// extracting attribute properties and values
	MyString PropVal = "";
	do
	{
		PropVal = splitListAttrs->pop_front();
		if (PropVal.Length())
		{
			MyStringSplit(PropVal, splitListPropVal, ':');
		}
	} while (PropVal.Length() > 0);

	// extract attributes pairs and write them to the target list
	MyString cAttrProp = "", cAttrValue = "";
	do
	{
		cAttrProp = splitListPropVal->pop_front();
		cAttrValue = splitListPropVal->pop_front();
		if (cAttrProp.Length() > 0 && cAttrValue.Length())
			attrList->push_back(cAttrProp, cAttrValue);
	} while (cAttrProp.Length() > 0 && cAttrValue.Length());

	// then do the same with the selector list and
	// send each to the attribute list 
	MyString cSelectorName = "";
	do
	{
		cSelectorName = splitListSelectors->pop_front();
		if (cSelectorName.Length())
		{
			// no need to duplicate selectors in the code
			// so put in only if there is no such selector
			if (selectorList->get_selector_name_num(cSelectorName) == 0)
				selectorList->push_back(cSelectorName, attrList);
		}
	} while (cSelectorName.Length());

	// fill CSS nodes
	cssNodeList->find_holey_block_last(selectorList);
}

// parse CSS string and put both selectors and attributes into the temporary lists
void ParceCSS(CSSNodeList* cssNodeList, MyString& cssWS)
{
	// for splitting by "}"
	SplitList* splitListBrace_End = new SplitList;
	MyString braceEnd = "";

	MyStringSplit(cssWS, splitListBrace_End, '}');
	do
	{
		// for splitting by "{"
		SplitList* splitListBrace_Begin = new SplitList;
		braceEnd = splitListBrace_End->pop_front();

		if (braceEnd.Length())
		{
			MyStringSplit(braceEnd, splitListBrace_Begin, '{');

			// there are 2 elements in the splitListBrace_Begin: 1st is selectors, 2nd is attributes
			// extract selectors with the first pop
			MyString Selectors = EMPTY_SELECTOR_NAME;
			// 6th test - empty selector, hence leave it empty, 1st element extract as an attribute
			if (splitListBrace_Begin->Size() == 2) Selectors = splitListBrace_Begin->pop_front();

			SplitList* splitListSelectors = new SplitList;
			MyStringSplit(Selectors, splitListSelectors, ',');
			// using second pop extract attributes
			MyString Attrs = splitListBrace_Begin->pop_front();
			if (Attrs.Length())
			{
				SplitList* splitListAttrs = new SplitList;
				MyStringSplit(Attrs, splitListAttrs, ';');

				// send temporary lists with selectors and attributes to the target ones
				CSS2Block(cssNodeList, splitListSelectors, splitListAttrs);
			}
		}
	} while (braceEnd != "");
}
