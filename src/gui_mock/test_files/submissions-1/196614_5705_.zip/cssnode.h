#pragma once
struct CSSNodeElement {
	CSSNodeElement* prev = nullptr;
	CSSNodeElement* next = nullptr;

	// counter of the occupied elements for an array SelectorsList
	// if it is equal to CSS_NODE_BLOCK_SIZE
	// we need to create a new node
	int block_counter = 0;

	SelectorList* SelectorsList[CSS_NODE_BLOCK_SIZE] = { nullptr };
};

class CSSNodeList {
public:
	CSSNodeElement* head = nullptr;
	CSSNodeElement* tail = nullptr;
	int count;

	CSSNodeList();
	~CSSNodeList();
	int Size() const;
	void print_list() const;
	void push_back(SelectorList* sList);
	void pop_front();
	void remove(CSSNodeElement* e);
	void remove_all();
	// search for "a hole" in the last block/array
	void find_holey_block_last(SelectorList* sList);
	// delete an element of a block/array
	void remove_block_element(CSSNodeElement* elem, int arr_id);
	// delete an element of block/array by CSS number and array id 
	bool remove_block_element_by_id(int css_id, int arr_id);

	//----- CMD Section
	// ? - get the number of CSS sections; 
	int getCSS_section_num() const;

	// i,S,? - print the number of selectors for section number i (section and attribute numbers start 
	// from 1), if there is no such block, skip;
	int getCSS_section_selectors_num(int section)const;

	//i,S,j - print the j - th selector for the i - th block(section and attribute numbers start from 1), if
	//	there is no section or selector, skip;
	MyString getCSS_selectors_by_section_snum(int section, int selector_id)const;

	// z,S,? - print the total (for all blocks) number of occurrences of selector z. It can be 0; 
	int getCSS_selector_name_num(MyString name)const;


	// i,A,? - print the number of attributes for section number i, if there is no such block or section, 
	// skip;
	int getCSS_section_attrs_num(int section)const;

	// i,A,n - print the value of the attribute with the name n for the i-th section, if there is no such 
	// attribute, skip;
	MyString getCSS_attr_value_by_prop_and_id(int section, MyString prop)const;

	//n,A,? - print the total (for all blocks) number of occurrences of attribute named n (duplicates 
	// should be removed when reading).It can be 0;
	int getCSS_attr_name_num(MyString prop)const;


	// z,E,n - print the value of the attribute named n for the selector z, in case of multiple 
	// occurrences of selector z, take the last one.If there is no such attribute, skip;
	MyString getCSS_attr_value_by_selector_and_attr_name(MyString selector_name, MyString prop)const;

	// DELETE

	//   /  "" id
	// i,D,* - remove the entire section number i (i.e., separators+attributes), after successful 
	// execution, print "deleted";
	bool removeCSS_block_by_id(int id);

	// i,D,n - remove the attribute named n from the i-th section, if the section becomes empty as a 
	// result of the operation, it should also be removed(along with any selectors), after successful
	//	execution, print "deleted"
	int removeCSS_attr_value_by_prop_and_id(int section, MyString prop);

};

CSSNodeList::CSSNodeList() {
	head = NULL;
	tail = NULL;
	count = 0;
}

CSSNodeList::~CSSNodeList() {
	while (head) {
		pop_front();
	}
}

int CSSNodeList::Size() const {
	int cnt = 0;
	CSSNodeElement* elem = head;
	while (elem) {
		cnt++;
		elem = elem->next; // updating the pointer to point to the next element
	}
	return cnt;
}

void CSSNodeList::push_back(SelectorList* sList) // adds an element at the end
{
	CSSNodeElement* elem;

	elem = new CSSNodeElement;
	elem->SelectorsList[++elem->block_counter] = sList;
	elem->next = NULL;
	elem->prev = tail;
	tail = elem;
	count++;
	if (elem->prev) elem->prev->next = elem;
	else head = elem;
}

void CSSNodeList::remove(CSSNodeElement* elem)
{
	if (!elem->prev && !elem->next) // if there is one element left
	{
		elem = NULL;
		return;
	}
	count--;

	if (elem->prev)
		// putting the pointer to the next (in respect to current one) element to the 
		// previous (in respect to current one) element so there is no hole
		elem->prev->next = elem->next;
	else
		head = elem->next;

	if (elem->next)
		elem->next->prev = elem->prev;
	else
		tail = elem->prev;

	elem = NULL;
}

void CSSNodeList::remove_all() {
	if (!count) return;

	CSSNodeElement* elem = head;

	for (int i = 1; elem; elem = elem->next, i++) {
		remove(elem);
	}
}

void CSSNodeList::pop_front() // extracts the first element
{
	if (this->count) remove(head);
}

void CSSNodeList::print_list() const {
	if (!this->count) return;

	CSSNodeElement* elem = head;

	printf("\n---PRINT Nodes---\n");
	printf("Number of CSS Nodes : %d\n", Size());
	for (int i = 1; elem; elem = elem->next, i++) {
		printf("\nnodeCSS[%d] (Block counter : %d)\n", i, elem->block_counter);

		for (int j = 1; j <= elem->block_counter; j++)
		{
			printf("\nj[%d]\n", j);
			elem->SelectorsList[j]->print_list();
		}
	}
}

// search for a hole in the last block
void CSSNodeList::find_holey_block_last(SelectorList* sList) {
	CSSNodeElement* elem = tail; // go from the end

	// if there is no CSS node yet created (or all of them are already deleted)
	// create a new one
	if (Size() == 0)
	{
		push_back(sList);
		return;
	}
	else
	{
		// go through nodes (in the reverse order) in the search of a hole
		for (; elem; elem = elem->next) {
			// find block with a hole => fill it and quit the function 
			if (elem->block_counter < CSS_NODE_BLOCK_SIZE)
			{
				elem->SelectorsList[++elem->block_counter] = sList;
				return;
			}
		}
	}
	// if no holes are found, create a new node
	push_back(sList);
}

int CSSNodeList::getCSS_section_num() const {
	CSSNodeElement* elem = head;
	int cnt = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		cnt += elem->block_counter;
	}
	return cnt;
}

int CSSNodeList::getCSS_section_selectors_num(int section) const {
	CSSNodeElement* elem = head;
	int num = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (section == ++num)
			{
				return elem->SelectorsList[i]->SizeNotEmptyName();
			}
		}
	}
	return -1; // there is no block
}

MyString CSSNodeList::getCSS_selectors_by_section_snum(int section, int selector_id) const {
	MyString selector_name = "";
	CSSNodeElement* elem = head;
	// for continuous numbering for all blocks
	int num = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (section == ++num)
			{
				return elem->SelectorsList[i]->get_selector_name_by_id(selector_id);
			}
		}
	}
	return selector_name;
}

MyString CSSNodeList::getCSS_attr_value_by_prop_and_id(int section, MyString prop) const {
	MyString attr_value = "";
	CSSNodeElement* elem = head;
	// for continuous numbering for all blocks
	int num = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (section == ++num)
			{
				return elem->SelectorsList[i]->get_attr_value_by_prop_and_id(prop);
			}
		}
	}
	return attr_value;
}

int CSSNodeList::removeCSS_attr_value_by_prop_and_id(int section, MyString prop) {
	CSSNodeElement* elem = head;

	// for continuous numbering for all blocks
	int num = 0;
	int block_size_attr = 0;
	int attr_remove_count = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (section == ++num)
			{
				attr_remove_count = elem->SelectorsList[i]->remove_attr_value_by_prop_and_id(prop);
				block_size_attr = elem->SelectorsList[i]->get_attrs_num();

				if (block_size_attr == 0) removeCSS_block_by_id(section);
				return attr_remove_count;
			}
		}
	}
	return 0;
}


int CSSNodeList::getCSS_selector_name_num(MyString name) const {
	MyString selector_name = "";
	CSSNodeElement* elem = head;
	int ret = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			ret += elem->SelectorsList[i]->get_selector_name_num(name);
		}
	}
	return ret;
}

// --- ATTRS BEGIN

int CSSNodeList::getCSS_attr_name_num(MyString prop) const {
	MyString selector_name = "";
	CSSNodeElement* elem = head;
	int cnt = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			cnt += elem->SelectorsList[i]->attr_name_num(prop);
		}
	}
	return cnt;
}

MyString CSSNodeList::getCSS_attr_value_by_selector_and_attr_name(MyString selector_name, MyString prop) const {
	//	MyString selector_name = "";
	CSSNodeElement* elem = tail;
	MyString value = "";
	// go through all nodes
	// in reverse order
	for (; elem; elem = elem->prev) {
		// reverse order again
		for (int i = elem->block_counter; i >= 1; i--)
		{
			value = elem->SelectorsList[i]->get_attr_value_by_selector_and_attr_name(selector_name, prop);
			if (value.Length()) return value;
		}
	}
	return value;
}

int CSSNodeList::getCSS_section_attrs_num(int section) const {
	CSSNodeElement* elem = head;
	int section_num = 0;
	//int count = 0;
	// go through all nodes
	for (; elem; elem = elem->next) {
		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (section == ++section_num)
			{
				return elem->SelectorsList[i]->get_attrs_num_without_duplicates();
			}
		}
	}
	return 0;
}

// --- DELETE BEGIN

void CSSNodeList::remove_block_element(CSSNodeElement* elem, int arr_id)
{
	// moving array elements downwards
	for (int i = arr_id; i < elem->block_counter; ++i)
		elem->SelectorsList[i] = elem->SelectorsList[i + 1];
	--elem->block_counter;
	// if an array is empty
	if (elem->block_counter == 0) remove(elem);
	//if (elem->block_counter == 0) elem = nullptr;
}

bool CSSNodeList::remove_block_element_by_id(int css_id, int arr_id)
{
	CSSNodeElement* elem = head;

	for (int i = 1; elem; elem = elem->next, i++) {
		if (i == css_id)
		{
			remove_block_element(elem, arr_id);
			return true;
		}
	}
	return false;
}

bool CSSNodeList::removeCSS_block_by_id(int id) {
	CSSNodeElement* elem = head;

	// for continuous numbering for all blocks
	int num = 0;
	// go through all nodes
	for (int node = 1; elem; elem = elem->next, node++) {

		for (int i = 1; i <= elem->block_counter; i++)
		{
			if (id == ++num)
			{
				return remove_block_element_by_id(node, i);
			}
		}
	}
	return false;
}
