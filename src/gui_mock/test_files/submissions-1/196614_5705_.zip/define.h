#pragma once

//#define DEBUG 1
// print info for the debug
#define PRINT_YES true
#define PRINT_NO false

// size of the string of reading commands
#define STR_MAX_SIZE 128

// the size we extend our buffer on during reallocating the memory
// for reading css blocks
#define GET_FILE_CHAR_BUFFER_SIZE 8

// size of an array in the node
#define CSS_NODE_BLOCK_SIZE 8

// macroses for printing symbols and cmd results
#define _EQ printf(" == ");
#define _CM printf(",");
#define _PRINT_D { cmd1.Print(); _CM cmd2.Print(); _CM cmd3.Print(); _EQ printf("%d\n", ret); }
#define _PRINT_DEL { cmd1.Print(); _CM cmd2.Print(); _CM cmd3.Print(); _EQ printf("deleted\n"); }
#define _PRINT_S { cmd1.Print(); _CM cmd2.Print(); _CM cmd3.Print(); _EQ ret.PrintN(); }

// identifier of an empty selector
#define EMPTY_SELECTOR_NAME "-1"

// stages of reading css/cmd
#define STAGE_READ_CSS 0
#define STAGE_READ_CMD 1

// read file stream
// FILE IN
//FILE* file = fopen(".\\in\\0.in", "r");
//#define FILE_IN file
#define FILE_IN stdin

