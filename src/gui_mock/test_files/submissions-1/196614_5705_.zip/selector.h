#pragma once
struct SelectorElement {
	SelectorElement* next = nullptr;
	MyString name = "";
	AttrList* AttributesList = new AttrList;
	// for counting unique attributes
};

class SelectorList {
public:
	SelectorElement* head = nullptr;

	SelectorList();
	~SelectorList();
	int Size() const;
	int SizeNotEmptyName() const;
	void print_list() const;
	void push_back(MyString& name, AttrList* aList);
	void pop_front();
	void remove(SelectorElement* elem);

	//----- CMD  Section
	MyString get_selector_name_by_id(int id) const;
	int get_selector_name_num(MyString str) const;

	int get_attrs_num() const;
	int get_attrs_num_without_duplicates() const;


	// i,A,n
	MyString get_attr_value_by_prop_and_id(MyString prop) const;
	// n,A,?
	int attr_name_num(MyString prop) const;

	// SEARCH
	MyString get_attr_value_by_selector_and_attr_name(MyString selector_name, MyString prop) const;

	// DELETE
	// i,D,n
	int remove_attr_value_by_prop_and_id(MyString prop);

};

SelectorList::SelectorList() {
	head = NULL;
}

SelectorList::~SelectorList() {
	while (head) {
		pop_front();
	}
}

int SelectorList::Size() const {
	int count = 0;
	SelectorElement* elem = head;
	while (elem) {
		count++;
		elem = elem->next;
	}
	return count;
}

int SelectorList::SizeNotEmptyName() const {
	int count = 0;
	SelectorElement* elem = head;
	while (elem) {
		if (elem->name != EMPTY_SELECTOR_NAME)
			count++;
		elem = elem->next;
	}
	return count;
}

void SelectorList::print_list() const {
	SelectorElement* elem = head;

	printf("Number of selectors : %d\n", Size());
	for (int i = 1; elem; elem = elem->next, i++) {
		printf("%d: ", i);
		elem->name.Print();
		printf("\n");
		elem->AttributesList->print_list();
	}
}

void SelectorList::push_back(MyString& name, AttrList* aList) { // adds an element at the end

	SelectorElement* p_elem, * elem;

	elem = new SelectorElement;
	elem->next = NULL;         
	elem->name = name;
	elem->AttributesList = aList;
	p_elem = head;
	if (p_elem) {
		while (p_elem->next) {
			p_elem = p_elem->next;
		}
		p_elem->next = elem;
	}
	else {
		head = elem;
	}
}

void SelectorList::pop_front() { // extracts the first element
	SelectorElement* elem = head;

	if (elem) {
		head = elem->next;
		delete elem;
	}
}

void SelectorList::remove(SelectorElement* elem) {
	SelectorElement* p_elem;
	if (!elem->next)
	{
		elem = NULL;
		return;
	}

	if (head == elem) pop_front();

	else {
		p_elem = head;
		while (p_elem->next != elem) p_elem = p_elem->next;

		p_elem->next = elem->next;
		delete elem;
		elem = NULL;
	}
}

//---- CDM Section

MyString SelectorList::get_attr_value_by_prop_and_id(MyString prop) const {
	SelectorElement* elem = head;
	return elem->AttributesList->get_attr_value_by_prop(prop);
}

int SelectorList::remove_attr_value_by_prop_and_id(MyString prop)  {
	SelectorElement* elem = head;
	MyString ret = "";
	bool attr_remove_ind = 0;

	// for all selectors attributes are the same => delete only one time
	attr_remove_ind = elem->AttributesList->remove_attr_value_by_prop(prop);

	return attr_remove_ind;
}

MyString SelectorList::get_selector_name_by_id(int id) const {
	SelectorElement* elem = head;
	MyString ret = "";
	for (int i = 1; elem; elem = elem->next, i++) {
		if (id == i) return elem->name;
	}
	return ret;
}

int SelectorList::get_selector_name_num(MyString str) const {
	SelectorElement* elem = head;
	int ret = 0;
	for (int i = 1; elem; elem = elem->next, i++) {
		if (elem->name == str) ret++;
	}
	return ret;
}


int SelectorList::get_attrs_num() const {
	SelectorElement* elem = head;
	int ret = 0;

	// in a block all selectors have the same amount of attributes =>
	// => we take only the 1st one
	ret = elem->AttributesList->Size();
	return ret;
}

int SelectorList::get_attrs_num_without_duplicates() const{
	SelectorElement* elem = head;
	int ret = 0;
	// in a block all selectors have the same amount of attributes =>
	// => we take only the 1st one
	ret = elem->AttributesList->get_attrs_num_without_duplicates();
	return ret;
}


int SelectorList::attr_name_num(MyString prop) const {
	SelectorElement* elem = head;
	int count = 0;
	count = elem->AttributesList->attr_name_num(prop);
	return count;
}

MyString SelectorList::get_attr_value_by_selector_and_attr_name(MyString selector_name, MyString prop)const
{
	SelectorElement* elem = head;
	MyString value = "";

	for (int i = 1; elem; elem = elem->next, i++) {
		if (elem->name == selector_name)
		{
			value = elem->AttributesList->get_attr_value_by_prop(prop);
			if (value.Length()) return value;
		}
	}
	return value;
}
