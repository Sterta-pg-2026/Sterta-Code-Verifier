#pragma once
// getting of the command consisting of 1 section
void get_cmd_1(SplitList* splitCMD, MyString& cmd1)
{
	cmd1 = splitCMD->pop_front();
	CleanStrAll(cmd1);
}

// getting three sections of a command
void get_cmd_1_3(SplitList* splitCMD, MyString& cmd1, MyString& cmd2, MyString& cmd3)
{
	cmd1 = splitCMD->pop_front();
	cmd2 = splitCMD->pop_front();
	cmd3 = splitCMD->pop_front();
	CleanStrAll(cmd1);
	CleanStrAll(cmd2);
	CleanStrAll(cmd3);
}

// stage of reading commands
void readCMD(CSSNodeList* cssNodeList, int& iStage)
{
	char cCMDLine[STR_MAX_SIZE] = "";
	//	MyString end = CMD_START_CSS"\n";

	while (fgets(cCMDLine, STR_MAX_SIZE, FILE_IN) != NULL)
	{
		MyString msCMDLineTmp = cCMDLine;

		// skipping empty lines
		CleanStrAll(msCMDLineTmp);
		if (msCMDLineTmp.Length() == 0) continue;

		SplitList* splitCMD = new SplitList;
		// splitting the string and attaching its parts to the list
		int iCMDPartNum = MyStringSplit(msCMDLineTmp, splitCMD, ',');

		MyString cmd1 = "", cmd2 = "", cmd3 = "";
		// we are interested only in commands consisting of 1 or 3 section
		switch (iCMDPartNum)
		{
		case 1:
			get_cmd_1(splitCMD, cmd1);
			if (msCMDLineTmp == "****")
			{
				// finish of the command processing and 
				// going to the stage of reading CSS
				iStage = STAGE_READ_CSS;
				return;
			}

			// ?
			if (msCMDLineTmp == "?")
			{
				// CMD_CSS_PASRT_COUNT
				cmd1.Print();
				printf(" == %d\n", cssNodeList->getCSS_section_num());

			}
			break;
		case 3:
			get_cmd_1_3(splitCMD, cmd1, cmd2, cmd3);

			// SELECTORS CMD
			if (cmd2 == "S")
			{
				if (cmd1.isInteger())
				{
					if (cmd3.isInteger()) // 1,S,1
					{
						MyString ret = cssNodeList->getCSS_selectors_by_section_snum(cmd1.Str2Int(), cmd3.Str2Int());
						if (ret != "" && ret != EMPTY_SELECTOR_NAME) _PRINT_S
					}
					else // 1,S,?
					{
						if (cmd3 == "?")
						{
							int ret = cssNodeList->getCSS_section_selectors_num(cmd1.Str2Int());
							if (ret >= 0) _PRINT_D
						}
					}
				}
				else
				{
					//	n, S, ?
					int ret = cssNodeList->getCSS_selector_name_num(cmd1);
					if (ret >= 0) _PRINT_D
				}

			}
			else // ATRIBUTES CMD

				if (cmd2 == "A")
				{
					if (cmd1.isInteger())
					{
						if (cmd3 == "?") // 1,A,?
						{
							int ret = cssNodeList->getCSS_section_attrs_num(cmd1.Str2Int());
							if (ret > 0) _PRINT_D
						}
						else // 1,A,n --- name
						{
							MyString ret = cssNodeList->getCSS_attr_value_by_prop_and_id(cmd1.Str2Int(), cmd3);
							if (ret != "") _PRINT_S
						}
					}
					else // n,A,?
					{
						int ret = cssNodeList->getCSS_attr_name_num(cmd1);
						if (ret >= 0) _PRINT_D
					}

				}
				else // SEARCH CMD

					if (cmd2 == "E")
					{
						MyString ret = cssNodeList->getCSS_attr_value_by_selector_and_attr_name(cmd1, cmd3);
						if (ret != "") _PRINT_S
					}
					else // DELETE CMD

						if (cmd2 == "D")
						{
							if (cmd3 == "*") // i,D,*
							{
								bool ret = cssNodeList->removeCSS_block_by_id(cmd1.Str2Int());
								if (ret == true) _PRINT_DEL
							}
							else // i,D,n
							{
								bool ret = cssNodeList->removeCSS_attr_value_by_prop_and_id(cmd1.Str2Int(), cmd3);
								if (ret) _PRINT_DEL
							}
						}
			break;
		default:
			continue;
		}
	}
}
