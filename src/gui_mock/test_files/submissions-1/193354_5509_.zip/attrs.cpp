#include "str.h"
#include "attrs.h"

bool Attrs::iterate()
{
    if (pos == nullptr or pos->next == nullptr)
        return false;
    else
    {
        pos = pos->next;
        return true;
    }
}

Attr *Attrs::get_it_val()
{
    return pos;
}

void Attrs::seek_start()
{
    pos = first;
}

void Attrs::push_back(Str *name, Str *val)
{
    /*Attr* tmp = first;
    while (first->next!=nullptr)
    {
        tmp=tmp->next;
    }*/

    Attr *pb = new Attr;
    pb->name = *name;
    pb->val = *val;

    if (first == nullptr)
    {
        first = pb;
        last = first;
    }
    else
    {
        delete_by_name(name);
        last->next = pb;
        last = last->next;
    }
    siz++;
}

Attr *Attrs::get_last()
{
    return last;
}

Attr::Attr()
{
}

Attrs::Attrs()
{
    first = nullptr;
    last = first;
}

Attrs::~Attrs()
{
    Attr *tmp = first;
    while (tmp != nullptr)
    {
        Attr *ax = tmp;
        tmp = tmp->next;
        delete ax;
    }
    first = nullptr;
    last = first;
    siz = 0;
}

void Attrs::print()
{
    Attr *tmp = first;
    while (tmp != nullptr)
    {
        tmp->name.print();
        putchar(':');
        tmp->val.print();
        putchar('\n');
        tmp = tmp->next;
    }
}

int Attrs::size()
{
    return siz;
}

Attr *Attrs::get_by_name(Str *n)
{
    seek_start();
    for (int i = 0; i < siz; ++i) // dziala jak contains
    {

        if (get_it_val()->name.equals(n)) // tutaj trzeba funkcje equals
            return pos;
        iterate();
    }
    return nullptr;
}

bool Attrs::delete_by_name(Str *n)
{
    seek_start();
    Attr *pre = get_it_val();
    for (int i = 0; i < siz; ++i)
    {
        if (get_it_val()->name.equals(n))
        {
            if (get_it_val() == first)
            {
                first = get_it_val()->next;
                siz--;
            }
            else if (get_it_val() == last)
            {
                last=pre;
                last->next=nullptr;
                siz--;
            }
            else
            {
                siz--;
                pre->next = get_it_val()->next;
            }
            delete get_it_val();

            return true;
        }
        pre = get_it_val();
        iterate();
    }
    return false;
}