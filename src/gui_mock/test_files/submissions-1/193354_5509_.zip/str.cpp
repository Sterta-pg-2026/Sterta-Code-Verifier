
#include "str.h"

int Str::size()
{
    return str_size;
}

void Str::clear()
{

    Aux *tmp = first;
    while (tmp != nullptr)
    {
        Aux *ax = tmp;
        tmp = tmp->next;
        delete ax;
    }
    first = nullptr;
    last = first;
    str_size = 0;
}

void Str::push_back(char a)
{
    if (a < 32 or a > 126)return;

    if (first == nullptr)
    {
        first = new Aux;
        first->val = a;
        last = first;
    }
    else
    {
        last->next = new Aux;
        last = last->next;
        last->val = a;
    }
    str_size++;
}

Str::Str(int siz)
{
    first = new Aux;
    Aux *tmp = first;
    str_size++;
    for (int i = 1; i < siz; ++i)
    {
        tmp->next = new Aux;
        tmp = tmp->next;
        last = tmp;
        str_size++;
    }
}

bool Str::equals(char other[], int len)
{
    if (str_size != len)
    {
        return false;
    }
    Aux *s1 = first;
    // Aux *s2 = other.first;
    // int ind = sizeof(oter);

    for (int i = 0; i < str_size; ++i)
    {
        if (s1->val != other[i])
            return false;
        s1 = s1->next;
    }
    return true;
}


bool Str::broken()
{
    int licz=0;
    Aux* tmp = first;
    while (tmp!=nullptr)
    {
        if (tmp->val == ',')licz++;
        tmp=tmp->next;
    }
    if (licz >=3)return true;
    return false;
    
}

bool Str::verybroken()
{
    int licz=0;
    Aux* tmp = first;
    while (tmp!=nullptr)
    {
        if (tmp->val == ',')licz++;
        tmp=tmp->next;
    }
    if (licz ==1)return true;
    return false;
    
}

bool Str::equals(Str* other)
{
    Aux* s1=first;
    Aux* s2=other->first;   
    while (s1 != nullptr and s2 != nullptr)
    {

        while ( s1!=nullptr and (s1->val <= 32 or s1->val >= 126))
        {
            s1=s1->next;
        }

        while ( s2!=nullptr and (s2->val <= 32 or s2->val >= 126))
        {
            s2=s2->next;
        }
        
        if ((s2 ==nullptr) xor (s1 ==nullptr))
        return false;
        if (s1 == nullptr and s2 ==nullptr)
        return true;

        if (s1->val != s2->val)return false;
        s1=s1->next;
        s2=s2->next;

        
    }
    while (s1 != nullptr)
    {
        if (!(s1->val <= 32 or s1->val >= 126))
        return false;
        s1=s1->next;
    }

     while (s2 != nullptr)
    {
        if (!(s2->val <= 32 or s2->val >= 126))
        return false;
        s2=s2->next;
    }
    
    return true;
    
}

bool Str::equals_no_white(char other[], int len)
{
    Aux *s1 = first;

    Str pom;
    while (s1!=nullptr)
    {
        if(s1->val <= 32 or s1->val >= 126)
        {
            s1 = s1->next;
        }
        else
        {
            pom.push_back(s1->val);
            s1 = s1->next;
        }

    }
    return pom.equals(other, len);
}


bool Str::empty()
{
    Aux* s1 = first;

    Str pom;
    while (s1 != nullptr)
    {
        if (s1->val <= 32 or s1->val >= 126)
        {
            s1 = s1->next;
        }
        else
        {
            s1 = s1->next;
            return false;
        }

    }
    return true;
}


bool Str::equals_back(char other[], int len)
{
    Aux *s1 = first;

    Str pom;
    for (int i=0;i<str_size-len;++i)
    {
        s1=s1->next;
    }
    while (s1!=nullptr)
    {
        pom.push_back(s1->val);
        s1=s1->next;
    }
    
    return pom.equals(other, len);
}


bool Str::operator==(Str other)
{
    if (str_size != other.size())
    {
        return false;
    }
    Aux *s1 = first;
    Aux *s2 = other.first;

    for (int i = 0; i < str_size; ++i)
    {
        if (s1->val != s2->val)
            return false;
        s1 = s1->next;
        s2 = s2->next;
    }
    return true;
}

Str &Str::operator=(const Str &other)
{
    // Str* ret = new Str;
    this->clear();
    if (other.str_size == 0)
        return *this;
    Aux *tmp = other.first;
    do
    {
        this->push_back(tmp->val);
        tmp = tmp->next;
    } while (tmp != nullptr);

    return *this;
}

Str::Str(const Str& other)
{
    first = nullptr;
    last = first;
    Aux* tmp = other.first;
    while (tmp != nullptr)
    {
        push_back(tmp->val);
        tmp = tmp->next;
    }
}

Str::Str()
{
    first = nullptr;
    last = first;
}

Str::~Str()
{
    clear();
}

void Str::print()
{
    Aux *tmp = first;
    while (tmp != nullptr and (tmp->val <= 32 or tmp->val >= 126))
    {
        tmp = tmp->next;
    }
    while (tmp != nullptr)
    {
       
        putchar(tmp->val);
        tmp = tmp->next;
    }
    // putchar('\n');
}


Str Str::get_argument(int n)
{
    int k=0;
    Str pom;
    Aux* tmp=first;

    while (tmp!=nullptr)
    {
        if (tmp->val == ',')
        {
            k++;
            tmp=tmp->next;
            continue;
        }
        if (k == n)
        {
            pom.push_back(tmp->val);
        }
        if (k > n)break;

        tmp=tmp->next;
    }
    return pom;
    
}

int Str::to_int()
{
    int out=0;
    Aux* tmp=first;
    while (tmp!=nullptr)
    {
        if (tmp->val >= '0' and tmp->val <= '9')
        out = out *10+(tmp->val - 48);
        tmp=tmp->next;
    }
    return out;
       
}


bool Str::contains(char other[], int len)
{
    Aux* tmp=first;
    for (int i=0;i<=str_size-len;++i)
    {   
        Aux* tmp_2=tmp;
        bool ok = true;
        for (int j=0;j<len;++j)
        {
            if (other[j] != tmp_2->val)
            {
                ok = false;
                break;
            }
            tmp_2=tmp_2->next;

        }
        if (ok)return true;
        tmp=tmp->next;
    }
    return false;
}

bool Str::is_num()
{
    Aux* tmp=first;
    while (tmp != nullptr)
    {
        if (tmp->val < 48 or tmp->val > 57)return false;
        tmp=tmp->next;
    }
    return true;

    
}
