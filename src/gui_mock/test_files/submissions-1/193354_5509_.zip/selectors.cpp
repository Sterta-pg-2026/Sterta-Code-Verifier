#include "str.h"
#include "selectors.h"


bool Selectors::iterate()
{
    if (pos==nullptr or pos->next==nullptr)return false;
    else
    {
        pos=pos->next;
        return true;
    }
}

Selector* Selectors::get_it_val()
{
    return pos;
}

void Selectors::seek_start()
{
    pos=first;
}

void Selectors::push_back(Str* other_name)
{
    // z jakiegos powodu ta funkcja dzwoni po destruktor na other name
    Selector* tmp = first;

    if (tmp == nullptr)
    {
        Selector *pb = new Selector;
        pb->name=*other_name;
        first = pb;
        siz++;
        return;
    }
    while ( tmp!=nullptr and tmp->next!=nullptr ) 
    {
        tmp=tmp->next;
    }
    Selector *pb = new Selector;
    pb->name=*other_name;
    tmp->next = pb;
    siz++;
}

Selector::Selector()
{
    next=nullptr;
}

Selectors::Selectors()
{
    first=nullptr;
    pos=nullptr;
}

Selectors::~Selectors()
{
    Selector *tmp = first;
    while (tmp != nullptr)
    {
        Selector *ax = tmp;
        tmp = tmp->next;
        delete ax;
    }
    first = nullptr;
    pos=nullptr;
    siz = 0;
}

void Selectors::print()
{
    Selector* tmp=first;
    while (tmp!=nullptr)
    {
        tmp->name.print();
        tmp=tmp->next;
        putchar('\n');
    }
    
}

int Selectors::size()
{
    return siz;
} 


Selector* Selectors::get_nth(int n)
{
    seek_start();
    for (int i=0;i<n;++i)
    {
        if (!iterate())return nullptr;
    }
    return get_it_val();

}

Selector* Selectors::get_by_name(Str* n)
{
    seek_start();
    for (int i=0;i<siz;++i)
    {
        

        if (get_it_val()->name.equals(n))//tutaj trzeba funkcje equals
        return pos;
        iterate();
    }
    return nullptr;

}