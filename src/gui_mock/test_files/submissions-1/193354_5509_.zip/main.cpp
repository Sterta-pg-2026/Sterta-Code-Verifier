#include <iostream>
#include "section.h"
#include "attrs.h"
#include "str.h"
#include "selectors.h"

enum states
{
    selektor = 0,
    attr_name = 1,
    attr_val = 2,
    attr_end = 3
};

// 0 - css 1 - command

char getbchar()
{
    char c = getchar();
    while (c == '\n' or c == '\r')
    {
        c = getchar();
    }
    return c;
}

char getbbchar()
{
    char c = getchar();
    if (c < 0)
        return -1;
    while ((c < 33 or c > 126) and !(c == '\r' or c == '\n' or c == ' '))
    {
        c = getchar();
        if (c < 0)
            return -1;
    }
    return c;
}
using namespace std;

int main()
{
    bool command_type = 0;
    char c = '0';
    Str *_ = new Str();
    states state;
    state = selektor;
    Str buf;
    buf.clear();
    bool verybroke = false;

    Section *sec = new Section;
    Sections secs;
    bool kill = 0;
    while (true)
    {

        // scanf(&c);
        c = getbbchar();
        if (c < 0)
            kill = 1;
        if (!command_type)
        {
            // CSS

            switch (state)
            {
            case selektor:
                if (c == '{')
                {
                    state = attr_name;
                    if (!buf.empty())
                        sec->selectors.push_back(&buf);
                    buf.clear(); // 0x602000000010
                }
                else if (c == ',')
                {
                    sec->selectors.push_back(&buf);
                    buf.clear();
                }
                else if (buf.equals_no_white((char *)"????", 4) and (c == '\n' or c == '\r'))
                {
                    command_type = 1;
                    buf.clear();
                    break;
                }
                else
                {
                    buf.push_back(c);
                }
                break;

            case attr_name:
                if (c == ':')
                {
                    // TODO save attr name

                    sec->attrs.push_back(&buf, _);
                    state = attr_val;
                    buf.clear();
                }
                else
                {
                    buf.push_back(c);
                }
                break;

            case attr_val:
                if (c == ';' or c == '\n' or c == '\r')
                {
                    // TODO save attr val
                    sec->attrs.get_last()->val = buf;
                    state = attr_end;
                    buf.clear();
                }
                else
                {
                    buf.push_back(c);
                }
                break;

            case attr_end:
                if (c == '}')
                {
                    secs.push_back(sec);

                    sec = new Section;

                    state = selektor;
                    buf.clear();
                }
                else if (c != '\n' and c != '\r')
                {
                    buf.clear();
                    buf.push_back(c);
                    state = attr_name;
                }
                break;
            }
        }
        else
        {
            if (c == '\n' or c == EOF or c == -1)
            {
                if (verybroke)
                {
                    verybroke=0;
                }
                else if (buf.equals_no_white((char *)"****", 4))
                {
                    command_type = 0;
                    buf.clear();
                }
                else if (buf.equals_no_white((char *)"?", 1))
                {
                    printf("? == %d\n", secs.size());
                }
                else if (buf.equals_back((char *)",S,?", 4))
                {
                    Str arg = buf.get_argument(0);
                    if (arg.is_num())
                    {
                        Section *tmp = secs.get_nth(arg.to_int() - 1);
                        if (tmp != nullptr)
                            printf("%d,S,? == %d\n", arg.to_int(), tmp->selectors.size());
                    }
                    else
                    {
                        if (!buf.verybroken())
                        {
                            if (!buf.broken())
                            {
                                int licz = 0;
                                secs.seek_start();
                                do
                                {
                                    if (secs.get_it_val() == nullptr)
                                        break;
                                    Section *tmp = secs.get_it_val();
                                    if (tmp->selectors.get_by_name(&arg) != nullptr)
                                        licz++;
                                } while (secs.iterate());

                                arg.print();
                                printf(",S,? == %d\n", licz);
                            }
                            else
                            {
                                buf.clear();
                            }
                        }
                        else
                        {
                            verybroke = true;
                            buf.clear();
                        }
                    }
                }
                else if (buf.equals_back((char *)",A,?", 4))
                {
                    Str arg = buf.get_argument(0);
                    if (arg.is_num())
                    {
                        Section *tmp = secs.get_nth(arg.to_int() - 1);
                        if (tmp != nullptr)
                            printf("%d,A,? == %d\n", arg.to_int(), tmp->attrs.size());
                    }
                    else
                    {
                        int licz = 0;
                        secs.seek_start();
                        do
                        {
                            if (secs.get_it_val() == nullptr)
                                break;
                            Section *tmp = secs.get_it_val();
                            if (tmp->attrs.get_by_name(&arg) != nullptr)
                                licz++;
                        } while (secs.iterate());

                        arg.print();
                        printf(",A,? == %d\n", licz);
                    }
                }
                else if (buf.contains((char *)",S,", 3))
                {
                    int arg1 = buf.get_argument(0).to_int();
                    int arg2 = buf.get_argument(2).to_int();

                    Section *tmp = secs.get_nth(arg1 - 1);
                    if (tmp != nullptr)
                    {
                        Selector *tmp2 = tmp->selectors.get_nth(arg2 - 1);
                        if (tmp2 != nullptr)
                        {
                            printf("%d,S,%d == ", arg1, arg2);
                            tmp2->name.print();
                            putchar('\n');
                        }
                    }
                    // putchar('p');
                }
                else if (buf.contains((char *)",A,", 3))
                {
                    int arg1 = buf.get_argument(0).to_int();
                    Str arg2 = buf.get_argument(2);
                    Section *tmp05 = secs.get_nth(arg1 - 1);
                    if (tmp05 != nullptr)
                    {
                        Attr *tmp = tmp05->attrs.get_by_name(&arg2);
                        if (tmp != nullptr)
                        {
                            printf("%d,A,", arg1);
                            arg2.print();
                            printf(" == ");
                            tmp->val.print();
                            putchar('\n');
                        }
                    }
                    // putchar('p');
                }
                else if (buf.contains((char *)",E,", 3))
                {
                    Str arg1 = buf.get_argument(0);
                    Str arg2 = buf.get_argument(2);

                    secs.seek_back();
                    do
                    {
                        Section *tmp = secs.get_it_val();
                        if ((tmp != nullptr) and (tmp->selectors.get_by_name(&arg1) != nullptr))
                        {
                            Attr *find = tmp->attrs.get_by_name(&arg2);
                            if (find != nullptr)
                            {
                                arg1.print();
                                printf(",E,");
                                arg2.print();
                                printf(" == ");
                                find->val.print();
                                putchar('\n');
                                break;
                            }
                        }
                    } while (secs.iterate_back());

                    // putchar('p');
                }
                else if (buf.contains((char *)",D,*", 4))
                {
                    int arg1 = buf.get_argument(0).to_int();
                    Section *tmp = secs.get_nth(arg1 - 1);
                    if (tmp != nullptr)
                    {
                        secs.delete_by_ptr(tmp);

                        printf("%d,D,* == deleted\n", arg1);
                    }
                }
                else if (buf.contains((char *)",D,", 3))
                {
                    int arg1 = buf.get_argument(0).to_int();
                    Str arg2 = buf.get_argument(2);

                    Section *tmp = secs.get_nth(arg1 - 1);
                    if (tmp != nullptr)
                    {
                        if (tmp->attrs.delete_by_name(&arg2))
                        {

                            if (tmp->attrs.size() == 0)
                                secs.delete_by_ptr(tmp);

                            printf("%d,D,", arg1);
                            arg2.print();
                            printf(" == deleted\n");
                        }
                    }
                }
                else
                {
                    if (buf.verybroken() and buf.size() > 0)
                    verybroke=true;
                }

                buf.clear();
            }
            else
            {
                buf.push_back(c);
            }
            if (kill)
                return 0;
        }
    }
}

/*

#breadcrumb
{
width: 80%;
font-size: 9pt;
}


h1, body {
min-width: 780px;
margin: 0;
padding: 0;
font-family: "Trebuchet MS", "Lucida Grande", Arial;
font-size: 85%;
color: #666666;
}
h1, h2, h3, h4, h5, h6 {color: #0066CB;}

????
?
1,S,?
1,S,1
1,A,?
2,A,font-family
h1,S,?
color,A,?
h1,E,color
1,A,padding
1,D,*
?
2,D,color
?
****
h1, h2, h3, h4, h5, h6 {color: #0066FF;}
????
?

*/