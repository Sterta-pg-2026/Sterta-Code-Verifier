#pragma once
#include "str.h"

class Attr{
    public:
    Str name;
    Str val;
    Attr* next=nullptr;

    Attr();
};

class Attrs
{
private:
    Attr* first;
    Attr* pos;
    Attr* last;
    int siz=0;

public:
    Attrs();
    ~Attrs();
    bool iterate();
    void seek_start();
    Attr* get_it_val();
    void push_back(Str* ,Str*);
    Attr* get_by_name(Str* n);
    bool delete_by_name(Str* n);
    Attr* get_last();
    int size();
    void print();
};


