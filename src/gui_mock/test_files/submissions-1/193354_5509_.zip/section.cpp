#include "section.h"

void Sections::push_back(Section *pb)
{

    if (first == nullptr)
    {
        first = new Section_block;
        last = first;
    }

    Section_block *tmp = last;
    /*while (tmp->next != nullptr)
    {
        tmp = tmp->next;
    }*/

    if (tmp->tab[T-1] != nullptr)
    {
        tmp->next = new Section_block;
        tmp->next->pre = tmp;
        tmp = tmp->next;
        last = tmp;
        tmp->occupied = 0;
    }

    int ti = T - 1;
    while (ti >= 0 and tmp->tab[ti] == nullptr)
    {
        ti--;
    }
    ti++;

    tmp->tab[ti] = pb; // new Section;
    tmp->tab[ti]->block = tmp;

    // tmp->tab[tmp->occupied]=pb;
    // int ind = tmp->occupied;

    /*b->selectors.seek_start();
    do
    {
        if (pb->selectors.get_it_val() == nullptr)
            continue;
        tmp->tab[ind]->selectors.push_back(&(pb->selectors.get_it_val()->name));
    } while (pb->selectors.iterate());

    pb->attrs.seek_start();
    do
    {
        if (pb->attrs.get_it_val() == nullptr)
            continue;
        tmp->tab[ind]->attrs.push_back(&(pb->attrs.get_it_val()->name), &(pb->attrs.get_it_val()->val));
    } while (pb->attrs.iterate());*/

    tmp->occupied += 1;
    siz += 1;
    


    int licz = 0;
    for (int i = 0; i < T; ++i)
    {
        if (first->tab[i] != nullptr)
        {
            licz++;
        }
    }
    
}
//

Section *Sections::get_nth(int n)
{

    Section_block *tmp = first;
    int i = n;
    int ti = 0;
    while ((i >= 0) and (tmp != nullptr))
    {

        if (i == 0 and tmp->tab[ti] != nullptr)
            return tmp->tab[ti];
        if (tmp->tab[ti] != nullptr)
        {
            i--;
        }
        ti += 1;
        if (ti == T)
        {
            ti = 0;
            tmp = tmp->next;
        }
    }
    return nullptr;
}

void Sections::print()
{
    int i = 0;
    while (get_nth(i) != nullptr)
    {

        printf("Section: ");
        printf("%d \n", i);
        get_nth(i)->selectors.print();
        get_nth(i)->attrs.print();
        i++;
    }
}

int Sections::size()
{
    return siz;
}

bool Sections::iterate()
{
    if (pos.sec_ind == nullptr)
        return false;
    if (pos.tab_ind < T - 1)
    {
        pos.tab_ind++;
        if (pos.sec_ind->tab[pos.tab_ind] == nullptr)
            return iterate();
        else
            return true;
    }
    else if (pos.tab_ind >= T - 1)
    {
        pos.tab_ind = 0;

        if (pos.sec_ind->next != nullptr)
        {
            pos.sec_ind = pos.sec_ind->next;
            return true;
        }
        else
            return false;
    }
    return false;
}

bool Sections::iterate_back()
{
    do
    {
        if (pos.tab_ind <= 0)
        {
            if (pos.sec_ind->pre == nullptr)
            {
                return false;
            }
            else
            {
                pos.tab_ind = T - 1;
                pos.sec_ind = pos.sec_ind->pre;
            }
        }
        else
        {
            pos.tab_ind--;
        }
    } while (pos.sec_ind->tab[pos.tab_ind] == nullptr);
    return true;
}

Section *Sections::get_it_val()
{
    return pos.sec_ind->tab[pos.tab_ind];
}

void Sections::seek_start()
{

    pos.sec_ind = first;
    pos.tab_ind = 0;
    while (pos.sec_ind->tab[pos.tab_ind] == nullptr)
    {
        pos.tab_ind++;
    }
}

void Sections::seek_back()
{
    pos.sec_ind = last;
    pos.tab_ind = T - 1;
    while (pos.sec_ind->tab[pos.tab_ind] == nullptr)
    {
        pos.tab_ind--;
    }
}

void Sections::delete_by_ptr(Section *n)
{
    
    if (n->block->occupied <= 1)
    {
        if (n->block == first and n->block==last)
        {
            siz=0;
            first=nullptr;
            last=nullptr;
        }
        else if (n->block == first)
        {
            first = n->block->next;
            first->pre = nullptr;
            siz--;
            // delete[] n->block->tab;
        }
        else if (n->block == last)
        {
            n->block->pre->next = nullptr;
            last = n->block->pre;
            siz--;
        }
        else
        {
            n->block->pre->next = n->block->next;
            n->block->next->pre = n->block->pre;
            siz--;
            // delete[] n->block->tab;
        }
        Section_block *_ = n->block;

        delete n;
        delete _;
        return;
    }
    else
    {
        for (int i = 0; i < T; ++i)
        {
            if (n->block->tab[i] == n)
            {
                n->block->tab[i] = nullptr;
                n->block->occupied--;
                delete n;

                break;
            }
        }
        siz--;
    }
    
    // int licz = 0;
    // for (int i = 0; i < T; ++i)
    // {
    //     if (first->tab[i] != nullptr)
    //     {
    //         licz++;
    //     }
    // }
    // if (licz != first->occupied)
    // {
    //     putchar('h');
    // }
}

Section_block::Section_block()
{
    occupied = 0;
    next = nullptr;
    pre = nullptr;
    for (int i = 0; i < T; ++i)
    {
        tab[i] = nullptr;
    }
}
