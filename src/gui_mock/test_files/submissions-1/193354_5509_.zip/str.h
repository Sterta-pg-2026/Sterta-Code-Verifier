#include <cstdlib>
#include <stdio.h>
#pragma once


struct Aux{
    char val='*';
    Aux* next=nullptr;
};


class Str
{
private:
    /* data */
    int str_size = 0;
    Aux* first=nullptr;
    Aux* last=first;

public:
    Str(int);
    bool operator==(Str);
    Str(const Str& other);
    bool equals(Str*);
    bool empty();
    bool equals(char [],int len);
    bool equals_no_white(char [],int len);
    bool equals_back(char other[], int len);
    bool contains(char other[], int len);
    bool broken();
    bool verybroken();
    bool is_num();
    Str get_argument(int n);
    Str& operator=(const Str& );
    int to_int();
    Str();
    ~Str();
    int size();
    //int buf_size();
    //char &operator[](int);
    void clear();
    void push_back(char);
    void print();
};