#pragma once
#include "str.h"

class Selector{
    public:
    Str name;
    Selector* next=nullptr;

    Selector();
};

class Selectors
{
private:
    Selector* first=nullptr;
    Selector* pos=nullptr;
    int siz=0;

public:
    Selectors();
    ~Selectors();
    bool iterate();
    void seek_start();
    Selector* get_it_val();
    void push_back(Str*);
    Selector* get_nth(int n);
    Selector* get_by_name(Str* n);
    int size();
    void print();
};


