#pragma once
#include "selectors.h"
#include "str.h"
#include "attrs.h"

//const int T=8;
#define T 17

struct Section_block;


class Section
{
private:
    
public:
    Selectors selectors;
    Attrs attrs;
    Section_block* block;
    //~Section();
};


struct Section_block
{

    int occupied=0;
    Section* tab[T];
    Section_block* next=nullptr;
    Section_block* pre=nullptr;

    Section_block();
};

struct it
{
    int tab_ind = 0;
    Section_block* sec_ind =nullptr;
};


class Sections
{
    private:
    int siz=0;
    Section_block* first=nullptr;
    Section_block* last=nullptr;
    it pos;
    public:

    int size();
    void push_back(Section* pb);
    
    Section* get_nth(int n);
    void delete_by_ptr(Section* n);
    void print();
    void seek_start();
    void seek_back();
    bool iterate();
    bool iterate_back();
    Section* get_it_val();


};